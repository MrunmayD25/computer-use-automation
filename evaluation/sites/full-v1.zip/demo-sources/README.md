# Computer-use demo applications

This source bundle retains all eleven banking web applications, the shared
vendor portal and financial database, assets and license notices, build inputs,
and unit/browser tests. The assignment's canvas teller is in evaluation/canvas
outside this ZIP. No application source or behavior was changed during cleanup.

The submission README documents setup and its three demo targets. To build all
bundled applications from this directory:

```sh
npm ci --prefix environments/database/financial
npm ci --prefix environments
npm --prefix environments run build
```

See each application's README for its start command and ports. Package scripts
retain type checks, unit tests and browser verification. The shared evaluation
catalog and executable verifier code remain available for those tests.

The latest saved verification run for each application is retained with its
matching capability manifest and qualification reports. Superseded runs, generated
aggregate/seed reports, development prompts, handoff notes, and old packaging
helpers are excluded. These saved records describe their recorded source revisions;
they do not certify this source snapshot through Git history. The assignment's
current discovery, replay, privacy and handoff evidence remains in the top-level
evidence directory. The included environment-release-audit module can validate
record structure. Its Git-history-based release command cannot establish current
source provenance from this snapshot, which intentionally has no Git history.

The archive contains no Git history or installed dependencies. Retained local
user-directory references are redacted. The outer manifest hashes this bundle.
