# Document & Ledger Workstation

A canvas document viewer + ledger grid workstation over the shared financial database.
See [SPEC.md](SPEC.md) for the interface contract and
IMPLEMENTATION.md (historical material omitted from this bundle) for the capability record.

## Requirements

- Node ≥ 25.9
- `pdftotext` (Poppler) on PATH for the PDF text layer used by the document canvas.
- A seeded financial SQLite world — the canonical demo lives at
  `../database/financial/.runtime/financial.sqlite` (seed once with
  `npm --prefix ../database/financial run seed -- --path <file>`); tests and
  verification always run on disposable copies.

## Commands

From this directory (or via `npm run … -w document-ledger-workstation` in
`environments/`):

| Command | Purpose |
| --- | --- |
| `npm install` (workspace root) | Install all workspace dependencies. |
| `npm run build` | Typecheck the server bundle and build the client to `dist/`. |
| `npm start` | Build, then serve `http://127.0.0.1:4370/`. |
| `npm run typecheck` | `tsc` over server+shared and the client. |
| `npm run lint` | ESLint over `src`, `test`, `verification`. |
| `npm test` | Vitest model + API suites on a disposable world copy. |
| `npm run verify` | Build, then Playwright specs against a disposable world copy. |
| `npm run check` | typecheck + lint + tests. |

## Running

```bash
npm start -- --port 4370 \
  --database ../database/financial/.runtime/financial.sqlite \
  --world financial-demo-v1 --operators OP0002,OP0003,OP0005,OP0001
```

Options: `--port`, `--host`, `--database` (or `FINANCIAL_DATABASE_PATH`), `--world`,
`--operators` (sign-on actor numbers; `OP0002` servicer, `OP0003` payments maker,
`OP0005` supervisor, `OP0001` viewer), `--verbose`, `--help`. Stop with Ctrl+C; the
listener and store close cleanly.

The workstation never seeds or mutates the canonical database at startup — it binds to
a named world already present in the file.

## Layout

- `src/server/` — Express API (`/api/i/:institutionId/…`), session/operator sign-on,
  review/execute endpoints, document bytes + text layout, scoped lists, exports.
- `src/client/model/` — pure viewport, grid, document, money, and paging math
  (unit-tested).
- `src/client/canvas/` — `GridCanvas` (frozen regions, hit test, overlay editor) and
  `DocumentCanvas` (pages, words, drag-select regions, zoom/pan).
- `src/client/operations/` — the 102-command catalog, field controls, pickers, and the
  review→commit→receipt dialog (with maker/checker approval request).
- `src/client/pages/` — list panes and record/document/case/merge/maintenance pages.
- `test/` — model unit tests and HTTP API tests on a disposable template world.
- `verification/` — Playwright specs, evidence artifacts under `verification/artifacts/`,
  and `canonical-guard.ts`, which fails the run if the canonical database changes.

