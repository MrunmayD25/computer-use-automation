/** Wire types shared by the workstation server and browser client. */

export interface InstitutionInfo {
  institutionId: string;
  datasetId: string;
  displayName: string;
  timeZone: string;
  defaultCurrency: string;
  asOf: string;
}

export interface OperatorInfo {
  actorId: string;
  actorNumber: string;
  displayName: string;
  permissions: string[];
}

export interface SessionInfo {
  institutions: InstitutionInfo[];
  operator: OperatorInfo | null;
  allowedOperatorNumbers: string[];
  fixedOperator: boolean;
}

export interface ApiErrorBody {
  error: { code: string; message: string; field?: string; currentVersion?: number };
}

/** One positioned text run on a rendered document page. */
export interface DocumentWord {
  text: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface DocumentPageLayout {
  pageNumber: number;
  /** Page dimensions in CSS-pixel points used by the canvas. */
  width: number;
  height: number;
  words: DocumentWord[];
}

export interface DocumentLayout {
  versionId: string;
  mediaType: string;
  pages: DocumentPageLayout[];
  /** CSV documents expose their parsed grid so the canvas can hit-test cells. */
  csv?: { rows: string[][] };
}
