import { z } from 'zod';

/** All request query strings are plain strings; these coerce and bound them. */

const intParam = (minimum: number, maximum: number) => z.coerce.number().int().min(minimum).max(maximum);
const text = z.string().max(500);

export const operatorBodySchema = z.strictObject({ actorNumber: z.string().min(1).max(40) });

export const memberQuerySchema = z.strictObject({
  query: text.optional(), field: z.enum(['memberNumber', 'name', 'email', 'phone', 'accountNumber']).optional(),
  match: z.enum(['exact', 'prefix', 'contains']).optional(), status: text.optional(),
  sort: text.optional(), direction: z.enum(['asc', 'desc']).optional(),
  limit: intParam(1, 500).default(50), offset: intParam(0, 1_000_000).default(0), ids: text.optional(), maxResults: intParam(1, 10_000).optional(),
});

export const accountQuerySchema = z.strictObject({
  query: text.optional(), memberId: text.optional(),
  ownershipRole: z.enum(['owner', 'joint-owner', 'signer', 'guardian', 'beneficial-owner', 'beneficiary']).optional(), status: text.optional(), currency: text.optional(),
  sort: text.optional(), direction: z.enum(['asc', 'desc']).optional(),
  limit: intParam(1, 500).default(50), offset: intParam(0, 1_000_000).default(0), ids: text.optional(), maxResults: intParam(1, 10_000).optional(),
});

export const transactionQuerySchema = z.strictObject({
  startDate: text.optional(), endDate: text.optional(), direction: z.enum(['credit', 'debit']).optional(),
  minMinorUnits: intParam(0, 1_000_000_000_000).optional(), maxMinorUnits: intParam(0, 1_000_000_000_000).optional(),
  text: text.optional(), order: z.enum(['newest', 'oldest']).optional(), status: z.enum(['posted', 'reversed']).optional(), reference: text.optional(),
  limit: intParam(1, 200).default(50), offset: intParam(0, 1_000_000).default(0),
});

export const caseQuerySchema = z.strictObject({
  query: text.optional(), memberId: text.optional(), accountId: text.optional(), states: text.optional(), queueIds: text.optional(),
  priority: text.optional(), assignedActorId: text.optional(), overdue: text.optional(),
  sort: text.optional(), direction: z.enum(['asc', 'desc']).optional(), groupBy: text.optional(),
  limit: intParam(1, 500).default(50), offset: intParam(0, 1_000_000).default(0), ids: text.optional(), maxResults: intParam(1, 10_000).optional(),
});

export const documentQuerySchema = z.strictObject({
  query: text.optional(), documentType: text.optional(), memberId: text.optional(), accountId: text.optional(),
  sort: text.optional(), direction: z.enum(['asc', 'desc']).optional(),
  limit: intParam(1, 500).default(50), offset: intParam(0, 1_000_000).default(0),
});

export const activityQuerySchema = z.strictObject({
  query: text.optional(), memberId: text.optional(), accountId: text.optional(), caseId: text.optional(), actorId: text.optional(),
  limit: intParam(1, 500).default(50), offset: intParam(0, 1_000_000).default(0),
});

export const statementQuerySchema = z.strictObject({ period: z.string().regex(/^\d{4}-\d{2}$/u, 'Period must be YYYY-MM.') });

export const exportQuerySchema = transactionQuerySchema.extend({ format: z.enum(['csv']).optional() });

export const scopedListQuerySchema = z.looseObject({
  kind: z.string().min(1).max(60),
  limit: intParam(1, 500).optional(), offset: intParam(0, 1_000_000).optional(),
});

export const savedSearchQuerySchema = z.strictObject({ entity: z.enum(['members', 'accounts', 'cases']).optional() });

export const stampBodySchema = z.strictObject({
  members: z.array(z.string().max(80)).max(300).optional(),
  accounts: z.array(z.string().max(80)).max(300).optional(),
  cases: z.array(z.string().max(80)).max(300).optional(),
});

export const reviewBodySchema = z.strictObject({ command: z.record(z.string(), z.unknown()) });
export const executeBodySchema = z.strictObject({
  command: z.record(z.string(), z.unknown()),
  idempotencyKey: z.string().min(8).max(200),
});

export const financeQueryBodySchema = z.record(z.string(), z.unknown());

export const servicingQuerySchema = z.strictObject({
  limit: intParam(1, 500).default(200), offset: intParam(0, 1_000_000).default(0),
  documentType: text.optional(), kind: text.optional(),
});

export const identityQuerySchema = z.strictObject({
  displayName: text.optional(), memberNumber: text.optional(), email: text.optional(), phone: text.optional(), birthDate: text.optional(),
});

export const historicalStatementQuerySchema = z.strictObject({
  accountId: z.string().min(1), periodStart: z.string().min(10).max(10), periodEnd: z.string().min(10).max(10), format: text.optional(),
});
