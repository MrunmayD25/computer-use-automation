import { execFile } from 'node:child_process';

import type { DocumentLayout, DocumentPageLayout, DocumentWord } from '../shared/api.js';

/**
 * Extracts positioned text from document bytes so the canvas can hit-test real words.
 * PDF pages are laid out via `pdftotext -bbox`; CSV documents are parsed into a grid
 * whose cell geometry the client computes; images carry no text layer.
 */

function runPdftotext(bytes: Uint8Array): Promise<string> {
  return new Promise((resolvePromise, rejectPromise) => {
    execFile('pdftotext', ['-bbox', '-', '-'], { maxBuffer: 64 * 1024 * 1024 }, (error, stdout) => {
      if (error !== null) { rejectPromise(new Error(error.message)); return; }
      resolvePromise(stdout);
    }).stdin?.end(Buffer.from(bytes));
  });
}

const entity = (text: string): string => text
  .replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&quot;', '"').replaceAll('&#39;', "'").replaceAll('&amp;', '&');

function numberAttr(tag: string, name: string): number | undefined {
  const match = new RegExp(`${name}="([0-9.]+)"`, 'u').exec(tag);
  return match === null || match[1] === undefined ? undefined : Number.parseFloat(match[1]);
}

/** Parses `pdftotext -bbox` XHTML output into positioned pages. */
export function parsePdfBBox(html: string): DocumentPageLayout[] {
  const pages: DocumentPageLayout[] = [];
  const pagePattern = /<page\b([^>]*)>([\s\S]*?)<\/page>/gu;
  for (const pageMatch of html.matchAll(pagePattern)) {
    const attrs = pageMatch[1] ?? '';
    const body = pageMatch[2] ?? '';
    const width = numberAttr(attrs, 'width');
    const height = numberAttr(attrs, 'height');
    if (width === undefined || height === undefined) continue;
    const words: DocumentWord[] = [];
    for (const wordMatch of body.matchAll(/<word\b([^>]*)>([\s\S]*?)<\/word>/gu)) {
      const wordAttrs = wordMatch[1] ?? '';
      const xMin = numberAttr(wordAttrs, 'xMin');
      const yMin = numberAttr(wordAttrs, 'yMin');
      const xMax = numberAttr(wordAttrs, 'xMax');
      const yMax = numberAttr(wordAttrs, 'yMax');
      if (xMin === undefined || yMin === undefined || xMax === undefined || yMax === undefined) continue;
      words.push({ text: entity(wordMatch[2] ?? ''), x: xMin, y: yMin, width: Math.max(1, xMax - xMin), height: Math.max(1, yMax - yMin) });
    }
    pages.push({ pageNumber: pages.length + 1, width, height, words });
  }
  return pages;
}

/** Minimal RFC-4180 CSV parser used to lay out CSV documents on the canvas. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  let started = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index] ?? '';
    if (quoted) {
      if (char === '"') {
        if (text[index + 1] === '"') { field += '"'; index += 1; } else { quoted = false; }
      } else { field += char; }
      continue;
    }
    if (char === '"' && !started) { quoted = true; started = true; continue; }
    if (char === ',') { row.push(field); field = ''; started = false; continue; }
    if (char === '\n' || char === '\r') {
      if (char === '\r' && text[index + 1] === '\n') index += 1;
      row.push(field); rows.push(row); row = []; field = ''; started = false;
      continue;
    }
    field += char; started = true;
  }
  if (started || field !== '' || row.length > 0) { row.push(field); rows.push(row); }
  return rows;
}

/** Builds the canvas layout for a stored document version. */
export async function documentLayout(versionId: string, mediaType: string, bytes: Uint8Array, pageCount: number): Promise<DocumentLayout> {
  if (mediaType === 'application/pdf') {
    const pages = parsePdfBBox(await runPdftotext(bytes));
    return { versionId, mediaType, pages };
  }
  if (mediaType === 'text/csv' || mediaType === 'text/plain') {
    const rows = parseCsv(Buffer.from(bytes).toString('utf8'));
    return { versionId, mediaType, pages: [{ pageNumber: 1, width: 0, height: 0, words: [] }], csv: { rows } };
  }
  // Images and other media: no text layer; the client draws bytes at natural size.
  const pages: DocumentPageLayout[] = Array.from({ length: Math.max(1, pageCount) }, (_unused, index) => ({ pageNumber: index + 1, width: 0, height: 0, words: [] }));
  return { versionId, mediaType, pages };
}
