import { randomBytes } from 'node:crypto';
import { createServer } from 'node:http';
import { join } from 'node:path';

import type { DatasetBinding } from '@computer-use/financial-database';
import {
  authorizeQuery, accountDetail, accountDocuments, accountTransactions, caseDetail, caseGroupCounts,
  communicationJob, documentContent, executeCommand, institutionSummary, readFinanceRecord,
  listActivity, listApprovals, listCaseSubjectCorrectionEvidence, listDocumentAnnotations, listDocumentSignatures, listEffectivePolicyVersions,
  listMemberAddressDestinations, listMemberAddresses, listMemberCommunicationJobs, listMemberCommunicationPreferences, listMemberConsents,
  listMemberDocumentVersions, listMemberIdentityEvidence, listMemberMaintenanceRequests, listMemberRetentionHolds, listSavedSearches,
  listServicingApprovalCheckers, listServicingQueues, listFinanceRecords, maintenanceRequest, memberDetail, operatorProfile, queryFinance, queryMemberMergePlan,
  receiptByNumber, recordStamps, referenceData, renderCsv, renderGeneratedStatement, resolveMemberIdentity,
  retrieveCustomerExportArtifact, retrieveHistoricalStatement, reviewCommand, searchAccounts, searchCases, searchDocuments, searchMembers,
  servicingCaseDetail, statementData, statementPeriods, transactionsCsv,
  type FinancialStore, type Rejection, type ServiceContext, type ServicingQueryResult, type WritePrincipal,
} from '@computer-use/financial-database/services';
import express, { type NextFunction, type Request, type Response } from 'express';
import type { z } from 'zod';

import type { ApiErrorBody, InstitutionInfo, OperatorInfo, SessionInfo } from '../shared/api.js';
import {
  accountQuerySchema, activityQuerySchema, caseQuerySchema, documentQuerySchema, executeBodySchema, exportQuerySchema,
  financeQueryBodySchema, historicalStatementQuerySchema, identityQuerySchema, memberQuerySchema, operatorBodySchema,
  reviewBodySchema, savedSearchQuerySchema, scopedListQuerySchema, servicingQuerySchema, stampBodySchema, statementQuerySchema,
  transactionQuerySchema,
} from './schemas.js';
import { documentLayout } from './text-layout.js';

export const APPLICATION_ID = 'document-ledger-workstation';
export const APPLICATION_VERSION = '0.1.0';
const MAX_SESSIONS = 500;
const MEMBER_SORTS: Record<string, string> = {
  memberNumber: 'memberNumber', name: 'name', displayName: 'name', email: 'email', phone: 'phone', status: 'status', openedAt: 'openedAt',
};
const ACCOUNT_SORTS: Record<string, string> = {
  accountNumber: 'accountNumber', product: 'product', productName: 'product', status: 'status', currency: 'currency', balance: 'balance', nickname: 'nickname',
};
const CASE_SORTS: Record<string, string> = {
  caseNumber: 'caseNumber', state: 'state', status: 'state', priority: 'priority', queue: 'queue', queueName: 'queue',
  category: 'category', dueDate: 'dueDate', openedAt: 'openedAt', updatedAt: 'updatedAt',
};
const DOCUMENT_SORTS: Record<string, string> = {
  displayName: 'displayName', name: 'displayName', documentType: 'documentType', type: 'documentType', version: 'version',
  issuedAt: 'issuedAt', periodStart: 'periodStart', status: 'status',
};

export interface OperatorConfig {
  actorNumbers: readonly string[];
  fixed: boolean;
}

export interface WorkstationOptions {
  store: FinancialStore;
  bindings: readonly DatasetBinding[];
  operator: OperatorConfig;
  mode: 'shared' | 'verification';
  principalKind?: WritePrincipal['kind'];
  publicDirectory?: string;
  host?: string;
  port?: number;
  verbose?: boolean;
  onClose?: () => void;
}

export interface WorkstationHandle {
  origin: string;
  close: () => Promise<void>;
}

class HttpError extends Error {
  constructor(readonly status: number, readonly code: string, message: string, readonly field?: string) { super(message); }
}

interface UiSession {
  id: string;
  actorNumber: string;
  lastSeen: number;
}

function parse<T>(schema: z.ZodType<T>, value: unknown): T {
  const result = schema.safeParse(value);
  if (!result.success) {
    const issue = result.error.issues[0];
    throw new HttpError(400, 'invalid_request', issue === undefined ? 'The request is invalid.' : `${issue.path.join('.') || 'request'}: ${issue.message}`, issue?.path.join('.'));
  }
  return result.data;
}

function parseCookies(header: string | undefined): Map<string, string> {
  const cookies = new Map<string, string>();
  for (const part of header?.split(';') ?? []) {
    const index = part.indexOf('=');
    if (index > 0) cookies.set(part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim()));
  }
  return cookies;
}

function contentDisposition(filename: string): string {
  return `attachment; filename="${filename.replaceAll(/[^A-Za-z0-9._-]/gu, '_')}"`;
}

function listFrom(value: string | undefined): string[] | undefined {
  if (value === undefined || value === '') return undefined;
  return value.split(',').map((item) => item.trim()).filter((item) => item.length > 0);
}

/** Drops undefined/empty query values; the mapped result keeps the service-side optional shape. */
function defined<T extends Record<string, unknown>>(input: T): { [K in keyof T]-?: Exclude<T[K], undefined> } {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input)) if (value !== undefined && value !== '') out[key] = value;
  return out as { [K in keyof T]-?: Exclude<T[K], undefined> };
}

/** Translates a service rejection into an HTTP error at the application boundary. */
function rejectionError(rejection: Rejection): HttpError {
  const status = rejection.code === 'not_authorized' ? 403
    : rejection.code === 'not_found' ? 404
    : rejection.code === 'stale_version' || rejection.code === 'idempotency_conflict' ? 409
    : 422;
  return new HttpError(status, rejection.code, rejection.message, rejection.field);
}

function isRejection(value: unknown): value is Rejection {
  return typeof value === 'object' && value !== null && 'kind' in value && value.kind === 'rejected';
}

function rejectIf<T>(value: T | Rejection): T {
  if (isRejection(value)) throw rejectionError(value);
  return value;
}

/** Unwraps an authorized servicing result; rejections become HTTP errors. */
function serviced<T>(result: ServicingQueryResult<T>): T {
  return rejectIf(result).value;
}

/** Reattachment fields the browser submits for binary/nested command data. */
function prepareCommand(command: Record<string, unknown>): Record<string, unknown> {
  const prepared = { ...command };
  if (prepared.kind === 'document.index' && typeof prepared.bytesBase64 === 'string' && prepared.bytes === undefined) {
    prepared.bytes = Buffer.from(prepared.bytesBase64, 'base64');
  }
  return prepared;
}

export function createWorkstationApp(options: WorkstationOptions): express.Express {
  const { store } = options;
  if (options.operator.actorNumbers.length === 0) throw new Error('At least one operator actor number is required.');
  const institutions = new Map<string, { binding: DatasetBinding; info: InstitutionInfo }>();
  store.read((database) => {
    for (const binding of options.bindings) {
      const summary = institutionSummary(database, binding.datasetId);
      if (summary.institutionId !== binding.institutionId) throw new Error(`Dataset ${binding.datasetId} does not belong to ${binding.institutionId}.`);
      institutions.set(binding.institutionId, {
        binding,
        info: {
          institutionId: summary.institutionId, datasetId: binding.datasetId, displayName: summary.displayName,
          timeZone: summary.timeZone, defaultCurrency: summary.defaultCurrency, asOf: summary.asOf,
        },
      });
    }
  });
  if (institutions.size === 0) throw new Error('At least one institution binding is required.');
  const sessions = new Map<string, UiSession>();
  const app = express();
  app.disable('x-powered-by');
  app.set('query parser', 'simple');

  if (options.verbose === true) {
    app.use((request, response, next) => {
      const started = process.hrtime.bigint();
      response.on('finish', () => console.error(`${request.method} ${request.originalUrl} ${response.statusCode} ${Number(process.hrtime.bigint() - started) / 1e6}ms`));
      next();
    });
  }
  app.use('/api', (request, response, next) => {
    response.setHeader('Cache-Control', 'no-store');
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      const origin = request.get('origin');
      if (origin !== undefined && origin !== `${request.protocol}://${request.get('host') ?? ''}`) {
        next(new HttpError(403, 'cross_origin', 'Cross-origin requests are not accepted.'));
        return;
      }
    }
    next();
  });
  app.use('/api', express.json({ limit: '4mb' }));

  const session = (request: Request, response: Response): UiSession => {
    const cookie = parseCookies(request.get('cookie')).get('dlw_session');
    const existing = cookie === undefined ? undefined : sessions.get(cookie);
    if (existing !== undefined) { existing.lastSeen = Date.now(); return existing; }
    if (sessions.size >= MAX_SESSIONS) {
      const oldest = [...sessions.values()].sort((a, b) => a.lastSeen - b.lastSeen)[0];
      if (oldest !== undefined) sessions.delete(oldest.id);
    }
    const created: UiSession = { id: randomBytes(18).toString('base64url'), actorNumber: options.operator.actorNumbers[0] ?? '', lastSeen: Date.now() };
    sessions.set(created.id, created);
    response.setHeader('Set-Cookie', `dlw_session=${created.id}; Path=/; HttpOnly; SameSite=Strict`);
    return created;
  };

  const institution = (request: Request): { binding: DatasetBinding; info: InstitutionInfo } => {
    const found = institutions.get(String(request.params.institutionId));
    if (found === undefined) throw new HttpError(404, 'unknown_institution', 'This workstation is not bound to that institution.');
    return found;
  };

  const profile = (actorNumber: string, binding: DatasetBinding): OperatorInfo | null => store.read((database) => {
    const found = operatorProfile(database, binding.datasetId, binding.institutionId, actorNumber);
    if (found === undefined || found.status !== 'active') return null;
    return { actorId: found.actor.id, actorNumber: found.actor.actorNumber, displayName: found.actor.displayName, permissions: found.permissions };
  });

  const actorFor = (request: Request, response: Response, binding: DatasetBinding): { actorId: string } => {
    const ui = session(request, response);
    const found = profile(ui.actorNumber, binding);
    if (found === null) throw new HttpError(403, 'operator_unavailable', `Operator ${ui.actorNumber} is not registered at this institution.`);
    return { actorId: found.actorId };
  };

  const serviceContext = (request: Request, response: Response): ServiceContext => {
    const { binding } = institution(request);
    const { actorId } = actorFor(request, response, binding);
    return {
      binding, actorId, reference: `${APPLICATION_ID}:${session(request, response).id}`,
      ...(options.principalKind === undefined ? {} : { principalKind: options.principalKind }),
    };
  };

  const documentReader = (request: Request, response: Response): { institutionId: string; actorId: string } => {
    const { binding } = institution(request);
    const { actorId } = actorFor(request, response, binding);
    return { institutionId: binding.institutionId, actorId };
  };

  const notFound = (what: string): HttpError => new HttpError(404, 'not_found', `The ${what} does not exist at this institution.`);

  app.get('/healthz', (_request, response) => { response.json({ status: 'ok', applicationId: APPLICATION_ID }); });

  app.get('/api/session', (request, response) => {
    const ui = session(request, response);
    const first = [...institutions.values()][0];
    const body: SessionInfo = {
      institutions: [...institutions.values()].map((entry) => entry.info),
      operator: first === undefined ? null : profile(ui.actorNumber, first.binding),
      allowedOperatorNumbers: [...options.operator.actorNumbers],
      fixedOperator: options.operator.fixed,
    };
    response.json(body);
  });

  app.post('/api/session/operator', (request, response) => {
    const ui = session(request, response);
    const { actorNumber } = parse(operatorBodySchema, request.body);
    if (options.operator.fixed) throw new HttpError(403, 'operator_fixed', 'The operator for this workstation is fixed by its backend.');
    if (!options.operator.actorNumbers.includes(actorNumber)) throw new HttpError(403, 'operator_not_configured', `Operator ${actorNumber} is not configured for sign-on.`);
    ui.actorNumber = actorNumber;
    response.json({ actorNumber });
  });

  const router = express.Router({ mergeParams: true });
  app.use('/api/i/:institutionId', router);
  router.use((request, response, next) => {
    const context = serviceContext(request, response);
    const denied = store.read((database) => authorizeQuery(database, context));
    if (denied !== null) throw new HttpError(403, denied.code, denied.message);
    next();
  });

  router.get('/operator', (request, response) => {
    const { binding } = institution(request);
    response.json({ operator: profile(session(request, response).actorNumber, binding) });
  });

  router.get('/reference', (request, response) => {
    const { binding } = institution(request);
    response.json(store.read((database) => referenceData(database, binding.datasetId, binding.institutionId)));
  });

  router.get('/members', (request, response) => {
    const { sort, direction, ids, maxResults, ...query } = parse(memberQuerySchema, request.query);
    const key = sort === undefined ? undefined : MEMBER_SORTS[sort];
    if (sort !== undefined && key === undefined) throw new HttpError(400, 'invalid_sort', `The members list cannot be sorted by ${sort}.`, 'sort');
    const { binding } = institution(request);
    const page = store.read((database) => searchMembers(database, binding.datasetId, defined({ ...query, sort: key, direction, ids: listFrom(ids) })));
    if (maxResults !== undefined && page.total > maxResults) {
      response.json({ ...page, items: page.items.slice(0, Math.max(0, maxResults - page.offset)), total: maxResults, limitedTo: maxResults, matched: page.total });
      return;
    }
    response.json(page);
  });

  router.get('/members/:memberId', (request, response) => {
    const { binding } = institution(request);
    const reader = documentReader(request, response);
    const detail = store.read((database) => memberDetail(database, binding.datasetId, request.params.memberId, reader));
    if (detail === undefined) throw notFound('member');
    response.json(detail);
  });

  router.get('/accounts', (request, response) => {
    const { sort, direction, ids, maxResults, ...query } = parse(accountQuerySchema, request.query);
    const key = sort === undefined ? undefined : ACCOUNT_SORTS[sort];
    if (sort !== undefined && key === undefined) throw new HttpError(400, 'invalid_sort', `The accounts list cannot be sorted by ${sort}.`, 'sort');
    const { binding } = institution(request);
    const page = store.read((database) => searchAccounts(database, binding.datasetId, defined({ ...query, sort: key, direction, ids: listFrom(ids) })));
    if (maxResults !== undefined && page.total > maxResults) {
      response.json({ ...page, items: page.items.slice(0, Math.max(0, maxResults - page.offset)), total: maxResults, limitedTo: maxResults, matched: page.total });
      return;
    }
    response.json(page);
  });

  router.get('/accounts/:accountId', (request, response) => {
    const { binding } = institution(request);
    const detail = store.read((database) => accountDetail(database, binding.datasetId, request.params.accountId));
    if (detail === undefined) throw notFound('account');
    response.json(detail);
  });

  router.get('/accounts/:accountId/transactions', (request, response) => {
    const query = parse(transactionQuerySchema, request.query);
    const { binding } = institution(request);
    const result = store.read((database) => accountDetail(database, binding.datasetId, request.params.accountId) === undefined ? undefined
      : accountTransactions(database, binding.datasetId, request.params.accountId, defined(query)));
    if (result === undefined) throw notFound('account');
    response.json(result);
  });

  router.get('/accounts/:accountId/transactions.csv', (request, response) => {
    const query = parse(exportQuerySchema, request.query);
    const { binding, info } = institution(request);
    const result = store.read((database) => {
      const account = accountDetail(database, binding.datasetId, request.params.accountId);
      if (account === undefined) return undefined;
      const rows = [];
      for (let offset = 0; offset < 10_000; offset += 200) {
        const page = accountTransactions(database, binding.datasetId, request.params.accountId, defined({ ...query, limit: 200, offset }));
        rows.push(...page.items);
        if (page.items.length < 200) break;
      }
      return { account, artifact: transactionsCsv(account.account, rows) };
    });
    if (result === undefined) throw notFound('account');
    response.setHeader('Content-Type', 'text/csv; charset=utf-8');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${result.account.account.accountNumber}-transactions.csv`));
    response.end(Buffer.from(result.artifact.bytes));
  });

  router.get('/accounts/:accountId/statements', (request, response) => {
    const { binding } = institution(request);
    const reader = documentReader(request, response);
    const result = store.read((database) => accountDetail(database, binding.datasetId, request.params.accountId) === undefined ? undefined
      : { periods: statementPeriods(database, binding.datasetId, request.params.accountId), documents: accountDocuments(database, binding.datasetId, request.params.accountId, reader) });
    if (result === undefined) throw notFound('account');
    response.json(result);
  });

  router.get('/accounts/:accountId/statement', (request, response) => {
    const { period } = parse(statementQuerySchema, request.query);
    const { binding } = institution(request);
    const statement = store.read((database) => statementData(database, binding.datasetId, request.params.accountId, period));
    if (statement === undefined) throw new HttpError(404, 'not_found', `No statement data exists for ${request.params.accountId} in ${period}.`);
    response.json(statement);
  });

  router.get('/accounts/:accountId/statement.pdf', async (request, response) => {
    const { period } = parse(statementQuerySchema, request.query);
    const { binding, info } = institution(request);
    const statement = store.read((database) => statementData(database, binding.datasetId, request.params.accountId, period));
    if (statement === undefined) throw new HttpError(404, 'not_found', `No statement data exists for ${request.params.accountId} in ${period}.`);
    const artifact = await renderGeneratedStatement(statement, info.asOf);
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${statement.account.accountNumber}-statement-${period}.pdf`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.end(Buffer.from(artifact.bytes));
  });

  router.get('/accounts/:accountId/statement.csv', (request, response) => {
    const { period } = parse(statementQuerySchema, request.query);
    const { binding, info } = institution(request);
    const statement = store.read((database) => statementData(database, binding.datasetId, request.params.accountId, period));
    if (statement === undefined) throw new HttpError(404, 'not_found', `No statement data exists for ${request.params.accountId} in ${period}.`);
    const artifact = renderCsv({
      displayName: `${statement.account.accountNumber}-statement-${period}.csv`,
      columns: ['effective_date', 'reference', 'description', 'currency', 'amount_minor_units'],
      rows: statement.entries.map((entry) => [entry.date, entry.reference, entry.description, statement.account.currency, entry.amountMinorUnits]),
    });
    response.setHeader('Content-Type', 'text/csv; charset=utf-8');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${statement.account.accountNumber}-statement-${period}.csv`));
    response.end(Buffer.from(artifact.bytes));
  });

  router.get('/accounts/:accountId/statement.html', (request, response) => {
    const { period } = parse(statementQuerySchema, request.query);
    const { binding, info } = institution(request);
    const statement = store.read((database) => statementData(database, binding.datasetId, request.params.accountId, period));
    if (statement === undefined) throw new HttpError(404, 'not_found', `No statement data exists for ${request.params.accountId} in ${period}.`);
    const esc = (value: unknown): string => String(value).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
    const money = (minor: number): string => `${(minor / 10 ** statement.account.exponent).toFixed(statement.account.exponent)} ${statement.account.currency}`;
    const lines = statement.entries.map((entry) => `<tr><td>${esc(entry.date)}</td><td>${esc(entry.reference)}</td><td>${esc(entry.description)}</td><td class="num">${esc(money(entry.amountMinorUnits))}</td></tr>`).join('');
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>Statement ${esc(period)} ${esc(statement.account.accountNumber)}</title>
<style>body{font-family:serif;margin:2rem}table{border-collapse:collapse;width:100%}td,th{border:1px solid #999;padding:4px 8px;text-align:left}td.num{text-align:right}h1{font-size:1.3rem}</style></head>
<body><h1>${esc(info.displayName)} — statement ${esc(period)}</h1>
<p>Account ${esc(statement.account.accountNumber)} — ${esc(statement.account.productName)} (${esc(statement.account.currency)}) · opening ${esc(money(statement.openingMinorUnits))} · closing ${esc(money(statement.closingMinorUnits))}</p>
<table><thead><tr><th>Date</th><th>Reference</th><th>Description</th><th>Amount</th></tr></thead><tbody>${lines}</tbody></table></body></html>`;
    response.setHeader('Content-Type', 'text/html; charset=utf-8');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${statement.account.accountNumber}-statement-${period}.html`));
    response.end(html);
  });

  router.get('/accounts/:accountId/documents', (request, response) => {
    const { binding } = institution(request);
    const reader = documentReader(request, response);
    const documents = store.read((database) => accountDocuments(database, binding.datasetId, request.params.accountId, reader));
    response.json({ items: documents });
  });

  router.get('/cases', (request, response) => {
    const { sort, direction, ids, maxResults, groupBy, ...query } = parse(caseQuerySchema, request.query);
    const key = sort === undefined ? undefined : CASE_SORTS[sort];
    if (sort !== undefined && key === undefined) throw new HttpError(400, 'invalid_sort', `The cases list cannot be sorted by ${sort}.`, 'sort');
    const { binding } = institution(request);
    const filter = defined({
      ...query,
      states: listFrom(query.states), queueIds: listFrom(query.queueIds),
      assignedActorId: query.assignedActorId === 'unassigned' ? null : query.assignedActorId,
      overdue: query.overdue === undefined ? undefined : query.overdue === 'true',
    });
    if (groupBy === 'state' || groupBy === 'queue') {
      response.json({ groups: store.read((database) => caseGroupCounts(database, binding.datasetId, filter, groupBy)) });
      return;
    }
    const page = store.read((database) => searchCases(database, binding.datasetId, defined({ ...filter, sort: key, direction, ids: listFrom(ids) })));
    if (maxResults !== undefined && page.total > maxResults) {
      response.json({ ...page, items: page.items.slice(0, Math.max(0, maxResults - page.offset)), total: maxResults, limitedTo: maxResults, matched: page.total });
      return;
    }
    response.json(page);
  });

  router.get('/cases/:caseId', (request, response) => {
    const context = serviceContext(request, response);
    const result = store.read((database) => {
      const core = caseDetail(database, context.binding.datasetId, request.params.caseId);
      if (core === undefined) return undefined;
      const servicing = servicingCaseDetail(database, context, request.params.caseId);
      return { case: core, servicing: servicing.kind === 'authorized' ? servicing.value : null };
    });
    if (result === undefined) throw notFound('case');
    response.json(result);
  });

  router.get('/documents', (request, response) => {
    const { sort, direction, ...query } = parse(documentQuerySchema, request.query);
    const key = sort === undefined ? undefined : DOCUMENT_SORTS[sort];
    if (sort !== undefined && key === undefined) throw new HttpError(400, 'invalid_sort', `The documents list cannot be sorted by ${sort}.`, 'sort');
    const context = serviceContext(request, response);
    response.json(store.read((database) => searchDocuments(database, context.binding.datasetId, defined({ ...query, sort: key, direction }),
      { institutionId: context.binding.institutionId, actorId: context.actorId })));
  });

  router.get('/documents/:versionId', (request, response) => {
    const context = serviceContext(request, response);
    const result = store.read((database) => {
      const row = documentContent(database, context.binding.datasetId, request.params.versionId,
        { institutionId: context.binding.institutionId, actorId: context.actorId });
      if (row === undefined) return undefined;
      const { bytes: _dropped, ...meta } = row;
      const annotations = listDocumentAnnotations(database, context, request.params.versionId);
      const signatures = listDocumentSignatures(database, context, request.params.versionId);
      return {
        document: meta,
        annotations: (annotations.kind === 'authorized' ? annotations.value : []).map((annotation) => {
          const micros = JSON.parse(annotation.regionJson) as { x: number; y: number; width: number; height: number };
          return {
            annotationId: annotation.id, pageNumber: annotation.pageNumber, text: annotation.text,
            status: annotation.status, fingerprint: annotation.fingerprint, createdAt: annotation.createdAt,
            region: { x: micros.x / 1_000_000, y: micros.y / 1_000_000, width: micros.width / 1_000_000, height: micros.height / 1_000_000 },
          };
        }),
        signatures: signatures.kind === 'authorized' ? signatures.value : [],
      };
    });
    if (result === undefined) throw notFound('document version');
    response.json(result);
  });

  router.get('/documents/:versionId/content', (request, response) => {
    const context = serviceContext(request, response);
    const row = store.read((database) => documentContent(database, context.binding.datasetId, request.params.versionId,
      { institutionId: context.binding.institutionId, actorId: context.actorId }));
    if (row === undefined) throw notFound('document version');
    response.setHeader('Content-Type', row.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${row.documentId}-v${row.version}-${row.digest.slice(0, 8)}`));
    response.setHeader('X-Document-Digest', row.digest);
    response.end(Buffer.from(row.bytes));
  });

  router.get('/documents/:versionId/layout', async (request, response) => {
    const context = serviceContext(request, response);
    const row = store.read((database) => documentContent(database, context.binding.datasetId, request.params.versionId,
      { institutionId: context.binding.institutionId, actorId: context.actorId }));
    if (row === undefined) throw notFound('document version');
    response.json(await documentLayout(row.versionId, row.mediaType, row.bytes, row.pageCount ?? 1));
  });

  router.get('/activity', (request, response) => {
    const query = parse(activityQuerySchema, request.query);
    const { binding } = institution(request);
    response.json(store.read((database) => listActivity(database, binding.datasetId, defined(query))));
  });

  router.get('/receipts/:number', (request, response) => {
    const { binding } = institution(request);
    const receipt = store.read((database) => receiptByNumber(database, binding.datasetId, request.params.number));
    if (receipt === undefined) throw notFound('receipt');
    response.json(receipt);
  });

  router.post('/stamps', (request, response) => {
    const body = parse(stampBodySchema, request.body);
    const { binding } = institution(request);
    response.json(store.read((database) => recordStamps(database, binding.datasetId, defined(body))));
  });

  router.get('/saved-searches', (request, response) => {
    const { entity } = parse(savedSearchQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(store.read((database) => listSavedSearches(database, context.binding.datasetId, context.actorId, entity)));
  });

  router.get('/lists', (request, response) => {
    const { kind, ...params } = parse(scopedListQuerySchema, request.query);
    const context = serviceContext(request, response);
    const value = params as Record<string, unknown>;
    const limit = typeof value.limit === 'number' ? value.limit : 200;
    const offset = typeof value.offset === 'number' ? value.offset : 0;
    const scopes: Record<string, string> = {
      'member.beneficiaries': 'beneficiary', 'beneficiary.routes': 'beneficiary-route', 'member.payments': 'payment', 'account.payments': 'payment',
      'account.schedules': 'payment-schedule', 'schedule.occurrences': 'schedule-occurrence', 'member.payment_returns': 'payment-return', 'account.payment_returns': 'payment-return',
      'account.cards': 'card', 'card.transactions': 'card-transaction', 'member.disputes': 'dispute', 'account.disputes': 'dispute', 'member.loans': 'loan', 'account.loans': 'loan',
      'member.loan_applications': 'loan-application', 'loan.payoff_quotes': 'payoff-quote', 'account.interest_calculations': 'interest-calculation', 'account.fees': 'fee',
      'account.fee_waivers': 'fee-waiver', 'settlement.batches': 'settlement-batch', 'suspense.items': 'suspense-item', 'batches': 'batch', 'batch.items': 'batch-item',
      'member.received_funds': 'received-funds', 'cash.sessions': 'cash-session', 'merge.plans': 'merge-plan', 'calendar.days': 'calendar-day', 'products': 'product',
      'member.name_history': 'name-history', 'member.tax_history': 'tax-history',
    };
    const resource = scopes[kind];
    if (resource === undefined) { if (kind === 'approval.checkers') {
      const commandKind = typeof value.commandKind === 'string' ? value.commandKind : '';
      response.json(rejectIf(store.read((database) => listServicingApprovalCheckers(database, context, commandKind, limit)))); return;
    } throw new HttpError(400, 'validation', `Unknown scoped list kind ${kind}.`, 'kind'); }
    const requestScope: Record<string, string | number> = { resource, limit, offset };
    const copy = (from: string, to: string): void => { const entry = value[from]; if (typeof entry === 'string') requestScope[to] = entry; };
    copy('memberId', 'memberId'); copy('accountId', 'accountId');
    const parentByKind: Record<string, string> = { 'beneficiary.routes': 'beneficiaryId', 'schedule.occurrences': 'scheduleId', 'card.transactions': 'cardId', 'loan.payoff_quotes': 'loanId', 'batch.items': 'batchId' };
    const parentField = parentByKind[kind]; if (parentField !== undefined) copy(parentField, 'parentId');
    if (kind === 'calendar.days') { copy('from', 'dateFrom'); copy('through', 'dateThrough'); }
    const result = listFinanceRecords(store, context, requestScope);
    if (result.kind === 'rejected') { response.json(rejectIf(result)); return; }
    const columns = result.items.length === 0 ? [] : Object.keys(result.items[0]?.fields ?? {});
    response.json({ kind: 'found', page: { columns, rows: result.items, total: result.total, truncated: !result.exhausted } });
  });

  router.get('/finance/record/:resource/:id', (request, response) => {
    const context = serviceContext(request, response);
    response.json(rejectIf(readFinanceRecord(store, context, request.params.resource as never, request.params.id)));
  });

  router.post('/finance/query', (request, response) => {
    const body = parse(financeQueryBodySchema, request.body);
    const context = serviceContext(request, response);
    response.json(rejectIf(queryFinance(store, context, body)));
  });

  router.get('/approvals', (request, response) => {
    const context = serviceContext(request, response);
    const limit = request.query.limit === undefined ? 100 : Number(request.query.limit);
    response.json(rejectIf(listApprovals(store, context, Number.isSafeInteger(limit) && limit >= 1 && limit <= 500 ? limit : 100)));
  });

  router.get('/servicing/queues', (request, response) => {
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listServicingQueues(database, context))));
  });

  router.get('/servicing/policy-versions', (request, response) => {
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listEffectivePolicyVersions(database, context))));
  });

  router.get('/servicing/checkers', (request, response) => {
    const { kind } = parse(servicingQuerySchema, request.query);
    if (kind === undefined) throw new HttpError(400, 'invalid_request', 'A command kind is required.', 'kind');
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listServicingApprovalCheckers(database, context, kind as never))));
  });

  router.get('/servicing/case-subject-correction/:memberId', (request, response) => {
    const context = serviceContext(request, response);
    const corrected = typeof request.query.correctedMemberId === 'string' && request.query.correctedMemberId.trim() !== ''
      ? request.query.correctedMemberId.trim() : request.params.memberId;
    response.json(store.read((database) => ({
      evidence: serviced(listCaseSubjectCorrectionEvidence(database, context, request.params.memberId, corrected)),
      checkers: serviced(listServicingApprovalCheckers(database, context, 'case.subject.correct')),
      policyVersions: serviced(listEffectivePolicyVersions(database, context)),
      approvals: rejectIf(listApprovals(store, context)),
    })));
  });

  router.get('/servicing/maintenance-requests/:requestId', (request, response) => {
    const context = serviceContext(request, response);
    const result = serviced(store.read((database) => maintenanceRequest(database, context, request.params.requestId)));
    if (result === undefined) throw notFound('maintenance request');
    response.json(result);
  });

  router.get('/servicing/communication-jobs/:jobId', (request, response) => {
    const context = serviceContext(request, response);
    const result = serviced(store.read((database) => communicationJob(database, context, request.params.jobId)));
    if (result === undefined) throw notFound('communication job');
    response.json(result);
  });

  router.get('/servicing/merge-plans/:planId', (request, response) => {
    const context = serviceContext(request, response);
    response.json(rejectIf(queryMemberMergePlan(store, context, request.params.planId)));
  });

  router.get('/members/:memberId/document-versions', (request, response) => {
    const { documentType, limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberDocumentVersions(database, context, request.params.memberId, documentType, limit))));
  });

  router.get('/members/:memberId/evidence', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberIdentityEvidence(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/addresses', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberAddresses(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/consents', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberConsents(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/retention-holds', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberRetentionHolds(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/preferences', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberCommunicationPreferences(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/destinations', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberAddressDestinations(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/maintenance-requests', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberMaintenanceRequests(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/communication-jobs', (request, response) => {
    const { limit } = parse(servicingQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => listMemberCommunicationJobs(database, context, request.params.memberId, limit))));
  });

  router.get('/members/:memberId/identity-resolution', (request, response) => {
    const criteria = parse(identityQuerySchema, request.query);
    const context = serviceContext(request, response);
    response.json(serviced(store.read((database) => resolveMemberIdentity(database, context, defined(criteria)))));
  });

  router.get('/members/:memberId/historical-statements', (request, response) => {
    const { accountId, periodStart, periodEnd, format } = parse(historicalStatementQuerySchema, request.query);
    const context = serviceContext(request, response);
    const result = serviced(store.read((database) => retrieveHistoricalStatement(database, context, accountId, periodStart, periodEnd, format)));
    if (result === undefined) throw notFound('historical statement');
    const { bytes: _bytes, ...meta } = result;
    response.json({ statement: meta });
  });

  router.get('/members/:memberId/export-artifacts/:versionId', (request, response) => {
    const context = serviceContext(request, response);
    const result = serviced(store.read((database) => retrieveCustomerExportArtifact(database, context, request.params.memberId, request.params.versionId)));
    if (result === undefined) throw notFound('customer export artifact');
    response.setHeader('Content-Type', result.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${request.params.memberId}-export-${result.digest.slice(0, 8)}.json`));
    response.setHeader('X-Document-Digest', result.digest);
    response.end(Buffer.from(result.bytes));
  });

  router.post('/commands/review', (request, response) => {
    const body = parse(reviewBodySchema, request.body);
    const context = serviceContext(request, response);
    const outcome = reviewCommand(store, context, prepareCommand(body.command) as never);
    response.json({ outcome });
  });

  router.post('/commands', (request, response) => {
    const body = parse(executeBodySchema, request.body);
    const context = serviceContext(request, response);
    const outcome = executeCommand(store, context, prepareCommand(body.command) as never, body.idempotencyKey);
    response.json({ outcome });
  });

  // Static application shell.
  const publicDirectory = options.publicDirectory;
  if (publicDirectory !== undefined) {
    app.use(express.static(publicDirectory));
    app.use((request, response, next) => {
      if (request.method !== 'GET' && request.method !== 'HEAD') { next(); return; }
      response.sendFile(join(publicDirectory, 'index.html'), (error) => { next(error); });
    });
  }

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    if (error instanceof HttpError) {
      const body: ApiErrorBody = { error: { code: error.code, message: error.message, ...(error.field === undefined ? {} : { field: error.field }) } };
      response.status(error.status).json(body);
      return;
    }
    if (error instanceof Error && 'type' in error && (error as { type?: string }).type === 'entity.parse.failed') {
      response.status(400).json({ error: { code: 'invalid_json', message: 'The request body is not valid JSON.' } } satisfies ApiErrorBody);
      return;
    }
    console.error(error);
    response.status(500).json({ error: { code: 'internal', message: 'The workstation backend failed.' } } satisfies ApiErrorBody);
  });

  return app;
}

export async function startWorkstation(options: WorkstationOptions): Promise<WorkstationHandle> {
  const app = createWorkstationApp(options);
  const server = createServer(app);
  const host = options.host ?? '127.0.0.1';
  const port = options.port ?? 0;
  await new Promise<void>((resolvePromise, rejectPromise) => {
    server.once('error', rejectPromise);
    server.listen(port, host, () => resolvePromise());
  });
  const address = server.address();
  const bound = typeof address === 'object' && address !== null ? address.port : port;
  return {
    origin: `http://${host}:${bound}`,
    close: () => new Promise<void>((resolvePromise, rejectPromise) => {
      server.close((error) => {
        if (error !== undefined) { rejectPromise(error); return; }
        try { options.onClose?.(); resolvePromise(); } catch (cause) { rejectPromise(cause instanceof Error ? cause : new Error(String(cause))); }
      });
    }),
  };
}
