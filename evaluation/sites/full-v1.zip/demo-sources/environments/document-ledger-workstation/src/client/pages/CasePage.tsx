import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { getJson, institutionPath } from '../api.js';
import type { WorkContext } from '../App.js';

interface CaseDetail {
  case: {
    id: string; caseNumber: string; memberId: string; accountId: string | null; state: string; status?: string;
    priority: string; queueId: string; queueName?: string; category: string; summary: string; dueDate: string;
    assignedActorId: string | null; version: number; openedAt: string;
  };
  servicing: Record<string, unknown> | null;
}

const CASE_OPS = [
  'case.assign', 'case.transition', 'case.note.add', 'case.information.request', 'case.escalate',
  'case.close', 'case.reopen', 'case.subject.correct',
] as const;

export function CasePage({ caseId, context }: { caseId: string; context: WorkContext }): ReactNode {
  const [detail, setDetail] = useState<CaseDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      setDetail(await getJson<CaseDetail>(`${base}/cases/${encodeURIComponent(caseId)}`));
      setError(null);
    } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
  }, [base, caseId]);

  useEffect(() => { void load(); }, [load, context.refreshKey]);

  if (error !== null) return <p className="form-error" role="alert">{error}</p>;
  if (detail === null) return <p className="muted">Loading case…</p>;
  const record = detail.case;

  return (
    <section className="case-page">
      <header className="record-header">
        <h2>{record.caseNumber} — {record.summary}</h2>
        <dl className="record-facts">
          <dt>State</dt><dd>{record.state}</dd>
          <dt>Priority</dt><dd>{record.priority}</dd>
          <dt>Queue</dt><dd>{record.queueName ?? record.queueId}</dd>
          <dt>Category</dt><dd>{record.category}</dd>
          <dt>Due</dt><dd>{record.dueDate}</dd>
          <dt>Version</dt><dd>{record.version}</dd>
          <dt>Member</dt><dd><button type="button" className="link" onClick={() => context.openTab({ kind: 'member', title: record.memberId, params: { id: record.memberId } })}>{record.memberId}</button></dd>
        </dl>
        <div className="record-ops">
          {CASE_OPS.map((kind) => (
            <button key={kind} type="button" className="tool-button" onClick={() => context.openOperation(kind, { caseId })}>{kind}</button>
          ))}
        </div>
      </header>
      {detail.servicing !== null ? (
        <section className="servicing-detail">
          <h3>Servicing detail</h3>
          <pre className="inspector-extra">{JSON.stringify(detail.servicing, null, 2)}</pre>
        </section>
      ) : null}
    </section>
  );
}
