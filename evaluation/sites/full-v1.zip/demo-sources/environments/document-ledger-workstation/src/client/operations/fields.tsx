import { useState, type ReactNode } from 'react';

import type { SavedSearchEntity } from '@computer-use/financial-database/services';

import { parseMoney } from '../model/money.js';
import type { Control, FieldSpec } from './catalog.js';
import { PickerDialog } from './PickerDialog.js';
import type { PickerOption, PickerScope } from './sources.js';

export type Values = Record<string, unknown>;

export interface FieldContext {
  institutionId: string;
  values: Values;
  currencies: Record<string, string>;
  setValue: (name: string, value: unknown) => void;
  onPick: (field: FieldSpec, option: PickerOption) => void;
  scopeFor: (field: FieldSpec) => PickerScope;
  asOf: string;
}

const inputValue = (value: unknown): string => typeof value === 'string' ? value : typeof value === 'number' ? String(value) : '';

function textInput(props: { value: unknown; onChange: (v: string) => void; type?: string; placeholder?: string; id?: string }): ReactNode {
  return <input id={props.id} className="field-input" type={props.type ?? 'text'} value={inputValue(props.value)} placeholder={props.placeholder} onChange={(e) => props.onChange(e.target.value)} />;
}

function AddressEditor({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const address = (value ?? {}) as Record<string, unknown>;
  const set = (key: string, next: string) => onChange({ line1: '', line2: null, city: '', region: '', postalCode: '', country: '', ...address, [key]: key === 'line2' && next === '' ? null : next });
  return (
    <div className="subform">
      {textInput({ value: address.line1, onChange: (v) => set('line1', v), placeholder: 'Line 1' })}
      {textInput({ value: address.line2, onChange: (v) => set('line2', v), placeholder: 'Line 2 (optional)' })}
      {textInput({ value: address.city, onChange: (v) => set('city', v), placeholder: 'City' })}
      {textInput({ value: address.region, onChange: (v) => set('region', v), placeholder: 'Region' })}
      {textInput({ value: address.postalCode, onChange: (v) => set('postalCode', v), placeholder: 'Postal code' })}
      {textInput({ value: address.country, onChange: (v) => set('country', v.toUpperCase()), placeholder: 'Country (2 letters)' })}
    </div>
  );
}

interface OwnerRow { memberId?: string | undefined; displayName?: string | undefined; ownershipBps?: number | undefined; isControlPerson?: boolean | undefined; startsAt?: string | undefined; endsAt?: string | null | undefined; evidenceId?: string | undefined }

function OwnersEditor({ value, onChange, context }: { value: unknown; onChange: (v: unknown) => void; context: FieldContext }): ReactNode {
  const owners = (Array.isArray(value) ? value : []) as OwnerRow[];
  const setRow = (index: number, patch: Partial<OwnerRow>) => onChange(owners.map((row, i) => i === index ? { ...row, ...patch } : row));
  const [picking, setPicking] = useState<number | null>(null);
  return (
    <div className="subform">
      {owners.map((row, index) => (
        <div key={index} className="subform-row">
          <button type="button" className="tool-button" onClick={() => setPicking(index)}>{row.memberId ?? row.displayName ?? 'Pick owner…'}</button>
          <input className="field-input small" type="number" placeholder="bps" value={row.ownershipBps ?? ''} onChange={(e) => setRow(index, { ownershipBps: e.target.value === '' ? undefined : Number(e.target.value) })} />
          <label className="check"><input type="checkbox" checked={row.isControlPerson === true} onChange={(e) => setRow(index, { isControlPerson: e.target.checked })} /> Control</label>
          <input className="field-input small" type="date" value={row.startsAt ?? ''} onChange={(e) => setRow(index, { startsAt: e.target.value })} />
          <button type="button" className="tool-button" onClick={() => onChange(owners.filter((_, i) => i !== index))}>Remove</button>
        </div>
      ))}
      <button type="button" className="tool-button" onClick={() => onChange([...owners, { isControlPerson: false }])}>Add owner</button>
      {picking !== null ? (
        <PickerDialog institutionId={context.institutionId} source="member" scope={{ values: context.values }} title="Beneficial owner"
          onPick={(option) => { setRow(picking, { memberId: option.id, displayName: option.label }); setPicking(null); }} onClose={() => setPicking(null)} />
      ) : null}
    </div>
  );
}

function ExcerptsEditor({ value, onChange, context, versionsFrom }: { value: unknown; onChange: (v: unknown) => void; context: FieldContext; versionsFrom?: string }): ReactNode {
  const excerpts = (Array.isArray(value) ? value : []) as { sourceVersionId?: string; text?: string }[];
  const versionIds = (context.values[versionsFrom ?? 'sourceVersionIds'] ?? []) as string[];
  const setRow = (index: number, patch: Partial<{ sourceVersionId: string; text: string }>) => onChange(excerpts.map((row, i) => i === index ? { ...row, ...patch } : row));
  return (
    <div className="subform">
      {excerpts.map((row, index) => (
        <div key={index} className="subform-row">
          <select className="field-input" value={row.sourceVersionId ?? ''} onChange={(e) => setRow(index, { sourceVersionId: e.target.value })}>
            <option value="">Source version…</option>
            {versionIds.map((id) => <option key={id} value={id}>{id.slice(0, 24)}</option>)}
          </select>
          <input className="field-input" placeholder="Approved excerpt text" value={row.text ?? ''} onChange={(e) => setRow(index, { text: e.target.value })} />
          <button type="button" className="tool-button" onClick={() => onChange(excerpts.filter((_, i) => i !== index))}>Remove</button>
        </div>
      ))}
      <button type="button" className="tool-button" onClick={() => onChange([...excerpts, {}])}>Add excerpt</button>
    </div>
  );
}

function PatchEditor({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const patch = (value ?? {}) as Record<string, unknown>;
  const set = (key: string, next: unknown) => {
    const out = { ...patch };
    if (next === undefined || next === '') out[key] = undefined; else out[key] = next;
    onChange(out);
  };
  return (
    <div className="subform">
      <label className="field-label">Subject {textInput({ value: patch.subject, onChange: (v) => set('subject', v) })}</label>
      <label className="field-label">Reason {textInput({ value: patch.reason, onChange: (v) => set('reason', v) })}</label>
      <label className="field-label">Note {textInput({ value: patch.note, onChange: (v) => set('note', v) })}</label>
      <label className="field-label">Evidence version {textInput({ value: patch.evidenceVersionId, onChange: (v) => set('evidenceVersionId', v) })}</label>
      <label className="field-label">Missing fields (one per line)
        <textarea className="field-input" value={Array.isArray(patch.missingFields) ? (patch.missingFields as string[]).join('\n') : ''} onChange={(e) => set('missingFields', e.target.value.split('\n').map((s) => s.trim()).filter(Boolean))} />
      </label>
    </div>
  );
}

const SEARCH_FIELDS: Record<SavedSearchEntity, readonly string[]> = {
  members: ['query', 'status'],
  accounts: ['query', 'status', 'currency'],
  cases: ['query', 'states', 'queueIds', 'priority', 'assignedActorId', 'overdue'],
};

function DefinitionEditor({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const definition = (value ?? {}) as { entity?: SavedSearchEntity; filters?: Record<string, unknown>; sort?: { field: string; direction: string }[]; columns?: string[]; maxResults?: number };
  const entity = definition.entity ?? 'members';
  const filters = definition.filters ?? {};
  const set = (patch: Partial<typeof definition>) => onChange({ entity, filters, sort: [], columns: [], ...definition, ...patch });
  return (
    <div className="subform">
      <label className="field-label">Entity
        <select className="field-input" value={entity} onChange={(e) => set({ entity: e.target.value as SavedSearchEntity, filters: {} })}>
          {(['members', 'accounts', 'cases'] as const).map((option) => <option key={option} value={option}>{option}</option>)}
        </select>
      </label>
      {SEARCH_FIELDS[entity].map((field) => (
        <label key={field} className="field-label">{field}
          <input className="field-input" value={inputValue(filters[field])}
            onChange={(e) => {
              const next = { ...filters };
              if (e.target.value === '') next[field] = undefined;
              else if (field === 'overdue') next[field] = e.target.value === 'true';
              else if (field === 'states' || field === 'queueIds') next[field] = e.target.value.split(',').map((s) => s.trim()).filter(Boolean);
              else next[field] = e.target.value;
              set({ filters: next });
            }} />
        </label>
      ))}
      <label className="field-label">Sort field {textInput({ value: definition.sort?.[0]?.field, onChange: (v) => set({ sort: v === '' ? [] : [{ field: v, direction: 'asc' }] }) })}</label>
      <label className="field-label">Result limit {textInput({ value: definition.maxResults, onChange: (v) => {
        const current = { entity, filters, sort: [], columns: [], ...definition };
        if (v === '') { delete current.maxResults; onChange(current); } else onChange({ ...current, maxResults: Number(v) });
      }, type: 'number' })}</label>
    </div>
  );
}

function ExpectedMetadataEditor({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const metadata = (value ?? {}) as Record<string, unknown>;
  const set = (key: string, next: string) => onChange({ ownerPartyId: '', accountId: null, documentType: '', displayName: '', retentionClass: '', ...metadata, [key]: next });
  return (
    <div className="subform">
      <p className="muted">Captured when the document was picked; edit only to reproduce a stale review.</p>
      {(['ownerPartyId', 'accountId', 'documentType', 'displayName', 'retentionClass'] as const).map((key) => (
        <label key={key} className="field-label">{key} {textInput({ value: metadata[key], onChange: (v) => set(key, v) })}</label>
      ))}
    </div>
  );
}

const MAINTENANCE_KINDS = ['contact.update', 'member.note.add', 'account.nickname.update', 'account.statement_delivery.update', 'account.close'] as const;

function RequestedCommandEditor({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const command = (value ?? {}) as Record<string, unknown>;
  const kind = typeof command.kind === 'string' ? command.kind : '';
  const set = (key: string, next: unknown) => onChange({ ...command, [key]: next });
  return (
    <div className="subform">
      <label className="field-label">Requested operation
        <select className="field-input" value={kind} onChange={(e) => onChange({ kind: e.target.value })}>
          <option value="">Choose…</option>
          {MAINTENANCE_KINDS.map((option) => <option key={option} value={option}>{option}</option>)}
        </select>
      </label>
      {kind === '' ? null : (
        <>
          <label className="field-label">memberId {textInput({ value: command.memberId, onChange: (v) => set('memberId', v) })}</label>
          {kind === 'contact.update' ? (
            <>
              <label className="field-label">expectedVersion {textInput({ value: command.expectedVersion, onChange: (v) => set('expectedVersion', v === '' ? undefined : Number(v)), type: 'number' })}</label>
              <label className="field-label">email {textInput({ value: command.email, onChange: (v) => set('email', v) })}</label>
              <label className="field-label">phone {textInput({ value: command.phone, onChange: (v) => set('phone', v) })}</label>
            </>
          ) : null}
          {kind === 'member.note.add' ? (
            <>
              <label className="field-label">visibility
                <select className="field-input" value={inputValue(command.visibility)} onChange={(e) => set('visibility', e.target.value)}>
                  <option value="">Choose…</option><option value="general">general</option><option value="restricted">restricted</option>
                </select>
              </label>
              <label className="field-label">text {textInput({ value: command.text, onChange: (v) => set('text', v) })}</label>
            </>
          ) : null}
          {kind === 'account.nickname.update' || kind === 'account.statement_delivery.update' || kind === 'account.close' ? (
            <>
              <label className="field-label">accountId {textInput({ value: command.accountId, onChange: (v) => set('accountId', v) })}</label>
              <label className="field-label">expectedVersion {textInput({ value: command.expectedVersion, onChange: (v) => set('expectedVersion', v === '' ? undefined : Number(v)), type: 'number' })}</label>
              {kind === 'account.nickname.update' ? <label className="field-label">nickname {textInput({ value: command.nickname, onChange: (v) => set('nickname', v) })}</label> : null}
              {kind === 'account.statement_delivery.update' ? (
                <label className="field-label">statementDelivery
                  <select className="field-input" value={inputValue(command.statementDelivery)} onChange={(e) => set('statementDelivery', e.target.value)}>
                    <option value="">Choose…</option><option value="paper">paper</option><option value="electronic">electronic</option>
                  </select>
                </label>
              ) : null}
              {kind === 'account.close' ? <label className="field-label">reason {textInput({ value: command.reason, onChange: (v) => set('reason', v) })}</label> : null}
            </>
          ) : null}
        </>
      )}
    </div>
  );
}

function AnnotationRegionEditor({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const region = (value ?? {}) as Record<string, unknown>;
  const set = (key: string, next: string) => onChange({ x: 0, y: 0, width: 0, height: 0, ...region, [key]: next === '' ? undefined : Math.round(Number(next)) });
  return (
    <div className="subform">
      <p className="muted">Normalized page region in millionths (0–1,000,000). Drag on the document canvas to fill this.</p>
      {(['x', 'y', 'width', 'height'] as const).map((key) => (
        <label key={key} className="field-label">{key} {textInput({ value: region[key], onChange: (v) => set(key, v), type: 'number' })}</label>
      ))}
    </div>
  );
}

function FileEditor({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const name = typeof value === 'object' && value !== null ? (value as { name?: string }).name ?? '' : '';
  return (
    <div className="subform">
      <input type="file" className="field-input" onChange={(e) => {
        const file = e.target.files?.[0];
        if (file === undefined) return;
        void file.arrayBuffer().then((buffer) => {
          let binary = '';
          new Uint8Array(buffer).forEach((byte) => { binary += String.fromCharCode(byte); });
          onChange({ name: file.name, mediaType: file.type, bytesBase64: btoa(binary), byteLength: buffer.byteLength });
        });
      }} />
      {name === '' ? <p className="muted">No file chosen.</p> : <p className="muted">{name} — {String((value as { byteLength?: number }).byteLength ?? 0)} bytes</p>}
    </div>
  );
}

function PickerButton({ field, context }: { field: FieldSpec; context: FieldContext }): ReactNode {
  const [open, setOpen] = useState(false);
  const source = field.control.type === 'picker' || field.control.type === 'picker-multi' ? field.control.source : 'member';
  const current = context.values[field.name];
  return (
    <>
      <div className="picker-field">
        <span className="picker-value">{typeof current === 'string' && current !== '' ? current : <em className="muted">Not selected</em>}</span>
        <button type="button" className="tool-button" onClick={() => setOpen(true)}>Choose…</button>
      </div>
      {open ? (
        <PickerDialog institutionId={context.institutionId} source={source} scope={context.scopeFor(field)} title={field.label}
          onPick={(option) => { context.onPick(field, option); setOpen(false); }} onClose={() => setOpen(false)} />
      ) : null}
    </>
  );
}

function MultiPickerEditor({ field, context }: { field: FieldSpec; context: FieldContext }): ReactNode {
  const [open, setOpen] = useState(false);
  const source = field.control.type === 'picker-multi' ? field.control.source : 'member';
  const selected = (Array.isArray(context.values[field.name]) ? context.values[field.name] : []) as string[];
  return (
    <>
      <div className="picker-field">
        <span className="picker-value">{selected.length === 0 ? <em className="muted">None selected</em> : selected.join(', ')}</span>
        <button type="button" className="tool-button" onClick={() => setOpen(true)}>Add…</button>
        {selected.length > 0 ? <button type="button" className="tool-button" onClick={() => context.setValue(field.name, [])}>Clear</button> : null}
      </div>
      {open ? (
        <PickerDialog institutionId={context.institutionId} source={source} scope={context.scopeFor(field)} title={field.label}
          onPick={(option) => { context.setValue(field.name, selected.includes(option.id) ? selected : [...selected, option.id]); setOpen(false); }} onClose={() => setOpen(false)} />
      ) : null}
    </>
  );
}

function MoneyEditor({ field, context }: { field: FieldSpec; context: FieldContext }): ReactNode {
  const currencyOf = field.control.type === 'money' ? field.control.currencyOf : undefined;
  const fixedCurrency = currencyOf === undefined ? undefined : context.currencies[currencyOf];
  const value = (context.values[field.name] ?? {}) as { minorUnits?: number; currency?: string };
  const [text, setText] = useState(value.minorUnits === undefined ? '' : (value.minorUnits / 100).toFixed(2));
  const error = text !== '' && parseMoney(text) === undefined;
  return (
    <div className="money-field">
      <input className={`field-input${error ? ' invalid' : ''}`} inputMode="decimal" placeholder="0.00" value={text}
        onChange={(e) => {
          setText(e.target.value);
          const parsed = parseMoney(e.target.value);
          if (parsed !== undefined) context.setValue(field.name, { minorUnits: parsed, currency: value.currency ?? fixedCurrency ?? '' });
          else context.setValue(field.name, undefined);
        }} />
      {fixedCurrency !== undefined ? <span className="money-currency">{fixedCurrency}</span> : (
        <input className="field-input small" placeholder="CCY" value={value.currency ?? ''} maxLength={3}
          onChange={(e) => {
            const currency = e.target.value.toUpperCase();
            context.setValue(field.name, value.minorUnits === undefined ? { currency } : { ...value, currency });
          }} />
      )}
      {error ? <span className="field-error">Not an exact amount</span> : null}
    </div>
  );
}

/** Renders one catalog field. Values stay JSON-shaped; the dialog validates before review. */
export function FieldControl({ field, context }: { field: FieldSpec; context: FieldContext }): ReactNode {
  const value = context.values[field.name];
  const set = (next: unknown) => context.setValue(field.name, next);
  const control: Control = field.control;
  switch (control.type) {
    case 'hidden':
      return <code className="auto-value">{value === undefined || value === null || value === '' ? '—' : JSON.stringify(value)}</code>;
    case 'text': return textInput({ value, onChange: set });
    case 'textarea': return <textarea className="field-input" value={inputValue(value)} onChange={(e) => set(e.target.value)} />;
    case 'integer': case 'number': return textInput({ value, onChange: (v) => set(v === '' ? undefined : Number(v)), type: 'number' });
    case 'date': return textInput({ value, onChange: set, type: 'date' });
    case 'instant': return textInput({ value, onChange: set, type: 'datetime-local' });
    case 'boolean': return <input type="checkbox" checked={value === true} onChange={(e) => set(e.target.checked)} />;
    case 'money': return <MoneyEditor field={field} context={context} />;
    case 'enum': return (
      <select className="field-input" value={inputValue(value)} onChange={(e) => set(e.target.value)}>
        <option value="">Choose…</option>
        {control.options.map((option) => <option key={option} value={option}>{option}</option>)}
      </select>
    );
    case 'strings': return <textarea className="field-input" placeholder="One per line" value={Array.isArray(value) ? (value as string[]).join('\n') : ''} onChange={(e) => set(e.target.value.split('\n').map((s) => s.trim()).filter((s) => s !== ''))} />;
    case 'picker': return <PickerButton field={field} context={context} />;
    case 'picker-multi': return <MultiPickerEditor field={field} context={context} />;
    case 'address': return <AddressEditor value={value} onChange={set} />;
    case 'owners': return <OwnersEditor value={value} onChange={set} context={context} />;
    case 'excerpts': return <ExcerptsEditor value={value} onChange={set} context={context} />;
    case 'patch': return <PatchEditor value={value} onChange={set} />;
    case 'definition': return <DefinitionEditor value={value} onChange={set} />;
    case 'expectedMetadata': return <ExpectedMetadataEditor value={value} onChange={set} />;
    case 'requestedCommand': return <RequestedCommandEditor value={value} onChange={set} />;
    case 'file': return <FileEditor value={value} onChange={set} />;
    case 'annotationRegion': return <AnnotationRegionEditor value={value} onChange={set} />;
    default: return null;
  }
}

/** Builds the command JSON from field values, enforcing required/optional/nullable rules. */
export function buildCommand(kind: string, fields: readonly FieldSpec[], values: Values): { command?: Record<string, unknown>; problems: string[] } {
  const command: Record<string, unknown> = { kind };
  const problems: string[] = [];
  for (const field of fields) {
    const value = values[field.name];
    const empty = value === undefined || value === '' || (Array.isArray(value) && value.length === 0)
      || (field.control.type === 'address' && Object.values(value as Record<string, unknown>).every((v) => v === '' || v === null || v === undefined));
    if (empty) {
      if (field.nullable === true) command[field.name] = null;
      else if (field.optional !== true && field.required !== false && field.control.type !== 'picker-multi') {
        if (field.control.type === 'hidden') problems.push(`${field.label}: pick ${field.auto?.from ?? 'the record'} first.`);
        else problems.push(`${field.label} is required.`);
      }
      continue;
    }
    if (field.control.type === 'file') {
      const file = value as { bytesBase64?: string; mediaType?: string };
      if (typeof file.bytesBase64 === 'string') command.bytesBase64 = file.bytesBase64;
      continue;
    }
    if (field.control.type === 'money') {
      const money = value as { minorUnits?: number; currency?: string };
      if (!Number.isSafeInteger(money.minorUnits)) { problems.push(`${field.label} needs an exact amount.`); continue; }
      if (typeof money.currency !== 'string' || money.currency === '') { problems.push(`${field.label} needs a currency.`); continue; }
      command[field.name] = { minorUnits: money.minorUnits, currency: money.currency };
      continue;
    }
    if (field.control.type === 'instant' && typeof value === 'string' && !value.includes('T')) { command[field.name] = value; continue; }
    command[field.name] = value;
  }
  return problems.length > 0 ? { problems } : { command, problems };
}
