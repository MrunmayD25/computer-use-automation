export interface PageResponse<T> {
  items: T[];
  total: number;
  offset: number;
  limit: number;
  /** Result limit of a saved search, when one applies. */
  limitedTo?: number | null;
  /** Records matching before the result limit. */
  matched?: number;
}

export type FetchPage<T> = (offset: number, limit: number, signal: AbortSignal) => Promise<PageResponse<T>>;

export interface PagedSnapshot {
  total: number | null;
  /** Increments whenever a page arrives, so subscribers re-render. */
  version: number;
  error: string | null;
  /** The total changed between page loads: records were added or removed since the first page. */
  drifted: boolean;
  limitedTo: number | null;
  matched: number | null;
  loading: boolean;
}

/**
 * A sparse, bounded window over one server query. Pages load on demand for the visible range and far pages
 * are evicted. A disposed source aborts its requests and ignores late responses, so results of an earlier
 * query can never be written into the rows of a newer one.
 */
export class PagedRows<T extends { id: string }> {
  private readonly pages = new Map<number, T[]>();
  private readonly inflight = new Map<number, AbortController>();
  private readonly listeners = new Set<() => void>();
  private disposed = false;
  private snapshot: PagedSnapshot = { total: null, version: 0, error: null, drifted: false, limitedTo: null, matched: null, loading: false };

  constructor(readonly key: string, readonly pageSize: number, private readonly fetchPage: FetchPage<T>, private readonly maxPages = 40) {}

  readonly subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener);
    return () => { this.listeners.delete(listener); };
  };

  readonly getSnapshot = (): PagedSnapshot => this.snapshot;

  get(index: number): T | undefined {
    return this.pages.get(Math.floor(index / this.pageSize))?.[index % this.pageSize];
  }

  /** Loaded rows of one page, or undefined when the page is not loaded. */
  page(pageIndex: number): readonly T[] | undefined {
    return this.pages.get(pageIndex);
  }

  /** Position of a record among loaded pages, if it is loaded. */
  indexOf(id: string): number | undefined {
    for (const [pageIndex, items] of this.pages) {
      const offset = items.findIndex((item) => item.id === id);
      if (offset >= 0) return pageIndex * this.pageSize + offset;
    }
    return undefined;
  }

  ensure(start: number, end: number): void {
    if (this.disposed) return;
    const last = this.snapshot.total === null ? Math.floor(end / this.pageSize) : Math.floor(Math.max(0, Math.min(end, this.snapshot.total - 1)) / this.pageSize);
    for (let page = Math.floor(Math.max(0, start) / this.pageSize); page <= last; page += 1) {
      if (!this.pages.has(page) && !this.inflight.has(page)) void this.load(page, (start + end) / 2);
    }
  }

  /** Reloads every loaded page in place after a commit; rows keep showing their previous values until the new ones arrive. */
  refresh(): void {
    if (this.disposed) return;
    for (const page of this.pages.keys()) {
      this.inflight.get(page)?.abort();
      this.inflight.delete(page);
      void this.load(page, page * this.pageSize);
    }
  }

  dispose(): void {
    this.disposed = true;
    for (const controller of this.inflight.values()) controller.abort();
    this.inflight.clear();
    this.listeners.clear();
  }

  private emit(patch: Partial<PagedSnapshot>): void {
    this.snapshot = { ...this.snapshot, ...patch, version: this.snapshot.version + 1, loading: this.inflight.size > 0 };
    for (const listener of this.listeners) listener();
  }

  private async load(page: number, focus: number): Promise<void> {
    const controller = new AbortController();
    this.inflight.set(page, controller);
    this.emit({});
    try {
      const response = await this.fetchPage(page * this.pageSize, this.pageSize, controller.signal);
      if (this.disposed || controller.signal.aborted) return;
      this.inflight.delete(page);
      this.pages.set(page, response.items);
      this.evict(focus);
      const drifted = this.snapshot.total !== null && this.snapshot.total !== response.total;
      this.emit({ total: response.total, drifted: this.snapshot.drifted || drifted, error: null, limitedTo: response.limitedTo ?? null, matched: response.matched ?? response.total });
    } catch (error) {
      if (this.disposed || controller.signal.aborted) return;
      this.inflight.delete(page);
      this.emit({ error: error instanceof Error ? error.message : String(error) });
    }
  }

  private evict(focus: number): void {
    if (this.pages.size <= this.maxPages) return;
    const focusPage = Math.floor(focus / this.pageSize);
    const farthest = [...this.pages.keys()].sort((a, b) => Math.abs(b - focusPage) - Math.abs(a - focusPage));
    for (const page of farthest.slice(0, this.pages.size - this.maxPages)) this.pages.delete(page);
  }
}

/**
 * Runs one request at a time for a changing subject. Starting a new request aborts the previous one and
 * a response that arrives after a newer request started is dropped instead of applied.
 */
export class LatestOnly {
  private ticket = 0;
  private controller: AbortController | null = null;

  run<T>(task: (signal: AbortSignal) => Promise<T>, apply: (value: T) => void, fail: (error: unknown) => void): void {
    this.ticket += 1;
    const ticket = this.ticket;
    this.controller?.abort();
    const controller = new AbortController();
    this.controller = controller;
    task(controller.signal).then(
      (value) => { if (ticket === this.ticket) apply(value); },
      (error: unknown) => { if (ticket === this.ticket && !controller.signal.aborted) fail(error); },
    );
  }

  cancel(): void {
    this.ticket += 1;
    this.controller?.abort();
    this.controller = null;
  }
}
