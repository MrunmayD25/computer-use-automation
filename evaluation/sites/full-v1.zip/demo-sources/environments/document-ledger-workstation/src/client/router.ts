/** Workspace tab identity. Each tab pins a business record or list — never a DOM position. */

export type TabKind =
  | 'members' | 'accounts' | 'cases' | 'documents' | 'activity' | 'approvals' | 'saved-searches'
  | 'list' | 'member' | 'account' | 'case' | 'document' | 'receipt' | 'record' | 'merge-plan' | 'maintenance';

export interface WorkTab {
  id: string;
  kind: TabKind;
  title: string;
  /** Query params for list tabs; record id for record tabs. */
  params: Record<string, string>;
}

let counter = 0;

export function tabId(kind: TabKind, key: string): string {
  counter += 1;
  return `${kind}:${key}:${counter}`;
}

export const LIST_KIND_LABELS: Record<string, string> = {
  'member.beneficiaries': 'Beneficiaries', 'beneficiary.routes': 'Beneficiary routes',
  'member.payments': 'Payments', 'account.payments': 'Account payments',
  'account.schedules': 'Payment schedules', 'schedule.occurrences': 'Schedule occurrences',
  'member.payment_returns': 'Payment returns', 'account.payment_returns': 'Account returns',
  'account.cards': 'Cards', 'card.transactions': 'Card transactions',
  'member.disputes': 'Disputes', 'account.disputes': 'Account disputes',
  'member.loans': 'Loans', 'account.loans': 'Account loans', 'member.loan_applications': 'Loan applications',
  'loan.payoff_quotes': 'Payoff quotes', 'account.interest_calculations': 'Interest calculations',
  'account.fees': 'Fees', 'account.fee_waivers': 'Fee waivers',
  'settlement.batches': 'Settlement batches', 'suspense.items': 'Suspense items',
  'batches': 'Batches', 'batch.items': 'Batch items', 'member.received_funds': 'Received funds',
  'cash.sessions': 'Cash sessions', 'merge.plans': 'Merge plans', 'calendar.days': 'Calendar days',
  'products': 'Products', 'member.name_history': 'Name history', 'member.tax_history': 'Tax history',
  'member.beneficial_owners': 'Beneficial owners', 'approval.checkers': 'Approval checkers',
};

/** Which scoped-list kinds need which scope input before they can list. */
export const LIST_SCOPE: Record<string, 'member' | 'account' | 'loan' | 'batch' | 'schedule' | 'card' | 'beneficiary' | 'dates' | 'command' | 'none'> = {
  'member.beneficiaries': 'member', 'beneficiary.routes': 'beneficiary',
  'member.payments': 'member', 'account.payments': 'account', 'account.schedules': 'account',
  'schedule.occurrences': 'schedule', 'member.payment_returns': 'member', 'account.payment_returns': 'account',
  'account.cards': 'account', 'card.transactions': 'card',
  'member.disputes': 'member', 'account.disputes': 'account',
  'member.loans': 'member', 'account.loans': 'account', 'member.loan_applications': 'member',
  'loan.payoff_quotes': 'loan', 'account.interest_calculations': 'account',
  'account.fees': 'account', 'account.fee_waivers': 'account',
  'settlement.batches': 'none', 'suspense.items': 'none', 'batches': 'none', 'batch.items': 'batch',
  'member.received_funds': 'member', 'cash.sessions': 'none', 'merge.plans': 'none',
  'calendar.days': 'dates', 'products': 'none',
  'member.name_history': 'member', 'member.tax_history': 'member', 'member.beneficial_owners': 'member',
  'approval.checkers': 'command',
  'member.document-versions': 'member', 'member.evidence': 'member', 'member.consents': 'member',
  'member.addresses': 'member', 'member.destinations': 'member', 'member.retention-holds': 'member',
  'member.preferences': 'member', 'member.communication-jobs': 'member',
};
