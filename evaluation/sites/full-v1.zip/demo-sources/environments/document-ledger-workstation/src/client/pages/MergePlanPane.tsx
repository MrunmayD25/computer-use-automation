import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { getJson, institutionPath } from '../api.js';
import type { WorkContext } from '../App.js';

interface MergePlan {
  kind: string; mergePlanId?: string; sourceMemberId?: string; targetMemberId?: string;
  planState?: string; fingerprint?: string; rowCount?: number;
  tables?: { table: string; count: number; fingerprint: string; records: { key: Record<string, string | number>; fingerprint: string }[] }[];
  message?: string;
}

/** Merge plan inventory: source/target members, table-level fingerprints, and the merge action. */
export function MergePlanPane({ planId, context }: { planId: string; context: WorkContext }): ReactNode {
  const [plan, setPlan] = useState<MergePlan | null>(null);
  const [error, setError] = useState<string | null>(null);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      const result = await getJson<MergePlan>(`${base}/servicing/merge-plans/${encodeURIComponent(planId)}`);
      if (result.kind !== 'found') { setError(result.message ?? 'Merge plan not found.'); return; }
      setPlan(result); setError(null);
      context.reportFocus({ area: 'merge-plan', record: `merge plan ${planId.slice(-8)}` });
    } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
  }, [base, planId]);

  useEffect(() => { void load(); }, [load, context.refreshKey]);

  if (error !== null) return <p className="form-error" role="alert">{error}</p>;
  if (plan === null) return <p className="muted">Loading merge plan…</p>;

  return (
    <section className="merge-pane">
      <header className="record-header">
        <h2>Merge plan {plan.mergePlanId}</h2>
        <dl className="record-facts">
          <dt>Source</dt><dd><button type="button" className="link" onClick={() => context.openTab({ kind: 'member', title: plan.sourceMemberId ?? '', params: { id: plan.sourceMemberId ?? '' } })}>{plan.sourceMemberId}</button></dd>
          <dt>Target</dt><dd><button type="button" className="link" onClick={() => context.openTab({ kind: 'member', title: plan.targetMemberId ?? '', params: { id: plan.targetMemberId ?? '' } })}>{plan.targetMemberId}</button></dd>
          <dt>State</dt><dd>{plan.planState}</dd>
          <dt>Rows</dt><dd>{plan.rowCount}</dd>
          <dt>Inventory fingerprint</dt><dd className="mono">{plan.fingerprint?.slice(0, 28)}…</dd>
        </dl>
        <div className="record-ops">
          <button type="button" className="tool-button" onClick={() => context.openOperation('member.merge', { mergePlanId: planId })}>member.merge…</button>
        </div>
      </header>
      <table className="list-table">
        <thead><tr><th>Table</th><th>Rows</th><th>Fingerprint</th></tr></thead>
        <tbody>
          {(plan.tables ?? []).map((table) => (
            <tr key={table.table}><td className="mono">{table.table}</td><td>{table.count}</td><td className="mono">{table.fingerprint.slice(0, 20)}…</td></tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
