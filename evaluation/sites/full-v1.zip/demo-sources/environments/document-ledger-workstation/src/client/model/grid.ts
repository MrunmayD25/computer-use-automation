import { clampScroll, type Viewport } from './viewport.js';

/**
 * Geometry for a canvas grid with a pinned header, pinned leading columns, and pinned leading data rows.
 * Hit tests and cell rects work in screen pixels against a zoomed, scrolled viewport.
 */

export interface GridColumn {
  key: string;
  label: string;
  width: number;
  align?: 'left' | 'right' | 'center';
}

export interface GridGeometry {
  columns: readonly GridColumn[];
  rowHeight: number;
  headerHeight: number;
  rowCount: number;
  /** Number of leading columns pinned to the left edge. */
  frozenColumns: number;
  /** Number of leading data rows pinned under the header. */
  frozenRows: number;
}

export interface CellRef {
  row: number;
  column: number;
}

export type GridRegion = 'corner' | 'header' | 'frozen-column' | 'frozen-row' | 'cell' | 'outside';

export interface GridHit {
  region: GridRegion;
  /** Data row index for cell/frozen regions; -1 for header/corner. */
  row: number;
  column: number;
}

export function columnOffsets(columns: readonly GridColumn[]): number[] {
  const offsets: number[] = [];
  let x = 0;
  for (const column of columns) { offsets.push(x); x += column.width; }
  return offsets;
}

export function contentWidth(geometry: GridGeometry): number {
  return geometry.columns.reduce((total, column) => total + column.width, 0);
}

export function contentHeight(geometry: GridGeometry): number {
  return geometry.headerHeight + geometry.rowCount * geometry.rowHeight;
}

function frozenWidth(geometry: GridGeometry): number {
  return geometry.columns.slice(0, geometry.frozenColumns).reduce((total, column) => total + column.width, 0);
}

function frozenHeight(geometry: GridGeometry): number {
  return geometry.headerHeight + geometry.frozenRows * geometry.rowHeight;
}

/** Maps a screen x to a content x, honoring pinned columns. */
export function contentXAt(geometry: GridGeometry, viewport: Viewport, screenX: number): number {
  const pinned = frozenWidth(geometry) * viewport.zoom;
  if (screenX < pinned) return screenX / viewport.zoom;
  return frozenWidth(geometry) + (screenX - pinned) / viewport.zoom + viewport.scrollX;
}

/** Maps a screen y to a content y, honoring the pinned header and pinned rows. */
export function contentYAt(geometry: GridGeometry, viewport: Viewport, screenY: number): number {
  const pinned = frozenHeight(geometry) * viewport.zoom;
  if (screenY < pinned) return screenY / viewport.zoom;
  return frozenHeight(geometry) + (screenY - pinned) / viewport.zoom + viewport.scrollY;
}

export function columnAt(geometry: GridGeometry, contentX: number): number {
  const offsets = columnOffsets(geometry.columns);
  if (contentX < 0 || contentX >= contentWidth(geometry)) return -1;
  let low = 0;
  let high = geometry.columns.length - 1;
  while (low < high) {
    const mid = Math.floor((low + high + 1) / 2);
    if ((offsets[mid] ?? 0) <= contentX) low = mid; else high = mid - 1;
  }
  return low;
}

export interface PageCell extends CellRef {
  key: string;
  /** Stable identity of the business row — selection follows the record, not the screen position. */
  rowKey: string;
}

/** Clamps a cell ref into the grid. */
export function normalize(cell: CellRef, rowCount: number, columnCount: number): CellRef {
  return { row: Math.min(Math.max(0, cell.row), Math.max(0, rowCount - 1)), column: Math.min(Math.max(0, cell.column), Math.max(0, columnCount - 1)) };
}

/** Binds a cell ref to its business row; null when the row index has no record. */
export function pageCell<T>(rows: readonly T[], cell: CellRef, rowKey: (row: T) => string): PageCell | null {
  const row = rows[cell.row];
  if (row === undefined) return null;
  return { row: cell.row, column: cell.column, key: `r${cell.row}c${cell.column}`, rowKey: rowKey(row) };
}

/** Scrolls the viewport so the given cell is fully inside the visible scroll region. */
export function scrollCellIntoView(geometry: GridGeometry, viewport: Viewport, cell: CellRef): Viewport {
  const rect = cellScreenRect(geometry, viewport, cell.row, cell.column);
  let { scrollX, scrollY } = viewport;
  const pinnedX = frozenWidth(geometry) * viewport.zoom;
  const pinnedY = frozenHeight(geometry) * viewport.zoom;
  if (rect.y + rect.height > viewport.height) scrollY += (rect.y + rect.height - viewport.height) / viewport.zoom;
  if (rect.y < pinnedY) scrollY += (rect.y - pinnedY) / viewport.zoom;
  if (rect.x + rect.width > viewport.width) scrollX += (rect.x + rect.width - viewport.width) / viewport.zoom;
  if (rect.x < pinnedX) scrollX += (rect.x - pinnedX) / viewport.zoom;
  return clampScroll({ ...viewport, scrollX, scrollY }, contentWidth(geometry), contentHeight(geometry));
}

export function rowAt(geometry: GridGeometry, contentY: number): number {
  const relative = contentY - geometry.headerHeight;
  if (relative < 0) return -1;
  const row = Math.floor(relative / geometry.rowHeight);
  return row < geometry.rowCount ? row : -1;
}

export function hitTest(geometry: GridGeometry, viewport: Viewport, screenX: number, screenY: number): GridHit {
  const inFrozenX = screenX < frozenWidth(geometry) * viewport.zoom;
  const inHeader = screenY < geometry.headerHeight * viewport.zoom;
  const cx = contentXAt(geometry, viewport, screenX);
  const cy = contentYAt(geometry, viewport, screenY);
  const column = columnAt(geometry, cx);
  if (column < 0) return { region: 'outside', row: -1, column: -1 };
  if (inHeader) return { region: inFrozenX ? 'corner' : 'header', row: -1, column };
  const row = rowAt(geometry, cy);
  if (row < 0) return { region: 'outside', row: -1, column: -1 };
  if (inFrozenX) return { region: 'frozen-column', row, column };
  if (row < geometry.frozenRows) return { region: 'frozen-row', row, column };
  return { region: 'cell', row, column };
}

/** Screen-space rect of one cell; overlays use this to anchor editors. */
export function cellScreenRect(geometry: GridGeometry, viewport: Viewport, row: number, column: number): { x: number; y: number; width: number; height: number } {
  const offsets = columnOffsets(geometry.columns);
  const columnX = offsets[column] ?? 0;
  const columnW = geometry.columns[column]?.width ?? 0;
  const pinnedX = frozenWidth(geometry);
  const pinnedY = frozenHeight(geometry);
  const x = columnX < pinnedX ? columnX * viewport.zoom : pinnedX * viewport.zoom + (columnX - pinnedX - viewport.scrollX) * viewport.zoom;
  const contentRowY = geometry.headerHeight + row * geometry.rowHeight;
  const y = contentRowY < pinnedY ? contentRowY * viewport.zoom : pinnedY * viewport.zoom + (contentRowY - pinnedY - viewport.scrollY) * viewport.zoom;
  return { x, y, width: columnW * viewport.zoom, height: geometry.rowHeight * viewport.zoom };
}

/** First and last visible data rows for a scroll offset (scrollable region only). */
export function visibleRowRange(geometry: GridGeometry, viewport: Viewport): { first: number; last: number } {
  const pinnedY = frozenHeight(geometry);
  const first = Math.max(geometry.frozenRows, Math.floor((viewport.scrollY + pinnedY - geometry.headerHeight) / geometry.rowHeight));
  const last = Math.min(geometry.rowCount - 1, Math.floor((viewport.scrollY + pinnedY - geometry.headerHeight + viewport.height / viewport.zoom) / geometry.rowHeight));
  return { first: Math.min(first, geometry.rowCount), last };
}
