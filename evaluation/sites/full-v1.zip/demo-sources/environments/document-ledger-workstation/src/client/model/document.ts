import type { DocumentPageLayout, DocumentWord } from '../../shared/api.js';
import type { Viewport } from './viewport.js';
import { screenToContent } from './viewport.js';

/** Hit test and region math for the canvas document viewer. */

export interface DocumentHit {
  pageNumber: number;
  word: DocumentWord | null;
  /** Content-space point within the page. */
  x: number;
  y: number;
}

export interface PagePlacement {
  pageNumber: number;
  /** Content-space top-left of the page in the document scroll area. */
  x: number;
  y: number;
  width: number;
  height: number;
}

const PAGE_GAP = 24;

/** Vertical stack layout of all pages, centered horizontally in `areaWidth` content units. */
export function pagePlacements(pages: readonly DocumentPageLayout[], areaWidth: number): PagePlacement[] {
  const placements: PagePlacement[] = [];
  let y = PAGE_GAP;
  for (const page of pages) {
    const x = Math.max(PAGE_GAP, (areaWidth - page.width) / 2);
    placements.push({ pageNumber: page.pageNumber, x, y, width: page.width, height: page.height });
    y += page.height + PAGE_GAP;
  }
  return placements;
}

export function documentContentSize(pages: readonly DocumentPageLayout[], areaWidth: number): { width: number; height: number } {
  const placements = pagePlacements(pages, areaWidth);
  const last = placements[placements.length - 1];
  const width = Math.max(areaWidth, ...placements.map((placement) => placement.x + placement.width + PAGE_GAP));
  return { width, height: last === undefined ? 0 : last.y + last.height + PAGE_GAP };
}

/** Finds the page and word under a screen point. */
export function documentHitTest(
  placements: readonly PagePlacement[],
  pages: readonly DocumentPageLayout[],
  viewport: Viewport,
  screenX: number,
  screenY: number,
): DocumentHit | null {
  const content = screenToContent(viewport, screenX, screenY);
  for (const placement of placements) {
    if (content.x < placement.x || content.x > placement.x + placement.width) continue;
    if (content.y < placement.y || content.y > placement.y + placement.height) continue;
    const page = pages.find((candidate) => candidate.pageNumber === placement.pageNumber);
    const px = content.x - placement.x;
    const py = content.y - placement.y;
    const word = page?.words.find((candidate) => px >= candidate.x && px <= candidate.x + candidate.width && py >= candidate.y && py <= candidate.y + candidate.height) ?? null;
    return { pageNumber: placement.pageNumber, word, x: px, y: py };
  }
  return null;
}

/** A dragged selection rectangle on one page, in page-relative content units. */
export interface PageRect {
  pageNumber: number;
  x: number;
  y: number;
  width: number;
  height: number;
}

export function normalizeRect(pageNumber: number, a: { x: number; y: number }, b: { x: number; y: number }): PageRect {
  return {
    pageNumber,
    x: Math.min(a.x, b.x), y: Math.min(a.y, b.y),
    width: Math.abs(b.x - a.x), height: Math.abs(b.y - a.y),
  };
}

/** Words fully inside a selection rectangle — used for annotation excerpts. */
export function wordsInRect(page: DocumentPageLayout, rect: PageRect): DocumentWord[] {
  return page.words.filter((word) =>
    word.x >= rect.x && word.y >= rect.y && word.x + word.width <= rect.x + rect.width && word.y + word.height <= rect.y + rect.height);
}
