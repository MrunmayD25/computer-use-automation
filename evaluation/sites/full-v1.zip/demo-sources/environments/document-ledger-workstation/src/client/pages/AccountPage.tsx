import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';

import { download, executeCommand, getJson, institutionPath, newIdempotencyKey, reviewCommand } from '../api.js';
import { GridCanvas, type GridCell } from '../canvas/GridCanvas.js';
import type { CellRef, GridColumn } from '../model/grid.js';
import { formatMoney } from '../model/money.js';
import { AnchoredMenu, type MenuItem } from '../ui/Menu.js';
import type { WorkContext } from '../App.js';

interface AccountDetail {
  account: {
    id: string; accountNumber: string; memberId: string; memberDisplayName: string; productId: string; productName: string;
    nickname: string | null; currency: string; status: string; version: number; statementDelivery: string;
    ledgerBalanceMinorUnits: number; availableBalanceMinorUnits: number; openedAt: string; closedAt: string | null;
  };
  owners?: { memberId: string; displayName: string; role: string }[];
  holds?: { id: string; amountMinorUnits: number; status: string; reason: string }[];
  restrictions?: { id: string; kind: string; status: string }[];
  facilities?: { id: string; kind: string; limitMinorUnits: number; usedMinorUnits: number; status: string }[];
  maturityTerms?: unknown[]; maturityInstructions?: { id: string; state: string }[];
}

interface TxRow {
  journalId: string; reference: string; postedAt: string; effectiveDate: string; description: string;
  status: string; lineNumber: number; amountMinorUnits: number; runningBalanceMinorUnits: number;
  counterparty: string | null; operationKind: string | null; receiptNumber: string | null;
}

const COLUMNS: readonly GridColumn[] = [
  { key: 'effectiveDate', label: 'Effective', width: 96 },
  { key: 'postedAt', label: 'Posted', width: 150 },
  { key: 'reference', label: 'Reference', width: 130 },
  { key: 'description', label: 'Description', width: 320 },
  { key: 'amount', label: 'Amount', width: 120, align: 'right' },
  { key: 'balance', label: 'Balance', width: 120, align: 'right' },
  { key: 'status', label: 'Status', width: 90 },
  { key: 'receipt', label: 'Receipt', width: 130 },
];

const ACCOUNT_OPS = [
  'account.nickname.update', 'account.statement_delivery.update', 'account.close',
  'cash.deposit', 'cash.withdraw', 'transfer.internal',
  'account.hold.place', 'account.hold.release', 'account.restriction.apply', 'account.restriction.release',
  'account.overdraft_limit.update', 'account.product.convert', 'account.owner.add', 'account.signer.remove',
  'account.maturity.instruct', 'fee.assess', 'fee.refund', 'fee.waiver.create', 'interest.adjust',
  'payment.create', 'payment.schedule.create', 'dispute.open', 'case.open',
] as const;

/** Account page: DOM detail header + the interactive canvas ledger. */
export function AccountPage({ accountId, context }: { accountId: string; context: WorkContext }): ReactNode {
  const [detail, setDetail] = useState<AccountDetail | null>(null);
  const [rows, setRows] = useState<TxRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [selection, setSelection] = useState<CellRef | null>(null);
  const [editing, setEditing] = useState<CellRef | null>(null);
  const [draft, setDraft] = useState('');
  const [menu, setMenu] = useState<{ cell: CellRef; at: { x: number; y: number } } | null>(null);
  const [frozen, setFrozen] = useState(1);
  const [busy, setBusy] = useState(false);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      const [account, transactions] = await Promise.all([
        getJson<AccountDetail>(`${base}/accounts/${encodeURIComponent(accountId)}`),
        getJson<{ items: TxRow[]; total: number }>(`${base}/accounts/${encodeURIComponent(accountId)}/transactions?limit=200`),
      ]);
      setDetail(account);
      setRows(transactions.items);
      setError(null);
      context.reportFocus({ area: 'ledger', record: account.account.accountNumber });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    }
  }, [base, accountId, context.refreshKey]);

  useEffect(() => { void load(); }, [load]);

  const currency = detail?.account.currency ?? '';

  const cellFor = useCallback((row: TxRow, column: number): GridCell => {
    switch (COLUMNS[column]?.key) {
      case 'effectiveDate': return { text: row.effectiveDate };
      case 'postedAt': return { text: row.postedAt.slice(0, 19).replace('T', ' '), tone: 'muted' };
      case 'reference': return { text: row.reference };
      case 'description': return { text: row.description };
      case 'amount': return { text: formatMoney(row.amountMinorUnits, currency), align: 'right', tone: row.amountMinorUnits >= 0 ? 'credit' : 'debit' };
      case 'balance': return { text: formatMoney(row.runningBalanceMinorUnits, currency), align: 'right' };
      case 'status': return { text: row.status, tone: row.status === 'reversed' ? 'warning' : 'normal' };
      case 'receipt': return { text: row.receiptNumber ?? '', tone: 'muted' };
      default: return { text: '' };
    }
  }, [currency]);

  const commitDescription = useCallback(async (row: TxRow, description: string) => {
    const record = await getJson<{ kind: string; snapshot?: { fingerprint: string } }>(`${base}/finance/record/transaction/${encodeURIComponent(row.journalId)}`);
    if (record.kind !== 'found' || record.snapshot === undefined) throw new Error('The journal could not be re-read.');
    const command = { kind: 'transaction.description.update', journalId: row.journalId, expectedFingerprint: record.snapshot.fingerprint, description };
    const reviewed = await reviewCommand(context.institutionId, command as never);
    if (reviewed.outcome.kind !== 'reviewable') throw new Error(`Review refused: ${JSON.stringify(reviewed.outcome)}`);
    const executed = await executeCommand(context.institutionId, command as never, newIdempotencyKey('transaction.description.update'));
    if (executed.outcome.kind !== 'committed') throw new Error(`Commit ${executed.outcome.kind}: ${executed.outcome.kind === 'rejected' ? executed.outcome.message : ''}`);
    context.message(`Description amended — ${executed.outcome.receipt.receiptNumber}`);
    await load();
  }, [base, context, load]);

  const menuItems = useMemo((): MenuItem[] => {
    if (menu === null) return [];
    const row = rows[menu.cell.row];
    if (row === undefined) return [];
    const items: MenuItem[] = [
      { id: 'describe', label: 'Amend description…', onSelect: () => { setEditing(menu.cell); setDraft(row.description); } },
      { id: 'receipt', label: `Open receipt ${row.receiptNumber ?? ''}`, disabled: row.receiptNumber === null, onSelect: () => context.openTab({ kind: 'receipt', title: `Receipt ${row.receiptNumber}`, params: { id: row.receiptNumber ?? '' } }) },
      { id: 'correct-date', label: 'Correct effective date…', onSelect: () => context.openOperation('transaction.effective_date.correct', { journalId: row.journalId, accountId }) },
    ];
    if (row.operationKind === 'cash.deposit') items.push({ id: 'reverse-deposit', label: 'Reverse deposit…', onSelect: () => context.openOperation('cash.deposit.reverse', { journalId: row.journalId, accountId }) });
    if (row.operationKind === 'cash.withdraw') items.push({ id: 'reverse-withdrawal', label: 'Reverse withdrawal…', onSelect: () => context.openOperation('cash.withdrawal.reverse', { journalId: row.journalId, accountId }) });
    if (row.operationKind === 'transfer.internal') items.push({ id: 'reverse-transfer', label: 'Reverse transfer…', onSelect: () => context.openOperation('transfer.internal.reverse', { transferJournalId: row.journalId, accountId }) });
    items.push({ id: 'csv', label: 'Download transactions CSV', onSelect: () => void download(`${base}/accounts/${encodeURIComponent(accountId)}/transactions.csv`) });
    return items;
  }, [menu, rows, context, accountId, base]);

  if (error !== null) return <p className="form-error" role="alert">{error}</p>;
  if (detail === null) return <p className="muted">Loading account…</p>;
  const account = detail.account;

  return (
    <section className="account-page">
      <header className="record-header">
        <h2>{account.accountNumber} — {account.productName}{account.nickname !== null ? ` (${account.nickname})` : ''}</h2>
        <dl className="record-facts">
          <dt>Member</dt><dd><button type="button" className="link" onClick={() => context.openTab({ kind: 'member', title: account.memberDisplayName, params: { id: account.memberId } })}>{account.memberDisplayName}</button></dd>
          <dt>Status</dt><dd>{account.status}</dd>
          <dt>Ledger</dt><dd>{formatMoney(account.ledgerBalanceMinorUnits, currency)}</dd>
          <dt>Available</dt><dd>{formatMoney(account.availableBalanceMinorUnits, currency)}</dd>
          <dt>Version</dt><dd>{account.version}</dd>
        </dl>
        <div className="record-ops">
          {ACCOUNT_OPS.map((kind) => (
            <button key={kind} type="button" className="tool-button" onClick={() => context.openOperation(kind, { accountId })}>{kind}</button>
          ))}
        </div>
      </header>
      <div className="ledger-toolbar">
        <span className="muted">Canvas ledger — {rows.length} entries · F2/double-click edits Description · Ctrl+scroll zooms · Shift+scroll pans</span>
        <label className="toolbar-field">Frozen columns
          <select value={frozen} onChange={(e) => setFrozen(Number(e.target.value))}>
            {[0, 1, 2, 3].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </label>
        <button type="button" className="tool-button" onClick={() => void download(`${base}/accounts/${encodeURIComponent(accountId)}/transactions.csv`)}>CSV</button>
        <button type="button" className="tool-button" onClick={() => context.openTab({ kind: 'list', title: 'Statements', params: { listKind: 'account.documents' } })}>Statements…</button>
      </div>
      <GridCanvas
        columns={COLUMNS}
        rows={rows}
        frozenColumns={frozen}
        cell={cellFor}
        selection={selection}
        editing={editing}
        data-testid="ledger-canvas"
        onSelect={(cell, row) => {
          setSelection(cell);
          context.reportFocus({ area: 'ledger', record: account.accountNumber, cell: cell === null ? undefined : `r${cell.row} ${COLUMNS[cell.column]?.key ?? ''}`, extra: row?.journalId });
        }}
        onFocus={(_cell, focused) => context.reportFocus({ area: focused ? 'ledger (focused)' : 'ledger', record: account.accountNumber, cell: selection === null ? undefined : `r${selection.row} ${COLUMNS[selection.column]?.key ?? ''}` })}
        onRequestEdit={(cell, row) => {
          if (COLUMNS[cell.column]?.key !== 'description') { context.message('Only the Description column is editable; other columns are protected.'); return; }
          setEditing(cell); setDraft(row.description);
        }}
        onCellMenu={(cell, _row, at) => { setSelection(cell); setMenu({ cell, at }); }}
        editor={(_rect, row) => (
          <form onSubmit={(event) => {
            event.preventDefault();
            setBusy(true);
            void commitDescription(row, draft).catch((cause: unknown) => context.message(cause instanceof Error ? cause.message : String(cause))).finally(() => { setBusy(false); setEditing(null); });
          }}>
            <input className="cell-input" autoFocus value={draft} disabled={busy}
              onChange={(event) => setDraft(event.target.value)}
              onKeyDown={(event) => { if (event.key === 'Escape') setEditing(null); }}
              onBlur={() => setEditing(null)} />
          </form>
        )}
      />
      {menu !== null ? (
        <AnchoredMenu label="Ledger row" items={menuItems}
          anchor={() => document.querySelector(`[data-testid="ledger-canvas"]`)}
          placement="right-start"
          onClose={() => setMenu(null)} />
      ) : null}
      <section className="account-extras">
        {(detail.holds ?? []).length > 0 ? <p>Holds: {(detail.holds ?? []).map((hold) => `${hold.id} ${formatMoney(hold.amountMinorUnits, currency)} ${hold.status}`).join(' · ')}</p> : null}
        {(detail.restrictions ?? []).length > 0 ? <p>Restrictions: {(detail.restrictions ?? []).map((restriction) => `${restriction.kind} ${restriction.status}`).join(' · ')}</p> : null}
        {(detail.facilities ?? []).length > 0 ? <p>Facilities: {(detail.facilities ?? []).map((facility) => `${facility.kind} ${formatMoney(facility.limitMinorUnits, currency)} used ${formatMoney(facility.usedMinorUnits, currency)}`).join(' · ')}</p> : null}
      </section>
    </section>
  );
}
