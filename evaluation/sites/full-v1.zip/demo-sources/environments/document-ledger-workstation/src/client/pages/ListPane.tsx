import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';

import { getJson, institutionPath, queryString } from '../api.js';
import { formatMoney } from '../model/money.js';
import type { WorkContext } from '../App.js';
import { LIST_SCOPE } from '../router.js';
import { PickerDialog } from '../operations/PickerDialog.js';
import type { PickerSource } from '../operations/catalog.js';

type Entity = 'members' | 'accounts' | 'cases' | 'documents' | 'activity' | 'saved-searches' | 'scoped';

interface Page<T> { items: T[]; total: number; offset: number; limit: number; limitedTo?: number | null; matched?: number }

const COLUMNS: Record<string, { key: string; label: string; money?: boolean }[]> = {
  members: [
    { key: 'memberNumber', label: 'Member #' }, { key: 'displayName', label: 'Name' }, { key: 'status', label: 'Status' },
    { key: 'email', label: 'Email' }, { key: 'phone', label: 'Phone' }, { key: 'openedAt', label: 'Opened' },
  ],
  accounts: [
    { key: 'accountNumber', label: 'Account #' }, { key: 'productName', label: 'Product' }, { key: 'memberDisplayName', label: 'Member' },
    { key: 'currency', label: 'CCY' }, { key: 'balanceMinorUnits', label: 'Balance', money: true }, { key: 'status', label: 'Status' },
  ],
  cases: [
    { key: 'caseNumber', label: 'Case #' }, { key: 'state', label: 'State' }, { key: 'priority', label: 'Priority' },
    { key: 'queueName', label: 'Queue' }, { key: 'summary', label: 'Summary' }, { key: 'dueDate', label: 'Due' },
  ],
  documents: [
    { key: 'displayName', label: 'Name' }, { key: 'documentType', label: 'Type' }, { key: 'version', label: 'Ver' },
    { key: 'mediaType', label: 'Media' }, { key: 'status', label: 'Status' }, { key: 'issuedAt', label: 'Issued' },
  ],
  activity: [
    { key: 'occurredAt', label: 'When' }, { key: 'actorNumber', label: 'Actor' }, { key: 'kind', label: 'Kind' },
    { key: 'resourceKind', label: 'Resource' }, { key: 'summary', label: 'Summary' },
  ],
  'saved-searches': [
    { key: 'name', label: 'Name' }, { key: 'entity', label: 'Entity' }, { key: 'visibility', label: 'Visibility' }, { key: 'revision', label: 'Rev' },
  ],
};

const SCOPE_SOURCE: Record<string, PickerSource | 'dates' | 'command'> = {
  member: 'member', account: 'account', loan: 'loan', batch: 'batch', schedule: 'paymentSchedule', card: 'card', beneficiary: 'beneficiary', dates: 'dates', command: 'command', none: 'command',
};

/** Member-scoped servicing endpoints surfaced as list kinds. */
const MEMBER_LIST_ENDPOINTS: Record<string, string> = {
  'member.document-versions': 'document-versions', 'member.evidence': 'evidence', 'member.consents': 'consents',
  'member.addresses': 'addresses', 'member.destinations': 'destinations', 'member.retention-holds': 'retention-holds',
  'member.preferences': 'preferences', 'member.communication-jobs': 'communication-jobs',
};

function cellText(value: unknown, moneyFlag?: boolean): string {
  if (value === null || value === undefined) return '—';
  if (moneyFlag === true && typeof value === 'number') return formatMoney(value, '');
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return String(value);
  return JSON.stringify(value);
}

/** Business id of a list row, when it carries one. */
function rowId(row: Record<string, unknown>): string | undefined {
  const id = row.id ?? row.name;
  return typeof id === 'string' || typeof id === 'number' ? String(id) : undefined;
}

/** Generic paged list pane for member/account/case/document/activity/search/scoped record inventories. */
export function ListPane({ entity, context, params }: { entity: Entity; context: WorkContext; params: Record<string, string> }): ReactNode {
  const [query, setQuery] = useState(params.query ?? '');
  const [offset, setOffset] = useState(0);
  const [scope, setScope] = useState<Record<string, string>>({});
  const [pickingScope, setPickingScope] = useState<PickerSource | null>(null);
  const [page, setPage] = useState<{ items: Record<string, unknown>[]; columns?: string[] | undefined; total: number; limitedTo?: number | null | undefined; matched?: number | undefined } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const limit = 50;

  const listKind = params.listKind ?? '';
  const scopeKind = entity === 'scoped' ? (LIST_SCOPE[listKind] ?? 'none') : 'none';
  const scopeField = scopeKind === 'member' ? 'memberId' : scopeKind === 'account' ? 'accountId' : scopeKind === 'loan' ? 'loanId'
    : scopeKind === 'batch' ? 'batchId' : scopeKind === 'schedule' ? 'scheduleId' : scopeKind === 'card' ? 'cardId'
    : scopeKind === 'beneficiary' ? 'beneficiaryId' : scopeKind === 'command' ? 'commandKind' : null;

  const load = useCallback(async () => {
    const base = institutionPath(context.institutionId, '');
    try {
      if (entity === 'scoped') {
        const memberEndpoint = MEMBER_LIST_ENDPOINTS[listKind];
        if (memberEndpoint !== undefined) {
          const memberId = scope.memberId ?? params.memberId;
          if (memberId === undefined) { setPage(null); return; }
          const rows = await getJson<Record<string, unknown>[]>(`${base}/members/${encodeURIComponent(memberId)}/${memberEndpoint}`);
          const first = rows[0];
          const keys = first === undefined ? [] : Object.keys(first).slice(0, 8);
          setPage({ items: rows, columns: keys, total: rows.length });
          setError(null);
          return;
        }
        const effectiveScope = { ...params, ...scope };
        const scopeMissing = scopeField !== null && listKind !== 'calendar.days' && effectiveScope[scopeField] === undefined;
        if (listKind === 'calendar.days' && (scope.from === undefined || scope.through === undefined)) { setPage(null); return; }
        if (scopeMissing) { setPage(null); return; }
        const result = await getJson<{ kind: string; page?: { columns: string[]; rows: { id: string; label: string; fields: Record<string, unknown> }[]; total: number; truncated: boolean } }>(
          `${base}/lists${queryString({ kind: listKind, ...effectiveScope, offset, limit })}`);
        if (result.kind !== 'found' || result.page === undefined) { setError((result as { message?: string }).message ?? 'List rejected.'); setPage(null); return; }
        setPage({ items: result.page.rows.map((row) => ({ id: row.id, label: row.label, ...row.fields })), columns: ['label', ...result.page.columns.filter((c) => c !== 'label')], total: result.page.total });
        setError(null);
        return;
      }
      if (entity === 'saved-searches') {
        const rows = await getJson<Record<string, unknown>[]>(`${base}/saved-searches`);
        setPage({ items: rows, total: rows.length });
        setError(null);
        return;
      }
      const path = entity === 'members' ? '/members' : entity === 'accounts' ? '/accounts' : entity === 'cases' ? '/cases' : entity === 'documents' ? '/documents' : '/activity';
      const result = await getJson<Page<Record<string, unknown>>>(`${base}${path}${queryString({ query, offset, limit })}`);
      setPage({ items: result.items, total: result.total, limitedTo: result.limitedTo ?? null, matched: result.matched });
      setError(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
      setPage(null);
    }
  }, [context.institutionId, entity, listKind, scope, scopeField, query, offset]);

  useEffect(() => { void load(); }, [load, context.refreshKey]);

  const columns = useMemo(() => entity === 'scoped' ? (page?.columns ?? []) : (COLUMNS[entity] ?? []).map((column) => column.key), [entity, page]);

  const openRow = (row: Record<string, unknown>): void => {
    if (entity === 'members') context.openTab({ kind: 'member', title: String(row.memberNumber ?? row.id), params: { id: String(row.id) } });
    else if (entity === 'accounts') context.openTab({ kind: 'account', title: String(row.accountNumber ?? row.id), params: { id: String(row.id) } });
    else if (entity === 'cases') context.openTab({ kind: 'case', title: String(row.caseNumber ?? row.id), params: { id: String(row.id) } });
    else if (entity === 'documents') context.openTab({ kind: 'document', title: String(row.displayName ?? row.id), params: { id: String(row.versionId ?? row.id) } });
    else if (entity === 'scoped' && listKind === 'merge.plans') context.openTab({ kind: 'merge-plan', title: `Merge ${(rowId(row) ?? '').slice(-8)}`, params: { id: rowId(row) ?? '' } });
    else if (entity === 'scoped') context.openTab({ kind: 'record', title: `${listKind} ${(rowId(row) ?? '').slice(-10)}`, params: { resource: resourceFor(listKind), id: rowId(row) ?? '' } });
    else context.message(`Row ${rowId(row) ?? ''}`);
  };

  return (
    <section className="list-pane">
      <div className="list-toolbar">
        {entity !== 'scoped' && entity !== 'saved-searches' ? (
          <input type="search" className="field-input" placeholder={`Search ${entity}…`} value={query}
            onChange={(event) => { setQuery(event.target.value); setOffset(0); }} onKeyDown={(event) => { if (event.key === 'Enter') void load(); }} />
        ) : null}
        {entity === 'scoped' && scopeKind !== 'none' ? (
          <span className="scope-picker">
            {scopeKind === 'dates' ? (
              <>
                <input className="field-input small" type="date" value={scope.from ?? ''} onChange={(e) => setScope((s) => ({ ...s, from: e.target.value }))} />
                <input className="field-input small" type="date" value={scope.through ?? ''} onChange={(e) => setScope((s) => ({ ...s, through: e.target.value }))} />
              </>
            ) : scopeKind === 'command' ? (
              <input className="field-input" placeholder="command kind (e.g. case.subject.correct)" value={scope.commandKind ?? ''} onChange={(e) => setScope((s) => ({ ...s, commandKind: e.target.value }))} />
            ) : (
              <button type="button" className="tool-button" onClick={() => setPickingScope(SCOPE_SOURCE[scopeKind] === undefined || SCOPE_SOURCE[scopeKind] === 'dates' || SCOPE_SOURCE[scopeKind] === 'command' ? null : SCOPE_SOURCE[scopeKind])}>
                {scope[scopeField ?? ''] ?? `Choose ${scopeKind}…`}
              </button>
            )}
          </span>
        ) : null}
        <button type="button" className="tool-button" onClick={() => void load()}>Refresh</button>
        <span className="muted">{page === null ? '' : `${page.items.length} of ${page.total}${page.limitedTo != null ? ` (limited to ${page.limitedTo}, matched ${page.matched ?? '?'})` : ''}`}</span>
        <button type="button" className="tool-button" disabled={offset === 0} onClick={() => setOffset((v) => Math.max(0, v - limit))}>◀</button>
        <button type="button" className="tool-button" disabled={page === null || offset + limit >= page.total} onClick={() => setOffset((v) => v + limit)}>▶</button>
      </div>
      {error !== null ? <p className="form-error" role="alert">{error}</p> : null}
      {entity === 'scoped' && scopeKind !== 'none' && page === null && error === null ? <p className="muted">Choose a ${scopeKind} scope to list {listKind}.</p> : null}
      {page === null ? null : (
        <table className="list-table" data-testid={`list-${entity}`}>
          <thead><tr>{columns.map((key) => <th key={key}>{key}</th>)}</tr></thead>
          <tbody>
            {page.items.map((row, index) => (
              <tr key={rowId(row) ?? index} onClick={() => openRow(row)} data-row-id={rowId(row) ?? String(index)}>
                {columns.map((key) => <td key={key} data-col={key}>{cellText(row[key], COLUMNS[entity]?.find((column) => column.key === key)?.money)}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {pickingScope !== null ? (
        <PickerDialog institutionId={context.institutionId} source={pickingScope} scope={{ values: scope }}
          title={`Scope — ${scopeKind}`}
          onPick={(option) => { setScope((s) => ({ ...s, [scopeField ?? '']: option.id })); setPickingScope(null); setOffset(0); }}
          onClose={() => setPickingScope(null)} />
      ) : null}
    </section>
  );
}

const SCOPED_RESOURCE: Record<string, string> = {
  'member.beneficiaries': 'beneficiary', 'beneficiary.routes': 'beneficiary-route',
  'member.payments': 'payment', 'account.payments': 'payment', 'account.schedules': 'payment-schedule',
  'schedule.occurrences': 'schedule-occurrence', 'member.payment_returns': 'payment-return', 'account.payment_returns': 'payment-return',
  'account.cards': 'card', 'card.transactions': 'card-transaction', 'member.disputes': 'dispute', 'account.disputes': 'dispute',
  'member.loans': 'loan', 'account.loans': 'loan', 'loan.payoff_quotes': 'loan-closure',
  'account.interest_calculations': 'interest-calculation', 'account.fees': 'fee',
  'settlement.batches': 'settlement-batch', 'suspense.items': 'suspense-item', 'batches': 'batch',
  'member.received_funds': 'received-funds', 'cash.sessions': 'cash-session',
};

function resourceFor(listKind: string): string {
  return SCOPED_RESOURCE[listKind] ?? 'payment';
}
