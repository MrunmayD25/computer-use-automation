/**
 * Declarative catalog of every business command the workstation exposes.
 * Field specs declare the control, scoping, and derived-value wiring; the dialog
 * builds the command object, reviews it, and commits it through the shared services.
 */

export type Section =
  | 'member' | 'account' | 'money' | 'payments' | 'cards' | 'loans'
  | 'documents' | 'cases' | 'servicing' | 'reconciliation' | 'search';

export type PickerSource =
  | 'member' | 'account' | 'case' | 'queue' | 'actor' | 'checker' | 'policyVersion' | 'approval'
  | 'document' | 'documentVersion' | 'evidence' | 'consent' | 'partyAddress' | 'addressDestination'
  | 'beneficiary' | 'beneficiaryRoute' | 'payment' | 'paymentSchedule' | 'occurrence' | 'paymentReturn'
  | 'card' | 'cardTransaction' | 'dispute' | 'loan' | 'payoffQuote' | 'interestCalculation' | 'fee' | 'feeWaiver'
  | 'hold' | 'restriction' | 'facility' | 'maturityInstruction' | 'journal' | 'transferJournal'
  | 'batch' | 'batchItem' | 'suspenseItem' | 'settlementBatch' | 'receivedFunds' | 'mergePlan'
  | 'product' | 'loanProduct' | 'cashSession' | 'maintenanceRequest' | 'communicationJob'
  | 'savedSearch' | 'statementPeriod' | 'calendarDay' | 'annotation' | 'destinationTarget';

export type Control =
  | { type: 'text' }
  | { type: 'textarea' }
  | { type: 'integer'; min?: number; max?: number }
  | { type: 'number' }
  /** Exact money; `currencyOf` names the account-picker field that fixes the currency. */
  | { type: 'money'; currencyOf?: string }
  | { type: 'date' }
  | { type: 'instant' }
  | { type: 'boolean' }
  | { type: 'enum'; options: readonly string[] }
  /** Newline-separated string list. */
  | { type: 'strings' }
  | { type: 'picker'; source: PickerSource }
  | { type: 'picker-multi'; source: PickerSource }
  | { type: 'address' }
  | { type: 'owners' }
  | { type: 'excerpts' }
  | { type: 'patch' }
  | { type: 'definition' }
  | { type: 'expectedMetadata' }
  | { type: 'requestedCommand' }
  | { type: 'file' }
  | { type: 'annotationRegion' }
  | { type: 'hidden' };

export interface FieldSpec {
  name: string;
  label: string;
  control: Control;
  /** Always sent; commit is blocked while the value is empty. */
  required?: boolean;
  /** Omitted from the command when empty. */
  optional?: boolean;
  /** Empty value is sent as null. */
  nullable?: boolean;
  /** Picker scoping: value of another field supplies the scope id. */
  scopeFrom?: string;
  /** Picker scoping keyed by the member/account field in this form. */
  memberFrom?: string;
  accountFrom?: string;
  /** Derived field: filled automatically from the picked record of `from`. */
  auto?: { from: string; property: string; resource?: string };
  /** On pick, copy `from` (a key of the option's record/fields) into `field`. */
  fills?: readonly { field: string; from: string }[];
  /** Only shown when `field`'s value is in `oneOf`. */
  when?: { field: string; oneOf: readonly unknown[] };
  help?: string;
}

export interface OperationSpec {
  kind: string;
  title: string;
  section: Section;
  /** Task-catalog capability ids this operation serves. */
  tasks: readonly string[];
  /** The command carries an approvalId and must be requested through maker/checker. */
  gated?: boolean;
  description?: string;
  fields: readonly FieldSpec[];
}

// --- field builders ---------------------------------------------------------

const text = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'text' }, required: true, ...extra });
const area = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'textarea' }, required: true, ...extra });
const int = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'integer' }, required: true, ...extra });
const money = (name: string, label: string, currencyOf?: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'money', ...(currencyOf === undefined ? {} : { currencyOf }) }, required: true, ...extra });
const date = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'date' }, required: true, ...extra });
const instant = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'instant' }, required: true, ...extra });
const bool = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'boolean' }, required: true, ...extra });
const en = (name: string, label: string, options: readonly string[], extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'enum', options }, required: true, ...extra });
const strings = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'strings' }, required: true, ...extra });
const pick = (name: string, label: string, source: PickerSource, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'picker', source }, required: true, ...extra });
const picks = (name: string, label: string, source: PickerSource, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'picker-multi', source }, required: true, ...extra });
const auto = (name: string, label: string, from: string, property: string, resource?: string): FieldSpec =>
  ({ name, label, control: { type: 'hidden' }, required: true, auto: { from, property, ...(resource === undefined ? {} : { resource }) } });
const address = (name: string, label = 'Address', extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, control: { type: 'address' }, ...extra });

const memberField = pick('memberId', 'Member', 'member');
const memberVersion = auto('expectedVersion', 'Member version', 'memberId', 'version');
const memberVersionAs = (name: string, from: string): FieldSpec => auto(name, 'Member version', from, 'version');
const accountField = pick('accountId', 'Account', 'account');
const accountVersion = auto('expectedVersion', 'Account version', 'accountId', 'version');
const caseVersion = auto('expectedVersion', 'Case version', 'caseId', 'version');
const evidenceField = (memberFrom = 'memberId', name = 'evidenceId', label = 'Identity evidence'): FieldSpec =>
  pick(name, label, 'evidence', { memberFrom });

// --- the catalog ------------------------------------------------------------

export const OPERATIONS: readonly OperationSpec[] = [
  // Members
  { kind: 'member.create', title: 'Open member', section: 'member', tasks: ['T001'], fields: [
    text('legalGiven', 'Legal given name'), text('legalFamily', 'Legal family name'), text('preferredName', 'Preferred name', { optional: true }),
    date('birthDate', 'Birth date'), text('email', 'Email', { optional: true }), text('phone', 'Phone', { optional: true }), address('address', 'Address', { optional: true }),
  ] },
  { kind: 'member.organization.create', title: 'Open organization member', section: 'member', tasks: ['T001'], fields: [
    text('legalName', 'Legal name'), text('registrationNumber', 'Registration number'), en('organizationType', 'Organization type', ['corporation', 'nonprofit']),
    text('email', 'Email', { optional: true }), text('phone', 'Phone', { optional: true }), address('address', 'Address', { optional: true }),
  ] },
  { kind: 'contact.update', title: 'Update contact details', section: 'member', tasks: ['T002'], fields: [
    memberField, memberVersion, text('email', 'Email', { optional: true, nullable: true }), text('phone', 'Phone', { optional: true, nullable: true }),
    address('address', 'Address', { optional: true }),
  ] },
  { kind: 'member.note.add', title: 'Add member note', section: 'member', tasks: ['T003'], fields: [
    memberField, en('visibility', 'Visibility', ['general', 'restricted']), area('text', 'Note'),
  ] },
  { kind: 'member.identity_evidence.register', title: 'Register identity evidence', section: 'member', tasks: ['T014'], fields: [
    memberField, pick('documentVersionId', 'Evidence document version', 'documentVersion', { memberFrom: 'memberId' }),
    en('evidenceKind', 'Evidence kind', ['passport', 'drivers-license', 'national-id', 'state-id']),
    date('issuedAt', 'Issued on'), date('expiresAt', 'Expires on'), text('reference', 'Evidence reference'), text('evidenceId', 'Evidence id', { optional: true }),
  ] },
  { kind: 'member.identity.verify', title: 'Verify member identity', section: 'member', tasks: ['T014'], fields: [
    memberField, pick('evidenceId', 'Evidence', 'evidence', { memberFrom: 'memberId' }), text('method', 'Verification method'),
  ] },
  { kind: 'member.legal_name.update', title: 'Update legal name', section: 'member', tasks: ['T015'], gated: true, fields: [
    memberField, memberVersion, text('legalGiven', 'Legal given name'), text('legalFamily', 'Legal family name'), evidenceField(),
  ] },
  { kind: 'member.preferred_name.update', title: 'Update preferred name', section: 'member', tasks: ['T016'], fields: [
    memberField, memberVersion, text('preferredName', 'Preferred name', { nullable: true }), text('communicationScope', 'Communication scope'),
  ] },
  { kind: 'member.merge', title: 'Merge members', section: 'member', tasks: ['T017'], gated: true, fields: [
    pick('mergePlanId', 'Merge plan', 'mergePlan', { fills: [{ field: 'sourceMemberId', from: 'sourceMemberId' }, { field: 'targetMemberId', from: 'targetMemberId' }] }),
    auto('sourceMemberId', 'Source member', 'mergePlanId', 'sourceMemberId'), auto('targetMemberId', 'Target member', 'mergePlanId', 'targetMemberId'),
    auto('expectedSourceVersion', 'Source version', 'sourceMemberId', 'version'), auto('expectedTargetVersion', 'Target version', 'targetMemberId', 'version'),
    picks('relationshipAccountIds', 'Relationship accounts', 'account', { memberFrom: 'sourceMemberId' }),
    auto('expectedInventoryFingerprint', 'Plan fingerprint', 'mergePlanId', 'inventoryFingerprint'),
  ] },
  { kind: 'member.deceased.record', title: 'Record member deceased', section: 'member', tasks: ['T018'], gated: true, fields: [
    memberField, memberVersion, evidenceField(), date('effectiveDate', 'Effective date'),
  ] },
  { kind: 'member.beneficial_owners.update', title: 'Update beneficial owners', section: 'member', tasks: ['T019'], gated: true, fields: [
    pick('organizationMemberId', 'Organization member', 'member'), memberVersionAs('expectedVersion', 'organizationMemberId'),
    { name: 'owners', label: 'Beneficial owners', control: { type: 'owners' }, required: true }, date('effectiveDate', 'Effective date'),
  ] },
  { kind: 'member.tax_classification.update', title: 'Update tax classification', section: 'member', tasks: ['T020'], gated: true, fields: [
    memberField, memberVersion, text('classification', 'Tax classification'), int('effectiveYear', 'Effective year'), evidenceField(),
  ] },

  // Accounts
  { kind: 'account.open', title: 'Open account', section: 'account', tasks: ['T004'], fields: [
    memberField, pick('productId', 'Product', 'product'), text('nickname', 'Nickname'), en('statementDelivery', 'Statement delivery', ['paper', 'electronic']),
  ] },
  { kind: 'account.nickname.update', title: 'Rename account', section: 'account', tasks: ['T005'], fields: [accountField, accountVersion, text('nickname', 'Nickname')] },
  { kind: 'account.statement_delivery.update', title: 'Change statement delivery', section: 'account', tasks: ['T006'], fields: [
    accountField, accountVersion, en('statementDelivery', 'Statement delivery', ['paper', 'electronic']),
  ] },
  { kind: 'account.close', title: 'Close account', section: 'account', tasks: ['T007'], fields: [accountField, accountVersion, text('reason', 'Closure reason')] },
  { kind: 'account.product.convert', title: 'Convert account product', section: 'account', tasks: ['T021'], gated: true, fields: [
    accountField, accountVersion, pick('targetProductId', 'Target product', 'product'), date('effectiveDate', 'Effective date'), bool('feeDisclosureAccepted', 'Fee disclosure accepted'),
  ] },
  { kind: 'account.owner.add', title: 'Add account owner', section: 'account', tasks: ['T022'], gated: true, fields: [
    accountField, accountVersion, memberField, en('role', 'Ownership role', ['owner', 'joint-owner']), date('effectiveDate', 'Effective date'),
    evidenceField('memberId', 'identityEvidenceId'), pick('consentId', 'Consent', 'consent', { memberFrom: 'memberId' }),
  ] },
  { kind: 'account.signer.remove', title: 'Remove account signer', section: 'account', tasks: ['T023'], gated: true, fields: [
    accountField, accountVersion, pick('signerMemberId', 'Signer to remove', 'member'), instant('effectiveAt', 'Effective at'),
  ] },
  { kind: 'account.overdraft_limit.update', title: 'Update overdraft limit', section: 'account', tasks: ['T024'], gated: true, fields: [
    accountField, accountVersion,
    { name: 'expectedFacilityFingerprint', label: 'Facility fingerprint', control: { type: 'hidden' }, nullable: true,
      auto: { from: 'accountId', property: 'facilityFingerprint' } },
    money('limit', 'New limit', 'accountId'), date('effectiveDate', 'Effective date'), instant('expiresAt', 'Expires at', { nullable: true }),
  ] },
  { kind: 'account.hold.place', title: 'Place account hold', section: 'account', tasks: ['T025'], fields: [
    accountField, accountVersion, money('amount', 'Hold amount', 'accountId'), text('reason', 'Reason'),
    instant('expiresAt', 'Expires at', { optional: true, nullable: true }), text('releaseAuthority', 'Release authority'),
  ] },
  { kind: 'account.hold.release', title: 'Release account hold', section: 'account', tasks: ['T026'], fields: [
    pick('holdId', 'Hold', 'hold', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Hold fingerprint', 'holdId', 'fingerprint', 'hold'),
    int('amountMinorUnits', 'Release amount (minor units)'), text('releaseAuthority', 'Release authority'), text('evidenceReference', 'Evidence reference'),
  ] },
  { kind: 'account.restriction.apply', title: 'Apply account restriction', section: 'account', tasks: ['T027'], gated: true, fields: [
    accountField, accountVersion, en('restrictionType', 'Restriction', ['debit-block', 'credit-block', 'closure-block', 'fraud-review', 'legal-hold']),
    text('reason', 'Reason'), text('authority', 'Authority'), pick('caseId', 'Case', 'case', { optional: true, nullable: true }),
  ] },
  { kind: 'account.restriction.release', title: 'Release account restriction', section: 'account', tasks: ['T028'], gated: true, fields: [
    pick('restrictionId', 'Restriction', 'restriction', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Restriction fingerprint', 'restrictionId', 'fingerprint', 'restriction'),
    pick('clearanceEvidenceId', 'Clearance evidence', 'evidence', {}),
  ] },
  { kind: 'account.maturity.instruct', title: 'Maturity instruction', section: 'account', tasks: ['T098'], gated: true, fields: [
    accountField, accountVersion,
    { name: 'expectedInstructionFingerprint', label: 'Instruction fingerprint', control: { type: 'hidden' }, nullable: true,
      auto: { from: 'accountId', property: 'maturityInstructionFingerprint' } },
    en('disposition', 'Disposition', ['renew', 'transfer', 'hold']),
    pick('destinationAccountId', 'Destination account', 'account', { nullable: true }),
    int('termMonths', 'Renewal term (months)', { nullable: true }), int('approvedAnnualRateBps', 'Approved rate (bps)', { nullable: true }),
  ] },

  // Money movement (teller)
  { kind: 'cash.deposit', title: 'Deposit cash', section: 'money', tasks: ['T008'], fields: [
    accountField, accountVersion, money('amount', 'Amount', 'accountId'), text('description', 'Description'),
  ] },
  { kind: 'cash.withdraw', title: 'Withdraw cash', section: 'money', tasks: ['T009'], fields: [
    accountField, accountVersion, money('amount', 'Amount', 'accountId'), text('description', 'Description'),
  ] },
  { kind: 'transfer.internal', title: 'Internal transfer', section: 'money', tasks: ['T010'], fields: [
    pick('sourceAccountId', 'Source account', 'account'), pick('destinationAccountId', 'Destination account', 'account'),
    auto('expectedSourceVersion', 'Source version', 'sourceAccountId', 'version'), auto('expectedDestinationVersion', 'Destination version', 'destinationAccountId', 'version'),
    money('amount', 'Amount', 'sourceAccountId'), text('description', 'Description'),
  ] },
  { kind: 'cash.deposit.reverse', title: 'Reverse deposit', section: 'money', tasks: ['T032'], gated: true, fields: [
    pick('journalId', 'Deposit journal', 'journal', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Journal fingerprint', 'journalId', 'fingerprint', 'transaction'),
    pick('correctionEvidenceId', 'Correction evidence', 'evidence', {}),
  ] },
  { kind: 'cash.withdrawal.reverse', title: 'Reverse withdrawal', section: 'money', tasks: ['T033'], gated: true, fields: [
    pick('journalId', 'Withdrawal journal', 'journal', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Journal fingerprint', 'journalId', 'fingerprint', 'transaction'), text('reason', 'Reason'),
  ] },
  { kind: 'transfer.internal.reverse', title: 'Reverse internal transfer', section: 'money', tasks: ['T034'], gated: true, fields: [
    pick('transferJournalId', 'Transfer journal', 'transferJournal', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Transfer fingerprint', 'transferJournalId', 'fingerprint', 'transfer'),
    money('amount', 'Amount'), text('reason', 'Reason'),
  ] },
  { kind: 'interest.adjust', title: 'Adjust interest', section: 'money', tasks: ['T035'], gated: true, fields: [
    accountField, pick('calculationId', 'Interest calculation', 'interestCalculation', { accountFrom: 'accountId' }),
    auto('expectedFingerprint', 'Calculation fingerprint', 'calculationId', 'fingerprint', 'interest-calculation'),
    money('approvedDelta', 'Approved delta', 'accountId'),
  ] },
  { kind: 'transaction.effective_date.correct', title: 'Correct effective date', section: 'money', tasks: ['T036'], gated: true, fields: [
    pick('journalId', 'Journal', 'journal', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Journal fingerprint', 'journalId', 'fingerprint', 'transaction'),
    date('correctedDate', 'Corrected effective date'), pick('policyVersionId', 'Policy version', 'policyVersion'), text('reason', 'Reason'),
  ] },
  { kind: 'transaction.description.update', title: 'Amend transaction description', section: 'money', tasks: ['T099'], fields: [
    pick('journalId', 'Journal', 'journal', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Journal fingerprint', 'journalId', 'fingerprint', 'transaction'), text('description', 'New description'),
  ] },
  { kind: 'fee.assess', title: 'Assess fee', section: 'money', tasks: ['T029'], fields: [
    accountField, accountVersion, text('feeCode', 'Fee code'), money('amount', 'Amount', 'accountId'), text('basis', 'Basis'),
    pick('policyVersionId', 'Policy version', 'policyVersion'),
  ] },
  { kind: 'fee.waiver.create', title: 'Create fee waiver', section: 'money', tasks: ['T030'], gated: true, fields: [
    accountField, text('feeCode', 'Fee code'), date('validFrom', 'Valid from'), date('validThrough', 'Valid through'),
    money('amountLimit', 'Amount limit', 'accountId'), int('maxOccurrences', 'Max occurrences'), text('reason', 'Reason'),
  ] },
  { kind: 'fee.refund', title: 'Refund fee', section: 'money', tasks: ['T031'], fields: [
    pick('feeId', 'Fee', 'fee', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Fee fingerprint', 'feeId', 'fingerprint', 'fee'), money('amount', 'Refund amount', 'accountId'), text('reason', 'Reason'),
  ] },

  // Payments & beneficiaries
  { kind: 'beneficiary.create', title: 'Create beneficiary', section: 'payments', tasks: ['T037'], fields: [
    memberField, memberVersionAs('expectedMemberVersion', 'memberId'), text('displayName', 'Beneficiary name'), text('routingKind', 'Routing kind'),
    text('maskedDestination', 'Masked destination'), text('simulatedToken', 'Simulated token'), strings('allowedRails', 'Allowed rails'),
  ] },
  { kind: 'beneficiary.verify', title: 'Verify beneficiary route', section: 'payments', tasks: ['T038'], gated: true, fields: [
    pick('beneficiaryId', 'Beneficiary', 'beneficiary', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    pick('routeId', 'Route', 'beneficiaryRoute', { scopeFrom: 'beneficiaryId' }),
    auto('expectedFingerprint', 'Route fingerprint', 'routeId', 'fingerprint', 'beneficiary-route'), evidenceField('memberId'),
  ] },
  { kind: 'beneficiary.routing.update', title: 'Update beneficiary routing', section: 'payments', tasks: ['T039'], gated: true, fields: [
    pick('beneficiaryId', 'Beneficiary', 'beneficiary', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    pick('routeId', 'Route', 'beneficiaryRoute', { scopeFrom: 'beneficiaryId' }),
    auto('expectedRouteFingerprint', 'Route fingerprint', 'routeId', 'fingerprint', 'beneficiary-route'),
    text('routingKind', 'Routing kind'), text('maskedDestination', 'Masked destination'), text('simulatedToken', 'Simulated token'), date('effectiveDate', 'Effective date'),
  ] },
  { kind: 'beneficiary.retire', title: 'Retire beneficiary', section: 'payments', tasks: ['T040'], fields: [
    pick('beneficiaryId', 'Beneficiary', 'beneficiary', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedFingerprint', 'Beneficiary fingerprint', 'beneficiaryId', 'fingerprint', 'beneficiary'),
    en('dependentDisposition', 'Dependents', ['reject-if-active', 'cancel-drafts']), text('reason', 'Reason'),
  ] },
  { kind: 'payment.create', title: 'Create payment', section: 'payments', tasks: ['T041'], fields: [
    pick('sourceAccountId', 'Source account', 'account'), auto('expectedSourceVersion', 'Source version', 'sourceAccountId', 'version'),
    pick('beneficiaryId', 'Beneficiary', 'beneficiary', { optional: true }), pick('beneficiaryRouteId', 'Beneficiary route', 'beneficiaryRoute', { scopeFrom: 'beneficiaryId' }),
    auto('expectedRouteFingerprint', 'Route fingerprint', 'beneficiaryRouteId', 'fingerprint', 'beneficiary-route'),
    money('amount', 'Amount', 'sourceAccountId'), text('rail', 'Rail'),
    pick('requestedDate', 'Requested date', 'calendarDay', { fills: [{ field: 'calendarVersion', from: 'calendarVersion' }, { field: 'cutoffAt', from: 'paymentCutoffAt' }] }),
    auto('calendarVersion', 'Calendar version', 'requestedDate', 'calendarVersion'), auto('cutoffAt', 'Cutoff', 'requestedDate', 'paymentCutoffAt'),
    text('reference', 'Reference'), en('targetState', 'Initial state', ['draft', 'pending-approval']),
  ] },
  { kind: 'payment.submit', title: 'Submit payment', section: 'payments', tasks: ['T041'], fields: [
    pick('paymentId', 'Payment', 'payment', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedVersion', 'Payment version', 'paymentId', 'version'),
  ] },
  { kind: 'payment.approve_release', title: 'Approve payment release', section: 'payments', tasks: ['T042'], gated: true, fields: [
    pick('paymentId', 'Payment', 'payment', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedVersion', 'Payment version', 'paymentId', 'version'),
    pick('requestedDate', 'Requested date', 'calendarDay', { fills: [{ field: 'calendarVersion', from: 'calendarVersion' }, { field: 'cutoffAt', from: 'paymentCutoffAt' }] }),
    auto('calendarVersion', 'Calendar version', 'requestedDate', 'calendarVersion'), auto('cutoffAt', 'Cutoff', 'requestedDate', 'paymentCutoffAt'),
  ] },
  { kind: 'payment.settle', title: 'Settle payment', section: 'payments', tasks: ['T042'], fields: [
    pick('paymentId', 'Payment', 'payment', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedVersion', 'Payment version', 'paymentId', 'version'), text('settlementReference', 'Settlement reference'),
  ] },
  { kind: 'payment.schedule.create', title: 'Create payment schedule', section: 'payments', tasks: ['T043'], gated: true, fields: [
    pick('sourceAccountId', 'Source account', 'account'), auto('expectedSourceVersion', 'Source version', 'sourceAccountId', 'version'),
    pick('beneficiaryId', 'Beneficiary', 'beneficiary', { optional: true }), pick('beneficiaryRouteId', 'Beneficiary route', 'beneficiaryRoute', { scopeFrom: 'beneficiaryId' }),
    auto('expectedRouteFingerprint', 'Route fingerprint', 'beneficiaryRouteId', 'fingerprint', 'beneficiary-route'),
    money('amount', 'Amount', 'sourceAccountId'), en('frequency', 'Frequency', ['daily', 'weekly', 'monthly']), int('interval', 'Every N periods'),
    date('startDate', 'Start date'), date('endDate', 'End date'),
  ] },
  { kind: 'payment.schedule.materialize', title: 'Materialize occurrence', section: 'payments', tasks: ['T043'], fields: [
    pick('scheduleId', 'Schedule', 'paymentSchedule', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    pick('occurrenceId', 'Occurrence', 'occurrence', { scopeFrom: 'scheduleId' }),
    auto('expectedFingerprint', 'Occurrence fingerprint', 'occurrenceId', 'fingerprint', 'schedule-occurrence'),
  ] },
  { kind: 'payment.occurrence.amend', title: 'Amend occurrence', section: 'payments', tasks: ['T044'], fields: [
    pick('scheduleId', 'Schedule', 'paymentSchedule', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    pick('occurrenceId', 'Occurrence', 'occurrence', { scopeFrom: 'scheduleId' }),
    auto('expectedFingerprint', 'Occurrence fingerprint', 'occurrenceId', 'fingerprint', 'schedule-occurrence'),
    money('newAmount', 'New amount', 'accountId'), date('newDate', 'New date'),
  ] },
  { kind: 'payment.cancel', title: 'Cancel payment', section: 'payments', tasks: ['T045'], fields: [
    pick('paymentId', 'Payment', 'payment', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedVersion', 'Payment version', 'paymentId', 'version'), text('reason', 'Reason'),
  ] },
  { kind: 'payment.return.resolve', title: 'Resolve payment return', section: 'payments', tasks: ['T046'], gated: true, fields: [
    pick('returnId', 'Return', 'paymentReturn', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Return fingerprint', 'returnId', 'fingerprint', 'payment-return'),
    auto('paymentId', 'Payment', 'returnId', 'paymentId'), en('disposition', 'Disposition', ['credit-source', 'investigate']),
  ] },
  { kind: 'payment.schedule.end', title: 'End payment schedule', section: 'payments', tasks: ['T097'], gated: true, fields: [
    pick('scheduleId', 'Schedule', 'paymentSchedule', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Schedule fingerprint', 'scheduleId', 'fingerprint', 'payment-schedule'),
    date('endFromDate', 'End from'), en('pendingDisposition', 'Pending occurrences', ['cancel-planned', 'retain-released']),
  ] },

  // Cards & disputes
  { kind: 'card.replace', title: 'Replace card', section: 'cards', tasks: ['T047'], fields: [
    pick('cardId', 'Card', 'card', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Card fingerprint', 'cardId', 'fingerprint', 'card'), text('reason', 'Reason'),
    pick('identityEvidenceId', 'Identity evidence', 'evidence', { optional: true, nullable: true }),
    pick('deliveryDestinationId', 'Delivery destination', 'addressDestination', { optional: true, nullable: true }),
    pick('deliveryAddressId', 'Delivery address', 'partyAddress', { optional: true, nullable: true }),
  ] },
  { kind: 'card.lock.update', title: 'Lock or unlock card', section: 'cards', tasks: ['T048'], fields: [
    pick('cardId', 'Card', 'card', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Card fingerprint', 'cardId', 'fingerprint', 'card'),
    en('requestedState', 'Requested state', ['locked', 'unlocked']), text('authority', 'Authority'),
  ] },
  { kind: 'card.limit.update', title: 'Update card limit', section: 'cards', tasks: ['T049'], gated: true, fields: [
    pick('cardId', 'Card', 'card', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Card fingerprint', 'cardId', 'fingerprint', 'card'),
    en('limitKind', 'Limit kind', ['daily-purchase', 'cash', 'online']), money('amount', 'Limit amount', 'accountId'),
    instant('effectiveAt', 'Effective at'), instant('expiresAt', 'Expires at', { nullable: true }),
  ] },
  { kind: 'dispute.open', title: 'Open dispute', section: 'cards', tasks: ['T050'], fields: [
    pick('cardId', 'Card', 'card', { accountFrom: 'accountId' }), pick('accountId', 'Account', 'account', { optional: true }),
    pick('cardTransactionId', 'Card transaction', 'cardTransaction', { scopeFrom: 'cardId' }),
    auto('expectedFingerprint', 'Transaction fingerprint', 'cardTransactionId', 'fingerprint', 'card-transaction'),
    text('reason', 'Reason'), money('assertedAmount', 'Asserted amount', 'accountId'),
    picks('evidenceIds', 'Evidence', 'evidence', { memberFrom: 'memberId', optional: true }), pick('memberId', 'Member', 'member', { optional: true }),
  ] },
  { kind: 'dispute.provisional_credit.issue', title: 'Issue provisional credit', section: 'cards', tasks: ['T051'], gated: true, fields: [
    pick('disputeId', 'Dispute', 'dispute', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Dispute fingerprint', 'disputeId', 'fingerprint', 'dispute'), money('amount', 'Credit amount', 'accountId'),
  ] },
  { kind: 'dispute.evidence.submit', title: 'Submit dispute evidence', section: 'cards', tasks: ['T052'], gated: true, fields: [
    pick('disputeId', 'Dispute', 'dispute', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Dispute fingerprint', 'disputeId', 'fingerprint', 'dispute'),
    picks('documentVersionIds', 'Evidence documents', 'documentVersion', { memberFrom: 'memberId' }),
    instant('deadline', 'Deadline'), text('recipient', 'Recipient'), text('channel', 'Channel'),
  ] },
  { kind: 'dispute.settle', title: 'Settle dispute', section: 'cards', tasks: ['T053'], gated: true, fields: [
    pick('disputeId', 'Dispute', 'dispute', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Dispute fingerprint', 'disputeId', 'fingerprint', 'dispute'),
    en('decision', 'Decision', ['approved', 'denied']), money('finalAmount', 'Final amount', 'accountId'),
  ] },

  // Loans
  { kind: 'loan.application.prepare', title: 'Prepare loan application', section: 'loans', tasks: ['T054'], fields: [
    memberField, memberVersionAs('expectedMemberVersion', 'memberId'), pick('productId', 'Loan product', 'loanProduct'),
    money('requestedAmount', 'Requested amount'), int('termMonths', 'Term (months)'), text('purpose', 'Purpose'),
    picks('evidenceIds', 'Evidence', 'evidence', { memberFrom: 'memberId', optional: true }),
  ] },
  { kind: 'loan.payment.allocate', title: 'Allocate loan payment', section: 'loans', tasks: ['T055'], fields: [
    pick('loanId', 'Loan', 'loan', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Loan fingerprint', 'loanId', 'fingerprint', 'loan'),
    pick('receivedFundsReference', 'Received funds', 'receivedFunds', { memberFrom: 'memberId' }),
    money('amount', 'Amount'), en('allocationPolicy', 'Allocation', ['fees-interest-principal', 'fees-interest-principal-hold-remainder']),
  ] },
  { kind: 'loan.payoff.quote', title: 'Quote loan payoff', section: 'loans', tasks: ['T056'], fields: [
    pick('loanId', 'Loan', 'loan', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Loan fingerprint', 'loanId', 'fingerprint', 'loan'),
    date('payoffDate', 'Payoff date'), pick('policyVersionId', 'Policy version', 'policyVersion'),
  ] },
  { kind: 'loan.close', title: 'Close loan', section: 'loans', tasks: ['T101'], gated: true, fields: [
    pick('loanId', 'Loan', 'loan', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedFingerprint', 'Loan fingerprint', 'loanId', 'fingerprint', 'loan'),
    pick('payoffEvidenceId', 'Payoff evidence', 'evidence', { memberFrom: 'memberId' }),
  ] },
  { kind: 'document.loan_closure.issue', title: 'Issue loan closure document', section: 'loans', tasks: ['T102'], gated: true, fields: [
    pick('loanId', 'Loan', 'loan', { memberFrom: 'memberId', accountFrom: 'accountId' }),
    pick('memberId', 'Member', 'member', { optional: true }), pick('accountId', 'Account', 'account', { optional: true }),
    auto('expectedClosureFingerprint', 'Closure fingerprint', 'loanId', 'fingerprint', 'loan-closure'),
    pick('templateVersionId', 'Template version', 'documentVersion', { memberFrom: 'memberId' }),
    auto('recipientPartyId', 'Recipient party', 'memberId', 'partyId'),
    en('documentType', 'Document type', ['loan-closure-confirmation', 'simulated-lien-release']),
  ] },

  // Cases & servicing
  { kind: 'case.open', title: 'Open case', section: 'cases', tasks: ['T065'], fields: [
    memberField, pick('accountId', 'Account', 'account', { memberFrom: 'memberId', nullable: true }),
    pick('queueId', 'Queue', 'queue'), pick('assignedActorId', 'Assignee', 'actor', { nullable: true }),
    text('category', 'Category'), en('priority', 'Priority', ['low', 'normal', 'high', 'urgent']), area('summary', 'Summary'), date('dueDate', 'Due date'),
  ] },
  { kind: 'case.assign', title: 'Assign case', section: 'cases', tasks: ['T066'], fields: [
    pick('caseId', 'Case', 'case', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }), caseVersion,
    pick('queueId', 'Queue', 'queue'), pick('assignedActorId', 'Assignee', 'actor', { nullable: true }), text('reason', 'Reason'),
  ] },
  { kind: 'case.transition', title: 'Transition case', section: 'cases', tasks: ['T070'], fields: [
    pick('caseId', 'Case', 'case', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }), caseVersion,
    en('toState', 'New state', ['open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened']), text('reason', 'Reason'),
  ] },
  { kind: 'case.note.add', title: 'Add case note', section: 'cases', tasks: ['T091'], fields: [
    pick('caseId', 'Case', 'case', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    en('visibility', 'Visibility', ['general', 'restricted']), area('text', 'Note'),
    picks('evidenceVersionIds', 'Evidence documents', 'documentVersion', { memberFrom: 'memberId', optional: true }),
  ] },
  { kind: 'case.information.request', title: 'Request case information', section: 'cases', tasks: ['T067'], fields: [
    pick('caseId', 'Case', 'case', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }), caseVersion,
    strings('fields', 'Requested fields'), auto('recipientPartyId', 'Recipient party', 'caseId', 'memberPartyId'),
    text('channel', 'Channel'), instant('dueAt', 'Due at'),
    pick('documentVersionId', 'Request document', 'documentVersion', { memberFrom: 'memberId', optional: true, nullable: true }), text('destination', 'Destination', { optional: true }),
  ] },
  { kind: 'case.escalate', title: 'Escalate case', section: 'cases', tasks: ['T068'], fields: [
    pick('caseId', 'Case', 'case', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }), caseVersion, text('escalationRule', 'Escalation rule'),
  ] },
  { kind: 'case.close', title: 'Close case', section: 'cases', tasks: ['T070'], fields: [
    pick('caseId', 'Case', 'case', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }), caseVersion,
    text('resolutionCode', 'Resolution code'),
    pick('effectEvidenceVersionId', 'Effect evidence version', 'documentVersion', { memberFrom: 'memberId' }),
  ] },
  { kind: 'case.reopen', title: 'Reopen case', section: 'cases', tasks: ['T071'], fields: [
    pick('caseId', 'Case', 'case', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }), caseVersion,
    pick('evidenceVersionId', 'Evidence version', 'documentVersion', { memberFrom: 'memberId' }), text('reopeningBasis', 'Reopening basis'), instant('dueAt', 'Due at', { optional: true }),
  ] },
  { kind: 'case.subject.correct', title: 'Correct case subject', section: 'cases', tasks: ['T072'], gated: true, fields: [
    pick('caseId', 'Case', 'case'), caseVersion, pick('correctMemberId', 'Correct member', 'member'),
    pick('correctAccountId', 'Correct account', 'account', { memberFrom: 'correctMemberId', nullable: true }),
    pick('evidenceVersionId', 'Evidence version', 'documentVersion', { memberFrom: 'correctMemberId' }),
  ] },
  { kind: 'edit.cancel', title: 'Cancel pending edit', section: 'servicing', tasks: ['T089'], fields: [
    pick('requestId', 'Request', 'maintenanceRequest', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedUpdatedAt', 'Request updated at', 'requestId', 'updatedAt'),
  ] },

  // Documents & servicing
  { kind: 'document.index', title: 'Index document', section: 'documents', tasks: ['T058'], fields: [
    memberField, auto('ownerPartyId', 'Owner party', 'memberId', 'partyId'),
    pick('accountId', 'Account', 'account', { memberFrom: 'memberId', nullable: true }),
    pick('documentId', 'Existing document (new version)', 'document', { memberFrom: 'memberId', optional: true }),
    text('documentType', 'Document type'), text('displayName', 'Display name'), text('retentionClass', 'Retention class'),
    { name: 'bytes', label: 'Document file', control: { type: 'file' }, required: true },
    text('mediaType', 'Media type', { optional: true }), int('pageCount', 'Page count', { optional: true, nullable: true }),
    text('source', 'Source', { optional: true }), text('sourceDigest', 'Source digest', { optional: true }),
  ] },
  { kind: 'document.annotation.update', title: 'Annotate document', section: 'documents', tasks: ['T093'], fields: [
    pick('documentVersionId', 'Document version', 'documentVersion', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    int('pageNumber', 'Page'), { name: 'regionMicros', label: 'Region', control: { type: 'annotationRegion' }, required: true },
    en('action', 'Action', ['create', 'amend', 'remove']),
    pick('annotationId', 'Existing annotation', 'annotation', { scopeFrom: 'documentVersionId', optional: true, when: { field: 'action', oneOf: ['amend', 'remove'] } }),
    { ...auto('expectedAnnotationFingerprint', 'Annotation fingerprint', 'annotationId', 'fingerprint'), when: { field: 'action', oneOf: ['amend', 'remove'] } },
    text('text', 'Annotation text', { optional: true }),
  ] },
  { kind: 'document.metadata.update', title: 'Update document metadata', section: 'documents', tasks: ['T094'], fields: [
    pick('documentId', 'Document', 'document', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    { name: 'expectedMetadata', label: 'Reviewed metadata', control: { type: 'expectedMetadata' }, required: true,
      auto: { from: 'documentId', property: 'expectedMetadata' } },
    text('documentType', 'Document type'), text('displayName', 'Display name'),
    auto('ownerPartyId', 'Owner party', 'documentId', 'ownerPartyId'),
    pick('accountId', 'Account', 'account', { memberFrom: 'memberId', nullable: true }), text('retentionClass', 'Retention class'),
    pick('approvalId', 'Approval', 'approval', { optional: true }),
  ] },
  { kind: 'document.bundle.redact', title: 'Create redacted bundle', section: 'documents', tasks: ['T059'], fields: [
    memberField, picks('sourceVersionIds', 'Source versions', 'documentVersion', { memberFrom: 'memberId' }),
    text('recipientPurpose', 'Recipient purpose'), pick('redactionPolicyVersionId', 'Redaction policy', 'policyVersion'),
    { name: 'approvedExcerpts', label: 'Approved excerpts', control: { type: 'excerpts' }, required: true },
    text('displayName', 'Display name', { optional: true }),
  ] },
  { kind: 'document.signature.collect', title: 'Collect signature', section: 'documents', tasks: ['T060'], fields: [
    en('action', 'Action', ['request', 'sign', 'decline', 'expire']),
    pick('documentVersionId', 'Document version', 'documentVersion', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('signerPartyIds', 'Signer parties', 'documentVersionId', 'ownerPartyIds'),
    text('channel', 'Channel'), text('evidenceReference', 'Evidence reference', { optional: true }),
  ] },
  { kind: 'document.customer_export.create', title: 'Create customer export', section: 'documents', tasks: ['T063'], gated: true, fields: [
    memberField, strings('categories', 'Categories'), date('from', 'From', { nullable: true }), date('through', 'Through', { nullable: true }),
    text('destination', 'Destination'), picks('documentVersionIds', 'Included documents', 'documentVersion', { memberFrom: 'memberId' }),
  ] },
  { kind: 'document.retention_hold.apply', title: 'Apply retention hold', section: 'documents', tasks: ['T064'], gated: true, fields: [
    pick('documentId', 'Document', 'document', { memberFrom: 'memberId', optional: true }), pick('caseId', 'Case', 'case', { memberFrom: 'memberId', optional: true }),
    pick('memberId', 'Member', 'member', { optional: true }), text('reason', 'Reason'), instant('reviewAt', 'Review at'),
  ] },
  { kind: 'consent.delivery.record', title: 'Record consent delivery', section: 'documents', tasks: ['T061'], fields: [
    memberField, auto('partyId', 'Party', 'memberId', 'partyId'),
    pick('accountId', 'Account', 'account', { memberFrom: 'memberId', nullable: true }),
    text('purpose', 'Purpose'), text('channel', 'Channel'),
    pick('disclosureVersionId', 'Disclosure version', 'documentVersion', { memberFrom: 'memberId' }), area('evidence', 'Evidence'),
  ] },
  { kind: 'consent.withdraw', title: 'Withdraw consent', section: 'documents', tasks: ['T062'], fields: [
    pick('consentId', 'Consent', 'consent', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    instant('effectiveAt', 'Effective at', { optional: true }), strings('affectedChannels', 'Affected channels'),
  ] },

  // Maintenance & communications
  { kind: 'maintenance.address.reconcile', title: 'Reconcile member address', section: 'servicing', tasks: ['T069'], gated: true, fields: [
    memberField, memberVersionAs('expectedMemberVersion', 'memberId'),
    pick('conflictingAddressId', 'Conflicting address', 'partyAddress', { memberFrom: 'memberId' }),
    pick('winningEvidenceVersionId', 'Winning evidence version', 'documentVersion', { memberFrom: 'memberId' }),
    auto('winningEvidenceDigest', 'Evidence digest', 'winningEvidenceVersionId', 'digest'),
    text('precedence', 'Precedence'), address('address'),
  ] },
  { kind: 'maintenance.address.destination.update', title: 'Update address destination', section: 'servicing', tasks: ['T069'], gated: true, fields: [
    memberField, en('context', 'Delivery context', ['member-mailing', 'account-statement', 'card-shipping', 'loan-notice']),
    pick('targetId', 'Target (member/account/card/loan)', 'destinationTarget', {}),
    pick('addressId', 'Address', 'partyAddress', { memberFrom: 'memberId' }),
    pick('evidenceVersionId', 'Evidence version', 'documentVersion', { memberFrom: 'memberId' }), date('effectiveDate', 'Effective date'),
    pick('expectedCurrentDestinationId', 'Current destination', 'addressDestination', { memberFrom: 'memberId', nullable: true }),
    pick('consentId', 'Consent', 'consent', { memberFrom: 'memberId', nullable: true }),
  ] },
  { kind: 'maintenance.draft.save', title: 'Save maintenance draft', section: 'servicing', tasks: ['T085'], fields: [
    memberField, pick('accountId', 'Account', 'account', { memberFrom: 'memberId', nullable: true }),
    pick('requestId', 'Existing request', 'maintenanceRequest', { memberFrom: 'memberId', optional: true }), text('requestNumber', 'Request number', { optional: true }),
    text('category', 'Category'), text('subject', 'Subject'),
    { name: 'requestedCommand', label: 'Requested command', control: { type: 'requestedCommand' }, required: true },
    strings('missingFields', 'Missing fields'), text('note', 'Note', { optional: true }),
    picks('evidenceDocumentVersionIds', 'Evidence documents', 'documentVersion', { memberFrom: 'memberId', optional: true }),
  ] },
  { kind: 'maintenance.draft.amend', title: 'Amend maintenance draft', section: 'servicing', tasks: ['T086'], fields: [
    pick('requestId', 'Request', 'maintenanceRequest', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedUpdatedAt', 'Request updated at', 'requestId', 'updatedAt'),
    { name: 'patch', label: 'Patch', control: { type: 'patch' }, required: true },
  ] },
  { kind: 'maintenance.request.submit', title: 'Submit maintenance request', section: 'servicing', tasks: ['T087'], fields: [
    pick('requestId', 'Request', 'maintenanceRequest', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedUpdatedAt', 'Request updated at', 'requestId', 'updatedAt'),
    en('declaredState', 'Declared state', ['submitted']),
  ] },
  { kind: 'maintenance.request.withdraw', title: 'Withdraw maintenance request', section: 'servicing', tasks: ['T088'], fields: [
    pick('requestId', 'Request', 'maintenanceRequest', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedUpdatedAt', 'Request updated at', 'requestId', 'updatedAt'), text('reason', 'Reason'),
  ] },
  { kind: 'maintenance.request.review', title: 'Review maintenance request', section: 'servicing', tasks: ['T087'], fields: [
    pick('requestId', 'Request', 'maintenanceRequest', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedUpdatedAt', 'Request updated at', 'requestId', 'updatedAt'),
    en('decision', 'Decision', ['approve', 'reject', 'return-for-information']), text('reason', 'Reason'), strings('missingFields', 'Missing fields', { optional: true }),
  ] },
  { kind: 'maintenance.request.process', title: 'Process maintenance request', section: 'servicing', tasks: ['T087'], fields: [
    pick('requestId', 'Request', 'maintenanceRequest', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedUpdatedAt', 'Request updated at', 'requestId', 'updatedAt'),
    en('disposition', 'Disposition', ['apply', 'reject']), text('reason', 'Reason'), text('appliedReceiptId', 'Applied receipt', { optional: true }),
  ] },
  { kind: 'communication.preference.update', title: 'Update communication preference', section: 'servicing', tasks: ['T095'], fields: [
    memberField, auto('partyId', 'Party', 'memberId', 'partyId'), text('purpose', 'Purpose'), text('channel', 'Channel'),
    en('state', 'State', ['enabled', 'disabled']),
  ] },
  { kind: 'communication.send', title: 'Send communication', section: 'servicing', tasks: ['T096'], fields: [
    memberField, auto('partyId', 'Party', 'memberId', 'partyId'),
    en('channel', 'Channel', ['email', 'mail']),
    text('destination', 'Email destination', { optional: true, when: { field: 'channel', oneOf: ['email'] } }),
    pick('addressDestinationId', 'Mail destination', 'addressDestination', { memberFrom: 'memberId', optional: true, when: { field: 'channel', oneOf: ['mail'] } }),
    text('purpose', 'Purpose'), pick('documentVersionId', 'Document version', 'documentVersion', { memberFrom: 'memberId' }),
    pick('jobId', 'Existing job', 'communicationJob', { memberFrom: 'memberId', optional: true }),
  ] },
  { kind: 'communication.delivery.update', title: 'Update delivery state', section: 'servicing', tasks: ['T096'], fields: [
    pick('jobId', 'Communication job', 'communicationJob', { memberFrom: 'memberId' }), pick('memberId', 'Member', 'member', { optional: true }),
    auto('expectedState', 'Expected state', 'jobId', 'state'), en('action', 'Action', ['accept', 'deliver', 'bounce', 'cancel']), text('detail', 'Detail'),
  ] },

  // Reconciliation
  { kind: 'reconciliation.suspense.investigate', title: 'Investigate suspense item', section: 'reconciliation', tasks: ['T075'], fields: [
    pick('suspenseId', 'Suspense item', 'suspenseItem'), auto('expectedFingerprint', 'Suspense fingerprint', 'suspenseId', 'fingerprint', 'suspense-item'),
    strings('evidenceReferences', 'Evidence references'), pick('proposedAccountId', 'Proposed account', 'account', { nullable: true }),
  ] },
  { kind: 'reconciliation.suspense.clear', title: 'Clear suspense item', section: 'reconciliation', tasks: ['T076'], gated: true, fields: [
    pick('suspenseId', 'Suspense item', 'suspenseItem'), auto('expectedFingerprint', 'Suspense fingerprint', 'suspenseId', 'fingerprint', 'suspense-item'),
    pick('destinationAccountId', 'Destination account', 'account'), money('amount', 'Amount'), text('evidenceReference', 'Evidence reference'),
  ] },
  { kind: 'batch.import', title: 'Import batch', section: 'reconciliation', tasks: ['T077'], fields: [
    pick('documentVersionId', 'Batch file version', 'documentVersion'), auto('inputDigest', 'File digest', 'documentVersionId', 'digest'),
    text('batchNumber', 'Batch number'), en('batchKind', 'Batch kind', ['contact-update', 'fee-refund']), text('currency', 'Currency', { nullable: true }),
  ] },
  { kind: 'batch.contacts.apply', title: 'Apply contact batch item', section: 'reconciliation', tasks: ['T078'], gated: true, fields: [
    pick('batchId', 'Batch', 'batch'), pick('itemId', 'Item', 'batchItem', { scopeFrom: 'batchId' }),
    auto('expectedFingerprint', 'Batch fingerprint', 'batchId', 'fingerprint', 'batch'),
    en('conflictPolicy', 'Conflict policy', ['skip-stale', 'reject-all']),
  ] },
  { kind: 'batch.fee_refunds.apply', title: 'Apply fee refund batch item', section: 'reconciliation', tasks: ['T079'], gated: true, fields: [
    pick('batchId', 'Batch', 'batch'), pick('itemId', 'Item', 'batchItem', { scopeFrom: 'batchId' }),
    auto('expectedFingerprint', 'Batch fingerprint', 'batchId', 'fingerprint', 'batch'),
  ] },

  // Saved searches & approvals
  { kind: 'search.saved.create', title: 'Save search', section: 'search', tasks: ['T092'], fields: [
    text('name', 'Name'), en('visibility', 'Visibility', ['private', 'shared']),
    { name: 'definition', label: 'Definition', control: { type: 'definition' }, required: true },
  ] },
  { kind: 'search.saved.update', title: 'Update saved search', section: 'search', tasks: ['T092'], fields: [
    pick('searchId', 'Saved search', 'savedSearch'), auto('expectedRevision', 'Revision', 'searchId', 'revision'),
    text('name', 'Name', { optional: true }), en('visibility', 'Visibility', ['private', 'shared'], { optional: true }),
    { name: 'definition', label: 'Definition', control: { type: 'definition' }, optional: true },
  ] },
  { kind: 'search.saved.delete', title: 'Delete saved search', section: 'search', tasks: ['T092'], fields: [
    pick('searchId', 'Saved search', 'savedSearch'), auto('expectedRevision', 'Revision', 'searchId', 'revision'),
  ] },
  { kind: 'approval.decide', title: 'Decide approval', section: 'servicing', tasks: ['T042'], fields: [
    pick('approvalId', 'Approval', 'approval'), auto('expectedFingerprint', 'Approval fingerprint', 'approvalId', 'fingerprint'),
    en('decision', 'Decision', ['approve', 'deny']), text('reason', 'Reason'),
  ] },
];

export const OPERATIONS_BY_KIND = new Map(OPERATIONS.map((operation) => [operation.kind, operation]));

export const SECTION_LABELS: Record<Section, string> = {
  member: 'Members', account: 'Accounts', money: 'Teller & corrections', payments: 'Payments & beneficiaries',
  cards: 'Cards & disputes', loans: 'Loans', documents: 'Documents', cases: 'Cases', servicing: 'Servicing & maintenance',
  reconciliation: 'Reconciliation', search: 'Searches',
};

export const SECTION_ORDER: readonly Section[] = ['member', 'account', 'money', 'payments', 'cards', 'loans', 'documents', 'cases', 'servicing', 'reconciliation', 'search'];
