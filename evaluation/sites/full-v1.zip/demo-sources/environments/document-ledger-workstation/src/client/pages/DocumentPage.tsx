import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { download, getJson, institutionPath } from '../api.js';
import { DocumentCanvas, type DocumentAnnotation } from '../canvas/DocumentCanvas.js';
import type { PageRect } from '../model/document.js';
import type { DocumentLayout } from '../../shared/api.js';
import type { WorkContext } from '../App.js';

interface DocumentDetail {
  document: {
    versionId: string; documentId: string; documentType: string; displayName: string; version: number;
    mediaType: string; digest: string; byteLength: number; status: string; pageCount: number | null;
    accountId: string | null; ownerPartyId: string | null; issuedAt: string | null; periodStart: string | null; periodEnd: string | null;
  };
  annotations: { annotationId: string; pageNumber: number; region: { x: number; y: number; width: number; height: number }; status: string; text: string; fingerprint: string }[];
  signatures: { signatureId: string; state: string; signerPartyId: string; channel: string }[];
}

const DOC_OPS = ['document.metadata.update', 'document.signature.collect', 'document.bundle.redact', 'document.retention_hold.apply'] as const;

/** Document page: immutable-version metadata + the canvas viewer + annotation workflow. */
export function DocumentPage({ versionId, context }: { versionId: string; context: WorkContext }): ReactNode {
  const [detail, setDetail] = useState<DocumentDetail | null>(null);
  const [layout, setLayout] = useState<DocumentLayout | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      const [doc, docLayout] = await Promise.all([
        getJson<DocumentDetail>(`${base}/documents/${encodeURIComponent(versionId)}`),
        getJson<DocumentLayout>(`${base}/documents/${encodeURIComponent(versionId)}/layout`),
      ]);
      setDetail(doc);
      setLayout(docLayout);
      setError(null);
      context.reportFocus({ area: 'document', document: `${doc.document.displayName} v${doc.document.version}` });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    }
  }, [base, versionId, context.refreshKey]);

  useEffect(() => { void load(); }, [load]);

  const onRegionSelect = useCallback((region: PageRect) => {
    if (detail === null) return;
    const page = layout?.pages.find((candidate) => candidate.pageNumber === region.pageNumber);
    if (page === undefined || page.width === 0 || page.height === 0) { context.message('This page has no positioned text layer to annotate.'); return; }
    const micros = {
      x: Math.max(0, Math.min(999_999, Math.round((region.x / page.width) * 1_000_000))),
      y: Math.max(0, Math.min(999_999, Math.round((region.y / page.height) * 1_000_000))),
      width: Math.max(1, Math.min(1_000_000, Math.round((region.width / page.width) * 1_000_000))),
      height: Math.max(1, Math.min(1_000_000, Math.round((region.height / page.height) * 1_000_000))),
    };
    context.openOperation('document.annotation.update', { documentVersionId: versionId, pageNumber: region.pageNumber, regionMicros: micros, action: 'create' });
  }, [detail, layout, context, versionId]);

  const onAnnotationSelect = useCallback((annotation: DocumentAnnotation) => {
    context.openOperation('document.annotation.update', {
      documentVersionId: versionId, pageNumber: annotation.pageNumber,
      regionMicros: { x: Math.round(annotation.region.x * 1_000_000), y: Math.round(annotation.region.y * 1_000_000), width: Math.round(annotation.region.width * 1_000_000), height: Math.round(annotation.region.height * 1_000_000) },
      annotationId: annotation.annotationId, expectedAnnotationFingerprint: annotation.fingerprint ?? '', action: 'amend',
    });
  }, [context, versionId]);

  if (error !== null) return <p className="form-error" role="alert">{error}</p>;
  if (detail === null || layout === null) return <p className="muted">Loading document…</p>;
  const doc = detail.document;
  const isStatement = doc.documentType === 'account-statement' && doc.accountId !== null && doc.periodStart !== null && doc.periodEnd !== null;
  const period = doc.periodStart?.slice(0, 7) ?? '';

  return (
    <section className="document-page">
      <header className="record-header">
        <h2>{doc.displayName} <span className="muted">v{doc.version} · {doc.documentType}</span></h2>
        <dl className="record-facts">
          <dt>Status</dt><dd>{doc.status}</dd>
          <dt>Media</dt><dd>{doc.mediaType}</dd>
          <dt>Bytes</dt><dd>{doc.byteLength}</dd>
          <dt>Digest</dt><dd className="mono">{doc.digest.slice(0, 20)}…</dd>
          <dt>Pages</dt><dd>{doc.pageCount ?? layout.pages.length}</dd>
        </dl>
        <div className="record-ops">
          <button type="button" className="tool-button" onClick={() => void download(`${base}/documents/${encodeURIComponent(versionId)}/content`)}>Download bytes</button>
          {isStatement && doc.accountId !== null ? (
            <>
              <button type="button" className="tool-button" onClick={() => void download(`${base}/accounts/${encodeURIComponent(doc.accountId ?? '')}/statement.pdf?period=${period}`)}>PDF</button>
              <button type="button" className="tool-button" onClick={() => void download(`${base}/accounts/${encodeURIComponent(doc.accountId ?? '')}/statement.csv?period=${period}`)}>CSV</button>
              <button type="button" className="tool-button" onClick={() => void download(`${base}/accounts/${encodeURIComponent(doc.accountId ?? '')}/statement.html?period=${period}`)}>HTML</button>
            </>
          ) : null}
          {DOC_OPS.map((kind) => (
            <button key={kind} type="button" className="tool-button" onClick={() => context.openOperation(kind, { documentId: doc.documentId, memberId: undefined, documentVersionId: versionId })}>{kind}</button>
          ))}
        </div>
        <div className="zoom-bar">
          <button type="button" className="tool-button" onClick={() => setZoom((value) => Math.max(0.25, value / 1.25))}>−</button>
          <span className="muted">{Math.round(zoom * 100)}%</span>
          <button type="button" className="tool-button" onClick={() => setZoom((value) => Math.min(4, value * 1.25))}>+</button>
        </div>
      </header>
      <DocumentCanvas
        layout={layout}
        contentUrl={`${base}/documents/${encodeURIComponent(versionId)}/content`}
        mediaType={doc.mediaType}
        annotations={detail.annotations.filter((annotation) => annotation.status !== 'removed')}
        zoom={zoom}
        onZoomChange={setZoom}
        data-testid="document-canvas"
        onPageChange={(page, total) => context.reportFocus({ area: 'document', document: `${doc.displayName} v${doc.version}`, page: `${page}/${total}` })}
        onWordSelect={(hit) => context.reportFocus({ area: 'document', document: `${doc.displayName} v${doc.version}`, cell: hit === null ? undefined : `"${hit.text}" @p${hit.pageNumber}` })}
        onRegionSelect={onRegionSelect}
        onAnnotationSelect={onAnnotationSelect}
      />
      <section className="annotation-list">
        <h3>Annotations ({detail.annotations.filter((annotation) => annotation.status !== 'removed').length})</h3>
        <ul>
          {detail.annotations.filter((annotation) => annotation.status !== 'removed').map((annotation) => (
            <li key={annotation.annotationId}>
              <button type="button" className="link" onClick={() => onAnnotationSelect(annotation)}>
                p{annotation.pageNumber} — {annotation.text}
              </button>
            </li>
          ))}
        </ul>
      </section>
      {detail.signatures.length > 0 ? (
        <section>
          <h3>Signatures</h3>
          <ul>{detail.signatures.map((signature) => <li key={signature.signatureId}>{signature.signerPartyId} — {signature.state} via {signature.channel}</li>)}</ul>
        </section>
      ) : null}
    </section>
  );
}
