import type { CommandOutcome, ReviewOutcome, ServiceCommand } from '@computer-use/financial-database/services';

import type { ApiErrorBody } from '../shared/api.js';

export class ApiError extends Error {
  constructor(readonly status: number, readonly code: string, message: string, readonly field?: string) { super(message); }
}

/** A request whose outcome is unknown because no response arrived. */
export function isNetworkFailure(error: unknown): boolean {
  return error instanceof ApiError && error.status === 0;
}

async function send(path: string, init: RequestInit): Promise<Response> {
  let response: Response;
  try {
    response = await fetch(path, { ...init, credentials: 'same-origin', headers: { accept: 'application/json', ...(init.body === undefined ? {} : { 'content-type': 'application/json' }) } });
  } catch (error) {
    if (init.signal?.aborted === true) throw error;
    throw new ApiError(0, 'network', 'The workspace backend could not be reached. Nothing was lost; retry when the connection returns.');
  }
  if (!response.ok) {
    let body: ApiErrorBody | undefined;
    try { body = await response.json() as ApiErrorBody; } catch { body = undefined; }
    throw new ApiError(response.status, body?.error.code ?? `http_${String(response.status)}`, body?.error.message ?? `The request failed with status ${String(response.status)}.`, body?.error.field);
  }
  return response;
}

export async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  return await (await send(path, signal === undefined ? {} : { signal })).json() as T;
}

export async function sendJson<T>(method: 'POST' | 'PUT' | 'DELETE', path: string, body?: unknown): Promise<T> {
  return await (await send(path, { method, ...(body === undefined ? {} : { body: JSON.stringify(body) }) })).json() as T;
}

/** Path below one bound institution. The backend maps it to its trusted dataset. */
export function institutionPath(institutionId: string, path: string): string {
  return `/api/i/${encodeURIComponent(institutionId)}${path}`;
}

export function queryString(parameters: Readonly<Record<string, string | number | boolean | readonly string[] | null | undefined>>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(parameters)) {
    if (value === undefined || value === null || value === '' || value === false) continue;
    search.set(key, Array.isArray(value) ? value.join(',') : String(value));
  }
  const text = search.toString();
  return text === '' ? '' : `?${text}`;
}

export function reviewCommand(institutionId: string, command: ServiceCommand): Promise<{ outcome: ReviewOutcome }> {
  return sendJson<{ outcome: ReviewOutcome }>('POST', institutionPath(institutionId, '/commands/review'), { command });
}

/** Runs a command. Retrying with the same key returns the original receipt instead of repeating the effect. */
export function executeCommand(institutionId: string, command: ServiceCommand, idempotencyKey: string): Promise<{ outcome: CommandOutcome }> {
  return sendJson<{ outcome: CommandOutcome }>('POST', institutionPath(institutionId, '/commands'), { command, idempotencyKey });
}

export function newIdempotencyKey(kind: string): string {
  return `${kind}:${crypto.randomUUID()}`;
}

export interface DownloadResult {
  filename: string;
  digest: string | null;
  count: number | null;
}

/** Downloads a server-rendered file through a real browser download, reporting its name and digest. */
export async function download(path: string, init: { method?: 'GET' | 'POST'; body?: unknown } = {}): Promise<DownloadResult> {
  const response = await send(path, init.method === 'POST' ? { method: 'POST', body: JSON.stringify(init.body) } : {});
  const disposition = response.headers.get('content-disposition') ?? '';
  const filename = /filename="([^"]+)"/u.exec(disposition)?.[1] ?? 'download';
  const url = URL.createObjectURL(await response.blob());
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  const count = response.headers.get('x-export-count');
  return { filename, digest: response.headers.get('x-document-digest'), count: count === null ? null : Number(count) };
}
