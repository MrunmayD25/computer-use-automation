import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { getJson, institutionPath } from '../api.js';
import type { WorkContext } from '../App.js';

interface MemberDetail {
  member: {
    id: string; memberNumber: string; displayName: string; partyId: string; status: string; version: number;
    kind: string; email: string | null; phone: string | null; openedAt: string; mergedIntoId: string | null;
  };
  accounts?: { id: string; accountNumber: string; productName: string; currency: string; status: string }[];
  notes?: { id: string; visibility: string; text: string; createdAt: string }[];
  cases?: { id: string; caseNumber: string; state: string; summary: string }[];
}

const MEMBER_LISTS: { kind: string; label: string }[] = [
  { kind: 'member.beneficiaries', label: 'Beneficiaries' }, { kind: 'member.payments', label: 'Payments' },
  { kind: 'member.disputes', label: 'Disputes' }, { kind: 'member.loans', label: 'Loans' },
  { kind: 'member.loan_applications', label: 'Loan applications' }, { kind: 'member.payment_returns', label: 'Payment returns' },
  { kind: 'member.received_funds', label: 'Received funds' }, { kind: 'member.name_history', label: 'Name history' },
  { kind: 'member.tax_history', label: 'Tax history' }, { kind: 'member.beneficial_owners', label: 'Beneficial owners' },
  { kind: 'merge.plans', label: 'Merge plans' },
];

const MEMBER_OPS = [
  'contact.update', 'member.note.add', 'member.identity_evidence.register', 'member.identity.verify',
  'member.legal_name.update', 'member.preferred_name.update', 'member.tax_classification.update',
  'member.beneficial_owners.update', 'member.deceased.record', 'member.merge',
  'account.open', 'case.open', 'beneficiary.create', 'loan.application.prepare',
  'document.index', 'document.customer_export.create', 'consent.delivery.record',
  'maintenance.address.reconcile', 'maintenance.address.destination.update', 'maintenance.draft.save',
  'communication.preference.update', 'communication.send',
] as const;

/** Member record page: detail, related accounts/cases/notes, scoped lists and member operations. */
export function MemberPage({ memberId, context }: { memberId: string; context: WorkContext }): ReactNode {
  const [detail, setDetail] = useState<MemberDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      setDetail(await getJson<MemberDetail>(`${base}/members/${encodeURIComponent(memberId)}`));
      setError(null);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    }
  }, [base, memberId]);

  useEffect(() => { void load(); }, [load, context.refreshKey]);

  useEffect(() => {
    if (detail !== null) context.reportFocus({ area: 'member', record: detail.member.memberNumber });
  }, [detail, context]);

  if (error !== null) return <p className="form-error" role="alert">{error}</p>;
  if (detail === null) return <p className="muted">Loading member…</p>;
  const member = detail.member;

  return (
    <section className="member-page">
      <header className="record-header">
        <h2>{member.memberNumber} — {member.displayName}</h2>
        <dl className="record-facts">
          <dt>Status</dt><dd>{member.status}</dd>
          <dt>Kind</dt><dd>{member.kind}</dd>
          <dt>Version</dt><dd>{member.version}</dd>
          <dt>Email</dt><dd>{member.email ?? '—'}</dd>
          <dt>Phone</dt><dd>{member.phone ?? '—'}</dd>
          {member.mergedIntoId !== null ? <><dt>Merged into</dt><dd>{member.mergedIntoId}</dd></> : null}
        </dl>
        <div className="record-ops">
          {MEMBER_OPS.map((kind) => (
            <button key={kind} type="button" className="tool-button" onClick={() => context.openOperation(kind, { memberId })}>{kind}</button>
          ))}
        </div>
      </header>
      <div className="member-columns">
        <section>
          <h3>Accounts</h3>
          <ul className="link-list">
            {(detail.accounts ?? []).map((account) => (
              <li key={account.id}>
                <button type="button" className="link" onClick={() => context.openTab({ kind: 'account', title: account.accountNumber, params: { id: account.id } })}>
                  {account.accountNumber} — {account.productName} ({account.currency} {account.status})
                </button>
              </li>
            ))}
          </ul>
          <h3>Cases</h3>
          <ul className="link-list">
            {(detail.cases ?? []).map((entry) => (
              <li key={entry.id}>
                <button type="button" className="link" onClick={() => context.openTab({ kind: 'case', title: entry.caseNumber, params: { id: entry.id } })}>
                  {entry.caseNumber} — {entry.summary} ({entry.state})
                </button>
              </li>
            ))}
          </ul>
        </section>
        <section>
          <h3>Record lists</h3>
          <ul className="link-list">
            {MEMBER_LISTS.map((list) => (
              <li key={list.kind}>
                <button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `${list.label} — ${member.memberNumber}`, params: { listKind: list.kind, memberId } })}>
                  {list.label}
                </button>
              </li>
            ))}
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Documents — ${member.memberNumber}`, params: { listKind: 'member.document-versions', memberId } })}>Documents</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Evidence — ${member.memberNumber}`, params: { listKind: 'member.evidence', memberId } })}>Identity evidence</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Consents — ${member.memberNumber}`, params: { listKind: 'member.consents', memberId } })}>Consents</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Addresses — ${member.memberNumber}`, params: { listKind: 'member.addresses', memberId } })}>Addresses</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Destinations — ${member.memberNumber}`, params: { listKind: 'member.destinations', memberId } })}>Address destinations</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Retention holds — ${member.memberNumber}`, params: { listKind: 'member.retention-holds', memberId } })}>Retention holds</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Preferences — ${member.memberNumber}`, params: { listKind: 'member.preferences', memberId } })}>Communication preferences</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'maintenance', title: `Maintenance — ${member.memberNumber}`, params: { id: memberId } })}>Maintenance requests</button></li>
            <li><button type="button" className="link" onClick={() => context.openTab({ kind: 'list', title: `Communications — ${member.memberNumber}`, params: { listKind: 'member.communication-jobs', memberId } })}>Communication jobs</button></li>
          </ul>
        </section>
        <section>
          <h3>Notes</h3>
          <ul className="notes">
            {(detail.notes ?? []).map((note) => <li key={note.id} className={`note ${note.visibility}`}>[{note.visibility}] {note.text}</li>)}
          </ul>
        </section>
      </div>
    </section>
  );
}
