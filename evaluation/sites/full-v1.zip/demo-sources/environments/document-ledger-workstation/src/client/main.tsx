import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import { App } from './App.js';
import { getJson } from './api.js';
import type { SessionInfo } from '../shared/api.js';
import './styles.css';

async function start(): Promise<void> {
  const session = await getJson<SessionInfo>('/api/session');
  const root = document.getElementById('root');
  if (root === null) throw new Error('Missing #root.');
  createRoot(root).render(
    <StrictMode>
      <App initialSession={session} />
    </StrictMode>,
  );
}

void start().catch((error: unknown) => {
  document.body.textContent = `Failed to start: ${error instanceof Error ? error.message : String(error)}`;
});
