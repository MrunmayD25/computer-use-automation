import { getJson, institutionPath, queryString } from '../api.js';
import type { PickerSource } from './catalog.js';

/** Picker data sources: every option is a real scoped record, never a typed-in identifier. */

export interface PickerOption {
  id: string;
  label: string;
  detail?: unknown;
  /** Raw row fields — `fields` for scoped lists, full objects for detail endpoints. */
  record?: Record<string, unknown>;
}

export interface PickerScope {
  memberId?: string | undefined;
  accountId?: string | undefined;
  /** Value of the field named by scopeFrom (beneficiaryId, scheduleId, cardId, loanId, batchId, versionId). */
  scopeId?: string | undefined;
  /** Current field values, for sources that dispatch on another field (destinationTarget). */
  values: Record<string, unknown>;
  query?: string | undefined;
  commandKind?: string | undefined;
}

interface ListRow { id: string; label: string; fields: Record<string, string | number | null> }
interface ListPage { columns: string[]; rows: ListRow[]; total: number; truncated: boolean }
interface ListResponse { kind: string; page: ListPage }

const list = async (base: string, kind: string, params: Record<string, string | number | undefined>): Promise<PickerOption[]> => {
  const page = (await getJson<ListResponse>(`${base}/lists${queryString({ kind, ...params })}`)).page;
  return page.rows.map((row) => ({ id: row.id, label: row.label, detail: row.fields, record: row.fields }));
};

const MEMBER_SCOPED = new Set<PickerSource>([
  'document', 'documentVersion', 'evidence', 'consent', 'partyAddress', 'addressDestination',
  'maintenanceRequest', 'communicationJob',
]);

/** Whether the source must be narrowed by a member before options load. */
export function needsMember(source: PickerSource): boolean {
  return MEMBER_SCOPED.has(source);
}

/** Scoped-list kinds keyed by which scope field they read. */
const LIST_SOURCES: Partial<Record<PickerSource, (scope: PickerScope) => { kind: string; params: Record<string, string | number | undefined> } | null>> = {
  beneficiary: (s) => s.memberId === undefined ? null : { kind: 'member.beneficiaries', params: { memberId: s.memberId } },
  beneficiaryRoute: (s) => s.scopeId === undefined ? null : { kind: 'beneficiary.routes', params: { beneficiaryId: s.scopeId } },
  payment: (s) => s.accountId !== undefined ? { kind: 'account.payments', params: { accountId: s.accountId } }
    : s.memberId !== undefined ? { kind: 'member.payments', params: { memberId: s.memberId } } : null,
  paymentSchedule: (s) => s.accountId === undefined ? null : { kind: 'account.schedules', params: { accountId: s.accountId } },
  occurrence: (s) => s.scopeId === undefined ? null : { kind: 'schedule.occurrences', params: { scheduleId: s.scopeId } },
  paymentReturn: (s) => s.accountId !== undefined ? { kind: 'account.payment_returns', params: { accountId: s.accountId } }
    : s.memberId !== undefined ? { kind: 'member.payment_returns', params: { memberId: s.memberId } } : null,
  card: (s) => s.accountId === undefined ? null : { kind: 'account.cards', params: { accountId: s.accountId } },
  cardTransaction: (s) => s.scopeId === undefined ? null : { kind: 'card.transactions', params: { cardId: s.scopeId } },
  dispute: (s) => s.accountId !== undefined ? { kind: 'account.disputes', params: { accountId: s.accountId } }
    : s.memberId !== undefined ? { kind: 'member.disputes', params: { memberId: s.memberId } } : null,
  loan: (s) => s.accountId !== undefined ? { kind: 'account.loans', params: { accountId: s.accountId } }
    : s.memberId !== undefined ? { kind: 'member.loans', params: { memberId: s.memberId } } : null,
  payoffQuote: (s) => s.scopeId === undefined ? null : { kind: 'loan.payoff_quotes', params: { loanId: s.scopeId } },
  interestCalculation: (s) => s.accountId === undefined ? null : { kind: 'account.interest_calculations', params: { accountId: s.accountId } },
  fee: (s) => s.accountId === undefined ? null : { kind: 'account.fees', params: { accountId: s.accountId } },
  feeWaiver: (s) => s.accountId === undefined ? null : { kind: 'account.fee_waivers', params: { accountId: s.accountId } },
  batch: () => ({ kind: 'batches', params: {} }),
  batchItem: (s) => s.scopeId === undefined ? null : { kind: 'batch.items', params: { batchId: s.scopeId } },
  suspenseItem: () => ({ kind: 'suspense.items', params: {} }),
  settlementBatch: () => ({ kind: 'settlement.batches', params: {} }),
  receivedFunds: (s) => s.memberId === undefined ? null : { kind: 'member.received_funds', params: { memberId: s.memberId } },
  mergePlan: (s) => ({ kind: 'merge.plans', params: { memberId: s.memberId } }),
  cashSession: () => ({ kind: 'cash.sessions', params: {} }),
  checker: (s) => s.commandKind === undefined ? null : { kind: 'approval.checkers', params: { commandKind: s.commandKind } },
};

export async function fetchOptions(institutionId: string, source: PickerSource, scope: PickerScope): Promise<PickerOption[]> {
  const base = institutionPath(institutionId, '');
  const listSource = LIST_SOURCES[source];
  if (listSource !== undefined) {
    const spec = listSource(scope);
    if (spec === null) return [];
    return list(base, spec.kind, spec.params);
  }
  switch (source) {
    case 'member': {
      const page = await getJson<{ items: { id: string; memberNumber: string; displayName: string; status: string }[] }>(`${base}/members${queryString({ query: scope.query, limit: 50 })}`);
      return page.items.map((row) => ({ id: row.id, label: `${row.memberNumber} — ${row.displayName}`, detail: row.status, record: row }));
    }
    case 'account': {
      const page = await getJson<{ items: { id: string; accountNumber: string; productName: string; currency: string; status: string; memberId: string }[] }>(
        `${base}/accounts${queryString({ query: scope.query, memberId: scope.memberId, limit: 50 })}`);
      return page.items.map((row) => ({ id: row.id, label: `${row.accountNumber} — ${row.productName}`, detail: `${row.currency} ${row.status}`, record: row }));
    }
    case 'case': {
      const page = await getJson<{ items: { id: string; caseNumber: string; state: string; summary: string; memberId: string }[] }>(
        `${base}/cases${queryString({ query: scope.query, memberId: scope.memberId, limit: 50 })}`);
      return page.items.map((row) => ({ id: row.id, label: `${row.caseNumber} — ${row.summary}`, detail: row.state, record: row }));
    }
    case 'queue': {
      const reference = await getJson<{ queues: { id: string; code: string; name: string }[] }>(`${base}/reference`);
      return reference.queues.map((row) => ({ id: row.id, label: `${row.code} — ${row.name}`, record: row }));
    }
    case 'actor': {
      const reference = await getJson<{ caseWorkers: { id: string; actorNumber: string; displayName: string }[] }>(`${base}/reference`);
      return reference.caseWorkers.map((row) => ({ id: row.id, label: `${row.actorNumber} — ${row.displayName}`, record: row }));
    }
    case 'policyVersion': {
      const rows = await getJson<{ policyVersionId: string; kind: string; effectiveFrom: string }[]>(`${base}/servicing/policy-versions`);
      return rows.map((row) => ({ id: row.policyVersionId, label: `${row.kind} ${row.effectiveFrom}`, record: row }));
    }
    case 'approval': {
      const page = await getJson<{ kind: string; approvals: { id: string; status: string; fingerprint: string; target: unknown; expiresAt: string }[] }>(`${base}/approvals`);
      if (page.kind !== 'found') return [];
      return page.approvals.map((row) => ({
        id: row.id, label: `${row.id.slice(0, 16)} — ${row.status}`, detail: row.expiresAt,
        record: { fingerprint: row.fingerprint, status: row.status, target: row.target, expiresAt: row.expiresAt },
      }));
    }
    case 'document': {
      if (scope.memberId !== undefined) {
        const versions = await getJson<{ versionId: string; documentId: string; displayName: string; documentType: string; version: number; status: string }[]>(
          `${base}/members/${encodeURIComponent(scope.memberId)}/document-versions`);
        const seen = new Map<string, PickerOption>();
        for (const row of versions) if (!seen.has(row.documentId)) seen.set(row.documentId, { id: row.documentId, label: `${row.displayName} (${row.documentType})`, detail: `v${row.version} ${row.status}`, record: row });
        return [...seen.values()];
      }
      const page = await getJson<{ items: { documentId: string; displayName: string; documentType: string; version: number; status: string }[] }>(`${base}/documents${queryString({ query: scope.query, limit: 50 })}`);
      const seen = new Map<string, PickerOption>();
      for (const row of page.items) if (!seen.has(row.documentId)) seen.set(row.documentId, { id: row.documentId, label: `${row.displayName} (${row.documentType})`, detail: `v${row.version} ${row.status}`, record: row });
      return [...seen.values()];
    }
    case 'documentVersion': {
      if (scope.memberId !== undefined) {
        const versions = await getJson<{ versionId: string; documentId: string; displayName: string; documentType: string; version: number; status: string; digest: string }[]>(
          `${base}/members/${encodeURIComponent(scope.memberId)}/document-versions`);
        return versions.map((row) => ({ id: row.versionId, label: `${row.displayName} v${row.version}`, detail: `${row.documentType} ${row.status}`, record: { ...row, digest: row.digest } }));
      }
      const page = await getJson<{ items: { versionId: string; displayName: string; documentType: string; version: number; status: string; digest: string }[] }>(`${base}/documents${queryString({ query: scope.query, limit: 50 })}`);
      return page.items.map((row) => ({ id: row.versionId, label: `${row.displayName} v${row.version}`, detail: `${row.documentType} ${row.status}`, record: row }));
    }
    case 'annotation': {
      if (scope.scopeId === undefined) return [];
      const detail = await getJson<{ annotations: { annotationId: string; pageNumber: number; status: string; text: string; fingerprint: string; region: Record<string, number> }[] }>(
        `${base}/documents/${encodeURIComponent(scope.scopeId)}`);
      return detail.annotations.filter((row) => row.status !== 'removed').map((row) => ({
        id: row.annotationId, label: `p${row.pageNumber} — ${row.text.slice(0, 60)}`, detail: row.status,
        record: row,
      }));
    }
    case 'evidence': {
      if (scope.memberId === undefined) return [];
      const rows = await getJson<{ evidenceId: string; kind: string; status: string; documentVersionId: string | null }[]>(`${base}/members/${encodeURIComponent(scope.memberId)}/evidence`);
      return rows.map((row) => ({ id: row.evidenceId, label: `${row.kind} — ${row.evidenceId}`, detail: row.status, record: row }));
    }
    case 'consent': {
      if (scope.memberId === undefined) return [];
      const rows = await getJson<{ consentId: string; purpose: string; channel: string; state: string }[]>(`${base}/members/${encodeURIComponent(scope.memberId)}/consents`);
      return rows.map((row) => ({ id: row.consentId, label: `${row.purpose} via ${row.channel}`, detail: row.state, record: row }));
    }
    case 'partyAddress': {
      if (scope.memberId === undefined) return [];
      const rows = await getJson<{ partyAddressId: string; purpose: string; line1: string; city: string; validTo: string | null }[]>(`${base}/members/${encodeURIComponent(scope.memberId)}/addresses`);
      return rows.map((row) => ({ id: row.partyAddressId, label: `${row.line1}, ${row.city}`, detail: `${row.purpose}${row.validTo === null ? '' : ' (ended)'}`, record: row }));
    }
    case 'addressDestination': {
      if (scope.memberId === undefined) return [];
      const rows = await getJson<{ destinationId: string; context: string; addressId: string }[]>(`${base}/members/${encodeURIComponent(scope.memberId)}/destinations`);
      return rows.map((row) => ({ id: row.destinationId, label: `${row.context} → ${row.addressId}`, record: row }));
    }
    case 'maintenanceRequest': {
      if (scope.memberId === undefined) return [];
      const rows = await getJson<{ requestId: string; requestNumber: string; state: string; subject: string; updatedAt: string }[]>(`${base}/members/${encodeURIComponent(scope.memberId)}/maintenance-requests`);
      return rows.map((row) => ({ id: row.requestId, label: `${row.requestNumber} — ${row.subject}`, detail: row.state, record: { ...row, requestId: row.requestId } }));
    }
    case 'communicationJob': {
      if (scope.memberId === undefined) return [];
      const rows = await getJson<{ jobId: string; channel: string; purpose: string; state: string }[]>(`${base}/members/${encodeURIComponent(scope.memberId)}/communication-jobs`);
      return rows.map((row) => ({ id: row.jobId, label: `${row.channel} — ${row.purpose}`, detail: row.state, record: row }));
    }
    case 'hold': case 'restriction': case 'facility': case 'maturityInstruction': {
      if (scope.accountId === undefined) return [];
      const detail = await getJson<{ holds?: { id: string; status: string; reason: string }[]; restrictions?: { id: string; kind: string; status: string }[]; facilities?: { id: string; kind: string; status: string }[]; maturityInstructions?: { id: string; state: string; cutoffAt: string }[] }>(
        `${base}/accounts/${encodeURIComponent(scope.accountId)}`);
      if (source === 'hold') return (detail.holds ?? []).map((row) => ({ id: row.id, label: `${row.id} — ${row.reason}`, detail: row.status, record: row }));
      if (source === 'restriction') return (detail.restrictions ?? []).map((row) => ({ id: row.id, label: row.kind, detail: row.status, record: row }));
      if (source === 'facility') return (detail.facilities ?? []).map((row) => ({ id: row.id, label: row.kind, detail: row.status, record: row }));
      return (detail.maturityInstructions ?? []).map((row) => ({ id: row.id, label: `${row.state} ${row.cutoffAt}`, record: row }));
    }
    case 'journal': case 'transferJournal': {
      if (scope.accountId === undefined) return [];
      const page = await getJson<{ items: { journalId: string; reference: string; description: string; postedAt: string; status: string }[] }>(
        `${base}/accounts/${encodeURIComponent(scope.accountId)}/transactions${queryString({ limit: 100 })}`);
      return page.items.map((row) => ({ id: row.journalId, label: `${row.reference} — ${row.description}`, detail: `${row.postedAt} ${row.status}`, record: row }));
    }
    case 'product': {
      const reference = await getJson<{ products: { id: string; code: string; name: string; currency: string }[] }>(`${base}/reference`);
      return reference.products.map((row) => ({ id: row.id, label: `${row.code} — ${row.name}`, detail: row.currency, record: row }));
    }
    case 'loanProduct': {
      const page = (await getJson<ListResponse>(`${base}/lists${queryString({ kind: 'products' })}`)).page;
      return page.rows.filter((row) => row.fields.family === 'loan').map((row) => ({ id: row.id, label: row.label, record: row.fields }));
    }
    case 'savedSearch': {
      const rows = await getJson<{ searches: { id: string; name: string; entity: string; visibility: string; revision: string }[] } | { id: string; name: string; entity: string; visibility: string; revision: string }[]>(`${base}/saved-searches`);
      const items = Array.isArray(rows) ? rows : rows.searches;
      return items.map((row) => ({ id: row.id, label: `${row.name} (${row.entity})`, detail: row.visibility, record: row }));
    }
    case 'statementPeriod': {
      if (scope.accountId === undefined) return [];
      const detail = await getJson<{ periods: { period: string }[] }>(`${base}/accounts/${encodeURIComponent(scope.accountId)}/statements`);
      return detail.periods.map((row) => ({ id: row.period, label: row.period, record: row }));
    }
    case 'calendarDay': {
      const today = new Date().toISOString().slice(0, 10);
      const from = new Date(Date.parse(`${today}T00:00:00Z`) - 45 * 86_400_000).toISOString().slice(0, 10);
      const through = new Date(Date.parse(`${today}T00:00:00Z`) + 45 * 86_400_000).toISOString().slice(0, 10);
      const page = (await getJson<ListResponse>(`${base}/lists${queryString({ kind: 'calendar.days', from, through })}`)).page;
      return page.rows.filter((row) => row.fields.isBusinessDay === 1 || row.fields.isBusinessDay === 'true').map((row) => ({ id: row.id, label: row.id, record: row.fields }));
    }
    case 'destinationTarget': {
      const context = typeof scope.values.context === 'string' ? scope.values.context : '';
      if (context === 'account-statement') return fetchOptions(institutionId, 'account', scope);
      if (context === 'card-shipping') return fetchOptions(institutionId, 'card', scope);
      if (context === 'loan-notice') return fetchOptions(institutionId, 'loan', scope);
      return fetchOptions(institutionId, 'member', scope);
    }
    default:
      return [];
  }
}

/** Maps a picker source to the finance record resource used for fingerprint reads. */
const FINGERPRINT_RESOURCE: Partial<Record<PickerSource, string>> = {
  beneficiary: 'beneficiary', beneficiaryRoute: 'beneficiary-route', payment: 'payment', paymentSchedule: 'payment-schedule',
  occurrence: 'schedule-occurrence', paymentReturn: 'payment-return', card: 'card', cardTransaction: 'card-transaction',
  dispute: 'dispute', loan: 'loan', payoffQuote: 'loan-closure', interestCalculation: 'interest-calculation', fee: 'fee',
  hold: 'hold', restriction: 'restriction', facility: 'facility', maturityInstruction: 'maturity-instruction',
  journal: 'transaction', transferJournal: 'transfer', batch: 'batch', suspenseItem: 'suspense-item',
  settlementBatch: 'settlement-batch', receivedFunds: 'received-funds',
};

/**
 * Fetches derived values for a picked record: versions, fingerprints, digests and scoped identities.
 * Every value comes from a live service read at pick time — nothing is remembered across submissions.
 */
export async function fetchAuto(institutionId: string, source: PickerSource, id: string, scope: PickerScope): Promise<Record<string, unknown>> {
  const base = institutionPath(institutionId, '');
  const resource = FINGERPRINT_RESOURCE[source];
  if (resource !== undefined) {
    const result = await getJson<{ kind: string; snapshot?: { fingerprint: string; record: Record<string, unknown> } }>(`${base}/finance/record/${encodeURIComponent(resource)}/${encodeURIComponent(id)}`);
    if (result.kind !== 'found' || result.snapshot === undefined) return {};
    const record = result.snapshot.record;
    return {
      fingerprint: result.snapshot.fingerprint,
      version: typeof record.version === 'number' ? record.version : undefined,
      paymentId: typeof record.payment_id === 'string' ? record.payment_id : typeof record.paymentId === 'string' ? record.paymentId : undefined,
      ...Object.fromEntries(Object.entries(record).filter(([, value]) => typeof value === 'string' || typeof value === 'number')),
    };
  }
  switch (source) {
    case 'member': {
      const detail = await getJson<{ member: { version: number; partyId: string } }>(`${base}/members/${encodeURIComponent(id)}`);
      return { version: detail.member.version, partyId: detail.member.partyId, memberId: id };
    }
    case 'account': {
      const detail = await getJson<{ account: { version: number; memberId: string; currency: string }; facilities?: { id: string }[]; maturityInstructions?: { id: string }[] }>(`${base}/accounts/${encodeURIComponent(id)}`);
      const facilityId = detail.facilities?.[0]?.id;
      const instructionId = detail.maturityInstructions?.[0]?.id;
      const out: Record<string, unknown> = { version: detail.account.version, memberId: detail.account.memberId, currency: detail.account.currency, accountId: id };
      if (facilityId !== undefined) {
        const facility = await fetchAuto(institutionId, 'facility', facilityId, scope);
        out.facilityFingerprint = facility.fingerprint;
      }
      if (instructionId !== undefined) {
        const instruction = await fetchAuto(institutionId, 'maturityInstruction', instructionId, scope);
        out.maturityInstructionFingerprint = instruction.fingerprint;
      }
      return out;
    }
    case 'case': {
      const detail = await getJson<{ case: { version: number; memberId: string; accountId: string | null } }>(`${base}/cases/${encodeURIComponent(id)}`);
      const member = await getJson<{ member: { partyId: string } }>(`${base}/members/${encodeURIComponent(detail.case.memberId)}`);
      return { version: detail.case.version, memberId: detail.case.memberId, accountId: detail.case.accountId, memberPartyId: member.member.partyId, caseId: id };
    }
    case 'mergePlan': {
      const plan = await getJson<{ kind: string; fingerprint?: string; sourceMemberId?: string; targetMemberId?: string }>(`${base}/servicing/merge-plans/${encodeURIComponent(id)}`);
      return { inventoryFingerprint: plan.fingerprint, sourceMemberId: plan.sourceMemberId, targetMemberId: plan.targetMemberId };
    }
    case 'approval': {
      const page = await getJson<{ kind: string; approvals: { id: string; fingerprint: string; status: string; target: unknown }[] }>(`${base}/approvals`);
      const found = page.kind === 'found' ? page.approvals.find((row) => row.id === id) : undefined;
      return found === undefined ? {} : { fingerprint: found.fingerprint, status: found.status, target: found.target };
    }
    case 'maintenanceRequest': {
      const detail = await getJson<{ requestId: string; updatedAt: string }>(`${base}/servicing/maintenance-requests/${encodeURIComponent(id)}`);
      return { updatedAt: detail.updatedAt, requestId: detail.requestId };
    }
    case 'communicationJob': {
      const detail = await getJson<{ jobId: string; state: string }>(`${base}/servicing/communication-jobs/${encodeURIComponent(id)}`);
      return { state: detail.state };
    }
    case 'documentVersion': {
      const detail = await getJson<{ document: { documentId: string; digest: string; ownerPartyId: string | null } }>(`${base}/documents/${encodeURIComponent(id)}`);
      return { digest: detail.document.digest, documentId: detail.document.documentId, ownerPartyIds: detail.document.ownerPartyId === null ? [] : [detail.document.ownerPartyId] };
    }
    case 'document': {
      if (scope.memberId === undefined) return {};
      const versions = await getJson<{ versionId: string; documentId: string; ownerPartyId: string; accountId: string | null; documentType: string; displayName: string; retentionClass: string; version: number }[]>(
        `${base}/members/${encodeURIComponent(scope.memberId)}/document-versions`);
      const latest = versions.filter((row) => row.documentId === id).sort((a, b) => b.version - a.version)[0];
      if (latest === undefined) return {};
      return {
        ownerPartyId: latest.ownerPartyId, memberId: scope.memberId,
        expectedMetadata: { ownerPartyId: latest.ownerPartyId, accountId: latest.accountId, documentType: latest.documentType, displayName: latest.displayName, retentionClass: latest.retentionClass },
        documentType: latest.documentType, displayName: latest.displayName, retentionClass: latest.retentionClass, accountId: latest.accountId,
      };
    }
    case 'annotation': {
      if (scope.scopeId === undefined) return {};
      const detail = await getJson<{ annotations: { annotationId: string; fingerprint: string; pageNumber: number; region: Record<string, number> }[] }>(`${base}/documents/${encodeURIComponent(scope.scopeId)}`);
      const found = detail.annotations.find((row) => row.annotationId === id);
      return found === undefined ? {} : { fingerprint: found.fingerprint, pageNumber: found.pageNumber, regionMicros: found.region };
    }
    case 'savedSearch': {
      const rows = await getJson<{ id: string; revision: string }[]>(`${base}/saved-searches`);
      const found = rows.find((row) => row.id === id);
      return found === undefined ? {} : { revision: found.revision };
    }
    default:
      return {};
  }
}
