import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { executeCommand, getJson, institutionPath, newIdempotencyKey } from '../api.js';
import type { WorkContext } from '../App.js';

interface ApprovalRow {
  id: string; approvalNumber?: string; status: string; expiresAt: string; fingerprint: string;
  target: Record<string, unknown>; actor?: string; checker?: string; policyVersionId?: string;
}

interface ApprovalPage { kind: string; approvals?: ApprovalRow[]; total?: number; truncated?: boolean; message?: string }

/** Maker/checker inbox: decide pending approvals, then execute approved targets as the checker. */
export function ApprovalsPane({ context }: { context: WorkContext }): ReactNode {
  const [page, setPage] = useState<ApprovalPage | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [deciding, setDeciding] = useState<ApprovalRow | null>(null);
  const [decision, setDecision] = useState<'approve' | 'deny'>('approve');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      const result = await getJson<ApprovalPage>(`${base}/approvals`);
      if (result.kind !== 'found') { setError(result.message ?? 'Approvals rejected.'); setPage(null); return; }
      setPage(result); setError(null);
    } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
  }, [base]);

  useEffect(() => { void load(); }, [load, context.refreshKey]);

  const decide = async (): Promise<void> => {
    if (deciding === null) return;
    setBusy(true);
    try {
      const body = await executeCommand(context.institutionId, {
        kind: 'approval.decide', approvalId: deciding.id, expectedFingerprint: deciding.fingerprint, decision, reason,
      } as never, newIdempotencyKey('approval.decide'));
      const outcome = body.outcome;
      context.message(`approval.decide → ${outcome.kind}${outcome.kind === 'rejected' || outcome.kind === 'unchanged' ? ` ${outcome.message}` : ''}`);
      setDeciding(null); setReason('');
      context.refresh();
    } finally { setBusy(false); }
  };

  const executeApproved = async (row: ApprovalRow): Promise<void> => {
    const target = { ...row.target } as Record<string, unknown>;
    target.approvalId = row.id;
    const kind = typeof target.kind === 'string' ? target.kind : '';
    setBusy(true);
    try {
      const body = await executeCommand(context.institutionId, target as never, newIdempotencyKey(kind));
      const outcome = body.outcome;
      context.message(`${kind} → ${outcome.kind}${outcome.kind === 'committed' || outcome.kind === 'duplicate' ? ` ${outcome.receipt.receiptNumber}` : ''}${outcome.kind === 'rejected' || outcome.kind === 'unchanged' ? ` ${outcome.message}` : ''}`);
      context.refresh();
    } catch (cause) {
      context.message(cause instanceof Error ? cause.message : String(cause));
    } finally { setBusy(false); }
  };

  return (
    <section className="approvals-pane">
      <div className="list-toolbar">
        <h2>Approvals</h2>
        <button type="button" className="tool-button" onClick={() => void load()}>Refresh</button>
        {page !== null ? <span className="muted">{page.approvals?.length ?? 0} shown{page.truncated === true ? ' (truncated)' : ''}</span> : null}
      </div>
      {error !== null ? <p className="form-error" role="alert">{error}</p> : null}
      {page === null ? null : (
        <table className="list-table" data-testid="approvals-table">
          <thead><tr><th>Approval</th><th>Status</th><th>Target</th><th>Expires</th><th>Actions</th></tr></thead>
          <tbody>
            {(page.approvals ?? []).map((row) => (
              <tr key={row.id} data-approval={row.id}>
                <td className="mono">{row.id.slice(0, 18)}…</td>
                <td>{row.status}</td>
                <td className="mono">{typeof row.target.kind === 'string' ? row.target.kind : '—'}</td>
                <td>{row.expiresAt}</td>
                <td>
                  {row.status === 'pending' ? <button type="button" className="tool-button" onClick={() => setDeciding(row)}>Decide…</button> : null}
                  {row.status === 'approved' ? <button type="button" className="tool-button" disabled={busy} onClick={() => void executeApproved(row)}>Execute target</button> : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {deciding !== null ? (
        <div className="inline-dialog" role="dialog" aria-label="Decide approval">
          <h3>Decide {deciding.id.slice(0, 18)}…</h3>
          <pre className="review-json">{JSON.stringify(deciding.target, null, 2)}</pre>
          <label className="field-label">Decision
            <select className="field-input" value={decision} onChange={(e) => setDecision(e.target.value as 'approve' | 'deny')}>
              <option value="approve">approve</option><option value="deny">deny</option>
            </select>
          </label>
          <label className="field-label">Reason
            <input className="field-input" value={reason} onChange={(e) => setReason(e.target.value)} />
          </label>
          <div className="dialog-actions">
            <button type="button" className="primary" disabled={busy || reason === ''} onClick={() => void decide()}>Submit decision</button>
            <button type="button" className="tool-button" onClick={() => setDeciding(null)}>Cancel</button>
          </div>
        </div>
      ) : null}
    </section>
  );
}
