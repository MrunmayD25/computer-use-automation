import { useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from 'react';

import type { DocumentLayout, DocumentPageLayout } from '../../shared/api.js';
import { documentContentSize, documentHitTest, normalizeRect, pagePlacements, type PagePlacement, type PageRect } from '../model/document.js';
import { clampScroll, clampZoom, screenToContent, zoomAt, type Viewport } from '../model/viewport.js';

export interface DocumentAnnotation {
  annotationId: string;
  pageNumber: number;
  /** Normalized 0..1 region within the page. */
  region: { x: number; y: number; width: number; height: number };
  status: string;
  text: string;
  fingerprint?: string;
}

export interface DocumentCanvasProps {
  layout: DocumentLayout;
  /** Direct bytes URL for image documents. */
  contentUrl: string;
  mediaType: string;
  annotations: readonly DocumentAnnotation[];
  /** Current page shown in the status bar; reported on scroll. */
  onPageChange?: (page: number, total: number) => void;
  onWordSelect?: (hit: { pageNumber: number; text: string } | null) => void;
  onRegionSelect?: (region: PageRect) => void;
  onAnnotationSelect?: (annotation: DocumentAnnotation) => void;
  zoom?: number;
  onZoomChange?: (zoom: number) => void;
  'data-testid'?: string;
}

const PAGE_BG = '#f4f1ea';
const PAGE_TEXT = '#1a1a1a';
const ANNOTATION_FILL = 'rgba(255, 214, 90, 0.35)';
const ANNOTATION_BORDER = '#e0a800';
const SELECT_FILL = 'rgba(88, 146, 255, 0.30)';
const WORD_SELECT = 'rgba(88, 146, 255, 0.45)';

const CSV_COL_WIDTH = 160;
const CSV_ROW_HEIGHT = 22;
const CSV_HEADER = 24;

/** Layout a CSV document as one canvas page of grid cells. */
function csvPage(rows: string[][]): DocumentPageLayout {
  const widths: number[] = [];
  for (const row of rows) row.forEach((cell, column) => { widths[column] = Math.max(widths[column] ?? 60, Math.min(320, 8 + cell.length * 7.2)); });
  const words: { text: string; x: number; y: number; width: number; height: number }[] = [];
  rows.forEach((row, r) => {
    let x = 0;
    row.forEach((cell, c) => {
      words.push({ text: cell, x, y: CSV_HEADER + r * CSV_ROW_HEIGHT, width: widths[c] ?? CSV_COL_WIDTH, height: CSV_ROW_HEIGHT });
      x += widths[c] ?? CSV_COL_WIDTH;
    });
  });
  const width = Math.max(200, widths.reduce((total, w) => total + w, 0));
  return { pageNumber: 1, width, height: CSV_HEADER + rows.length * CSV_ROW_HEIGHT + 8, words };
}

/** Interactive document canvas: hit-testable words, zoom, pan, annotation regions. */
export function DocumentCanvas(props: DocumentCanvasProps): ReactNode {
  const { layout, annotations, onPageChange, onWordSelect, onRegionSelect, onAnnotationSelect } = props;
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const [imageReady, setImageReady] = useState(false);
  const [size, setSize] = useState({ width: 700, height: 500 });
  const [viewport, setViewport] = useState<Viewport>({ scrollX: 0, scrollY: 0, zoom: props.zoom ?? 1, width: 700, height: 500 });
  const [selectedWord, setSelectedWord] = useState<{ pageNumber: number; x: number; y: number; width: number; height: number; text: string } | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<PageRect | null>(null);
  const dragRef = useRef<{ kind: 'pan' | 'select'; startX: number; startY: number; page?: number; anchor?: { x: number; y: number }; scrollX: number; scrollY: number } | null>(null);
  const [imageSize, setImageSize] = useState<{ width: number; height: number } | null>(null);

  const isImage = props.mediaType.startsWith('image/');
  const isCsv = layout.csv !== undefined;

  useEffect(() => {
    if (!isImage) return;
    const image = new Image();
    image.onload = () => { imageRef.current = image; setImageSize({ width: image.naturalWidth, height: image.naturalHeight }); setImageReady(true); };
    image.src = props.contentUrl;
    return () => { imageRef.current = null; };
  }, [isImage, props.contentUrl]);

  const pages = useMemo<DocumentPageLayout[]>(() => {
    if (isCsv && layout.csv !== undefined) return [csvPage(layout.csv.rows)];
    if (isImage && imageSize !== null) {
      const scale = Math.min(1, 900 / imageSize.width);
      return layout.pages.map((page, index) => index === 0 ? { ...page, width: imageSize.width * scale, height: imageSize.height * scale } : page);
    }
    return layout.pages;
  }, [layout, isCsv, isImage, imageSize]);

  const placements = useMemo<PagePlacement[]>(() => pagePlacements(pages, 1000), [pages]);
  const contentSize = useMemo(() => documentContentSize(pages, 1000), [pages]);

  useLayoutEffect(() => {
    const node = containerRef.current;
    if (node === null) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) setSize({ width: entry.contentRect.width, height: entry.contentRect.height });
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useLayoutEffect(() => {
    setViewport((current) => clampScroll({ ...current, width: size.width, height: size.height }, contentSize.width, contentSize.height));
  }, [size, contentSize]);

  useEffect(() => {
    if (props.zoom !== undefined) setViewport((current) => clampScroll({ ...current, zoom: clampZoom(props.zoom ?? current.zoom) }, contentSize.width, contentSize.height));
  }, [props.zoom, contentSize]);

  // Report the page occupying the viewport center — only when it actually changes,
  // because reporting feeds parent state and an unguarded report loops forever.
  const lastReportedPage = useRef(0);
  useLayoutEffect(() => {
    const center = screenToContent(viewport, size.width / 2, size.height / 2);
    const current = placements.find((placement) => center.y >= placement.y && center.y <= placement.y + placement.height);
    if (current !== undefined && current.pageNumber !== lastReportedPage.current) {
      lastReportedPage.current = current.pageNumber;
      onPageChange?.(current.pageNumber, placements.length);
    }
  }, [viewport, placements, size, onPageChange]);

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (canvas === null) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, Math.round(size.width * dpr));
    canvas.height = Math.max(1, Math.round(size.height * dpr));
    const ctx = canvas.getContext('2d');
    if (ctx === null) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#17181c';
    ctx.fillRect(0, 0, size.width, size.height);

    const { zoom } = viewport;
    const toScreen = (x: number, y: number): { x: number; y: number } => ({ x: (x - viewport.scrollX) * zoom, y: (y - viewport.scrollY) * zoom });

    for (const placement of placements) {
      const page = pages.find((candidate) => candidate.pageNumber === placement.pageNumber);
      if (page === undefined) continue;
      const topLeft = toScreen(placement.x, placement.y);
      const pw = placement.width * zoom;
      const ph = placement.height * zoom;
      if (topLeft.y > size.height || topLeft.y + ph < 0 || topLeft.x > size.width || topLeft.x + pw < 0) continue;

      ctx.fillStyle = PAGE_BG;
      ctx.fillRect(topLeft.x, topLeft.y, pw, ph);
      ctx.strokeStyle = '#000';
      ctx.strokeRect(topLeft.x, topLeft.y, pw, ph);

      if (isImage && imageRef.current !== null && imageReady && placement.pageNumber === 1) {
        ctx.drawImage(imageRef.current, topLeft.x, topLeft.y, pw, ph);
      } else {
        ctx.fillStyle = PAGE_TEXT;
        ctx.textBaseline = 'top';
        ctx.textAlign = 'left';
        ctx.font = `${Math.max(6, 11 * zoom)}px "IBM Plex Mono", Menlo, monospace`;
        for (const word of page.words) {
          const p = toScreen(placement.x + word.x, placement.y + word.y);
          if (p.y > size.height || p.y + word.height * zoom < 0) continue;
          if (isCsv) {
            ctx.strokeStyle = '#b9b4a5';
            ctx.strokeRect(p.x, p.y, word.width * zoom, word.height * zoom);
          }
          ctx.fillText(word.text, p.x + (isCsv ? 4 * zoom : 0), p.y + (word.height * zoom - 11 * zoom) / 2);
        }
        if (isCsv) {
          ctx.fillStyle = 'rgba(0,0,0,0.06)';
          ctx.fillRect(topLeft.x, topLeft.y, pw, CSV_HEADER * zoom);
        }
      }

      // Annotations for this page.
      for (const annotation of annotations) {
        if (annotation.pageNumber !== placement.pageNumber) continue;
        const rx = placement.x + annotation.region.x * placement.width;
        const ry = placement.y + annotation.region.y * placement.height;
        const p = toScreen(rx, ry);
        ctx.fillStyle = ANNOTATION_FILL;
        ctx.fillRect(p.x, p.y, annotation.region.width * placement.width * zoom, annotation.region.height * placement.height * zoom);
        ctx.strokeStyle = ANNOTATION_BORDER;
        ctx.strokeRect(p.x, p.y, annotation.region.width * placement.width * zoom, annotation.region.height * placement.height * zoom);
      }
      // Page number badge.
      ctx.fillStyle = 'rgba(0,0,0,0.55)';
      ctx.fillRect(topLeft.x, topLeft.y - 18, 64, 16);
      ctx.fillStyle = '#fff';
      ctx.font = '10px "IBM Plex Mono", Menlo, monospace';
      ctx.fillText(`page ${placement.pageNumber}`, topLeft.x + 4, topLeft.y - 15);
    }

    // Selected word.
    if (selectedWord !== null) {
      const placement = placements.find((candidate) => candidate.pageNumber === selectedWord.pageNumber);
      if (placement !== undefined) {
        const p = toScreen(placement.x + selectedWord.x, placement.y + selectedWord.y);
        ctx.fillStyle = WORD_SELECT;
        ctx.fillRect(p.x, p.y, selectedWord.width * zoom, selectedWord.height * zoom);
      }
    }
    // Drag selection.
    if (selectedRegion !== null) {
      const placement = placements.find((candidate) => candidate.pageNumber === selectedRegion.pageNumber);
      if (placement !== undefined) {
        const p = toScreen(placement.x + selectedRegion.x, placement.y + selectedRegion.y);
        ctx.fillStyle = SELECT_FILL;
        ctx.fillRect(p.x, p.y, selectedRegion.width * zoom, selectedRegion.height * zoom);
        ctx.strokeStyle = '#5892ff';
        ctx.strokeRect(p.x, p.y, selectedRegion.width * zoom, selectedRegion.height * zoom);
      }
    }
  });

  const toLocal = (event: { clientX: number; clientY: number }): { x: number; y: number } => {
    const rect = canvasRef.current?.getBoundingClientRect();
    return { x: event.clientX - (rect?.left ?? 0), y: event.clientY - (rect?.top ?? 0) };
  };

  const onPointerDown = (event: React.PointerEvent<HTMLCanvasElement>): void => {
    const point = toLocal(event);
    const hit = documentHitTest(placements, pages, viewport, point.x, point.y);
    if (event.shiftKey && hit !== null) {
      dragRef.current = { kind: 'select', startX: event.clientX, startY: event.clientY, page: hit.pageNumber, anchor: { x: hit.x, y: hit.y }, scrollX: viewport.scrollX, scrollY: viewport.scrollY };
      (event.target as Element).setPointerCapture(event.pointerId);
      return;
    }
    dragRef.current = { kind: 'pan', startX: event.clientX, startY: event.clientY, scrollX: viewport.scrollX, scrollY: viewport.scrollY };
    (event.target as Element).setPointerCapture(event.pointerId);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLCanvasElement>): void => {
    const drag = dragRef.current;
    if (drag === null) return;
    if (drag.kind === 'pan') {
      const dx = (event.clientX - drag.startX) / viewport.zoom;
      const dy = (event.clientY - drag.startY) / viewport.zoom;
      setViewport((current) => clampScroll({ ...current, scrollX: drag.scrollX - dx, scrollY: drag.scrollY - dy }, contentSize.width, contentSize.height));
      return;
    }
    // Region select within the anchor page.
    const local = toLocal(event);
    const hit = documentHitTest(placements, pages, viewport, local.x, local.y);
    const page = pages.find((candidate) => candidate.pageNumber === drag.page);
    const anchor = drag.anchor;
    if (anchor === undefined || page === undefined) return;
    const point = hit !== null && hit.pageNumber === drag.page ? { x: hit.x, y: hit.y }
      : (() => { const p = toLocal(event); const c = screenToContent(viewport, p.x, p.y); const placement = placements.find((pl) => pl.pageNumber === drag.page); return placement === undefined ? anchor : { x: Math.min(Math.max(0, c.x - placement.x), placement.width), y: Math.min(Math.max(0, c.y - placement.y), placement.height) }; })();
    setSelectedRegion(normalizeRect(drag.page ?? 1, anchor, point));
  };

  const onPointerUp = (event: React.PointerEvent<HTMLCanvasElement>): void => {
    const drag = dragRef.current;
    dragRef.current = null;
    if (drag === null) return;
    if (drag.kind === 'select') {
      const region = selectedRegion;
      if (region !== null && region.width > 2 && region.height > 2) onRegionSelect?.(region);
      return;
    }
    // Click: select the word or annotation under the pointer.
    const point = toLocal(event);
    const moved = Math.abs(event.clientX - drag.startX) + Math.abs(event.clientY - drag.startY) > 4;
    if (moved) return;
    const hit = documentHitTest(placements, pages, viewport, point.x, point.y);
    if (hit === null) { setSelectedWord(null); onWordSelect?.(null); return; }
    const placement = placements.find((candidate) => candidate.pageNumber === hit.pageNumber);
    if (placement !== undefined) {
      const annotation = annotations.find((candidate) => {
        if (candidate.pageNumber !== hit.pageNumber) return false;
        const rx = candidate.region.x * placement.width;
        const ry = candidate.region.y * placement.height;
        return hit.x >= rx && hit.x <= rx + candidate.region.width * placement.width && hit.y >= ry && hit.y <= ry + candidate.region.height * placement.height;
      });
      if (annotation !== undefined) { onAnnotationSelect?.(annotation); return; }
    }
    if (hit.word !== null) {
      setSelectedWord({ pageNumber: hit.pageNumber, ...hit.word });
      onWordSelect?.({ pageNumber: hit.pageNumber, text: hit.word.text });
    } else {
      setSelectedWord(null);
      onWordSelect?.(null);
    }
  };

  const onWheel = (event: React.WheelEvent<HTMLCanvasElement>): void => {
    if (event.ctrlKey || event.metaKey) {
      const point = toLocal(event);
      const zoom = clampZoom(viewport.zoom * (event.deltaY > 0 ? 1 / 1.15 : 1.15));
      setViewport((current) => clampScroll(zoomAt(current, point, zoom), contentSize.width, contentSize.height));
      props.onZoomChange?.(zoom);
      return;
    }
    setViewport((current) => clampScroll({ ...current, scrollX: current.scrollX + event.deltaX / current.zoom, scrollY: current.scrollY + event.deltaY / current.zoom }, contentSize.width, contentSize.height));
  };

  return (
    <div ref={containerRef} className="document-canvas" data-testid={props['data-testid'] ?? 'document-canvas'}>
      <canvas
        ref={canvasRef}
        style={{ width: size.width, height: size.height, cursor: 'crosshair' }}
        tabIndex={0}
        role="document"
        aria-label="Document pages"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onWheel={onWheel}
        onContextMenu={(event) => event.preventDefault()}
      />
      <div className="document-hud muted">
        {isImage && !imageReady ? 'Loading image…' : `${placements.length} page(s) · ${Math.round(viewport.zoom * 100)}% · Shift-drag to mark a region`}
      </div>
    </div>
  );
}
