import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { getJson, institutionPath } from '../api.js';
import type { WorkContext } from '../App.js';

/** Generic finance-record pane: shows the authoritative record snapshot and its fingerprint. */
export function RecordPane({ resource, id, context }: { resource: string; id: string; context: WorkContext }): ReactNode {
  const [data, setData] = useState<Record<string, unknown> | null>(null);
  const [fingerprint, setFingerprint] = useState('');
  const [error, setError] = useState<string | null>(null);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      if (resource === 'receipt') {
        const receipt = await getJson<Record<string, unknown>>(`${base}/receipts/${encodeURIComponent(id)}`);
        setData(receipt); setFingerprint(''); setError(null);
        return;
      }
      const result = await getJson<{ kind: string; snapshot?: { fingerprint: string; record: Record<string, unknown>; observedAt: string }; message?: string }>(
        `${base}/finance/record/${encodeURIComponent(resource)}/${encodeURIComponent(id)}`);
      if (result.kind !== 'found' || result.snapshot === undefined) { setError(result.message ?? 'The record could not be read.'); return; }
      setData(result.snapshot.record);
      setFingerprint(result.snapshot.fingerprint);
      setError(null);
      context.reportFocus({ area: 'record', record: `${resource}:${id}` });
    } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
  }, [base, resource, id]);

  useEffect(() => { void load(); }, [load, context.refreshKey]);

  if (error !== null) return <p className="form-error" role="alert">{error}</p>;
  if (data === null) return <p className="muted">Loading record…</p>;

  return (
    <section className="record-pane">
      <header className="record-header">
        <h2>{resource} {id}</h2>
        {fingerprint !== '' ? <p className="muted mono">fingerprint {fingerprint.slice(0, 24)}…</p> : null}
      </header>
      <RecordTree value={data} context={context} />
    </section>
  );
}

function RecordTree({ value, context }: { value: unknown; context: WorkContext }): ReactNode {
  if (value === null || value === undefined) return <span className="muted">—</span>;
  if (Array.isArray(value)) {
    return (
      <ul className="record-list">
        {(value as unknown[]).map((item: unknown, index) => <li key={index}><RecordTree value={item} context={context} /></li>)}
      </ul>
    );
  }
  if (typeof value === 'object') {
    return (
      <dl className="record-facts nested">
        {Object.entries(value as Record<string, unknown>).map(([key, child]) => {
          let parsed: unknown = child;
          if (typeof child === 'string' && child.startsWith('[')) { try { parsed = JSON.parse(child) as unknown; } catch { /* keep */ } }
          return <span key={key} className="record-entry"><dt>{key}</dt><dd><RecordTree value={parsed} context={context} /></dd></span>;
        })}
      </dl>
    );
  }
  return <span>{typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean' ? String(value) : ''}</span>;
}
