import {
  FloatingFocusManager, FloatingPortal, autoUpdate, flip, offset, shift, size, useDismiss, useFloating, useInteractions, useListNavigation, useRole, type Placement,
} from '@floating-ui/react';
import { useEffect, useLayoutEffect, useMemo, useRef, useState, type ReactNode } from 'react';

export interface MenuItem {
  id: string;
  label: string;
  hint?: string;
  checked?: boolean;
  disabled?: boolean;
  /** Why the item is unavailable, shown as its description. */
  disabledReason?: string;
  /** Starts a new section with this heading. */
  section?: string;
  onSelect: () => void;
}

export type MenuCloseReason = 'select' | 'dismiss' | 'anchor-removed';

interface AnchoredMenuProps {
  label: string;
  /**
   * Finds the anchor by business identity on every frame. Recycled grid rows reuse DOM nodes for other
   * records, so a menu never holds on to a node; when the lookup fails the owner is gone and the menu closes.
   */
  anchor: () => Element | null;
  items: readonly MenuItem[];
  onClose: (reason: MenuCloseReason) => void;
  placement?: Placement;
}

/** A menu rendered in a portal outside its owner's subtree, positioned against an anchor found by identity. */
export function AnchoredMenu({ label, anchor, items, onClose, placement = 'bottom-start' }: AnchoredMenuProps): ReactNode {
  const firstEnabled = items.findIndex((item) => item.disabled !== true);
  const [activeIndex, setActiveIndex] = useState<number | null>(firstEnabled < 0 ? null : firstEnabled);
  const listRef = useRef<(HTMLElement | null)[]>([]);
  const anchorRef = useRef(anchor);
  const closeRef = useRef(onClose);
  useLayoutEffect(() => { anchorRef.current = anchor; closeRef.current = onClose; });
  const lastRect = useRef(new DOMRect());
  const reference = useMemo(() => ({
    getBoundingClientRect: () => { const element = anchorRef.current(); if (element !== null) lastRect.current = element.getBoundingClientRect(); return lastRect.current; },
  }), []);
  const { refs, floatingStyles, context } = useFloating({
    open: true,
    onOpenChange: (open) => { if (!open) closeRef.current('dismiss'); },
    placement,
    middleware: [offset(4), flip({ padding: 8 }), shift({ padding: 8 }), size({ padding: 8, apply({ availableHeight, elements }) { elements.floating.style.maxHeight = `${String(Math.max(120, availableHeight))}px`; } })],
    whileElementsMounted: (referenceElement, floating, update) => autoUpdate(referenceElement, floating, update, { animationFrame: true }),
  });
  useLayoutEffect(() => { refs.setPositionReference(reference); }, [refs, reference]);
  useEffect(() => {
    let frame = 0;
    const check = (): void => {
      if (anchorRef.current() === null) { closeRef.current('anchor-removed'); return; }
      frame = requestAnimationFrame(check);
    };
    frame = requestAnimationFrame(check);
    return () => cancelAnimationFrame(frame);
  }, []);
  const disabledIndices = items.flatMap((item, index) => (item.disabled === true ? [index] : []));
  const navigation = useListNavigation(context, { listRef, activeIndex, onNavigate: setActiveIndex, loop: true, disabledIndices, focusItemOnOpen: true });
  const role = useRole(context, { role: 'menu' });
  const dismiss = useDismiss(context);
  const { getFloatingProps, getItemProps } = useInteractions([navigation, role, dismiss]);
  return (
    <FloatingPortal>
      <FloatingFocusManager context={context} modal={false} returnFocus={false} initialFocus={-1}>
        <div ref={(node) => refs.setFloating(node)} style={floatingStyles} className="menu" aria-label={label} {...getFloatingProps()}>
          {items.map((item, index) => (
            <div key={item.id}>
              {item.section === undefined ? null : <div className="menu-heading" role="presentation">{item.section}</div>}
              <button
                type="button"
                ref={(node) => { listRef.current[index] = node; }}
                role={item.checked === undefined ? 'menuitem' : 'menuitemcheckbox'}
                aria-checked={item.checked}
                aria-disabled={item.disabled === true ? true : undefined}
                title={item.disabledReason}
                tabIndex={activeIndex === index ? 0 : -1}
                className="menu-item"
                {...getItemProps({
                  onClick() { if (item.disabled !== true) { item.onSelect(); closeRef.current('select'); } },
                })}
              >
                <span className="menu-check" aria-hidden="true">{item.checked === true ? '✓' : ''}</span>
                <span className="menu-label">{item.label}</span>
                {item.hint === undefined ? null : <span className="menu-hint">{item.hint}</span>}
              </button>
              {item.disabled === true && item.disabledReason !== undefined ? <div className="menu-reason">{item.disabledReason}</div> : null}
            </div>
          ))}
        </div>
      </FloatingFocusManager>
    </FloatingPortal>
  );
}

interface MenuButtonProps {
  label: string;
  items: () => readonly MenuItem[];
  children: ReactNode;
  className?: string;
  disabled?: boolean;
  title?: string;
  /** Accessible name for a button whose content is only a symbol. */
  buttonLabel?: string;
}

/** A toolbar button that opens an anchored menu and returns focus to itself when the menu closes. */
export function MenuButton({ label, items, children, className, disabled, title, buttonLabel }: MenuButtonProps): ReactNode {
  const [open, setOpen] = useState(false);
  const button = useRef<HTMLButtonElement>(null);
  return (
    <>
      <button
        ref={button} type="button" className={className ?? 'tool-button'} aria-haspopup="menu" aria-expanded={open} aria-label={buttonLabel} disabled={disabled} title={title}
        onClick={() => setOpen((value) => !value)}
      >{children}</button>
      {open ? (
        <AnchoredMenu
          label={label} items={items()} anchor={() => (button.current?.isConnected === true ? button.current : null)}
          onClose={(reason) => { setOpen(false); if (reason !== 'anchor-removed') button.current?.focus(); }}
        />
      ) : null}
    </>
  );
}
