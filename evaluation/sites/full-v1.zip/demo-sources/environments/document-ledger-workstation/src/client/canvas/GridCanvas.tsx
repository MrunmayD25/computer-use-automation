import { useLayoutEffect, useRef, useState, type ReactNode } from 'react';

import type { CellRef, GridColumn, GridGeometry } from '../model/grid.js';
import { cellScreenRect, columnOffsets, contentHeight, contentWidth, hitTest, visibleRowRange } from '../model/grid.js';
import { clampScroll, clampZoom, screenToContent, zoomAt, type Viewport } from '../model/viewport.js';

export interface GridCell {
  text: string;
  align?: 'left' | 'right' | 'center';
  tone?: 'normal' | 'muted' | 'credit' | 'debit' | 'warning';
}

export interface GridCanvasProps<T> {
  columns: readonly GridColumn[];
  rows: readonly T[];
  rowHeight?: number;
  headerHeight?: number;
  frozenColumns?: number;
  frozenRows?: number;
  cell: (row: T, column: number) => GridCell;
  /** The selected cell in data coordinates; null hides the selection. */
  selection: CellRef | null;
  onSelect: (cell: CellRef | null, row: T | undefined) => void;
  /** Renders the floating editor over the editing cell. */
  editing: CellRef | null;
  editor?: (rect: { x: number; y: number; width: number; height: number }, row: T) => ReactNode;
  onRequestEdit?: (cell: CellRef, row: T) => void;
  /** Fired on right-click / context-menu with the cell under the pointer. */
  onCellMenu?: (cell: CellRef, row: T, at: { x: number; y: number }) => void;
  /** Announces focus/cell identity to the status bar. */
  onFocus?: (cell: CellRef | null, focused: boolean) => void;
  /** Column header suffix, e.g. a sort marker. */
  columnLabel?: (column: GridColumn, index: number) => string;
  onHeaderClick?: (column: GridColumn, index: number) => void;
  'data-testid'?: string;
}

const COLORS = {
  background: '#1e1f24', headerBg: '#26272e', headerText: '#b8bcc8', frozenBg: '#23242a',
  gridLine: '#3a3b44', text: '#dde0e8', muted: '#8a8f9e', credit: '#7dd8a3', debit: '#f2a9a0',
  warning: '#f2c97d', selection: 'rgba(88, 146, 255, 0.28)', selectionBorder: '#5892ff', rowHover: 'rgba(255,255,255,0.04)',
};

/**
 * A real canvas grid: zoomed, panned, hit-tested, with a pinned header and pinned leading
 * columns/rows. Editable cells get a DOM overlay anchored by business row, not DOM position.
 */
export function GridCanvas<T>(props: GridCanvasProps<T>): ReactNode {
  const {
    columns, rows, cell, selection, onSelect, editing, editor, onRequestEdit, onCellMenu, onFocus, columnLabel, onHeaderClick,
  } = props;
  const rowHeight = props.rowHeight ?? 24;
  const headerHeight = props.headerHeight ?? 28;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ width: 600, height: 300 });
  const [viewport, setViewport] = useState<Viewport>({ scrollX: 0, scrollY: 0, zoom: 1, width: 600, height: 300 });
  const [hover, setHover] = useState<CellRef | null>(null);
  const drag = useRef<{ startX: number; startY: number; scrollX: number; scrollY: number; moved: boolean } | null>(null);
  // PointerEvent.detail is always 0, so double-click detection tracks its own clicks.
  const lastUp = useRef<{ time: number; row: number; column: number } | null>(null);
  const focusedRef = useRef(false);

  const geometry: GridGeometry = {
    columns, rowHeight, headerHeight,
    rowCount: rows.length,
    frozenColumns: props.frozenColumns ?? 0,
    frozenRows: props.frozenRows ?? 0,
  };
  const cw = contentWidth(geometry);
  const ch = contentHeight(geometry);

  useLayoutEffect(() => {
    const node = containerRef.current;
    if (node === null) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setSize({ width, height });
      }
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useLayoutEffect(() => {
    setViewport((current) => clampScroll({ ...current, width: size.width, height: size.height }, cw, ch));
  }, [size, cw, ch]);

  // ---- paint ---------------------------------------------------------------
  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (canvas === null) return;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, Math.round(size.width * dpr));
    canvas.height = Math.max(1, Math.round(size.height * dpr));
    const ctx = canvas.getContext('2d');
    if (ctx === null) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = COLORS.background;
    ctx.fillRect(0, 0, size.width, size.height);

    const { zoom } = viewport;
    const offsets = columnOffsets(columns);
    const pinnedW = offsets[geometry.frozenColumns] ?? cw;
    const pinnedH = headerHeight + geometry.frozenRows * rowHeight;
    const toScreenX = (x: number): number => (x < pinnedW ? x * zoom : pinnedW * zoom + (x - pinnedW - viewport.scrollX) * zoom);
    const toScreenY = (y: number): number => (y < pinnedH ? y * zoom : pinnedH * zoom + (y - pinnedH - viewport.scrollY) * zoom);

    const range = visibleRowRange(geometry, viewport);
    const visibleRows = new Set<number>();
    for (let row = geometry.frozenRows - 1; row >= 0; row -= 1) visibleRows.add(row);
    for (let row = range.first; row <= range.last; row += 1) visibleRows.add(row);

    // Grid body cells.
    ctx.font = `${zoom >= 1 ? Math.round(12 * zoom) : 12}px "IBM Plex Mono", Menlo, monospace`;
    const rowYs = new Map<number, number>();
    for (const row of visibleRows) {
      const y = toScreenY(headerHeight + row * rowHeight);
      if (y > size.height + rowHeight * zoom || y < pinnedH * zoom - rowHeight * zoom) continue;
      rowYs.set(row, y);
      const record = rows[row];
      if (record === undefined) continue;
      if (hover !== null && hover.row === row) {
        ctx.fillStyle = COLORS.rowHover;
        ctx.fillRect(0, y, size.width, rowHeight * zoom);
      }
      if (selection !== null && selection.row === row) {
        ctx.fillStyle = 'rgba(88,146,255,0.10)';
        ctx.fillRect(0, y, size.width, rowHeight * zoom);
      }
      for (let column = 0; column < columns.length; column += 1) {
        const x = toScreenX(offsets[column] ?? 0);
        const w = (columns[column]?.width ?? 0) * zoom;
        if (x > size.width || x + w < (column < geometry.frozenColumns ? 0 : pinnedW * zoom)) {
          if (column >= geometry.frozenColumns && x + w < pinnedW * zoom) continue;
          if (x > size.width) continue;
        }
        const cellValue = cell(record, column);
        const color = cellValue.tone === 'credit' ? COLORS.credit : cellValue.tone === 'debit' ? COLORS.debit : cellValue.tone === 'warning' ? COLORS.warning : cellValue.tone === 'muted' ? COLORS.muted : COLORS.text;
        ctx.fillStyle = color;
        ctx.textBaseline = 'middle';
        const textY = y + (rowHeight * zoom) / 2;
        const pad = 6 * zoom;
        ctx.save();
        ctx.beginPath();
        ctx.rect(x, y, w, rowHeight * zoom);
        ctx.clip();
        if (cellValue.align === 'right') { ctx.textAlign = 'right'; ctx.fillText(cellValue.text, x + w - pad, textY); }
        else if (cellValue.align === 'center') { ctx.textAlign = 'center'; ctx.fillText(cellValue.text, x + w / 2, textY); }
        else { ctx.textAlign = 'left'; ctx.fillText(cellValue.text, x + pad, textY); }
        ctx.restore();
      }
    }

    // Frozen column veil.
    if (geometry.frozenColumns > 0) {
      ctx.fillStyle = COLORS.frozenBg;
      ctx.fillRect(0, 0, pinnedW * zoom, size.height);
      ctx.strokeStyle = COLORS.gridLine;
      ctx.beginPath();
      ctx.moveTo(pinnedW * zoom, 0); ctx.lineTo(pinnedW * zoom, size.height); ctx.stroke();
      ctx.textBaseline = 'middle';
      for (const [row, y] of rowYs) {
        const record = rows[row]; if (record === undefined) continue;
        for (let column = 0; column < geometry.frozenColumns; column += 1) {
          const x = toScreenX(offsets[column] ?? 0);
          const w = (columns[column]?.width ?? 0) * zoom;
          const cellValue = cell(record, column);
          ctx.fillStyle = cellValue.tone === 'muted' ? COLORS.muted : COLORS.text;
          ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, rowHeight * zoom); ctx.clip();
          ctx.fillText(cellValue.text, x + 6 * zoom, y + (rowHeight * zoom) / 2);
          ctx.restore();
        }
      }
    }

    // Grid lines for the scrollable body.
    ctx.strokeStyle = COLORS.gridLine;
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (const [, y] of rowYs) { ctx.moveTo(0, Math.round(y) + 0.5); ctx.lineTo(size.width, Math.round(y) + 0.5); }
    for (let column = geometry.frozenColumns; column <= columns.length; column += 1) {
      const x = toScreenX(offsets[column] ?? cw);
      if (x >= pinnedW * zoom && x <= size.width) { ctx.moveTo(Math.round(x) + 0.5, 0); ctx.lineTo(Math.round(x) + 0.5, size.height); }
    }
    ctx.stroke();

    // Header.
    ctx.fillStyle = COLORS.headerBg;
    ctx.fillRect(0, 0, size.width, headerHeight * zoom);
    ctx.font = `${Math.max(10, Math.round(11 * zoom))}px "IBM Plex Mono", Menlo, monospace`;
    ctx.fillStyle = COLORS.headerText;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    for (let column = 0; column < columns.length; column += 1) {
      const x = toScreenX(offsets[column] ?? 0);
      const w = (columns[column]?.width ?? 0) * zoom;
      if (x + w < 0 || x > size.width) continue;
      ctx.save(); ctx.beginPath(); ctx.rect(x, 0, w, headerHeight * zoom); ctx.clip();
      ctx.fillText(columnLabel?.(columns[column] as GridColumn, column) ?? columns[column]?.label ?? '', x + 6 * zoom, (headerHeight * zoom) / 2);
      ctx.restore();
    }
    ctx.strokeStyle = COLORS.gridLine;
    ctx.beginPath(); ctx.moveTo(0, headerHeight * zoom + 0.5); ctx.lineTo(size.width, headerHeight * zoom + 0.5); ctx.stroke();

    // Pinned-row separator.
    if (geometry.frozenRows > 0) {
      ctx.fillStyle = COLORS.frozenBg;
      for (let row = 0; row < Math.min(geometry.frozenRows, rows.length); row += 1) {
        const y = headerHeight * zoom + row * rowHeight * zoom;
        ctx.fillRect(0, y, size.width, rowHeight * zoom);
        const record = rows[row]; if (record === undefined) continue;
        for (let column = 0; column < columns.length; column += 1) {
          const x = toScreenX(offsets[column] ?? 0);
          const w = (columns[column]?.width ?? 0) * zoom;
          const cellValue = cell(record, column);
          ctx.fillStyle = COLORS.text;
          ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, rowHeight * zoom); ctx.clip();
          ctx.fillText(cellValue.text, x + 6 * zoom, y + (rowHeight * zoom) / 2);
          ctx.restore();
        }
      }
      ctx.strokeStyle = COLORS.gridLine;
      ctx.beginPath(); ctx.moveTo(0, pinnedH * zoom + 0.5); ctx.lineTo(size.width, pinnedH * zoom + 0.5); ctx.stroke();
    }

    // Selection.
    if (selection !== null && selection.row >= 0 && selection.row < rows.length) {
      const rect = cellScreenRect(geometry, viewport, selection.row, selection.column);
      ctx.strokeStyle = COLORS.selectionBorder;
      ctx.lineWidth = 2;
      ctx.strokeRect(rect.x + 1, rect.y + 1, rect.width - 2, rect.height - 2);
      ctx.fillStyle = COLORS.selection;
      ctx.fillRect(rect.x + 1, rect.y + 1, rect.width - 2, rect.height - 2);
    }
    // Canvas focus ring.
    if (focusedRef.current) {
      ctx.strokeStyle = 'rgba(88,146,255,0.55)';
      ctx.lineWidth = 1;
      ctx.strokeRect(0.5, 0.5, size.width - 1, size.height - 1);
    }
  });

  // ---- input ---------------------------------------------------------------
  const toLocal = (event: { clientX: number; clientY: number }): { x: number; y: number } => {
    const rect = canvasRef.current?.getBoundingClientRect();
    return { x: event.clientX - (rect?.left ?? 0), y: event.clientY - (rect?.top ?? 0) };
  };

  const onPointerDown = (event: React.PointerEvent<HTMLCanvasElement>): void => {
    const point = toLocal(event);
    const hit = hitTest(geometry, viewport, point.x, point.y);
    if (event.button === 2) {
      const row = hit.row >= 0 ? rows[hit.row] : undefined;
      if (hit.region === 'cell' || hit.region === 'frozen-column' || hit.region === 'frozen-row') {
        if (row !== undefined) onCellMenu?.({ row: hit.row, column: hit.column }, row, point);
      }
      return;
    }
    if (hit.region === 'header' || hit.region === 'corner') {
      const column = columns[hit.column];
      if (column !== undefined) onHeaderClick?.(column, hit.column);
      return;
    }
    if (hit.region === 'cell' || hit.region === 'frozen-column' || hit.region === 'frozen-row') {
      onSelect({ row: hit.row, column: hit.column }, rows[hit.row]);
    } else {
      onSelect(null, undefined);
    }
    drag.current = { startX: event.clientX, startY: event.clientY, scrollX: viewport.scrollX, scrollY: viewport.scrollY, moved: false };
    (event.target as Element).setPointerCapture(event.pointerId);
  };

  const onPointerMove = (event: React.PointerEvent<HTMLCanvasElement>): void => {
    const point = toLocal(event);
    if (drag.current !== null) {
      const dx = (event.clientX - drag.current.startX) / viewport.zoom;
      const dy = (event.clientY - drag.current.startY) / viewport.zoom;
      const pan = drag.current;
      if (Math.abs(event.clientX - pan.startX) + Math.abs(event.clientY - pan.startY) > 3) pan.moved = true;
      if (pan.moved) {
        setViewport((current) => clampScroll({ ...current, scrollX: pan.scrollX - dx, scrollY: pan.scrollY - dy }, cw, ch));
      }
      return;
    }
    const hit = hitTest(geometry, viewport, point.x, point.y);
    setHover(hit.row >= 0 ? { row: hit.row, column: hit.column } : null);
  };

  const onPointerUp = (event: React.PointerEvent<HTMLCanvasElement>): void => {
    if (drag.current !== null && !drag.current.moved) {
      const point = toLocal(event);
      const hit = hitTest(geometry, viewport, point.x, point.y);
      if (hit.region === 'cell' || hit.region === 'frozen-column' || hit.region === 'frozen-row') {
        const now = performance.now();
        const previous = lastUp.current;
        lastUp.current = { time: now, row: hit.row, column: hit.column };
        if (previous !== null && now - previous.time < 500 && previous.row === hit.row && previous.column === hit.column) {
          const row = rows[hit.row];
          if (row !== undefined) onRequestEdit?.({ row: hit.row, column: hit.column }, row);
        }
      } else {
        lastUp.current = null;
      }
    }
    drag.current = null;
  };

  const onWheel = (event: React.WheelEvent<HTMLCanvasElement>): void => {
    if (event.ctrlKey || event.metaKey) {
      const point = toLocal(event);
      setViewport((current) => clampScroll(zoomAt(current, point, current.zoom * (event.deltaY > 0 ? 1 / 1.15 : 1.15)), cw, ch));
      return;
    }
    setViewport((current) => clampScroll({ ...current, scrollX: current.scrollX + event.deltaX / current.zoom, scrollY: current.scrollY + event.deltaY / current.zoom }, cw, ch));
  };

  const onKeyDown = (event: React.KeyboardEvent<HTMLCanvasElement>): void => {
    if (selection === null) return;
    const move = (dRow: number, dCol: number): void => {
      const next = { row: Math.min(Math.max(0, selection.row + dRow), rows.length - 1), column: Math.min(Math.max(0, selection.column + dCol), columns.length - 1) };
      onSelect(next, rows[next.row]);
      ensureVisible(next);
      event.preventDefault();
    };
    switch (event.key) {
      case 'ArrowUp': move(-1, 0); break;
      case 'ArrowDown': move(1, 0); break;
      case 'ArrowLeft': move(0, -1); break;
      case 'ArrowRight': move(0, 1); break;
      case 'PageDown': move(Math.max(1, Math.floor(viewport.height / viewport.zoom / rowHeight) - 1), 0); break;
      case 'PageUp': move(-Math.max(1, Math.floor(viewport.height / viewport.zoom / rowHeight) - 1), 0); break;
      case 'F2': case 'Enter': {
        const row = rows[selection.row];
        if (row !== undefined) onRequestEdit?.(selection, row);
        event.preventDefault();
        break;
      }
      default: break;
    }
  };

  const ensureVisible = (cell: CellRef): void => {
    const rect = cellScreenRect(geometry, viewport, cell.row, cell.column);
    setViewport((current) => {
      let { scrollX, scrollY } = current;
      if (rect.y + rect.height > current.height) scrollY += (rect.y + rect.height - current.height) / current.zoom;
      if (rect.y < 0) scrollY += rect.y / current.zoom;
      if (rect.x + rect.width > current.width) scrollX += (rect.x + rect.width - current.width) / current.zoom;
      if (rect.x < 0) scrollX += rect.x / current.zoom;
      return clampScroll({ ...current, scrollX, scrollY }, cw, ch);
    });
  };

  const editingRect = editing !== null && editing.row < rows.length ? cellScreenRect(geometry, viewport, editing.row, editing.column) : null;
  const editingRow = editing !== null ? rows[editing.row] : undefined;

  return (
    <div ref={containerRef} className="grid-canvas" data-testid={props['data-testid'] ?? 'grid-canvas'}>
      <canvas
        ref={canvasRef}
        style={{ width: size.width, height: size.height }}
        tabIndex={0}
        role="grid"
        aria-label="Ledger grid"
        aria-rowcount={rows.length}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onWheel={onWheel}
        onKeyDown={onKeyDown}
        onContextMenu={(event) => event.preventDefault()}
        onFocus={() => { focusedRef.current = true; onFocus?.(selection, true); }}
        onBlur={() => { focusedRef.current = false; onFocus?.(selection, false); }}
      />
      {editingRect !== null && editingRow !== undefined && editor !== undefined ? (
        <div className="cell-editor" style={{ left: editingRect.x, top: editingRect.y, width: editingRect.width, height: editingRect.height }}>
          {editor(editingRect, editingRow)}
        </div>
      ) : null}
      <div className="grid-scrollbar" aria-hidden="true">
        <span className="muted">{rows.length} rows · {Math.round(viewport.zoom * 100)}%</span>
      </div>
    </div>
  );
}

export { clampZoom, screenToContent };
