import { useEffect, useMemo, useState, type ReactNode } from 'react';

import { Dialog } from '../ui/Dialog.js';
import type { PickerSource } from './catalog.js';
import { fetchOptions, needsMember, type PickerOption, type PickerScope } from './sources.js';

interface PickerDialogProps {
  institutionId: string;
  source: PickerSource;
  scope: PickerScope;
  title: string;
  onPick: (option: PickerOption) => void;
  onClose: () => void;
}

const SEARCHABLE = new Set<PickerSource>(['member', 'account', 'case', 'document', 'documentVersion']);

/** One picking step: options for a source under a scope. */
function OptionList({ institutionId, source, scope, onPick }: { institutionId: string; source: PickerSource; scope: PickerScope; onPick: (o: PickerOption) => void }): ReactNode {
  const [query, setQuery] = useState('');
  const [options, setOptions] = useState<PickerOption[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const debounced = useDebounced(query);
  useEffect(() => {
    let live = true;
    setOptions(null);
    fetchOptions(institutionId, source, { ...scope, query: debounced }).then(
      (rows) => { if (live) { setOptions(rows); setError(null); } },
      (e: unknown) => { if (live) { setOptions([]); setError(e instanceof Error ? e.message : String(e)); } },
    );
    return () => { live = false; };
  }, [institutionId, source, scope, debounced]);
  return (
    <div className="picker">
      {SEARCHABLE.has(source) ? (
        <input className="picker-query" type="search" placeholder="Search…" value={query} onChange={(event) => setQuery(event.target.value)} autoFocus />
      ) : null}
      {error !== null ? <p className="form-error" role="alert">{error}</p> : null}
      {options === null ? <p className="muted">Loading…</p> : options.length === 0 ? <p className="muted">No records match this scope.</p> : (
        <ul className="picker-options" role="listbox">
          {options.map((option) => (
            <li key={option.id}>
              <button type="button" className="picker-option" onClick={() => onPick(option)}>
                <span className="picker-label">{option.label}</span>
                {option.detail === undefined ? null : <span className="picker-detail">{typeof option.detail === 'string' ? option.detail : JSON.stringify(option.detail)}</span>}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function useDebounced(value: string): string {
  const [current, setCurrent] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setCurrent(value), 200);
    return () => clearTimeout(timer);
  }, [value]);
  return current;
}

/**
 * Modal record picker. Member-scoped sources that arrive without a member first ask for one,
 * so every option shown is a real record inside the caller's institution scope.
 */
export function PickerDialog({ institutionId, source, scope, title, onPick, onClose }: PickerDialogProps): ReactNode {
  const [memberId, setMemberId] = useState(scope.memberId);
  const needsMemberStep = needsMember(source) && memberId === undefined;
  const effectiveScope = useMemo<PickerScope>(() => ({ ...scope, memberId }), [scope, memberId]);
  return (
    <Dialog title={needsMemberStep ? `${title} — choose member` : title} onClose={onClose} wide>
      {needsMemberStep ? (
        <OptionList institutionId={institutionId} source="member" scope={scope} onPick={(option) => setMemberId(option.id)} />
      ) : (
        <OptionList institutionId={institutionId} source={source} scope={effectiveScope} onPick={onPick} />
      )}
    </Dialog>
  );
}
