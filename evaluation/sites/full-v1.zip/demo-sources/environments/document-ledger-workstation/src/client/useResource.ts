import { useCallback, useEffect, useRef, useState } from 'react';

import { getJson } from './api.js';
import { LatestOnly } from './model/paged.js';

export interface Resource<T> {
  data: T | undefined;
  error: string | null;
  loading: boolean;
  reload: () => void;
}

/**
 * Loads one JSON resource. Data is tagged with the path that produced it and only returned for that path,
 * so switching records never shows the previous record's data, and a late response for an earlier path
 * is dropped. Refreshing the same path keeps the current data visible until the new response arrives.
 */
export function useResource<T>(path: string | null, refreshKey: unknown = null): Resource<T> {
  const [state, setState] = useState<{ path: string | null; data: T | undefined; error: string | null; settled: boolean }>({ path: null, data: undefined, error: null, settled: false });
  const latest = useRef<LatestOnly | null>(null);
  const [nonce, setNonce] = useState(0);
  useEffect(() => {
    latest.current ??= new LatestOnly();
    const runner = latest.current;
    if (path === null) { runner.cancel(); return; }
    setState((previous) => (previous.path === path ? { ...previous, settled: false } : { path, data: undefined, error: null, settled: false }));
    runner.run(
      (signal) => getJson<T>(path, signal),
      (data) => setState({ path, data, error: null, settled: true }),
      (error: unknown) => setState((previous) => ({ path, data: previous.path === path ? previous.data : undefined, error: error instanceof Error ? error.message : String(error), settled: true })),
    );
  }, [path, refreshKey, nonce]);
  useEffect(() => () => latest.current?.cancel(), []);
  const reload = useCallback(() => setNonce((value) => value + 1), []);
  const current = state.path === path;
  return { data: current ? state.data : undefined, error: current ? state.error : null, loading: !current || !state.settled, reload };
}
