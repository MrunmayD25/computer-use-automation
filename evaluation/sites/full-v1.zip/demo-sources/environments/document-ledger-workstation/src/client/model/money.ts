/** Exact-money helpers shared by the workstation client. Minor units are integers; no floats cross the wire. */

export interface MoneyInput {
  minorUnits: number;
  currency: string;
}

/** Formats minor units with the currency's exponent (default 2). */
export function formatMoney(minorUnits: number, currency: string, exponent = 2): string {
  const sign = minorUnits < 0 ? '-' : '';
  const absolute = Math.abs(minorUnits);
  const whole = Math.floor(absolute / 10 ** exponent);
  const fraction = exponent === 0 ? '' : `.${String(absolute % 10 ** exponent).padStart(exponent, '0')}`;
  return `${sign}${whole.toLocaleString('en-US')}${fraction} ${currency}`;
}

/**
 * Parses user-entered text into exact minor units.
 * Returns undefined for unparseable or fractional-overflow input instead of rounding.
 */
export function parseMoney(text: string, exponent = 2): number | undefined {
  const trimmed = text.trim().replaceAll(',', '');
  if (trimmed === '') return undefined;
  const match = /^([+-]?)(\d+)(?:\.(\d+))?$/u.exec(trimmed);
  if (match === null) return undefined;
  const negative = match[1] === '-';
  const whole = Number.parseInt(match[2] ?? '0', 10);
  const fractionText = match[3] ?? '';
  if (fractionText.length > exponent) return undefined;
  const fraction = fractionText === '' ? 0 : Number.parseInt(fractionText.padEnd(exponent, '0'), 10);
  const minorUnits = whole * 10 ** exponent + fraction;
  if (!Number.isSafeInteger(minorUnits)) return undefined;
  return negative ? -minorUnits : minorUnits;
}

export function formatInstant(iso: string | null | undefined): string {
  if (iso === null || iso === undefined || iso === '') return '—';
  return iso.slice(0, 19).replace('T', ' ');
}

export function formatDate(iso: string | null | undefined): string {
  if (iso === null || iso === undefined || iso === '') return '—';
  return iso.slice(0, 10);
}
