import { useCallback, useMemo, useRef, useState, type ReactNode } from 'react';

import { getJson, sendJson } from './api.js';
import { OPERATIONS, OPERATIONS_BY_KIND, SECTION_LABELS, SECTION_ORDER, type OperationSpec } from './operations/catalog.js';
import { OperationDialog } from './operations/OperationDialog.js';
import { ApprovalsPane } from './pages/ApprovalsPane.js';
import { ListPane } from './pages/ListPane.js';
import { MemberPage } from './pages/MemberPage.js';
import { AccountPage } from './pages/AccountPage.js';
import { CasePage } from './pages/CasePage.js';
import { DocumentPage } from './pages/DocumentPage.js';
import { RecordPane } from './pages/RecordPane.js';
import { MergePlanPane } from './pages/MergePlanPane.js';
import { MaintenancePane } from './pages/MaintenancePane.js';
import { LIST_KIND_LABELS, tabId, type WorkTab } from './router.js';
import type { InstitutionInfo, SessionInfo } from '../shared/api.js';
import { MenuButton, type MenuItem } from './ui/Menu.js';

export interface FocusInfo {
  area: string;
  record?: string | undefined;
  document?: string | undefined;
  page?: string | undefined;
  cell?: string | undefined;
  extra?: string | undefined;
}

export interface WorkContext {
  institutionId: string;
  asOf: string;
  openTab: (tab: Omit<WorkTab, 'id'>) => void;
  openOperation: (kind: string, initial?: Record<string, unknown>, approvalId?: string) => void;
  reportFocus: (focus: FocusInfo) => void;
  refresh: () => void;
  refreshKey: number;
  message: (text: string) => void;
}

const TREE_ROOTS: { label: string; tab: Omit<WorkTab, 'id'> }[] = [
  { label: 'Members', tab: { kind: 'members', title: 'Members', params: {} } },
  { label: 'Accounts', tab: { kind: 'accounts', title: 'Accounts', params: {} } },
  { label: 'Cases', tab: { kind: 'cases', title: 'Cases', params: {} } },
  { label: 'Documents', tab: { kind: 'documents', title: 'Documents', params: {} } },
  { label: 'Approvals', tab: { kind: 'approvals', title: 'Approvals', params: {} } },
  { label: 'Activity', tab: { kind: 'activity', title: 'Activity', params: {} } },
  { label: 'Saved searches', tab: { kind: 'saved-searches', title: 'Saved searches', params: {} } },
];

const RECORD_LISTS = Object.keys(LIST_KIND_LABELS);

export function App({ initialSession }: { initialSession: SessionInfo }): ReactNode {
  const [session, setSession] = useState(initialSession);
  const [institutionId, setInstitutionId] = useState(initialSession.institutions[0]?.institutionId ?? '');
  const [tabs, setTabs] = useState<WorkTab[]>([{ id: 'members:root:0', kind: 'members', title: 'Members', params: {} }]);
  const [activeId, setActiveId] = useState('members:root:0');
  const [operation, setOperation] = useState<{ spec: OperationSpec; initial?: Record<string, unknown>; approvalId?: string } | null>(null);
  const [focus, setFocus] = useState<FocusInfo>({ area: 'tree' });
  const [message, setMessage] = useState('Ready.');
  const [refreshKey, setRefreshKey] = useState(0);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({ records: false });
  const counter = useRef(0);

  const institution: InstitutionInfo | undefined = session.institutions.find((entry) => entry.institutionId === institutionId);

  const openTab = useCallback((tab: Omit<WorkTab, 'id'>): void => {
    counter.current += 1;
    const id = tabId(tab.kind, `${counter.current}`);
    setTabs((current) => [...current, { ...tab, id }]);
    setActiveId(id);
  }, []);

  const openOperation = useCallback((kind: string, initial?: Record<string, unknown>, approvalId?: string) => {
    const spec = OPERATIONS_BY_KIND.get(kind);
    if (spec === undefined) { setMessage(`No operation catalog entry for ${kind}.`); return; }
    setOperation({ spec, ...(initial === undefined ? {} : { initial }), ...(approvalId === undefined ? {} : { approvalId }) });
  }, []);

  const closeTab = useCallback((id: string) => {
    setTabs((current) => {
      const next = current.filter((tab) => tab.id !== id);
      if (next.length === 0) next.push({ id: 'members:root:0', kind: 'members', title: 'Members', params: {} });
      return next;
    });
    setActiveId((current) => current === id ? 'members:root:0' : current);
  }, []);

  const context = useMemo<WorkContext>(() => ({
    institutionId, asOf: institution?.asOf ?? '', openTab, openOperation,
    reportFocus: setFocus, refresh: () => setRefreshKey((value) => value + 1), refreshKey, message: setMessage,
  }), [institutionId, institution?.asOf, openTab, openOperation, refreshKey]);

  const switchOperator = useCallback(async (actorNumber: string) => {
    await sendJson('POST', '/api/session/operator', { actorNumber });
    setSession(await getJson<SessionInfo>('/api/session'));
    setMessage(`Signed on as ${actorNumber}.`);
  }, []);

  const operationsMenu = (section: string): MenuItem[] => OPERATIONS.filter((op) => op.section === section).map((op) => ({
    id: op.kind, label: op.title, onSelect: () => openOperation(op.kind),
  }));

  const activeTab = tabs.find((tab) => tab.id === activeId) ?? tabs[0];

  return (
    <div className="workstation">
      <header className="menubar" role="menubar">
        <span className="brand">Ledger Workstation</span>
        <MenuButton label="Workstation" items={() => [
          { id: 'about', label: `Bound to ${session.institutions.length} institution(s)`, onSelect: () => {} },
          { id: 'operator', label: `Operator ${session.operator?.actorNumber ?? '—'} (${session.operator?.displayName ?? 'not registered'})`, onSelect: () => {} },
        ]}>Workstation</MenuButton>
        {SECTION_ORDER.map((section) => (
          <MenuButton key={section} label={SECTION_LABELS[section]} items={() => operationsMenu(section)}>{SECTION_LABELS[section]}</MenuButton>
        ))}
        <span className="spacer" />
        <label className="toolbar-field">Institution
          <select value={institutionId} onChange={(event) => setInstitutionId(event.target.value)}>
            {session.institutions.map((entry) => <option key={entry.institutionId} value={entry.institutionId}>{entry.displayName}</option>)}
          </select>
        </label>
        <label className="toolbar-field">Operator
          <select value={session.operator?.actorNumber ?? ''} disabled={session.fixedOperator} onChange={(event) => void switchOperator(event.target.value)}>
            {session.allowedOperatorNumbers.map((number) => <option key={number} value={number}>{number}</option>)}
          </select>
        </label>
      </header>

      <div className="workbench">
        <nav className="tree" aria-label="Records">
          <div className="tree-node root">{institution?.displayName ?? institutionId}</div>
          {TREE_ROOTS.map((root) => (
            <button key={root.label} type="button" className="tree-node" onClick={() => openTab(root.tab)}>{root.label}</button>
          ))}
          <button type="button" className="tree-node" aria-expanded={openSections.records === true}
            onClick={() => setOpenSections((current) => ({ ...current, records: !(current.records ?? false) }))}>
            ▸ Record lists
          </button>
          {openSections.records === true ? (
            <div className="tree-children">
              {RECORD_LISTS.map((kind) => (
                <button key={kind} type="button" className="tree-node child"
                  onClick={() => openTab({ kind: 'list', title: LIST_KIND_LABELS[kind] ?? kind, params: { listKind: kind } })}>
                  {LIST_KIND_LABELS[kind]}
                </button>
              ))}
            </div>
          ) : null}
        </nav>

        <main className="workspace">
          <div className="tabs" role="tablist">
            {tabs.map((tab) => (
              <div key={tab.id} role="tab" aria-selected={tab.id === activeTab?.id} className={`tab${tab.id === activeTab?.id ? ' active' : ''}`}
                onClick={() => setActiveId(tab.id)}>
                <span>{tab.title}</span>
                <button type="button" className="tab-close" aria-label={`Close ${tab.title}`} onClick={(event) => { event.stopPropagation(); closeTab(tab.id); }}>×</button>
              </div>
            ))}
          </div>
          <div className="page">
            {activeTab === undefined ? <p className="muted">No open record.</p> : <TabBody tab={activeTab} context={context} />}
          </div>
        </main>

        <aside className="inspector" aria-label="Inspector">
          <h3>Inspector</h3>
          <dl>
            <dt>Area</dt><dd>{focus.area}</dd>
            <dt>Record</dt><dd>{focus.record ?? '—'}</dd>
            <dt>Document</dt><dd>{focus.document ?? '—'}</dd>
            <dt>Page</dt><dd>{focus.page ?? '—'}</dd>
            <dt>Cell</dt><dd>{focus.cell ?? '—'}</dd>
          </dl>
          {focus.extra !== undefined ? <pre className="inspector-extra">{focus.extra}</pre> : null}
        </aside>
      </div>

      <footer className="statusbar" data-testid="statusbar">
        <span>{institution?.displayName ?? ''}</span>
        <span>op {session.operator?.actorNumber ?? '—'}</span>
        <span data-testid="status-record">{focus.record ?? 'no record'}</span>
        <span data-testid="status-cell">{focus.cell ?? ''}</span>
        <span data-testid="status-focus">{focus.area}</span>
        <span className="status-message" data-testid="status-message">{message}</span>
      </footer>

      {operation !== null ? (
        <OperationDialog institutionId={institutionId} spec={operation.spec}
          initial={operation.initial} approvalId={operation.approvalId}
          onClose={() => setOperation(null)}
          onCommitted={(outcome) => {
            setRefreshKey((value) => value + 1);
            setMessage(outcome.kind === 'committed' ? `Committed ${outcome.receipt.receiptNumber}` : outcome.kind === 'rejected' ? `Rejected: ${outcome.message}` : outcome.kind === 'duplicate' ? `Duplicate → ${outcome.receipt.receiptNumber}` : 'Unchanged.');
          }} />
      ) : null}
    </div>
  );
}

function TabBody({ tab, context }: { tab: WorkTab; context: WorkContext }): ReactNode {
  switch (tab.kind) {
    case 'members': return <ListPane entity="members" context={context} params={tab.params} />;
    case 'accounts': return <ListPane entity="accounts" context={context} params={tab.params} />;
    case 'cases': return <ListPane entity="cases" context={context} params={tab.params} />;
    case 'documents': return <ListPane entity="documents" context={context} params={tab.params} />;
    case 'activity': return <ListPane entity="activity" context={context} params={tab.params} />;
    case 'saved-searches': return <ListPane entity="saved-searches" context={context} params={tab.params} />;
    case 'approvals': return <ApprovalsPane context={context} />;
    case 'list': return <ListPane entity="scoped" context={context} params={tab.params} />;
    case 'member': return <MemberPage memberId={tab.params.id ?? ''} context={context} />;
    case 'account': return <AccountPage accountId={tab.params.id ?? ''} context={context} />;
    case 'case': return <CasePage caseId={tab.params.id ?? ''} context={context} />;
    case 'document': return <DocumentPage versionId={tab.params.id ?? ''} context={context} />;
    case 'receipt': return <RecordPane resource="receipt" id={tab.params.id ?? ''} context={context} />;
    case 'record': return <RecordPane resource={tab.params.resource ?? ''} id={tab.params.id ?? ''} context={context} />;
    case 'merge-plan': return <MergePlanPane planId={tab.params.id ?? ''} context={context} />;
    case 'maintenance': return <MaintenancePane memberId={tab.params.id ?? ''} context={context} />;
    default: return <p className="muted">Unknown tab.</p>;
  }
}
