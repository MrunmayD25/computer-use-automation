/** Pan/zoom viewport math for canvas surfaces. All positions are in content units; screens multiply by zoom and subtract scroll. */

export interface Viewport {
  /** Content-space offset of the visible region's top-left corner. */
  scrollX: number;
  scrollY: number;
  zoom: number;
  /** Viewport pixel size. */
  width: number;
  height: number;
}

export const MIN_ZOOM = 0.25;
export const MAX_ZOOM = 4;

export function clampZoom(zoom: number): number {
  return Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, zoom));
}

export function screenToContent(viewport: Viewport, x: number, y: number): { x: number; y: number } {
  return { x: x / viewport.zoom + viewport.scrollX, y: y / viewport.zoom + viewport.scrollY };
}

export function contentToScreen(viewport: Viewport, x: number, y: number): { x: number; y: number } {
  return { x: (x - viewport.scrollX) * viewport.zoom, y: (y - viewport.scrollY) * viewport.zoom };
}

/** Clamps scroll so the content never detaches from the viewport edges. */
export function clampScroll(viewport: Viewport, contentWidth: number, contentHeight: number): Viewport {
  const maxX = Math.max(0, contentWidth - viewport.width / viewport.zoom);
  const maxY = Math.max(0, contentHeight - viewport.height / viewport.zoom);
  return { ...viewport, scrollX: Math.min(Math.max(0, viewport.scrollX), maxX), scrollY: Math.min(Math.max(0, viewport.scrollY), maxY) };
}

/** Zooms keeping the content point under `anchor` fixed on screen. */
export function zoomAt(viewport: Viewport, anchor: { x: number; y: number }, nextZoom: number): Viewport {
  const zoom = clampZoom(nextZoom);
  const anchorContent = screenToContent(viewport, anchor.x, anchor.y);
  return {
    ...viewport,
    zoom,
    scrollX: anchorContent.x - anchor.x / zoom,
    scrollY: anchorContent.y - anchor.y / zoom,
  };
}
