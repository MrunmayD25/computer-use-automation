import { useCallback, useMemo, useRef, useState, type ReactNode } from 'react';

import type { CommandOutcome, OperationReview, ServiceCommand } from '@computer-use/financial-database/services';

import { executeCommand, newIdempotencyKey, reviewCommand } from '../api.js';
import { Dialog } from '../ui/Dialog.js';
import type { FieldSpec, OperationSpec } from './catalog.js';
import { buildCommand, FieldControl, type Values } from './fields.js';
import { PickerDialog } from './PickerDialog.js';
import { fetchAuto, type PickerOption, type PickerScope } from './sources.js';

type Outcome = CommandOutcome;

interface OperationDialogProps {
  institutionId: string;
  spec: OperationSpec;
  initial?: Values | undefined;
  /** For gated commands: prefill a decided approval (checker executing the approved target). */
  approvalId?: string | undefined;
  onClose: () => void;
  onCommitted: (outcome: Outcome) => void;
}

/** Rebuilds the command, then reviews or commits it. */
async function runOutcome(institutionId: string, command: Record<string, unknown>, key: string, review: boolean): Promise<{ outcome?: Outcome | undefined; review?: OperationReview | undefined }> {
  if (review) {
    const body = await reviewCommand(institutionId, command as ServiceCommand);
    const outcome = body.outcome;
    if (outcome.kind === 'reviewable') return { review: outcome.review };
    if (outcome.kind === 'rejected') return { outcome: outcome };
    return { outcome };
  }
  const body = await executeCommand(institutionId, command as ServiceCommand, key);
  return { outcome: body.outcome };
}

export function OperationDialog({ institutionId, spec, initial, approvalId, onClose, onCommitted }: OperationDialogProps): ReactNode {
  const [values, setValues] = useState<Values>(() => ({ ...(initial ?? {}), ...(approvalId === undefined ? {} : { approvalId }) }));
  const [currencies, setCurrencies] = useState<Record<string, string>>({});
  const [, setDerived] = useState<Record<string, Record<string, unknown>>>({});
  const [problems, setProblems] = useState<string[]>([]);
  const [review, setReview] = useState<OperationReview | null>(null);
  const [reviewedJson, setReviewedJson] = useState<string | null>(null);
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [busy, setBusy] = useState<null | 'review' | 'commit' | 'request'>(null);
  const [pickingChecker, setPickingChecker] = useState(false);
  const idempotencyKey = useRef(newIdempotencyKey(spec.kind));
  const [approval, setApproval] = useState<Record<string, unknown>>({});

  const scopeFor = useCallback((field: FieldSpec): PickerScope => ({
    memberId: field.memberFrom === undefined ? undefined : values[field.memberFrom] as string | undefined,
    accountId: field.accountFrom === undefined ? undefined : values[field.accountFrom] as string | undefined,
    scopeId: field.scopeFrom === undefined ? undefined : values[field.scopeFrom] as string | undefined,
    values, commandKind: spec.kind,
  }), [values, spec.kind]);

  const setValue = useCallback((name: string, value: unknown) => {
    setValues((current) => ({ ...current, [name]: value }));
    setReview(null);
    setReviewedJson(null);
    setOutcome(null);
  }, []);

  const onPick = useCallback((field: FieldSpec, option: PickerOption) => {
    setValue(field.name, option.id);
    const record = option.record ?? {};
    // Fills: copy option fields into sibling fields.
    for (const fill of field.fills ?? []) {
      const next = record[fill.from] ?? (record.fields as Record<string, unknown> | undefined)?.[fill.from];
      if (next !== undefined) setValue(fill.field, next);
    }
    void (async () => {
      const source = field.control.type === 'picker' || field.control.type === 'picker-multi' ? field.control.source : 'member';
      const auto = await fetchAuto(institutionId, source, option.id, scopeFor(field));
      setDerived((current) => ({ ...current, [field.name]: { ...record, ...auto } }));
      const currency = auto.currency ?? record.currency;
      if (typeof currency === 'string' && currency !== '') setCurrencies((current) => ({ ...current, [field.name]: currency }));
      // Derived fields bound to this picker.
      for (const target of spec.fields) {
        if (target.auto === undefined || target.auto.from !== field.name) continue;
        const next = auto[target.auto.property] ?? record[target.auto.property];
        if (next !== undefined) setValue(target.name, next);
      }
    })();
  }, [institutionId, scopeFor, setValue, spec.fields]);

  const visibleFields = useMemo(
    () => spec.fields.filter((field) => field.when === undefined || field.when.oneOf.includes(values[field.when.field])),
    [spec.fields, values],
  );

  const submit = async (mode: 'review' | 'commit' | 'request'): Promise<void> => {
    const built = buildCommand(spec.kind, visibleFields, values);
    if (built.problems.length > 0 || built.command === undefined) { setProblems(built.problems); return; }
    const command = built.command;
    setBusy(mode);
    setProblems([]);
    try {
      if (mode === 'request') {
        if (typeof approval.checkerActorId !== 'string' || approval.checkerActorId === ''
          || typeof approval.policyVersionId !== 'string' || approval.policyVersionId === ''
          || typeof approval.expiresAt !== 'string' || approval.expiresAt === '') {
          setProblems(['Choose a checker, policy version, and expiry for the approval request.']);
          return;
        }
        const request = {
          kind: 'approval.request', target: command,
          checkerActorId: approval.checkerActorId, policyVersionId: approval.policyVersionId,
          expiresAt: approval.expiresAt,
          amountLimit: approval.amountLimit ?? null,
        };
        const result = await runOutcome(institutionId, request, newIdempotencyKey('approval.request'), false);
        setOutcome(result.outcome ?? null);
        if (result.outcome?.kind === 'committed') onCommitted(result.outcome);
        return;
      }
      const result = await runOutcome(institutionId, command, idempotencyKey.current, mode === 'review');
      if (result.review !== undefined) { setReview(result.review); setReviewedJson(JSON.stringify(command)); }
      if (result.outcome !== undefined) {
        setOutcome(result.outcome);
        if (result.outcome.kind === 'committed' || result.outcome.kind === 'duplicate' || result.outcome.kind === 'unchanged') onCommitted(result.outcome);
      }
    } catch (error) {
      setOutcome({ kind: 'rejected', code: 'validation', message: error instanceof Error ? error.message : String(error) });
    } finally {
      setBusy(null);
    }
  };

  return (
    <Dialog title={spec.title} onClose={onClose} wide
      footer={(
        <>
          <span className="muted idem">key {idempotencyKey.current.slice(0, 24)}…</span>
          <button type="button" className="tool-button" disabled={busy !== null} onClick={() => void submit('review')}>Review</button>
          {spec.gated === true ? (
            <button type="button" className="primary" disabled={busy !== null} onClick={() => void submit('request')}>Request approval</button>
          ) : (
            <button type="button" className="primary" disabled={busy !== null || review === null} onClick={() => void submit('commit')}>Commit</button>
          )}
          <button type="button" className="tool-button" onClick={onClose}>Close</button>
        </>
      )}>
      {spec.description !== undefined ? <p className="muted">{spec.description}</p> : null}
      <div className="op-fields">
        {visibleFields.map((field) => (
          <div key={field.name} className={`op-field${field.control.type === 'hidden' ? ' auto' : ''}`}>
            <span className="field-label">{field.label}{field.required === true ? ' *' : ''}</span>
            <FieldControl field={field} context={{ institutionId, values, currencies, setValue, onPick, scopeFor, asOf: '' }} />
            {field.help !== undefined ? <span className="field-help">{field.help}</span> : null}
          </div>
        ))}
      </div>
      {spec.gated === true ? (
        <fieldset className="approval-box">
          <legend>Independent approval</legend>
          <div className="op-field">
            <span className="field-label">Checker *</span>
            <div className="picker-field">
              <span className="picker-value">{typeof approval.checkerActorId === 'string' ? approval.checkerActorId : <em className="muted">Not selected</em>}</span>
              <button type="button" className="tool-button" onClick={() => setPickingChecker(true)}>Choose…</button>
            </div>
          </div>
          <div className="op-field">
            <span className="field-label">Policy version *</span>
            <PolicyPicker value={approval.policyVersionId} institutionId={institutionId} onPick={(id) => setApproval((a) => ({ ...a, policyVersionId: id }))} />
          </div>
          <div className="op-field">
            <span className="field-label">Expires at *</span>
            <input className="field-input" type="datetime-local" value={typeof approval.expiresAt === 'string' ? approval.expiresAt : ''} onChange={(e) => setApproval((a) => ({ ...a, expiresAt: e.target.value }))} />
          </div>
          <div className="op-field">
            <span className="field-label">Amount limit</span>
            <AmountLimit value={approval.amountLimit} onChange={(v) => setApproval((a) => ({ ...a, amountLimit: v }))} />
          </div>
          {pickingChecker ? (
            <PickerDialog institutionId={institutionId} source="checker" scope={{ values, commandKind: spec.kind }} title="Approval checker"
              onPick={(option) => { setApproval((a) => ({ ...a, checkerActorId: option.id })); setPickingChecker(false); }} onClose={() => setPickingChecker(false)} />
          ) : null}
        </fieldset>
      ) : null}
      {problems.length > 0 ? <ul className="form-error" role="alert">{problems.map((problem) => <li key={problem}>{problem}</li>)}</ul> : null}
      {review !== null ? (
        <div className="review-box" data-testid="op-review">
          <h3>Reviewed terms — {review.institutionName}</h3>
          {reviewedJson !== null && reviewedJson !== JSON.stringify(buildCommand(spec.kind, visibleFields, values).command ?? {}) ? (
            <p className="stale-warning" role="alert">Fields changed after this review — review again before committing.</p>
          ) : null}
          {review.description !== null ? <p className="review-line">{review.description}</p> : null}
          {review.amount !== null ? <p className="review-line">Amount: {(review.amount.minorUnits / 10 ** (review.exponent ?? 2)).toFixed(review.exponent ?? 2)} {review.amount.currency}</p> : null}
          {review.accounts.map((account) => (
            <p key={account.id} className="review-line">{account.accountNumber} — posted {account.postedBeforeMinorUnits} → {account.postedAfterMinorUnits} · available {account.availableBeforeMinorUnits} → {account.availableAfterMinorUnits}</p>
          ))}
          {review.consequences.map((line) => <p key={line} className="review-line issue">{line}</p>)}
        </div>
      ) : null}
      {outcome !== null ? (
        <div className={`outcome-box ${outcome.kind}`} data-testid="op-outcome">
          {outcome.kind === 'committed' ? <p>Committed — receipt {outcome.receipt.receiptNumber}: {outcome.receipt.affected.map((a) => `${a.kind} ${a.label}`).join(', ') || outcome.receipt.operationKind}</p> : null}
          {outcome.kind === 'duplicate' ? <p>Duplicate — original receipt {outcome.receipt.receiptNumber} returned.</p> : null}
          {outcome.kind === 'unchanged' ? <p>Unchanged — {outcome.message}</p> : null}
          {outcome.kind === 'rejected' ? <p>Rejected [{outcome.code}] — {outcome.message}</p> : null}
        </div>
      ) : null}
    </Dialog>
  );
}

function PolicyPicker({ institutionId, value, onPick }: { institutionId: string; value: unknown; onPick: (id: string) => void }): ReactNode {
  const [open, setOpen] = useState(false);
  return (
    <>
      <div className="picker-field">
        <span className="picker-value">{typeof value === 'string' && value !== '' ? value : <em className="muted">Not selected</em>}</span>
        <button type="button" className="tool-button" onClick={() => setOpen(true)}>Choose…</button>
      </div>
      {open ? (
        <PickerDialog institutionId={institutionId} source="policyVersion" scope={{ values: {} }} title="Policy version"
          onPick={(option) => { onPick(option.id); setOpen(false); }} onClose={() => setOpen(false)} />
      ) : null}
    </>
  );
}

function AmountLimit({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }): ReactNode {
  const money = (value ?? {}) as { minorUnits?: number; currency?: string };
  return (
    <div className="money-field">
      <input className="field-input" inputMode="decimal" placeholder="optional 0.00"
        value={money.minorUnits === undefined ? '' : (money.minorUnits / 100).toFixed(2)}
        onChange={(e) => {
          if (e.target.value === '') { onChange(null); return; }
          const parsed = Number(e.target.value);
          if (Number.isFinite(parsed)) onChange({ minorUnits: Math.round(parsed * 100), currency: money.currency ?? 'USD' });
        }} />
      <input className="field-input small" placeholder="CCY" maxLength={3} value={money.currency ?? ''}
        onChange={(e) => onChange({ minorUnits: money.minorUnits ?? 0, currency: e.target.value.toUpperCase() })} />
    </div>
  );
}
