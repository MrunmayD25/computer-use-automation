import { FloatingFocusManager, FloatingOverlay, FloatingPortal, useDismiss, useFloating, useInteractions, useRole } from '@floating-ui/react';
import { useId, type ReactNode } from 'react';

interface DialogProps {
  title: string;
  /** Called on Escape or the close button; a dialog that must not close yet ignores it. */
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}

/** Modal dialog in a portal outside the workspace tree. Focus is trapped inside and returned on close. */
export function Dialog({ title, onClose, children, footer, wide }: DialogProps): ReactNode {
  const { refs, context } = useFloating({ open: true, onOpenChange: (open) => { if (!open) onClose(); } });
  const { getFloatingProps } = useInteractions([useDismiss(context, { outsidePress: false }), useRole(context, { role: 'dialog' })]);
  const titleId = useId();
  return (
    <FloatingPortal>
      <FloatingOverlay className="dialog-backdrop" lockScroll>
        <FloatingFocusManager context={context}>
          <div ref={(node) => refs.setFloating(node)} className={wide === true ? 'dialog wide' : 'dialog'} aria-labelledby={titleId} aria-modal="true" {...getFloatingProps()}>
            <header className="dialog-header">
              <h2 id={titleId}>{title}</h2>
              <button type="button" className="icon-button" aria-label="Close dialog" onClick={onClose}>×</button>
            </header>
            <div className="dialog-body">{children}</div>
            {footer === undefined ? null : <footer className="dialog-footer">{footer}</footer>}
          </div>
        </FloatingFocusManager>
      </FloatingOverlay>
    </FloatingPortal>
  );
}
