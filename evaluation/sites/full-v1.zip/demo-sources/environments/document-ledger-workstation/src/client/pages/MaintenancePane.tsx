import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { getJson, institutionPath } from '../api.js';
import type { WorkContext } from '../App.js';

interface RequestRow { requestId: string; requestNumber: string; state: string; category: string; subject: string; updatedAt: string; requestedCommand?: unknown }

/** Member maintenance requests with the draft→submit→review→process/withdraw lifecycle actions. */
export function MaintenancePane({ memberId, context }: { memberId: string; context: WorkContext }): ReactNode {
  const [rows, setRows] = useState<RequestRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const base = institutionPath(context.institutionId, '');

  const load = useCallback(async () => {
    try {
      setRows(await getJson<RequestRow[]>(`${base}/members/${encodeURIComponent(memberId)}/maintenance-requests`));
      setError(null);
      context.reportFocus({ area: 'maintenance', record: memberId });
    } catch (cause) { setError(cause instanceof Error ? cause.message : String(cause)); }
  }, [base, memberId]);

  useEffect(() => { void load(); }, [load, context.refreshKey]);

  return (
    <section className="maintenance-pane">
      <div className="list-toolbar">
        <h2>Maintenance requests</h2>
        <button type="button" className="tool-button" onClick={() => context.openOperation('maintenance.draft.save', { memberId })}>New draft…</button>
        <button type="button" className="tool-button" onClick={() => void load()}>Refresh</button>
      </div>
      {error !== null ? <p className="form-error" role="alert">{error}</p> : null}
      {rows === null ? null : (
        <table className="list-table">
          <thead><tr><th>Request</th><th>State</th><th>Subject</th><th>Updated</th><th>Actions</th></tr></thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.requestId}>
                <td className="mono">{row.requestNumber}</td>
                <td>{row.state}</td>
                <td>{row.subject}</td>
                <td>{row.updatedAt}</td>
                <td className="row-actions">
                  <button type="button" className="tool-button" onClick={() => context.openOperation('maintenance.draft.amend', { requestId: row.requestId, memberId })}>Amend</button>
                  <button type="button" className="tool-button" onClick={() => context.openOperation('maintenance.request.submit', { requestId: row.requestId, memberId })}>Submit</button>
                  <button type="button" className="tool-button" onClick={() => context.openOperation('maintenance.request.review', { requestId: row.requestId, memberId })}>Review</button>
                  <button type="button" className="tool-button" onClick={() => context.openOperation('maintenance.request.process', { requestId: row.requestId, memberId })}>Process</button>
                  <button type="button" className="tool-button" onClick={() => context.openOperation('maintenance.request.withdraw', { requestId: row.requestId, memberId })}>Withdraw</button>
                  <button type="button" className="tool-button" onClick={() => context.openOperation('edit.cancel', { requestId: row.requestId, memberId })}>Cancel</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}
