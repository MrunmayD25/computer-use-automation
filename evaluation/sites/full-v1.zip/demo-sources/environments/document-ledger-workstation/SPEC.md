# Document & Ledger Workstation — specification

A document and ledger desktop modeled on scanned-document viewers and browser spreadsheet
editors. One Express process serves the React shell and the JSON API; the shared financial
database (`../database/financial`) owns all business data, mutations, approvals, receipts,
and document bytes.

## Identity

- **Package:** `document-ledger-workstation` (private, ESM, Node ≥ 25.9)
- **Entry URL:** `http://localhost:4173/` by default (`--port` configurable)
- **Family:** document/ledger workstation — canvas surfaces plus DOM chrome
- **Institutions:** every dataset binding of the opened financial world (`/api/i/:institutionId/…`)

## Structural mechanisms (the distinctive surface)

- **Ledger canvas** (`src/client/canvas/GridCanvas.tsx`): a real `<canvas>` grid painting
  account transactions and CSV document rows. Hit testing maps screen coordinates through
  zoom and scroll to `(row, column)`; frozen columns and a frozen header stay pinned;
  wheel scroll pans, Ctrl+wheel zooms around the pointer; arrow keys move the selection;
  a second click on the same cell inside 500 ms opens an editable DOM overlay positioned
  over the cell. Only the Description column is editable — all other cells report that
  they are protected in the status bar.
- **Document canvas** (`src/client/canvas/DocumentCanvas.tsx`): pages are stacked
  vertically and centered; words come from a real positioned-text layer extracted from
  document bytes server-side (`pdftotext -bbox` for PDFs, CSV cell geometry for CSV
  documents, raw pixels for images). Clicking a word names it in the status bar;
  Shift+drag marks a normalized region and opens the annotation operation prefilled.
- **DOM chrome:** menu bar with the full operation catalog grouped by domain section,
  a record tree, a tab strip, an inspector showing area/record/document/page/cell, and a
  status bar carrying institution, operator, record, cell, focus area, and the last
  service message. Dialogs are genuine DOM (`<dialog>`), pickers are two-step where a
  member scope is required.
- **Focus contract:** every canvas interaction reports the active record, cell, word, or
  page to the status bar and inspector so keyboard and pointer focus are always
  identifiable.

## Business surface

- **Operation catalog** (`src/client/operations/catalog.ts`): 102 `ServiceCommand` kinds
  covering T001–T102 command capabilities, grouped into eleven menu sections
  (Members, Accounts, Teller & corrections, Payments & beneficiaries, Cards & disputes,
  Loans, Documents, Cases, Servicing & maintenance, Reconciliation, Searches).
- Every command runs review → commit → receipt through `reviewCommand`/`executeCommand`
  with an explicit idempotency key shown in the dialog footer. Thirty-eight gated
  commands surface the maker/checker path: the dialog collects checker, policy version,
  and expiry, submits `approval.request`, then the checker decides via `approval.decide`
  from the Approvals pane before the target commit carries `approvalId`.
- Derived fields (versions, fingerprints, calendars, eligibility) are fetched from the
  server at pick time — never typed in — so stale-version and fingerprint checks are real.
- Correction commands (`transaction.effective_date.correct`, `transaction.description.update`,
  reversal kinds) are the only write path for ledger history; the immutable journal is
  never edited.

## Query surfaces

- Members, accounts, cases, documents, activity, saved searches, approvals: paged list
  panes with server-side filters.
- Scoped record lists (`/api/i/:i/lists?kind=…`) covering beneficiaries, payments,
  schedules, cards, disputes, loans, fees, batches, suspense, cash sessions, merge plans,
  calendar days, products, member histories, consents, and servicing evidence — the
  picker/inspector sources for every scoped field.
- Statement data, HTML/CSV/PDF statement exports, transaction CSV, stored document bytes
  (digest headers), customer export artifacts, and document text layouts.
- Reconciliation inquiries (`transfer`, `settlement_batch`, `batch.preview`, `cash_day`)
  through `queryFinance`; record snapshots with complete-state fingerprints through
  `readFinanceRecord`.

## Shared entities

Members, accounts, journals/transactions, statements, documents and versions,
annotations, signatures, receipts, cases, approvals, beneficiaries, payments, schedules,
cards, disputes, loans, batches, suspense items, maintenance requests, merge plans,
communication jobs, consents, retention holds, saved searches — all owned by the
financial database package. This application keeps no authoritative business copy.

## Completion criteria

- Typecheck, lint, unit/model tests, API tests, and Playwright verification pass.
- Canvas evidence: cell/word hit testing at multiple zoom/scroll positions, frozen
  regions, editable overlay, annotation drag-select persisted with the version bound.
- Cross-app evidence: a note committed here is read through
  `virtualized-service-workspace`; a peer write is visible here; a stale fingerprint is
  refused.
- The canonical demonstration database is never mutated by verification
  (`canonical-guard.ts` fingerprints it before and after the run).

