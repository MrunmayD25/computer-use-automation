import { describe, expect, it } from 'vitest';

import { cellScreenRect, columnOffsets, contentHeight, contentWidth, hitTest, normalize, pageCell, scrollCellIntoView, visibleRowRange, type GridGeometry } from '../src/client/model/grid.js';
import { formatMoney, parseMoney } from '../src/client/model/money.js';
import { documentContentSize, documentHitTest, normalizeRect, pagePlacements, wordsInRect } from '../src/client/model/document.js';
import { clampScroll, clampZoom, screenToContent, zoomAt, type Viewport } from '../src/client/model/viewport.js';
import type { DocumentPageLayout } from '../src/shared/api.js';

const GEOMETRY: GridGeometry = {
  columns: [
    { key: 'date', label: 'Date', width: 100 },
    { key: 'ref', label: 'Reference', width: 150 },
    { key: 'desc', label: 'Description', width: 300 },
  ],
  rowHeight: 20,
  headerHeight: 30,
  rowCount: 100,
  frozenColumns: 1,
  frozenRows: 0,
};

describe('grid geometry', () => {
  it('computes content size and column offsets', () => {
    expect(contentWidth(GEOMETRY)).toBe(550);
    expect(contentHeight(GEOMETRY)).toBe(30 + 2000);
    expect(columnOffsets(GEOMETRY.columns)).toEqual([0, 100, 250]);
  });

  it('hit-tests frozen columns, scrolled cells, and headers', () => {
    const viewport: Viewport = { scrollX: 40, scrollY: 200, zoom: 1, width: 400, height: 300 };
    // Frozen column: screen x<100 maps to content x directly; screen y=60 → content 30+30+200=260 → row 11.
    expect(hitTest(GEOMETRY, viewport, 50, 60)).toEqual({ region: 'frozen-column', row: 11, column: 0 });
    // Scrolled region: content x = 100 + (260-100) + 40 = 300 → column 2.
    expect(hitTest(GEOMETRY, viewport, 260, 60)).toEqual({ region: 'cell', row: 11, column: 2 });
    // Header row.
    expect(hitTest(GEOMETRY, viewport, 260, 10)).toEqual({ region: 'header', row: -1, column: 2 });
    // Past the last row.
    expect(hitTest(GEOMETRY, viewport, 260, 2080)).toEqual({ region: 'outside', row: -1, column: -1 });
  });

  it('hit testing respects zoom', () => {
    const viewport: Viewport = { scrollX: 0, scrollY: 0, zoom: 2, width: 400, height: 300 };
    // At zoom 2 row 5 (content y 130..150) spans screen y 260..300; frozen col spans screen x 0..200.
    expect(hitTest(GEOMETRY, viewport, 50, 265).row).toBe(5);
    expect(hitTest(GEOMETRY, viewport, 210, 265)).toEqual({ region: 'cell', row: 5, column: 1 });
  });

  it('pins frozen rows during vertical scroll', () => {
    const frozen = { ...GEOMETRY, frozenRows: 1 };
    const viewport: Viewport = { scrollX: 0, scrollY: 500, zoom: 1, width: 400, height: 300 };
    // Pinned height = 30+20 = 50. y=40 is the frozen row; y=60 → content 50+10+500=560 → row 26.
    expect(hitTest(frozen, viewport, 150, 40)).toEqual({ region: 'frozen-row', row: 0, column: 1 });
    expect(hitTest(frozen, viewport, 150, 60)).toEqual({ region: 'cell', row: 26, column: 1 });
  });

  it('scrolls cells into view', () => {
    const viewport: Viewport = { scrollX: 0, scrollY: 0, zoom: 1, width: 400, height: 200 };
    const next = scrollCellIntoView(GEOMETRY, viewport, { row: 20, column: 2 });
    expect(next.scrollY).toBeGreaterThan(0);
    const rect = cellScreenRect(GEOMETRY, next, 20, 2);
    expect(rect.y + rect.height).toBeLessThanOrEqual(200 + 0.001);
  });

  it('reports the visible row window', () => {
    const viewport: Viewport = { scrollX: 0, scrollY: 200, zoom: 1, width: 400, height: 200 };
    const range = visibleRowRange(GEOMETRY, viewport);
    expect(range.first).toBe(10);
    expect(range.last).toBe(20);
  });

  it('binds cells to business rows and clamps refs', () => {
    const rows = [{ id: 'a' }, { id: 'b' }];
    const cell = pageCell(rows, { row: 1, column: 2 }, (row) => row.id);
    expect(cell).toEqual({ row: 1, column: 2, key: 'r1c2', rowKey: 'b' });
    expect(pageCell(rows, { row: 9, column: 0 }, (row) => row.id)).toBeNull();
    expect(normalize({ row: -2, column: 99 }, 5, 3)).toEqual({ row: 0, column: 2 });
  });
});

describe('viewport', () => {
  it('clamps scroll and zoom to content bounds', () => {
    const viewport: Viewport = { scrollX: -50, scrollY: 900, zoom: 1, width: 300, height: 200 };
    const clamped = clampScroll(viewport, 500, 400);
    expect(clamped.scrollX).toBe(0);
    expect(clamped.scrollY).toBe(200);
    expect(clampZoom(99)).toBe(4);
    expect(clampZoom(0.01)).toBe(0.25);
  });

  it('zooms around the pointer', () => {
    const viewport: Viewport = { scrollX: 100, scrollY: 50, zoom: 1, width: 300, height: 200 };
    const next = zoomAt(viewport, { x: 150, y: 100 }, 2);
    expect(screenToContent(next, 150, 100)).toEqual({ x: 250, y: 150 });
  });

  it('maps screen to content through zoom and scroll', () => {
    const viewport: Viewport = { scrollX: 40, scrollY: 20, zoom: 2, width: 300, height: 200 };
    expect(screenToContent(viewport, 100, 60)).toEqual({ x: 90, y: 50 });
  });
});

describe('money', () => {
  it('parses and formats exact amounts', () => {
    expect(parseMoney('12.34')).toBe(1234);
    expect(parseMoney('-0.01')).toBe(-1);
    expect(parseMoney('abc')).toBeUndefined();
    expect(parseMoney('1.005')).toBeUndefined();
    expect(formatMoney(1234, 'USD')).toBe('12.34 USD');
    expect(formatMoney(-5, 'USD')).toBe('-0.05 USD');
    expect(formatMoney(1234567, 'USD')).toBe('12,345.67 USD');
  });
});

describe('document model', () => {
  const pages: DocumentPageLayout[] = [
    { pageNumber: 1, width: 612, height: 792, words: [{ text: 'Balance', x: 44, y: 100, width: 60, height: 12 }] },
    { pageNumber: 2, width: 612, height: 792, words: [] },
  ];

  it('stacks pages vertically with gaps, centered in the scroll area', () => {
    const placements = pagePlacements(pages, 1000);
    expect(placements[0]).toMatchObject({ pageNumber: 1, x: 194, y: 24, width: 612 });
    expect(placements[1]).toMatchObject({ pageNumber: 2, y: 24 + 792 + 24 });
    expect(documentContentSize(pages, 1000)).toEqual({ width: 1000, height: 840 + 792 + 24 });
  });

  it('hit-tests words and pages', () => {
    const placements = pagePlacements(pages, 1000);
    const viewport: Viewport = { scrollX: 0, scrollY: 0, zoom: 1, width: 1000, height: 800 };
    const hit = documentHitTest(placements, pages, viewport, 250, 130);
    expect(hit?.pageNumber).toBe(1);
    expect(hit?.word?.text).toBe('Balance');
    expect(documentHitTest(placements, pages, viewport, 300, 900)?.pageNumber).toBe(2);
    expect(documentHitTest(placements, pages, viewport, 300, 3000)).toBeNull();
    // A point between pages hits no page.
    expect(documentHitTest(placements, pages, viewport, 300, 830)).toBeNull();
  });

  it('normalizes drag rectangles and collects enclosed words', () => {
    const rect = normalizeRect(1, { x: 200, y: 300 }, { x: 100, y: 250 });
    expect(rect).toEqual({ pageNumber: 1, x: 100, y: 250, width: 100, height: 50 });
    const page = pages[0];
    expect(wordsInRect(page as DocumentPageLayout, rect).length).toBe(0);
    expect(wordsInRect(page as DocumentPageLayout, normalizeRect(1, { x: 0, y: 0 }, { x: 200, y: 200 })).map((word) => word.text)).toEqual(['Balance']);
  });
});
