import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import { startTestWorkspace, type TestWorkspace } from './support.js';

let workspace: TestWorkspace;

beforeAll(async () => {
  workspace = await startTestWorkspace();
});

afterAll(async () => {
  await workspace.close();
});

const BASE = '/api/i/northstar';

interface Page<T = Record<string, unknown>> { items: T[]; total: number; offset: number }
interface SessionBody {
  institutions: { institutionId: string; datasetId: string; displayName: string; timeZone: string; defaultCurrency: string }[];
  operator: { actorId: string; actorNumber: string; displayName: string; permissions: string[] } | null;
  allowedOperatorNumbers: string[];
  fixedOperator: boolean;
}

async function firstMember(): Promise<Record<string, unknown>> {
  const page = await workspace.client().json<Page>(`${BASE}/members?limit=1`);
  const member = page.items[0];
  if (member === undefined) throw new Error('No members in the test world.');
  return member;
}

async function firstAccount(): Promise<Record<string, unknown>> {
  const page = await workspace.client().json<Page>(`${BASE}/accounts?limit=1`);
  const account = page.items[0];
  if (account === undefined) throw new Error('No accounts in the test world.');
  return account;
}

describe('session and reference', () => {
  it('answers health and session', async () => {
    const client = workspace.client();
    const health = await client.json<{ status: string; applicationId: string }>('/healthz');
    expect(health.status).toBe('ok');
    const session = await client.json<SessionBody>('/api/session');
    expect(session.institutions.map((institution) => institution.institutionId)).toContain('northstar');
    expect(session.operator?.actorNumber).toBe('OP0002');
    expect(session.fixedOperator).toBe(false);
  });

  it('switches operators within the configured set and rejects others', async () => {
    const client = workspace.client();
    const denied = await client.send('POST', '/api/session/operator', { actorNumber: 'OP0099' });
    expect(denied.status).toBe(403);
    await client.json('/api/session/operator', { actorNumber: 'OP0003' });
    const session = await client.json<SessionBody>('/api/session');
    expect(session.operator?.actorNumber).toBe('OP0003');
    await client.json('/api/session/operator', { actorNumber: 'OP0002' });
  });

  it('rejects unknown institutions and cross-origin posts', async () => {
    const client = workspace.client();
    const unknown = await client.get('/api/i/nowhere/members');
    expect(unknown.status).toBe(404);
    const foreign = await client.send('POST', `${BASE}/commands`, { command: {}, idempotencyKey: 'x'.repeat(9) }, { origin: 'https://evil.example' });
    expect(foreign.status).toBe(403);
  });

  it('exposes reference data', async () => {
    const reference = await workspace.client().json<{ currencies: { code: string; exponent: number }[]; products: { code: string }[]; caseWorkers: { id: string }[] }>(`${BASE}/reference`);
    expect(reference.currencies.length).toBeGreaterThan(0);
    expect(reference.products.length).toBeGreaterThan(0);
  });
});

describe('record surfaces', () => {
  it('lists and details members', async () => {
    const client = workspace.client();
    const member = await firstMember();
    const detail = await client.json<{ member: { id: string; memberNumber: string }; notes: unknown[] }>(`${BASE}/members/${String(member.id)}`);
    expect(detail.member.memberNumber).toBe(member.memberNumber);
    const missing = await client.get(`${BASE}/members/no-such-member`);
    expect(missing.status).toBe(404);
  });

  it('lists accounts with detail, transactions, and a real CSV', async () => {
    const client = workspace.client();
    const account = await firstAccount();
    const detail = await client.json<{ account: { id: string; currency: string }; eligibility: { debit: unknown } }>(`${BASE}/accounts/${String(account.id)}`);
    expect(detail.account.id).toBe(account.id);
    const transactions = await client.json<Page>(`${BASE}/accounts/${String(account.id)}/transactions?limit=10`);
    expect(transactions.total).toBeGreaterThan(0);
    const csv = await client.get(`${BASE}/accounts/${String(account.id)}/transactions.csv`);
    expect(csv.status).toBe(200);
    expect(csv.headers.get('content-type')).toContain('text/csv');
    const text = await csv.text();
    expect(text.split('\n')[0]).toContain('account_number');
  });

  it('renders statement data, PDF, CSV, and HTML for a stored period', async () => {
    const client = workspace.client();
    const account = await firstAccount();
    const listing = await client.json<{ periods: { period: string }[] }>(`${BASE}/accounts/${String(account.id)}/statements`);
    const period = listing.periods[0]?.period;
    if (period === undefined) return; // small world may lack generated periods
    const data = await client.json<{ period: string; entries: unknown[]; account: { accountNumber: string } }>(`${BASE}/accounts/${String(account.id)}/statement?period=${period}`);
    expect(data.period).toBe(period);
    const pdf = await client.get(`${BASE}/accounts/${String(account.id)}/statement.pdf?period=${period}`);
    expect(pdf.status).toBe(200);
    const pdfBytes = new Uint8Array(await pdf.arrayBuffer());
    expect([...pdfBytes.slice(0, 5)]).toEqual([0x25, 0x50, 0x44, 0x46, 0x2d]); // %PDF-
    expect(pdf.headers.get('x-document-digest')).toMatch(/^[0-9a-f]{64}$/u);
    const csv = await client.get(`${BASE}/accounts/${String(account.id)}/statement.csv?period=${period}`);
    expect((await csv.text()).split('\n')[0]).toContain('effective_date');
    const html = await client.get(`${BASE}/accounts/${String(account.id)}/statement.html?period=${period}`);
    expect(await html.text()).toContain(period);
  });

  it('lists documents with metadata, bytes, and positioned layout', async () => {
    const client = workspace.client();
    const page = await client.json<Page<{ versionId: string; documentType: string; digest: string }>>(`${BASE}/documents?limit=10`);
    expect(page.items.length).toBeGreaterThan(0);
    const version = page.items[0];
    if (version === undefined) throw new Error('unreachable');
    const detail = await client.json<{ document: { versionId: string }; annotations: unknown[]; signatures: unknown[] }>(`${BASE}/documents/${version.versionId}`);
    expect(detail.document.versionId).toBe(version.versionId);
    const content = await client.get(`${BASE}/documents/${version.versionId}/content`);
    expect(content.status).toBe(200);
    expect(content.headers.get('x-document-digest')).toBe(version.digest);
    const layout = await client.json<{ pages: { pageNumber: number; words: { text: string; x: number }[] }[] }>(`${BASE}/documents/${version.versionId}/layout`);
    expect(layout.pages.length).toBeGreaterThan(0);
  });

  it('lists activity and scoped record lists', async () => {
    const client = workspace.client();
    const activity = await client.json<Page>(`${BASE}/activity?limit=5`);
    expect(activity.items.length).toBeGreaterThan(0);
    const products = await client.json<{ kind: string; page: { rows: { id: string; fields: Record<string, unknown> }[] } }>(`${BASE}/lists?kind=products&limit=5`);
    expect(products.page.rows.length).toBeGreaterThan(0);
    const days = await client.json<{ kind: string; page: { rows: { id: string }[] } }>(`${BASE}/lists?kind=calendar.days&from=2025-01-01&through=2025-01-14`);
    expect(days.page.rows.length).toBeGreaterThan(0);
    const bad = await client.get(`${BASE}/lists?kind=calendar.days&from=2025-01-01&through=2025-12-31`);
    expect(bad.status).toBe(422);
  });

  it('reads finance records through the snapshot endpoint', async () => {
    const client = workspace.client();
    const account = await firstAccount();
    const transactions = await client.json<Page<{ journalId: string }>>(`${BASE}/accounts/${String(account.id)}/transactions?limit=1`);
    const journalId = transactions.items[0]?.journalId;
    if (journalId === undefined) throw new Error('No transactions in the test world.');
    const snapshot = await client.json<{ kind: string; snapshot: { fingerprint: string; record: Record<string, unknown> } }>(`${BASE}/finance/record/journal/${encodeURIComponent(journalId)}`);
    expect(snapshot.kind).toBe('found');
    expect(snapshot.snapshot.fingerprint).toMatch(/^[0-9a-f]{64}$/u);
    const missing = await client.get(`${BASE}/finance/record/journal/none`);
    expect(missing.status).toBe(404);
    const body = await missing.json() as { error: { code: string } };
    expect(body.error.code).toBe('not_found');
  });
});

describe('command lifecycle', () => {
  it('reviews, commits, and reconciles a member note', async () => {
    const client = workspace.client();
    const member = await firstMember();
    const command = { kind: 'member.note.add', memberId: String(member.id), visibility: 'general', text: 'Workstation API verification note.' };
    const review = await client.json<{ outcome: { kind: string; review?: { commandKind: string } } }>(`${BASE}/commands/review`, { command });
    expect(review.outcome.kind).toBe('reviewable');
    const key = `api-note-${Date.now()}`;
    const committed = await client.json<{ outcome: { kind: string; receipt?: { receiptNumber: string } } }>(`${BASE}/commands`, { command, idempotencyKey: key });
    expect(committed.outcome.kind).toBe('committed');
    const number = committed.outcome.receipt?.receiptNumber ?? '';
    expect(number).not.toBe('');
    const duplicate = await client.json<{ outcome: { kind: string; receipt?: { receiptNumber: string } } }>(`${BASE}/commands`, { command, idempotencyKey: key });
    expect(duplicate.outcome.kind).toBe('duplicate');
    expect(duplicate.outcome.receipt?.receiptNumber).toBe(number);
    const receipt = await client.json<{ receiptNumber: string; events: { summary: string }[] }>(`${BASE}/receipts/${encodeURIComponent(number)}`);
    expect(receipt.receiptNumber).toBe(number);
    const detail = await client.json<{ notes: { text: string }[] }>(`${BASE}/members/${String(member.id)}`);
    expect(detail.notes.some((note) => note.text === 'Workstation API verification note.')).toBe(true);
  });

  it('reports stale fingerprints as rejections', async () => {
    const client = workspace.client();
    const member = await firstMember();
    const detail = await client.json<{ member: { version: number } }>(`${BASE}/members/${String(member.id)}`);
    const command = { kind: 'contact.update', memberId: String(member.id), expectedVersion: detail.member.version + 50, email: 'stale@example.test' };
    const outcome = await client.json<{ outcome: { kind: string; code?: string } }>(`${BASE}/commands`, { command, idempotencyKey: `stale-${Date.now()}` });
    expect(outcome.outcome.kind).toBe('rejected');
    expect(outcome.outcome.code).toBe('stale_version');
  });

  it('denies write commands to a viewer', async () => {
    const client = workspace.client();
    await client.json('/api/session/operator', { actorNumber: 'OP0001' });
    const member = await firstMember();
    const outcome = await client.json<{ outcome: { kind: string; code?: string } }>(`${BASE}/commands`, {
      command: { kind: 'member.note.add', memberId: String(member.id), visibility: 'general', text: 'Denied.' },
      idempotencyKey: `denied-${Date.now()}`,
    });
    expect(outcome.outcome.kind).toBe('rejected');
    expect(outcome.outcome.code).toBe('not_authorized');
  });
});
