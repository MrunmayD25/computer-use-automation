import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';
import { inject } from 'vitest';

import { startWorkstation, type WorkstationHandle } from '../src/server/app.js';

export interface TestWorkspace {
  readonly origin: string;
  bindings: readonly DatasetBinding[];
  directory: string;
  /** Read-only query against this test's disposable copy. */
  query: <T>(sql: string, ...params: SQLInputValue[]) => T[];
  datasetId: (institutionId: string) => string;
  client: () => TestClient;
  restart: () => Promise<void>;
  close: () => Promise<void>;
}

export interface TestClient {
  get: (path: string) => Promise<Response>;
  send: (method: string, path: string, body?: unknown, headers?: Record<string, string>) => Promise<Response>;
  json: <T>(path: string, body?: unknown, method?: string) => Promise<T>;
}

export interface TestWorkspaceOptions {
  operators?: readonly string[];
}

/** Copies the cached small template so each test owns a disposable database. */
export async function startTestWorkspace(options: TestWorkspaceOptions = {}): Promise<TestWorkspace> {
  const directory = mkdtempSync(join(tmpdir(), 'dlw-api-'));
  const path = join(directory, 'financial.sqlite');
  copyFileSync(inject('templatePath'), path);
  const bindings = inject('templateBindings');
  let handle: WorkstationHandle;
  const launch = async (): Promise<WorkstationHandle> => {
    const store = openFinancialStore({ path });
    return startWorkstation({
      store, bindings, mode: 'shared', operator: { actorNumbers: options.operators ?? ['OP0002', 'OP0003', 'OP0005', 'OP0001'], fixed: false },
      port: 0,
      onClose: () => { store.close(); },
    });
  };
  handle = await launch();
  const workspace: TestWorkspace = {
    bindings, directory,
    get origin() { return handle.origin; },
    query<T>(sql: string, ...params: SQLInputValue[]): T[] {
      using database = new DatabaseSync(path, { readOnly: true });
      return database.prepare(sql).all(...params) as T[];
    },
    datasetId(institutionId) {
      const binding = bindings.find((item) => item.institutionId === institutionId);
      if (binding === undefined) throw new Error(`No ${institutionId} binding.`);
      return binding.datasetId;
    },
    client() {
      let cookie = '';
      const send = async (method: string, target: string, body?: unknown, headers: Record<string, string> = {}): Promise<Response> => {
        const response = await fetch(`${handle.origin}${target}`, {
          method, ...(body === undefined ? {} : { body: JSON.stringify(body) }),
          headers: { ...(cookie === '' ? {} : { cookie }), ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...headers },
        });
        const set = response.headers.get('set-cookie');
        if (set !== null) cookie = set.split(';')[0] ?? '';
        return response;
      };
      const client: TestClient = {
        get: (target) => send('GET', target),
        send,
        async json<T>(target: string, body?: unknown, method = body === undefined ? 'GET' : 'POST'): Promise<T> {
          const response = await send(method, target, body);
          if (!response.ok) throw new Error(`${target} returned ${String(response.status)}: ${await response.text()}`);
          return await response.json() as T;
        },
      };
      return client;
    },
    async restart() {
      await handle.close();
      handle = await launch();
    },
    async close() {
      await handle.close();
      rmSync(directory, { recursive: true, force: true });
    },
  };
  return workspace;
}
