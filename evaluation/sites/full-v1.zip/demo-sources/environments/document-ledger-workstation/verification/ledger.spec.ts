import type { Page } from '@playwright/test';

import { test, expect, shot, statusCell, statusMessage, statusRecord, tree } from './fixtures.js';

/** Opens the first account's ledger tab. Returns the canvas locator. */
async function openLedger(page: Page, origin: string) {
  await page.goto(origin);
  await tree(page).getByText('Accounts', { exact: true }).click();
  const list = page.locator('.list-pane .list-table');
  await expect(list.locator('tr[data-row-id]').first()).toBeVisible();
  const accountNumber = await list.locator('tr[data-row-id] td').first().innerText();
  await list.locator('tr[data-row-id]').first().click();
  const canvas = page.locator('[data-testid="ledger-canvas"] canvas');
  await expect(canvas).toBeVisible();
  return { canvas, accountNumber };
}

test('ledger canvas hit-tests cells at several zoom and scroll positions', async ({ page, workspace, evidence }, info) => {
  const { canvas } = await openLedger(page, workspace.origin);
  const box = await canvas.boundingBox();
  if (box === null) throw new Error('canvas has no box');

  // Click a scrolled-region cell (date column is frozen, so start at x>120).
  await page.mouse.click(box.x + 300, box.y + 45);
  await expect(statusCell(page)).toContainText('r0');
  await expect(statusRecord(page)).not.toContainText('no record');

  // Scroll down with the wheel, then click again — the same screen coordinate must hit a different row.
  await page.mouse.move(box.x + 300, box.y + 60);
  await page.mouse.wheel(0, 240);
  await page.mouse.click(box.x + 300, box.y + 200);
  const scrolledCell = await statusCell(page).innerText();
  expect(scrolledCell).not.toBe('r0');
  evidence.browser('scrolled cell', { cell: scrolledCell });

  // Ctrl+wheel zooms; the HUD reports the zoom level.
  await page.mouse.move(box.x + 200, box.y + 200);
  await page.keyboard.down('Control');
  await page.mouse.wheel(0, -240);
  await page.keyboard.up('Control');
  await expect(page.locator('.grid-scrollbar')).not.toContainText('100%');
  const zoom = await page.locator('.grid-scrollbar').innerText();
  evidence.browser('zoom level', { zoom });
  await shot(page, info, 'ledger-zoomed');
});

test('double-click opens an editable overlay only on the description column', async ({ page, workspace, evidence }, info) => {
  const { canvas } = await openLedger(page, workspace.origin);
  const box = await canvas.boundingBox();
  if (box === null) throw new Error('canvas has no box');

  // Column 0 (date) is protected — dblclick reports it in the status line.
  await page.mouse.dblclick(box.x + 40, box.y + 45);
  await expect(statusMessage(page)).toContainText('protected');

  // Column offsets: date 96, posted 150, reference 130 → description starts at 376 content units.
  // The overlay input appears positioned over the cell.
  const descriptionX = box.x + 96 + 150 + 130 + 60;
  await page.mouse.dblclick(descriptionX, box.y + 45);
  const editor = page.locator('.cell-editor input');
  await expect(editor).toBeVisible();
  await expect(editor).toBeFocused();
  const original = await editor.inputValue();
  evidence.browser('editor opened', { original });
  await shot(page, info, 'cell-editor');
  await editor.press('Escape');
  await expect(editor).toBeHidden();
});

test('amending a description commits through review and updates the shared record', async ({ page, workspace, evidence }) => {
  const { canvas, accountNumber } = await openLedger(page, workspace.origin);
  const box = await canvas.boundingBox();
  if (box === null) throw new Error('canvas has no box');
  const descriptionX = box.x + 96 + 150 + 130 + 60;
  await page.mouse.dblclick(descriptionX, box.y + 45);
  const editor = page.locator('.cell-editor input');
  await expect(editor).toBeVisible();
  const amended = `Amended in workstation ${Date.now()}`;
  await editor.fill(amended);
  await editor.press('Enter');
  await expect(page.locator('.cell-editor')).toBeHidden();
  await expect(statusMessage(page)).toContainText('amended');

  const rows = workspace.query<{ new_description: string }>(
    `SELECT new_description FROM transaction_amendments WHERE dataset_id=? ORDER BY amended_at DESC, id DESC LIMIT 1`,
    workspace.datasetId('northstar'),
  );
  evidence.database('latest amendment', rows[0] ?? null);
  evidence.browser('account', { accountNumber });
});
