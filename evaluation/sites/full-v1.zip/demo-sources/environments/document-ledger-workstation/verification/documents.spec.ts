import type { Page } from '@playwright/test';

import { test, expect, shot, statusCell, statusFocus, tree } from './fixtures.js';

/** Opens the first stored document in the canvas document tab. */
async function openDocument(page: Page, origin: string) {
  await page.goto(origin);
  await tree(page).getByText('Documents', { exact: true }).click();
  const list = page.locator('.list-pane .list-table');
  await expect(list.locator('tr[data-row-id]').first()).toBeVisible();
  const title = await list.locator('tr[data-row-id] td').first().innerText();
  await list.locator('tr[data-row-id]').first().click();
  const canvas = page.locator('.document-canvas canvas');
  await expect(canvas).toBeVisible();
  return { canvas, title };
}

test('document canvas renders positioned pages with word hit testing', async ({ page, workspace, evidence }, info) => {
  const { canvas } = await openDocument(page, workspace.origin);
  const box = await canvas.boundingBox();
  if (box === null) throw new Error('document canvas has no box');
  // The HUD reports page count.
  await expect(page.locator('.document-hud')).toContainText('page');
  // Clicking inside the first page reports the document area; clicking a word names it.
  await expect(statusFocus(page)).toContainText('document');
  await page.mouse.click(box.x + box.width / 2, box.y + 120);
  const focus = await statusCell(page).innerText();
  evidence.browser('document focus', { focus });
  // Ctrl+wheel zoom changes the reported zoom level.
  await page.mouse.move(box.x + box.width / 2, box.y + 300);
  await page.keyboard.down('Control');
  await page.mouse.wheel(0, -300);
  await page.keyboard.up('Control');
  await expect(page.locator('.document-hud')).not.toContainText('100%');
  await shot(page, info, 'document-viewer');
});

test('drag-select creates a persisted annotation bound to the version', async ({ page, workspace, evidence }) => {
  const { canvas } = await openDocument(page, workspace.origin);
  const box = await canvas.boundingBox();
  if (box === null) throw new Error('document canvas has no box');

  const annotationsBefore = await page.locator('.annotation-list li').count();

  // Shift+drag a region inside the first page → the annotate operation opens prefilled.
  const cx = box.x + box.width / 2;
  await page.mouse.move(cx - 80, box.y + 150);
  await page.keyboard.down('Shift');
  await page.mouse.down();
  await page.mouse.move(cx + 120, box.y + 220, { steps: 6 });
  await page.mouse.up();
  await page.keyboard.up('Shift');

  const dialog = page.locator('[role="dialog"]').first();
  await expect(dialog).toBeVisible();
  await expect(dialog).toContainText('Annotate document');
  await dialog.locator('.op-field', { hasText: 'Annotation text' }).locator('input,textarea').first().fill('Canvas annotation from drag-select.');
  await dialog.getByRole('button', { name: 'Review' }).click();
  await expect(page.getByTestId('op-review')).toBeVisible();
  await dialog.getByRole('button', { name: 'Commit' }).click();
  await expect(page.getByTestId('op-outcome')).toContainText('Committed');

  const rows = workspace.query<{ text: string; region_json: string }>(
    'SELECT text,region_json FROM document_annotations WHERE dataset_id=? ORDER BY created_at DESC LIMIT 1',
    workspace.datasetId('northstar'),
  );
  expect(rows[0]?.text).toBe('Canvas annotation from drag-select.');
  const region = JSON.parse(rows[0]?.region_json ?? '{}') as { width: number; height: number };
  expect(region.width).toBeGreaterThan(0);
  expect(region.height).toBeGreaterThan(0);
  evidence.database('annotation', rows[0]);
  evidence.browser('annotations before', { count: annotationsBefore });
});

test('documents list shows real metadata with digests', async ({ page, workspace, evidence }) => {
  await page.goto(workspace.origin);
  await tree(page).getByText('Documents', { exact: true }).click();
  const list = page.locator('.list-pane .list-table');
  const rows = list.locator('tr[data-row-id]');
  await expect(rows.first()).toBeVisible();
  const cellText = await rows.first().innerText();
  evidence.browser('first document row', { text: cellText });
  expect(cellText.length).toBeGreaterThan(10);
});
