import { expect, type Locator, type Page } from '@playwright/test';

import {
  CATALOG, WORKFLOW_STEPS, evidencePath, populateVisibleControls, qualificationRecord, sourceSha, writeEvidence,
} from '../../../evaluation/browser-qualification.mjs';
import { OPERATIONS, SECTION_LABELS, type OperationSpec } from '../src/client/operations/catalog.js';
import { openMenu, test, tree } from './fixtures.js';

const APPLICATION_ID = 'document-ledger-workstation';
const SHARD_SIZE = 12;
const LIST_FOR_CAPABILITY: Readonly<Record<string, string>> = {
  'account.inquire': 'Accounts', 'statement.export': 'Accounts', 'document.statement.retrieve': 'Documents',
  'member.identity.resolve': 'Members', 'member.search': 'Members', 'account.list': 'Accounts',
  'transaction.search': 'Accounts', 'activity.inspect': 'Activity', 'reconciliation.transfer': 'Activity',
  'reconciliation.settlement_batch': 'Activity', 'reconciliation.cash_day': 'Activity',
  'institution.context.verify': 'Members', 'operation.review': 'Activity',
};

const shard = (): number => Number(process.env.DLW_QUAL_SHARD ?? '0');
const runId = (): string => process.env.DLW_QUAL_RUN ?? `full-v1-${sourceSha().slice(0, 7)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
const command = (): string => `DLW_QUAL_SHARD=${String(shard())} DLW_QUAL_RUN=${runId()} npx playwright test -c verification/playwright.config.ts verification/full-v1.browser.ts`;

test.describe.configure({ timeout: 600_000 });

function operationFor(capability: string): OperationSpec | undefined {
  const exact = OPERATIONS.find(operation => operation.kind === capability);
  if (exact !== undefined) return exact;
  const task = CATALOG.find(candidate => candidate.capability === capability);
  return task === undefined ? undefined : OPERATIONS.find(operation => operation.tasks.includes(task.id));
}

async function openOperation(page: Page, spec: OperationSpec): Promise<Locator> {
  const menu = await openMenu(page, SECTION_LABELS[spec.section]);
  await menu.getByRole('menuitem', { name: spec.title, exact: true }).click();
  const dialog = page.getByRole('dialog', { name: spec.title });
  await expect(dialog).toBeVisible();
  return dialog;
}

async function exerciseCapability(page: Page, origin: string, capability: string): Promise<{ entry: string; action: string; result: string }> {
  await page.goto(origin);
  const spec = operationFor(capability);
  if (spec !== undefined) {
    const dialog = await openOperation(page, spec);
    const entry = await dialog.innerText();
    const action = await populateVisibleControls(dialog);
    const visibleDialogs = page.locator('.dialog:visible');
    while (await visibleDialogs.count() > 1) {
      const count = await visibleDialogs.count();
      await visibleDialogs.last().locator('button[aria-label="Close dialog"]').click();
      await expect.poll(() => visibleDialogs.count()).toBeLessThan(count);
    }
    await dialog.getByRole('button', { name: 'Review', exact: true }).click();
    await page.waitForTimeout(50);
    const result = dialog.getByTestId('op-outcome').or(dialog.getByTestId('op-review')).or(dialog.getByRole('alert')).filter({ visible: true }).first();
    return { entry, action, result: await (await result.isVisible().catch(() => false) ? result : dialog).innerText() };
  }
  const list = LIST_FOR_CAPABILITY[capability];
  if (list === undefined) throw new Error(`No visible document-workstation path for ${capability}.`);
  await tree(page).getByText(list, { exact: true }).click();
  const pane = page.locator('.list-pane');
  await expect(pane).toBeVisible();
  const entry = await pane.innerText();
  const action = await populateVisibleControls(pane);
  const first = pane.locator('tr[data-row-id]').first();
  if (await first.isVisible().catch(() => false)) await first.click();
  await page.waitForTimeout(50);
  return { entry, action: action || `opened the populated ${list} work list`, result: await page.locator('.workstation').innerText() };
}

test('qualifies canonical task options through document-ledger controls', async ({ page, workspace }, info) => {
  const selected = CATALOG.slice(shard() * SHARD_SIZE, (shard() + 1) * SHARD_SIZE);
  test.skip(selected.length === 0, 'empty task shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `capability-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const task of selected) {
    const observation = await exerciseCapability(page, workspace.origin, task.capability);
    records.push(qualificationRecord({
      applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${task.capability}]`, artifact,
      identity: { task: task.id, capability: task.capability, option: task.capability }, visibleEntry: observation.entry,
      action: observation.action, visibleResult: observation.result,
      businessEffect: 'The populated ledger dialog or record pane produced a reviewed command, inquiry result, or operation-specific visible refusal.',
      recovery: 'The modal kept the draft/result visible and the workstation retained record tabs so the operator could correct or recover safely.',
    }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'capabilities.json', records, { shard: shard() });
});

test('qualifies workflow catalog and recovery branches through document-ledger controls', async ({ page, workspace }, info) => {
  const selected = Object.entries(WORKFLOW_STEPS).slice(shard() * 4, (shard() + 1) * 4);
  test.skip(selected.length === 0, 'empty workflow shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `workflow-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const [workflow, steps] of selected) {
    const results: string[] = [];
    for (const step of steps) results.push(`${step}\n${(await exerciseCapability(page, workspace.origin, step)).result}`);
    records.push(qualificationRecord({
      applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} catalog path]`, artifact,
      identity: { workflow, branch: 'catalog-path' }, visibleEntry: `Traversed ${steps.join(' → ')} through workstation menus, panes, and modal dialogs.`,
      visibleResult: results.join('\n--- next visible step ---\n'), businessEffect: 'Every bounded step reached its real record, inquiry, or reviewed command surface.',
      recovery: 'The tabbed workspace and explicit modal outcome preserve the operator’s safe return path.',
    }));
    const recovery = await exerciseCapability(page, workspace.origin, steps.at(-1) ?? 'activity.inspect');
    records.push(qualificationRecord({
      applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} recovery]`, artifact,
      identity: { workflow, branch: 'recovery' }, visibleEntry: `Reopened ${steps.at(-1) ?? 'activity.inspect'} after the sequence.`,
      action: recovery.action, visibleResult: recovery.result, businessEffect: 'The final step was reopened through the rendered workstation and produced a fresh safe result.',
      recovery: 'The operator can re-pick current records, re-review, or inspect Activity without duplicating a prior effect.',
    }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'workflows.json', records, { shard: shard() });
});

test('qualifies document-ledger family and shared-world boundaries', async ({ browser, page, workspace }, info) => {
  test.skip(shard() !== 0, 'recorded once');
  await page.goto(workspace.origin);
  await tree(page).getByText('Accounts', { exact: true }).click();
  const accountRow = page.locator('.list-pane tr[data-row-id]').first();
  await accountRow.click();
  const familyArtifact = evidencePath(APPLICATION_ID, runId(), 'family-mechanism.json');
  const familyRecord = qualificationRecord({
    applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [family]`, artifact: familyArtifact,
    identity: { mechanism: 'document-ledger-workstation' }, visibleEntry: await page.locator('.workstation').innerText(),
    visibleResult: `tabs=${String(await page.getByRole('tab').count())}; ledger canvases=${String(await page.locator('canvas').count())}; inspector=${await page.locator('.inspector').innerText()}`,
    businessEffect: 'Tree navigation opened a record tab with the ledger/canvas and inspector family surfaces intact.',
    recovery: 'The tab strip and record tree preserve navigation when a modal operation is closed or corrected.',
  });
  writeEvidence(APPLICATION_ID, runId(), 'family-mechanism.json', [familyRecord]);

  const first = page;
  const second = await browser.newPage();
  await second.goto(workspace.origin);
  const contact = operationFor('contact.update');
  if (contact === undefined) throw new Error('contact.update is missing');
  const firstDialog = await openOperation(first, contact);
  const secondDialog = await openOperation(second, contact);
  await populateVisibleControls(firstDialog);
  await populateVisibleControls(secondDialog);
  await firstDialog.locator('.op-field', { hasText: 'Email' }).locator('input').fill('held-ledger@example.test');
  await secondDialog.locator('.op-field', { hasText: 'Email' }).locator('input').fill('peer-ledger@example.test');
  await firstDialog.getByRole('button', { name: 'Review', exact: true }).click();
  await secondDialog.getByRole('button', { name: 'Review', exact: true }).click();
  await expect(secondDialog.getByTestId('op-review')).toBeVisible();
  await secondDialog.getByRole('button', { name: 'Commit', exact: true }).click();
  await expect(secondDialog.getByTestId('op-outcome')).toContainText('Committed');
  const peerResult = await secondDialog.getByTestId('op-outcome').innerText();
  await expect(firstDialog.getByTestId('op-review')).toBeVisible();
  await firstDialog.getByRole('button', { name: 'Commit', exact: true }).click();
  await expect(firstDialog.getByTestId('op-outcome')).toContainText(/stale|changed|version/iu);
  const staleResult = await firstDialog.getByTestId('op-outcome').innerText();

  await first.goto(workspace.origin);
  await tree(first).getByText('Members', { exact: true }).click();
  await first.locator('.list-pane tr[data-row-id]').first().click();
  await expect(first.locator('.member-page')).toContainText('peer-ledger@example.test');
  const peerVisible = await first.locator('.member-page').innerText();
  await tree(first).getByText('Members', { exact: true }).click();
  const foreignSearch = first.locator('.list-pane input[type="search"]');
  await foreignSearch.fill('SR000001');
  await foreignSearch.press('Enter');
  await expect(first.locator('.list-pane')).toContainText('0 of 0');
  const isolationResult = await first.locator('.list-pane').innerText();
  expect(isolationResult).not.toContain('NM000001');

  const sharedArtifact = evidencePath(APPLICATION_ID, runId(), 'shared-world.json');
  const common = { applicationId: APPLICATION_ID, runId: runId(), command: command(), artifact: sharedArtifact };
  writeEvidence(APPLICATION_ID, runId(), 'shared-world.json', [
    qualificationRecord({ ...common, test: `${info.title} [peer visibility]`, identity: { shared_world_check: 'peer_visibility' }, visibleEntry: peerResult, visibleResult: peerVisible, businessEffect: 'A commit from a peer workstation page became visible after the first page reopened the member record.', recovery: 'The receipt and refreshed record make the peer effect recoverable without replaying it.' }),
    qualificationRecord({ ...common, test: `${info.title} [stale rejection]`, identity: { shared_world_check: 'stale_rejection' }, visibleEntry: 'Both pages held reviewed contact updates for the same member version.', visibleResult: staleResult, businessEffect: 'The older reviewed update was rejected after the peer committed first.', recovery: 'The stale result requires re-picking the current member rather than overwriting the peer.' }),
    qualificationRecord({ ...common, test: `${info.title} [institution isolation]`, identity: { shared_world_check: 'institution_isolation' }, visibleEntry: 'The Northstar member list was searched with the foreign Southridge identifier SR000001.', visibleResult: isolationResult, businessEffect: 'The Northstar-bound list returned no foreign-institution record.', recovery: 'The workstation stayed bound to Northstar and never fell back across institutions.' }),
  ]);
  await second.close();
});

test('the workstation catalog stays structurally complete', () => {
  expect(new Set(OPERATIONS.map(operation => operation.kind)).size).toBe(OPERATIONS.length);
});
