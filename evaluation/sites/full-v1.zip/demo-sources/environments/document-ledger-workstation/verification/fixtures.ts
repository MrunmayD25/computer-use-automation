import { copyFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';
import { test as base, expect, type Locator, type Page, type TestInfo } from '@playwright/test';

import { startWorkstation, type WorkstationHandle } from '../src/server/app.js';
import { ensureTemplate } from '../test/template.js';

export const PUBLIC_DIRECTORY = resolve(import.meta.dirname, '..', 'dist', 'public');

export interface LaunchedWorkspace {
  origin: string;
  /** Path of this test's disposable copy of the template world. */
  databasePath: string;
  bindings: readonly DatasetBinding[];
  datasetId: (institutionId: string) => string;
  /** Read-only query against the disposable copy. */
  query: <T>(sql: string, ...params: SQLInputValue[]) => T[];
}

/** Browser observations and database observations are recorded separately and written per test. */
export interface EvidenceLog {
  browser: (label: string, detail: unknown) => void;
  database: (label: string, detail: unknown) => void;
}

interface Fixtures {
  workspace: LaunchedWorkspace;
  evidence: EvidenceLog;
  /** Uncaught exceptions and console errors, excluding the browser's own log line for an expected 4xx response. */
  pageErrors: string[];
}

export function bindingFor(bindings: readonly DatasetBinding[], institutionId: string): DatasetBinding {
  const binding = bindings.find((item) => item.institutionId === institutionId);
  if (binding === undefined) throw new Error(`The template world has no ${institutionId} dataset.`);
  return binding;
}

export const test = base.extend<Fixtures>({
  workspace: async ({ browserName: _browserName }, use) => {
    const template = await ensureTemplate();
    const directory = mkdtempSync(join(tmpdir(), 'dlw-verify-'));
    const path = join(directory, 'financial.sqlite');
    let handle: WorkstationHandle | undefined;
    try {
      copyFileSync(template.path, path);
      const store = openFinancialStore({ path });
      handle = await startWorkstation({
        store, bindings: template.bindings, mode: 'shared', operator: { actorNumbers: ['OP0002', 'OP0003', 'OP0005', 'OP0001'], fixed: false },
        port: 0, publicDirectory: PUBLIC_DIRECTORY, onClose: () => { store.close(); },
      });
      await use({
        origin: handle.origin,
        databasePath: path,
        bindings: template.bindings,
        datasetId: (institutionId) => bindingFor(template.bindings, institutionId).datasetId,
        query<T>(sql: string, ...params: SQLInputValue[]): T[] {
          using database = new DatabaseSync(path, { readOnly: true });
          return database.prepare(sql).all(...params) as T[];
        },
      });
    } finally {
      await handle?.close();
      rmSync(directory, { recursive: true, force: true });
    }
  },
  evidence: async ({ browserName: _browserName }, use, info) => {
    const browser: { label: string; detail: unknown }[] = [];
    const database: { label: string; detail: unknown }[] = [];
    await use({ browser: (label, detail) => { browser.push({ label, detail }); }, database: (label, detail) => { database.push({ label, detail }); } });
    const path = info.outputPath('evidence.json');
    writeFileSync(path, `${JSON.stringify({ test: info.titlePath.slice(1), status: info.status, browser, database }, null, 2)}\n`);
    await info.attach('evidence', { path, contentType: 'application/json' });
  },
  pageErrors: async ({ page }, use) => {
    const errors: string[] = [];
    page.on('pageerror', (error) => { errors.push(error.message); });
    page.on('console', (message) => { if (message.type() === 'error' && !message.text().startsWith('Failed to load resource')) errors.push(message.text()); });
    await use(errors);
  },
});

export { expect };

export async function shot(page: Page, info: TestInfo, name: string): Promise<void> {
  const path = info.outputPath(`${name}.png`);
  await page.screenshot({ path });
  await info.attach(name, { path, contentType: 'image/png' });
}

/** Locators for the workstation shell. */
export const statusBar = (page: Page): Locator => page.locator('.statusbar');
export const statusFocus = (page: Page): Locator => page.getByTestId('status-focus');
export const statusRecord = (page: Page): Locator => page.getByTestId('status-record');
export const statusCell = (page: Page): Locator => page.getByTestId('status-cell');
export const statusMessage = (page: Page): Locator => page.getByTestId('status-message');
export const menuBar = (page: Page): Locator => page.locator('.menubar');
export const tabStrip = (page: Page): Locator => page.locator('.tabs');
export const tree = (page: Page): Locator => page.locator('.tree');
export const inspector = (page: Page): Locator => page.locator('.inspector');

/** Canvas grid surface inside the active tab. */
export const gridCanvas = (page: Page): Locator => page.locator('canvas.grid-canvas').first();
export const documentCanvas = (page: Page): Locator => page.locator('canvas.document-canvas');
export const cellEditor = (page: Page): Locator => page.locator('.cell-editor');
export const listPane = (page: Page): Locator => page.locator('.list-pane');

/** Opens a menu in the menu bar by its trigger label. */
export async function openMenu(page: Page, label: string): Promise<Locator> {
  await menuBar(page).getByRole('button', { name: label, exact: true }).click();
  const menu = page.locator('[role="menu"]');
  await expect(menu).toBeVisible();
  return menu;
}

/** Opens the operations tree node then a list entry. */
export async function openTreeList(page: Page, ...path: string[]): Promise<void> {
  for (const label of path) await tree(page).getByText(label, { exact: true }).click();
}
