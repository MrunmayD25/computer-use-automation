import { test, expect, openMenu, tree, statusMessage } from './fixtures.js';
import { startPeerWorkspace } from './peer.js';

/**
 * Cross-application evidence: this workstation and the virtualized service workspace open
 * the same disposable world. Writes committed through this app's canvas/dialogs must be
 * visible to the peer's API, and vice versa.
 */
test('a note committed in this workstation is readable through the peer workspace', async ({ page, workspace, evidence }) => {
  const peer = await startPeerWorkspace(workspace.databasePath, workspace.bindings, ['OP0005']);
  try {
    await page.goto(workspace.origin);
    await tree(page).getByText('Members', { exact: true }).click();
    const list = page.locator('.list-pane .list-table');
    const memberRowId = await list.locator('tr[data-row-id]').first().getAttribute('data-row-id');
    if (memberRowId === null) throw new Error('no members');

    const menu = await openMenu(page, 'Members');
    await menu.getByRole('menuitem', { name: 'Add member note' }).click();
    const dialog = page.locator('[role="dialog"]').first();
    await dialog.locator('.op-field', { hasText: 'Member' }).getByRole('button', { name: 'Choose…' }).click();
    const picker = page.locator('[role="dialog"]').last();
    await picker.locator('.picker-option').first().click();
    await dialog.locator('.op-field', { hasText: 'Visibility' }).locator('select').selectOption('general');
    const note = `Cross-app workstation note ${Date.now()}`;
    await dialog.locator('.op-field', { hasText: 'Note' }).locator('textarea').fill(note);
    await dialog.getByRole('button', { name: 'Review' }).click();
    await expect(page.getByTestId('op-review')).toBeVisible();
    await dialog.getByRole('button', { name: 'Commit' }).click();
    await expect(page.getByTestId('op-outcome')).toContainText('Committed');
    await expect(statusMessage(page)).toContainText('Committed');

    const peerResponse = await fetch(`${peer.origin}/api/i/northstar/members/${memberRowId}`);
    expect(peerResponse.status).toBe(200);
    const peerDetail = await peerResponse.json() as { notes: { text: string }[] };
    expect(peerDetail.notes.some((entry) => entry.text === note)).toBe(true);
    evidence.browser('committed note', { note });
    evidence.database('peer visibility', { peerSaw: true });
  } finally {
    await peer.close();
  }
});

test('a peer write updates this workstation and stale fingerprints are refused', async ({ page, workspace, evidence }) => {
  const peer = await startPeerWorkspace(workspace.databasePath, workspace.bindings, ['OP0002']);
  try {
    await page.goto(workspace.origin);
    await tree(page).getByText('Members', { exact: true }).click();
    const list = page.locator('.list-pane .list-table');
    const memberRowId = await list.locator('tr[data-row-id]').first().getAttribute('data-row-id');
    if (memberRowId === null) throw new Error('no members');

    const before = await (await fetch(`${peer.origin}/api/i/northstar/members/${memberRowId}`)).json() as { member: { version: number } };
    const peerWrite = await fetch(`${peer.origin}/api/i/northstar/commands`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        command: { kind: 'contact.update', memberId: memberRowId, expectedVersion: before.member.version, email: `peer-${Date.now()}@example.test` },
        idempotencyKey: `peer-${Date.now()}-x`,
      }),
    });
    const peerOutcome = await peerWrite.json() as { kind: string };
    expect(peerOutcome.kind).toBe('committed');
    evidence.database('peer committed contact update', peerOutcome);

    const myDetail = await (await fetch(`${workspace.origin}/api/i/northstar/members/${memberRowId}`)).json() as { member: { version: number }; email: { value: string } | null };
    expect(myDetail.member.version).toBe(before.member.version + 1);
    expect(myDetail.email?.value).toContain('peer-');

    const stale = await fetch(`${workspace.origin}/api/i/northstar/commands`, {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        command: { kind: 'contact.update', memberId: memberRowId, expectedVersion: before.member.version, email: 'stale-cross@example.test' },
        idempotencyKey: `stale-cross-${Date.now()}`,
      }),
    });
    const staleOutcome = (await stale.json() as { outcome: { kind: string; code?: string } }).outcome;
    expect(staleOutcome.kind).toBe('rejected');
    expect(staleOutcome.code).toBe('stale_version');
    evidence.browser('stale refusal through this app', staleOutcome);
  } finally {
    await peer.close();
  }
});
