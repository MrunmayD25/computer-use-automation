import { openFinancialStore } from '@computer-use/financial-database/services';
import type { DatasetBinding } from '@computer-use/financial-database';

/** A running peer application sharing this test's disposable world. */
export interface PeerHandle {
  origin: string;
  close: () => Promise<void>;
}

/**
 * Boots the virtualized-service-workspace peer against the same database file as this
 * workstation's test world. The peer is imported at runtime (non-literal specifier) so
 * this project's typecheck does not pull a sibling package's sources into its program.
 */
export async function startPeerWorkspace(databasePath: string, bindings: readonly DatasetBinding[], actorNumbers: readonly string[]): Promise<PeerHandle> {
  const appPath = '../../virtualized-service-workspace/src/server/app.js';
  const preferencesPath = '../../virtualized-service-workspace/src/server/preferences.js';
  const appModule = await import(appPath) as {
    startWorkspace: (options: Record<string, unknown>) => Promise<PeerHandle>;
  };
  const preferencesModule = await import(preferencesPath) as { memoryPreferenceStore: () => unknown };
  const store = openFinancialStore({ path: databasePath });
  const handle = await appModule.startWorkspace({
    store, bindings, mode: 'verification',
    operator: { actorNumbers: [...actorNumbers], fixed: true },
    preferences: preferencesModule.memoryPreferenceStore(),
  });
  return {
    origin: handle.origin,
    close: async () => { await handle.close(); },
  };
}
