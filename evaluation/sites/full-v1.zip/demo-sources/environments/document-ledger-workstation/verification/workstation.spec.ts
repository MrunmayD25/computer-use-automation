import { test, expect, openMenu, shot, statusMessage, statusFocus, statusRecord, tree, tabStrip } from './fixtures.js';

test('shell boots with menubar, tree, tabs, inspector, status bar', async ({ page, workspace, evidence }, info) => {
  await page.goto(workspace.origin);
  await expect(page.locator('.workstation')).toBeVisible();
  await expect(page.locator('.menubar')).toBeVisible();
  await expect(tree(page).getByText('Members', { exact: true })).toBeVisible();
  await expect(page.getByTestId('statusbar')).toContainText('op OP0002');
  await expect(page.locator('.inspector')).toContainText('Inspector');
  evidence.browser('shell', { operator: 'OP0002' });
  await shot(page, info, 'shell');
});

test('tree opens the members list and rows open member detail tabs', async ({ page, workspace, evidence }, info) => {
  await page.goto(workspace.origin);
  await tree(page).getByText('Members', { exact: true }).click();
  const list = page.locator('.list-pane .list-table');
  await expect(list.locator('tr[data-row-id]').first()).toBeVisible();
  const count = await list.locator('tr[data-row-id]').count();
  expect(count).toBeGreaterThan(3);
  const first = list.locator('tr[data-row-id]').first();
  const memberNumber = await first.locator('td').first().innerText();
  await first.click();
  await expect(tabStrip(page).getByRole('tab', { name: memberNumber })).toHaveAttribute('aria-selected', 'true');
  await expect(page.locator('.member-page')).toContainText(memberNumber);
  evidence.browser('member detail opened', { memberNumber });
  await shot(page, info, 'member-detail');
});

test('menu runs a member note operation through review and commit', async ({ page, workspace, evidence }) => {
  await page.goto(workspace.origin);
  await tree(page).getByText('Members', { exact: true }).click();
  const list = page.locator('.list-pane .list-table');
  const firstId = await list.locator('tr[data-row-id]').first().getAttribute('data-row-id');
  if (firstId === null) throw new Error('no member rows');

  const menu = await openMenu(page, 'Members');
  await menu.getByRole('menuitem', { name: 'Add member note' }).click();
  const dialog = page.locator('[role="dialog"]').first();
  await expect(dialog).toBeVisible();

  await dialog.locator('.op-field', { hasText: 'Member' }).getByRole('button', { name: 'Choose…' }).click();
  const picker = page.locator('[role="dialog"]').last();
  await expect(picker.locator('.picker-option').first()).toBeVisible();
  await picker.locator('.picker-option').first().click();
  await expect(dialog.locator('.picker-value').first()).not.toContainText('Not selected');

  await dialog.locator('.op-field', { hasText: 'Visibility' }).locator('select').selectOption('general');
  await dialog.locator('.op-field', { hasText: 'Note' }).locator('textarea').fill('Workstation browser verification note.');
  await dialog.getByRole('button', { name: 'Review' }).click();
  await expect(page.getByTestId('op-review')).toBeVisible();
  await dialog.getByRole('button', { name: 'Commit' }).click();
  await expect(page.getByTestId('op-outcome')).toContainText('Committed');
  const outcomeText = await page.getByTestId('op-outcome').innerText();
  evidence.browser('note committed', { outcome: outcomeText });
  await expect(statusMessage(page)).toContainText('Committed');

  const note = workspace.query<{ text: string }>(
    'SELECT n.text FROM member_notes n WHERE n.dataset_id=? AND n.text=?',
    workspace.datasetId('northstar'), 'Workstation browser verification note.',
  );
  expect(note.length).toBe(1);
  evidence.database('note row', note[0]);
});

test('viewer operator is denied write operations visibly', async ({ page, workspace, evidence }) => {
  await page.goto(workspace.origin);
  await page.locator('.toolbar-field', { hasText: 'Operator' }).locator('select').selectOption('OP0001');
  await expect(statusMessage(page)).toContainText('OP0001');
  const menu = await openMenu(page, 'Members');
  await menu.getByRole('menuitem', { name: 'Add member note' }).click();
  const dialog = page.locator('[role="dialog"]').first();
  await dialog.locator('.op-field', { hasText: 'Member' }).getByRole('button', { name: 'Choose…' }).click();
  const picker = page.locator('[role="dialog"]').last();
  await picker.locator('.picker-option').first().click();
  await dialog.locator('.op-field', { hasText: 'Visibility' }).locator('select').selectOption('general');
  await dialog.locator('.op-field', { hasText: 'Note' }).locator('textarea').fill('Denied note.');
  await dialog.getByRole('button', { name: 'Review' }).click();
  // Review itself may be rejected for a viewer, or committing the reviewable draft is denied.
  await expect(page.getByTestId('op-outcome').or(page.getByTestId('op-review'))).toBeVisible();
  if (await page.getByTestId('op-review').count() > 0) await dialog.getByRole('button', { name: 'Commit' }).click();
  await expect(page.getByTestId('op-outcome')).toContainText('not_authorized');
  evidence.browser('viewer denied', { outcome: await page.getByTestId('op-outcome').innerText() });
});

test('focus and record identity surface in the status bar', async ({ page, workspace }) => {
  await page.goto(workspace.origin);
  await tree(page).getByText('Accounts', { exact: true }).click();
  const list = page.locator('.list-pane .list-table');
  await list.locator('tr[data-row-id]').first().click();
  const canvas = page.locator('[data-testid="ledger-canvas"] canvas');
  await expect(canvas).toBeVisible();
  const box = await canvas.boundingBox();
  if (box === null) throw new Error('no canvas box');
  await page.mouse.click(box.x + 300, box.y + 60);
  await expect(statusFocus(page)).toContainText('ledger');
  await expect(statusRecord(page)).not.toContainText('no record');
});
