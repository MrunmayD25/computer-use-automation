import { CORE_OPERATIONS } from './registry-core.js';
import { FINANCE_OPERATIONS } from './registry-finance.js';
import { SERVICING_OPERATIONS } from './registry-servicing.js';
import type { ModuleKey, OperationSpec } from './spec.js';

export const OPERATIONS: readonly OperationSpec[] = [...CORE_OPERATIONS, ...SERVICING_OPERATIONS, ...FINANCE_OPERATIONS];

export const OPERATION_COUNT = OPERATIONS.length;

const byKind = new Map(OPERATIONS.map((spec) => [spec.kind, spec]));

export function operationSpec(kind: string): OperationSpec | undefined {
  return byKind.get(kind);
}

export function operationsByModule(module: ModuleKey): readonly OperationSpec[] {
  return OPERATIONS.filter((spec) => spec.module === module);
}

export const MODULE_LABELS: Readonly<Record<ModuleKey, string>> = {
  members: 'Members',
  accounts: 'Accounts',
  money: 'Money movement',
  payments: 'Payments',
  cards: 'Cards & disputes',
  loans: 'Loans',
  documents: 'Documents',
  servicing: 'Servicing',
  cases: 'Cases',
  maintenance: 'Maintenance',
  reconciliation: 'Reconciliation',
  approvals: 'Approvals',
  searches: 'Saved searches',
  system: 'System',
};
