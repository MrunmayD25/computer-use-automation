import { createHash, randomUUID } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import express, { type Request, type Response } from 'express';

import type { DatasetBinding } from '@computer-use/financial-database';
import type { FinancialStore } from '@computer-use/financial-database/services';
import { authorizeQuery, executeCommand, exportStatement, listApprovals, referenceData, reviewCommand, searchDocuments } from '@computer-use/financial-database/services';
import { buildCommand, type FormIssue } from './command.js';
import { formatInstant, parseMoney } from './format.js';
import { createSessionStore, resolveOperator, type PortalSession, type RequestContext, type SessionStore } from './context.js';
import { DraftStore, formPage, resultPage, reviewPage, subjectPage } from './engine.js';
import { html, type SafeHtml } from './html.js';
import {
  accountPage, accountsPage, activityPage, approvalsPage, casePage, casesPage, commPage,
  docDownload, docVersionPage, homePage, memberPage, membersPage, recordListPage, recordPage,
  receiptPage, reconciliationInquiryPage, requestPage, searchesPage, statementPage, systemPage,
} from './pages.js';
import { MODULE_LABELS, OPERATION_COUNT, operationsByModule, operationSpec } from './registry.js';
import { link, page, table, type DeploymentBranding, type PageModel } from './render.js';
import { resolveRef, resolveValues } from './resolve.js';
import type { ModuleKey, OperationSpec } from './spec.js';

const strField = (value: unknown): string => (typeof value === 'string' ? value : '');
const bodyObj = (value: unknown): Record<string, unknown> =>
  value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
const bodyStrings = (value: unknown): Record<string, string> => {
  const out: Record<string, string> = {};
  for (const [key, item] of Object.entries(bodyObj(value))) if (typeof item === 'string') out[key] = item;
  return out;
};
const flowKeyOf = (req: Request): string => strField(req.query.flow);

export interface VendorPortalConfig {
  store: FinancialStore;
  bindings: readonly DatasetBinding[];
  /** Operator actor numbers allowed to sign on. */
  operators: readonly string[];
  branding: DeploymentBranding;
  /** Defaults to a generated token printed once at startup; the admin surface never exposes business writes. */
  adminToken?: string;
  verbose?: boolean;
  renderPage?: (branding: DeploymentBranding, model: PageModel) => SafeHtml;
  assetsDirectory?: string;
}

export interface VendorPortal {
  app: express.Express;
  sessions: SessionStore;
  drafts: DraftStore;
}

const here = dirname(fileURLToPath(import.meta.url));

export function createVendorPortal(config: VendorPortalConfig): VendorPortal {
  const renderPage = config.renderPage ?? page;
  const app = express();
  app.disable('x-powered-by');
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));
  const sessions = createSessionStore();
  const drafts = new DraftStore();
  const adminToken = config.adminToken ?? `admin-${randomUUID()}`;

  const cookie = (req: Request): string | undefined => {
    const header = req.headers.cookie ?? '';
    const match = /(?:^|;\s*)vps=([0-9a-f-]{36})/.exec(header);
    return match?.[1];
  };

  const respond = (res: Response, status: number, model: PageModel | { error: string }, rc?: RequestContext): void => {
    if ('error' in model && !('body' in model)) {
      res.status(status === 200 ? 404 : status).send(renderPage(config.branding, {
        title: 'Not found', crumbs: [{ label: 'Home', href: '/' }],
        ...(rc === undefined ? {} : { operator: { displayName: rc.displayName, actorNumber: rc.actorNumber } }),
        body: html`<p class="errors">${model.error}</p>`,
      }).value);
      return;
    }
    if ('body' in model && typeof model.body === 'object' && model.body !== null && 'error' in model.body) {
      const m = model as PageModel;
      res.status(status === 200 ? 404 : status).send(renderPage(config.branding, {
        title: m.title, crumbs: m.crumbs ?? [{ label: 'Home', href: '/' }],
        ...(rc === undefined ? {} : { operator: { displayName: rc.displayName, actorNumber: rc.actorNumber } }),
        body: html`<p class="errors">${(m.body as { error: string }).error}</p>`,
      }).value);
      return;
    }
    res.status(status).send(renderPage(config.branding, model as PageModel).value);
  };

  const rcOf = (req: Request, res: Response): { rc: RequestContext; session: PortalSession } | undefined => {
    const session = sessions.get(cookie(req) ?? '');
    if (session === undefined || session.actorNumber === null) {
      res.redirect(303, '/signon');
      return undefined;
    }
    const bindingIndex = sessionBinding(session, config.bindings);
    if (bindingIndex === undefined) {
      res.redirect(303, '/signon');
      return undefined;
    }
    const rc = resolveOperator(config.store, bindingIndex, session.actorNumber, session.id);
    if (rc === undefined) {
      sessions.setActor(session.id, null);
      res.redirect(303, '/signon');
      return undefined;
    }
    return { rc, session };
  };

  function sessionBinding(session: PortalSession, bindings: readonly DatasetBinding[]): DatasetBinding | undefined {
    const record = session as PortalSession & { bindingIndex?: number };
    return bindings[record.bindingIndex ?? 0];
  }

  // --- Sign on ---
  app.get('/signon', (_req, res) => {
    res.send(renderPage(config.branding, {
      title: 'Sign on',
      body: html`<form method="post" action="/signon"><table class="form">
        <tr><th>Operator</th><td><select name="actorNumber">${config.operators.map((number) => html`<option>${number}</option>`)}</select></td></tr>
        ${config.bindings.length <= 1 ? '' : html`<tr><th>Institution</th><td><select name="binding">${config.bindings.map((binding, index) => html`<option value="${index}">${binding.institutionId}</option>`)}</select></td></tr>`}
        </table><p class="actions"><button type="submit">Sign on</button></p></form>`,
    }).value);
  });

  app.post('/signon', (req, res) => {
    const body = bodyObj(req.body);
    const actorNumber = strField(body.actorNumber);
    const bindingIndex = Number(strField(body.binding) || '0');
    const binding = config.bindings[bindingIndex];
    if (!config.operators.includes(actorNumber) || binding === undefined) {
      res.status(403).send(renderPage(config.branding, { title: 'Sign on failed', body: html`<p class="errors">The operator or institution is not permitted here.</p><p><a href="/signon">Try again</a></p>` }).value);
      return;
    }
    const probe = resolveOperator(config.store, binding, actorNumber, 'probe');
    if (probe === undefined) {
      res.status(403).send(renderPage(config.branding, { title: 'Sign on failed', body: html`<p class="errors">No active operator matches ${actorNumber} in this dataset.</p><p><a href="/signon">Try again</a></p>` }).value);
      return;
    }
    const session = sessions.create(actorNumber);
    (session as PortalSession & { bindingIndex?: number }).bindingIndex = bindingIndex;
    res.setHeader('Set-Cookie', `vps=${session.id}; Path=/; HttpOnly; SameSite=Lax`);
    res.redirect(303, '/');
  });

  app.get('/signout', (req, res) => {
    const id = cookie(req);
    if (id !== undefined) sessions.delete(id);
    res.setHeader('Set-Cookie', 'vps=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0');
    res.redirect(303, '/signon');
  });

  app.get('/', (req, res) => {
    const session = sessions.get(cookie(req) ?? '');
    if (session === undefined || session.actorNumber === null) { res.redirect(303, '/signon'); return; }
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Welcome', operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: homePage(auth.rc),
    }, auth.rc);
  });

  // --- Module landing pages ---
  const moduleRoutes: Record<string, (rc: RequestContext, req: Request) => SafeHtml | { error: string }> = {
    members: (rc, req) => membersPage(rc, req.query as Record<string, string | undefined>),
    accounts: (rc, req) => accountsPage(rc, req.query as Record<string, string | undefined>),
    cases: (rc, req) => casesPage(rc, req.query as Record<string, string | undefined>),
    money: (rc) => recordListPage(rc, 'journals'),
    payments: (rc) => recordListPage(rc, 'payments'),
    cards: (rc) => recordListPage(rc, 'cards'),
    loans: (rc) => recordListPage(rc, 'loans'),
    documents: () => html`${documentSearchForm()}`,
    servicing: () => moduleLanding('servicing'),
    maintenance: (rc) => recordListPage(rc, 'requests'),
    reconciliation: (rc) => { const list = recordListPage(rc, 'batches'); return 'error' in list ? list : html`<p><a href="/reconciliation/inquiry">Open read-only reconciliation inquiries</a></p>${list}`; },
    approvals: (rc) => approvalsPage(rc),
    searches: (rc) => searchesPage(rc),
    system: (rc) => systemPage(rc),
    activity: (rc) => activityPage(rc),
  };

  for (const [module, handler] of Object.entries(moduleRoutes)) {
    app.get(`/${module}`, (req, res) => {
      const auth = rcOf(req, res);
      if (auth === undefined) return;
      const body = handler(auth.rc, req);
      respond(res, 200, {
        title: module in MODULE_LABELS ? MODULE_LABELS[module as ModuleKey] : module, module: module as ModuleKey,
        crumbs: [{ label: 'Home', href: '/' }],
        operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
        body,
      }, auth.rc);
    });
  }

  // List subroutes under modules
  app.get('/list/:name', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: `Records · ${req.params.name}`, crumbs: [{ label: 'Home', href: '/' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: recordListPage(auth.rc, req.params.name),
    }, auth.rc);
  });

  app.get('/documents/search', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Document search', module: 'documents', crumbs: [{ label: 'Home', href: '/' }, { label: 'Documents', href: '/documents' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: html`${documentSearchForm()}${docSearchResults(auth.rc, req.query as Record<string, string | undefined>)}`,
    }, auth.rc);
  });

  app.get('/reconciliation/inquiry', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Reconciliation inquiry', module: 'reconciliation', crumbs: [{ label: 'Home', href: '/' }, { label: 'Reconciliation', href: '/reconciliation' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber }, body: reconciliationInquiryPage(auth.rc, req.query as Record<string, string | undefined>),
    }, auth.rc);
  });

  app.get('/record/:kind/:id', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: `Record`, crumbs: [{ label: 'Home', href: '/' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: recordPage(auth.rc, req.params.kind, req.params.id),
    }, auth.rc);
  });

  app.get('/member/:id', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Member', module: 'members', crumbs: [{ label: 'Home', href: '/' }, { label: 'Members', href: '/members' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: memberPage(auth.rc, req.params.id),
    }, auth.rc);
  });

  app.get('/account/:id', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Account', module: 'accounts', crumbs: [{ label: 'Home', href: '/' }, { label: 'Accounts', href: '/accounts' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: accountPage(auth.rc, req.params.id, req.query as Record<string, string | undefined>),
    }, auth.rc);
  });

  app.get('/account/:id/statement', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const period = strField(req.query.period);
    respond(res, 200, {
      title: 'Account statement', module: 'accounts', crumbs: [{ label: 'Home', href: '/' }, { label: 'Accounts', href: '/accounts' }, { label: 'Statement' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber }, body: statementPage(auth.rc, req.params.id, period),
    }, auth.rc);
  });

  app.get('/account/:id/statement/download', async (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const period = strField(req.query.period);
    const format = strField(req.query.format);
    const account = auth.rc.store.read((db) => db.prepare('SELECT member_id FROM accounts WHERE dataset_id=? AND id=?').get(auth.rc.binding.datasetId, req.params.id) as { member_id: string } | undefined);
    if (account === undefined || !['html', 'csv', 'pdf'].includes(format)) { res.status(404).send('Statement artifact not found.'); return; }
    const artifact = await exportStatement(auth.rc.store, auth.rc.context, { memberId: account.member_id, accountId: req.params.id, period, formats: [format as 'html' | 'csv' | 'pdf'], destinationId: 'browser-download' }, ['browser-download']);
    if (artifact.kind !== 'artifacts' || artifact.artifacts[0] === undefined) { res.status(400).send('message' in artifact ? artifact.message : 'Statement artifact unavailable.'); return; }
    const file = artifact.artifacts[0];
    res.setHeader('Content-Type', file.mediaType);
    res.setHeader('Content-Disposition', `attachment; filename="${file.displayName.replaceAll('"', '')}"`);
    res.send(Buffer.from(file.bytes));
  });

  app.get('/case/:id', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Case', module: 'cases', crumbs: [{ label: 'Home', href: '/' }, { label: 'Cases', href: '/cases' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: casePage(auth.rc, req.params.id),
    }, auth.rc);
  });

  app.get('/request/:id', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Maintenance request', module: 'maintenance', crumbs: [{ label: 'Home', href: '/' }, { label: 'Maintenance', href: '/maintenance' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: requestPage(auth.rc, req.params.id),
    }, auth.rc);
  });

  app.get('/comm/:id', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Communication', crumbs: [{ label: 'Home', href: '/' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: commPage(auth.rc, req.params.id),
    }, auth.rc);
  });

  app.get('/doc-version/:id', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Document version', module: 'documents', crumbs: [{ label: 'Home', href: '/' }, { label: 'Documents', href: '/documents' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: docVersionPage(auth.rc, req.params.id),
    }, auth.rc);
  });

  app.get('/doc-version/:id/download', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const result = docDownload(auth.rc, req.params.id);
    if ('error' in result) { res.status(404).send(result.error); return; }
    res.setHeader('Content-Type', result.mediaType);
    res.setHeader('Content-Disposition', `attachment; filename="${result.name.replaceAll('"', '')}"`);
    res.send(Buffer.from(result.bytes));
  });

  app.get('/receipts', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const number = req.query.number;
    if (typeof number === 'string' && number !== '') {
      res.redirect(303, `/receipt/${encodeURIComponent(number)}`);
      return;
    }
    respond(res, 200, {
      title: 'Receipts', crumbs: [{ label: 'Home', href: '/' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: html`<form method="get" action="/receipts"><label>Receipt number <input type="text" name="number" class="mono"></label> <button type="submit">Look up</button></form>`,
    }, auth.rc);
  });

  app.get('/receipt/:number', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    respond(res, 200, {
      title: 'Receipt', crumbs: [{ label: 'Home', href: '/' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: receiptPage(auth.rc, req.params.number),
    }, auth.rc);
  });

  // --- Approval decision (checker surface) ---
  app.get('/approval/:id/decide', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const result = listApprovals(auth.rc.store, auth.rc.context, 200);
    const item = result.kind === 'found' ? result.approvals.find((a) => a.id === req.params.id) : undefined;
    if (item === undefined) { respond(res, 404, { error: 'Approval not found or not yours.' }, auth.rc); return; }
    respond(res, 200, {
      title: 'Decide approval', module: 'approvals', crumbs: [{ label: 'Home', href: '/' }, { label: 'Approvals', href: '/approvals' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: html`<h2>Scope under review</h2><pre class="mono small">${JSON.stringify(item.target, null, 2)}</pre>
      <p>Amount limit: ${item.amountLimit === null ? 'unlimited' : `${item.amountLimit.minorUnits} ${item.amountLimit.currency}`} · Expires ${item.expiresAt}</p>
      <form method="post" action="/approval/${item.id}/decide"><table class="form">
      <tr><th>Decision</th><td><label><input type="radio" name="decision" value="approve" checked> Approve</label> <label><input type="radio" name="decision" value="deny"> Deny</label></td></tr>
      <tr><th>Reason</th><td><input type="text" name="reason" size="60" required></td></tr>
      </table><input type="hidden" name="fingerprint" value="${item.fingerprint}">
      <p class="actions"><button type="submit">Record decision</button></p></form>`,
    }, auth.rc);
  });

  app.post('/approval/:id/decide', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const body = bodyObj(req.body);
    const command = {
      kind: 'approval.decide',
      approvalId: req.params.id,
      expectedFingerprint: strField(body.fingerprint),
      decision: strField(body.decision),
      reason: strField(body.reason),
    };
    const outcome = executeCommand(auth.rc.store, auth.rc.context, command as never, `vendor:decide:${req.params.id}:${auth.session.id}`);
    respond(res, 200, {
      title: 'Approval decision', module: 'approvals',
      crumbs: [{ label: 'Home', href: '/' }, { label: 'Approvals', href: '/approvals' }],
      operator: { displayName: auth.rc.displayName, actorNumber: auth.rc.actorNumber },
      body: outcome.kind === 'committed' || outcome.kind === 'duplicate'
        ? html`<div class="committed"><h2>Decision recorded</h2><p>Receipt <a class="mono" href="/receipt/${outcome.receipt.receiptNumber}">${outcome.receipt.receiptNumber}</a></p><p><a href="/approvals">Back to approvals</a></p></div>`
        : outcome.kind === 'unchanged'
          ? html`<p class="notice">${outcome.message}</p><p><a href="/approvals">Back to approvals</a></p>`
          : html`<div class="errors"><b>${outcome.code}</b> — ${outcome.message}</div><p><a href="/approvals">Back to approvals</a></p>`,
    }, auth.rc);
  });

  // --- Operation engine ---
  const specFor = (kind: string, res: Response): OperationSpec | undefined => {
    const spec = operationSpec(kind);
    if (spec === undefined) respond(res, 404, { error: `Unknown operation ${kind}.` });
    return spec;
  };

  const wrap = (title: string, spec: OperationSpec, rc: RequestContext, body: SafeHtml): PageModel => ({
    title: `${spec.title} — ${title}`, module: spec.module,
    crumbs: [{ label: 'Home', href: '/' }, { label: MODULE_LABELS[spec.module], href: `/${spec.module}` }, { label: spec.title }],
    operator: { displayName: rc.displayName, actorNumber: rc.actorNumber },
    body,
  });

  app.get('/op/:kind', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    if (spec.subjects.length === 0) {
      const draft = drafts.create(auth.session.id, spec.kind);
      res.redirect(303, `/op/${spec.kind}/form?flow=${draft.key}`);
      return;
    }
    respond(res, 200, wrap('select records', spec, auth.rc, subjectPage(spec, [], {})), auth.rc);
  });

  app.post('/op/:kind/select', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const posted = bodyStrings(bodyObj(req.body).subject);
    const issues: FormIssue[] = [];
    const subjects: Record<string, string> = {};
    auth.rc.store.read((db) => {
      for (const subject of spec.subjects) {
        const input = posted[subject.key] ?? '';
        if (input.trim() === '') {
          if (subject.optional !== true) issues.push({ field: subject.key, message: `${subject.label} is required.` });
          continue;
        }
        const resolved = resolveRef(auth.rc, db, subject.ref, input);
        if ('error' in resolved) issues.push({ field: subject.key, message: `${subject.label}: ${resolved.error}` });
        else subjects[subject.key] = resolved.id;
      }
    });
    if (issues.length > 0) {
      respond(res, 200, wrap('select records', spec, auth.rc, subjectPage(spec, issues, posted)), auth.rc);
      return;
    }
    const draft = drafts.create(auth.session.id, spec.kind);
    draft.subjects = subjects;
    const { resolved, issues: resolveIssues } = resolveValues(auth.rc, spec.resolved, subjects);
    draft.resolved = resolved;
    if (resolveIssues.length > 0) {
      respond(res, 200, wrap('select records', spec, auth.rc, subjectPage(spec, resolveIssues.map((message) => ({ field: '', message })), posted)), auth.rc);
      return;
    }
    res.redirect(303, `/op/${spec.kind}/form?flow=${draft.key}`);
  });

  app.get('/op/:kind/form', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const draft = drafts.get(flowKeyOf(req), auth.session.id);
    if (draft === undefined || draft.kind !== spec.kind) { respond(res, 410, { error: 'That form draft expired. Start the operation again.' }, auth.rc); return; }
    if (Object.keys(draft.resolved).length === 0 && spec.resolved.length > 0) {
      const { resolved } = resolveValues(auth.rc, spec.resolved, draft.subjects);
      draft.resolved = resolved;
    }
    auth.rc.store.read((db) => {
      respond(res, 200, wrap('details', spec, auth.rc, formPage(auth.rc, db, spec, draft)), auth.rc);
    });
  });

  app.post('/op/:kind/review', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const draft = drafts.get(flowKeyOf(req), auth.session.id);
    if (draft === undefined || draft.kind !== spec.kind) { respond(res, 410, { error: 'That form draft expired. Start the operation again.' }, auth.rc); return; }
    if (strField(bodyObj(req.body).step) === 'cancel') {
      drafts.drop(draft.key, auth.session.id);
      res.redirect(303, `/${spec.module}`);
      return;
    }
    const body = bodyObj(bodyObj(req.body).f);
    draft.posted = body;
    draft.flags = {
      n: bodyObj(bodyObj(req.body).n),
      s: bodyObj(bodyObj(req.body).s),
    };
    const { resolved, issues: resolveIssues } = resolveValues(auth.rc, spec.resolved, { ...draft.subjects, ...flattenScalarKeys(body) });
    const issues = [...resolveIssues.map((message) => ({ field: '', message }))];
    const built = auth.rc.store.read((db) =>
      buildCommand(auth.rc, db, spec, draft.subjects, { ...draft.resolved, ...resolved }, { f: body, n: draft.flags.n, s: draft.flags.s }));
    if ('issues' in built) {
      draft.issues = [...issues, ...built.issues];
      res.redirect(303, `/op/${spec.kind}/form?flow=${draft.key}`);
      return;
    }
    if (issues.length > 0) {
      draft.issues = issues;
      res.redirect(303, `/op/${spec.kind}/form?flow=${draft.key}`);
      return;
    }
    draft.issues = [];
    const outcome = reviewCommand(auth.rc.store, auth.rc.context, built.command as never);
    draft.review = { command: built.command, fingerprint: fingerprint(built.command), outcome };
    res.redirect(303, `/op/${spec.kind}/review?flow=${draft.key}`);
  });

  app.get('/op/:kind/review', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const draft = drafts.get(flowKeyOf(req), auth.session.id);
    if (draft === undefined || draft.kind !== spec.kind) { respond(res, 410, { error: 'That form draft expired. Start the operation again.' }, auth.rc); return; }
    auth.rc.store.read((db) => {
      respond(res, 200, wrap('review', spec, auth.rc, reviewPage(auth.rc, db, spec, draft)), auth.rc);
    });
  });

  app.post('/op/:kind/commit', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const draft = drafts.get(flowKeyOf(req), auth.session.id);
    if (draft === undefined || draft.kind !== spec.kind || draft.review === undefined) {
      respond(res, 410, { error: 'Nothing reviewed to commit.' }, auth.rc); return;
    }
    if (draft.review.outcome.kind !== 'reviewable') {
      draft.committed = draft.review.outcome;
      res.redirect(303, `/op/${spec.kind}/result?flow=${draft.key}`);
      return;
    }
    const command = draft.review.command;
    // Execution owns atomic revalidation and checks durable idempotency first.
    // A separate review here would reject a successful retry as stale.
    const outcome = executeCommand(auth.rc.store, auth.rc.context, command as never, `vendor:${draft.key}`);
    draft.committed = outcome;
    res.redirect(303, `/op/${spec.kind}/result?flow=${draft.key}`);
  });

  app.post('/op/:kind/request-approval', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const draft = drafts.get(flowKeyOf(req), auth.session.id);
    const awaitingApproval = spec.approval === true && draft?.review?.outcome.kind === 'rejected';
    if (draft === undefined || draft.kind !== spec.kind || draft.review === undefined || (draft.review.outcome.kind !== 'reviewable' && !awaitingApproval)) {
      respond(res, 410, { error: 'Review the operation first.' }, auth.rc); return;
    }
    const a = bodyStrings(bodyObj(req.body).a);
    const issues: FormIssue[] = [];
    const target = { ...draft.review.command, approvalId: draft.review.command.approvalId ?? '' };
    const command: Record<string, unknown> = {
      kind: 'approval.request', target,
      checkerActorId: a.checkerActorId ?? '', policyVersionId: a.policyVersionId ?? '',
      expiresAt: a.expiresAt ?? '', amountLimit: null,
    };
    if (typeof a.amount === 'string' && a.amount.trim() !== '') {
      const currency = a.currency ?? '';
      const entry = auth.rc.store.read((db) => referenceData(db, auth.rc.binding.datasetId, auth.rc.binding.institutionId).currencies.find((item) => item.code === currency));
      const amount = entry === undefined ? 'Choose a known currency.' : parseMoney(a.amount, currency, entry.exponent);
      if (typeof amount === 'string') issues.push({ field: 'amount', message: amount });
      else if (amount.minorUnits <= 0) issues.push({ field: 'amount', message: 'Amount limit must be positive.' });
      else command.amountLimit = amount;
    }
    if (issues.length > 0) { draft.issues = issues; res.redirect(303, `/op/${spec.kind}/review?flow=${draft.key}`); return; }
    const outcome = executeCommand(auth.rc.store, auth.rc.context, command as never, `vendor:approval:${draft.key}`);
    draft.committed = outcome;
    res.redirect(303, `/op/${spec.kind}/result?flow=${draft.key}`);
  });

  app.post('/op/:kind/abandon', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    drafts.drop(flowKeyOf(req), auth.session.id);
    res.redirect(303, `/${spec.module}`);
  });

  app.post('/op/:kind/form', (req, res) => {
    // Back-from-review posts land here; keep the draft and re-render the form.
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const draft = drafts.get(flowKeyOf(req), auth.session.id);
    if (draft === undefined) { respond(res, 410, { error: 'That form draft expired.' }, auth.rc); return; }
    res.redirect(303, `/op/${spec.kind}/form?flow=${draft.key}`);
  });

  app.get('/op/:kind/result', (req, res) => {
    const auth = rcOf(req, res);
    if (auth === undefined) return;
    const spec = specFor(req.params.kind, res);
    if (spec === undefined) return;
    const draft = drafts.get(flowKeyOf(req), auth.session.id);
    if (draft === undefined || draft.kind !== spec.kind) { respond(res, 410, { error: 'That result expired.' }, auth.rc); return; }
    respond(res, 200, wrap('result', spec, auth.rc, resultPage(spec, draft)), auth.rc);
  });

  // --- Admin boundary ---
  app.get('/admin', (req, res) => {
    const token = strField(req.query.token);
    if (token !== adminToken) { res.status(403).send('Administration requires the instance token.'); return; }
    res.send(renderPage(config.branding, {
      title: 'Administration',
      body: html`<table class="deflist"><tbody>
      <tr><th>Institutions</th><td>${config.bindings.map((b) => html`<span class="mono">${b.institutionId}:${b.datasetId}</span><br>`)}</td></tr>
      <tr><th>Operators</th><td>${config.operators.join(', ')}</td></tr>
      <tr><th>Sessions</th><td>${sessions.count()}</td></tr>
      <tr><th>Operations</th><td>${operationCount()}</td></tr></tbody></table>`,
    }).value);
  });

  if (config.assetsDirectory !== undefined) app.use('/static', express.static(config.assetsDirectory));
  app.use('/static', express.static(join(here, '..', 'static')));

  return { app, sessions, drafts };
}

function operationCount(): number {
  return OPERATION_COUNT;
}

/** Posted field values that are plain scalars (subject-style ids) feed field-bound resolvers. */
function flattenScalarKeys(body: Record<string, unknown>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [key, value] of Object.entries(body)) if (typeof value === 'string' && value !== '') out[key] = value;
  return out;
}

const fingerprint = (command: Record<string, unknown>): string => {
  const canonical = (value: unknown): unknown => {
    if (Array.isArray(value)) return value.map(canonical);
    if (value !== null && typeof value === 'object') {
      if (value instanceof Uint8Array) return { bytes: value.byteLength };
      return Object.fromEntries(Object.keys(value as Record<string, unknown>).sort().map((key) => [key, canonical((value as Record<string, unknown>)[key])]));
    }
    return value;
  };
  return createHash('sha256').update(JSON.stringify(canonical(command))).digest('hex');
};

function moduleLanding(module: ModuleKey): SafeHtml {
  return html`<table class="grid"><thead><tr><th>Operation</th><th>Command</th><th>Description</th></tr></thead><tbody>
    ${operationsByModule(module).map((spec) => html`<tr><td><a href="/op/${spec.kind}">${spec.title}</a></td><td class="mono small">${spec.kind}</td><td>${spec.summary}</td></tr>`)}
  </tbody></table>`;
}

function documentSearchForm(): SafeHtml {
  return html`<form method="get" action="/documents/search"><fieldset class="filters"><legend>Find documents</legend>
    <label>Member number <input type="text" name="member" class="mono"></label>
    <label>Text <input type="text" name="q"></label>
    <button type="submit">Search</button></fieldset></form>`;
}

function docSearchResults(rc: RequestContext, query: Record<string, string | undefined>): SafeHtml {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    let memberId: string | undefined;
    if (query.member !== undefined && query.member.trim() !== '') {
      const resolved = resolveRef(rc, db, 'member', query.member);
      if ('error' in resolved) return html`<p class="notice">${resolved.error}</p>`;
      memberId = resolved.id;
    }
    const result = searchDocuments(db, rc.binding.datasetId, {
      limit: 100, offset: 0, sort: 'issued', direction: 'desc',
      ...(memberId === undefined ? {} : { memberId }),
      ...(query.q === undefined || query.q === '' ? {} : { query: query.q }),
    }, { institutionId: rc.binding.institutionId, actorId: rc.actorId });
    return table(['Version', 'Document', 'Member', 'Type', 'Media', 'Issued'],
      result.items.map((row) => [link(`/doc-version/${row.versionId}`, `v${row.version}`), row.displayName, link(`/member/${row.memberId}`, row.memberNumber), row.documentType, row.mediaType, formatInstant(row.issuedAt)]));
  });
}
