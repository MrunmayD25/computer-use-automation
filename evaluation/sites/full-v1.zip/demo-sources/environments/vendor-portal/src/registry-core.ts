import type { OperationSpec } from './spec.js';

const MEMBER = { key: 'memberId', label: 'Member', ref: 'member' as const };
const ACCOUNT = { key: 'accountId', label: 'Account', ref: 'account' as const };
const CASE = { key: 'caseId', label: 'Case', ref: 'case' as const };
const VERSION = (subject: string) => ({ key: 'expectedVersion', resolver: { of: 'version' as const, subject } });
const MEMBER_VERSION = (subject = 'memberId') => ({ key: 'expectedVersion', resolver: { of: 'memberVersion' as const, subject } });

export const CORE_OPERATIONS: readonly OperationSpec[] = [
  {
    kind: 'member.create', task: 'T001', module: 'members', title: 'Create member',
    summary: 'Enrolls a new person member with legal name, birth date and optional contact points.',
    subjects: [], resolved: [],
    fields: [
      { key: 'legalGiven', label: 'Legal given name', input: 'text', maxLength: 60 },
      { key: 'legalFamily', label: 'Legal family name', input: 'text', maxLength: 60 },
      { key: 'preferredName', label: 'Preferred name', input: 'text', nullable: true, maxLength: 60 },
      { key: 'birthDate', label: 'Birth date', input: 'date' },
      { key: 'email', label: 'Email', input: 'text', nullable: true },
      { key: 'phone', label: 'Phone', input: 'text', nullable: true },
      { key: 'address', label: 'Mailing address', input: 'address', nullable: true },
    ],
  },
  {
    kind: 'member.organization.create', task: 'T001', module: 'members', title: 'Create organization member',
    summary: 'Enrolls a new organization member for beneficial-ownership servicing.',
    subjects: [], resolved: [],
    fields: [
      { key: 'legalName', label: 'Legal name', input: 'text', maxLength: 120 },
      { key: 'registrationNumber', label: 'Registration number', input: 'text' },
      { key: 'organizationType', label: 'Organization type', input: 'select', choices: ['corporation', 'nonprofit'] },
      { key: 'email', label: 'Email', input: 'text', nullable: true },
      { key: 'phone', label: 'Phone', input: 'text', nullable: true },
      { key: 'address', label: 'Mailing address', input: 'address', nullable: true },
    ],
  },
  {
    kind: 'contact.update', task: 'T002', module: 'members', title: 'Update contact details',
    summary: 'Changes the member\'s current email, phone or mailing address. Unchanged fields keep their values.',
    subjects: [MEMBER], resolved: [VERSION('memberId')],
    fields: [
      { key: 'email', label: 'Email', input: 'text', optional: true, nullable: true },
      { key: 'phone', label: 'Phone', input: 'text', optional: true, nullable: true },
      { key: 'address', label: 'Mailing address', input: 'address', optional: true },
    ],
  },
  {
    kind: 'member.note.add', task: 'T003', module: 'members', title: 'Add member note',
    summary: 'Appends a general or restricted note to the member record.',
    subjects: [MEMBER], resolved: [],
    fields: [
      { key: 'visibility', label: 'Visibility', input: 'select', choices: ['general', 'restricted'], help: 'Restricted notes need case or supervisory authority to read.' },
      { key: 'text', label: 'Note', input: 'textarea', maxLength: 2000 },
    ],
  },
  {
    kind: 'account.open', task: 'T004', module: 'accounts', title: 'Open account',
    summary: 'Opens a new deposit account for the member under a current product.',
    subjects: [MEMBER], resolved: [],
    fields: [
      { key: 'productId', label: 'Product', input: 'select', provider: 'products' },
      { key: 'nickname', label: 'Nickname', input: 'text', maxLength: 40 },
      { key: 'statementDelivery', label: 'Statement delivery', input: 'select', choices: ['paper', 'electronic'] },
    ],
  },
  {
    kind: 'account.nickname.update', task: 'T005', module: 'accounts', title: 'Rename account',
    summary: 'Changes the display nickname of an open account.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')],
    fields: [{ key: 'nickname', label: 'New nickname', input: 'text', maxLength: 40 }],
  },
  {
    kind: 'account.statement_delivery.update', task: 'T006', module: 'accounts', title: 'Change statement delivery',
    summary: 'Switches the account between paper and electronic statement delivery.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')],
    fields: [{ key: 'statementDelivery', label: 'Statement delivery', input: 'select', choices: ['paper', 'electronic'] }],
  },
  {
    kind: 'account.close', task: 'T007', module: 'accounts', title: 'Close account',
    summary: 'Closes an account once every closure blocker is cleared. The review lists remaining blockers.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')],
    fields: [{ key: 'reason', label: 'Closure reason', input: 'text', maxLength: 500 }],
  },
  {
    kind: 'cash.deposit', task: 'T008', module: 'money', title: 'Deposit cash',
    summary: 'Posts an exact cash deposit to the account ledger.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')],
    fields: [
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'description', label: 'Description', input: 'text', maxLength: 120 },
    ],
  },
  {
    kind: 'cash.withdraw', task: 'T009', module: 'money', title: 'Withdraw cash',
    summary: 'Posts an exact cash withdrawal when the account is eligible and funded.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')],
    fields: [
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'description', label: 'Description', input: 'text', maxLength: 120 },
    ],
  },
  {
    kind: 'transfer.internal', task: 'T010', module: 'money', title: 'Internal transfer',
    summary: 'Moves exact funds between two open accounts in the same currency.',
    subjects: [
      { key: 'sourceAccountId', label: 'From account', ref: 'account' },
      { key: 'destinationAccountId', label: 'To account', ref: 'account' },
    ],
    resolved: [
      { key: 'expectedSourceVersion', resolver: { of: 'version', subject: 'sourceAccountId' } },
      { key: 'expectedDestinationVersion', resolver: { of: 'version', subject: 'destinationAccountId' } },
    ],
    fields: [
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'description', label: 'Description', input: 'text', maxLength: 120 },
    ],
  },
  {
    kind: 'case.open', task: 'T065', module: 'cases', title: 'Open servicing case',
    summary: 'Opens a servicing case in a queue with a category, priority and due date.',
    subjects: [MEMBER],
    resolved: [],
    fields: [
      { key: 'accountId', label: 'Related account', input: 'ref', ref: 'account', provider: 'memberAccounts', nullable: true },
      { key: 'queueId', label: 'Queue', input: 'select', provider: 'queues' },
      { key: 'assignedActorId', label: 'Assign to', input: 'select', provider: 'caseWorkers', nullable: true },
      { key: 'category', label: 'Category', input: 'select', choices: [
        { value: 'account-servicing', label: 'Account servicing' }, { value: 'address-evidence', label: 'Address evidence' },
        { value: 'contact-evidence', label: 'Contact evidence' }, { value: 'statement-copy', label: 'Statement copy' },
        { value: 'transaction-inquiry', label: 'Transaction inquiry' }, { value: 'fee-inquiry', label: 'Fee inquiry' },
        { value: 'complaint', label: 'Complaint' }, { value: 'general', label: 'General servicing' },
      ] },
      { key: 'priority', label: 'Priority', input: 'select', choices: ['low', 'normal', 'high', 'urgent'] },
      { key: 'summary', label: 'Summary', input: 'text', maxLength: 200 },
      { key: 'dueDate', label: 'Due date', input: 'date' },
    ],
  },
  {
    kind: 'case.assign', task: 'T066', module: 'cases', title: 'Route or assign case',
    summary: 'Moves a case to a queue and assigns a caseworker. Widening visibility needs supervisory authority.',
    subjects: [CASE], resolved: [VERSION('caseId')],
    fields: [
      { key: 'queueId', label: 'Queue', input: 'select', provider: 'queues' },
      { key: 'assignedActorId', label: 'Assign to', input: 'select', provider: 'caseWorkers', nullable: true },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
    ],
  },
  {
    kind: 'case.transition', task: 'T066', module: 'cases', title: 'Transition case state',
    summary: 'Moves a case through its allowed state machine without rewriting history.',
    subjects: [CASE], resolved: [VERSION('caseId')],
    fields: [
      { key: 'toState', label: 'New state', input: 'select', choices: ['open', 'pending-customer', 'pending-internal', 'resolved', 'reopened'] },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
    ],
  },
  {
    kind: 'case.note.add', task: 'T091', module: 'cases', title: 'Add case note',
    summary: 'Appends a note with optional document evidence to the case record.',
    subjects: [CASE], resolved: [],
    fields: [
      { key: 'visibility', label: 'Visibility', input: 'select', choices: ['general', 'restricted'] },
      { key: 'text', label: 'Note', input: 'textarea', maxLength: 2000 },
      { key: 'evidenceVersionIds', label: 'Evidence documents', input: 'multiselect', provider: 'caseDocuments', optional: true },
    ],
  },
  {
    kind: 'search.saved.create', task: 'T092', module: 'searches', title: 'Save search',
    summary: 'Saves a reusable member, account or case search for this operator or the team.',
    subjects: [], resolved: [],
    fields: [
      { key: 'name', label: 'Search name', input: 'text', maxLength: 80 },
      { key: 'visibility', label: 'Visibility', input: 'select', choices: ['private', 'shared'], help: 'Shared searches need case or supervisory authority.' },
      { key: 'definition', label: 'Search definition', input: 'savedSearchDef' },
    ],
  },
  {
    kind: 'search.saved.update', task: 'T092', module: 'searches', title: 'Update saved search',
    summary: 'Renames, reshares or redefines one of this operator\'s saved searches.',
    subjects: [{ key: 'searchId', label: 'Saved search', ref: 'saved-search' }],
    resolved: [{ key: 'expectedRevision', resolver: { of: 'savedSearchRevision', subject: 'searchId' } }],
    fields: [
      { key: 'name', label: 'Search name', input: 'text', optional: true, maxLength: 80 },
      { key: 'visibility', label: 'Visibility', input: 'select', choices: ['private', 'shared'], optional: true },
      { key: 'definition', label: 'Search definition', input: 'savedSearchDef', optional: true },
    ],
  },
  {
    kind: 'search.saved.delete', task: 'T092', module: 'searches', title: 'Delete saved search',
    summary: 'Removes one of this operator\'s saved searches.',
    subjects: [{ key: 'searchId', label: 'Saved search', ref: 'saved-search' }],
    resolved: [{ key: 'expectedRevision', resolver: { of: 'savedSearchRevision', subject: 'searchId' } }],
    fields: [],
  },
  {
    kind: 'edit.cancel', task: 'T089', module: 'maintenance', title: 'Discard maintenance draft',
    summary: 'Discards a saved maintenance draft durably; the record keeps its history.',
    subjects: [{ key: 'requestId', label: 'Maintenance request', ref: 'maintenance-request' }],
    resolved: [{ key: 'expectedUpdatedAt', resolver: { of: 'requestUpdatedAt', subject: 'requestId' } }],
    fields: [],
  },
];

export { MEMBER_VERSION };
