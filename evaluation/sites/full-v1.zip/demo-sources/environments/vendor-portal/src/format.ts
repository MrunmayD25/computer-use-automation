import type { Money } from '@computer-use/financial-database/services';

/** Parses a decimal amount into exact minor units; rejects values that do not fit the exponent. */
export function parseMoney(text: string, currency: string, exponent: number): Money | string {
  const trimmed = text.trim().replaceAll(',', '');
  if (!/^-?\d+(\.\d+)?$/u.test(trimmed)) return 'Enter a plain decimal amount, for example 1234.56.';
  const negative = trimmed.startsWith('-');
  const unsigned = negative ? trimmed.slice(1) : trimmed;
  const [wholePart, fractionPart = ''] = unsigned.split('.');
  if (fractionPart.length > exponent) {
    return `This currency supports at most ${String(exponent)} decimal places.`;
  }
  const whole = Number(wholePart);
  const fraction = fractionPart.length === 0 ? 0 : Number(fractionPart.padEnd(exponent, '0'));
  if (!Number.isSafeInteger(whole) || !Number.isSafeInteger(fraction)) return 'The amount is outside the supported range.';
  const minorUnits = whole * 10 ** exponent + fraction;
  if (!Number.isSafeInteger(minorUnits)) return 'The amount is outside the supported range.';
  return { minorUnits: negative ? -minorUnits : minorUnits, currency };
}

/** Formats exact minor units for display using the ISO exponent. */
export function formatMoney(minorUnits: number, currency: string, exponent: number): string {
  const negative = minorUnits < 0;
  const magnitude = Math.abs(minorUnits);
  const divisor = 10 ** exponent;
  const whole = Math.floor(magnitude / divisor);
  const fraction = exponent === 0 ? '' : `.${String(magnitude % divisor).padStart(exponent, '0')}`;
  return `${negative ? '-' : ''}${whole.toLocaleString('en-US')}${fraction} ${currency}`;
}

/** `2026-09-14T15:00:00.000Z` -> `2026-09-14 15:00 UTC`; other values are shown as entered. */
export function formatInstant(value: string | null): string {
  if (value === null) return '—';
  const match = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})(?::\d{2}(?:\.\d+)?)?(Z|[+-]\d{2}:\d{2})$/u.exec(value);
  if (match === null) return value;
  return `${match[1] ?? ''} ${match[2] ?? ''} ${match[3] === 'Z' ? 'UTC' : match[3] ?? ''}`;
}

export function formatDate(value: string | null): string {
  return value ?? '—';
}

export function formatInstantInput(date: Date): string {
  return date.toISOString().replace(/\.\d{3}Z$/u, 'Z');
}
