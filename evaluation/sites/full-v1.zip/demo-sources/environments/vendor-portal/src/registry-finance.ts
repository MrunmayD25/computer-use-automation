import type { OperationSpec , FinanceRecordKindName } from './spec.js';

const ACCOUNT = { key: 'accountId', label: 'Account', ref: 'account' as const };
const MEMBER = { key: 'memberId', label: 'Member', ref: 'member' as const };
const VERSION = (subject: string) => ({ key: 'expectedVersion', resolver: { of: 'version' as const, subject } });
const MEMBER_VERSION = (subject = 'memberId') => ({ key: 'expectedVersion', resolver: { of: 'memberVersion' as const, subject } });
const MEMBER_VERSION_KEY = (key: string, subject: string) => ({ key, resolver: { of: 'memberVersion' as const, subject } });
const FINGERPRINT = (kind: FinanceRecordKindName, subject: string, key = 'expectedFingerprint') =>
  ({ key, resolver: { of: 'fingerprint' as const, kind, subject } });
const APPROVAL_FIELD = { key: 'approvalId', label: 'Approval', input: 'select' as const, provider: 'myApprovals' as const, optional: true, help: 'An approved request naming this exact change; request one from the review step when you have none.' };

const RAILS = ['ach', 'internal', 'wire', 'rtp'] as const;

export const FINANCE_OPERATIONS: readonly OperationSpec[] = [
  {
    kind: 'member.merge', task: 'T017', module: 'members', title: 'Merge member records',
    summary: 'Executes a reviewed merge plan, redirecting the source member into the target.',
    subjects: [{ key: 'mergePlanId', label: 'Merge plan', ref: 'merge-plan' }],
    resolved: [{ key: '', resolver: { of: 'mergeFacts', subject: 'mergePlanId' } }],
    approval: true,
    fields: [
      { key: 'relationshipAccountIds', label: 'Relationship account ids', input: 'lines', help: 'Account ids shared between the two members, one per line.' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'member.deceased.record', task: 'T018', module: 'members', title: 'Record member deceased',
    summary: 'Records the member\'s death against verified evidence; needs independent approval.',
    subjects: [MEMBER], resolved: [MEMBER_VERSION()], approval: true,
    fields: [
      { key: 'evidenceId', label: 'Authority evidence', input: 'select', provider: 'memberEvidenceVerified' },
      { key: 'effectiveDate', label: 'Date of death', input: 'date' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'member.beneficial_owners.update', task: 'T019', module: 'members', title: 'Update beneficial owners',
    summary: 'Replaces the organization member\'s verified beneficial-owner set; needs approval.',
    subjects: [{ key: 'organizationMemberId', label: 'Organization member', ref: 'member' }],
    resolved: [MEMBER_VERSION_KEY('expectedVersion', 'organizationMemberId')], approval: true,
    fields: [
      { key: 'owners', label: 'Beneficial owners', input: 'owners' },
      { key: 'effectiveDate', label: 'Effective date', input: 'date' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'member.tax_classification.update', task: 'T020', module: 'members', title: 'Update tax classification',
    summary: 'Changes the member\'s tax classification with evidence; needs approval.',
    subjects: [MEMBER], resolved: [MEMBER_VERSION()], approval: true,
    fields: [
      { key: 'classification', label: 'Classification', input: 'select', choices: ['individual', 'organization', 'tax-exempt'] },
      { key: 'effectiveYear', label: 'Effective year', input: 'integer', placeholder: '2026' },
      { key: 'evidenceId', label: 'Authority evidence', input: 'select', provider: 'memberEvidenceVerified' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'account.product.convert', task: 'T021', module: 'accounts', title: 'Convert account product',
    summary: 'Converts the account to another product; needs approval.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')], approval: true,
    fields: [
      { key: 'targetProductId', label: 'New product', input: 'select', provider: 'products' },
      { key: 'effectiveDate', label: 'Effective date', input: 'date' },
      { key: 'feeDisclosureAccepted', label: 'Fee disclosure accepted', input: 'boolean' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'account.owner.add', task: 'T022', module: 'accounts', title: 'Add account owner',
    summary: 'Adds a member as an owner or joint owner; needs approval.',
    subjects: [ACCOUNT, MEMBER], resolved: [VERSION('accountId')], approval: true,
    fields: [
      { key: 'role', label: 'Role', input: 'select', choices: ['owner', 'joint-owner'] },
      { key: 'effectiveDate', label: 'Effective date', input: 'date' },
      { key: 'identityEvidenceId', label: 'Identity evidence', input: 'select', provider: 'memberEvidenceVerified' },
      { key: 'consentId', label: 'Consent', input: 'select', provider: 'memberConsentsMail' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'account.signer.remove', task: 'T023', module: 'accounts', title: 'Remove signer',
    summary: 'Ends a signer\'s authority on the account; needs approval.',
    subjects: [ACCOUNT, { key: 'signerMemberId', label: 'Signer member', ref: 'member' }],
    resolved: [VERSION('accountId')], approval: true,
    fields: [
      { key: 'effectiveAt', label: 'Effective at', input: 'instant' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'account.overdraft_limit.update', task: 'T024', module: 'accounts', title: 'Update overdraft limit',
    summary: 'Sets the overdraft facility limit for a period; needs approval.',
    subjects: [ACCOUNT],
    resolved: [VERSION('accountId'), { key: 'expectedFacilityFingerprint', resolver: { of: 'overdraftFacilityFingerprint', subject: 'accountId' } }],
    approval: true,
    fields: [
      { key: 'limit', label: 'New limit', input: 'money' },
      { key: 'effectiveDate', label: 'Effective date', input: 'date' },
      { key: 'expiresAt', label: 'Expires at', input: 'instant', nullable: true },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'account.hold.place', task: 'T025', module: 'accounts', title: 'Place hold',
    summary: 'Places an exact-amount hold on the account.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')],
    fields: [
      { key: 'amount', label: 'Hold amount', input: 'money' },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      { key: 'expiresAt', label: 'Expires at', input: 'instant' },
      { key: 'releaseAuthority', label: 'Release authority', input: 'text', placeholder: 'operations' },
    ],
  },
  {
    kind: 'account.hold.release', task: 'T026', module: 'accounts', title: 'Release hold',
    summary: 'Releases part or all of an active hold.',
    subjects: [{ key: 'holdId', label: 'Hold', ref: 'hold' }], resolved: [FINGERPRINT('hold', 'holdId')],
    fields: [
      { key: 'amountMinorUnits', label: 'Release amount (minor units)', input: 'integer', help: 'Enter the exact minor-unit amount shown on the hold record.' },
      { key: 'releaseAuthority', label: 'Release authority', input: 'text' },
      { key: 'evidenceReference', label: 'Evidence reference', input: 'text' },
    ],
  },
  {
    kind: 'account.restriction.apply', task: 'T027', module: 'accounts', title: 'Apply restriction',
    summary: 'Applies a debit, credit, closure or review restriction under a case; needs approval.',
    subjects: [ACCOUNT, CASE_SUBJECT()], resolved: [VERSION('accountId')], approval: true,
    fields: [
      { key: 'restrictionType', label: 'Restriction', input: 'select', choices: ['debit-block', 'credit-block', 'closure-block', 'fraud-review', 'legal-hold'] },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      { key: 'authority', label: 'Authority', input: 'text' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'account.restriction.release', task: 'T028', module: 'accounts', title: 'Release restriction',
    summary: 'Releases an active restriction with clearance evidence; needs approval.',
    subjects: [{ key: 'restrictionId', label: 'Restriction', ref: 'restriction' }], resolved: [FINGERPRINT('restriction', 'restrictionId')], approval: true,
    fields: [
      { key: 'clearanceEvidenceId', label: 'Clearance evidence', input: 'ref', ref: 'identity-evidence' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'fee.assess', task: 'T029', module: 'money', title: 'Assess fee',
    summary: 'Posts a fee to the account under the fee policy, or waives it under an approved waiver.',
    subjects: [ACCOUNT], resolved: [VERSION('accountId')],
    fields: [
      { key: 'feeCode', label: 'Fee code', input: 'text', placeholder: 'monthly-service', maxLength: 60 },
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'basis', label: 'Basis', input: 'text', maxLength: 200 },
      { key: 'policyVersionId', label: 'Fee policy', input: 'select', provider: 'policyVersions' },
    ],
  },
  {
    kind: 'fee.waiver.create', task: 'T030', module: 'money', title: 'Register fee waiver',
    summary: 'Approves a prospective fee waiver window for the account; needs approval.',
    subjects: [ACCOUNT], resolved: [], approval: true,
    fields: [
      { key: 'feeCode', label: 'Fee code', input: 'text', maxLength: 60 },
      { key: 'validFrom', label: 'Valid from', input: 'date' },
      { key: 'validThrough', label: 'Valid through', input: 'date' },
      { key: 'amountLimit', label: 'Amount limit', input: 'money' },
      { key: 'maxOccurrences', label: 'Maximum occurrences', input: 'integer' },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'fee.refund', task: 'T031', module: 'money', title: 'Refund fee',
    summary: 'Refunds part or all of an assessed fee.',
    subjects: [{ key: 'feeId', label: 'Fee', ref: 'fee' }], resolved: [FINGERPRINT('fee', 'feeId')],
    fields: [
      { key: 'amount', label: 'Refund amount', input: 'money' },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
    ],
  },
  {
    kind: 'cash.deposit.reverse', task: 'T032', module: 'money', title: 'Reverse deposit',
    summary: 'Reverses a posted deposit journal with correction evidence; needs approval.',
    subjects: [{ key: 'journalId', label: 'Deposit journal', ref: 'journal' }], resolved: [FINGERPRINT('journal', 'journalId')], approval: true,
    fields: [
      { key: 'correctionEvidenceId', label: 'Correction evidence', input: 'ref', ref: 'identity-evidence' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'cash.withdrawal.reverse', task: 'T033', module: 'money', title: 'Reverse withdrawal',
    summary: 'Reverses a posted withdrawal journal; needs approval.',
    subjects: [{ key: 'journalId', label: 'Withdrawal journal', ref: 'journal' }], resolved: [FINGERPRINT('journal', 'journalId')], approval: true,
    fields: [
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'transfer.internal.reverse', task: 'T034', module: 'money', title: 'Reverse transfer',
    summary: 'Reverses an internal transfer journal for a stated amount; needs approval.',
    subjects: [{ key: 'transferJournalId', label: 'Transfer journal', ref: 'journal' }], resolved: [FINGERPRINT('journal', 'transferJournalId')], approval: true,
    fields: [
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'interest.adjust', task: 'T035', module: 'money', title: 'Adjust interest',
    summary: 'Applies an approved delta to a posted interest calculation; needs approval.',
    subjects: [{ key: 'calculationId', label: 'Interest calculation', ref: 'interest-calculation' }],
    resolved: [
      FINGERPRINT('interest-calculation', 'calculationId'),
      { key: 'accountId', resolver: { of: 'recordField', kind: 'interest-calculation', subject: 'calculationId', field: 'account_id' } },
    ],
    approval: true,
    fields: [
      { key: 'approvedDelta', label: 'Approved delta', input: 'signedMoney', help: 'Positive adds interest; negative removes it.' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'transaction.effective_date.correct', task: 'T036', module: 'money', title: 'Correct effective date',
    summary: 'Corrects a posting\'s effective date inside an open policy period; needs approval.',
    subjects: [{ key: 'journalId', label: 'Transaction journal', ref: 'journal' }], resolved: [FINGERPRINT('journal', 'journalId')], approval: true,
    fields: [
      { key: 'correctedDate', label: 'Corrected date', input: 'date' },
      { key: 'policyVersionId', label: 'Policy', input: 'select', provider: 'policyVersions' },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'transaction.description.update', task: 'T099', module: 'money', title: 'Correct transaction description',
    summary: 'Amends a posted transaction\'s description while preserving the original.',
    // The service fingerprints the transaction projection, including any prior display
    // amendment and effective-date correction. Using the journal snapshot here made the
    // review fingerprint differ from the commit-time projection and every ordinary edit
    // was rejected as stale.
    subjects: [{ key: 'journalId', label: 'Transaction journal', ref: 'journal' }], resolved: [FINGERPRINT('transaction', 'journalId')],
    fields: [{ key: 'description', label: 'New description', input: 'text', maxLength: 120 }],
  },
  {
    kind: 'beneficiary.create', task: 'T037', module: 'payments', title: 'Create beneficiary',
    summary: 'Creates a payment beneficiary with its first unverified route.',
    subjects: [MEMBER], resolved: [MEMBER_VERSION_KEY('expectedMemberVersion', 'memberId')],
    fields: [
      { key: 'displayName', label: 'Beneficiary name', input: 'text', maxLength: 120 },
      { key: 'routingKind', label: 'Routing kind', input: 'select', choices: [...RAILS] },
      { key: 'maskedDestination', label: 'Masked destination', input: 'text', placeholder: '****1234', maxLength: 80 },
      { key: 'simulatedToken', label: 'Route token', input: 'text', maxLength: 200 },
      { key: 'allowedRails', label: 'Allowed rails', input: 'multiselect', choices: [...RAILS], help: 'Must include the routing kind.' },
    ],
  },
  {
    kind: 'beneficiary.verify', task: 'T038', module: 'payments', title: 'Verify beneficiary route',
    summary: 'Verifies a beneficiary route against identity evidence; needs approval.',
    subjects: [{ key: 'routeId', label: 'Beneficiary route', ref: 'beneficiary-route' }],
    resolved: [
      FINGERPRINT('beneficiary-route', 'routeId'),
      { key: 'beneficiaryId', resolver: { of: 'routeBeneficiary', subject: 'routeId' } },
    ],
    approval: true,
    fields: [
      { key: 'evidenceId', label: 'Verification evidence', input: 'ref', ref: 'identity-evidence' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'beneficiary.routing.update', task: 'T039', module: 'payments', title: 'Update beneficiary route',
    summary: 'Supersedes the beneficiary\'s route with new routing details; needs approval.',
    subjects: [{ key: 'beneficiaryId', label: 'Beneficiary', ref: 'beneficiary' }],
    resolved: [{ key: 'expectedRouteFingerprint', resolver: { of: 'beneficiaryRoute', subject: 'beneficiaryId' } }],
    approval: true,
    fields: [
      { key: 'routingKind', label: 'Routing kind', input: 'select', choices: [...RAILS] },
      { key: 'maskedDestination', label: 'Masked destination', input: 'text', maxLength: 80 },
      { key: 'simulatedToken', label: 'Route token', input: 'text', maxLength: 200 },
      { key: 'effectiveDate', label: 'Effective date', input: 'date' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'beneficiary.retire', task: 'T040', module: 'payments', title: 'Retire beneficiary',
    summary: 'Retires a beneficiary, rejecting active dependents or cancelling drafts.',
    subjects: [{ key: 'beneficiaryId', label: 'Beneficiary', ref: 'beneficiary' }], resolved: [FINGERPRINT('beneficiary', 'beneficiaryId')],
    fields: [
      { key: 'dependentDisposition', label: 'Dependents', input: 'select', choices: ['reject-if-active', 'cancel-drafts'] },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
    ],
  },
  {
    kind: 'payment.create', task: 'T041', module: 'payments', title: 'Create payment instruction',
    summary: 'Creates a draft or approval-bound payment against a verified beneficiary route.',
    subjects: [{ key: 'sourceAccountId', label: 'Source account', ref: 'account' }],
    resolved: [
      { key: 'expectedSourceVersion', resolver: { of: 'version', subject: 'sourceAccountId' } },
      { key: 'expectedRouteFingerprint', resolver: { of: 'fingerprint', kind: 'beneficiary-route', subject: 'beneficiaryRouteId' } },
      { key: 'rail', resolver: { of: 'recordField', kind: 'beneficiary-route', subject: 'beneficiaryRouteId', field: 'routing_kind' } },
    ],
    fields: [
      { key: 'beneficiaryRouteId', label: 'Beneficiary route', input: 'select', provider: 'accountBeneficiaryRoutes' },
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'requestedDate', label: 'Requested date', input: 'date' },
      { key: 'calendarVersion', label: 'Calendar', input: 'text', defaultValue: 'US-FI-2026.1' },
      { key: 'cutoffAt', label: 'Cutoff at', input: 'instant' },
      { key: 'reference', label: 'Reference', input: 'text', maxLength: 60 },
      { key: 'targetState', label: 'Target state', input: 'select', choices: ['draft', 'pending-approval'] },
    ],
  },
  {
    kind: 'payment.submit', task: 'T042', module: 'payments', title: 'Submit payment',
    summary: 'Moves a draft payment to pending approval.',
    subjects: [{ key: 'paymentId', label: 'Payment', ref: 'payment' }],
    resolved: [{ key: 'expectedVersion', resolver: { of: 'recordField', kind: 'payment', subject: 'paymentId', field: 'version' } }],
    fields: [],
  },
  {
    kind: 'payment.approve_release', task: 'T042', module: 'payments', title: 'Approve and release payment',
    summary: 'Approves a pending payment for release on a checked date; needs approval.',
    subjects: [{ key: 'paymentId', label: 'Payment', ref: 'payment' }],
    resolved: [{ key: 'expectedVersion', resolver: { of: 'recordField', kind: 'payment', subject: 'paymentId', field: 'version' } }],
    approval: true,
    fields: [
      { key: 'requestedDate', label: 'Release date', input: 'date' },
      { key: 'calendarVersion', label: 'Calendar', input: 'text', defaultValue: 'US-FI-2026.1' },
      { key: 'cutoffAt', label: 'Cutoff at', input: 'instant' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'payment.settle', task: 'T042', module: 'payments', title: 'Settle payment',
    summary: 'Records the trusted settlement callback for a released payment.',
    subjects: [{ key: 'paymentId', label: 'Payment', ref: 'payment' }],
    resolved: [{ key: 'expectedVersion', resolver: { of: 'recordField', kind: 'payment', subject: 'paymentId', field: 'version' } }],
    fields: [{ key: 'settlementReference', label: 'Settlement reference', input: 'text' }],
  },
  {
    kind: 'payment.cancel', task: 'T045', module: 'payments', title: 'Cancel payment',
    summary: 'Cancels a draft or pending payment with a reason.',
    subjects: [{ key: 'paymentId', label: 'Payment', ref: 'payment' }],
    resolved: [{ key: 'expectedVersion', resolver: { of: 'recordField', kind: 'payment', subject: 'paymentId', field: 'version' } }],
    fields: [{ key: 'reason', label: 'Reason', input: 'text', maxLength: 500 }],
  },
  {
    kind: 'payment.schedule.create', task: 'T043', module: 'payments', title: 'Create payment schedule',
    summary: 'Creates a bounded recurring schedule against a verified route; needs approval.',
    subjects: [{ key: 'sourceAccountId', label: 'Source account', ref: 'account' }],
    resolved: [
      { key: 'expectedSourceVersion', resolver: { of: 'version', subject: 'sourceAccountId' } },
      { key: 'expectedRouteFingerprint', resolver: { of: 'fingerprint', kind: 'beneficiary-route', subject: 'beneficiaryRouteId' } },
    ],
    approval: true,
    fields: [
      { key: 'beneficiaryRouteId', label: 'Beneficiary route', input: 'select', provider: 'accountBeneficiaryRoutes' },
      { key: 'amount', label: 'Amount each', input: 'money' },
      { key: 'frequency', label: 'Frequency', input: 'select', choices: ['daily', 'weekly', 'monthly'] },
      { key: 'interval', label: 'Interval', input: 'integer' },
      { key: 'startDate', label: 'Start date', input: 'date' },
      { key: 'endDate', label: 'End date', input: 'date' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'payment.schedule.materialize', task: 'T043', module: 'payments', title: 'Materialize occurrence',
    summary: 'Turns a planned schedule occurrence into a draft payment.',
    subjects: [{ key: 'occurrenceId', label: 'Schedule occurrence', ref: 'schedule-occurrence' }],
    resolved: [FINGERPRINT('schedule-occurrence', 'occurrenceId')],
    fields: [],
  },
  {
    kind: 'payment.occurrence.amend', task: 'T044', module: 'payments', title: 'Amend occurrence',
    summary: 'Amends a planned occurrence\'s amount or local date.',
    subjects: [{ key: 'occurrenceId', label: 'Schedule occurrence', ref: 'schedule-occurrence' }],
    resolved: [FINGERPRINT('schedule-occurrence', 'occurrenceId')],
    fields: [
      { key: 'newAmount', label: 'New amount', input: 'money' },
      { key: 'newDate', label: 'New local date', input: 'date' },
    ],
  },
  {
    kind: 'payment.schedule.end', task: 'T097', module: 'payments', title: 'End payment schedule',
    summary: 'Ends a schedule from a date, cancelling or retaining planned items; needs approval.',
    subjects: [{ key: 'scheduleId', label: 'Payment schedule', ref: 'payment-schedule' }],
    resolved: [FINGERPRINT('payment-schedule', 'scheduleId')], approval: true,
    fields: [
      { key: 'endFromDate', label: 'End from', input: 'date' },
      { key: 'pendingDisposition', label: 'Pending items', input: 'select', choices: ['cancel-planned', 'retain-released'] },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'payment.return.resolve', task: 'T046', module: 'payments', title: 'Resolve payment return',
    summary: 'Resolves a returned payment by crediting the source or opening an investigation; needs approval.',
    subjects: [{ key: 'returnId', label: 'Payment return', ref: 'payment-return' }],
    resolved: [
      FINGERPRINT('payment-return', 'returnId'),
      { key: 'paymentId', resolver: { of: 'recordField', kind: 'payment-return', subject: 'returnId', field: 'payment_id' } },
    ],
    approval: true,
    fields: [
      { key: 'disposition', label: 'Disposition', input: 'select', choices: ['credit-source', 'investigate'] },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'card.replace', task: 'T047', module: 'cards', title: 'Replace card',
    summary: 'Orders a replacement card with evidence and delivery details.',
    subjects: [{ key: 'cardId', label: 'Card', ref: 'card' }], resolved: [FINGERPRINT('card', 'cardId')],
    fields: [
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      { key: 'identityEvidenceId', label: 'Identity evidence', input: 'select', provider: 'cardMemberEvidence' },
      { key: 'deliveryDestinationId', label: 'Delivery destination', input: 'select', provider: 'cardMemberDestinations' },
      { key: 'deliveryAddressId', label: 'Delivery address', input: 'select', provider: 'cardMemberAddresses' },
    ],
  },
  {
    kind: 'card.lock.update', task: 'T048', module: 'cards', title: 'Update card lock',
    summary: 'Locks or unlocks a card under a recorded authority.',
    subjects: [{ key: 'cardId', label: 'Card', ref: 'card' }], resolved: [FINGERPRINT('card', 'cardId')],
    fields: [
      { key: 'requestedState', label: 'Requested state', input: 'select', choices: ['locked', 'unlocked'] },
      { key: 'authority', label: 'Authority', input: 'text' },
    ],
  },
  {
    kind: 'card.limit.update', task: 'T049', module: 'cards', title: 'Update card limit',
    summary: 'Sets a spend limit kind and amount for the card; needs approval.',
    subjects: [{ key: 'cardId', label: 'Card', ref: 'card' }], resolved: [FINGERPRINT('card', 'cardId')], approval: true,
    fields: [
      { key: 'limitKind', label: 'Limit kind', input: 'select', choices: ['daily-purchase', 'cash', 'online'] },
      { key: 'amount', label: 'Limit amount', input: 'money' },
      { key: 'effectiveAt', label: 'Effective at', input: 'instant' },
      { key: 'expiresAt', label: 'Expires at', input: 'instant', nullable: true },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'dispute.open', task: 'T050', module: 'cards', title: 'Open card dispute',
    summary: 'Opens a card transaction dispute with asserted amount and evidence.',
    subjects: [{ key: 'cardTransactionId', label: 'Card transaction', ref: 'card-transaction' }],
    resolved: [FINGERPRINT('card-transaction', 'cardTransactionId')],
    fields: [
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      { key: 'assertedAmount', label: 'Asserted amount', input: 'money' },
      { key: 'evidenceIds', label: 'Evidence documents', input: 'multiselect', provider: 'cardMemberDocuments' },
    ],
  },
  {
    kind: 'dispute.provisional_credit.issue', task: 'T051', module: 'cards', title: 'Issue provisional credit',
    summary: 'Posts a provisional credit on the dispute; needs approval.',
    subjects: [{ key: 'disputeId', label: 'Dispute', ref: 'dispute' }], resolved: [FINGERPRINT('dispute', 'disputeId')], approval: true,
    fields: [
      { key: 'amount', label: 'Credit amount', input: 'money' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'dispute.evidence.submit', task: 'T052', module: 'cards', title: 'Submit dispute evidence',
    summary: 'Submits dispute evidence documents to a recipient; needs approval.',
    subjects: [{ key: 'disputeId', label: 'Dispute', ref: 'dispute' }], resolved: [FINGERPRINT('dispute', 'disputeId')], approval: true,
    fields: [
      { key: 'documentVersionIds', label: 'Evidence documents', input: 'multiselect', provider: 'disputeMemberDocuments' },
      { key: 'deadline', label: 'Deadline', input: 'instant' },
      { key: 'recipient', label: 'Recipient', input: 'text' },
      { key: 'channel', label: 'Channel', input: 'select', choices: ['email', 'mail'] },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'dispute.settle', task: 'T053', module: 'cards', title: 'Settle dispute',
    summary: 'Approves or denies the dispute with a final amount; needs approval.',
    subjects: [{ key: 'disputeId', label: 'Dispute', ref: 'dispute' }], resolved: [FINGERPRINT('dispute', 'disputeId')], approval: true,
    fields: [
      { key: 'decision', label: 'Decision', input: 'select', choices: ['approved', 'denied'] },
      { key: 'finalAmount', label: 'Final amount', input: 'money' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'loan.application.prepare', task: 'T054', module: 'loans', title: 'Prepare loan application',
    summary: 'Prepares a loan application for the member with evidence references.',
    subjects: [MEMBER], resolved: [MEMBER_VERSION_KEY('expectedMemberVersion', 'memberId')],
    fields: [
      { key: 'productId', label: 'Loan product', input: 'select', provider: 'loanProducts' },
      { key: 'requestedAmount', label: 'Requested amount', input: 'money' },
      { key: 'termMonths', label: 'Term (months)', input: 'integer' },
      { key: 'purpose', label: 'Purpose', input: 'text', maxLength: 200 },
      { key: 'evidenceIds', label: 'Evidence', input: 'multiselect', provider: 'memberEvidence' },
    ],
  },
  {
    kind: 'loan.payment.allocate', task: 'T055', module: 'loans', title: 'Allocate loan payment',
    summary: 'Allocates received funds to loan components under a policy.',
    subjects: [{ key: 'loanId', label: 'Loan', ref: 'loan' }], resolved: [FINGERPRINT('loan', 'loanId')],
    fields: [
      { key: 'receivedFundsReference', label: 'Received funds', input: 'ref', ref: 'received-funds', help: 'The received-funds reference to allocate.' },
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'allocationPolicy', label: 'Allocation policy', input: 'select', choices: ['fees-interest-principal', 'fees-interest-principal-hold-remainder'] },
    ],
  },
  {
    kind: 'loan.payoff.quote', task: 'T056', module: 'loans', title: 'Payoff quote',
    summary: 'Computes a durable payoff quote for the loan under the payoff policy.',
    subjects: [{ key: 'loanId', label: 'Loan', ref: 'loan' }], resolved: [FINGERPRINT('loan', 'loanId')],
    fields: [
      { key: 'payoffDate', label: 'Payoff date', input: 'date' },
      { key: 'policyVersionId', label: 'Payoff policy', input: 'select', provider: 'policyVersions' },
    ],
  },
  {
    kind: 'loan.close', task: 'T101', module: 'loans', title: 'Close loan',
    summary: 'Closes a fully satisfied loan with payoff evidence; needs approval.',
    subjects: [{ key: 'loanId', label: 'Loan', ref: 'loan' }], resolved: [FINGERPRINT('loan', 'loanId')], approval: true,
    fields: [
      { key: 'payoffEvidenceId', label: 'Payoff evidence', input: 'ref', ref: 'identity-evidence' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'document.loan_closure.issue', task: 'T102', module: 'loans', title: 'Issue closure document',
    summary: 'Issues the loan closure confirmation or lien-release document to the borrower; needs approval.',
    subjects: [{ key: 'loanId', label: 'Loan', ref: 'loan' }],
    resolved: [
      { key: 'expectedClosureFingerprint', resolver: { of: 'loanClosureFingerprint', subject: 'loanId' } },
      { key: 'recipientPartyId', resolver: { of: 'loanParty', subject: 'loanId' } },
    ],
    approval: true,
    fields: [
      { key: 'templateVersionId', label: 'Template document', input: 'ref', ref: 'document-version', help: 'An indexed closure template document version.' },
      { key: 'documentType', label: 'Document type', input: 'select', choices: ['loan-closure-confirmation', 'simulated-lien-release'] },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'reconciliation.suspense.investigate', task: 'T075', module: 'reconciliation', title: 'Investigate suspense item',
    summary: 'Attaches investigation evidence and a proposed account to a suspense item.',
    subjects: [{ key: 'suspenseId', label: 'Suspense item', ref: 'suspense-item' }],
    resolved: [FINGERPRINT('suspense-item', 'suspenseId')],
    fields: [
      { key: 'evidenceReferences', label: 'Evidence references', input: 'lines' },
      { key: 'proposedAccountId', label: 'Proposed account', input: 'ref', ref: 'account', nullable: true },
    ],
  },
  {
    kind: 'reconciliation.suspense.clear', task: 'T076', module: 'reconciliation', title: 'Clear suspense item',
    summary: 'Posts an exact amount from the suspense item to a destination account; needs approval.',
    subjects: [{ key: 'suspenseId', label: 'Suspense item', ref: 'suspense-item' }],
    resolved: [FINGERPRINT('suspense-item', 'suspenseId')], approval: true,
    fields: [
      { key: 'destinationAccountId', label: 'Destination account', input: 'ref', ref: 'account' },
      { key: 'amount', label: 'Amount', input: 'money' },
      { key: 'evidenceReference', label: 'Evidence reference', input: 'text' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'batch.import', task: 'T077', module: 'reconciliation', title: 'Import batch',
    summary: 'Imports an indexed CSV document as an immutable contact-update or fee-refund batch.',
    subjects: [{ key: 'documentVersionId', label: 'Batch document', ref: 'document-version' }],
    resolved: [{ key: 'inputDigest', resolver: { of: 'docDigest', subject: 'documentVersionId' } }],
    fields: [
      { key: 'batchNumber', label: 'Batch number', input: 'text' },
      { key: 'batchKind', label: 'Batch kind', input: 'select', choices: ['contact-update', 'fee-refund'] },
      { key: 'currency', label: 'Currency', input: 'select', provider: 'currencies', nullable: true, help: 'Required for fee-refund batches only.' },
    ],
  },
  {
    kind: 'batch.contacts.apply', task: 'T078', module: 'reconciliation', title: 'Apply contact batch item',
    summary: 'Applies one item of a contact-update batch; needs approval covering the batch scope.',
    subjects: [{ key: 'batchId', label: 'Batch', ref: 'batch' }], resolved: [FINGERPRINT('batch', 'batchId')], approval: true,
    fields: [
      { key: 'itemId', label: 'Batch item', input: 'select', provider: 'batchItems' },
      { key: 'conflictPolicy', label: 'On conflict', input: 'select', choices: ['skip-stale', 'reject-all'] },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'batch.fee_refunds.apply', task: 'T079', module: 'reconciliation', title: 'Apply fee-refund batch item',
    summary: 'Applies one item of a fee-refund batch under its approved total; needs approval.',
    subjects: [{ key: 'batchId', label: 'Batch', ref: 'batch' }], resolved: [FINGERPRINT('batch', 'batchId')], approval: true,
    fields: [
      { key: 'itemId', label: 'Batch item', input: 'select', provider: 'batchItems' },
      APPROVAL_FIELD,
    ],
  },
  {
    kind: 'account.maturity.instruct', task: 'T098', module: 'accounts', title: 'Maturity instruction',
    summary: 'Records the maturity disposition for a deposit account; needs approval.',
    subjects: [ACCOUNT],
    resolved: [
      VERSION('accountId'),
      { key: 'expectedInstructionFingerprint', resolver: { of: 'maturityInstructionFingerprint', subject: 'accountId' } },
    ],
    approval: true,
    fields: [
      { key: 'disposition', label: 'Disposition', input: 'select', choices: ['renew', 'transfer', 'hold'] },
      { key: 'destinationAccountId', label: 'Destination account', input: 'select', provider: 'accountMemberAccounts', nullable: true },
      { key: 'termMonths', label: 'Renewal term (months)', input: 'integer', nullable: true },
      { key: 'approvedAnnualRateBps', label: 'Approved rate (bps)', input: 'integer', nullable: true },
      APPROVAL_FIELD,
    ],
  },
];

function CASE_SUBJECT(): { key: string; label: string; ref: 'case' } {
  return { key: 'caseId', label: 'Authorizing case', ref: 'case' };
}
