import type { Rejection, SqlDatabase } from '@computer-use/financial-database/services';
import { referenceData } from '@computer-use/financial-database/services';
import type { RequestContext } from './context.js';
import { resolveRef } from './resolve.js';
import type { FieldSpec, OperationSpec } from './spec.js';

export interface FormIssue { field: string; message: string }
export type BuildResult = { ok: true; command: Record<string, unknown> } | { ok: false; issues: FormIssue[] };

type Posted = Record<string, unknown>;
const isRecord = (value: unknown): value is Record<string, unknown> => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = (value: unknown): string => (typeof value === 'string' ? value.trim() : '');

/** Field names in the posted body: f[key], f[key][sub], n[key] marks JSON null, s[key] marks "set". */
export function buildCommand(rc: RequestContext, db: SqlDatabase, spec: OperationSpec, subjects: Record<string, string>, resolved: Record<string, unknown>, body: Posted): BuildResult {
  const issues: FormIssue[] = [];
  const command: Record<string, unknown> = { kind: spec.kind };
  for (const subject of spec.subjects) {
    if (subjects[subject.key] !== undefined && subject.intoCommand !== false) command[subject.key] = subjects[subject.key];
  }
  const fields = (body.f ?? {}) as Posted;
  const nulls = (body.n ?? {}) as Posted;
  const sets = (body.s ?? {}) as Posted;

  const target = spec.patchKey === undefined ? command : (command[spec.patchKey] = {} as Record<string, unknown>);
  for (const field of spec.fields) {
    const parsed = parseField(rc, db, field, fields, nulls[field.key] !== undefined, sets[field.key] !== undefined, subjects, issues);
    if (field.optional && sets[field.key] === undefined) continue;
    if (parsed !== undefined || field.nullable) target[field.key] = parsed ?? null;
  }
  for (const [key, value] of Object.entries(resolved)) command[key] = value;
  if (spec.constants !== undefined) Object.assign(command, spec.constants);
  if (spec.approval === true && command.approvalId === undefined) command.approvalId = '';
  return issues.length === 0 ? { ok: true, command } : { ok: false, issues };
}

function parseField(
  rc: RequestContext,
  db: SqlDatabase,
  field: FieldSpec,
  fields: Posted,
  isNull: boolean,
  isSet: boolean,
  subjects: Record<string, string>,
  issues: FormIssue[],
): unknown {
  const raw = fields[field.key];
  const label = field.label;
  const missing = () => { if (!field.optional && !field.nullable) issues.push({ field: field.key, message: `${label} is required.` }); return undefined; };

  if (field.nullable && isNull) return null;
  if (field.optional && !isSet) return undefined;

  switch (field.input) {
    case 'text': case 'textarea': case 'date': case 'instant': {
      const value = text(raw);
      if (value === '') return field.nullable ? null : missing();
      return value;
    }
    case 'integer': {
      const value = text(raw);
      if (value === '') return field.nullable ? null : missing();
      const parsed = Number(value);
      if (!Number.isSafeInteger(parsed)) { issues.push({ field: field.key, message: `${label} must be a whole number.` }); return undefined; }
      return parsed;
    }
    case 'boolean':
      return raw !== undefined && raw !== 'off' && raw !== '';
    case 'money': case 'signedMoney': {
      const record = isRecord(raw) ? raw : {};
      const amount = text(record.amount);
      const currency = text(record.currency);
      if (amount === '' || currency === '') { if (field.nullable) return null; return missing(); }
      const minor = moneyToMinor(rc, db, amount, currency, field.input === 'signedMoney');
      if (minor === undefined) { issues.push({ field: field.key, message: `${label} must be a numeric amount in a known currency.` }); return undefined; }
      return { minorUnits: minor, currency };
    }
    case 'select': {
      const value = text(raw);
      if (value === '') return field.nullable ? null : missing();
      return value;
    }
    case 'multiselect': {
      const values = Array.isArray(raw) ? raw.map((item) => String(item).trim()).filter((item) => item !== '') : [];
      if (values.length === 0) return missing();
      return values;
    }
    case 'lines': {
      const values = text(raw).split(/\r?\n/).map((line) => line.trim()).filter((line) => line !== '');
      if (values.length === 0) return field.optional && isSet ? [] : field.optional || field.nullable ? (field.nullable ? null : undefined) : [];
      return values;
    }
    case 'address': {
      const record = isRecord(raw) ? raw : {};
      const address = {
        line1: text(record.line1), line2: text(record.line2) === '' ? null : text(record.line2), city: text(record.city),
        region: text(record.region), postalCode: text(record.postalCode), country: text(record.country),
      };
      if (address.line1 === '' || address.city === '' || address.region === '' || address.postalCode === '' || address.country === '') {
        return field.nullable || field.optional ? (field.optional && !isSet ? undefined : field.nullable ? null : missing()) : missing();
      }
      return address;
    }
    case 'ref': {
      const value = text(raw);
      if (value === '') return field.nullable ? null : missing();
      const resolved = resolveRef(rc, db, field.ref ?? 'member', value);
      if ('error' in resolved) { issues.push({ field: field.key, message: `${label}: ${resolved.error}` }); return undefined; }
      return field.as === 'partyId' ? partyOfMember(rc, db, resolved.id, field.key, issues) : resolved.id;
    }
    case 'bytes': {
      const value = text(raw);
      if (value === '') return missing();
      return new TextEncoder().encode(value);
    }
    case 'region': {
      const record = isRecord(raw) ? raw : {};
      const region = { x: Number(text(record.x)), y: Number(text(record.y)), width: Number(text(record.width)), height: Number(text(record.height)) };
      if (!Object.values(region).every((part) => Number.isSafeInteger(part) && part >= 0)) {
        issues.push({ field: field.key, message: `${label} needs whole non-negative x, y, width and height.` }); return undefined;
      }
      return region;
    }
    case 'owners': {
      const rows = isRecord(raw) ? Object.values(raw) : Array.isArray(raw) ? raw : [];
      const owners = [];
      for (const row of rows) {
        if (!isRecord(row)) continue;
        const member = text(row.memberId);
        if (member === '') continue;
        const resolved = resolveRef(rc, db, 'member', member);
        if ('error' in resolved) { issues.push({ field: field.key, message: `${label}: ${resolved.error}` }); continue; }
        owners.push({
          memberId: resolved.id,
          ownershipBps: Number(text(row.ownershipBps)),
          isControlPerson: row.isControlPerson !== undefined,
          evidenceId: text(row.evidenceId),
        });
      }
      if (owners.length === 0) return missing();
      return owners;
    }
    case 'excerpts': {
      const rows = isRecord(raw) ? Object.values(raw) : Array.isArray(raw) ? raw : [];
      const excerpts = [];
      for (const row of rows) {
        if (!isRecord(row)) continue;
        const sourceVersionId = text(row.sourceVersionId);
        const excerptText = text(row.text);
        if (sourceVersionId === '' && excerptText === '') continue;
        excerpts.push({ sourceVersionId, text: excerptText });
      }
      if (excerpts.length === 0) return missing();
      return excerpts;
    }
    case 'partylist': {
      const record = isRecord(raw) ? raw : {};
      const selected = Array.isArray(record.selected) ? record.selected.map(String) : [];
      const extra = text(record.extra).split(/\r?\n/).map((line) => line.trim()).filter((line) => line !== '');
      const parties = [...selected];
      for (const entry of extra) {
        const member = resolveRef(rc, db, 'member', entry);
        if ('error' in member) { issues.push({ field: field.key, message: `${label}: ${member.error}` }); continue; }
        const party = partyOfMember(rc, db, member.id, field.key, issues);
        if (party !== undefined) parties.push(party);
      }
      if (parties.length === 0) return missing();
      return [...new Set(parties)];
    }
    case 'subcommand': {
      const record = isRecord(raw) ? raw : {};
      return parseSubcommand(rc, db, record, subjects, field.key, issues);
    }
    case 'savedSearchDef': {
      const record = isRecord(raw) ? raw : {};
      const entity = text(record.entity);
      const filters = isRecord(record.filters) ? record.filters : {};
      const parsedFilters: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(filters)) {
        const v = text(value);
        if (v !== '') parsedFilters[key] = v === 'true' ? true : v;
      }
      const sortField = text(record.sortField);
      const sort = sortField === '' ? [] : [{ field: sortField, direction: text(record.sortDirection) === 'desc' ? 'desc' as const : 'asc' as const }];
      const columns = Array.isArray(record.columns) ? record.columns.map(String).filter((c) => c !== '') : [];
      if (entity === '' || columns.length === 0) { issues.push({ field: field.key, message: `${label} needs an entity and at least one column.` }); return undefined; }
      return { entity, filters: parsedFilters, sort, columns };
    }
    default:
      return missing();
  }
}

const SUBCOMMANDS: Record<string, { fields: readonly string[]; memberVersion: boolean }> = {
  'contact.update': { fields: ['email', 'phone', 'address'], memberVersion: false },
  'member.note.add': { fields: ['visibility', 'text'], memberVersion: false },
  'account.nickname.update': { fields: ['nickname'], memberVersion: false },
  'account.statement_delivery.update': { fields: ['statementDelivery'], memberVersion: false },
  'account.close': { fields: ['reason'], memberVersion: false },
};

function parseSubcommand(rc: RequestContext, db: SqlDatabase, record: Record<string, unknown>, subjects: Record<string, string>, key: string, issues: FormIssue[]): Record<string, unknown> | undefined {
  const kind = text(record.kind);
  const spec = SUBCOMMANDS[kind];
  if (spec === undefined) { issues.push({ field: key, message: 'Choose a requested change kind.' }); return undefined; }
  const memberId = subjects.memberId;
  if (memberId === undefined) { issues.push({ field: key, message: 'The requested change needs the draft member.' }); return undefined; }
  const command: Record<string, unknown> = { kind, memberId };
  if (kind !== 'member.note.add') {
    const member = db.prepare("SELECT version FROM members WHERE dataset_id=? AND id=?").get(rc.binding.datasetId, memberId) as { version: number } | undefined;
    if (member === undefined) { issues.push({ field: key, message: 'The draft member was not found.' }); return undefined; }
    if (kind === 'contact.update') command.expectedVersion = member.version;
  }
  if (kind !== 'contact.update' && kind !== 'member.note.add') {
    const accountId = subjects.accountId ?? text(record.accountId);
    const resolved = accountId === '' ? undefined : accountId;
    const accountRef = resolved === undefined ? resolveRef(rc, db, 'account', text(record.accountNumber)) : { id: resolved };
    if ('error' in accountRef) { issues.push({ field: key, message: 'The requested change needs a valid account.' }); return undefined; }
    command.accountId = accountRef.id;
    const account = db.prepare('SELECT version FROM accounts WHERE dataset_id=? AND id=?').get(rc.binding.datasetId, accountRef.id) as { version: number } | undefined;
    if (account === undefined) { issues.push({ field: key, message: 'The account was not found.' }); return undefined; }
    command.expectedVersion = account.version;
  }
  for (const name of spec.fields) {
    if (name === 'address') {
      const address = isRecord(record.address) ? record.address : {};
      const filled = ['line1', 'city', 'region', 'postalCode', 'country'].some((part) => text(address[part]) !== '');
      if (!filled && text(address.line2) === '') continue;
      command.address = {
        line1: text(address.line1), line2: text(address.line2) === '' ? null : text(address.line2), city: text(address.city),
        region: text(address.region), postalCode: text(address.postalCode), country: text(address.country),
      };
      continue;
    }
    if (name === 'email' || name === 'phone') {
      const value = text(record[name]);
      if (value !== '') command[name] = value;
      continue;
    }
    const value = text(record[name]);
    if (value === '') { issues.push({ field: key, message: `The requested change needs ${name}.` }); return undefined; }
    command[name] = value;
  }
  return command;
}

function partyOfMember(rc: RequestContext, db: SqlDatabase, memberId: string, key: string, issues: FormIssue[]): string | undefined {
  const row = db.prepare('SELECT party_id FROM members WHERE dataset_id=? AND id=?').get(rc.binding.datasetId, memberId) as { party_id: string } | undefined;
  if (row === undefined) { issues.push({ field: key, message: `Member ${memberId} was not found.` }); return undefined; }
  return row.party_id;
}

function moneyToMinor(rc: RequestContext, db: SqlDatabase, amount: string, currency: string, signed: boolean): number | undefined {
  const currencies = referenceData(db, rc.binding.datasetId, rc.binding.institutionId).currencies;
  const entry = currencies.find((c) => c.code === currency);
  if (entry === undefined) return undefined;
  const match = /^(-?)(\d+)(?:\.(\d+))?$/.exec(amount.trim());
  if (match === null) return undefined;
  const [, sign, whole, fraction = ''] = match;
  if (sign === '-' && !signed) return undefined;
  if (fraction.length > entry.exponent) return undefined;
  const minor = Number(whole) * 10 ** entry.exponent + Number(fraction.padEnd(entry.exponent, '0') || '0');
  if (!Number.isSafeInteger(minor)) return undefined;
  return sign === '-' ? -minor : minor;
}

export type { Rejection };
