import { randomUUID } from 'node:crypto';

import type { CommandOutcome, ReviewOutcome, SqlDatabase } from '@computer-use/financial-database/services';
import type { FormIssue } from './command.js';
import type { RequestContext } from './context.js';
import type { SafeHtml } from './html.js';
import { html, joinHtml } from './html.js';
import { definitionList, displayValue, fieldControl, issueSummary, moneyCell } from './render.js';
import { describeRef, optionsFor } from './resolve.js';
import type { OperationSpec } from './spec.js';

export interface FlowDraft {
  key: string;
  kind: string;
  sessionId: string;
  createdAt: number;
  subjects: Record<string, string>;
  resolved: Record<string, unknown>;
  posted: Record<string, unknown>;
  flags: { n: Record<string, unknown>; s: Record<string, unknown> };
  review?: { command: Record<string, unknown>; fingerprint: string; outcome: ReviewOutcome };
  committed?: CommandOutcome;
  issues: FormIssue[];
}

const DRAFT_TTL_MS = 30 * 60 * 1000;
const DRAFT_LIMIT = 400;

export class DraftStore {
  private readonly drafts = new Map<string, FlowDraft>();

  get(key: string, sessionId: string): FlowDraft | undefined {
    this.purge();
    const draft = this.drafts.get(key);
    if (draft === undefined || draft.sessionId !== sessionId) return undefined;
    return draft;
  }

  create(sessionId: string, kind: string): FlowDraft {
    this.purge();
    if (this.drafts.size >= DRAFT_LIMIT) {
      const oldest = [...this.drafts.values()].sort((a, b) => a.createdAt - b.createdAt)[0];
      if (oldest !== undefined) this.drafts.delete(oldest.key);
    }
    const draft: FlowDraft = {
      key: randomUUID().replaceAll('-', '').slice(0, 20), kind, sessionId, createdAt: Date.now(),
      subjects: {}, resolved: {}, posted: {}, flags: { n: {}, s: {} }, issues: [],
    };
    this.drafts.set(draft.key, draft);
    return draft;
  }

  drop(key: string, sessionId: string): void {
    const draft = this.drafts.get(key);
    if (draft !== undefined && draft.sessionId === sessionId) this.drafts.delete(key);
  }

  private purge(): void {
    const cutoff = Date.now() - DRAFT_TTL_MS;
    for (const [key, draft] of this.drafts) if (draft.createdAt < cutoff) this.drafts.delete(key);
  }
}

export function subjectPage(spec: OperationSpec, issues: FormIssue[], posted: Record<string, string>): SafeHtml {
  const rows = spec.subjects.map((subject) => html`<tr><th><label for="s-${subject.key}">${subject.label}</label>${subject.optional === true ? html` <span class="hint">(optional)</span>` : ''}</th>
    <td><input type="text" id="s-${subject.key}" name="subject[${subject.key}]" value="${posted[subject.key] ?? ''}" class="mono" placeholder="id or business number" autofocus>
    ${subject.help === undefined ? '' : html`<div class="hint">${subject.help}</div>`}</td></tr>`);
  return html`<p class="summary">${spec.summary}</p>
  ${issueSummary(issues)}
  <form method="post" action="/op/${spec.kind}/select"><table class="form">${rows}</table>
  <p class="actions"><button type="submit" name="step" value="select">Continue to details</button> <a href="/${spec.module}">Cancel</a></p></form>`;
}

export function formPage(rc: RequestContext, db: SqlDatabase, spec: OperationSpec, draft: FlowDraft): SafeHtml {
  const resolvedRows = Object.entries(draft.resolved).map(([key, value]) => html`<tr><th class="mono small">${key}</th><td class="mono small">${displayValue(rc, db, value)}</td></tr>`);
  const subjectRows = Object.entries(draft.subjects).map(([key, id]) => {
    const subjectSpec = spec.subjects.find((subject) => subject.key === key);
    return [subjectSpec?.label ?? key, html`<span class="mono">${describeRef(rc, db, subjectSpec?.ref ?? 'member', id)}</span>`] as const;
  });
  const errorFields = new Set(draft.issues.map((issue) => issue.field));
  return html`<p class="summary">${spec.summary}</p>
  ${issueSummary(draft.issues)}
  ${definitionList(subjectRows)}
  <form method="post" action="/op/${spec.kind}/review?flow=${draft.key}"><table class="form">
  ${spec.fields.map((field) => fieldControl(rc, db, spec, field, draft.subjects, draft.posted, errorFields, draft.flags))}
  ${resolvedRows.length === 0 ? '' : html`<tr><th colspan="2" class="resolved-hdr">Resolved at form load (stale-checked on commit)</th></tr>${resolvedRows}`}
  </table>
  <p class="actions"><button type="submit" name="step" value="review">Review change</button>
  <button type="submit" name="step" value="cancel" formnovalidate>Cancel</button></p></form>`;
}

export function reviewPage(rc: RequestContext, db: SqlDatabase, spec: OperationSpec, draft: FlowDraft): SafeHtml {
  const review = draft.review;
  if (review === undefined) return html`<p class="notice">Nothing reviewed yet. <a href="/op/${spec.kind}/form?flow=${draft.key}">Return to the form.</a></p>`;
  if (review.outcome.kind !== 'reviewable') {
    const reason = review.outcome.kind === 'unchanged'
      ? html`<p class="notice">The service reports this change is already in effect: ${review.outcome.message}</p>`
      : html`<div class="errors"><b>The service declined this operation:</b><ul><li><b>${review.outcome.code}</b> — ${review.outcome.message}</li></ul></div>`;
    const awaiting = spec.approval === true && review.outcome.kind === 'rejected'
      && (review.command.approvalId === undefined || review.command.approvalId === '');
    return html`${reason}${awaiting ? approvalPanel(rc, db, spec, draft) : ''}<p><a href="/op/${spec.kind}/form?flow=${draft.key}">Back to the form</a> · <a href="/${spec.module}">Abandon</a></p>`;
  }
  const command = review.command;
  const rows = Object.entries(command).map(([key, value]) => [key, displayValue(rc, db, value)] as const);
  const detail = review.outcome.review;
  return html`
  <h2>Reviewed terms</h2>
  ${definitionList([
    ['Operation', spec.title],
    ['Institution', detail.institutionName],
    ['Amount', detail.amount === null ? '—' : moneyCell(rc, db, detail.amount.minorUnits, detail.amount.currency)],
    ['Accounts affected', detail.accounts.length === 0 ? '—' : joinHtml(detail.accounts.map((account) => html`<div class="mono">${account.accountNumber} · ${account.ownerName} · ${account.memberNumber}</div>`), '')],
  ])}
  <h2>Command values</h2>
  ${definitionList(rows)}
  ${detail.consequences.length === 0 ? '' : html`<h2>Consequences</h2><ul>${detail.consequences.map((item) => html`<li>${item}</li>`)}</ul>`}
  ${spec.approval === true && (command.approvalId === undefined || command.approvalId === '') ? approvalPanel(rc, db, spec, draft) : ''}
  <form method="post" action="/op/${spec.kind}/commit?flow=${draft.key}">
  <p class="actions"><button type="submit" name="step" value="commit">Commit</button>
  <button type="submit" formaction="/op/${spec.kind}/form?flow=${draft.key}" name="step" value="back" formnovalidate>Back to form</button>
  <button type="submit" formaction="/op/${spec.kind}/abandon?flow=${draft.key}" name="step" value="cancel" formnovalidate>Cancel</button></p></form>`;
}

function approvalPanel(rc: RequestContext, db: SqlDatabase, spec: OperationSpec, draft: FlowDraft): SafeHtml {
  const checkers = optionsFor(rc, db, 'approvalCheckers', draft.subjects, spec.kind);
  const policies = optionsFor(rc, db, 'policyVersions', draft.subjects);
  const currencies = optionsFor(rc, db, 'currencies', {});
  return html`<h2>Independent approval required</h2>
  <p>This operation needs a different operator's approval before it can commit. Request it here, then choose the approved request in the Approval field after the checker decides on the <a href="/approvals">Approvals</a> page.</p>
  <form method="post" action="/op/${spec.kind}/request-approval?flow=${draft.key}"><table class="form">
  <tr><th>Checker</th><td><select name="a[checkerActorId]">${checkers.map((option) => html`<option value="${option.value}">${option.label}</option>`)}</select></td></tr>
  <tr><th>Policy</th><td><select name="a[policyVersionId]">${policies.map((option) => html`<option value="${option.value}">${option.label}</option>`)}</select></td></tr>
  <tr><th>Expires at</th><td><input type="text" name="a[expiresAt]" class="mono" value="${defaultExpiry()}" size="24"></td></tr>
  <tr><th>Amount limit</th><td><input type="text" name="a[amount]" size="14" class="mono" placeholder="blank = unlimited"> <select name="a[currency]">${currencies.map((option) => html`<option value="${option.value}">${option.value}</option>`)}</select></td></tr>
  </table><p class="actions"><button type="submit" name="step" value="request">Request approval</button></p></form>`;
}

function defaultExpiry(): string {
  return new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().replace(/\.\d{3}Z$/, 'Z');
}

export function resultPage(spec: OperationSpec, draft: FlowDraft): SafeHtml {
  const committed = draft.committed;
  if (committed === undefined) return html`<p class="notice">No result recorded. <a href="/op/${spec.kind}/form?flow=${draft.key}">Return to the form.</a></p>`;
  if (committed.kind === 'committed' || committed.kind === 'duplicate') {
    const receipt = committed.receipt;
    return html`<div class="committed"><h2>${committed.kind === 'duplicate' ? 'Already committed' : 'Committed'}</h2>
    ${committed.kind === 'duplicate' ? html`<p class="notice">This operation was already committed; the original durable receipt is shown.</p>` : ''}
    ${definitionList([
      ['Receipt', html`<a class="mono" href="/receipt/${receipt.receiptNumber}">${receipt.receiptNumber}</a>`],
      ['Operation id', receipt.operationId],
      ['Committed at', receipt.committedAt],
      ['Reference', receipt.businessReference],
    ])}
    <p><a href="/op/${spec.kind}">Start another ${spec.title}</a> · <a href="/${spec.module}">${spec.module} module</a> · <a href="/">Home</a></p></div>`;
  }
  if (committed.kind === 'unchanged') {
    return html`<div class="committed"><h2>Already applied</h2><p>${committed.message}</p>
    <p><a href="/op/${spec.kind}">Start another</a> · <a href="/${spec.module}">Module</a></p></div>`;
  }
  return html`<div class="errors"><h2>Rejected by the service</h2>
  ${definitionList([['Code', committed.code], ['Reason', committed.message], ...(committed.field === undefined ? [] : [['Field', committed.field] as const])])}
  <p><a href="/op/${spec.kind}/form?flow=${draft.key}">Return to the form with your entries</a> · <a href="/${spec.module}">Abandon</a></p></div>`;
}
