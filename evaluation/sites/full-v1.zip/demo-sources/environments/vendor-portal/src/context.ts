import { createHash, randomUUID } from 'node:crypto';

import type { DatasetBinding } from '@computer-use/financial-database';
import type { FinancialStore, ServiceContext } from '@computer-use/financial-database/services';
import { operatorProfile } from '@computer-use/financial-database/services';

export interface PortalSession {
  id: string;
  actorNumber: string | null;
  createdAt: number;
}

export interface SessionStore {
  create(actorNumber: string): PortalSession;
  get(id: string): PortalSession | undefined;
  setActor(id: string, actorNumber: string | null): void;
  delete(id: string): void;
  count(): number;
  purge(): void;
}

const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const SESSION_LIMIT = 500;

export function createSessionStore(): SessionStore {
  const sessions = new Map<string, PortalSession>();
  const store: SessionStore = {
    create(actorNumber) {
      store.purge();
      if (sessions.size >= SESSION_LIMIT) {
        const oldest = [...sessions.values()].sort((a, b) => a.createdAt - b.createdAt)[0];
        if (oldest !== undefined) sessions.delete(oldest.id);
      }
      const session: PortalSession = { id: randomUUID(), actorNumber, createdAt: Date.now() };
      sessions.set(session.id, session);
      return session;
    },
    get(id) {
      const session = sessions.get(id);
      if (session !== undefined && Date.now() - session.createdAt > SESSION_TTL_MS) {
        sessions.delete(id);
        return undefined;
      }
      return session;
    },
    setActor(id, actorNumber) {
      const session = sessions.get(id);
      if (session !== undefined) session.actorNumber = actorNumber;
    },
    delete(id) {
      sessions.delete(id);
    },
    count() {
      return sessions.size;
    },
    purge() {
      const cutoff = Date.now() - SESSION_TTL_MS;
      for (const [id, session] of sessions) if (session.createdAt < cutoff) sessions.delete(id);
    },
  };
  return store;
}

/** Signed-on operator bound to one dataset. `read`/`write` scope every access to one snapshot/transaction. */
export interface RequestContext {
  store: FinancialStore;
  binding: DatasetBinding;
  actorNumber: string;
  actorId: string;
  context: ServiceContext;
  permissions: ReadonlySet<string>;
  displayName: string;
  sessionId: string;
}

/** Resolves an operator actor number to the actor and grants inside the bound dataset. */
export function resolveOperator(store: FinancialStore, binding: DatasetBinding, actorNumber: string, sessionId: string): RequestContext | undefined {
  const profile = store.read((db) => operatorProfile(db, binding.datasetId, binding.institutionId, actorNumber));
  if (profile === undefined) return undefined;
  const context: ServiceContext = { binding, actorId: profile.actor.id, principalKind: 'human', reference: `vendor-portal:${actorNumber}` };
  return {
    store,
    binding,
    actorNumber,
    actorId: profile.actor.id,
    context,
    permissions: new Set(profile.permissions),
    displayName: profile.actor.displayName,
    sessionId,
  };
}

/** Short-lived flow keys bound to session + operator + operation so replayed posts are detectable. */
export function flowKey(sessionId: string, actorId: string, kind: string): string {
  return createHash('sha256').update(`${sessionId}:${actorId}:${kind}:${randomUUID()}`).digest('hex').slice(0, 24);
}
