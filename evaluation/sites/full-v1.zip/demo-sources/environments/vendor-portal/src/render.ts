import { referenceData } from '@computer-use/financial-database/services';
import type { FormIssue } from './command.js';
import type { RequestContext } from './context.js';
import type { SqlDatabase } from '@computer-use/financial-database/services';
import { formatMoney } from './format.js';
import { escapeAttribute, html, joinHtml, raw, type HtmlValue, type SafeHtml } from './html.js';
import { MODULE_LABELS, operationsByModule } from './registry.js';
import { optionsFor } from './resolve.js';
import type { Choice, FieldSpec, ModuleKey, OperationSpec } from './spec.js';

export interface DeploymentBranding {
  productName: string;
  institutionName: string;
  tagline: string;
  accent: string;
}

export interface PageModel {
  title: string;
  module?: ModuleKey;
  crumbs?: readonly { label: string; href?: string }[];
  operator?: { displayName: string; actorNumber: string } | undefined;
  notices?: readonly string[];
  body: HtmlValue | { error: string };
}

const NAV_ORDER: readonly ModuleKey[] = [
  'members', 'accounts', 'money', 'payments', 'cards', 'loans', 'documents', 'servicing',
  'cases', 'maintenance', 'reconciliation', 'approvals', 'searches', 'system',
];

/** Full classic page chrome: fixed-width, left module rail, dense body, conventional links. */
export function page(branding: DeploymentBranding, model: PageModel): SafeHtml {
  const crumbs = model.crumbs ?? [];
  const nav = NAV_ORDER.map((module) => html`<li class="${model.module === module ? 'on' : ''}"><a href="/${module}">${MODULE_LABELS[module]}</a></li>`);
  return html`<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><title>${model.title} — ${branding.productName}</title>
<link rel="stylesheet" href="/static/classic.css"></head>
<body><div class="wrap">
<header class="masthead">
  <div class="brand"><span class="bank">${branding.institutionName}</span><span class="product">${branding.productName}</span></div>
  <div class="operator">${model.operator === undefined ? '' : html`Signed on as <b>${model.operator.displayName}</b> (${model.operator.actorNumber}) · <a href="/signout">Sign out</a> · `}<a href="/admin">Administration</a></div>
  <div class="tagline">${branding.tagline}</div>
</header>
<div class="columns"><nav class="rail"><ul>${nav}</ul></nav>
<main class="content">
${crumbs.length === 0 ? '' : html`<p class="crumbs">${joinHtml(crumbs.map((crumb) => crumb.href === undefined ? html`<span>${crumb.label}</span>` : html`<a href="${crumb.href}">${crumb.label}</a>`), html` <span class="sep">›</span> `)}</p>`}
<h1>${model.title}</h1>
${(model.notices ?? []).map((notice) => html`<p class="notice">${notice}</p>`)}
${model.body as HtmlValue}
</main></div>
<footer class="foot">${branding.institutionName} · ${branding.productName} · Records are authoritative in the shared financial service.</footer>
</div></body></html>`;
}

export function issueSummary(issues: readonly FormIssue[]): SafeHtml | '' {
  if (issues.length === 0) return '';
  return html`<div class="errors"><b>This form needs attention:</b><ul>${issues.map((issue) => html`<li><a href="#f-${escapeAttribute(issue.field)}">${issue.message}</a></li>`)}</ul></div>`;
}

export function table(headers: readonly string[], rows: readonly (readonly HtmlValue[])[], cls = ''): SafeHtml {
  return html`<table class="grid ${cls}"><thead><tr>${headers.map((header) => html`<th>${header}</th>`)}</tr></thead><tbody>
${rows.length === 0 ? html`<tr><td colspan="${headers.length}" class="empty">No records.</td></tr>` : rows.map((row) => html`<tr>${row.map((cell) => html`<td>${cell}</td>`)}</tr>`)}
</tbody></table>`;
}

export function definitionList(entries: readonly (readonly [string, HtmlValue])[]): SafeHtml {
  return html`<table class="deflist"><tbody>${entries.map(([key, value]) => html`<tr><th>${key}</th><td>${value}</td></tr>`)}</tbody></table>`;
}

export function link(href: string, label: string): SafeHtml {
  return html`<a href="${escapeAttribute(href)}">${label}</a>`;
}

export function moneyCell(rc: RequestContext, db: SqlDatabase, minorUnits: number, currency: string): string {
  const entry = referenceData(db, rc.binding.datasetId, rc.binding.institutionId).currencies.find((c) => c.code === currency);
  return formatMoney(minorUnits, currency, entry?.exponent ?? 2);
}

const txt = (value: unknown): string => typeof value === 'string' ? value : typeof value === 'number' ? String(value) : '';

/** Renders one operation field inside the details form. */
export function fieldControl(rc: RequestContext, db: SqlDatabase, spec: OperationSpec, field: FieldSpec, subjectValues: Record<string, string>, draft: Record<string, unknown>, errors: Set<string>, flags: { n: Record<string, unknown>; s: Record<string, unknown> }): SafeHtml {
  const name = `f[${field.key}]`;
  const err = errors.has(field.key) ? ' err' : '';
  const marks = html`${field.nullable === true ? html`<label class="flag"><input type="checkbox" name="n[${field.key}]"${flags.n[field.key] !== undefined ? ' checked' : ''}> none</label>` : ''}${field.optional === true ? html`<label class="flag"><input type="checkbox" name="s[${field.key}]"${flags.s[field.key] !== undefined ? ' checked' : ''}> set</label>` : ''}`;
  const help = field.help === undefined ? '' : html`<div class="hint">${field.help}</div>`;
  const posted = draft[field.key];
  const control = controlFor(rc, db, spec, field, name, posted, subjectValues);
  return html`<tr class="frow${err}" id="f-${escapeAttribute(field.key)}"><th><label>${field.label}</label>${marks}</th><td>${control}${help}</td></tr>`;
}

function choiceOptions(rc: RequestContext, db: SqlDatabase, spec: OperationSpec, field: FieldSpec, subjectValues: Record<string, string>): Choice[] {
  if (field.provider !== undefined) return optionsFor(rc, db, field.provider, subjectValues, spec.kind);
  return (field.choices ?? []).map((choice) => typeof choice === 'string' ? { value: choice, label: choice } : choice);
}

function controlFor(rc: RequestContext, db: SqlDatabase, spec: OperationSpec, field: FieldSpec, name: string, posted: unknown, subjectValues: Record<string, string>): SafeHtml {
  const current = typeof posted === 'string' ? posted : typeof posted === 'number' ? String(posted) : '';
  switch (field.input) {
    case 'text': return html`<input type="text" name="${name}" value="${current === '' && field.defaultValue !== undefined ? field.defaultValue : current}"${field.maxLength === undefined ? '' : raw(` maxlength="${field.maxLength}"`)}${field.placeholder === undefined ? '' : html` placeholder="${field.placeholder}"`}>`;
    case 'textarea': return html`<textarea name="${name}" rows="4"${field.placeholder === undefined ? '' : html` placeholder="${field.placeholder}"`}>${current}</textarea>`;
    case 'integer': return html`<input type="number" step="1" name="${name}" value="${current}"${field.placeholder === undefined ? '' : html` placeholder="${field.placeholder}"`}>`;
    case 'date': return html`<input type="date" name="${name}" value="${current}">`;
    case 'instant': return html`<input type="text" name="${name}" value="${current}" placeholder="2026-09-15T18:00:00Z" pattern="\d{4}-\d{2}-\d{2}T\d{2}:\d{2}.*" class="mono">`;
    case 'boolean': return html`<input type="checkbox" name="${name}"${posted === 'on' || posted === true ? ' checked' : ''}>`;
    case 'select': {
      const options = choiceOptions(rc, db, spec, field, subjectValues);
      return html`<select name="${name}"><option value="">— choose —</option>${options.map((option) => html`<option value="${option.value}"${current === option.value ? ' selected' : ''}>${option.label}</option>`)}</select>`;
    }
    case 'multiselect': {
      const options = choiceOptions(rc, db, spec, field, subjectValues);
      const selected = new Set(Array.isArray(posted) ? posted.map(String) : []);
      return html`<select name="${name}[]" multiple size="${Math.min(8, Math.max(3, options.length))}">${options.map((option) => html`<option value="${option.value}"${selected.has(option.value) ? ' selected' : ''}>${option.label}</option>`)}</select>`;
    }
    case 'partylist': {
      const options = choiceOptions(rc, db, spec, { ...field, input: 'multiselect' }, subjectValues);
      const record = posted !== null && typeof posted === 'object' ? posted as Record<string, unknown> : {};
      const selected = new Set(Array.isArray(record.selected) ? (record.selected as string[]).map(String) : []);
      return html`<select name="${name}[selected][]" multiple size="4">${options.map((option) => html`<option value="${option.value}"${selected.has(option.value) ? ' selected' : ''}>${option.label}</option>`)}</select>
        <div class="hint">Additional member numbers (one per line):</div>
        <textarea name="${name}[extra]" rows="2">${typeof record.extra === 'string' ? record.extra : ''}</textarea>`;
    }
    case 'lines': return html`<textarea name="${name}" rows="4">${current}</textarea>`;
    case 'money': case 'signedMoney': {
      const record = posted !== null && typeof posted === 'object' ? posted as Record<string, unknown> : {};
      const currencies = optionsFor(rc, db, 'currencies', {});
      return html`<input type="text" name="${name}[amount]" value="${typeof record.amount === 'string' ? record.amount : ''}" size="14" class="mono" placeholder="0.00">
        <select name="${name}[currency]">${currencies.map((option) => html`<option value="${option.value}"${record.currency === option.value ? ' selected' : ''}>${option.value}</option>`)}</select>`;
    }
    case 'address': {
      const record = posted !== null && typeof posted === 'object' ? posted as Record<string, unknown> : {};
      const part = (key: string) => txt(record[key]);
      return html`<div class="addr">
        <input type="text" name="${name}[line1]" value="${part('line1')}" placeholder="Line 1"><br>
        <input type="text" name="${name}[line2]" value="${part('line2')}" placeholder="Line 2 (optional)"><br>
        <input type="text" name="${name}[city]" value="${part('city')}" placeholder="City" size="18">
        <input type="text" name="${name}[region]" value="${part('region')}" placeholder="Region" size="10"><br>
        <input type="text" name="${name}[postalCode]" value="${part('postalCode')}" placeholder="Postal code" size="10">
        <input type="text" name="${name}[country]" value="${part('country')}" placeholder="Country" size="14"></div>`;
    }
    case 'ref': return html`<input type="text" name="${name}" value="${current}" class="mono" placeholder="record id or number">`;
    case 'bytes': return html`<textarea name="${name}" rows="8" class="mono" placeholder="Document text content (stored exactly as entered)">${current}</textarea>`;
    case 'region': {
      const record = posted !== null && typeof posted === 'object' ? posted as Record<string, unknown> : {};
      const part = (key: string) => { const v = record[key]; return v === undefined ? '0' : txt(v); };
      return html`<span class="mono">x <input type="number" name="${name}[x]" value="${part('x')}" size="6"> y <input type="number" name="${name}[y]" value="${part('y')}" size="6"> w <input type="number" name="${name}[width]" value="${part('width')}" size="6"> h <input type="number" name="${name}[height]" value="${part('height')}" size="6"></span>`;
    }
    case 'owners': {
      const rows = posted !== null && typeof posted === 'object' ? posted as Record<string, Record<string, unknown>> : {};
      const evidence = optionsFor(rc, db, 'memberEvidence', subjectValues);
      const row = (index: number) => {
        const record = rows[String(index)] ?? {};
        const val = (key: string) => txt(record[key]);
        return html`<tr><td><input type="text" name="${name}[${index}][memberId]" value="${val('memberId')}" class="mono" size="18" placeholder="member number"></td>
          <td><input type="number" name="${name}[${index}][ownershipBps]" value="${val('ownershipBps')}" size="7"></td>
          <td><input type="checkbox" name="${name}[${index}][isControlPerson]"${record.isControlPerson !== undefined ? ' checked' : ''}></td>
          <td><select name="${name}[${index}][evidenceId]"><option value="">— evidence —</option>${evidence.map((option) => html`<option value="${option.value}"${val('evidenceId') === option.value ? ' selected' : ''}>${option.label}</option>`)}</select></td></tr>`;
      };
      return html`<table class="subgrid"><thead><tr><th>Member</th><th>Ownership bps</th><th>Control</th><th>Evidence</th></tr></thead><tbody>${[0, 1, 2, 3].map(row)}</tbody></table>`;
    }
    case 'excerpts': {
      const rows = posted !== null && typeof posted === 'object' ? posted as Record<string, Record<string, unknown>> : {};
      const documents = optionsFor(rc, db, 'memberDocuments', subjectValues);
      const row = (index: number) => {
        const record = rows[String(index)] ?? {};
        const val = (key: string) => txt(record[key]);
        return html`<tr><td><select name="${name}[${index}][sourceVersionId]"><option value="">— source —</option>${documents.map((option) => html`<option value="${option.value}"${val('sourceVersionId') === option.value ? ' selected' : ''}>${option.label}</option>`)}</select></td>
          <td><input type="text" name="${name}[${index}][text]" value="${val('text')}" size="42"></td></tr>`;
      };
      return html`<table class="subgrid"><thead><tr><th>Source version</th><th>Approved excerpt text</th></tr></thead><tbody>${[0, 1, 2].map(row)}</tbody></table>`;
    }
    case 'subcommand': {
      const record = posted !== null && typeof posted === 'object' ? posted as Record<string, unknown> : {};
      const val = (key: string) => txt(record[key]);
      const kinds = ['contact.update', 'member.note.add', 'account.nickname.update', 'account.statement_delivery.update', 'account.close'];
      return html`<div class="subcmd">
        <div><label>Change kind <select name="${name}[kind]"><option value="">— choose —</option>${kinds.map((kind) => html`<option value="${kind}"${val('kind') === kind ? ' selected' : ''}>${kind}</option>`)}</select></label></div>
        <div><label>Account number (for account changes) <input type="text" name="${name}[accountNumber]" value="${val('accountNumber')}" class="mono"></label></div>
        <div><label>Nickname <input type="text" name="${name}[nickname]" value="${val('nickname')}"></label>
        <label>Delivery <select name="${name}[statementDelivery]"><option value="">—</option><option${val('statementDelivery') === 'paper' ? ' selected' : ''}>paper</option><option${val('statementDelivery') === 'electronic' ? ' selected' : ''}>electronic</option></select></label></div>
        <div><label>Visibility <select name="${name}[visibility]"><option value="">—</option><option${val('visibility') === 'general' ? ' selected' : ''}>general</option><option${val('visibility') === 'restricted' ? ' selected' : ''}>restricted</option></select></label>
        <label>Reason <input type="text" name="${name}[reason]" value="${val('reason')}"></label></div>
        <div><label>Note text <input type="text" name="${name}[text]" value="${val('text')}" size="40"></label></div>
        <div><label>Email <input type="text" name="${name}[email]" value="${val('email')}" size="20"></label>
        <label>Phone <input type="text" name="${name}[phone]" value="${val('phone')}" size="14"></label></div>
        <div class="hint">Address (for contact.update):</div>
        <div><input type="text" name="${name}[address][line1]" value="" placeholder="Line 1" size="20"> <input type="text" name="${name}[address][city]" value="" placeholder="City" size="12">
        <input type="text" name="${name}[address][region]" value="" placeholder="Region" size="6"> <input type="text" name="${name}[address][postalCode]" value="" placeholder="Postal" size="8">
        <input type="text" name="${name}[address][country]" value="" placeholder="Country" size="8"></div></div>`;
    }
    case 'savedSearchDef': {
      const record = posted !== null && typeof posted === 'object' ? posted as Record<string, unknown> : {};
      const val = (key: string) => txt(record[key]);
      const columns: Record<string, readonly string[]> = {
        members: ['member_number', 'display_name', 'kind', 'status', 'email', 'phone', 'open_accounts', 'joined_at', 'version'],
        accounts: ['account_number', 'member_number', 'owner_name', 'product_code', 'product_name', 'currency', 'status', 'nickname', 'statement_delivery', 'posted_minor_units', 'available_minor_units', 'opened_at', 'closed_at', 'version'],
        cases: ['case_number', 'member_number', 'member_name', 'account_number', 'queue_code', 'assigned_name', 'state', 'priority', 'category', 'summary', 'opened_at', 'due_at', 'overdue', 'version'],
      };
      const sorts: Record<string, readonly string[]> = {
        members: ['member_number', 'display_name', 'status', 'joined_at'],
        accounts: ['account_number', 'member_number', 'owner_name', 'product_code', 'status', 'nickname', 'posted_minor_units', 'available_minor_units', 'opened_at'],
        cases: ['case_number', 'due_at', 'opened_at', 'state', 'priority', 'member_number', 'queue_code', 'assigned_name'],
      };
      const entity = val('entity');
      const cols = columns[entity] ?? [];
      const sortFields = sorts[entity] ?? [];
      const selectedColumns = new Set(Array.isArray(record.columns) ? (record.columns as string[]) : []);
      return html`<div class="subcmd">
        <div><label>Entity <select name="${name}[entity]"><option value="">— choose —</option>${Object.keys(columns).map((key) => html`<option value="${key}"${entity === key ? ' selected' : ''}>${key}</option>`)}</select></label>
        <div class="hint">Submit this step once to load the column and sort choices for the entity, then finish the definition.</div></div>
        <div><label>Query filter <input type="text" name="${name}[filters][query]" value=""></label>
        <label>Status filter <input type="text" name="${name}[filters][status]" value=""></label>
        <label>Currency <input type="text" name="${name}[filters][currency]" value="" size="6"></label>
        <label>Priority <input type="text" name="${name}[filters][priority]" value="" size="8"></label>
        <label>Overdue <select name="${name}[filters][overdue]"><option value="">—</option><option value="true">yes</option></select></label></div>
        ${cols.length === 0 ? '' : html`<div><label>Sort <select name="${name}[sortField]"><option value="">—</option>${sortFields.map((key) => html`<option value="${key}">${key}</option>`)}</select></label>
        <label>Direction <select name="${name}[sortDirection]"><option value="asc">asc</option><option value="desc">desc</option></select></label></div>
        <div>Columns: ${cols.map((column) => html`<label class="flag"><input type="checkbox" name="${name}[columns][]" value="${column}"${selectedColumns.has(column) ? ' checked' : ''}> ${column}</label>`)}</div>`}
      </div>`;
    }
    default: return html`<input type="text" name="${name}" value="${current}">`;
  }
}

/** Field-value echo for the review table. */
export function displayValue(rc: RequestContext, db: SqlDatabase, value: unknown): HtmlValue {
  if (value === null) return html`<i>null</i>`;
  if (value === undefined) return html`<i>unset</i>`;
  if (typeof value === 'boolean') return value ? 'yes' : 'no';
  if (typeof value === 'number') return String(value);
  if (typeof value === 'string') return value === '' ? html`<i>empty</i>` : value;
  if (value instanceof Uint8Array) return `${value.byteLength} bytes`;
  if (Array.isArray(value)) return value.length === 0 ? html`<i>none</i>` : html`<ul class="flat">${value.map((item) => html`<li>${displayValue(rc, db, item)}</li>`)}</ul>`;
  if (typeof value === 'object') {
    const record = value as Record<string, unknown>;
    if ('minorUnits' in record && 'currency' in record) return moneyCell(rc, db, Number(record.minorUnits), String(record.currency));
    if ('line1' in record) return `${String(record.line1)}${typeof record.line2 === 'string' ? `, ${record.line2}` : ''}, ${String(record.city)}, ${String(record.region)} ${String(record.postalCode)}, ${String(record.country)}`;
    return html`<ul class="flat">${Object.entries(record).map(([key, entry]) => html`<li><b>${key}</b>: ${displayValue(rc, db, entry)}</li>`)}</ul>`;
  }
  return JSON.stringify(value);
}

/** Module landing page: the operation index for one module. */
export function moduleIndex(module: ModuleKey): SafeHtml {
  const specs = operationsByModule(module);
  return html`<table class="grid"><thead><tr><th>Operation</th><th>Command</th><th>Description</th></tr></thead><tbody>
    ${specs.map((spec) => html`<tr><td><a href="/op/${spec.kind}">${spec.title}</a></td><td class="mono small">${spec.kind}</td><td>${spec.summary}</td></tr>`)}
  </tbody></table>`;
}
