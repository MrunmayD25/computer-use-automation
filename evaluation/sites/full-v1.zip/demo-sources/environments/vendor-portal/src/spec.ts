/**
 * Declarative operation metadata. Each entry describes one financial-service command kind as a
 * classic multi-page form: which record references the operator picks first, which fields they
 * enter, and which concurrency facts (versions, fingerprints, digests) the server resolves from
 * the authoritative store. The form never asks the user to type fingerprints.
 */

/** Record kinds a user can pick. Resolution accepts the internal id or the public business number. */
export type RefKind =
  | 'member' | 'account' | 'case' | 'document' | 'document-version' | 'maintenance-request'
  | 'saved-search' | 'merge-plan' | 'identity-evidence' | 'consent' | 'address' | 'party-address'
  | 'address-destination' | 'communication-job' | 'annotation' | 'receipt'
  | 'beneficiary' | 'beneficiary-route' | 'payment' | 'payment-schedule' | 'schedule-occurrence'
  | 'payment-return' | 'card' | 'card-transaction' | 'dispute' | 'loan' | 'interest-calculation'
  | 'fee' | 'hold' | 'restriction' | 'facility' | 'maturity-instruction' | 'received-funds'
  | 'settlement-batch' | 'suspense-item' | 'batch' | 'batch-item' | 'journal' | 'transfer'
  | 'transaction' | 'loan-closure' | 'approval' | 'actor' | 'party' | 'product' | 'queue'
  | 'policy-version';

export type Choice = { value: string; label: string };
export type ChoiceList = readonly (string | Choice)[];

/** Provider names resolved against the current subjects; implemented in resolve.ts. */
export type OptionProvider =
  | 'products' | 'loanProducts' | 'currencies' | 'queues' | 'caseWorkers' | 'policyVersions'
  | 'memberAccounts' | 'memberEvidence' | 'memberEvidenceVerified' | 'memberDocuments'
  | 'memberConsents' | 'memberConsentsMail' | 'memberAddresses' | 'memberDestinations'
  | 'memberMaintenanceRequests' | 'memberCommunicationJobs' | 'memberBeneficiaries'
  | 'accountBeneficiaryRoutes' | 'batchItems' | 'documentAnnotations' | 'myApprovals'
  | 'signerParties' | 'receivedFunds' | 'accountMemberAccounts' | 'memberCases'
  | 'mergePlans' | 'cardMemberEvidence' | 'cardMemberDestinations' | 'cardMemberAddresses'
  | 'cardMemberDocuments' | 'disputeMemberDocuments' | 'caseDocuments' | 'actors' | 'approvalCheckers';

export interface FieldSpec {
  /** Command property name. */
  key: string;
  label: string;
  input:
    | 'text' | 'textarea' | 'integer' | 'money' | 'signedMoney' | 'date' | 'instant' | 'boolean'
    | 'select' | 'multiselect' | 'lines' | 'address' | 'ref' | 'bytes' | 'region'
    | 'owners' | 'excerpts' | 'subcommand' | 'savedSearchDef' | 'partylist';
  choices?: ChoiceList;
  provider?: OptionProvider;
  ref?: RefKind;
  /** For 'ref' fields: convert the resolved member id to its party id. */
  as?: 'partyId';
  /** The command carries JSON null for this field. Renders a companion "none" checkbox. */
  nullable?: boolean;
  /** The property may be absent. Renders a companion "set" checkbox. */
  optional?: boolean;
  /** Pre-fills the input on a fresh form. */
  defaultValue?: string;
  help?: string;
  placeholder?: string;
  maxLength?: number;
}

/** A record the operator must identify before the detail form renders. */
export interface SubjectSpec {
  key: string;
  label: string;
  ref: RefKind;
  optional?: boolean;
  help?: string;
  /** Default true: the resolved id becomes a command property. False when it only scopes provider lists. */
  intoCommand?: false;
}

/** Server-resolved concurrency/identity facts carried from the form page into the command. */
export interface ResolvedSpec {
  /** Command property name; empty for multi-value resolvers such as mergeFacts. */
  key: string;
  resolver:
    | { of: 'version'; subject: string }
    | { of: 'fingerprint'; kind: FinanceRecordKindName; subject: string }
    | { of: 'recordField'; kind: FinanceRecordKindName; subject: string; field: string }
    | { of: 'memberParty'; subject: string }
    | { of: 'memberVersion'; subject: string }
    | { of: 'caseParty'; subject: string }
    | { of: 'docDigest'; subject: string }
    | { of: 'documentMetadata'; subject: string }
    | { of: 'requestUpdatedAt'; subject: string }
    | { of: 'savedSearchRevision'; subject: string }
    | { of: 'mergeFacts'; subject: string }
    | { of: 'overdraftFacilityFingerprint'; subject: string }
    | { of: 'maturityInstructionFingerprint'; subject: string }
    | { of: 'addressDestination'; member: string; context: string; target: string }
    | { of: 'loanClosureFingerprint'; subject: string }
    | { of: 'loanParty'; subject: string }
    | { of: 'annotationFingerprint'; subject: string }
    | { of: 'routeBeneficiary'; subject: string }
    | { of: 'beneficiaryRoute'; subject: string }
    | { of: 'consentChannel'; subject: string };
}

export type FinanceRecordKindName =
  | 'beneficiary' | 'beneficiary-route' | 'payment' | 'payment-schedule' | 'schedule-occurrence'
  | 'payment-return' | 'card' | 'card-transaction' | 'dispute' | 'loan' | 'interest-calculation'
  | 'fee' | 'hold' | 'restriction' | 'facility' | 'maturity-instruction' | 'received-funds'
  | 'transaction' | 'journal' | 'transfer' | 'settlement-batch' | 'suspense-item' | 'batch'
  | 'loan-closure';

export type ModuleKey =
  | 'members' | 'accounts' | 'money' | 'payments' | 'cards' | 'loans' | 'documents' | 'servicing'
  | 'cases' | 'maintenance' | 'reconciliation' | 'approvals' | 'searches' | 'system';

export interface OperationSpec {
  kind: string;
  /** Primary evaluation task this operation serves (documentation only). */
  task: string;
  module: ModuleKey;
  title: string;
  summary: string;
  subjects: readonly SubjectSpec[];
  resolved: readonly ResolvedSpec[];
  fields: readonly FieldSpec[];
  /** The command carries an approvalId bound to an independent checker decision. */
  approval?: boolean;
  /** Constant properties merged into the command at build time. */
  constants?: Record<string, unknown>;
  /** Wraps all user fields under this property (maintenance.draft.amend's patch). */
  patchKey?: string;
  /** Review page shows these extra cautions. */
  cautions?: readonly string[];
}
