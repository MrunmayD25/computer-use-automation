import type { Rejection, SqlDatabase } from '@computer-use/financial-database/services';
import {
  FINANCE_GRANTS,
  SERVICING_GRANTS,
  authorizeQuery,
  documentAnnotation,
  listApprovals,
  listDocumentAnnotations,
  listEffectivePolicyVersions,
  listMemberAddressDestinations,
  listMemberCommunicationJobs,
  listMemberConsents,
  listMemberDocumentVersions,
  listMemberIdentityEvidence,
  listMemberMaintenanceRequests,
  listServicingQueues,
  maintenanceRequest,
  memberDetail,
  queryMemberMergePlan,
  readFinanceRecord,
  referenceData,
  savedSearchRevision,
  searchAccounts,
  searchCases,
} from '@computer-use/financial-database/services';
import type { RequestContext } from './context.js';
import type { Choice, FinanceRecordKindName, OptionProvider, RefKind, ResolvedSpec } from './spec.js';

const APPROVAL_TARGET_GRANTS: Record<string, readonly string[]> = { ...FINANCE_GRANTS, ...SERVICING_GRANTS };

type Row = Record<string, unknown>;
const textOf = (value: unknown): string => typeof value === 'string' ? value : typeof value === 'number' || typeof value === 'bigint' || typeof value === 'boolean' ? String(value) : value === null || value === undefined ? '' : JSON.stringify(value);
const str = (row: Row, key: string): string => textOf(row[key]);
const optStr = (row: Row, key: string): string | null => (row[key] === null || row[key] === undefined ? null : textOf(row[key]));

function one(rc: RequestContext, db: SqlDatabase, sql: string, ...params: (string | number)[]): Row | undefined {
  return db.prepare(sql).get(rc.binding.datasetId, ...params);
}

function all(rc: RequestContext, db: SqlDatabase, sql: string, ...params: (string | number)[]): Row[] {
  return db.prepare(sql).all(rc.binding.datasetId, ...params);
}

const REF_TABLES: Record<RefKind, { table: string; number?: string }> = {
  member: { table: 'members', number: 'member_number' },
  account: { table: 'accounts', number: 'account_number' },
  case: { table: 'cases', number: 'case_number' },
  document: { table: 'documents' },
  'document-version': { table: 'document_versions' },
  'maintenance-request': { table: 'maintenance_requests', number: 'request_number' },
  'saved-search': { table: 'saved_searches' },
  'merge-plan': { table: 'member_merge_plans' },
  'identity-evidence': { table: 'identity_evidence' },
  consent: { table: 'consents' },
  address: { table: 'addresses' },
  'party-address': { table: 'party_addresses' },
  'address-destination': { table: 'address_destinations' },
  'communication-job': { table: 'communication_jobs' },
  annotation: { table: 'document_annotations' },
  receipt: { table: 'operation_receipts', number: 'receipt_number' },
  beneficiary: { table: 'beneficiaries' },
  'beneficiary-route': { table: 'beneficiary_routes' },
  payment: { table: 'payments', number: 'reference' },
  'payment-schedule': { table: 'payment_schedules' },
  'schedule-occurrence': { table: 'schedule_occurrences' },
  'payment-return': { table: 'payment_returns' },
  card: { table: 'cards', number: 'token' },
  'card-transaction': { table: 'card_transactions' },
  dispute: { table: 'disputes', number: 'case_number' },
  loan: { table: 'loans' },
  'interest-calculation': { table: 'interest_calculations' },
  fee: { table: 'fees' },
  hold: { table: 'holds' },
  restriction: { table: 'restrictions' },
  facility: { table: 'facilities' },
  'maturity-instruction': { table: 'maturity_instructions' },
  'received-funds': { table: 'received_funds', number: 'reference' },
  'settlement-batch': { table: 'settlement_batches', number: 'reference' },
  'suspense-item': { table: 'suspense_items' },
  batch: { table: 'batches', number: 'batch_number' },
  'batch-item': { table: 'batch_items' },
  journal: { table: 'journals', number: 'reference' },
  transfer: { table: 'journals', number: 'reference' },
  transaction: { table: 'journals', number: 'reference' },
  'loan-closure': { table: 'loan_closures' },
  approval: { table: 'business_approvals' },
  actor: { table: 'actors', number: 'actor_number' },
  party: { table: 'parties' },
  product: { table: 'products', number: 'code' },
  queue: { table: 'queues', number: 'code' },
  'policy-version': { table: 'policy_versions' },
};

/** Resolves a user-supplied reference (internal id or public business number) to the record id. */
export function resolveRef(rc: RequestContext, db: SqlDatabase, ref: RefKind, input: string): { id: string } | { error: string } {
  const denied = authorizeQuery(db, rc.context);
  if (denied !== null) return { error: denied.message };
  const spec = REF_TABLES[ref];
  const value = input.trim();
  if (value.length === 0) return { error: 'A value is required.' };
  const byId = one(rc, db, `SELECT id FROM ${spec.table} WHERE dataset_id=? AND id=?`, value);
  if (byId !== undefined) return { id: str(byId, 'id') };
  if (spec.number !== undefined) {
    const byNumber = one(rc, db, `SELECT id FROM ${spec.table} WHERE dataset_id=? AND ${spec.number}=?`, value.toUpperCase());
    if (byNumber !== undefined) return { id: str(byNumber, 'id') };
  }
  return { error: `No ${ref} record matches.` };
}

/** Human-readable label for a resolved record reference, used on review pages and pickers. */
export function describeRef(rc: RequestContext, db: SqlDatabase, ref: RefKind, id: string): string {
  const spec = REF_TABLES[ref];
  const row = one(rc, db, `SELECT * FROM ${spec.table} WHERE dataset_id=? AND id=?`, id);
  if (row === undefined) return id;
  const number = spec.number === undefined ? null : optStr(row, spec.number);
  const extra = optStr(row, 'display_name') ?? optStr(row, 'nickname') ?? optStr(row, 'name') ?? optStr(row, 'reference') ?? optStr(row, 'state') ?? optStr(row, 'status');
  const label = number !== null && number !== id ? number : id;
  return extra === null || extra === label ? label : `${label} — ${extra}`;
}

function memberIdOfAccount(rc: RequestContext, db: SqlDatabase, accountId: string): string | undefined {
  const row = one(rc, db, 'SELECT member_id FROM accounts WHERE dataset_id=? AND id=?', accountId);
  return row === undefined ? undefined : str(row, 'member_id');
}
function accountIdOfCard(rc: RequestContext, db: SqlDatabase, cardId: string): string | undefined {
  const row = one(rc, db, 'SELECT account_id FROM cards WHERE dataset_id=? AND id=?', cardId);
  return row === undefined ? undefined : str(row, 'account_id');
}
function accountIdOfDispute(rc: RequestContext, db: SqlDatabase, disputeId: string): string | undefined {
  const row = one(rc, db, 'SELECT account_id FROM disputes WHERE dataset_id=? AND id=?', disputeId);
  return row === undefined ? undefined : str(row, 'account_id');
}
function partyIdOfMember(rc: RequestContext, db: SqlDatabase, memberId: string): string | undefined {
  const row = one(rc, db, "SELECT party_id FROM members WHERE dataset_id=? AND id=? AND status<>'merged'", memberId);
  return row === undefined ? undefined : str(row, 'party_id');
}
function memberIdOfCase(rc: RequestContext, db: SqlDatabase, caseId: string): string | undefined {
  const row = one(rc, db, 'SELECT member_id FROM cases WHERE dataset_id=? AND id=?', caseId);
  return row === undefined ? undefined : str(row, 'member_id');
}

type Values = Readonly<Record<string, string>>;

/** The member a form operates on, derived from whichever subject chain is present. */
export function memberContext(rc: RequestContext, db: SqlDatabase, values: Values): string | undefined {
  if (values.memberId !== undefined) return values.memberId;
  const accountKey = values.accountId ?? values.sourceAccountId;
  if (accountKey !== undefined) return memberIdOfAccount(rc, db, accountKey);
  if (values.caseId !== undefined) return memberIdOfCase(rc, db, values.caseId);
  if (values.cardId !== undefined) {
    const account = accountIdOfCard(rc, db, values.cardId);
    return account === undefined ? undefined : memberIdOfAccount(rc, db, account);
  }
  if (values.disputeId !== undefined) {
    const account = accountIdOfDispute(rc, db, values.disputeId);
    return account === undefined ? undefined : memberIdOfAccount(rc, db, account);
  }
  return undefined;
}

/** Produces select options for a provider, scoped by the currently resolved subject/field values. */
export function optionsFor(rc: RequestContext, db: SqlDatabase, provider: OptionProvider, values: Values, commandKind?: string): Choice[] {
  const memberId = memberContext(rc, db, values);
  switch (provider) {
    case 'products':
      return all(rc, db, "SELECT id,code,name FROM products WHERE dataset_id=? AND family='deposit' AND status='active' ORDER BY code")
        .map((row) => ({ value: str(row, 'id'), label: `${str(row, 'code')} — ${str(row, 'name')}` }));
    case 'loanProducts':
      return all(rc, db, "SELECT id,code,name FROM products WHERE dataset_id=? AND family='loan' AND status='active' ORDER BY code")
        .map((row) => ({ value: str(row, 'id'), label: `${str(row, 'code')} — ${str(row, 'name')}` }));
    case 'currencies':
      return referenceData(db, rc.binding.datasetId, rc.binding.institutionId).currencies.map((c) => ({ value: c.code, label: `${c.code} — ${c.name}` }));
    case 'queues': {
      const result = listServicingQueues(db, rc.context);
      return result.kind === 'authorized' ? result.value.map((q) => ({ value: q.id, label: `${q.code} — ${q.name}` })) : [];
    }
    case 'caseWorkers': case 'actors': {
      const rows = all(rc, db, "SELECT id,actor_number,display_name,status FROM actors WHERE dataset_id=? AND status='active' ORDER BY actor_number");
      return rows.map((row) => ({ value: str(row, 'id'), label: `${str(row, 'actor_number')} — ${str(row, 'display_name')}` }));
    }
    case 'policyVersions': {
      const result = listEffectivePolicyVersions(db, rc.context);
      return result.kind === 'authorized' ? result.value.map((p) => ({ value: p.id, label: `${p.name} ${p.version}` })) : [];
    }
    case 'memberAccounts': case 'accountMemberAccounts': {
      if (memberId === undefined) return [];
      const result = searchAccounts(db, rc.binding.datasetId, { memberId, limit: 200, offset: 0, sort: 'accountNumber', direction: 'asc' });
      return result.items.map((row) => ({ value: row.id, label: `${row.accountNumber} — ${row.nickname} (${row.status})` }));
    }
    case 'memberEvidence': case 'memberEvidenceVerified': case 'cardMemberEvidence': {
      if (memberId === undefined) return [];
      const result = listMemberIdentityEvidence(db, rc.context, memberId);
      if (result.kind !== 'authorized') return [];
      return result.value
        .filter((item) => provider === 'memberEvidence' || provider === 'cardMemberEvidence' || item.status === 'verified')
        .map((item) => ({ value: item.id, label: `${item.kind} · ${item.status} · ${item.sourceReference}` }));
    }
    case 'memberDocuments': case 'caseDocuments': case 'cardMemberDocuments': case 'disputeMemberDocuments': {
      if (memberId === undefined) return [];
      const result = listMemberDocumentVersions(db, rc.context, memberId);
      if (result.kind !== 'authorized') return [];
      return result.value.map((item) => ({ value: item.versionId, label: `${item.displayName} v${item.version} (${item.documentType})` }));
    }
    case 'memberConsents': case 'memberConsentsMail': {
      if (memberId === undefined) return [];
      const result = listMemberConsents(db, rc.context, memberId);
      if (result.kind !== 'authorized') return [];
      return result.value
        .filter((item) => item.state === 'granted' && (provider === 'memberConsents' || item.channel === 'mail'))
        .map((item) => ({ value: item.id, label: `${item.purpose} · ${item.channel} · ${item.accountId ?? 'party-wide'}` }));
    }
    case 'memberAddresses': case 'cardMemberAddresses': {
      if (memberId === undefined) return [];
      const rows = all(rc, db, `SELECT a.id,a.line1,a.city,a.postal_code,pa.purpose,pa.evidence_status FROM party_addresses pa
        JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
        JOIN members m ON m.dataset_id=pa.dataset_id AND m.party_id=pa.party_id
        WHERE pa.dataset_id=? AND m.id=? ORDER BY pa.valid_from DESC`, memberId);
      return rows.map((row) => ({ value: str(row, 'id'), label: `${str(row, 'line1')}, ${str(row, 'city')} ${str(row, 'postal_code')} (${str(row, 'purpose')}, ${str(row, 'evidence_status')})` }));
    }
    case 'memberDestinations': case 'cardMemberDestinations': {
      if (memberId === undefined) return [];
      const result = listMemberAddressDestinations(db, rc.context, memberId);
      if (result.kind !== 'authorized') return [];
      return result.value
        .filter((item) => item.endsAt === null)
        .map((item) => ({ value: item.id, label: `${item.context} → ${item.address.line1}, ${item.address.city} (${item.targetId})` }));
    }
    case 'memberMaintenanceRequests': {
      if (memberId === undefined) return [];
      const result = listMemberMaintenanceRequests(db, rc.context, memberId);
      if (result.kind !== 'authorized') return [];
      return result.value.map((item) => ({ value: item.id, label: `${item.requestNumber} — ${item.subject} (${item.state})` }));
    }
    case 'memberCommunicationJobs': {
      if (memberId === undefined) return [];
      const result = listMemberCommunicationJobs(db, rc.context, memberId);
      if (result.kind !== 'authorized') return [];
      return result.value.map((item) => ({ value: item.id, label: `${item.purpose} · ${item.channel} · ${item.state}` }));
    }
    case 'memberBeneficiaries': {
      if (memberId === undefined) return [];
      const party = partyIdOfMember(rc, db, memberId);
      if (party === undefined) return [];
      return all(rc, db, 'SELECT id,display_name,status FROM beneficiaries WHERE dataset_id=? AND owner_party_id=? ORDER BY display_name', party)
        .map((row) => ({ value: str(row, 'id'), label: `${str(row, 'display_name')} (${str(row, 'status')})` }));
    }
    case 'accountBeneficiaryRoutes': {
      const accountKey = values.accountId ?? values.sourceAccountId;
      if (accountKey === undefined) return [];
      const member = memberIdOfAccount(rc, db, accountKey);
      if (member === undefined) return [];
      const party = partyIdOfMember(rc, db, member);
      if (party === undefined) return [];
      const rows = all(rc, db, `SELECT r.id,b.display_name,r.routing_kind,r.masked_destination,r.status FROM beneficiary_routes r
        JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id
        WHERE r.dataset_id=? AND b.owner_party_id=? AND b.status='active' ORDER BY b.display_name,r.version`, party);
      return rows.map((row) => ({ value: str(row, 'id'), label: `${str(row, 'display_name')} · ${str(row, 'routing_kind')} ${str(row, 'masked_destination')} (${str(row, 'status')})` }));
    }
    case 'batchItems': {
      if (values.batchId === undefined) return [];
      const rows = all(rc, db, 'SELECT id,ordinal,source_key,state FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal', values.batchId);
      return rows.map((row) => ({ value: str(row, 'id'), label: `#${str(row, 'ordinal')} ${str(row, 'source_key')} (${str(row, 'state')})` }));
    }
    case 'documentAnnotations': {
      if (values.documentVersionId === undefined) return [];
      const result = listDocumentAnnotations(db, rc.context, values.documentVersionId);
      if (result.kind !== 'authorized') return [];
      return result.value.map((item) => ({ value: item.id, label: `p${item.pageNumber} — ${item.text.slice(0, 60)} (${item.status})` }));
    }
    case 'myApprovals': {
      const rows = all(rc, db, `SELECT a.id,a.status,p.display_name AS checker,v.name AS policy_name
        FROM business_approvals a JOIN actors p ON p.dataset_id=a.dataset_id AND p.id=a.checker_actor_id
        JOIN policy_versions v ON v.dataset_id=a.dataset_id AND v.id=a.policy_version_id
        WHERE a.dataset_id=? AND a.checker_actor_id=? AND a.status='approved' AND a.expires_at>(SELECT as_of FROM datasets WHERE id=?) ORDER BY a.expires_at`, rc.actorId, rc.binding.datasetId);
      return rows.map((row) => ({ value: str(row, 'id'), label: `${str(row, 'id').slice(0, 18)}… (you as checker, ${str(row, 'policy_name')})` }));
    }
    case 'approvalCheckers': {
      if (commandKind === undefined) return [];
      const grants = APPROVAL_TARGET_GRANTS[commandKind];
      if (grants === undefined || grants.length === 0) return [];
      const placeholders = grants.map(() => '?').join(',');
      const rows = all(rc, db, `SELECT DISTINCT a.id,a.actor_number,a.display_name FROM actors a
        JOIN actor_roles ar ON ar.dataset_id=a.dataset_id AND ar.actor_id=a.id
          AND ar.starts_at<=(SELECT as_of FROM datasets WHERE id=a.dataset_id) AND (ar.ends_at IS NULL OR ar.ends_at>(SELECT as_of FROM datasets WHERE id=a.dataset_id))
        JOIN role_permissions rp ON rp.dataset_id=a.dataset_id AND rp.role_id=ar.role_id
        WHERE a.dataset_id=? AND a.status='active' AND a.id<>? AND rp.permission IN (${placeholders}) ORDER BY a.actor_number`,
        rc.actorId, ...grants);
      return rows.map((row) => ({ value: str(row, 'id'), label: `${str(row, 'actor_number')} — ${str(row, 'display_name')}` }));
    }
    case 'signerParties': {
      if (memberId === undefined) return [];
      const party = partyIdOfMember(rc, db, memberId);
      const parties: Choice[] = party === undefined ? [] : [{ value: party, label: `Member party ${party.slice(0, 16)}…` }];
      const coOwners = all(rc, db, `SELECT DISTINCT ap.party_id,p.display_name FROM account_parties ap
        JOIN parties p ON p.dataset_id=ap.dataset_id AND p.id=ap.party_id
        WHERE ap.dataset_id=? AND ap.account_id IN (SELECT id FROM accounts WHERE dataset_id=? AND member_id=?) AND ap.party_id<>?`, memberId, party ?? '');
      for (const row of coOwners) parties.push({ value: str(row, 'party_id'), label: `Co-owner ${str(row, 'display_name')}` });
      return parties;
    }
    case 'receivedFunds': {
      const rows = memberId === undefined
        ? all(rc, db, 'SELECT id,reference,amount_minor_units,currency,state FROM received_funds WHERE dataset_id=? ORDER BY received_at DESC')
        : all(rc, db, 'SELECT id,reference,amount_minor_units,currency,state FROM received_funds WHERE dataset_id=? AND member_id=? ORDER BY received_at DESC', memberId);
      return rows.map((row) => ({ value: str(row, 'reference'), label: `${str(row, 'reference')} · ${str(row, 'amount_minor_units')} ${str(row, 'currency')} (${str(row, 'state')})` }));
    }
    case 'memberCases': {
      if (memberId === undefined) return [];
      const result = searchCases(db, rc.binding.datasetId, { memberId, limit: 200, offset: 0, sort: 'caseNumber', direction: 'asc' });
      return result.items.map((row) => ({ value: row.id, label: `${row.caseNumber} — ${row.summary} (${row.state})` }));
    }
    case 'mergePlans': {
      const rows = all(rc, db, 'SELECT id,state FROM member_merge_plans WHERE dataset_id=? ORDER BY created_at DESC');
      return rows.map((row) => ({ value: str(row, 'id'), label: `${str(row, 'id').slice(0, 16)}… (${str(row, 'state')})` }));
    }
    default:
      return [];
  }
}

/**
 * Runs the spec's resolvers whose subject key is present in `values`. Resolvers bound to form
 * fields (e.g. a fingerprint over a user-picked route) run when those fields post; subject-bound
 * resolvers run when the form renders and are carried through hidden state for stale detection.
 */
const FINANCE_RESOLVERS = new Set(['fingerprint', 'recordField', 'loanClosureFingerprint', 'loanParty', 'routeBeneficiary']);

/**
 * Two phases: row lookups run inside one read snapshot; finance-record fingerprints open their
 * own store reads (readFinanceRecord owns its snapshot and cannot nest inside ours).
 */
export function resolveValues(rc: RequestContext, spec: readonly ResolvedSpec[], values: Values): { resolved: Record<string, unknown>; issues: string[] } {
  const resolved: Record<string, unknown> = {};
  const issues: string[] = [];
  const deferred: string[] = [];
  rc.store.read((db) => {
    resolveValuesDb(rc, db, spec, values, resolved, issues, deferred);
  });
  resolveValuesFinance(rc, spec, values, resolved, issues, deferred);
  return { resolved, issues };
}

function resolveValuesFinance(rc: RequestContext, spec: readonly ResolvedSpec[], values: Values, resolved: Record<string, unknown>, issues: string[], deferred: string[]): void {
  const missing = (name: string | undefined) => name === undefined || values[name] === undefined || values[name].trim() === '';
  for (const entry of spec) {
    const r = entry.resolver;
    if (!FINANCE_RESOLVERS.has(r.of) || !('subject' in r)) continue;
    if (missing(r.subject)) continue;
    const kind: FinanceRecordKindName = r.of === 'loanClosureFingerprint' || r.of === 'loanParty' ? 'loan-closure' : r.of === 'routeBeneficiary' ? 'beneficiary-route' : 'kind' in r ? r.kind : 'beneficiary';
    const snapshot = financeSnapshot(rc, kind, values[r.subject] as string, issues);
    if (snapshot === undefined) continue;
    if (r.of === 'fingerprint' || r.of === 'loanClosureFingerprint') resolved[entry.key] = snapshot.fingerprint;
    else if (r.of === 'loanParty') resolved[entry.key] = snapshot.record.party_id;
    else if (r.of === 'routeBeneficiary') resolved[entry.key] = snapshot.record.beneficiary_id;
    else if (r.of === 'recordField') resolved[entry.key] = r.field === 'version' ? Number(snapshot.record.version) : snapshot.record[r.field];
  }
  for (const item of deferred) {
    const [key, kind, id] = item.split('\t');
    if (key === undefined || kind === undefined || id === undefined) continue;
    if (kind === 'merge-plan') {
      mergeFacts(rc, id, resolved, issues);
      continue;
    }
    const snapshot = financeSnapshot(rc, kind as FinanceRecordKindName, id, issues);
    if (snapshot !== undefined) resolved[key] = snapshot.fingerprint;
  }
}

function mergeFacts(rc: RequestContext, planId: string, resolved: Record<string, unknown>, issues: string[]): void {
  const plan = queryMemberMergePlan(rc.store, rc.context, planId);
  if (plan.kind !== 'found') { issues.push(plan.message); return; }
  resolved.sourceMemberId = plan.sourceMemberId;
  resolved.targetMemberId = plan.targetMemberId;
  resolved.expectedInventoryFingerprint = plan.fingerprint;
  rc.store.read((db) => {
    const source = one(rc, db, 'SELECT version FROM members WHERE dataset_id=? AND id=?', plan.sourceMemberId);
    const target = one(rc, db, 'SELECT version FROM members WHERE dataset_id=? AND id=?', plan.targetMemberId);
    if (source === undefined || target === undefined) issues.push('The merge plan members were not found.');
    else {
      resolved.expectedSourceVersion = Number(source.version);
      resolved.expectedTargetVersion = Number(target.version);
    }
  });
}

function resolveValuesDb(rc: RequestContext, db: SqlDatabase, spec: readonly ResolvedSpec[], values: Values, resolved: Record<string, unknown>, issues: string[], deferred: string[]): void {
  const missing = (name: string | undefined) => name === undefined || values[name] === undefined || values[name].trim() === '';
  for (const entry of spec) {
    const r = entry.resolver;
    if (FINANCE_RESOLVERS.has(r.of)) continue;
    switch (r.of) {
      case 'version': {
        if (missing(r.subject)) continue;
        resolved[entry.key] = recordVersion(rc, db, values[r.subject] as string, issues);
        break;
      }
      case 'memberVersion': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, "SELECT version FROM members WHERE dataset_id=? AND id=? AND status<>'merged'", values[r.subject] as string);
        if (row === undefined) issues.push(`The member ${values[r.subject]} was not found.`);
        else resolved[entry.key] = Number(row.version);
        break;
      }


      case 'memberParty': {
        if (missing(r.subject)) continue;
        const party = partyIdOfMember(rc, db, values[r.subject] as string);
        if (party === undefined) issues.push(`The member ${values[r.subject]} was not found.`);
        else resolved[entry.key] = party;
        break;
      }
      case 'caseParty': {
        if (missing(r.subject)) continue;
        const member = memberIdOfCase(rc, db, values[r.subject] as string);
        const party = member === undefined ? undefined : partyIdOfMember(rc, db, member);
        if (party === undefined) issues.push(`The case ${values[r.subject]} was not found.`);
        else resolved[entry.key] = party;
        break;
      }
      case 'docDigest': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, 'SELECT digest FROM document_versions WHERE dataset_id=? AND id=?', values[r.subject] as string);
        if (row === undefined) issues.push(`The document version ${values[r.subject]} was not found.`);
        else resolved[entry.key] = str(row, 'digest');
        break;
      }
      case 'documentMetadata': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, 'SELECT owner_party_id,account_id,document_type,display_name,retention_class FROM documents WHERE dataset_id=? AND id=?', values[r.subject] as string);
        if (row === undefined) issues.push(`The document ${values[r.subject]} was not found.`);
        else resolved[entry.key] = { ownerPartyId: str(row, 'owner_party_id'), accountId: optStr(row, 'account_id'), documentType: str(row, 'document_type'), displayName: str(row, 'display_name'), retentionClass: str(row, 'retention_class') };
        break;
      }
      case 'requestUpdatedAt': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, 'SELECT updated_at FROM maintenance_requests WHERE dataset_id=? AND id=?', values[r.subject] as string);
        if (row === undefined) issues.push(`The maintenance request ${values[r.subject]} was not found.`);
        else resolved[entry.key] = str(row, 'updated_at');
        break;
      }
      case 'savedSearchRevision': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, 'SELECT name,visibility,definition_json FROM saved_searches WHERE dataset_id=? AND id=?', values[r.subject] as string);
        if (row === undefined) issues.push(`The saved search ${values[r.subject]} was not found.`);
        else resolved[entry.key] = savedSearchRevision({ name: str(row, 'name'), visibility: str(row, 'visibility'), definitionJson: str(row, 'definition_json') });
        break;
      }
      case 'mergeFacts': {
        if (missing(r.subject)) continue;
        deferred.push(`${entry.key}	merge-plan	${values[r.subject] as string}`);
        break;
      }
      case 'overdraftFacilityFingerprint': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, "SELECT id FROM facilities WHERE dataset_id=? AND account_id=? AND kind='overdraft' AND status='active'", values[r.subject] as string);
        if (row === undefined) resolved[entry.key] = null;
        else deferred.push(`${entry.key}	facility	${str(row, 'id')}`);
        break;
      }
      case 'maturityInstructionFingerprint': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, "SELECT id FROM maturity_instructions WHERE dataset_id=? AND account_id=? AND state='active'", values[r.subject] as string);
        if (row === undefined) resolved[entry.key] = null;
        else deferred.push(`${entry.key}	maturity-instruction	${str(row, 'id')}`);
        break;
      }
      case 'addressDestination': {
        if (missing(r.member) || missing(r.context)) continue;
        const targetInput = values[r.target];
        const target = targetInput === undefined || targetInput.trim() === '' ? (values[r.member] as string) : targetInput;
        const result = listMemberAddressDestinations(db, rc.context, values[r.member] as string);
        if (result.kind !== 'authorized') { issues.push(result.message); break; }
        const current = result.value.find((item) => item.context === values[r.context] && item.targetId === target && item.endsAt === null);
        resolved[entry.key] = current === undefined ? null : current.id;
        break;
      }

      case 'annotationFingerprint': {
        if (missing(r.subject)) continue;
        const result = documentAnnotation(db, rc.context, values[r.subject] as string);
        if (result.kind !== 'authorized') { issues.push(result.message); break; }
        if (result.value === undefined) issues.push('The annotation was not found.');
        else resolved[entry.key] = result.value.fingerprint;
        break;
      }

      case 'beneficiaryRoute': {
        if (missing(r.subject)) continue;
        const row = one(rc, db, 'SELECT id FROM beneficiary_routes WHERE dataset_id=? AND beneficiary_id=? ORDER BY version DESC LIMIT 1', values[r.subject] as string);
        if (row === undefined) issues.push(`The beneficiary ${values[r.subject]} has no route.`);
        else deferred.push(`${entry.key}	beneficiary-route	${str(row, 'id')}`);
        break;
      }
      case 'consentChannel': {
        const consentMember = memberContext(rc, db, values);
        if (missing(r.subject) || consentMember === undefined) continue;
        const result = listMemberConsents(db, rc.context, consentMember);
        if (result.kind !== 'authorized') { issues.push(result.message); break; }
        const consent = result.value.find((item) => item.id === values[r.subject]);
        if (consent === undefined) issues.push(`The consent ${values[r.subject]} was not found.`);
        else resolved[entry.key] = [consent.channel];
        break;
      }
    }
  }
}

function recordVersion(rc: RequestContext, db: SqlDatabase, id: string, issues: string[]): number | undefined {
  for (const table of ['accounts', 'cases', 'members', 'payments']) {
    const row = one(rc, db, `SELECT version FROM ${table} WHERE dataset_id=? AND id=?`, id);
    if (row !== undefined) return Number(row.version);
  }
  issues.push(`The record ${id} was not found or has no version.`);
  return undefined;
}

function financeSnapshot(rc: RequestContext, kind: FinanceRecordKindName, id: string, issues: string[]) {
  const result = readFinanceRecord(rc.store, rc.context, kind, id);
  if (result.kind === 'found') return result.snapshot;
  issues.push(result.kind === 'rejected' ? result.message : `The ${kind} record ${id} was not found.`);
  return undefined;
}

export {
  documentAnnotation,
  listApprovals,
  listDocumentAnnotations,
  listEffectivePolicyVersions,
  listMemberAddressDestinations,
  listMemberCommunicationJobs,
  listMemberConsents,
  listMemberDocumentVersions,
  listMemberIdentityEvidence,
  listMemberMaintenanceRequests,
  listServicingQueues,
  maintenanceRequest,
  memberDetail,
  queryMemberMergePlan,
  readFinanceRecord,
  referenceData,
  savedSearchRevision,
  searchAccounts,
  searchCases,
};
export type { Rejection };
