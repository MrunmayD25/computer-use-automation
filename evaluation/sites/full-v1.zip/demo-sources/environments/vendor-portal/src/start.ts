import type { Server } from 'node:http';
import type { VendorPortal } from './server.js';

export interface StartedPortal {
  server: Server;
  origin: string;
  portal: VendorPortal;
}

export function startVendorPortal(portal: VendorPortal, host: string, port: number): Promise<StartedPortal> {
  return new Promise((resolve, reject) => {
    const server = portal.app.listen(port, host, () => {
      const address = server.address();
      const bound = typeof address === 'object' && address !== null ? address.port : port;
      resolve({ server, origin: `http://${host}:${bound}`, portal });
    });
    server.on('error', reject);
  });
}
