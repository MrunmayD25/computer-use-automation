import {
  accountDetail,
  accountTransactions,
  authorizeQuery,
  communicationJob,
  listActivity,
  listApprovals,
  listDocumentAnnotations,
  listDocumentSignatures,
  listMemberAddressDestinations,
  listMemberAddresses,
  listMemberCommunicationJobs,
  listMemberCommunicationPreferences,
  listMemberConsents,
  listMemberDocumentVersions,
  listMemberIdentityEvidence,
  listMemberMaintenanceRequests,
  listMemberRetentionHolds,
  listSavedSearches,
  maintenanceRequest,
  memberDetail,
  readFinanceRecord,
  queryFinance,
  receiptByNumber,
  referenceData,
  searchAccounts,
  searchCases,
  searchMembers,
  statementData,
  statementPeriods,
  servicingCaseDetail,
} from '@computer-use/financial-database/services';
import type { RequestContext } from './context.js';
import { formatInstant, formatMoney } from './format.js';
import { html, joinHtml, type HtmlValue, type SafeHtml } from './html.js';
import { operationsByModule } from './registry.js';
import { definitionList, link, moneyCell, table } from './render.js';
import { describeRef, optionsFor, resolveRef } from './resolve.js';
import type { ModuleKey } from './spec.js';

type Row = Record<string, unknown>;
const txt = (value: unknown): string => typeof value === 'string' ? value : typeof value === 'number' || typeof value === 'bigint' || typeof value === 'boolean' ? String(value) : value === null || value === undefined ? '' : JSON.stringify(value);
const s = (row: Row, key: string): string => txt(row[key]);

const ops = (module: ModuleKey) => html`<p class="oplinks">${joinHtml(operationsByModule(module).map((spec) => html`<a href="/op/${spec.kind}">${spec.title}</a>`), ' · ')}</p>`;

function reader(rc: RequestContext) {
  return { institutionId: rc.binding.institutionId, actorId: rc.actorId };
}

export function homePage(rc: RequestContext): SafeHtml {
  const ref = rc.store.read((db) => referenceData(db, rc.binding.datasetId, rc.binding.institutionId));
  return html`
  <form method="get" action="/members"><fieldset class="quick"><legend>Find member</legend>
    <label>Name, number, email or phone <input type="text" name="q" size="28"></label>
    <button type="submit">Search</button></fieldset></form>
  <form method="get" action="/receipts"><fieldset class="quick"><legend>Recover a receipt</legend>
    <label>Receipt number <input type="text" name="number" size="20" class="mono"></label>
    <button type="submit">Look up</button></fieldset></form>
  <h2>Modules</h2>
  ${table(['Module', 'Operations'], (['members', 'accounts', 'money', 'payments', 'cards', 'loans', 'documents', 'servicing', 'cases', 'maintenance', 'reconciliation', 'approvals', 'searches', 'system'] as const).map((module) => [
    html`<a href="/${module}">${module}</a>`, String(operationsByModule(module).length || '—'),
  ]))}
  <h2>Institution</h2>
  ${definitionList([
    ['Products', String(ref.products.length)],
    ['Queues', String(ref.queues.length)],
    ['Currencies', ref.currencies.map((c) => c.code).join(', ')],
  ])}`;
}

export function membersPage(rc: RequestContext, query: Record<string, string | undefined>): SafeHtml {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const offset = Number(query.offset ?? '0') || 0;
    const page = searchMembers(db, rc.binding.datasetId, {
      limit: 50, offset, sort: 'memberNumber', direction: 'asc',
      ...(query.q === undefined || query.q === '' ? {} : { query: query.q }),
      ...(query.status === undefined || query.status === '' ? {} : { status: query.status }),
    });
    const rows = page.items.map((row) => [
      link(`/member/${row.id}`, row.memberNumber), row.displayName, row.status,
      row.email ?? '—', row.phone ?? '—', String(row.openAccounts),
    ]);
    const qs = `q=${encodeURIComponent(query.q ?? '')}&status=${encodeURIComponent(query.status ?? '')}`;
    return html`${ops('members')}
    <form method="get" action="/members"><fieldset class="filters"><legend>Filter</legend>
      <label>Search <input type="text" name="q" value="${query.q ?? ''}"></label>
      <label>Status <select name="status"><option value="">any</option>${['active', 'inactive', 'deceased', 'merged'].map((v) => html`<option${query.status === v ? ' selected' : ''}>${v}</option>`)}</select></label>
      <button type="submit">Apply</button></fieldset></form>
    ${table(['Number', 'Name', 'Status', 'Email', 'Phone', 'Open accounts'], rows)}
    <p>${offset > 0 ? html`<a href="/members?${qs}&offset=${Math.max(0, offset - 50)}">← Previous</a>` : ''}
    ${offset + page.items.length < page.total ? html`<a href="/members?${qs}&offset=${offset + 50}">Next page →</a>` : ''}
    <span class="hint">${page.total} members</span></p>`;
  });
}

export function memberPage(rc: RequestContext, memberId: string): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const detail = memberDetail(db, rc.binding.datasetId, memberId, reader(rc));
    if (detail === undefined) return { error: 'Member not found.' };
    const member = detail.member;
    const evidence = listMemberIdentityEvidence(db, rc.context, memberId);
    const addresses = listMemberAddresses(db, rc.context, memberId);
    const destinations = listMemberAddressDestinations(db, rc.context, memberId);
    const consents = listMemberConsents(db, rc.context, memberId);
    const preferences = listMemberCommunicationPreferences(db, rc.context, memberId);
    const documents = listMemberDocumentVersions(db, rc.context, memberId);
    const jobs = listMemberCommunicationJobs(db, rc.context, memberId);
    const requests = listMemberMaintenanceRequests(db, rc.context, memberId);
    const holds = listMemberRetentionHolds(db, rc.context, memberId);
    return html`
    ${definitionList([
      ['Member number', html`<b class="mono">${member.memberNumber}</b>`],
      ['Name', member.displayName],
      ['Kind', member.kind],
      ['Status', member.status],
      ['Tax classification', member.taxClassification],
      ['Joined', member.joinedAt],
      ['Party', html`<span class="mono">${member.partyId}</span>`],
      ['Version', String(member.version)],
      ['Email', detail.email?.value ?? '—'], ['Phone', detail.phone?.value ?? '—'],
    ])}
    ${detail.person === null ? '' : html`
    ${detail.person.preferredName === null ? '' : html`<p>Preferred name: <b>${detail.person.preferredName}</b> (${detail.person.preferredNameScope ?? '—'})</p>`}
    ${detail.person.deceasedAt === null ? '' : html`<p class="notice">Deceased recorded ${detail.person.deceasedAt}.</p>`}`}
    ${detail.address === null ? '' : html`<p>Address: ${detail.address.line1}${detail.address.line2 === null ? '' : `, ${detail.address.line2}`}, ${detail.address.city}, ${detail.address.region} ${detail.address.postalCode}, ${detail.address.country} (${detail.address.evidenceStatus})</p>`}
    ${detail.organization === null ? '' : html`<h3>Organization</h3>${definitionList([['Legal name', detail.organization.legalName], ['Registration', detail.organization.registrationNumber], ['Type', detail.organization.organizationType]])}`}
    ${detail.redirectTo === null ? '' : html`<p class="notice">Merged into ${link(`/member/${detail.redirectTo.memberId}`, detail.redirectTo.memberNumber)}.</p>`}
    <h3>Accounts</h3>
    ${table(['Number', 'Nickname', 'Product', 'Status', 'Posted', 'Available'],
      detail.accounts.map((row) => [link(`/account/${row.id}`, row.accountNumber), row.nickname, row.productName, row.status, moneyCell(rc, db, row.postedMinorUnits, row.currency), moneyCell(rc, db, row.availableMinorUnits, row.currency)]))}
    <h3>Identity evidence</h3>
    ${evidence.kind === 'authorized' ? table(['Id', 'Kind', 'Status', 'Issued', 'Expires', 'Reference'],
      evidence.value.map((item) => [html`<span class="mono small">${item.id.slice(0, 18)}…</span>`, item.kind, item.status, item.issuedAt, item.expiresAt ?? '—', item.sourceReference])) : html`<p class="notice">${evidence.message}</p>`}
    <h3>Addresses</h3>
    ${addresses.kind === 'authorized' ? table(['Address id', 'Purpose', 'Address', 'From', 'To', 'Evidence'],
      addresses.value.map((item) => [html`<span class="mono small">${item.addressId.slice(0, 18)}…</span>`, item.purpose, `${item.line1}, ${item.city} ${item.postalCode}`, item.validFrom, item.validTo ?? '—', item.evidenceStatus])) : ''}
    ${destinations.kind === 'authorized' && destinations.value.length > 0 ? html`<h3>Delivery instructions</h3>${table(['Id', 'Context', 'Target', 'Address', 'Effective', 'Ends'],
      destinations.value.map((item) => [html`<span class="mono small">${item.id.slice(0, 18)}…</span>`, item.context, html`<span class="mono small">${item.targetId.slice(0, 18)}…</span>`, `${item.address.line1}, ${item.address.city}`, item.effectiveAt, item.endsAt ?? '—']))}` : ''}
    <h3>Consents</h3>
    ${consents.kind === 'authorized' ? table(['Id', 'Purpose', 'Channel', 'State', 'Effective', 'Account'],
      consents.value.map((item) => [html`<span class="mono small">${item.id.slice(0, 18)}…</span>`, item.purpose, item.channel, item.state, item.effectiveAt, item.accountId === null ? 'party-wide' : html`<span class="mono small">${item.accountId.slice(0, 18)}…</span>`])) : ''}
    ${preferences.kind === 'authorized' && preferences.value.length > 0 ? html`<h3>Communication preferences</h3>${table(['Purpose', 'Channel', 'State', 'Updated'], preferences.value.map((item) => [item.purpose, item.channel, item.state, item.updatedAt]))}` : ''}
    <h3>Documents</h3>
    ${documents.kind === 'authorized' ? table(['Version', 'Document', 'Type', 'Media', 'Digest'],
      documents.value.map((item) => [link(`/doc-version/${item.versionId}`, `v${item.version}`), item.displayName, item.documentType, item.mediaType, html`<span class="mono small">${item.digest.slice(0, 12)}…</span>`])) : ''}
    <h3>Communications</h3>
    ${jobs.kind === 'authorized' ? table(['Job', 'Purpose', 'Channel', 'Destination', 'State'],
      jobs.value.map((item) => [link(`/comm/${item.id}`, item.id.slice(0, 18) + '…'), item.purpose, item.channel, item.destination, item.state])) : ''}
    <h3>Cases</h3>
    ${table(['Number', 'Summary', 'State', 'Priority', 'Queue'],
      detail.cases.map((row) => [link(`/case/${row.id}`, row.caseNumber), row.summary, row.state, row.priority, row.queueCode]))}
    <h3>Maintenance requests</h3>
    ${requests.kind === 'authorized' ? table(['Number', 'Subject', 'State', 'Updated'],
      requests.value.map((item) => [link(`/request/${item.id}`, item.requestNumber), item.subject, item.state, item.updatedAt])) : ''}
    ${holds.kind === 'authorized' && holds.value.length > 0 ? html`<h3>Retention holds</h3>${table(['Id', 'On', 'Reason', 'State', 'Review'], holds.value.map((item) => [html`<span class="mono small">${item.id.slice(0, 18)}…</span>`, item.documentId ?? item.caseId ?? '—', item.reason, item.state, item.reviewAt]))}` : ''}
    <h3>Notes${detail.restrictedNotesWithheld > 0 ? ` (${detail.restrictedNotesWithheld} restricted withheld)` : ''}</h3>
    ${table(['When', 'Visibility', 'By', 'Text'], detail.notes.map((note) => [note.createdAt, note.visibility, note.actor?.displayName ?? 'system', note.text]))}
    <h3>Operations on this member</h3>
    ${ops('members')}`;
  });
}

export function accountsPage(rc: RequestContext, query: Record<string, string | undefined>): SafeHtml {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    let memberId: string | undefined;
    let memberError = '';
    if (query.member !== undefined && query.member.trim() !== '') {
      const resolved = resolveRef(rc, db, 'member', query.member);
      if ('error' in resolved) memberError = resolved.error;
      else memberId = resolved.id;
    }
    const page = searchAccounts(db, rc.binding.datasetId, {
      limit: 100, offset: 0, sort: 'accountNumber', direction: 'asc',
      ...(memberId === undefined ? {} : { memberId }),
      ...(query.q === undefined || query.q === '' ? {} : { query: query.q }),
      ...(query.status === undefined || query.status === '' ? {} : { status: query.status }),
    });
    return html`${ops('accounts')}
    <form method="get" action="/accounts"><fieldset class="filters"><legend>Filter</legend>
      <label>Member number <input type="text" name="member" value="${query.member ?? ''}" class="mono"></label>
      <label>Search <input type="text" name="q" value="${query.q ?? ''}"></label>
      <label>Status <select name="status"><option value="">any</option>${['open', 'restricted', 'dormant', 'closed', 'matured'].map((v) => html`<option${query.status === v ? ' selected' : ''}>${v}</option>`)}</select></label>
      <button type="submit">Apply</button></fieldset></form>
    ${memberError === '' ? '' : html`<p class="notice">${memberError}</p>`}
    ${table(['Number', 'Member', 'Owner', 'Product', 'Nickname', 'Status', 'Posted', 'Available'],
      page.items.map((row) => [link(`/account/${row.id}`, row.accountNumber), row.memberNumber, row.ownerName, row.productName, row.nickname, row.status, moneyCell(rc, db, row.postedMinorUnits, row.currency), moneyCell(rc, db, row.availableMinorUnits, row.currency)]))}`;
  });
}

export function accountPage(rc: RequestContext, accountId: string, query: Record<string, string | undefined>): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const detail = accountDetail(db, rc.binding.datasetId, accountId);
    if (detail === undefined) return { error: 'Account not found.' };
    const account = detail.account;
    const tx = accountTransactions(db, rc.binding.datasetId, accountId, {
      limit: 50, offset: 0,
      ...(query.start === undefined || query.start === '' ? {} : { startDate: query.start }),
      ...(query.end === undefined || query.end === '' ? {} : { endDate: query.end }),
      ...(query.direction === undefined || query.direction === '' ? {} : { direction: query.direction as 'credit' | 'debit' }),
      ...(query.text === undefined || query.text === '' ? {} : { text: query.text }),
    });
    return html`
    ${definitionList([
      ['Account number', html`<b class="mono">${account.accountNumber}</b>`],
      ['Member', link(`/member/${account.memberId}`, `${account.memberNumber} — ${account.ownerName}`)],
      ['Product', `${account.productCode} — ${account.productName}`],
      ['Status', `${account.status} (member ${detail.memberStatus})`],
      ['Currency', account.currency],
      ['Nickname', account.nickname],
      ['Statement delivery', account.statementDelivery],
      ['Posted balance', moneyCell(rc, db, account.postedMinorUnits, account.currency)],
      ['Available', moneyCell(rc, db, account.availableMinorUnits, account.currency)],
      ['Opened', account.openedAt],
      ['Closed', account.closedAt ?? '—'],
      ['Version', String(account.version)],
    ])}
    <h3>Eligibility</h3>
    ${table(['Action', 'Eligible', 'Reasons'], (['debit', 'credit', 'closure'] as const).map((key) => [
      key, detail.eligibility[key].eligible ? 'yes' : 'no', detail.eligibility[key].reasons.join('; '),
    ]))}
    ${detail.parties.length === 0 ? '' : html`<h3>Parties</h3>${table(['Party', 'Role', 'From', 'To'], detail.parties.map((party) => [html`<span class="mono small">${party.partyId.slice(0, 18)}… ${party.displayName}</span>`, party.role, party.startsAt, party.endsAt ?? '—']))}`}
    ${detail.holds.length === 0 ? '' : html`<h3>Holds</h3>${table(['Id', 'Amount', 'Status', 'Reason', 'Placed'], detail.holds.map((hold) => [html`<span class="mono small">${hold.id.slice(0, 18)}…</span>`, moneyCell(rc, db, hold.amountMinorUnits, account.currency), hold.status, hold.reason, hold.placedAt]))}`}
    ${detail.restrictions.length === 0 ? '' : html`<h3>Restrictions</h3>${table(['Id', 'Kind', 'Status', 'Authority'], detail.restrictions.map((r) => [html`<span class="mono small">${r.id.slice(0, 18)}…</span>`, r.kind, r.status, r.authority]))}`}
    ${detail.facilities.length === 0 ? '' : html`<h3>Facilities</h3>${table(['Id', 'Kind', 'Limit', 'Used', 'Status'], detail.facilities.map((f) => [html`<span class="mono small">${f.id.slice(0, 18)}…</span>`, f.kind, moneyCell(rc, db, f.limitMinorUnits, account.currency), moneyCell(rc, db, f.usedMinorUnits, account.currency), f.status]))}`}
    ${detail.maturityTerms.length === 0 ? '' : html`<h3>Maturity terms</h3>${table(['Maturity', 'Cutoff', 'Projected proceeds'], detail.maturityTerms.map((m) => [m.maturityDate, formatInstant(m.cutoffAt), moneyCell(rc, db, m.projectedProceedsMinorUnits, m.currency)]))}`}
    ${detail.maturityInstructions.length === 0 ? '' : html`<h3>Maturity instructions</h3>${table(['Id', 'State', 'Cutoff'], detail.maturityInstructions.map((m) => [html`<span class="mono small">${m.id.slice(0, 18)}…</span>`, m.state, formatInstant(m.cutoffAt)]))}`}
    ${detail.cards.length === 0 ? '' : html`<h3>Cards</h3>${table(['Card', 'Last four', 'Status'], detail.cards.map((card) => [link(`/record/card/${card.id}`, card.id.slice(0, 18) + '…'), card.lastFour, card.status]))}`}
    <h3>Transactions</h3>
    <form method="get" action="/account/${account.id}"><fieldset class="filters"><legend>Filter transactions</legend>
      <label>From <input type="date" name="start" value="${query.start ?? ''}"></label>
      <label>To <input type="date" name="end" value="${query.end ?? ''}"></label>
      <label>Direction <select name="direction"><option value="">both</option>${['credit', 'debit'].map((v) => html`<option${query.direction === v ? ' selected' : ''}>${v}</option>`)}</select></label>
      <label>Text <input type="text" name="text" value="${query.text ?? ''}"></label>
      <button type="submit">Apply</button></fieldset></form>
    ${table(['Reference', 'Posted', 'Effective', 'Description', 'Amount', 'Balance after', 'Receipt'],
      tx.items.map((row) => [link(`/record/journal/${row.journalId}`, row.reference), formatInstant(row.postedAt), row.effectiveDate, row.description,
        moneyCell(rc, db, row.amountMinorUnits, account.currency), moneyCell(rc, db, row.runningBalanceMinorUnits, account.currency),
        row.receiptNumber === null ? '—' : link(`/receipt/${row.receiptNumber}`, row.receiptNumber)]))}
    <h3>Operations on this account</h3>
    ${ops('accounts')} ${ops('money')}
    <h3>Statements and exports</h3>
    ${statementPeriods(db, rc.binding.datasetId, accountId).length === 0 ? html`<p class="empty">No posted statement periods.</p>` : html`<ul class="flat">${statementPeriods(db, rc.binding.datasetId, accountId).map((period) => html`<li><a href="/account/${account.id}/statement?period=${period}">${period}</a> · <a href="/account/${account.id}/statement/download?period=${period}&format=pdf">PDF</a> · <a href="/account/${account.id}/statement/download?period=${period}&format=csv">CSV</a></li>`)}</ul>`}`;
  });
}

export function statementPage(rc: RequestContext, accountId: string, period: string): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const statement = statementData(db, rc.binding.datasetId, accountId, period);
    if (statement === undefined) return { error: 'Statement period or account not found.' };
    const exponent = referenceData(db, rc.binding.datasetId, rc.binding.institutionId).currencies.find((c) => c.code === statement.account.currency)?.exponent ?? 2;
    return html`<p class="summary">Derived from the posted ledger snapshot for ${statement.periodStart} through ${statement.periodEndExclusive}. No business record is changed.</p>
      ${definitionList([
        ['Member', statement.account.memberNumber], ['Account', statement.account.accountNumber], ['Period', statement.period],
        ['Opening balance', formatMoney(statement.openingMinorUnits, statement.account.currency, exponent)],
        ['Credits', formatMoney(statement.creditsMinorUnits, statement.account.currency, exponent)],
        ['Debits', formatMoney(statement.debitsMinorUnits, statement.account.currency, exponent)],
        ['Closing balance', formatMoney(statement.closingMinorUnits, statement.account.currency, exponent)],
      ])}
      <p class="actions"><a href="/account/${accountId}/statement/download?period=${period}&format=pdf">Download PDF</a> · <a href="/account/${accountId}/statement/download?period=${period}&format=csv">Download CSV</a> · <a href="/account/${accountId}/statement/download?period=${period}&format=html">Download HTML</a></p>
      ${table(['Date', 'Reference', 'Description', 'Signed amount'], statement.entries.map((entry) => [entry.date, entry.reference, entry.description, formatMoney(entry.amountMinorUnits, statement.account.currency, exponent)]))}`;
  });
}

/** Side-effect-free reconciliation inquiries keep the authoritative query service visible to operators. */
export function reconciliationInquiryPage(rc: RequestContext, query: Record<string, string | undefined>): SafeHtml {
  const transferId = query.transferId?.trim() ?? '';
  const cashIds = (query.cashSessionIds ?? '').split(',').map((value) => value.trim()).filter(Boolean);
  let result: unknown;
  if (transferId !== '') {
    const snapshot = readFinanceRecord(rc.store, rc.context, 'transfer', transferId);
    result = snapshot.kind === 'found' ? queryFinance(rc.store, rc.context, { kind: 'reconciliation.transfer', transferJournalId: transferId, expectedFingerprint: snapshot.snapshot.fingerprint }) : snapshot;
  } else if (cashIds.length > 0) {
    const amount = Number(query.declaredMinorUnits ?? '');
    result = Number.isSafeInteger(amount) ? queryFinance(rc.store, rc.context, { kind: 'reconciliation.cash_day', businessDate: query.businessDate ?? '', cashSessionIds: cashIds, declaredTotal: { currency: query.currency ?? '', minorUnits: amount } }) : { kind: 'rejected', message: 'Declared total must be an exact integer number of minor units.' };
  }
  return html`<p class="summary">These inquiries are read-only and use the shared reconciliation service. No balancing entries are created.</p>
    <h2>Internal transfer</h2><form method="get" action="/reconciliation/inquiry"><label>Transfer journal id <input class="mono" name="transferId" required></label> <button type="submit">Reconcile</button></form>
    <h2>Cash day</h2><form method="get" action="/reconciliation/inquiry"><label>Business date <input type="date" name="businessDate" required></label> <label>Session ids <input class="mono" name="cashSessionIds" placeholder="id-1,id-2" required></label> <label>Declared minor units <input type="number" name="declaredMinorUnits" required></label> <label>Currency <input name="currency" value="USD" maxlength="3" required></label> <button type="submit">Reconcile</button></form>
    ${result === undefined ? '' : html`<h2>Result</h2><pre class="mono small">${JSON.stringify(result, null, 2)}</pre>`}`;
}

export function casesPage(rc: RequestContext, query: Record<string, string | undefined>): SafeHtml {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const page = searchCases(db, rc.binding.datasetId, {
      limit: 100, offset: 0, sort: 'caseNumber', direction: 'asc',
      ...(query.q === undefined || query.q === '' ? {} : { query: query.q }),
      ...(query.state === undefined || query.state === '' ? {} : { states: [query.state] }),
      ...(query.queueId === undefined || query.queueId === '' ? {} : { queueId: query.queueId }),
      ...(query.priority === undefined || query.priority === '' ? {} : { priority: query.priority }),
    });
    const queues = optionsFor(rc, db, 'queues', {});
    return html`${ops('cases')}
    <form method="get" action="/cases"><fieldset class="filters"><legend>Filter</legend>
      <label>Search <input type="text" name="q" value="${query.q ?? ''}"></label>
      <label>Queue <select name="queueId"><option value="">any</option>${queues.map((o) => html`<option value="${o.value}"${query.queueId === o.value ? ' selected' : ''}>${o.label}</option>`)}</select></label>
      <label>State <select name="state"><option value="">any</option>${['open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened'].map((v) => html`<option${query.state === v ? ' selected' : ''}>${v}</option>`)}</select></label>
      <label>Priority <select name="priority"><option value="">any</option>${['low', 'normal', 'high', 'urgent'].map((v) => html`<option${query.priority === v ? ' selected' : ''}>${v}</option>`)}</select></label>
      <button type="submit">Apply</button></fieldset></form>
    ${table(['Number', 'Member', 'Summary', 'Queue', 'State', 'Priority', 'Due'],
      page.items.map((row) => [link(`/case/${row.id}`, row.caseNumber), link(`/member/${row.memberId}`, row.memberNumber), row.summary, row.queueCode, row.state, row.priority, formatInstant(row.dueAt)]))}`;
  });
}

export function casePage(rc: RequestContext, caseId: string): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const result = servicingCaseDetail(db, rc.context, caseId);
    if (result.kind !== 'authorized') return { error: result.message };
    if (result.value === undefined) return { error: 'Case not found.' };
    const detail = result.value;
    return html`
    ${definitionList([
      ['Case number', html`<b class="mono">${detail.caseNumber}</b>`],
      ['Member', link(`/member/${detail.memberId}`, describeRef(rc, db, 'member', detail.memberId))],
      ['Account', detail.accountId === null ? '—' : link(`/account/${detail.accountId}`, describeRef(rc, db, 'account', detail.accountId))],
      ['State', detail.state], ['Priority', detail.priority], ['Version', String(detail.version)],
    ])}
    <h3>Dependencies</h3>
    ${table(['Kind', 'Reference', 'State', 'Due'], detail.dependencies.map((d) => [d.kind, html`<span class="mono small">${d.referenceId.slice(0, 18)}…</span>`, d.state, d.dueAt === null ? '—' : formatInstant(d.dueAt)]))}
    <h3>Events</h3>
    ${table(['Seq', 'State', 'When', 'Detail'], detail.events.map((e) => [String(e.sequence), e.state, formatInstant(e.occurredAt), e.detail]))}
    <h3>Operations on this case</h3>
    ${ops('cases')}`;
  });
}

export function requestPage(rc: RequestContext, requestId: string): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const result = maintenanceRequest(db, rc.context, requestId);
    if (result.kind !== 'authorized') return { error: result.message };
    if (result.value === undefined) return { error: 'Maintenance request not found.' };
    const request = result.value;
    return html`
    ${definitionList([
      ['Request', html`<b class="mono">${request.requestNumber}</b>`],
      ['Member', link(`/member/${request.memberId}`, describeRef(rc, db, 'member', request.memberId))],
      ['Account', request.accountId === null ? '—' : link(`/account/${request.accountId}`, describeRef(rc, db, 'account', request.accountId))],
      ['Category', request.category],
      ['Subject', request.subject],
      ['Reason', request.reason ?? '—'],
      ['State', request.state],
      ['Created', request.createdAt], ['Updated', html`<span class="mono">${request.updatedAt}</span>`],
      ['Applied receipt', request.appliedReceiptId === null ? '—' : html`<span class="mono">${request.appliedReceiptId}</span>`],
    ])}
    <h3>Requested change</h3>
    <pre class="mono small">${JSON.stringify(request.draft, null, 2)}</pre>
    ${request.attachments.length === 0 ? '' : html`<h3>Attachments</h3>${table(['Version', 'Purpose'], request.attachments.map((a) => [link(`/doc-version/${a.documentVersionId}`, a.documentVersionId.slice(0, 18) + '…'), a.purpose]))}`}
    ${ops('maintenance')}`;
  });
}

export function commPage(rc: RequestContext, jobId: string): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const result = communicationJob(db, rc.context, jobId);
    if (result.kind !== 'authorized') return { error: result.message };
    if (result.value === undefined) return { error: 'Communication job not found.' };
    const job = result.value;
    return html`
    ${definitionList([
      ['Job', html`<span class="mono">${job.id}</span>`],
      ['Purpose', job.purpose], ['Channel', job.channel], ['Destination', job.destination], ['State', job.state],
      ['Document', job.documentVersionId === null ? '—' : link(`/doc-version/${job.documentVersionId}`, job.documentVersionId.slice(0, 18) + '…')],
    ])}
    <h3>Delivery events</h3>
    ${table(['Seq', 'State', 'When', 'Detail'], job.events.map((e) => [String(e.sequence), e.state, formatInstant(e.occurredAt), e.detail]))}
    ${ops('servicing')}`;
  });
}

export function docVersionPage(rc: RequestContext, versionId: string): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const row = db.prepare(`SELECT v.id AS vid,v.version,v.status,v.media_type,v.digest,v.issued_at,v.period_start,v.period_end,d.id AS did,d.display_name,d.document_type,d.retention_class,m.id AS mid,m.member_number
      FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
      WHERE v.dataset_id=? AND v.id=?`).get(rc.binding.datasetId, versionId) as Row | undefined;
    if (row === undefined) return { error: 'Document version not found.' };
    const annotations = listDocumentAnnotations(db, rc.context, versionId);
    const signatures = listDocumentSignatures(db, rc.context, versionId);
    return html`
    ${definitionList([
      ['Document', s(row, 'display_name')],
      ['Member', link(`/member/${s(row, 'mid')}`, s(row, 'member_number'))],
      ['Type', s(row, 'document_type')],
      ['Version', String(row.version)], ['Status', s(row, 'status')], ['Media', s(row, 'media_type')],
      ['Digest', html`<span class="mono small">${s(row, 'digest')}</span>`],
      ['Issued', formatInstant(s(row, 'issued_at'))],
      ['Retention', s(row, 'retention_class')],
    ])}
    <p><a href="/doc-version/${versionId}/download">Download bytes</a> · ${link(`/op/document.annotation.update`, 'Annotate')} · ${link(`/op/document.metadata.update`, 'Update metadata')} · ${link(`/op/document.signature.collect`, 'Signature ceremony')}</p>
    ${annotations.kind === 'authorized' && annotations.value.length > 0 ? html`<h3>Annotations</h3>${table(['Id', 'Page', 'Region', 'Text', 'Status', 'Fingerprint'],
      annotations.value.map((a) => [html`<span class="mono small">${a.id.slice(0, 18)}…</span>`, String(a.pageNumber), a.regionJson, a.text, a.status, html`<span class="mono small">${a.fingerprint.slice(0, 16)}…</span>`]))}` : ''}
    ${signatures.kind === 'authorized' && signatures.value.length > 0 ? html`<h3>Signatures</h3>${table(['Id', 'Signer', 'Status', 'Requested', 'Signed'],
      signatures.value.map((sig) => [html`<span class="mono small">${sig.id.slice(0, 18)}…</span>`, html`<span class="mono small">${sig.signerPartyId.slice(0, 18)}…</span>`, sig.status, formatInstant(sig.requestedAt), sig.signedAt === null ? '—' : formatInstant(sig.signedAt)]))}` : ''}
    ${ops('documents')}`;
  });
}

export function docDownload(rc: RequestContext, versionId: string): { bytes: Uint8Array; mediaType: string; name: string } | { error: string } {
  return rc.store.read((db) => {
    const denied = authorizeQuery(db, rc.context);
    if (denied !== null) return { error: denied.message };
    const row = db.prepare(`SELECT b.bytes,v.media_type,d.display_name,m.id AS mid FROM document_versions v
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
      JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      WHERE v.dataset_id=? AND v.id=?`).get(rc.binding.datasetId, versionId) as Row | undefined;
    if (row === undefined) return { error: 'Document version not found.' };
    const visible = listMemberDocumentVersions(db, rc.context, s(row, 'mid'));
    if (visible.kind !== 'authorized') return { error: visible.message };
    if (!visible.value.some((item) => item.versionId === versionId)) return { error: 'This document version is restricted.' };
    return { bytes: row.bytes as Uint8Array, mediaType: s(row, 'media_type'), name: s(row, 'display_name') };
  });
}

interface ListSpec {
  module: ModuleKey;
  sql: string;
  columns: { key: string; label: string; money?: boolean; self?: string }[];
  kind: string;
}

const LIST_SPECS: Record<string, ListSpec> = {
  beneficiaries: { module: 'payments', kind: 'beneficiary', sql: `SELECT b.id,b.display_name,b.status,p.display_name AS owner FROM beneficiaries b JOIN parties p ON p.dataset_id=b.dataset_id AND p.id=b.owner_party_id WHERE b.dataset_id=? ORDER BY b.display_name LIMIT 300`,
    columns: [{ key: 'id', label: 'Beneficiary', self: 'id' }, { key: 'display_name', label: 'Name' }, { key: 'owner', label: 'Owner' }, { key: 'status', label: 'Status' }] },
  routes: { module: 'payments', kind: 'beneficiary-route', sql: `SELECT r.id,b.display_name,r.routing_kind,r.masked_destination,r.status,r.version FROM beneficiary_routes r JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id WHERE r.dataset_id=? ORDER BY b.display_name,r.version LIMIT 300`,
    columns: [{ key: 'id', label: 'Route', self: 'id' }, { key: 'display_name', label: 'Beneficiary' }, { key: 'routing_kind', label: 'Kind' }, { key: 'masked_destination', label: 'Destination' }, { key: 'status', label: 'Status' }] },
  payments: { module: 'payments', kind: 'payment', sql: `SELECT p.id,p.reference,a.account_number,p.amount_minor_units,p.currency,p.requested_date,p.state,p.version FROM payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE p.dataset_id=? ORDER BY p.requested_date DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Payment', self: 'id' }, { key: 'reference', label: 'Reference' }, { key: 'account_number', label: 'Source' }, { key: 'amount_minor_units', label: 'Amount', money: true }, { key: 'requested_date', label: 'Requested' }, { key: 'state', label: 'State' }] },
  schedules: { module: 'payments', kind: 'payment-schedule', sql: `SELECT s.id,a.account_number,s.state,s.start_date,s.end_date FROM payment_schedules s JOIN accounts a ON a.dataset_id=s.dataset_id AND a.id=s.source_account_id WHERE s.dataset_id=? ORDER BY s.start_date DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Schedule', self: 'id' }, { key: 'account_number', label: 'Account' }, { key: 'state', label: 'State' }, { key: 'start_date', label: 'Start' }, { key: 'end_date', label: 'End' }] },
  occurrences: { module: 'payments', kind: 'schedule-occurrence', sql: `SELECT o.id,o.local_date,o.state,o.payment_id,o.schedule_id FROM schedule_occurrences o WHERE o.dataset_id=? ORDER BY o.local_date DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Occurrence', self: 'id' }, { key: 'local_date', label: 'Date' }, { key: 'state', label: 'State' }, { key: 'payment_id', label: 'Payment' }] },
  returns: { module: 'payments', kind: 'payment-return', sql: `SELECT r.id,p.reference AS payment,r.return_code,r.amount_minor_units,r.currency,r.occurred_at FROM payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id WHERE r.dataset_id=? ORDER BY r.occurred_at DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Return', self: 'id' }, { key: 'payment', label: 'Payment' }, { key: 'return_code', label: 'Code' }, { key: 'amount_minor_units', label: 'Amount', money: true }, { key: 'occurred_at', label: 'When' }] },
  cards: { module: 'cards', kind: 'card', sql: `SELECT c.id,a.account_number,c.last_four,c.status,c.expiry_month,c.expiry_year FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? ORDER BY c.id LIMIT 300`,
    columns: [{ key: 'id', label: 'Card', self: 'id' }, { key: 'account_number', label: 'Account' }, { key: 'last_four', label: 'Last four' }, { key: 'status', label: 'Status' }, { key: 'expiry_month', label: 'Expires' }] },
  cardtransactions: { module: 'cards', kind: 'card-transaction', sql: `SELECT t.id,c.last_four,t.merchant,t.amount_minor_units,t.currency,t.state,t.occurred_at FROM card_transactions t JOIN cards c ON c.dataset_id=t.dataset_id AND c.id=t.card_id WHERE t.dataset_id=? ORDER BY t.occurred_at DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Transaction', self: 'id' }, { key: 'last_four', label: 'Card' }, { key: 'merchant', label: 'Merchant' }, { key: 'amount_minor_units', label: 'Amount', money: true }, { key: 'state', label: 'State' }] },
  disputes: { module: 'cards', kind: 'dispute', sql: `SELECT d.id,d.case_number,a.account_number,d.claimed_amount_minor_units,d.currency,d.state,d.deadline FROM disputes d JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id WHERE d.dataset_id=? ORDER BY d.case_number LIMIT 300`,
    columns: [{ key: 'id', label: 'Dispute', self: 'id' }, { key: 'case_number', label: 'Number' }, { key: 'account_number', label: 'Account' }, { key: 'claimed_amount_minor_units', label: 'Claimed', money: true }, { key: 'state', label: 'State' }, { key: 'deadline', label: 'Deadline' }] },
  loans: { module: 'loans', kind: 'loan', sql: `SELECT l.id,a.account_number,l.principal_minor_units,l.currency,l.state,l.annual_rate_bps FROM loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id WHERE l.dataset_id=? ORDER BY l.opened_at DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Loan', self: 'id' }, { key: 'account_number', label: 'Account' }, { key: 'principal_minor_units', label: 'Principal', money: true }, { key: 'annual_rate_bps', label: 'Rate bps' }, { key: 'state', label: 'State' }] },
  loanapplications: { module: 'loans', kind: 'loan-application', sql: `SELECT la.id,m.member_number,la.requested_amount_minor_units,la.currency,la.state FROM loan_applications la JOIN members m ON m.dataset_id=la.dataset_id AND m.id=la.member_id WHERE la.dataset_id=? ORDER BY la.id LIMIT 300`,
    columns: [{ key: 'id', label: 'Application', self: 'id' }, { key: 'member_number', label: 'Member' }, { key: 'requested_amount_minor_units', label: 'Requested', money: true }, { key: 'state', label: 'State' }] },
  batches: { module: 'reconciliation', kind: 'batch', sql: `SELECT b.id,b.batch_number,b.kind,b.state,b.created_at FROM batches b WHERE b.dataset_id=? ORDER BY b.created_at DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Batch', self: 'id' }, { key: 'batch_number', label: 'Number' }, { key: 'kind', label: 'Kind' }, { key: 'state', label: 'State' }, { key: 'created_at', label: 'Created' }] },
  suspense: { module: 'reconciliation', kind: 'suspense-item', sql: `SELECT s.id,j.reference,s.remaining_amount_minor_units,s.currency,s.state FROM suspense_items s JOIN journals j ON j.dataset_id=s.dataset_id AND j.id=s.journal_id WHERE s.dataset_id=? ORDER BY s.id LIMIT 300`,
    columns: [{ key: 'id', label: 'Item', self: 'id' }, { key: 'reference', label: 'Journal' }, { key: 'remaining_amount_minor_units', label: 'Remaining', money: true }, { key: 'state', label: 'State' }] },
  journals: { module: 'money', kind: 'journal', sql: `SELECT j.id,j.reference,j.status,j.effective_date,j.description,j.posted_at FROM journals j WHERE j.dataset_id=? ORDER BY j.posted_at DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Journal', self: 'id' }, { key: 'reference', label: 'Reference' }, { key: 'status', label: 'Status' }, { key: 'effective_date', label: 'Effective' }, { key: 'description', label: 'Description' }] },
  requests: { module: 'maintenance', kind: 'maintenance-request', sql: `SELECT r.id,r.request_number,m.member_number,r.category,r.subject,r.state,r.updated_at FROM maintenance_requests r JOIN members m ON m.dataset_id=r.dataset_id AND m.id=r.member_id WHERE r.dataset_id=? ORDER BY r.updated_at DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Request', self: 'request' }, { key: 'request_number', label: 'Number' }, { key: 'member_number', label: 'Member' }, { key: 'subject', label: 'Subject' }, { key: 'state', label: 'State' }, { key: 'updated_at', label: 'Updated' }] },
  mergeplans: { module: 'members', kind: 'merge-plan', sql: `SELECT p.id,p.state,p.created_at,sm.member_number AS source,tm.member_number AS target FROM member_merge_plans p JOIN members sm ON sm.dataset_id=p.dataset_id AND sm.id=p.source_member_id JOIN members tm ON tm.dataset_id=p.dataset_id AND tm.id=p.target_member_id WHERE p.dataset_id=? ORDER BY p.created_at DESC LIMIT 300`,
    columns: [{ key: 'id', label: 'Plan', self: 'id' }, { key: 'source', label: 'Source' }, { key: 'target', label: 'Target' }, { key: 'state', label: 'State' }] },
};

export const LIST_NAMES = Object.keys(LIST_SPECS);

export function recordListPage(rc: RequestContext, list: string): SafeHtml | { error: string } {
  const spec = LIST_SPECS[list];
  if (spec === undefined) return { error: 'Unknown record list.' };
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const rows = db.prepare(spec.sql).all(rc.binding.datasetId) as Row[];
    return html`${ops(spec.module)}
    ${table(spec.columns.map((c) => c.label), rows.map((row) => spec.columns.map((column) => {
      const value = row[column.key];
      if (column.money === true) return moneyCell(rc, db, Number(value), typeof row.currency === 'string' ? row.currency : 'USD');
      if (column.self === 'id') return link(`/record/${spec.kind}/${txt(value)}`, `${txt(value).slice(0, 18)}…`);
      if (column.self === 'request') return link(`/request/${txt(value)}`, `${txt(value).slice(0, 18)}…`);
      return value === null || value === undefined ? '—' : txt(value);
    })))}`;
  });
}

const GENERIC_RECORD_TABLES: Record<string, string> = {
  'loan-application': 'loan_applications', 'merge-plan': 'member_merge_plans', 'maintenance-request': 'maintenance_requests',
};

export function recordPage(rc: RequestContext, kind: string, id: string): SafeHtml | { error: string } {
  if (GENERIC_RECORD_TABLES[kind] === undefined) return recordSnapshotPage(rc, kind, id);
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const generic = GENERIC_RECORD_TABLES[kind];
    const row = db.prepare(`SELECT * FROM ${generic} WHERE dataset_id=? AND id=?`).get(rc.binding.datasetId, id) as Row | undefined;
    if (row === undefined) return { error: `${kind} not found.` };
    return html`${definitionList([['Kind', kind], ['Record', html`<span class="mono">${id}</span>`]])}
    <h3>Fields</h3>${definitionList(Object.entries(row).map(([key, value]) => [key, displayRecord(value)] as const))}
    <p class="oplinks">${opsForRecord(kind)}</p>`;
  });
}

function recordSnapshotPage(rc: RequestContext, kind: string, id: string): SafeHtml | { error: string } {
  const result = readFinanceRecord(rc.store, rc.context, kind as never, id);
  if (result.kind === 'found') {
    const snapshot = result.snapshot;
    const entries = Object.entries(snapshot.record).map(([key, value]) => [key, displayRecord(value)] as const);
    return html`
    ${definitionList([
      ['Kind', snapshot.kind],
      ['Record', html`<span class="mono">${snapshot.id}</span>`],
      ['Fingerprint', html`<span class="mono small">${snapshot.fingerprint}</span>`],
      ['Observed', formatInstant(snapshot.observedAt)],
    ])}
    <h3>Fields</h3>
    ${definitionList(entries)}
    <p class="oplinks">${opsForRecord(kind)}</p>`;
  }
  return { error: result.kind === 'rejected' ? result.message : `${kind} not found.` };
}

function displayRecord(value: unknown): HtmlValue {
  if (value === null) return '—';
  if (typeof value === 'object') return html`<span class="mono small">${JSON.stringify(value)}</span>`;
  return txt(value);
}

const RECORD_OPS: Record<string, string[]> = {
  beneficiary: ['beneficiary.verify', 'beneficiary.routing.update', 'beneficiary.retire'],
  'beneficiary-route': ['beneficiary.verify'],
  payment: ['payment.submit', 'payment.approve_release', 'payment.settle', 'payment.cancel'],
  'payment-schedule': ['payment.schedule.end'],
  'schedule-occurrence': ['payment.schedule.materialize', 'payment.occurrence.amend'],
  'payment-return': ['payment.return.resolve'],
  card: ['card.replace', 'card.lock.update', 'card.limit.update'],
  dispute: ['dispute.provisional_credit.issue', 'dispute.evidence.submit', 'dispute.settle'],
  loan: ['loan.payment.allocate', 'loan.payoff.quote', 'loan.close', 'document.loan_closure.issue'],
  'suspense-item': ['reconciliation.suspense.investigate', 'reconciliation.suspense.clear'],
  batch: ['batch.contacts.apply', 'batch.fee_refunds.apply'],
  journal: ['cash.deposit.reverse', 'cash.withdrawal.reverse', 'transfer.internal.reverse', 'transaction.effective_date.correct', 'transaction.description.update'],
};

function opsForRecord(kind: string): SafeHtml | '' {
  const kinds = RECORD_OPS[kind] ?? [];
  if (kinds.length === 0) return '';
  return html`Operations: ${joinHtml(kinds.map((kind_) => html`<a href="/op/${kind_}">${kind_}</a>`), ' · ')}`;
}

export function approvalsPage(rc: RequestContext): SafeHtml {
  const result = listApprovals(rc.store, rc.context, 200);
  return rc.store.read((db) => {
    const items = result.kind === 'found' ? result.approvals : [];
    const pending = items.filter((item) => item.status === 'pending');
    const decided = items.filter((item) => item.status !== 'pending');
    return html`${ops('approvals')}
    <h3>Pending decisions</h3>
    ${table(['Approval', 'Target', 'Expires', 'Amount limit', 'Decide'], pending.map((item) => [
      html`<span class="mono small">${item.id.slice(0, 20)}…</span>`,
      html`<span class="mono small">${JSON.stringify(item.target).slice(0, 90)}</span>`,
      formatInstant(item.expiresAt),
      item.amountLimit === null ? '—' : moneyCell(rc, db, item.amountLimit.minorUnits, item.amountLimit.currency),
      link(`/approval/${item.id}/decide`, 'Decide'),
    ]))}
    <h3>Decided</h3>
    ${table(['Approval', 'Status', 'Target', 'Expires'], decided.map((item) => [
      html`<span class="mono small">${item.id.slice(0, 20)}…</span>`, item.status,
      html`<span class="mono small">${JSON.stringify(item.target).slice(0, 90)}</span>`, formatInstant(item.expiresAt),
    ]))}`;
  });
}

export function searchesPage(rc: RequestContext): SafeHtml {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const rows = listSavedSearches(db, rc.binding.datasetId, rc.actorId);
    return html`${ops('searches')}
    ${table(['Name', 'Visibility', 'Entity', 'Owner', 'Mine', 'Created'], rows.map((row) => [
      row.name, row.visibility, row.definition?.entity ?? '—', row.owner.displayName, row.mine ? 'yes' : 'no', row.createdAt,
    ]))}`;
  });
}

export function systemPage(rc: RequestContext): SafeHtml {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const ref = referenceData(db, rc.binding.datasetId, rc.binding.institutionId);
    const actors = db.prepare('SELECT actor_number,display_name,status FROM actors WHERE dataset_id=? ORDER BY actor_number').all(rc.binding.datasetId) as Row[];
    const policies = db.prepare('SELECT name,version,effective_at FROM policy_versions WHERE dataset_id=? ORDER BY effective_at').all(rc.binding.datasetId) as Row[];
    return html`
    <h3>Products</h3>${table(['Code', 'Name', 'Currency'], ref.products.map((p) => [p.code, p.name, p.currency]))}
    <h3>Queues</h3>${table(['Code', 'Name', 'Visibility'], ref.queues.map((q) => [q.code, q.name, q.visibility]))}
    <h3>Branches</h3>${table(['Number', 'Name', 'Time zone'], (db.prepare('SELECT branch_number,name,time_zone FROM branches WHERE dataset_id=? ORDER BY branch_number').all(rc.binding.datasetId) as Row[]).map((b) => [s(b, 'branch_number'), s(b, 'name'), s(b, 'time_zone')]))}
    <h3>Operators</h3>${table(['Number', 'Name', 'Status'], actors.map((a) => [s(a, 'actor_number'), s(a, 'display_name'), s(a, 'status')]))}
    <h3>Policy versions</h3>${table(['Name', 'Version', 'Effective'], policies.map((p) => [s(p, 'name'), s(p, 'version'), formatInstant(s(p, 'effective_at'))]))}`;
  });
}

export function activityPage(rc: RequestContext): SafeHtml {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const page = listActivity(db, rc.binding.datasetId, { limit: 100, offset: 0 });
    return html`${table(['When', 'Kind', 'Record', 'Summary', 'Actor', 'Operation', 'Receipt'],
      page.items.map((row) => [formatInstant(row.occurredAt), row.kind, html`<span class="mono small">${row.resourceKind}:${row.resourceId.slice(0, 12)}…</span>`, row.summary,
        row.actor === null ? '—' : row.actor.displayName, row.operationStatus ?? '—',
        row.receiptNumber === null ? '—' : link(`/receipt/${row.receiptNumber}`, row.receiptNumber)]))}`;
  });
}

export function receiptPage(rc: RequestContext, receiptNumber: string): SafeHtml | { error: string } {
  return rc.store.read((db) => {
    authorizeQuery(db, rc.context);
    const receipt = receiptByNumber(db, rc.binding.datasetId, receiptNumber);
    if (receipt === undefined) return { error: `Receipt ${receiptNumber} not found.` };
    return html`
    ${definitionList([
      ['Receipt', html`<b class="mono">${receipt.receiptNumber}</b>`],
      ['Operation', receipt.operationKind],
      ['Operation id', html`<span class="mono small">${receipt.operationId}</span>`],
      ['Status', receipt.status],
      ['Committed', receipt.committedAt],
      ['Actor', `${receipt.actor.actorNumber} — ${receipt.actor.displayName}`],
      ['Business reference', receipt.businessReference],
    ])}
    ${receipt.affected.length === 0 ? '' : html`<h3>Affected records</h3>${table(['Kind', 'Record', 'Number'], receipt.affected.map((a) => [a.kind, html`<span class="mono small">${a.id}</span>`, a.label]))}`}
    ${receipt.events.length === 0 ? '' : html`<h3>Events</h3>${table(['Seq', 'Kind', 'Record', 'Summary'], receipt.events.map((e) => [String(e.sequence), e.kind, html`<span class="mono small">${e.resourceId.slice(0, 14)}…</span>`, e.summary]))}`}
    ${receipt.journals.length === 0 ? '' : html`<h3>Journals</h3>${receipt.journals.map((journal) => html`
      <p><b class="mono">${journal.reference}</b> · ${journal.description} · effective ${journal.effectiveDate}</p>
      ${table(['Line', 'Ledger', 'Debit', 'Credit', 'Memo'], journal.lines.map((line) => [String(line.lineNumber), line.ledgerCode, String(line.debitMinorUnits), String(line.creditMinorUnits), line.memo]))}`)}`}
    ${receipt.result === null ? '' : html`<h3>Result</h3><pre class="mono small">${JSON.stringify(receipt.result, null, 2)}</pre>`}
    <p><a href="/activity">Activity</a> · <a href="/">Home</a></p>`;
  });
}
