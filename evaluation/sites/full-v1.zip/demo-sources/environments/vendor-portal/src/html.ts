/** HTML building with contextual escaping; `raw` is the escape hatch for composed markup. */
export class SafeHtml {
  readonly value: string;

  constructor(value: string) {
    this.value = value;
  }

  toString(): string {
    return this.value;
  }
}

export type HtmlValue = SafeHtml | string | number | false | null | undefined | readonly HtmlValue[];

const entities: Readonly<Record<string, string>> = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
};

export function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/gu, (character) => entities[character] ?? character);
}

export function escapeAttribute(text: string): string {
  return escapeHtml(text);
}

function isList(value: HtmlValue): value is readonly HtmlValue[] {
  return Array.isArray(value);
}

function renderValue(value: HtmlValue): string {
  if (value instanceof SafeHtml) return value.value;
  if (isList(value)) return value.map(renderValue).join('');
  if (value === null || value === undefined || value === false) return '';
  if (typeof value === 'number') return String(value);
  return escapeHtml(value);
}

export function html(strings: TemplateStringsArray, ...values: readonly HtmlValue[]): SafeHtml {
  let result = strings[0] ?? '';
  for (const [index, value] of values.entries()) {
    result += renderValue(value) + (strings[index + 1] ?? '');
  }
  return new SafeHtml(result);
}

export function raw(trustedHtml: string): SafeHtml {
  return new SafeHtml(trustedHtml);
}

/** Joins composed fragments with a separator — Array.join only accepts strings. */
export function joinHtml(items: readonly HtmlValue[], separator: HtmlValue): SafeHtml {
  return new SafeHtml(items.map(renderValue).join(typeof separator === 'object' && separator instanceof SafeHtml ? separator.value : renderValue(separator)));
}
