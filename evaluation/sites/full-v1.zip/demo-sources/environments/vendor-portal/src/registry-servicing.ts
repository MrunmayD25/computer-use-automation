import type { OperationSpec, SubjectSpec } from './spec.js';

const MEMBER = { key: 'memberId', label: 'Member', ref: 'member' as const };
const MEMBER_CTX: SubjectSpec = { key: 'memberId', label: 'Member', ref: 'member', intoCommand: false };
const CASE = { key: 'caseId', label: 'Case', ref: 'case' as const };
const REQUEST = { key: 'requestId', label: 'Maintenance request', ref: 'maintenance-request' as const };
const VERSION = (subject: string) => ({ key: 'expectedVersion', resolver: { of: 'version' as const, subject } });
const MEMBER_VERSION = { key: 'expectedVersion', resolver: { of: 'memberVersion' as const, subject: 'memberId' } };
const UPDATED_AT = { key: 'expectedUpdatedAt', resolver: { of: 'requestUpdatedAt' as const, subject: 'requestId' } };

const EVIDENCE_KINDS = ['passport', 'drivers-license', 'national-id', 'state-id'] as const;
const CONSENT_PURPOSES = ['account-statements', 'servicing-notices', 'loan-notices', 'card-shipping', 'marketing'] as const;
const COMM_CHANNELS = ['mail', 'email', 'online', 'phone', 'sms'] as const;
const DOCUMENT_TYPES = [
  'identity-document', 'passport', 'drivers-license', 'national-id', 'state-id', 'account-statement',
  'delivery-disclosure', 'servicing-notice', 'signature-evidence', 'redacted-evidence',
  'customer-record-export', 'batch-input', 'contact-evidence', 'address-evidence',
  'loan-closure-confirmation', 'simulated-lien-release', 'general',
] as const;

export const SERVICING_OPERATIONS: readonly OperationSpec[] = [
  {
    kind: 'member.identity_evidence.register', task: 'T014', module: 'members', title: 'Register identity evidence',
    summary: 'Registers an indexed identity document version as identity evidence for the member.',
    subjects: [MEMBER], resolved: [],
    fields: [
      { key: 'documentVersionId', label: 'Evidence document', input: 'select', provider: 'memberDocuments', help: 'The document version must be an indexed identity document.' },
      { key: 'evidenceId', label: 'Evidence id', input: 'text', optional: true, help: 'Leave unset to let the service assign one.' },
      { key: 'evidenceKind', label: 'Evidence kind', input: 'select', choices: [...EVIDENCE_KINDS] },
      { key: 'issuedAt', label: 'Issued on', input: 'date' },
      { key: 'expiresAt', label: 'Expires on', input: 'date' },
      { key: 'reference', label: 'Issuer reference', input: 'text' },
    ],
  },
  {
    kind: 'member.identity.verify', task: 'T014', module: 'members', title: 'Verify identity evidence',
    summary: 'Marks registered identity evidence verified through a recorded method.',
    subjects: [MEMBER], resolved: [],
    fields: [
      { key: 'evidenceId', label: 'Evidence', input: 'select', provider: 'memberEvidence' },
      { key: 'method', label: 'Verification method', input: 'text', placeholder: 'document-review' },
    ],
  },
  {
    kind: 'member.legal_name.update', task: 'T015', module: 'members', title: 'Update legal name',
    summary: 'Changes the member\'s legal name against authority evidence; needs independent approval.',
    subjects: [MEMBER], resolved: [MEMBER_VERSION], approval: true,
    fields: [
      { key: 'legalGiven', label: 'Legal given name', input: 'text', maxLength: 60 },
      { key: 'legalFamily', label: 'Legal family name', input: 'text', maxLength: 60 },
      { key: 'evidenceId', label: 'Authority evidence', input: 'select', provider: 'memberEvidenceVerified', help: 'Verified court-order or identity evidence.' },
      { key: 'approvalId', label: 'Approval', input: 'select', provider: 'myApprovals', optional: true, help: 'An approved request naming this exact change, or request one below.' },
    ],
  },
  {
    kind: 'member.preferred_name.update', task: 'T016', module: 'members', title: 'Update preferred name',
    summary: 'Records or clears the member\'s preferred name and its communication scope.',
    subjects: [MEMBER], resolved: [MEMBER_VERSION],
    fields: [
      { key: 'preferredName', label: 'Preferred name', input: 'text', nullable: true, maxLength: 60 },
      { key: 'communicationScope', label: 'Used in', input: 'select', choices: ['servicing', 'communications', 'all'] },
    ],
  },
  {
    kind: 'document.index', task: 'T058', module: 'documents', title: 'Index document',
    summary: 'Indexes document bytes into the member\'s durable document store with its metadata.',
    subjects: [MEMBER],
    resolved: [{ key: 'ownerPartyId', resolver: { of: 'memberParty', subject: 'memberId' } }],
    fields: [
      { key: 'accountId', label: 'Related account', input: 'select', provider: 'memberAccounts', nullable: true },
      { key: 'documentType', label: 'Document type', input: 'select', choices: [...DOCUMENT_TYPES] },
      { key: 'displayName', label: 'Display name', input: 'text', maxLength: 200 },
      { key: 'retentionClass', label: 'Retention class', input: 'select', choices: ['standard', 'financial-seven-years', 'legal-hold'] },
      { key: 'bytes', label: 'Document content', input: 'bytes' },
      { key: 'documentId', label: 'Attach to document', input: 'ref', ref: 'document', optional: true, help: 'An existing document id adds this as a new version; blank creates a document.' },
      { key: 'mediaType', label: 'Media type', input: 'text', optional: true, placeholder: 'text/plain' },
      { key: 'pageCount', label: 'Page count', input: 'integer', optional: true },
      { key: 'source', label: 'Source', input: 'select', choices: ['approved-local-source', 'approved-local-upload', 'approved-local-scan'], defaultValue: 'approved-local-scan' },
      { key: 'sourceDigest', label: 'Source digest', input: 'text', optional: true },
    ],
  },
  {
    kind: 'document.bundle.redact', task: 'T059', module: 'documents', title: 'Redact document bundle',
    summary: 'Builds a safe text derivative retaining only the approved excerpts under a redaction policy.',
    subjects: [MEMBER], resolved: [],
    fields: [
      { key: 'sourceVersionIds', label: 'Source versions', input: 'multiselect', provider: 'memberDocuments' },
      { key: 'recipientPurpose', label: 'Recipient purpose', input: 'text', maxLength: 120 },
      { key: 'redactionPolicyVersionId', label: 'Redaction policy', input: 'select', provider: 'policyVersions' },
      { key: 'approvedExcerpts', label: 'Approved excerpts', input: 'excerpts' },
      { key: 'displayName', label: 'Derivative name', input: 'text', optional: true },
    ],
  },
  {
    kind: 'document.signature.collect', task: 'T060', module: 'documents', title: 'Collect signature',
    summary: 'Requests or records a local signature ceremony outcome on a document version.',
    subjects: [MEMBER_CTX], resolved: [],
    fields: [
      { key: 'action', label: 'Ceremony action', input: 'select', choices: ['request', 'sign', 'decline', 'expire'] },
      { key: 'documentVersionId', label: 'Document version', input: 'select', provider: 'memberDocuments' },
      { key: 'signerPartyIds', label: 'Signers', input: 'partylist', provider: 'signerParties', help: 'Member parties that may sign; add extra member numbers in the box below.' },
      { key: 'channel', label: 'Channel', input: 'select', choices: ['authorized-local-signature', 'in-person-signature', 'secure-message-signature'] },
      { key: 'evidenceReference', label: 'Evidence reference', input: 'text', optional: true, help: 'Required when recording sign, decline or expire.' },
    ],
  },
  {
    kind: 'consent.delivery.record', task: 'T061', module: 'servicing', title: 'Record delivery consent',
    summary: 'Records the member\'s affirmative consent for a disclosure purpose and channel.',
    subjects: [MEMBER_CTX],
    resolved: [{ key: 'partyId', resolver: { of: 'memberParty', subject: 'memberId' } }],
    fields: [
      { key: 'accountId', label: 'Account scope', input: 'select', provider: 'memberAccounts', nullable: true, help: 'Blank applies the consent party-wide.' },
      { key: 'purpose', label: 'Purpose', input: 'select', choices: [...CONSENT_PURPOSES] },
      { key: 'channel', label: 'Channel', input: 'select', choices: [...COMM_CHANNELS] },
      { key: 'disclosureVersionId', label: 'Disclosure document', input: 'select', provider: 'memberDocuments' },
      { key: 'evidence', label: 'Acknowledgement evidence', input: 'text' },
    ],
  },
  {
    kind: 'consent.withdraw', task: 'T062', module: 'servicing', title: 'Withdraw consent',
    summary: 'Withdraws an active consent while preserving the original grant evidence.',
    subjects: [MEMBER_CTX],
    resolved: [{ key: 'affectedChannels', resolver: { of: 'consentChannel', subject: 'consentId' } }],
    fields: [
      { key: 'consentId', label: 'Consent', input: 'select', provider: 'memberConsents' },
      { key: 'effectiveAt', label: 'Effective at', input: 'instant', optional: true, help: 'Must not be in the future.' },
    ],
  },
  {
    kind: 'document.customer_export.create', task: 'T063', module: 'documents', title: 'Customer record export',
    summary: 'Compiles the approved member documents into a durable customer export artifact.',
    subjects: [MEMBER], resolved: [], approval: true,
    fields: [
      { key: 'categories', label: 'Categories', input: 'multiselect', choices: ['statements', 'disclosures', 'servicing-notices', 'servicing-evidence', 'signed-evidence'] },
      { key: 'from', label: 'From date', input: 'date', nullable: true },
      { key: 'through', label: 'Through date', input: 'date', nullable: true },
      { key: 'destination', label: 'Destination directory', input: 'text', help: 'Must be inside the configured export destinations.' },
      { key: 'documentVersionIds', label: 'Document versions', input: 'multiselect', provider: 'memberDocuments', help: 'The exact inventory bound into the approval.' },
      { key: 'approvalId', label: 'Approval', input: 'select', provider: 'myApprovals', optional: true },
    ],
  },
  {
    kind: 'document.retention_hold.apply', task: 'T064', module: 'documents', title: 'Apply retention hold',
    summary: 'Places a legal retention hold on a document or the documents attached to a case.',
    subjects: [
      { key: 'documentId', label: 'Document', ref: 'document', optional: true },
      { key: 'caseId', label: 'Case', ref: 'case', optional: true },
    ],
    resolved: [], approval: true,
    fields: [
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      { key: 'reviewAt', label: 'Review date', input: 'date' },
      { key: 'approvalId', label: 'Approval', input: 'select', provider: 'myApprovals', optional: true },
    ],
  },
  {
    kind: 'case.information.request', task: 'T067', module: 'cases', title: 'Request case information',
    summary: 'Sends the customer a missing-information request and opens a case dependency.',
    subjects: [CASE],
    resolved: [
      VERSION('caseId'),
      { key: 'recipientPartyId', resolver: { of: 'caseParty', subject: 'caseId' } },
    ],
    fields: [
      { key: 'fields', label: 'Requested items', input: 'lines', help: 'One required item per line.' },
      { key: 'channel', label: 'Channel', input: 'select', choices: ['email'] },
      { key: 'dueAt', label: 'Due at', input: 'instant' },
      { key: 'documentVersionId', label: 'Request letter', input: 'select', provider: 'caseDocuments', optional: true, nullable: true },
      { key: 'destination', label: 'Destination override', input: 'text', optional: true },
    ],
  },
  {
    kind: 'case.escalate', task: 'T068', module: 'cases', title: 'Escalate case',
    summary: 'Escalates an overdue case under a recorded escalation rule.',
    subjects: [CASE], resolved: [VERSION('caseId')],
    fields: [{ key: 'escalationRule', label: 'Escalation rule', input: 'text', maxLength: 200 }],
  },
  {
    kind: 'maintenance.address.reconcile', task: 'T069', module: 'maintenance', title: 'Reconcile member address',
    summary: 'Resolves a conflicting member address against verified evidence; needs approval.',
    subjects: [MEMBER],
    resolved: [
      { key: 'expectedMemberVersion', resolver: { of: 'memberVersion', subject: 'memberId' } },
      { key: 'winningEvidenceDigest', resolver: { of: 'docDigest', subject: 'winningEvidenceVersionId' } },
    ],
    approval: true,
    fields: [
      { key: 'conflictingAddressId', label: 'Conflicting address', input: 'select', provider: 'memberAddresses' },
      { key: 'winningEvidenceVersionId', label: 'Winning evidence', input: 'select', provider: 'memberDocuments' },
      { key: 'precedence', label: 'Precedence', input: 'select', choices: ['verified-evidence'] },
      { key: 'address', label: 'Approved address', input: 'address' },
      { key: 'approvalId', label: 'Approval', input: 'select', provider: 'myApprovals', optional: true },
    ],
  },
  {
    kind: 'maintenance.address.destination.update', task: 'T069', module: 'maintenance', title: 'Update address destination',
    summary: 'Sets the effective address instruction for a delivery context; needs approval.',
    subjects: [MEMBER],
    resolved: [{ key: 'expectedCurrentDestinationId', resolver: { of: 'addressDestination', member: 'memberId', context: 'context', target: 'targetId' } }],
    approval: true,
    fields: [
      { key: 'context', label: 'Delivery context', input: 'select', choices: ['member-mailing', 'account-statement', 'card-shipping', 'loan-notice'] },
      { key: 'targetId', label: 'Context target', input: 'text', help: 'Member number for member-mailing; otherwise the account number or card token the context addresses. Resolved to the record id.' },
      { key: 'addressId', label: 'Address', input: 'select', provider: 'memberAddresses' },
      { key: 'evidenceVersionId', label: 'Evidence', input: 'select', provider: 'memberDocuments' },
      { key: 'effectiveDate', label: 'Effective date', input: 'date' },
      { key: 'consentId', label: 'Postal consent', input: 'select', provider: 'memberConsentsMail', nullable: true, help: 'Granted mail consent for the context purpose; "none" records that none is required.' },
      { key: 'approvalId', label: 'Approval', input: 'select', provider: 'myApprovals', optional: true },
    ],
  },
  {
    kind: 'case.close', task: 'T070', module: 'cases', title: 'Close case',
    summary: 'Closes a resolved case once every dependency is satisfied.',
    subjects: [CASE], resolved: [VERSION('caseId')],
    fields: [
      { key: 'resolutionCode', label: 'Resolution code', input: 'text', maxLength: 100 },
      { key: 'effectEvidenceVersionId', label: 'Closure evidence', input: 'select', provider: 'caseDocuments' },
    ],
  },
  {
    kind: 'case.reopen', task: 'T071', module: 'cases', title: 'Reopen case',
    summary: 'Reopens a closed case with evidence and a recorded basis.',
    subjects: [CASE], resolved: [VERSION('caseId')],
    fields: [
      { key: 'evidenceVersionId', label: 'Reopening evidence', input: 'select', provider: 'caseDocuments' },
      { key: 'reopeningBasis', label: 'Basis', input: 'text', maxLength: 200 },
      { key: 'dueAt', label: 'New due time', input: 'instant', optional: true },
    ],
  },
  {
    kind: 'case.subject.correct', task: 'T072', module: 'cases', title: 'Correct case subject',
    summary: 'Repairs a case opened against the wrong member or account; needs approval.',
    subjects: [CASE], resolved: [VERSION('caseId')], approval: true,
    fields: [
      { key: 'correctMemberId', label: 'Correct member', input: 'ref', ref: 'member' },
      { key: 'correctAccountId', label: 'Correct account', input: 'ref', ref: 'account', nullable: true },
      { key: 'evidenceVersionId', label: 'Evidence', input: 'select', provider: 'caseDocuments' },
      { key: 'approvalId', label: 'Approval', input: 'select', provider: 'myApprovals', optional: true },
    ],
  },
  {
    kind: 'maintenance.draft.save', task: 'T085', module: 'maintenance', title: 'Save maintenance draft',
    summary: 'Saves a durable maintenance request draft with its requested change and missing fields.',
    subjects: [MEMBER], resolved: [],
    fields: [
      { key: 'accountId', label: 'Related account', input: 'select', provider: 'memberAccounts', nullable: true },
      { key: 'category', label: 'Category', input: 'select', choices: [
        { value: 'account-servicing', label: 'Account servicing' }, { value: 'address-evidence', label: 'Address evidence' },
        { value: 'contact-evidence', label: 'Contact evidence' }, { value: 'statement-copy', label: 'Statement copy' },
        { value: 'transaction-inquiry', label: 'Transaction inquiry' }, { value: 'fee-inquiry', label: 'Fee inquiry' },
        { value: 'complaint', label: 'Complaint' }, { value: 'general', label: 'General servicing' },
      ] },
      { key: 'subject', label: 'Subject', input: 'text', maxLength: 200 },
      { key: 'requestedCommand', label: 'Requested change', input: 'subcommand' },
      { key: 'missingFields', label: 'Missing fields', input: 'lines', help: 'Information still needed before submission.' },
      { key: 'note', label: 'Draft note', input: 'text', optional: true },
      { key: 'evidenceDocumentVersionIds', label: 'Evidence documents', input: 'multiselect', provider: 'memberDocuments', optional: true },
    ],
  },
  {
    kind: 'maintenance.draft.amend', task: 'T086', module: 'maintenance', title: 'Amend maintenance draft',
    summary: 'Patches a saved draft\'s subject, note, requested change or evidence.',
    subjects: [REQUEST], resolved: [UPDATED_AT], patchKey: 'patch',
    fields: [
      { key: 'subject', label: 'Subject', input: 'text', optional: true, maxLength: 200 },
      { key: 'reason', label: 'Reason', input: 'text', optional: true, nullable: true },
      { key: 'note', label: 'Draft note', input: 'text', optional: true },
      { key: 'requestedCommand', label: 'Requested change', input: 'subcommand', optional: true },
      { key: 'missingFields', label: 'Missing fields', input: 'lines', optional: true },
      { key: 'evidenceVersionId', label: 'Evidence version', input: 'ref', ref: 'document-version', optional: true },
      { key: 'evidenceDocumentVersionIds', label: 'Evidence documents', input: 'lines', optional: true },
    ],
  },
  {
    kind: 'maintenance.request.submit', task: 'T087', module: 'maintenance', title: 'Submit maintenance request',
    summary: 'Submits a complete draft for supervisory review.',
    subjects: [REQUEST], resolved: [UPDATED_AT], fields: [], constants: { declaredState: 'submitted' },
  },
  {
    kind: 'maintenance.request.withdraw', task: 'T088', module: 'maintenance', title: 'Withdraw maintenance request',
    summary: 'Withdraws a draft or submitted request with a reason.',
    subjects: [REQUEST], resolved: [UPDATED_AT],
    fields: [{ key: 'reason', label: 'Reason', input: 'text', maxLength: 500 }],
  },
  {
    kind: 'maintenance.request.review', task: 'T087', module: 'maintenance', title: 'Review maintenance request',
    summary: 'Supervisory review: approve, reject or return a submitted request for information.',
    subjects: [REQUEST], resolved: [UPDATED_AT],
    fields: [
      { key: 'decision', label: 'Decision', input: 'select', choices: ['approve', 'reject', 'return-for-information'] },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      { key: 'missingFields', label: 'Missing fields', input: 'lines', optional: true },
    ],
  },
  {
    kind: 'maintenance.request.process', task: 'T087', module: 'maintenance', title: 'Process maintenance request',
    summary: 'Applies or rejects an approved request, recording the applied receipt for audit.',
    subjects: [REQUEST], resolved: [UPDATED_AT],
    fields: [
      { key: 'disposition', label: 'Disposition', input: 'select', choices: ['apply', 'reject'] },
      { key: 'reason', label: 'Reason', input: 'text', maxLength: 500 },
      { key: 'appliedReceiptId', label: 'Applied receipt', input: 'ref', ref: 'receipt', optional: true, help: 'Required when applying: the receipt of the already committed change.' },
    ],
  },
  {
    kind: 'document.annotation.update', task: 'T093', module: 'documents', title: 'Annotate document',
    summary: 'Creates, amends or removes a page annotation on a document version.',
    subjects: [{ key: 'documentVersionId', label: 'Document version', ref: 'document-version' }], resolved: [],
    fields: [
      { key: 'annotationId', label: 'Annotation', input: 'select', provider: 'documentAnnotations', optional: true, help: 'Pick an existing annotation to amend or remove; blank creates one.' },
      { key: 'pageNumber', label: 'Page', input: 'integer' },
      { key: 'regionMicros', label: 'Region (micro-units)', input: 'region' },
      { key: 'action', label: 'Action', input: 'select', choices: ['create', 'amend', 'remove'] },
      { key: 'text', label: 'Annotation text', input: 'textarea', optional: true },
      { key: 'expectedAnnotationFingerprint', label: 'Current fingerprint', input: 'text', optional: true, help: 'Required for amend or remove; shown on the document annotation list.' },
    ],
  },
  {
    kind: 'document.metadata.update', task: 'T094', module: 'documents', title: 'Update document metadata',
    summary: 'Changes a document\'s type, name, owner, account link or retention class. Ownership changes need approval.',
    subjects: [{ key: 'documentId', label: 'Document', ref: 'document' }],
    resolved: [{ key: 'expectedMetadata', resolver: { of: 'documentMetadata', subject: 'documentId' } }],
    fields: [
      { key: 'documentType', label: 'Document type', input: 'select', choices: [...DOCUMENT_TYPES] },
      { key: 'displayName', label: 'Display name', input: 'text', maxLength: 200 },
      { key: 'ownerPartyId', label: 'Owner member', input: 'ref', ref: 'member', as: 'partyId', help: 'Enter the member whose party owns the document.' },
      { key: 'accountId', label: 'Related account', input: 'ref', ref: 'account', nullable: true },
      { key: 'retentionClass', label: 'Retention class', input: 'select', choices: ['standard', 'financial-seven-years', 'legal-hold'] },
      { key: 'approvalId', label: 'Approval', input: 'select', provider: 'myApprovals', optional: true, help: 'Required only when the owner or account association changes.' },
    ],
  },
  {
    kind: 'communication.preference.update', task: 'T095', module: 'servicing', title: 'Update communication preference',
    summary: 'Enables or disables a communication purpose and channel for the member.',
    subjects: [MEMBER_CTX],
    resolved: [{ key: 'partyId', resolver: { of: 'memberParty', subject: 'memberId' } }],
    fields: [
      { key: 'purpose', label: 'Purpose', input: 'select', choices: [...CONSENT_PURPOSES] },
      { key: 'channel', label: 'Channel', input: 'select', choices: [...COMM_CHANNELS] },
      { key: 'state', label: 'State', input: 'select', choices: ['enabled', 'disabled'] },
    ],
  },
  {
    kind: 'communication.send', task: 'T096', module: 'servicing', title: 'Send communication',
    summary: 'Queues a member communication for delivery on a channel with its document.',
    subjects: [MEMBER_CTX],
    resolved: [{ key: 'partyId', resolver: { of: 'memberParty', subject: 'memberId' } }],
    fields: [
      { key: 'channel', label: 'Channel', input: 'select', choices: [...COMM_CHANNELS] },
      { key: 'destination', label: 'Destination', input: 'text', optional: true, help: 'Electronic delivery address; leave blank when using an address destination.' },
      { key: 'addressDestinationId', label: 'Address destination', input: 'select', provider: 'memberDestinations', optional: true },
      { key: 'purpose', label: 'Purpose', input: 'select', choices: [...CONSENT_PURPOSES] },
      { key: 'documentVersionId', label: 'Document', input: 'select', provider: 'memberDocuments' },
      { key: 'jobId', label: 'Existing job', input: 'text', optional: true },
    ],
  },
  {
    kind: 'communication.delivery.update', task: 'T096', module: 'servicing', title: 'Update delivery state',
    summary: 'Records the delivery outcome for a queued communication job.',
    subjects: [MEMBER_CTX], resolved: [],
    fields: [
      { key: 'jobId', label: 'Communication job', input: 'select', provider: 'memberCommunicationJobs' },
      { key: 'expectedState', label: 'Expected state', input: 'select', choices: ['queued', 'accepted'] },
      { key: 'action', label: 'Delivery action', input: 'select', choices: ['accept', 'deliver', 'bounce', 'cancel'] },
      { key: 'detail', label: 'Detail', input: 'text', maxLength: 500 },
    ],
  },
];
