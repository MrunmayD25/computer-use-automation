# Vendor portal (shared package)

`@computer-use/vendor-portal` is the shared, branding-agnostic application package for the
white-label family. It is not a standalone application: a deployment package (currently
`environments/white-label-classic`) supplies branding, port selection, and the operator list.

## What it provides

- `createVendorPortal(options)` — an Express application bound to an open `FinancialStore`.
- `startVendorPortal(app, host, port)` — listener helper.
- Declarative operation registry (`src/registry*.ts`) covering every service command kind,
  split into core, servicing, finance, and approval/maintenance entries.
- A multi-page engine (`src/engine.ts`): select subject -> fill form -> review terms ->
  commit once -> durable receipt, with an independent-approval step for approval-required
  operations.
- Query-backed list/detail pages (`src/pages.ts`) for members, accounts, cases, documents,
  finance records, receipts, approvals, saved searches, maintenance, and reconciliation.
- Classic HTML helpers (`src/html.ts`, `src/render.ts`, `static/classic.css`) shared by
  deployments that want the fixed-width branch-console presentation.

## Contracts

- The shared financial database stays authoritative for business state, permissions,
  reviews, receipts, and reconciliation. The portal resolves references, versions, and
  fingerprints from the authoritative store at form load and re-checks them on commit.
- Commands are validated by `validateServiceCommand` before review; the registry-shape test
  synthesizes a command for every registered operation and asserts validator completeness.
- Approval-required commands reach review without an approval id (the service decline is
  shown alongside the approval-request panel); the assigned checker decides on the
  Approvals page and then executes the command with the approval id.

## Test

```sh
npm run typecheck && npm run lint && npm run build && npm test
```

Tests seed a disposable copy of the template world; they never touch the demonstration
database.
