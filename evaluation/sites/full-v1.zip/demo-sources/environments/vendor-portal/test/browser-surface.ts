import { expect, test, type Page } from '@playwright/test';

import { OPERATIONS } from '../src/index.js';

async function signOn(page: Page): Promise<void> {
  await page.goto('/signon');
  await page.locator('select[name="actorNumber"]').selectOption('OP0002');
  await page.getByRole('button', { name: 'Sign on' }).click();
  await expect(page).toHaveURL(/\/$/u);
}

/** Shared browser contract for the classic and modern vendor deployments. */
export function registerVendorPortalSurfaceTests(): void {
  test('every registered business operation has a visible deployment entry path', async ({ page }) => {
    await signOn(page);
    expect(OPERATIONS.length).toBeGreaterThanOrEqual(100);
    for (const operation of OPERATIONS) {
      await page.goto(`/op/${operation.kind}`);
      await expect(page.locator('h1')).toBeVisible();
      await expect(page.locator('form')).toBeVisible();
    }
  });

  test('validation is visible and the operation remains recoverable', async ({ page }) => {
    await signOn(page);
    await page.goto('/op/member.note.add');
    await page.locator('[name="subject[memberId]"]').fill('northstar-member-1');
    await page.getByRole('button', { name: /Continue|Select/iu }).click();
    await page.getByRole('button', { name: /Review/iu }).click();
    await expect(page.locator('.errors')).toContainText(/required|attention/iu);
    await expect(page.locator('textarea[name="f[text]"]')).toBeVisible();
  });

  test('a note commits through review and its durable receipt is recoverable', async ({ page }) => {
    await signOn(page);
    await page.goto('/op/member.note.add');
    await page.locator('[name="subject[memberId]"]').fill('northstar-member-1');
    await page.getByRole('button', { name: /Continue|Select/iu }).click();
    await page.locator('textarea[name="f[text]"]').fill('Vendor deployment browser evidence note');
    await page.locator('select[name="f[visibility]"]').selectOption('general');
    await page.getByRole('button', { name: /Review/iu }).click();
    await page.getByRole('button', { name: /Commit/iu }).click();
    const receiptLink = page.locator('a[href^="/receipt/"]');
    await expect(receiptLink).toBeVisible();
    const receiptHref = await receiptLink.getAttribute('href');
    expect(receiptHref).toMatch(/^\/receipt\/RCP/u);
    await page.goto(receiptHref ?? '/receipts');
    await expect(page.locator('body')).toContainText('member.note.add');
  });

  test('a concurrent update makes the older review visibly stale', async ({ browser }) => {
    const first = await browser.newPage();
    const second = await browser.newPage();
    await signOn(first);
    await signOn(second);
    const prepare = async (page: Page, preferredName: string): Promise<void> => {
      await page.goto('/op/member.preferred_name.update');
      await page.locator('[name="subject[memberId]"]').fill('northstar-member-1');
      await page.getByRole('button', { name: /Continue|Select/iu }).click();
      await page.locator('[name="f[preferredName]"]').fill(preferredName);
      await page.locator('[name="f[communicationScope]"]').selectOption('all');
      await page.getByRole('button', { name: /Review/iu }).click();
      await expect(page).toHaveURL(/\/review/u);
    };
    const stamp = String(Date.now());
    await prepare(first, `First update ${stamp}`);
    await prepare(second, `Stale update ${stamp}`);
    await first.getByRole('button', { name: /Commit/iu }).click();
    await second.getByRole('button', { name: /Commit/iu }).click();
    await expect(second.locator('body')).toContainText(/stale|changed|re-review/iu);
    await first.close();
    await second.close();
  });
}
