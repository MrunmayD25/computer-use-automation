import { describe, expect, it } from 'vitest';

import { validateServiceCommand } from '@computer-use/financial-database/services';

import { OPERATIONS, OPERATION_COUNT } from '../src/registry.js';
import type { FieldSpec, OperationSpec, ResolvedSpec } from '../src/spec.js';

/** Produces a validator-shaped value for a field, mirroring buildCommand's parse output. */
function synthField(field: FieldSpec): unknown {
  switch (field.input) {
    case 'integer': return 1;
    case 'boolean': return true;
    case 'money': case 'signedMoney': return { minorUnits: 1000, currency: 'USD' };
    case 'multiselect': return ['a'];
    case 'lines': return ['a'];
    case 'address': return { line1: '1 Main St', line2: null, city: 'Portsmouth', region: 'NH', postalCode: '03801', country: 'US' };
    case 'bytes': return new Uint8Array([115, 121, 110]);
    case 'region': return { x: 0, y: 0, width: 10, height: 10 };
    case 'owners': return [{ memberId: 'm1', ownershipBps: 5000, isControlPerson: false, evidenceId: 'e1' }];
    case 'excerpts': return [{ sourceVersionId: 'v1', text: 'excerpt' }];
    case 'partylist': return ['party-x'];
    case 'savedSearchDef': return { entity: 'members', filters: {}, sort: [], columns: ['memberNumber'] };
    case 'subcommand': return { kind: 'member.note.add', memberId: 'x', visibility: 'general', text: 'note' };
    case 'select': return field.choices?.[0] === undefined ? 'x' : (typeof field.choices[0] === 'string' ? field.choices[0] : field.choices[0].value);
    default: return 'x';
  }
}

/** Produces the resolved-concurrency value buildCommand would merge in. */
function synthResolved(resolved: ResolvedSpec): Record<string, unknown> {
  switch (resolved.resolver.of) {
    case 'version': case 'memberVersion': return { [resolved.key]: 1 };
    case 'recordField': return { [resolved.key]: resolved.resolver.field === 'version' ? 1 : 'x' };
    case 'mergeFacts': return { sourceMemberId: 'm1', targetMemberId: 'm2', expectedInventoryFingerprint: 'fp', expectedSourceVersion: 1, expectedTargetVersion: 1 };
    case 'addressDestination': return { [resolved.key]: null };
    case 'consentChannel': return { [resolved.key]: ['email'] };
    case 'memberParty': case 'caseParty': case 'loanParty': return { [resolved.key]: 'party-x' };
    case 'documentMetadata': return { [resolved.key]: { ownerPartyId: 'p1', accountId: null, documentType: 'statement', displayName: 'Doc', retentionClass: 'standard' } };
    case 'requestUpdatedAt': return { [resolved.key]: '2026-01-01T00:00:00Z' };
    case 'savedSearchRevision': return { [resolved.key]: 'rev' };
    default: return { [resolved.key]: 'fp' };
  }
}

const OVERRIDES: Record<string, Record<string, unknown>> = {
  'communication.send': { channel: 'mail', destination: undefined, addressDestinationId: 'dest-1', jobId: undefined },
};

function synthCommand(spec: OperationSpec): Record<string, unknown> {
  let command: Record<string, unknown> = { kind: spec.kind };
  if (spec.constants !== undefined) Object.assign(command, spec.constants);
  for (const subject of spec.subjects) if (subject.intoCommand !== false) command[subject.key] = 'x';
  const target = spec.patchKey === undefined ? command : (command[spec.patchKey] = {});
  for (const field of spec.fields) target[field.key] = synthField(field);
  for (const resolved of spec.resolved) Object.assign(command, synthResolved(resolved));
  for (const [key, value] of Object.entries(OVERRIDES[spec.kind] ?? {})) {
    if (value === undefined) command = Object.fromEntries(Object.entries(command).filter(([name]) => name !== key));
    else command[key] = value;
  }
  return command;
}

describe('operation registry', () => {
  it(`covers ${String(OPERATION_COUNT)} operations`, () => {
    expect(OPERATIONS.length).toBe(OPERATION_COUNT);
    expect(new Set(OPERATIONS.map((spec) => spec.kind)).size).toBe(OPERATION_COUNT);
  });

  it.each(OPERATIONS.map((spec) => [spec.kind, spec] as const))('%s builds a validator-complete command', (_kind, spec) => {
    const command = synthCommand(spec);
    const issues = validateServiceCommand(command);
    expect(issues ?? [], `${spec.kind}: ${JSON.stringify(issues)} on ${JSON.stringify(command)}`).toEqual([]);
  });
});
