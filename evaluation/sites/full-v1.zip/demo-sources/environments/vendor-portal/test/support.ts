import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';
import { inject } from 'vitest';

import { createVendorPortal } from '../src/server.js';
import { startVendorPortal } from '../src/start.js';

export interface TestPortal {
  path: string;
  bindings: readonly DatasetBinding[];
  origin: string;
  directory: string;
  query: <T>(sql: string, ...params: SQLInputValue[]) => T[];
  exec: (sql: string, ...params: SQLInputValue[]) => void;
  datasetId: (institutionId: string) => string;
  operator: (actorNumber: string, bindingIndex?: number) => PortalClient;
  close: () => void;
}

export interface PortalClient {
  get: (path: string) => Promise<{ status: number; body: string }>;
  post: (path: string, fields: Record<string, string | readonly string[]>) => Promise<{ status: number; body: string; location: string | null }>;
}

export function startTestPortal(): Promise<TestPortal> {
  const directory = mkdtempSync(join(tmpdir(), 'vendor-portal-'));
  const path = join(directory, 'financial.sqlite');
  copyFileSync(inject('templatePath'), path);
  const bindings = inject('templateBindings');
  const store = openFinancialStore({ path });
  const portal = createVendorPortal({
    store,
    bindings,
    operators: ['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0007'],
    branding: { productName: 'Test Classic', institutionName: 'Test Institution', tagline: 'test', accent: '#234' },
    adminToken: 'test-admin',
  });
  return startVendorPortal(portal, '127.0.0.1', 0).then((started) => {
    const operator = (_actorNumber: string, _bindingIndex = 0): PortalClient => {
      let cookie = '';
      const send = async (method: string, target: string, fields?: Record<string, string | readonly string[]>) => {
        const body = fields === undefined ? undefined : (() => {
          const params = new URLSearchParams();
          for (const [key, value] of Object.entries(fields)) {
            if (typeof value === 'string') params.append(key, value);
            else for (const item of value) params.append(key, item);
          }
          return params;
        })();
        const response = await fetch(`${started.origin}${target}`, {
          method, redirect: 'manual',
          ...(body === undefined ? {} : { body }),
          headers: { ...(cookie === '' ? {} : { cookie }) },
        });
        const set = response.headers.get('set-cookie');
        if (set !== null) cookie = set.split(';')[0] ?? '';
        return { status: response.status, body: await response.text(), location: response.headers.get('location') };
      };
      return {
        get: (target) => send('GET', target),
        post: (target, fields) => send('POST', target, fields),
      };
    };
    const portal_: TestPortal = {
      path, bindings, directory,
      get origin() { return started.origin; },
      query<T>(sql: string, ...params: SQLInputValue[]): T[] {
        using database = new DatabaseSync(path, { readOnly: true });
        return database.prepare(sql).all(...params) as T[];
      },
      exec(sql: string, ...params: SQLInputValue[]): void {
        const database = new DatabaseSync(path);
        try { database.prepare(sql).run(...params); } finally { database.close(); }
      },
      datasetId(institutionId) {
        const binding = bindings.find((item) => item.institutionId === institutionId);
        if (binding === undefined) throw new Error(`No ${institutionId} binding.`);
        return binding.datasetId;
      },
      operator,
      close: () => { started.server.close(); store.close(); rmSync(directory, { recursive: true, force: true }); },
    };
    return portal_;
  });
}

/** Signs the client on; returns the client for chaining. */
export async function signOn(client: PortalClient, actorNumber: string, bindingIndex = 0): Promise<PortalClient> {
  const response = await client.post('/signon', { actorNumber, binding: String(bindingIndex) });
  if (response.status !== 303) throw new Error(`Sign-on failed with ${String(response.status)}: ${response.body.slice(0, 400)}`);
  return client;
}
