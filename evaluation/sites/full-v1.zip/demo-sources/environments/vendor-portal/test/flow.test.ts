import { afterEach, describe, expect, it } from 'vitest';

import { signOn, startTestPortal, type TestPortal } from './support.js';

let portal: TestPortal | undefined;
afterEach(() => { portal?.close(); portal = undefined; });

describe('classic multi-page operation flow', () => {
  it('creates a member through the visible form and persists its canonical identity', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.get('/op/member.create');
    const form = selected.body.match(/\/op\/member\.create\/form\?flow=[0-9a-f]+/)?.[0] ?? '';
    expect(form).toContain('/op/member.create/form?flow=');
    const reviewed = await client.post(form.replace('/form?', '/review?'), {
      'f[legalGiven]': 'Avery', 'f[legalFamily]': 'North', 'f[birthDate]': '1988-04-12',
      'f[email]': 'avery.north@example.test', 'f[phone]': '555-0108',
      'f[address][line1]': '8 Main Street', 'f[address][city]': 'Madison', 'f[address][region]': 'WI', 'f[address][postalCode]': '53703', 'f[address][country]': 'US',
    });
    const flow = form.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    expect(reviewed.status).toBe(303);
    const commit = await client.post(`/op/member.create/commit?flow=${flow}`, {});
    const result = await client.get(commit.location ?? '');
    expect(result.body).toContain('Committed');
    const rows = portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM members WHERE dataset_id=? AND id LIKE ?', portal.datasetId('northstar'), 'northstar-member-%');
    expect(rows[0]?.count).toBeGreaterThan(10);
  });

  it('opens an account and transfers exact funds between eligible accounts', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.post('/op/account.open/select', { 'subject[memberId]': 'northstar-member-1' });
    const form = selected.location ?? '';
    const flow = form.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/account.open/review?flow=${flow}`, { 'f[productId]': 'northstar-product-USD-checking', 'f[nickname]': 'New checking', 'f[statementDelivery]': 'paper' });
    const commit = await client.post(`/op/account.open/commit?flow=${flow}`, {});
    expect((await client.get(commit.location ?? '')).body).toContain('Committed');

    await client.post('/signon', { actorNumber: 'OP0003', binding: '0' });
    const sourceBefore = portal.query<{ available: number }>('SELECT available_balance_minor_units AS available FROM account_balances WHERE dataset_id=? AND account_id=?', portal.datasetId('northstar'), 'northstar-account-1')[0]?.available ?? 0;
    const destinationBefore = portal.query<{ available: number }>('SELECT available_balance_minor_units AS available FROM account_balances WHERE dataset_id=? AND account_id=?', portal.datasetId('northstar'), 'northstar-account-2')[0]?.available ?? 0;
    const transfer = await client.post('/op/transfer.internal/select', { 'subject[sourceAccountId]': 'northstar-account-1', 'subject[destinationAccountId]': 'northstar-account-2' });
    const transferFlow = transfer.location?.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/transfer.internal/review?flow=${transferFlow}`, { 'f[amount][amount]': '1.25', 'f[amount][currency]': 'USD', 'f[description]': 'Branch transfer' });
    const transferCommit = await client.post(`/op/transfer.internal/commit?flow=${transferFlow}`, {});
    expect((await client.get(transferCommit.location ?? '')).body).toContain('Committed');
    const sourceAfter = portal.query<{ available: number }>('SELECT available_balance_minor_units AS available FROM account_balances WHERE dataset_id=? AND account_id=?', portal.datasetId('northstar'), 'northstar-account-1')[0]?.available ?? 0;
    const destinationAfter = portal.query<{ available: number }>('SELECT available_balance_minor_units AS available FROM account_balances WHERE dataset_id=? AND account_id=?', portal.datasetId('northstar'), 'northstar-account-2')[0]?.available ?? 0;
    expect(sourceAfter).toBe(sourceBefore - 125);
    expect(destinationAfter).toBe(destinationBefore + 125);
  });

  it('opens a servicing case and appends a durable case note', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.post('/op/case.open/select', { 'subject[memberId]': 'northstar-member-1' });
    const form = selected.location ?? '';
    const flow = form.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/case.open/review?flow=${flow}`, {
      'f[queueId]': 'northstar-queue-1', 'f[category]': 'general', 'f[priority]': 'normal', 'f[summary]': 'Branch follow-up', 'f[dueDate]': '2026-10-01',
      'n[accountId]': 'on', 'n[assignedActorId]': 'on',
    });
    const commit = await client.post(`/op/case.open/commit?flow=${flow}`, {});
    expect((await client.get(commit.location ?? '')).body).toContain('Committed');
    const newCase = portal.query<{ id: string }>('SELECT id FROM cases WHERE dataset_id=? AND summary=? ORDER BY opened_at DESC LIMIT 1', portal.datasetId('northstar'), 'Branch follow-up')[0];
    expect(newCase?.id).toBeTruthy();

    const noteSelect = await client.post('/op/case.note.add/select', { 'subject[caseId]': newCase?.id ?? '' });
    const noteFlow = noteSelect.location?.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/case.note.add/review?flow=${noteFlow}`, { 'f[visibility]': 'general', 'f[text]': 'Customer contacted by branch.' });
    const noteCommit = await client.post(`/op/case.note.add/commit?flow=${noteFlow}`, {});
    expect((await client.get(noteCommit.location ?? '')).body).toContain('Committed');
  });

  it('creates a beneficiary with an explicit allowed rail and durable route', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    await client.post('/signon', { actorNumber: 'OP0003', binding: '0' });
    const selected = await client.post('/op/beneficiary.create/select', { 'subject[memberId]': 'northstar-member-1' });
    const form = selected.location ?? '';
    const flow = form.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/beneficiary.create/review?flow=${flow}`, {
      'f[displayName]': 'Branch Utility', 'f[routingKind]': 'ach', 'f[maskedDestination]': '****7788', 'f[simulatedToken]': 'token-branch-utility', 'f[allowedRails][]': 'ach',
    });
    const commit = await client.post(`/op/beneficiary.create/commit?flow=${flow}`, {});
    expect((await client.get(commit.location ?? '')).body).toContain('Committed');
    const rows = portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM beneficiaries WHERE dataset_id=? AND display_name=?', portal.datasetId('northstar'), 'Branch Utility');
    expect(rows[0]?.count).toBe(1);
    const route = portal.query<{ status: string }>('SELECT status FROM beneficiary_routes WHERE dataset_id=? AND masked_destination=?', portal.datasetId('northstar'), '****7788')[0];
    expect(route?.status).toBe('unverified');
  });

  it('creates a draft payment against a verified beneficiary route', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    await client.post('/signon', { actorNumber: 'OP0003', binding: '0' });
    const calendar = portal.query<{ localDate: string; version: string; cutoff: string }>('SELECT local_date AS localDate, calendar_version AS version, payment_cutoff_at AS cutoff FROM calendar_days WHERE dataset_id=? AND is_business_day=1 AND local_date >= \'2026-09-20\' ORDER BY local_date LIMIT 1', portal.datasetId('northstar'))[0];
    expect(calendar).toBeTruthy();
    const source = portal.query<{ id: string }>('SELECT a.id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN beneficiaries b ON b.dataset_id=m.dataset_id AND b.owner_party_id=m.party_id JOIN beneficiary_routes r ON r.dataset_id=b.dataset_id AND r.beneficiary_id=b.id WHERE a.dataset_id=? AND r.id=? AND a.status=\'open\' LIMIT 1', portal.datasetId('northstar'), 'northstar-beneficiary-route-2')[0];
    expect(source).toBeTruthy();
    const selected = await client.post('/op/payment.create/select', { 'subject[sourceAccountId]': source?.id ?? '' });
    const flow = selected.location?.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/payment.create/review?flow=${flow}`, {
      'f[beneficiaryRouteId]': 'northstar-beneficiary-route-2',
      'f[amount][amount]': '2.50', 'f[amount][currency]': 'USD',
      'f[requestedDate]': calendar?.localDate ?? '', 'f[calendarVersion]': calendar?.version ?? '',
      'f[cutoffAt]': calendar?.cutoff ?? '', 'f[reference]': 'Branch draft payment', 'f[targetState]': 'draft',
    });
    const commit = await client.post(`/op/payment.create/commit?flow=${flow}`, {});
    expect((await client.get(commit.location ?? '')).body).toContain('Committed');
    const payment = portal.query<{ state: string; amount: number }>('SELECT state, amount_minor_units AS amount FROM payments WHERE dataset_id=? AND reference=?', portal.datasetId('northstar'), 'Branch draft payment')[0];
    expect(payment).toEqual({ state: 'draft', amount: 250 });
  });

  it('submits a draft payment and records pending approval with a reservation', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    await client.post('/signon', { actorNumber: 'OP0003', binding: '0' });
    const draft = portal.query<{ id: string; version: number }>('SELECT p.id,p.version FROM payments p JOIN beneficiary_routes r ON r.dataset_id=p.dataset_id AND r.id=p.beneficiary_route_id JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id WHERE p.dataset_id=? AND p.state=\'draft\' AND r.status=\'verified\' AND b.status=\'active\' AND r.expires_at>\'2026-09-19T00:00:00.000Z\' ORDER BY p.id LIMIT 1', portal.datasetId('northstar'))[0];
    expect(draft).toBeTruthy();
    const selected = await client.post('/op/payment.submit/select', { 'subject[paymentId]': draft?.id ?? '' });
    expect(selected.location).toContain('/op/payment.submit/form?flow=');
    const flow = selected.location?.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/payment.submit/review?flow=${flow}`, {});
    const commit = await client.post(`/op/payment.submit/commit?flow=${flow}`, {});
    expect((await client.get(commit.location ?? '')).body).toContain('Committed');
    const row = portal.query<{ state: string; version: number }>('SELECT state,version FROM payments WHERE dataset_id=? AND id=?', portal.datasetId('northstar'), draft?.id ?? '')[0];
    const reservation = portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM reservations WHERE dataset_id=? AND payment_id=? AND status=\'active\'', portal.datasetId('northstar'), draft?.id ?? '')[0];
    expect(row?.state).toBe('pending-approval');
    expect(row?.version).toBe((draft?.version ?? 0) + 1);
    expect(reservation?.count).toBe(1);
  });

  it('cancels a draft payment and records an accepted cancellation request', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    await client.post('/signon', { actorNumber: 'OP0003', binding: '0' });
    const draft = portal.query<{ id: string }>('SELECT id FROM payments WHERE dataset_id=? AND state=\'draft\' ORDER BY id LIMIT 1', portal.datasetId('northstar'))[0];
    expect(draft).toBeTruthy();
    const selected = await client.post('/op/payment.cancel/select', { 'subject[paymentId]': draft?.id ?? '' });
    const form = selected.location ?? '';
    const flow = form.match(/flow=([0-9a-f]+)/)?.[1] ?? '';
    await client.post(`/op/payment.cancel/review?flow=${flow}`, { 'f[reason]': 'Member requested cancellation' });
    const commit = await client.post(`/op/payment.cancel/commit?flow=${flow}`, {});
    expect((await client.get(commit.location ?? '')).body).toContain('Committed');
    const row = portal.query<{ state: string }>('SELECT state FROM payments WHERE dataset_id=? AND id=?', portal.datasetId('northstar'), draft?.id ?? '')[0];
    const request = portal.query<{ state: string; reason: string }>('SELECT state,reason FROM payment_cancel_requests WHERE dataset_id=? AND payment_id=? ORDER BY requested_at DESC LIMIT 1', portal.datasetId('northstar'), draft?.id ?? '')[0];
    expect(row?.state).toBe('cancelled');
    expect(request).toEqual({ state: 'accepted', reason: 'Member requested cancellation' });
  });

  it('renders a posted statement and exposes a real CSV artifact download', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const statement = await client.get('/account/northstar-account-1/statement?period=2026-09');
    expect(statement.status).toBe(200);
    expect(statement.body).toContain('Account statement');
    expect(statement.body).toContain('Download CSV');
    const csv = await client.get('/account/northstar-account-1/statement/download?period=2026-09&format=csv');
    expect(csv.status).toBe(200);
    expect(csv.body).toContain('member_number,account_number,currency');
    const missing = await client.get('/account/northstar-account-1/statement?period=2026-13');
    expect(missing.status).toBe(404);
  });

  it('exposes read-only reconciliation inquiries with recoverable validation', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const page = await client.get('/reconciliation/inquiry');
    expect(page.status).toBe(200);
    expect(page.body).toContain('Internal transfer');
    const invalid = await client.get('/reconciliation/inquiry?businessDate=2026-09-13&cashSessionIds=northstar-cash-session-2&declaredMinorUnits=not-number&currency=USD');
    expect(invalid.status).toBe(200);
    expect(invalid.body).toContain('Declared total must be an exact integer');
  });

  it('cancels a details form without reviewing or retaining its draft', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.post('/op/member.note.add/select', { 'subject[memberId]': 'northstar-member-1' });
    const form = selected.location ?? '';
    const cancelled = await client.post(form.replace('/form?', '/review?'), { step: 'cancel' });
    expect(cancelled.location).toBe('/members');
    expect((await client.get(form)).status).toBe(410);
  });

  it('recovers the original receipt when a version-changing commit is retried', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.post('/op/account.nickname.update/select', { 'subject[accountId]': 'northstar-account-1' });
    const form = selected.location ?? '';
    await client.post(form.replace('/form?', '/review?'), { 'f[nickname]': 'Branch reserve' });
    const first = await client.post(form.replace('/form?', '/commit?'), {});
    const original = await client.get(first.location ?? '');
    expect(original.body).toContain('Committed');
    const receipt = /\/receipt\/(RCP\d+)/.exec(original.body)?.[1];
    expect(receipt).toBeTruthy();
    const again = await client.post(form.replace('/form?', '/commit?'), {});
    const recovered = await client.get(again.location ?? '');
    expect(recovered.body).toContain('Already committed');
    expect(recovered.body).toContain(`/receipt/${receipt}`);
  });
  it('requires sign-on and rejects unknown operators', async () => {
    portal = await startTestPortal();
    const anon = portal.operator('OP0002');
    const landing = await anon.get('/members');
    expect(landing.status).toBe(303);
    expect(landing.body).toContain('/signon');

    const bad = await anon.post('/signon', { actorNumber: 'OP9999', binding: '0' });
    expect(bad.status).toBe(403);
    expect(bad.body).toContain('not permitted');
  });

  it('returns a recoverable not-found page for an unknown record', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const response = await client.get('/record/journal/no-such-record');
    expect(response.status).toBe(404);
    expect(response.body).toContain('does not exist');
  });

  it('member.note.add: select → form → review → commit → durable receipt', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');

    const select = await client.get('/op/member.note.add');
    expect(select.status).toBe(200);
    expect(select.body).toContain('subject[memberId]');

    const selected = await client.post('/op/member.note.add/select', { 'subject[memberId]': 'northstar-member-1' });
    expect(selected.status).toBe(303);
    const formUrl = selected.location ?? '';
    expect(formUrl).toContain('/op/member.note.add/form?flow=');

    const form = await client.get(formUrl);
    expect(form.status).toBe(200);
    expect(form.body).toContain('f[text]');
    expect(form.body).toContain('f[visibility]');

    const review = await client.post(formUrl.replace('/form?', '/review?'), { 'f[text]': 'Integration note', 'f[visibility]': 'general' });
    expect(review.status).toBe(303);
    const reviewPage = await client.get(review.location ?? '');
    expect(reviewPage.status).toBe(200);
    expect(reviewPage.body).toContain('Reviewed terms');
    expect(reviewPage.body).toContain('Integration note');

    const commit = await client.post(`/op/member.note.add/commit?flow=${(formUrl.match(/flow=([0-9a-f]+)/) ?? [])[1] ?? ''}`, {});
    expect(commit.status).toBe(303);
    const result = await client.get(commit.location ?? '');
    expect(result.status).toBe(200);
    expect(result.body).toContain('Committed');
    const receipt = /\/receipt\/(RCP\d+)/.exec(result.body)?.[1];
    expect(receipt).toBeTruthy();

    const receiptPage = await client.get(`/receipt/${receipt}`);
    expect(receiptPage.status).toBe(200);
    expect(receiptPage.body).toContain('member.note.add');

    const rows = portal.query<{ member_id: string }>(
      'SELECT member_id FROM member_notes WHERE dataset_id=? AND member_id=?', portal.datasetId('northstar'), 'northstar-member-1');
    expect(rows.length).toBeGreaterThan(0);
  });

  it('keeps posted values on validation failure and shows the field-level issue', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.post('/op/member.note.add/select', { 'subject[memberId]': 'northstar-member-1' });
    const formUrl = selected.location ?? '';
    const review = await client.post(formUrl.replace('/form?', '/review?'), { 'f[text]': '', 'f[visibility]': 'general' });
    expect(review.status).toBe(303);
    const form = await client.get(formUrl);
    expect(form.body).toContain('needs attention');
    expect(form.body).toContain('required');
  });

  it('declines an over-limit withdrawal at review instead of committing', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.post('/op/cash.withdraw/select', { 'subject[accountId]': 'northstar-account-1' });
    const formUrl = selected.location ?? '';
    const flow = (formUrl.match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    await client.post(`/op/cash.withdraw/review?flow=${flow}`, { 'f[amount][amount]': '99999999', 'f[amount][currency]': 'USD', 'f[description]': 'overdraw' });
    const review = await client.get(`/op/cash.withdraw/review?flow=${flow}`);
    expect(review.body).toContain('declined');
    const commit = await client.post(`/op/cash.withdraw/commit?flow=${flow}`, {});
    expect(commit.status).toBe(303);
    const result = await client.get(`/op/cash.withdraw/result?flow=${flow}`);
    expect(result.body).not.toContain('receipt/RCP');
  });

  it('cash.deposit commits and the balance persists for other applications', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const before = portal.query<{ available: number }>(
      'SELECT available_balance_minor_units AS available FROM account_balances WHERE dataset_id=? AND account_id=?',
      portal.datasetId('northstar'), 'northstar-account-1')[0];
    const selected = await client.post('/op/cash.deposit/select', { 'subject[accountId]': 'northstar-account-1' });
    const flow = ((selected.location ?? '').match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    await client.post(`/op/cash.deposit/review?flow=${flow}`, { 'f[amount][amount]': '125.50', 'f[amount][currency]': 'USD', 'f[description]': 'test deposit' });
    const commit = await client.post(`/op/cash.deposit/commit?flow=${flow}`, {});
    const result = await client.get(commit.location ?? '');
    expect(result.body).toContain('Committed');
    const after = portal.query<{ available: number }>(
      'SELECT available_balance_minor_units AS available FROM account_balances WHERE dataset_id=? AND account_id=?',
      portal.datasetId('northstar'), 'northstar-account-1')[0];
    expect(after?.available).toBe((before?.available ?? 0) + 12_550);
  });

  it('repeating a commit returns the same receipt (idempotent)', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const selected = await client.post('/op/member.note.add/select', { 'subject[memberId]': 'northstar-member-1' });
    const flow = ((selected.location ?? '').match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    await client.post(`/op/member.note.add/review?flow=${flow}`, { 'f[text]': 'once', 'f[visibility]': 'general' });
    await client.post(`/op/member.note.add/commit?flow=${flow}`, {});
    const again = await client.post(`/op/member.note.add/commit?flow=${flow}`, {});
    const result = await client.get(again.location ?? '');
    expect(result.body).toContain('Already committed');
  });

  it('signing on again re-binds the session to the new operator visibly', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    await client.post('/signon', { actorNumber: 'OP0005', binding: '0' });
    const home = await client.get('/');
    expect(home.body).toContain('OP0005');
  });

  it('member.legal_name.update: maker requests approval, checker decides and executes', async () => {
    portal = await startTestPortal();
    const maker = await signOn(portal.operator('OP0002'), 'OP0002');
    const dataset = portal.datasetId('northstar');
    const pdf = ['%PDF-1.4', '1 0 obj', '<< /Type /Catalog /Pages 2 0 R >>', 'endobj',
      '2 0 obj', '<< /Type /Pages /Count 1 /Kids [ 3 0 R ] >>', 'endobj',
      '3 0 obj', '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >>', 'endobj',
      '4 0 obj', '<< /Length 44 >>', 'stream', 'BT /F1 12 Tf 72 720 Td (Hello) Tj ET', 'endstream', 'endobj',
      'xref', '0 5', '0000000000 65535 f ', 'trailer', '<< /Size 5 /Root 1 0 R >>', 'startxref', '0', '%%EOF'].join('\n');

    const docSel = await maker.post('/op/document.index/select', { 'subject[memberId]': 'northstar-member-10' });
    const docFlow = ((docSel.location ?? '').match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    await maker.post(`/op/document.index/review?flow=${docFlow}`, {
      'f[documentType]': 'identity-document', 'f[displayName]': 'passport.pdf', 'f[retentionClass]': 'financial-seven-years',
      'f[bytes]': pdf, 'f[source]': 'approved-local-scan', 'f[mediaType]': 'application/pdf', 'f[pageCount]': '1',
    });
    const docCommit = await maker.post(`/op/document.index/commit?flow=${docFlow}`, {});
    const docResult = await maker.get(docCommit.location ?? '');
    expect(docResult.body).toContain('Committed');
    const versionRow = portal.query<{ id: string }>(
      'SELECT id FROM document_versions WHERE dataset_id=? AND document_id LIKE ? ORDER BY id DESC LIMIT 1',
      dataset, 'document-%')[0];
    if (versionRow === undefined) throw new Error('Indexed document version missing.');

    const evSel = await maker.post('/op/member.identity_evidence.register/select', { 'subject[memberId]': 'northstar-member-10' });
    const evFlow = ((evSel.location ?? '').match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    await maker.post(`/op/member.identity_evidence.register/review?flow=${evFlow}`, {
      'f[documentVersionId]': versionRow.id, 'f[evidenceKind]': 'passport',
      'f[issuedAt]': '2024-06-01', 'f[expiresAt]': '2034-06-01', 'f[reference]': 'EV-TEST-1',
    });
    const evCommit = await maker.post(`/op/member.identity_evidence.register/commit?flow=${evFlow}`, {});
    const evResult = await maker.get(evCommit.location ?? '');
    expect(evResult.body).toContain('Committed');
    const evidenceRow = portal.query<{ id: string }>(
      "SELECT id FROM identity_evidence WHERE dataset_id=? AND party_id='northstar-party-person-10' AND status='unverified' AND id LIKE 'identity-evidence-%'", dataset)[0];
    if (evidenceRow === undefined) throw new Error('Registered evidence missing.');

    const verSel = await maker.post('/op/member.identity.verify/select', { 'subject[memberId]': 'northstar-member-10' });
    const verFlow = ((verSel.location ?? '').match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    await maker.post(`/op/member.identity.verify/review?flow=${verFlow}`, { 'f[evidenceId]': evidenceRow.id, 'f[method]': 'document-review' });
    const verCommit = await maker.post(`/op/member.identity.verify/commit?flow=${verFlow}`, {});
    const verResult = await maker.get(verCommit.location ?? '');
    expect(verResult.body).toMatch(/Committed|Already applied/);

    const nameSel = await maker.post('/op/member.legal_name.update/select', { 'subject[memberId]': 'northstar-member-10' });
    const nameFlow = ((nameSel.location ?? '').match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    const fields = {
      'f[legalGiven]': 'Renamed', 'f[legalFamily]': 'Member', 'f[evidenceId]': evidenceRow.id,
    };
    await maker.post(`/op/member.legal_name.update/review?flow=${nameFlow}`, fields);
    const declined = await maker.get(`/op/member.legal_name.update/review?flow=${nameFlow}`);
    expect(declined.body).toContain('declined');
    expect(declined.body).toContain('Request approval');
    expect(declined.body).toContain('northstar-actor-5');

    const request = await maker.post(`/op/member.legal_name.update/request-approval?flow=${nameFlow}`, {
      'a[checkerActorId]': 'northstar-actor-5', 'a[policyVersionId]': 'northstar-policy-1',
      'a[expiresAt]': '2026-09-18T00:00:00Z', 'a[amount]': '', 'a[currency]': 'USD',
    });
    expect(request.status).toBe(303);
    const requestResult = await maker.get(request.location ?? '');
    expect(requestResult.body).toContain('Committed');
    const approvalId = /(approval-[0-9a-f-]{36})/.exec(requestResult.body)?.[1] ?? '';
    expect(approvalId).toMatch(/^approval-/);

    const checker = await signOn(portal.operator('OP0005'), 'OP0005');
    const queue = await checker.get('/approvals');
    expect(queue.body).toContain(approvalId.slice(0, 18));
    const decide = await checker.get(`/approval/${approvalId}/decide`);
    const fingerprint = /name="fingerprint" value="([0-9a-f]+)"/.exec(decide.body)?.[1] ?? '';
    expect(fingerprint).not.toBe('');
    const decided = await checker.post(`/approval/${approvalId}/decide`, {
      decision: 'approve', fingerprint, reason: 'Verified against evidence.',
    });
    expect(decided.body).not.toContain('errors');

    const execSel = await checker.post('/op/member.legal_name.update/select', { 'subject[memberId]': 'northstar-member-10' });
    const execFlow = ((execSel.location ?? '').match(/flow=([0-9a-f]+)/) ?? [])[1] ?? '';
    const execForm = await checker.get(`/op/member.legal_name.update/form?flow=${execFlow}`);
    expect(execForm.body).toContain(approvalId);
    await checker.post(`/op/member.legal_name.update/review?flow=${execFlow}`, {
      ...fields, 's[approvalId]': '1', 'f[approvalId]': approvalId,
    });
    const reviewed = await checker.get(`/op/member.legal_name.update/review?flow=${execFlow}`);
    expect(reviewed.body).toContain('Reviewed terms');
    const execCommit = await checker.post(`/op/member.legal_name.update/commit?flow=${execFlow}`, {});
    const execResult = await checker.get(execCommit.location ?? '');
    expect(execResult.body).toContain('Committed');
    expect(execResult.body).toContain('receipt/RCP');

    const person = portal.query<{ legal_given: string }>(
      "SELECT legal_given FROM people WHERE dataset_id=? AND party_id='northstar-party-person-10'", dataset)[0];
    expect(person?.legal_given).toBe('Renamed');
    const approval = portal.query<{ status: string }>(
      'SELECT status FROM business_approvals WHERE dataset_id=? AND id=?', dataset, approvalId)[0];
    expect(approval?.status).toBe('consumed');
  });
});
