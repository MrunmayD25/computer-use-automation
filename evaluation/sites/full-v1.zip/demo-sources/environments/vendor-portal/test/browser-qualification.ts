import { execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';

import { expect, test, type Locator, type Page } from '@playwright/test';
import { openFinancialDatabase } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';

import { createVendorPortal, OPERATIONS, startVendorPortal } from '../src/index.js';
import type { FieldSpec, OperationSpec, RefKind } from '../src/spec.js';

interface QualificationConfig {
  applicationId: string;
  shardEnvironment: string;
  runEnvironment: string;
  familyMechanism: string;
  familyMarker: string;
}

const REPOSITORY_ROOT = resolve(import.meta.dirname, '..', '..', '..');
const SHARD_SIZE = 12;
const CATALOG = JSON.parse(readFileSync(resolve(REPOSITORY_ROOT, 'evaluation', 'catalog.json'), 'utf8')) as { business_tasks: { id: string; capability: string }[] };
const CATALOG_CAPABILITY = new Map(CATALOG.business_tasks.map((task) => [task.id, task.capability]));

const WORKFLOW_STEPS: Readonly<Record<string, readonly string[]>> = {
  W01: ['member.create', 'account.open', 'cash.deposit'],
  W02: ['member.merge', 'activity.inspect'],
  W03: ['contact.update', 'maintenance.address.reconcile'],
  W04: ['transfer.internal', 'payment.schedule.end', 'account.close'],
  W05: ['beneficiary.create', 'beneficiary.verify', 'payment.create', 'payment.approve_release'],
  W06: ['card.lock.update', 'card.replace', 'dispute.open', 'dispute.provisional_credit.issue'],
  W07: ['loan.payoff.quote', 'loan.payment.allocate', 'loan.close', 'document.loan_closure.issue'],
  W08: ['payment.return.resolve', 'beneficiary.routing.update', 'activity.inspect'],
  W09: ['batch.preview', 'batch.contacts.apply', 'activity.inspect'],
  W10: ['reconciliation.cash_day', 'reconciliation.suspense.investigate', 'case.open'],
  W11: ['member.search', 'account.list', 'account.inquire', 'transaction.search', 'statement.export'],
  W12: ['contact.update', 'account.statement_delivery.update', 'activity.inspect'],
  W13: ['account.inquire', 'cash.deposit', 'transfer.internal', 'cash.withdraw', 'activity.inspect'],
  W14: ['account.list', 'account.open', 'account.nickname.update', 'transfer.internal', 'activity.inspect'],
  W15: ['account.inquire', 'transfer.internal', 'account.close', 'activity.inspect'],
  W16: ['operation.review', 'activity.inspect'],
  W17: ['transfer.internal', 'activity.inspect'],
  W18: ['institution.context.verify', 'transfer.internal', 'activity.inspect', 'account.inquire'],
  W19: ['member.search', 'contact.update', 'account.nickname.update', 'member.note.add'],
  W20: ['operation.review', 'edit.cancel', 'contact.update', 'activity.inspect'],
  W21: ['maintenance.draft.save', 'maintenance.draft.amend', 'maintenance.request.submit', 'activity.inspect'],
  W22: ['document.index', 'document.metadata.update', 'document.annotation.update', 'document.bundle.redact'],
  W23: ['consent.delivery.record', 'consent.withdraw', 'communication.preference.update', 'communication.send'],
  W24: ['payment.schedule.create', 'payment.occurrence.amend', 'payment.schedule.end', 'reconciliation.settlement_batch'],
  W25: ['account.hold.place', 'account.inquire', 'account.hold.release', 'transfer.internal'],
  W26: ['card.lock.update', 'maintenance.address.reconcile', 'card.replace', 'communication.send'],
  W27: ['dispute.open', 'document.index', 'dispute.evidence.submit', 'dispute.provisional_credit.issue', 'dispute.settle'],
  W28: ['account.list', 'account.inquire', 'operation.review', 'account.maturity.instruct'],
  W29: ['institution.context.verify', 'account.inquire', 'contact.update', 'transfer.internal'],
  W30: ['batch.preview', 'batch.contacts.apply', 'activity.inspect', 'case.open', 'case.route'],
};

const INQUIRY_PATHS: Readonly<Record<string, { path: string; expected: string }>> = {
  'account.inquire': { path: '/account/northstar-account-1', expected: 'Posted balance' },
  'member.search': { path: '/members?q=NM000002', expected: 'NM000002' },
  'account.list': { path: '/accounts?member=NM000002', expected: 'AC0000001' },
  'transaction.search': { path: '/account/northstar-account-1?start=2025-01-01&end=2027-01-01', expected: 'Transactions' },
  'activity.inspect': { path: '/activity', expected: 'activity' },
  'statement.export': { path: '/account/northstar-account-1/statement?period=2026-09', expected: 'Statement' },
  'reconciliation.transfer': { path: '/record/transfer/northstar-journal-transfer-1', expected: 'transfer' },
  'reconciliation.settlement_batch': { path: '/record/settlement-batch/northstar-settlement-batch-1', expected: 'settlement' },
  'reconciliation.cash_day': { path: '/reconciliation/inquiry?businessDate=2026-09-12', expected: 'Cash' },
  'institution.context.verify': { path: '/system', expected: 'OP0002' },
};

const STEP_OPERATION_ALIASES: Readonly<Record<string, string>> = {
  'batch.preview': 'batch.import',
  'case.route': 'case.assign',
  'operation.review': 'cash.deposit',
};

const REF_VALUES: Readonly<Record<RefKind, string>> = {
  member: 'northstar-member-2',
  account: 'northstar-account-1',
  case: 'northstar-case-1',
  document: 'northstar-document-notice-1',
  'document-version': 'northstar-document-version-notice-1-1',
  'maintenance-request': 'northstar-maintenance-request-1',
  'saved-search': 'northstar-saved-search-1-private',
  'merge-plan': 'northstar-merge-plan-2',
  'identity-evidence': 'northstar-evidence-2',
  consent: 'northstar-consent-1',
  address: 'northstar-address-2',
  'party-address': 'northstar-party-address-2',
  'address-destination': 'northstar-address-destination-missing',
  'communication-job': 'northstar-communication-job-1',
  annotation: 'northstar-document-annotation-1',
  receipt: 'RC-opening-1',
  beneficiary: 'northstar-beneficiary-1',
  'beneficiary-route': 'northstar-beneficiary-route-old-1',
  payment: 'northstar-payment-1',
  'payment-schedule': 'northstar-payment-schedule-1',
  'schedule-occurrence': 'northstar-schedule-occurrence-1-2',
  'payment-return': 'northstar-payment-return-8',
  card: 'northstar-card-2',
  'card-transaction': 'northstar-card-transaction-2',
  dispute: 'northstar-dispute-1',
  loan: 'northstar-loan-1',
  'interest-calculation': 'northstar-interest-calculation-0',
  fee: 'northstar-fee-2',
  hold: 'northstar-hold-4',
  restriction: 'northstar-restriction-4',
  facility: 'northstar-facility-13',
  'maturity-instruction': 'northstar-maturity-5',
  'received-funds': 'northstar-received-funds-1',
  'settlement-batch': 'northstar-settlement-batch-1',
  'suspense-item': 'northstar-suspense-item-1',
  batch: 'northstar-batch-1',
  'batch-item': 'northstar-batch-item-1-1',
  journal: 'northstar-journal-opening-1',
  transfer: 'northstar-journal-transfer-1',
  transaction: 'northstar-journal-card-purchase-2',
  'loan-closure': 'northstar-loan-closure-4',
  approval: 'northstar-approval-2',
  actor: 'northstar-actor-2',
  party: 'northstar-party-person-2',
  product: 'northstar-product-USD-savings',
  queue: 'northstar-queue-1',
  'policy-version': 'northstar-policy-1',
};

const SUBJECT_OVERRIDES: Readonly<Record<string, Readonly<Record<string, string>>>> = {
  'transfer.internal': { destinationAccountId: 'northstar-account-2' },
  'account.owner.add': { accountId: 'northstar-account-1', memberId: 'northstar-member-3' },
  'account.signer.remove': { accountId: 'northstar-account-4' },
  'account.hold.release': { holdId: 'northstar-hold-4' },
  'account.restriction.release': { restrictionId: 'northstar-restriction-4' },
  'cash.deposit.reverse': { journalId: 'northstar-journal-activity-1-1' },
  'cash.withdrawal.reverse': { journalId: 'northstar-journal-activity-1-1' },
  'transfer.internal.reverse': { transferJournalId: 'northstar-journal-historical-transfer-0' },
  'interest.adjust': { calculationId: 'northstar-interest-calculation-0' },
  'transaction.effective_date.correct': { journalId: 'northstar-journal-activity-1-1' },
  'transaction.description.update': { journalId: 'northstar-journal-activity-1-1' },
  'beneficiary.verify': { beneficiaryRouteId: 'northstar-beneficiary-route-1' },
  'beneficiary.routing.update': { beneficiaryRouteId: 'northstar-beneficiary-route-old-1' },
  'payment.return.resolve': { returnId: 'northstar-payment-return-8' },
  'dispute.open': { cardTransactionId: 'northstar-card-transaction-2' },
  'loan.payment.allocate': { loanId: 'northstar-loan-1' },
  'loan.close': { loanId: 'northstar-loan-4' },
  'document.loan_closure.issue': { loanId: 'northstar-loan-4' },
};

async function signOn(page: Page, actorNumber = 'OP0002', origin = '', binding = '0'): Promise<void> {
  await page.goto(`${origin}/signon`);
  await page.locator('select[name="actorNumber"]').selectOption(actorNumber);
  const institution = page.locator('select[name="binding"]');
  if (await institution.count()) await institution.selectOption(binding);
  await page.getByRole('button', { name: 'Sign on' }).click();
  await expect(page).toHaveURL(new RegExp(`${origin.replaceAll('.', '[.]')}/?$`, 'u'));
}

function textValue(field: FieldSpec, spec: OperationSpec): string {
  const key = field.key.toLowerCase();
  if (key.includes('email')) return `qualification-${spec.task.toLowerCase()}@example.test`;
  if (key.includes('phone')) return '312-555-0198';
  if (key.includes('postal')) return '60601';
  if (key.includes('country')) return 'US';
  if (key.includes('region')) return 'IL';
  if (key.includes('destination')) return 'qualification@example.test';
  if (key.includes('masked')) return '****0198';
  if (key.includes('token')) return `simulated-${spec.task.toLowerCase()}`;
  if (key.includes('reference')) return `QUAL-${spec.task}`;
  if (key.includes('digest')) return '0'.repeat(64);
  if (key.includes('name')) return `Qualification ${spec.task}`;
  if (key.includes('reason') || key.includes('basis') || key.includes('purpose') || key.includes('summary') || key.includes('description') || key.includes('text') || key.includes('note')) return `Visible qualification for ${spec.kind}`;
  if (key.includes('channel')) return 'email';
  if (key.includes('method')) return 'documentary';
  if (key.includes('authority')) return 'risk-operations';
  if (key.includes('code')) return 'QUAL';
  if (key.includes('state')) return 'active';
  return `qualification-${spec.task.toLowerCase()}`;
}

async function chooseFirst(select: Locator): Promise<string | undefined> {
  const values = await optionValues(select);
  if (values[0] === undefined) return undefined;
  await select.selectOption(values[0]);
  return values[0];
}

async function optionValues(select: Locator): Promise<string[]> {
  const values: string[] = [];
  for (const option of await select.locator('option').all()) {
    const value = await option.getAttribute('value');
    if (value !== null && value !== '') values.push(value);
  }
  return values;
}

async function fillField(page: Page, spec: OperationSpec, field: FieldSpec): Promise<void> {
  if (field.optional === true) {
    if (field.key === 'approvalId') return;
    const set = page.locator(`input[name="s[${field.key}]"]`);
    if (await set.count()) await set.check();
  }
  const base = `f[${field.key}]`;
  switch (field.input) {
    case 'text': case 'textarea': case 'lines': case 'bytes':
      await page.locator(`[name="${base}"]`).fill(field.input === 'lines' ? `QUAL-${spec.task}-1\nQUAL-${spec.task}-2` : textValue(field, spec));
      break;
    case 'integer':
      await page.locator(`[name="${base}"]`).fill(field.key === 'effectiveYear' ? '2026' : field.key.toLowerCase().includes('bps') ? '250' : '1');
      break;
    case 'money': case 'signedMoney':
      await page.locator(`[name="${base}[amount]"]`).fill('1.00');
      await page.locator(`[name="${base}[currency]"]`).selectOption('USD');
      break;
    case 'date':
      await page.locator(`[name="${base}"]`).fill(field.key === 'birthDate' ? '1990-01-15' : field.key.toLowerCase().includes('through') || field.key.toLowerCase().includes('end') ? '2026-12-31' : '2026-09-15');
      break;
    case 'instant':
      await page.locator(`[name="${base}"]`).fill(field.key.toLowerCase().includes('expire') ? '2027-09-15T18:00:00Z' : '2026-09-15T18:00:00Z');
      break;
    case 'boolean':
      await page.locator(`[name="${base}"]`).check();
      break;
    case 'select': {
      const select = page.locator(`select[name="${base}"]`);
      if (spec.kind === 'account.statement_delivery.update' && field.key === 'statementDelivery') await select.selectOption('electronic');
      else await chooseFirst(select);
      break;
    }
    case 'multiselect': {
      const select = page.locator(`select[name="${base}[]"]`);
      const values = await optionValues(select);
      if (values[0] !== undefined) await select.selectOption(values[0]);
      break;
    }
    case 'partylist': {
      const select = page.locator(`select[name="${base}[selected][]"]`);
      const values = await optionValues(select);
      if (values[0] !== undefined) await select.selectOption(values[0]);
      else await page.locator(`[name="${base}[extra]"]`).fill('NM000003');
      break;
    }
    case 'address':
      await page.locator(`[name="${base}[line1]"]`).fill('22 Qualification Lane');
      await page.locator(`[name="${base}[city]"]`).fill('Chicago');
      await page.locator(`[name="${base}[region]"]`).fill('IL');
      await page.locator(`[name="${base}[postalCode]"]`).fill('60601');
      await page.locator(`[name="${base}[country]"]`).fill('US');
      break;
    case 'ref':
      await page.locator(`[name="${base}"]`).fill(REF_VALUES[field.ref ?? 'member']);
      break;
    case 'region':
      for (const [part, value] of [['x', '100000'], ['y', '100000'], ['width', '300000'], ['height', '100000']] as const) await page.locator(`[name="${base}[${part}]"]`).fill(value);
      break;
    case 'owners':
      await page.locator(`[name="${base}[0][memberId]"]`).fill('northstar-member-3');
      await page.locator(`[name="${base}[0][ownershipBps]"]`).fill('10000');
      await page.locator(`[name="${base}[0][isControlPerson]"]`).check();
      await chooseFirst(page.locator(`select[name="${base}[0][evidenceId]"]`));
      break;
    case 'excerpts':
      await chooseFirst(page.locator(`select[name="${base}[0][sourceVersionId]"]`));
      await page.locator(`[name="${base}[0][text]"]`).fill('Approved visible excerpt for qualification.');
      break;
    case 'subcommand':
      await page.locator(`select[name="${base}[kind]"]`).selectOption('member.note.add');
      await page.locator(`select[name="${base}[visibility]"]`).selectOption('general');
      await page.locator(`[name="${base}[text]"]`).fill(`Requested change for ${spec.task}`);
      break;
    case 'savedSearchDef':
      await page.locator(`select[name="${base}[entity]"]`).selectOption('members');
      break;
  }
}

async function fillOperation(page: Page, spec: OperationSpec): Promise<{ entry: string; action: string }> {
  await page.goto(`/op/${spec.kind}`);
  const overrides = SUBJECT_OVERRIDES[spec.kind] ?? {};
  for (const subject of spec.subjects) {
    const value = overrides[subject.key] ?? REF_VALUES[subject.ref];
    await page.locator(`[name="subject[${subject.key}]"]`).fill(value);
  }
  if (spec.subjects.length > 0) {
    await page.getByRole('button', { name: /Continue to details/iu }).click();
    await expect(page).toHaveURL(new RegExp(`/op/${spec.kind.replaceAll('.', '[.]')}/form`, 'u'));
  }
  const form = page.locator('form[action*="/review"]');
  await expect(form).toBeVisible();
  const entry = await page.locator('main').innerText();
  for (const field of spec.fields) await fillField(page, spec, field);
  const values: string[] = [];
  for (const control of await form.locator('input, select, textarea').all()) {
    const name = await control.getAttribute('name') ?? '';
    if (name.includes('approvalId')) continue;
    const type = await control.getAttribute('type') ?? '';
    const multiple = await control.getAttribute('multiple') !== null;
    const value = multiple ? (await optionValues(control)).join(',') : type === 'checkbox' ? String(await control.isChecked()) : await control.inputValue();
    values.push(`${name}=${value}`);
  }
  await page.getByRole('button', { name: 'Review change' }).click();
  if (spec.fields.some((field) => field.input === 'savedSearchDef') && /\/form(?:\?|$)/u.test(page.url())) {
    const columns = page.locator('input[name$="[columns][]"]');
    if (await columns.count()) {
      await columns.first().check();
      const sort = page.locator('select[name$="[sortField]"]');
      if (await sort.count()) await chooseFirst(sort);
      await page.getByRole('button', { name: 'Review change' }).click();
    }
  }
  return { entry, action: values.join('; ') };
}

function resultKind(text: string): 'committed' | 'reviewed' | 'refused' {
  if (/\bCommitted\b|Already committed|Already applied/u.test(text)) return 'committed';
  if (/Reviewed terms/u.test(text)) return 'reviewed';
  return 'refused';
}

function actorFor(spec: OperationSpec): string {
  if (spec.kind === 'member.merge') return 'OP0005';
  if (spec.kind === 'transfer.internal' || spec.kind.startsWith('payment.') || spec.kind.startsWith('beneficiary.')
    || spec.kind.startsWith('interest.') || spec.kind.endsWith('.reverse') || spec.kind === 'transaction.effective_date.correct') return 'OP0003';
  return 'OP0002';
}

async function driveWorkflowStep(page: Page, step: string): Promise<string> {
  const inquiry = INQUIRY_PATHS[step];
  if (inquiry !== undefined) {
    await page.goto(inquiry.path);
    const result = await page.locator('main').innerText();
    expect(result).toContain(inquiry.expected);
    return `${step}\n${result}`;
  }
  const kind = STEP_OPERATION_ALIASES[step] ?? step;
  const spec = OPERATIONS.find(candidate => candidate.kind === kind);
  if (spec === undefined) throw new Error(`Workflow step ${step} has no visible operation or inquiry path.`);
  await signOn(page, actorFor(spec));
  const { entry } = await fillOperation(page, spec);
  const result = await page.locator('main').innerText();
  expect(result.trim().length).toBeGreaterThan(0);
  return `${step}\nENTRY\n${entry}\nRESULT\n${result}`;
}

async function preparePreferredName(page: Page, origin: string, value: string): Promise<string> {
  await page.goto(`${origin}/op/member.preferred_name.update`);
  await page.locator('[name="subject[memberId]"]').fill('northstar-member-1');
  await page.getByRole('button', { name: /Continue|Select/iu }).click();
  await page.locator('[name="f[preferredName]"]').fill(value);
  await page.locator('[name="f[communicationScope]"]').selectOption('all');
  const entry = await page.locator('main').innerText();
  await page.getByRole('button', { name: /Review/iu }).click();
  await expect(page).toHaveURL(/\/review/u);
  return entry;
}

async function commitPrepared(page: Page): Promise<string> {
  await page.getByRole('button', { name: /Commit/iu }).click();
  const result = await page.locator('main').innerText();
  expect(result).toMatch(/Committed|already/iu);
  return result;
}

/** Registers bounded, durable visible-UI qualification shards for one vendor deployment. */
export function registerVendorPortalQualificationTests(config: QualificationConfig): void {
  test('qualifies operation-specific fields and results through the visible deployment', async ({ page }, testInfo) => {
    const shard = Number(process.env[config.shardEnvironment] ?? '0');
    const selected = OPERATIONS.slice(shard * SHARD_SIZE, (shard + 1) * SHARD_SIZE);
    test.skip(selected.length === 0, `qualification shard ${String(shard)} has no operations`);
    const sourceSha = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPOSITORY_ROOT, encoding: 'utf8' }).trim();
    const runId = process.env[config.runEnvironment] ?? `qual-${sourceSha.slice(0, 8)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
    const command = `${config.shardEnvironment}=${String(shard)} ${config.runEnvironment}=${runId} npx playwright test -c verification/playwright.config.ts verification/qualification.spec.ts`;
    const evidenceDirectory = resolve(REPOSITORY_ROOT, 'environments', config.applicationId, 'verification', 'evidence', runId);
    const artifact = join(evidenceDirectory, `capability-shard-${String(shard).padStart(2, '0')}.json`);
    const artifactPath = relative(REPOSITORY_ROOT, artifact).split('/').join('/');
    mkdirSync(dirname(artifact), { recursive: true });
    let actorNumber = '';
    const records: Record<string, unknown>[] = [];

    for (const spec of selected) {
      const requiredActor = actorFor(spec);
      if (actorNumber !== requiredActor) {
        await signOn(page, requiredActor);
        actorNumber = requiredActor;
      }
      const { entry, action } = await fillOperation(page, spec);
      let visibleResult = await page.locator('main').innerText();
      let kind = resultKind(visibleResult);
      if (kind === 'reviewed' && spec.approval !== true) {
        await page.getByRole('button', { name: 'Commit' }).click();
        visibleResult = await page.locator('main').innerText();
        kind = resultKind(visibleResult);
      }
      expect(visibleResult.trim().length).toBeGreaterThan(0);
      records.push({
        source_sha: sourceSha,
        recorded_at: new Date().toISOString(),
        command,
        test: `${testInfo.title} [${spec.kind}]`,
        task: spec.task,
        capability: CATALOG_CAPABILITY.get(spec.task) ?? spec.kind,
        option: CATALOG_CAPABILITY.get(spec.task) ?? spec.kind,
        visible_entry: entry,
        action,
        visible_result: visibleResult,
        business_effect: kind === 'committed' ? 'The visible operation committed and displayed its durable result.' : kind === 'reviewed' ? 'The visible operation reached its reviewed target state; no write was requested.' : 'The shared service truthfully refused the populated operation and displayed its specific reason.',
        artifact_path: artifactPath,
        recovery: kind === 'committed' ? 'The result exposes a durable receipt for retry and reconciliation.' : 'No target business write occurred; the form remains recoverable for correction or re-review.',
      });
    }
    writeFileSync(artifact, `${JSON.stringify({ application_id: config.applicationId, source_sha: sourceSha, run_id: runId, shard, total_shards: Math.ceil(OPERATIONS.length / SHARD_SIZE), records }, null, 2)}\n`);
  });

  test('qualifies the visible inquiry and export capabilities', async ({ page }, testInfo) => {
    const shard = Number(process.env[config.shardEnvironment] ?? '0');
    test.skip(shard !== 0, 'inquiry qualification is recorded once with capability shard zero');
    const sourceSha = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPOSITORY_ROOT, encoding: 'utf8' }).trim();
    const runId = process.env[config.runEnvironment] ?? `qual-${sourceSha.slice(0, 8)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
    const command = `${config.shardEnvironment}=0 ${config.runEnvironment}=${runId} npx playwright test -c verification/playwright.config.ts verification/qualification.spec.ts`;
    const evidenceDirectory = resolve(REPOSITORY_ROOT, 'environments', config.applicationId, 'verification', 'evidence', runId);
    const artifact = join(evidenceDirectory, 'capability-inquiries.json');
    const artifactPath = relative(REPOSITORY_ROOT, artifact).split('/').join('/');
    mkdirSync(dirname(artifact), { recursive: true });
    await signOn(page);
    const inquiries = [
      { task: 'T011', capability: 'account.inquire', option: 'account.inquire', path: '/account/northstar-account-1', expected: 'Posted balance' },
      { task: 'T013', capability: 'member.identity.resolve', option: 'member.identity.resolve', path: '/members?q=Alex', expected: 'members' },
      { task: 'T057', capability: 'document.statement.retrieve', option: 'document.statement.retrieve', path: '/account/northstar-account-1/statement?period=2026-09', expected: 'Statement' },
      { task: 'T073', capability: 'reconciliation.transfer', option: 'reconciliation.transfer', path: '/record/transfer/northstar-journal-transfer-1', expected: 'transfer' },
      { task: 'T074', capability: 'reconciliation.settlement_batch', option: 'reconciliation.settlement_batch', path: '/record/settlement-batch/northstar-settlement-batch-1', expected: 'settlement' },
      { task: 'T080', capability: 'reconciliation.cash_day', option: 'reconciliation.cash_day', path: '/reconciliation/inquiry?businessDate=2026-09-12', expected: 'Cash' },
      { task: 'T081', capability: 'member.search', option: 'member.search', path: '/members?q=NM000002', expected: 'NM000002' },
      { task: 'T082', capability: 'account.list', option: 'account.list', path: '/accounts?member=NM000002', expected: 'AC0000001' },
      { task: 'T083', capability: 'transaction.search', option: 'transaction.search', path: '/account/northstar-account-1?start=2025-01-01&end=2027-01-01', expected: 'Transactions' },
      { task: 'T084', capability: 'activity.inspect', option: 'activity.inspect', path: '/activity', expected: 'activity' },
      { task: 'T100', capability: 'institution.context.verify', option: 'institution.context.verify', path: '/system', expected: 'OP0002' },
    ] as const;
    const records: Record<string, unknown>[] = [];
    for (const inquiry of inquiries) {
      await page.goto(inquiry.path);
      const visibleResult = await page.locator('body').innerText();
      expect(visibleResult).toContain(inquiry.expected);
      records.push({
        source_sha: sourceSha, recorded_at: new Date().toISOString(), command,
        test: `${testInfo.title} [${inquiry.capability}]`, task: inquiry.task, capability: inquiry.capability, option: inquiry.option,
        visible_entry: `Signed-on operator navigated to ${inquiry.path}.`, action: `Read ${inquiry.capability} with institution-scoped filters.`, visible_result: visibleResult,
        business_effect: 'The visible application returned the institution-scoped read result without a business write.', artifact_path: artifactPath,
        recovery: 'The inquiry is read-only and can be repeated after interruption without creating a duplicate effect.',
      });
    }
    const reviewSpec = OPERATIONS.find(spec => spec.kind === 'cash.deposit');
    if (reviewSpec === undefined) throw new Error('cash.deposit operation is missing');
    const review = await fillOperation(page, reviewSpec);
    const reviewedResult = await page.locator('main').innerText();
    expect(reviewedResult).toMatch(/Reviewed terms|declined|attention/iu);
    records.push({
      source_sha: sourceSha, recorded_at: new Date().toISOString(), command,
      test: `${testInfo.title} [operation.review]`, task: 'T090', capability: 'operation.review', option: 'operation.review',
      visible_entry: review.entry, action: review.action, visible_result: reviewedResult,
      business_effect: 'The populated cash operation reached a visible review decision without this qualification step requesting a commit.', artifact_path: artifactPath,
      recovery: 'The operator can return to the populated form or abandon the reviewed operation without a financial effect.',
    });
    await page.goto('/account/northstar-account-1/statement?period=2026-09');
    const statementEntry = await page.locator('main').innerText();
    const downloadPromise = page.waitForEvent('download');
    await page.getByRole('link', { name: /Download CSV/iu }).click();
    const download = await downloadPromise;
    const stream = await download.createReadStream();
    let bytes = 0;
    for await (const chunk of stream) bytes += Buffer.byteLength(chunk as Uint8Array);
    expect(bytes).toBeGreaterThan(0);
    records.push({
      source_sha: sourceSha, recorded_at: new Date().toISOString(), command,
      test: `${testInfo.title} [statement.export]`, task: 'T012', capability: 'statement.export', option: 'statement.export',
      visible_entry: statementEntry, action: 'Selected the visible CSV download for the September 2026 account statement.',
      visible_result: `${download.suggestedFilename()} downloaded with ${String(bytes)} bytes.`, business_effect: 'A real nonempty CSV artifact was downloaded for the selected account and period.',
      artifact_path: artifactPath, recovery: 'The export is read-only and its exact account/period selection can be safely retried.',
    });
    writeFileSync(artifact, `${JSON.stringify({ application_id: config.applicationId, source_sha: sourceSha, run_id: runId, records }, null, 2)}\n`);
  });

  test('qualifies bounded workflow paths and their visible recovery observation', async ({ page }, testInfo) => {
    const shard = Number(process.env[config.shardEnvironment] ?? '0');
    const workflows = Object.entries(WORKFLOW_STEPS).slice(shard * 4, (shard + 1) * 4);
    test.skip(workflows.length === 0, `workflow qualification shard ${String(shard)} has no workflows`);
    const sourceSha = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPOSITORY_ROOT, encoding: 'utf8' }).trim();
    const runId = process.env[config.runEnvironment] ?? `qual-${sourceSha.slice(0, 8)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
    const command = `${config.shardEnvironment}=${String(shard)} ${config.runEnvironment}=${runId} npx playwright test -c verification/playwright.config.ts verification/qualification.spec.ts`;
    const evidenceDirectory = resolve(REPOSITORY_ROOT, 'environments', config.applicationId, 'verification', 'evidence', runId);
    const artifact = join(evidenceDirectory, `workflow-shard-${String(shard).padStart(2, '0')}.json`);
    const artifactPath = relative(REPOSITORY_ROOT, artifact).split('/').join('/');
    mkdirSync(dirname(artifact), { recursive: true });
    const records: Record<string, unknown>[] = [];

    for (const [workflow, steps] of workflows) {
      await signOn(page);
      const visibleResults: string[] = [];
      for (const step of steps) visibleResults.push(await driveWorkflowStep(page, step));
      records.push({
        source_sha: sourceSha, recorded_at: new Date().toISOString(), command,
        test: `${testInfo.title} [${workflow} catalog path]`, workflow, branch: 'catalog-path',
        visible_entry: `The signed-on operator followed ${steps.join(' → ')} through visible deployment controls.`,
        visible_result: visibleResults.join('\n\n--- next visible workflow step ---\n\n'),
        business_effect: 'Every bounded step produced a visible reviewed, committed, inquiry, or operation-specific safe-stop result; no hidden service call substituted for the UI sequence.',
        artifact_path: artifactPath,
        recovery: 'Each durable result is receipt-backed; each safe stop retained an ordinary correction or re-entry path.',
      });
      await page.goto('/activity');
      const recoveryResult = await page.locator('main').innerText();
      expect(recoveryResult).toMatch(/activity/iu);
      records.push({
        source_sha: sourceSha, recorded_at: new Date().toISOString(), command,
        test: `${testInfo.title} [${workflow} recovery]`, workflow, branch: 'recovery',
        visible_entry: `After the ${workflow} path, the operator reopened the authoritative activity surface instead of resubmitting the sequence.`,
        visible_result: recoveryResult,
        business_effect: 'The visible recovery observation preserved committed effects and exposed prior operation state without creating another business write.',
        artifact_path: artifactPath,
        recovery: 'The workflow resumes from visible activity and receipts, so interruption does not restart already attempted effects.',
      });
    }
    writeFileSync(artifact, `${JSON.stringify({ application_id: config.applicationId, source_sha: sourceSha, run_id: runId, shard, records }, null, 2)}\n`);
  });

  test('qualifies the deployment family mechanism', async ({ page }, testInfo) => {
    const shard = Number(process.env[config.shardEnvironment] ?? '0');
    test.skip(shard !== 0, 'family qualification is recorded once with capability shard zero');
    const sourceSha = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPOSITORY_ROOT, encoding: 'utf8' }).trim();
    const runId = process.env[config.runEnvironment] ?? `qual-${sourceSha.slice(0, 8)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
    const command = `${config.shardEnvironment}=0 ${config.runEnvironment}=${runId} npx playwright test -c verification/playwright.config.ts verification/qualification.spec.ts`;
    const evidenceDirectory = resolve(REPOSITORY_ROOT, 'environments', config.applicationId, 'verification', 'evidence', runId);
    const artifact = join(evidenceDirectory, 'family-mechanism.json');
    const artifactPath = relative(REPOSITORY_ROOT, artifact).split('/').join('/');
    mkdirSync(dirname(artifact), { recursive: true });
    if (config.applicationId === 'white-label-responsive') await page.setViewportSize({ width: 390, height: 844 });
    await signOn(page);
    await page.goto('/op/member.note.add');
    const visibleResult = await page.locator('body').innerText();
    expect(visibleResult).toContain(config.familyMarker);
    const record = {
      source_sha: sourceSha, recorded_at: new Date().toISOString(), command, test: testInfo.title,
      mechanism: config.familyMechanism, visible_entry: 'The operator signed on through the deployment-owned entry and opened a real operation through its configured navigation.',
      visible_result: visibleResult,
      business_effect: `The ${config.familyMechanism} presentation rendered the shared operation with deployment-specific context and remained interactive.`,
      artifact_path: artifactPath,
      recovery: 'Reloading the operation preserved the signed-on deployment context and ordinary navigation path.',
    };
    writeFileSync(artifact, `${JSON.stringify({ application_id: config.applicationId, source_sha: sourceSha, run_id: runId, records: [record] }, null, 2)}\n`);
  });

  test('qualifies peer visibility, stale rejection, and institution isolation through two visible deployments', async ({ browser, page }, testInfo) => {
    const shard = Number(process.env[config.shardEnvironment] ?? '0');
    test.skip(shard !== 0, 'shared-world qualification is recorded once with capability shard zero');
    const databasePath = process.env.VENDOR_QUAL_DATABASE_PATH;
    const world = process.env.VENDOR_QUAL_WORLD;
    if (databasePath === undefined || world === undefined) throw new Error('The Playwright config must expose VENDOR_QUAL_DATABASE_PATH and VENDOR_QUAL_WORLD.');
    const sourceSha = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPOSITORY_ROOT, encoding: 'utf8' }).trim();
    const runId = process.env[config.runEnvironment] ?? `qual-${sourceSha.slice(0, 8)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
    const command = `${config.shardEnvironment}=0 ${config.runEnvironment}=${runId} npx playwright test -c verification/playwright.config.ts verification/qualification.spec.ts`;
    const evidenceDirectory = resolve(REPOSITORY_ROOT, 'environments', config.applicationId, 'verification', 'evidence', runId);
    const artifact = join(evidenceDirectory, 'shared-world.json');
    const artifactPath = relative(REPOSITORY_ROOT, artifact).split('/').join('/');
    mkdirSync(dirname(artifact), { recursive: true });
    const database = openFinancialDatabase({ path: databasePath });
    const bindings = database.getNamedWorld(world);
    database.close();
    const peerStore = openFinancialStore({ path: databasePath });
    const peerPortal = createVendorPortal({
      store: peerStore, bindings, operators: ['OP0002', 'OP0003', 'OP0005', 'OP0001'],
      branding: { productName: 'Qualification Peer', institutionName: 'Peer Operations', tagline: 'Independent visible deployment', accent: '#513a78' },
    });
    const peer = await startVendorPortal(peerPortal, '127.0.0.1', 0);
    const peerPage = await browser.newPage();
    try {
      await signOn(page);
      await signOn(peerPage, 'OP0002', peer.origin);
      const stamp = `${Date.now()}`;
      await preparePreferredName(page, '', `Visible from peer ${stamp}`);
      const currentCommit = await commitPrepared(page);
      await peerPage.goto(`${peer.origin}/member/northstar-member-1`);
      const peerVisible = await peerPage.locator('main').innerText();
      expect(peerVisible).toContain(`Visible from peer ${stamp}`);

      const staleEntry = await preparePreferredName(page, '', `Stale candidate ${stamp}`);
      await preparePreferredName(peerPage, peer.origin, `Peer wins ${stamp}`);
      const peerCommit = await commitPrepared(peerPage);
      await page.getByRole('button', { name: /Commit/iu }).click();
      const staleResult = await page.locator('main').innerText();
      expect(staleResult).toMatch(/stale|changed|re-review/iu);

      await peerPage.goto(`${peer.origin}/signout`);
      await signOn(peerPage, 'OP0002', peer.origin, '1');
      const isolatedContext = await peerPage.locator('body').innerText();
      await peerPage.goto(`${peer.origin}/members?q=${encodeURIComponent(`Peer wins ${stamp}`)}`);
      const isolatedSearch = await peerPage.locator('main').innerText();
      expect(isolatedSearch).not.toContain(`Peer wins ${stamp}`);

      const common = { source_sha: sourceSha, recorded_at: new Date().toISOString(), command, artifact_path: artifactPath };
      const records = [
        { ...common, test: `${testInfo.title} [peer visibility]`, shared_world_check: 'peer_visibility', visible_entry: staleEntry, visible_result: `${currentCommit}\n\nPEER READ\n${peerVisible}`, business_effect: 'A change committed through the current deployment appeared through the independent peer deployment on the same dataset.', recovery: 'The peer read the durable current value after navigation; no duplicate write was needed.' },
        { ...common, test: `${testInfo.title} [stale rejection]`, shared_world_check: 'stale_rejection', visible_entry: staleEntry, visible_result: `${peerCommit}\n\nOLDER REVIEW RESULT\n${staleResult}`, business_effect: 'The peer committed a newer version and the older visible review was rejected as stale.', recovery: 'The stale deployment explicitly directs the operator to reread and re-review instead of overwriting the peer.' },
        { ...common, test: `${testInfo.title} [institution isolation]`, shared_world_check: 'institution_isolation', visible_entry: isolatedContext, visible_result: isolatedSearch, business_effect: 'The alternate institution context did not disclose the preferred name written in the first institution despite a matching search string.', recovery: 'Returning to sign-on permits an explicit institution rebind; the application never falls back across institutions.' },
      ];
      writeFileSync(artifact, `${JSON.stringify({ application_id: config.applicationId, source_sha: sourceSha, run_id: runId, records }, null, 2)}\n`);
    } finally {
      await peerPage.close();
      await new Promise<void>(resolveClose => peer.server.close(() => resolveClose()));
      peerStore.close();
    }
  });
}
