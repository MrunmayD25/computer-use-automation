import { createHash } from 'node:crypto';
import { afterEach, describe, expect, it } from 'vitest';

import { signOn, startTestPortal, type PortalClient, type TestPortal } from './support.js';

let portal: TestPortal | undefined;
afterEach(() => { portal?.close(); portal = undefined; });

type Fields = Record<string, string | readonly string[]>;

function flowId(location: string | null): string {
  const id = location?.match(/flow=([0-9a-f]+)/)?.[1];
  if (id === undefined) throw new Error(`Expected a flow redirect, got ${String(location)}`);
  return id;
}

async function runOperation(client: PortalClient, kind: string, subjects: Fields, fields: Fields): Promise<{ result: string; receipt: string }> {
  const selected = await client.post(`/op/${kind}/select`, subjects);
  const flow = flowId(selected.location);
  const reviewed = await client.post(`/op/${kind}/review?flow=${flow}`, fields);
  expect(reviewed.status, `${kind} review redirect`).toBe(303);
  const reviewPage = await client.get(`/op/${kind}/review?flow=${flow}`);
  expect(reviewPage.status, `${kind} review page`).toBe(200);
  expect(reviewPage.body, `${kind} review page`).not.toContain('Invalid fields');
  const commit = await client.post(`/op/${kind}/commit?flow=${flow}`, {});
  const result = await client.get(commit.location ?? `/op/${kind}/result?flow=${flow}`);
  expect(result.status, `${kind} result page`).toBe(200);
  expect(result.body, `${kind} result`).toMatch(/Committed|Already applied|Already committed/);
  const receipt = result.body.match(/\/receipt\/(RCP\d+)/)?.[1] ?? '';
  expect(receipt, `${kind} receipt`).toMatch(/^RCP/);
  return { result: result.body, receipt };
}

describe('classic full-v1 lifecycle slice', () => {
  it('drives organization, account, case, preferred-name and saved-search lifecycles', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const dataset = portal.datasetId('northstar');

    await runOperation(client, 'member.organization.create', {}, {
      'f[legalName]': 'Harbor Light Community Kitchen', 'f[registrationNumber]': 'REG-PORTAL-7781',
      'f[organizationType]': 'nonprofit', 'f[email]': 'office@example.test', 'f[phone]': '555-0121',
    });
    expect(portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM organizations WHERE dataset_id=? AND registration_number=?', dataset, 'REG-PORTAL-7781')[0]?.count).toBe(1);

    const delivery = portal.query<{ id: string; version: number }>("SELECT id,version FROM accounts WHERE dataset_id=? AND status='open' AND statement_delivery='electronic' ORDER BY id LIMIT 1", dataset)[0];
    expect(delivery).toBeTruthy();
    await runOperation(client, 'account.statement_delivery.update', { 'subject[accountId]': delivery?.id ?? '' }, { 'f[statementDelivery]': 'paper' });
    expect(portal.query<{ statement_delivery: string }>('SELECT statement_delivery FROM accounts WHERE dataset_id=? AND id=?', dataset, delivery?.id ?? '')[0]?.statement_delivery).toBe('paper');

    const close = portal.query<{ id: string; version: number }>(`SELECT a.id,a.version FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
      WHERE a.dataset_id=? AND a.status='open' AND b.posted_balance_minor_units=0 AND b.available_balance_minor_units=0
      AND NOT EXISTS (SELECT 1 FROM holds h WHERE h.dataset_id=a.dataset_id AND h.account_id=a.id AND h.status='active')
      AND NOT EXISTS (SELECT 1 FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active') ORDER BY a.id LIMIT 1`, dataset)[0];
    expect(close).toBeTruthy();
    await runOperation(client, 'account.close', { 'subject[accountId]': close?.id ?? '' }, { 'f[reason]': 'Member requested account closure' });
    expect(portal.query<{ status: string }>('SELECT status FROM accounts WHERE dataset_id=? AND id=?', dataset, close?.id ?? '')[0]?.status).toBe('closed');

    const caseRow = portal.query<{ id: string; version: number }>("SELECT id,version FROM cases WHERE dataset_id=? AND state='open' AND queue_id='northstar-queue-1' LIMIT 1", dataset)[0];
    expect(caseRow).toBeTruthy();
    await runOperation(client, 'case.assign', { 'subject[caseId]': caseRow?.id ?? '' }, {
      'f[queueId]': 'northstar-queue-1', 'f[assignedActorId]': 'northstar-actor-7', 'f[reason]': 'Servicing desk follow-up',
    });
    expect(portal.query<{ assigned_actor_id: string }>('SELECT assigned_actor_id FROM cases WHERE dataset_id=? AND id=?', dataset, caseRow?.id ?? '')[0]?.assigned_actor_id).toBe('northstar-actor-7');
    const assigned = portal.query<{ id: string; version: number }>("SELECT id,version FROM cases WHERE dataset_id=? AND state='open' AND queue_id='northstar-queue-1' AND assigned_actor_id='northstar-actor-7' LIMIT 1", dataset)[0];
    await runOperation(client, 'case.transition', { 'subject[caseId]': assigned?.id ?? '' }, { 'f[toState]': 'pending-customer', 'f[reason]': 'Awaiting customer confirmation' });
    expect(portal.query<{ state: string }>('SELECT state FROM cases WHERE dataset_id=? AND id=?', dataset, assigned?.id ?? '')[0]?.state).toBe('pending-customer');

    const member = portal.query<{ id: string; version: number }>('SELECT id,version FROM members WHERE dataset_id=? AND id=?', dataset, 'northstar-member-1')[0];
    await runOperation(client, 'member.preferred_name.update', { 'subject[memberId]': member?.id ?? '' }, { 'f[preferredName]': 'Alex', 'f[communicationScope]': 'all' });
    expect(portal.query<{ preferred_name: string }>('SELECT preferred_name FROM people WHERE dataset_id=? AND party_id=(SELECT party_id FROM members WHERE dataset_id=? AND id=?)', dataset, dataset, member?.id ?? '')[0]?.preferred_name).toBe('Alex');

    const definition = { entity: 'cases', filters: {}, sort: [], columns: ['case_number', 'state'] };
    await runOperation(client, 'search.saved.create', {}, {
      'f[name]': 'Portal lifecycle cases', 'f[visibility]': 'private', 'f[definition][entity]': definition.entity,
      'f[definition][sortDirection]': 'asc', 'f[definition][columns][]': definition.columns,
    });
    const search = portal.query<{ id: string }>('SELECT id FROM saved_searches WHERE dataset_id=? AND name=? ORDER BY created_at DESC LIMIT 1', dataset, 'Portal lifecycle cases')[0];
    expect(search).toBeTruthy();
    await runOperation(client, 'search.saved.update', { 'subject[searchId]': search?.id ?? '' }, { 's[name]': '1', 'f[name]': 'Portal lifecycle cases updated' });
    expect(portal.query<{ name: string }>('SELECT name FROM saved_searches WHERE dataset_id=? AND id=?', dataset, search?.id ?? '')[0]?.name).toBe('Portal lifecycle cases updated');
    await runOperation(client, 'search.saved.delete', { 'subject[searchId]': search?.id ?? '' }, {});
    expect(portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM saved_searches WHERE dataset_id=? AND id=?', dataset, search?.id ?? '')[0]?.count).toBe(0);
  });

  it('drives documents, consent, communication and maintenance recovery paths', async () => {
    portal = await startTestPortal();
    const client = await signOn(portal.operator('OP0002'), 'OP0002');
    const dataset = portal.datasetId('northstar');

    const member = 'northstar-member-1';
    const version = portal.query<{ id: string }>('SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE v.dataset_id=? AND v.id LIKE ? ORDER BY v.id LIMIT 1', dataset, 'northstar-document-version-notice-%')[0]?.id ?? '';
    const party = portal.query<{ party_id: string }>('SELECT party_id FROM members WHERE dataset_id=? AND id=?', dataset, member)[0]?.party_id ?? '';
    const account = portal.query<{ id: string }>('SELECT id FROM accounts WHERE dataset_id=? AND member_id=? ORDER BY id LIMIT 1', dataset, member)[0]?.id ?? '';
    expect(version).not.toBe('');
    await runOperation(client, 'document.signature.collect', { 'subject[memberId]': member }, {
      'f[action]': 'request', 'f[documentVersionId]': version, 'f[signerPartyIds][selected][]': party,
      'f[channel]': 'in-person-signature',
    });
    expect(portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM signatures WHERE dataset_id=? AND document_version_id=? AND status=\'requested\'', dataset, version)[0]?.count).toBeGreaterThan(0);

    const disclosure = portal.query<{ id: string }>('SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE v.dataset_id=? AND d.document_type=\'delivery-disclosure\' AND d.owner_party_id=? ORDER BY v.id LIMIT 1', dataset, party)[0]?.id ?? '';
    await runOperation(client, 'consent.delivery.record', { 'subject[memberId]': member }, {
      'f[accountId]': account, 'f[purpose]': 'servicing-notices', 'f[channel]': 'email', 'f[disclosureVersionId]': disclosure, 'f[evidence]': 'Accepted in branch portal',
    });
    const consent = portal.query<{ id: string }>('SELECT id FROM consents WHERE dataset_id=? AND party_id=? AND purpose=? AND channel=? AND state=\'granted\' ORDER BY effective_at DESC LIMIT 1', dataset, party, 'servicing-notices', 'email')[0];
    expect(consent).toBeTruthy();
    await runOperation(client, 'consent.withdraw', { 'subject[memberId]': member }, { 'f[consentId]': consent?.id ?? '', 'f[effectiveAt]': '2026-09-19T15:00:00Z' });
    expect(portal.query<{ state: string }>('SELECT state FROM consents WHERE dataset_id=? AND id=?', dataset, consent?.id ?? '')[0]?.state).toBe('granted');
    expect(portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM consents WHERE dataset_id=? AND party_id=? AND purpose=? AND channel=? AND state=\'withdrawn\'', dataset, party, 'servicing-notices', 'email')[0]?.count).toBeGreaterThan(0);

    const currentPreference = portal.query<{ state: string }>('SELECT state FROM communication_preferences WHERE dataset_id=? AND party_id=? AND purpose=? AND channel=?', dataset, party, 'servicing-notices', 'email')[0]?.state;
    await runOperation(client, 'communication.preference.update', { 'subject[memberId]': member }, { 'f[purpose]': 'servicing-notices', 'f[channel]': 'email', 'f[state]': currentPreference === 'enabled' ? 'disabled' : 'enabled' });
    const currentEmail = portal.query<{ value: string }>("SELECT value FROM contact_points WHERE dataset_id=? AND party_id=? AND kind='email' AND valid_to IS NULL ORDER BY id LIMIT 1", dataset, party)[0]?.value ?? '';
    await runOperation(client, 'communication.send', { 'subject[memberId]': member }, {
      'f[channel]': 'email', 's[destination]': '1', 'f[destination]': currentEmail, 'f[purpose]': 'servicing-notices', 'f[documentVersionId]': version,
    });
    const job = portal.query<{ id: string }>('SELECT id FROM communication_jobs WHERE dataset_id=? AND party_id=? ORDER BY created_at DESC LIMIT 1', dataset, party)[0]?.id ?? '';
    expect(job).not.toBe('');

    const draft = portal.query<{ id: string }>("SELECT id FROM maintenance_requests WHERE dataset_id=? AND state='draft' ORDER BY id LIMIT 1", dataset)[0]?.id ?? '';
    expect(draft).not.toBe('');
    await runOperation(client, 'edit.cancel', { 'subject[requestId]': draft }, {});
    expect(portal.query<{ state: string }>('SELECT state FROM maintenance_requests WHERE dataset_id=? AND id=?', dataset, draft)[0]?.state).toBe('withdrawn');
  });

  it('drives money, payment, card, loan and reconciliation inquiry lifecycles', async () => {
    portal = await startTestPortal();
    const servicer = await signOn(portal.operator('OP0002'), 'OP0002');
    const reader = await signOn(portal.operator('OP0001'), 'OP0001');
    const paymentsMaker = await signOn(portal.operator('OP0003'), 'OP0003');
    const paymentsChecker = await signOn(portal.operator('OP0004'), 'OP0004');
    const dataset = portal.datasetId('northstar');

    const account = portal.query<{ id: string; version: number; currency: string }>("SELECT a.id,a.version,a.currency FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.status='open' AND b.available_balance_minor_units>1000 AND NOT EXISTS (SELECT 1 FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active') ORDER BY a.id LIMIT 1", dataset)[0];
    expect(account).toBeTruthy();
    await runOperation(servicer, 'account.hold.place', { 'subject[accountId]': account?.id ?? '' }, {
      'f[amount][amount]': '1.00', 'f[amount][currency]': account?.currency ?? 'USD', 'f[reason]': 'Branch verification hold', 'f[expiresAt]': '2026-10-01T15:00:00Z', 'f[releaseAuthority]': 'branch-operations',
    });
    const hold = portal.query<{ id: string }>('SELECT id FROM holds WHERE dataset_id=? AND account_id=? AND reason=? ORDER BY placed_at DESC LIMIT 1', dataset, account?.id ?? '', 'Branch verification hold')[0]?.id ?? '';
    expect(hold).not.toBe('');
    await runOperation(servicer, 'account.hold.release', { 'subject[holdId]': hold }, { 'f[amountMinorUnits]': '100', 'f[releaseAuthority]': 'branch-operations', 'f[evidenceReference]': 'BRANCH-RELEASE-001' });
    expect(portal.query<{ status: string }>('SELECT status FROM holds WHERE dataset_id=? AND id=?', dataset, hold)[0]?.status).toBe('released');

    const fee = portal.query<{ id: string; account_id: string }>("SELECT id,account_id FROM fees WHERE dataset_id=? AND status='assessed' ORDER BY id LIMIT 1", dataset)[0];
    expect(fee).toBeTruthy();
    const feeAccount = portal.query<{ version: number; currency: string }>('SELECT version,currency FROM accounts WHERE dataset_id=? AND id=?', dataset, fee?.account_id ?? '')[0];
    const policy = portal.query<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? ORDER BY id LIMIT 1', dataset)[0]?.id ?? '';
    await runOperation(paymentsMaker, 'fee.assess', { 'subject[accountId]': fee?.account_id ?? '' }, { 'f[feeCode]': 'document-copy', 'f[amount][amount]': '1.00', 'f[amount][currency]': feeAccount?.currency ?? 'USD', 'f[basis]': 'Branch document request', 'f[policyVersionId]': policy });
    await runOperation(paymentsMaker, 'fee.refund', { 'subject[feeId]': fee?.id ?? '' }, { 'f[amount][amount]': '1.00', 'f[amount][currency]': feeAccount?.currency ?? 'USD', 'f[reason]': 'Fee correction' });
    expect(portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM fee_refunds WHERE dataset_id=? AND fee_id=?', dataset, fee?.id ?? '')[0]?.count).toBeGreaterThan(0);

    const journal = portal.query<{ id: string }>("SELECT id FROM journals WHERE dataset_id=? AND status='posted' AND posted_at>='2026-08-01T00:00:00Z' ORDER BY posted_at,id LIMIT 1", dataset)[0]?.id ?? '';
    await runOperation(servicer, 'transaction.description.update', { 'subject[journalId]': journal }, { 'f[description]': 'Branch corrected description' });
    expect(portal.query<{ new_description: string }>('SELECT new_description FROM transaction_amendments WHERE dataset_id=? AND journal_id=? ORDER BY amended_at DESC LIMIT 1', dataset, journal)[0]?.new_description).toBe('Branch corrected description');

    const retire = portal.query<{ id: string }>("SELECT b.id FROM beneficiaries b JOIN beneficiary_routes r ON r.dataset_id=b.dataset_id AND r.beneficiary_id=b.id JOIN payments p ON p.dataset_id=r.dataset_id AND p.beneficiary_route_id=r.id WHERE b.dataset_id=? AND b.status='active' AND p.state='draft' ORDER BY b.id LIMIT 1", dataset)[0]?.id ?? '';
    expect(retire).not.toBe('');
    await runOperation(paymentsMaker, 'beneficiary.retire', { 'subject[beneficiaryId]': retire }, { 'f[dependentDisposition]': 'cancel-drafts', 'f[reason]': 'Beneficiary retired by member' });
    expect(portal.query<{ status: string }>('SELECT status FROM beneficiaries WHERE dataset_id=? AND id=?', dataset, retire)[0]?.status).toBe('disabled');

    const settle = portal.query<{ id: string }>("SELECT id FROM payments WHERE dataset_id=? AND state='released' AND requested_date<='2026-09-19' ORDER BY id LIMIT 1", dataset)[0]?.id ?? '';
    expect(settle).not.toBe('');
    await runOperation(paymentsChecker, 'payment.settle', { 'subject[paymentId]': settle }, { 'f[settlementReference]': 'BRANCH-SETTLEMENT-001' });
    expect(portal.query<{ state: string }>('SELECT state FROM payments WHERE dataset_id=? AND id=?', dataset, settle)[0]?.state).toBe('settled');

    const occurrence = 'northstar-schedule-occurrence-1-2';
    await runOperation(paymentsMaker, 'payment.occurrence.amend', { 'subject[occurrenceId]': occurrence }, { 'f[newAmount][amount]': '3.00', 'f[newAmount][currency]': 'USD', 'f[newDate]': '2026-01-08' });
    expect(portal.query<{ payment_id: string }>('SELECT payment_id FROM schedule_occurrences WHERE dataset_id=? AND id=?', dataset, occurrence)[0]?.payment_id).not.toBeNull();
    // The seeded legacy schedule intentionally omits its amount rule. Add the exact
    // amount used by the occurrence so the ordinary materialize path has a valid
    // due schedule fixture while retaining the service's invalid-rule behavior for
    // other schedules.
    portal.exec('UPDATE payment_schedules SET rule_json=? WHERE dataset_id=? AND id=?', JSON.stringify({ frequency: 'daily', interval: 1, shift: 'next-business-day', amountMinorUnits: 300, currency: 'USD' }), dataset, 'northstar-payment-schedule-1');
    await runOperation(paymentsMaker, 'payment.schedule.materialize', { 'subject[occurrenceId]': 'northstar-schedule-occurrence-1-3' }, {});
    expect(portal.query<{ state: string }>('SELECT state FROM schedule_occurrences WHERE dataset_id=? AND id=?', dataset, 'northstar-schedule-occurrence-1-3')[0]?.state).toBe('materialized');

    const card = portal.query<{ id: string }>("SELECT id FROM cards WHERE dataset_id=? AND status='active' ORDER BY id LIMIT 1", dataset)[0]?.id ?? '';
    await runOperation(servicer, 'card.lock.update', { 'subject[cardId]': card }, { 'f[requestedState]': 'locked', 'f[authority]': 'branch-risk' });
    expect(portal.query<{ state: string }>('SELECT state FROM card_locks WHERE dataset_id=? AND card_id=? ORDER BY placed_at DESC LIMIT 1', dataset, card)[0]?.state).toBe('active');

    const loan = portal.query<{ id: string }>("SELECT id FROM loans WHERE dataset_id=? AND state='active' ORDER BY id LIMIT 1", dataset)[0]?.id ?? '';
    await runOperation(reader, 'loan.payoff.quote', { 'subject[loanId]': loan }, { 'f[payoffDate]': '2026-09-19', 'f[policyVersionId]': policy });
    expect(portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM payoff_quotes WHERE dataset_id=? AND loan_id=?', dataset, loan)[0]?.count).toBeGreaterThan(0);

    // Batch import consumes an indexed CSV; the seed's CSVs are already imported.
    // Prepare fresh immutable input in this test's disposable database.
    const batchDoc = 'portal-batch-document-version';
    const bytes = new TextEncoder().encode('member_id,email\r\nnorthstar-member-1,portal-batch@example.test\r\n');
    const digest = createHash('sha256').update(bytes).digest('hex');
    portal.exec('INSERT INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,?,?,?)',
      dataset, digest, 'text/csv', bytes.byteLength, bytes);
    portal.exec(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
      SELECT dataset_id,?,owner_party_id,account_id,document_type,?,retention_class,created_at
      FROM documents WHERE dataset_id=? AND id=?`,
      'portal-batch-document', 'Portal lifecycle contacts.csv', dataset, 'northstar-batch-document-1');
    portal.exec(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      SELECT dataset_id,?,?,1,?,media_type,issued_at,period_start,period_end,page_count,status
      FROM document_versions WHERE dataset_id=? AND id=?`,
      batchDoc, 'portal-batch-document', digest, dataset, 'northstar-batch-document-version-1');
    await runOperation(servicer, 'batch.import', { 'subject[documentVersionId]': batchDoc }, { 'f[batchNumber]': 'BT-PORTAL-0001', 'f[batchKind]': 'contact-update', 'n[currency]': '1' });
    expect(portal.query<{ count: number }>('SELECT COUNT(*) AS count FROM batches WHERE dataset_id=? AND batch_number=?', dataset, 'BT-PORTAL-0001')[0]?.count).toBe(1);
  });
});
