# Federated servicing suite

Four independently listening portals share the canonical financial dataset while keeping portal navigation and browser sessions separate.

## Run

From `environments/`, install workspace dependencies with `npm ci` and seed the financial database once, then run:

```sh
FEDERATED_PORT=4380 npm run start:federated-servicing-suite
```

The root command builds the financial package and suite before launching. Entry points: launcher `http://127.0.0.1:4380/`, member `:4381`, payment `:4382`, document `:4383`. Set `FINANCIAL_DATABASE_PATH` to choose a seeded database, or append `-- --database /absolute/path/to/world.sqlite --world <name>`. Stop with Ctrl-C or SIGTERM.

## Checks

`npm run typecheck -w federated-servicing-suite`, `npm run lint -w federated-servicing-suite`, and `npm test -w federated-servicing-suite`.

Root `npm run build`, `npm run check`, and `npm test` include the suite. Dependencies use the root workspace lockfile. The app-local browser smoke script is not full-v1 qualification.

