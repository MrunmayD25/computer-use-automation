# Federated servicing suite specification

The suite models a Northstar Mutual operations desk composed of Federation Desk, Member Relations, Payments Control, and Document Registry. Each portal has a distinct TCP origin and visible identity. Top-level links carry member and case context; direct URLs remain usable.

Shared entities are institution, member, account, case, document, approval, and receipt identifiers. Reads use `@computer-use/financial-database/services` against the seeded shared dataset. Portal sessions and navigation are process-local; business records are not copied.

Completion requires direct entry, launcher discovery, named top-level handoff, return context, peer health/recovery messaging, member search, real statement download, and durable receipt lookup.

