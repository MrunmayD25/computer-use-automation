import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

describe('federated suite contract', () => {
  it('declares four independently reachable portal origins and recovery surfaces', () => {
    const source = readFileSync(resolve(import.meta.dirname, '../src/main.ts'), 'utf8');
    expect(source).toContain("id:'launcher'");
    expect(source).toContain("id:'member'");
    expect(source).toContain("id:'payment'");
    expect(source).toContain("id:'document'");
    expect(source).toContain("/healthz");
    expect(source).toContain('/downloads/statement.csv');
    expect(source).toContain('/api/receipt/:id');
  });
});
