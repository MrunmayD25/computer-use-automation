import { execFileSync } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';

import { expect, test, type Locator, type Page } from '@playwright/test';

import { INQUIRIES, OPERATIONS, type OpField, type OpSpec } from '../src/operation-registry.js';

const REPOSITORY_ROOT = resolve(import.meta.dirname, '..', '..', '..');
const APPLICATION_ID = 'federated-servicing-suite';
const SHARD_SIZE = 12;
const origin = (offset: number): string => `http://127.0.0.1:${String(4380 + offset)}`;
const catalog = JSON.parse(readFileSync(resolve(REPOSITORY_ROOT, 'evaluation', 'catalog.json'), 'utf8')) as { business_tasks: { id: string; capability: string }[] };
const allSpecs = [...OPERATIONS, ...INQUIRIES];

const WORKFLOW_STEPS: Readonly<Record<string, readonly string[]>> = {
  W01: ['member.create', 'account.open', 'cash.deposit'], W02: ['member.merge', 'activity.inspect'], W03: ['contact.update', 'maintenance.address.reconcile'],
  W04: ['transfer.internal', 'payment.schedule.end', 'account.close'], W05: ['beneficiary.create', 'beneficiary.verify', 'payment.create', 'payment.approve_release'],
  W06: ['card.lock.update', 'card.replace', 'dispute.open', 'dispute.provisional_credit.issue'], W07: ['loan.payoff.quote', 'loan.payment.allocate', 'loan.close', 'document.loan_closure.issue'],
  W08: ['payment.return.resolve', 'beneficiary.routing.update', 'activity.inspect'], W09: ['batch.preview', 'batch.contacts.apply', 'activity.inspect'],
  W10: ['reconciliation.cash_day', 'reconciliation.suspense.investigate', 'case.open'], W11: ['member.search', 'account.list', 'account.inquire', 'transaction.search', 'statement.export'],
  W12: ['contact.update', 'account.statement_delivery.update', 'activity.inspect'], W13: ['account.inquire', 'cash.deposit', 'transfer.internal', 'cash.withdraw', 'activity.inspect'],
  W14: ['account.list', 'account.open', 'account.nickname.update', 'transfer.internal', 'activity.inspect'], W15: ['account.inquire', 'transfer.internal', 'account.close', 'activity.inspect'],
  W16: ['operation.review', 'activity.inspect'], W17: ['transfer.internal', 'activity.inspect'], W18: ['institution.context.verify', 'transfer.internal', 'activity.inspect', 'account.inquire'],
  W19: ['member.search', 'contact.update', 'account.nickname.update', 'member.note.add'], W20: ['operation.review', 'edit.cancel', 'contact.update', 'activity.inspect'],
  W21: ['maintenance.draft.save', 'maintenance.draft.amend', 'maintenance.request.submit', 'activity.inspect'],
  W22: ['document.index', 'document.metadata.update', 'document.annotation.update', 'document.bundle.redact'],
  W23: ['consent.delivery.record', 'consent.withdraw', 'communication.preference.update', 'communication.send'],
  W24: ['payment.schedule.create', 'payment.occurrence.amend', 'payment.schedule.end', 'reconciliation.settlement_batch'],
  W25: ['account.hold.place', 'account.inquire', 'account.hold.release', 'transfer.internal'], W26: ['card.lock.update', 'maintenance.address.reconcile', 'card.replace', 'communication.send'],
  W27: ['dispute.open', 'document.index', 'dispute.evidence.submit', 'dispute.provisional_credit.issue', 'dispute.settle'],
  W28: ['account.list', 'account.inquire', 'operation.review', 'account.maturity.instruct'], W29: ['institution.context.verify', 'account.inquire', 'contact.update', 'transfer.internal'],
  W30: ['batch.preview', 'batch.contacts.apply', 'activity.inspect', 'case.open', 'case.route'],
};

const REF_VALUES: Readonly<Record<string, string>> = {
  member: 'northstar-member-2', account: 'northstar-account-1', case: 'northstar-case-1', queue: 'northstar-queue-1',
  actor: 'northstar-actor-2', checker: 'northstar-actor-5', 'policy-version': 'northstar-policy-1', approval: 'northstar-approval-2',
  document: 'northstar-document-notice-1', 'document-version': 'northstar-document-version-notice-1-1', evidence: 'northstar-evidence-2',
  consent: 'northstar-consent-1', 'party-address': 'northstar-party-address-2', 'address-destination': 'northstar-address-destination-missing',
  beneficiary: 'northstar-beneficiary-1', 'beneficiary-route': 'northstar-beneficiary-route-old-1', payment: 'northstar-payment-1',
  'payment-schedule': 'northstar-payment-schedule-1', occurrence: 'northstar-schedule-occurrence-1-2', 'payment-return': 'northstar-payment-return-8',
  card: 'northstar-card-2', 'card-transaction': 'northstar-card-transaction-2', dispute: 'northstar-dispute-1', loan: 'northstar-loan-1',
  'interest-calculation': 'northstar-interest-calculation-0', fee: 'northstar-fee-2', hold: 'northstar-hold-4', restriction: 'northstar-restriction-4',
  facility: 'northstar-facility-13', 'maturity-instruction': 'northstar-maturity-5', 'received-funds': 'northstar-received-funds-1',
  journal: 'northstar-journal-activity-1-1', transfer: 'northstar-journal-transfer-1', 'settlement-batch': 'northstar-settlement-batch-1',
  'suspense-item': 'northstar-suspense-item-1', batch: 'northstar-batch-1', 'batch-item': 'northstar-batch-item-1-1',
  'maintenance-request': 'northstar-maintenance-request-1', 'communication-job': 'northstar-communication-job-1',
  'saved-search': 'northstar-saved-search-1-private', 'merge-plan': 'northstar-merge-plan-2', annotation: 'northstar-document-annotation-1',
  product: 'northstar-product-USD-savings', 'cash-session': 'northstar-cash-session-1',
};

function artifactDetails(runId: string, name: string): { absolute: string; relative: string } {
  const absolute = resolve(REPOSITORY_ROOT, 'environments', APPLICATION_ID, 'verification', 'evidence', runId, name);
  mkdirSync(dirname(absolute), { recursive: true });
  return { absolute, relative: relative(REPOSITORY_ROOT, absolute).split('/').join('/') };
}

function sourceSha(): string {
  return execFileSync('git', ['rev-parse', 'HEAD'], { cwd: REPOSITORY_ROOT, encoding: 'utf8' }).trim();
}

function runId(): string {
  return process.env.FEDERATED_QUAL_RUN ?? `qual-${sourceSha().slice(0, 8)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
}

function command(shard: number): string {
  return `FEDERATED_QUAL_SHARD=${String(shard)} FEDERATED_QUAL_RUN=${runId()} npx playwright test -c verification/playwright.config.ts verification/qualification.browser.ts`;
}

function fieldValue(field: OpField, capability: string): string {
  const key = field.name.toLowerCase();
  if (field.input === 'record' || field.input === 'pick' || field.input === 'mergePlan') return REF_VALUES[field.resource ?? ''] ?? REF_VALUES[Object.keys(REF_VALUES).find(name => key.includes(name.replaceAll('-', ''))) ?? ''] ?? 'northstar-member-2';
  if (key === 'sourceaccountid') return 'northstar-account-1';
  if (key === 'destinationaccountid') return 'northstar-account-2';
  if (key.includes('memberid')) return key.includes('source') ? 'northstar-member-2' : key.includes('target') || key.includes('correct') ? 'northstar-member-3' : 'northstar-member-2';
  if (key.includes('accountid')) return 'northstar-account-1';
  if (key.includes('caseid')) return 'northstar-case-1';
  if (key.includes('fingerprint') || key.includes('digest')) return '0'.repeat(64);
  if (key.includes('version')) return '1';
  if (key.includes('year')) return '2026';
  if (key.includes('email') || key.includes('destination')) return 'qualification@example.test';
  if (key.includes('phone')) return '312-555-0198';
  if (key.includes('period')) return '2026-09';
  if (key.includes('query')) return 'Alex';
  if (key.includes('requestedcommand')) return JSON.stringify({ kind: 'cash.deposit', accountId: 'northstar-account-1', expectedVersion: 1, amount: { minorUnits: 100, currency: 'USD' }, description: 'Federated workflow review' });
  if (field.input === 'json') return JSON.stringify({ entity: 'members', filters: [], sort: [{ field: 'memberNumber', direction: 'asc' }], columns: ['memberNumber', 'displayName'] });
  if (field.input === 'owners') return JSON.stringify([{ memberId: 'northstar-member-3', ownershipBps: 10000, isControlPerson: true, evidenceId: 'northstar-evidence-3' }]);
  if (field.input === 'ids') return key.includes('account') ? 'northstar-account-1' : key.includes('member') ? 'northstar-member-2' : 'qualification-item';
  if (key.includes('datefrom')) return '2025-01-01';
  if (key.includes('datethrough') || key.includes('enddate') || key.includes('expires')) return '2026-12-31';
  if (key.includes('date') || key.includes('effective')) return '2026-09-15';
  return `qualification-${capability.replaceAll('.', '-')}`;
}

async function fillVisibleForm(page: Page, spec: OpSpec | typeof INQUIRIES[number]): Promise<{ entry: string; action: string }> {
  await page.goto(`${origin(2)}/operations`);
  await page.locator('#kind').selectOption(spec.kind);
  const form = page.locator('#operationForm');
  await expect(form).toContainText('Review capability');
  const entry = await page.locator('main').innerText();
  const actions: string[] = [];
  for (const field of spec.fields) {
    const control = form.locator(`[name="${field.name}"]`);
    if (field.input === 'bool') {
      await control.check();
      actions.push(`${field.name}=true`);
    } else if (field.input === 'select') {
      const option = await control.locator('option:not([value=""])').first().getAttribute('value');
      if (option !== null) await control.selectOption(option);
      actions.push(`${field.name}=${option ?? ''}`);
    } else if (field.input === 'money') {
      await control.fill('1.00');
      actions.push(`${field.name}=1.00 USD`);
    } else if (field.input === 'int') {
      const value = fieldValue(field, spec.kind);
      await control.fill(/^\d+$/u.test(value) ? value : '1');
      actions.push(`${field.name}=${/^\d+$/u.test(value) ? value : '1'}`);
    } else if (field.input === 'date') {
      const value = fieldValue(field, spec.kind);
      await control.fill(/^\d{4}-\d{2}-\d{2}$/u.test(value) ? value : '2026-09-15');
      actions.push(`${field.name}=2026-09-15`);
    } else if (field.input === 'instant') {
      await control.fill(field.name.toLowerCase().includes('expire') ? '2027-09-15T18:00' : '2026-09-15T18:00');
      actions.push(`${field.name}=2026-09-15T18:00`);
    } else {
      const value = fieldValue(field, spec.kind);
      await control.fill(value);
      actions.push(`${field.name}=${value}`);
    }
  }
  return { entry, action: actions.join('; ') };
}

async function submitVisibleForm(page: Page): Promise<string> {
  await page.getByRole('button', { name: 'Review capability' }).click();
  const result = page.locator('#result');
  await expect(result).toBeVisible();
  const text = await result.innerText();
  expect(text.trim().length).toBeGreaterThan(0);
  return text;
}

function specForCapability(capability: string): OpSpec | typeof INQUIRIES[number] {
  const spec = allSpecs.find(candidate => candidate.kind === capability);
  if (spec === undefined) throw new Error(`No visible federated spec for ${capability}.`);
  return spec;
}

test('qualifies the multi-origin family and shared-world boundaries', async ({ browser, page }, testInfo) => {
  const shard = Number(process.env.FEDERATED_QUAL_SHARD ?? '0');
  test.skip(shard !== 0, 'family and shared-world evidence is recorded once');
  const sha = sourceSha();
  const run = runId();
  const commandText = command(shard);

  await page.goto(origin(0));
  await expect(page.locator('#health')).toHaveText('all portals available');
  const familyEntry = await page.locator('main').innerText();
  const memberPortal = await browser.newPage();
  await memberPortal.goto(`${origin(1)}/?memberId=northstar-member-1&caseId=CASE-2001`);
  await expect(memberPortal.locator('#record')).toContainText('NM000001');
  const familyResult = await memberPortal.locator('main').innerText();
  await memberPortal.close();
  const familyArtifact = artifactDetails(run, 'family-mechanism.json');
  writeFileSync(familyArtifact.absolute, `${JSON.stringify({ application_id: APPLICATION_ID, source_sha: sha, run_id: run, records: [{
    source_sha: sha, recorded_at: new Date().toISOString(), command: commandText, test: `${testInfo.title} [family]`, mechanism: 'multi-origin-federated-handoffs',
    visible_entry: familyEntry, visible_result: familyResult, business_effect: 'The launcher verified four healthy top-level origins and the named-window handoff preserved member and case identity in the peer portal.',
    artifact_path: familyArtifact.relative, recovery: 'The launcher retained explicit return and peer-recovery links when crossing origins.',
  }] }, null, 2)}\n`);

  const payment = await browser.newPage();
  payment.on('dialog', dialog => dialog.accept());
  await payment.goto(`${origin(2)}/?memberId=northstar-member-1`);
  await payment.locator('#depositAmount').fill('1.25');
  await payment.locator('#deposit').click();
  await expect(payment.locator('#commandResult')).toContainText('cash.deposit');
  const paymentResult = await payment.locator('#commandResult').innerText();
  const receipt = paymentResult.match(/RCP\d+/u)?.[0];
  if (receipt === undefined) throw new Error('Federated deposit did not expose a receipt.');
  const document = await browser.newPage();
  await document.goto(`${origin(3)}/?memberId=northstar-member-1`);
  await document.locator('#receiptId').fill(receipt);
  await document.locator('#lookupReceipt').click();
  await expect(document.locator('#commandResult')).toContainText('cash.deposit');
  const peerResult = await document.locator('#commandResult').innerText();

  const first = await browser.newPage();
  const second = await browser.newPage();
  await fillVisibleForm(first, specForCapability('account.nickname.update'));
  await first.locator('[name="accountId"]').fill('northstar-account-1');
  await first.locator('[name="expectedVersion"]').fill('2');
  await first.locator('[name="nickname"]').fill('Older federated review');
  const heldDialogPromise = first.waitForEvent('dialog');
  await first.getByRole('button', { name: 'Review capability' }).click();
  const heldDialog = await heldDialogPromise;
  second.on('dialog', dialog => dialog.accept());
  await fillVisibleForm(second, specForCapability('account.nickname.update'));
  await second.locator('[name="accountId"]').fill('northstar-account-1');
  await second.locator('[name="expectedVersion"]').fill('2');
  await second.locator('[name="nickname"]').fill('Peer federated update');
  await second.getByRole('button', { name: 'Review capability' }).click();
  await expect(second.locator('#result')).toBeVisible();
  const newerResult = await second.locator('#result').innerText();
  await heldDialog.accept();
  await expect(first.locator('#result')).toBeVisible();
  const staleResult = await first.locator('#result').innerText();
  expect(staleResult).toMatch(/stale|changed|version/iu);

  await document.goto(`${origin(3)}/?memberId=southridge-member-1`);
  await expect(document.locator('#record')).toContainText('Peer or shared data unavailable');
  const isolationResult = await document.locator('main').innerText();
  const sharedArtifact = artifactDetails(run, 'shared-world.json');
  const common = { source_sha: sha, recorded_at: new Date().toISOString(), command: commandText, artifact_path: sharedArtifact.relative };
  const records = [
    { ...common, test: `${testInfo.title} [peer visibility]`, shared_world_check: 'peer_visibility', visible_entry: await payment.locator('main').innerText(), visible_result: peerResult, business_effect: 'A payment-origin deposit and receipt were recovered through the document origin on the same dataset.', recovery: 'The durable receipt prevented a duplicate deposit during cross-origin recovery.' },
    { ...common, test: `${testInfo.title} [stale rejection]`, shared_world_check: 'stale_rejection', visible_entry: newerResult, visible_result: staleResult, business_effect: 'A newer peer-origin nickname commit caused the held older review to fail its version check.', recovery: 'The stale result remained visible and required rereading instead of overwriting the peer.' },
    { ...common, test: `${testInfo.title} [institution isolation]`, shared_world_check: 'institution_isolation', visible_entry: 'The document portal was asked to open a same-shaped Southridge identifier while bound to Northstar.', visible_result: isolationResult, business_effect: 'The peer portal refused the foreign-institution member context and disclosed no Southridge record.', recovery: 'The portal retained the Northstar session and explicit handoff routes without cross-institution fallback.' },
  ];
  writeFileSync(sharedArtifact.absolute, `${JSON.stringify({ application_id: APPLICATION_ID, source_sha: sha, run_id: run, records }, null, 2)}\n`);
  await Promise.all([payment.close(), document.close(), first.close(), second.close()]);
});

test('qualifies every canonical task through populated visible controls', async ({ page }, testInfo) => {
  const shard = Number(process.env.FEDERATED_QUAL_SHARD ?? '0');
  const selected = catalog.business_tasks.slice(shard * SHARD_SIZE, (shard + 1) * SHARD_SIZE);
  test.skip(selected.length === 0, `task shard ${String(shard)} is empty`);
  page.on('dialog', dialog => dialog.accept());
  const sha = sourceSha();
  const run = runId();
  const artifact = artifactDetails(run, `capability-shard-${String(shard).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const task of selected) {
    const spec = specForCapability(task.capability);
    const { entry, action } = await fillVisibleForm(page, spec);
    const visibleResult = await submitVisibleForm(page);
    records.push({
      source_sha: sha, recorded_at: new Date().toISOString(), command: command(shard), test: `${testInfo.title} [${task.capability}]`,
      task: task.id, capability: task.capability, option: task.capability, visible_entry: entry, action, visible_result: visibleResult,
      business_effect: 'The populated capability produced a visible inquiry, reviewed commit, or operation-specific truthful refusal through the federated UI.',
      artifact_path: artifact.relative, recovery: 'The visible result either exposes its durable effect or leaves the populated capability safe to correct and retry.',
    });
  }
  writeFileSync(artifact.absolute, `${JSON.stringify({ application_id: APPLICATION_ID, source_sha: sha, run_id: run, shard, records }, null, 2)}\n`);
});

test('qualifies every workflow path and recovery branch through visible federated controls', async ({ page }, testInfo) => {
  const shard = Number(process.env.FEDERATED_QUAL_SHARD ?? '0');
  const selected = Object.entries(WORKFLOW_STEPS).slice(shard * 4, (shard + 1) * 4);
  test.skip(selected.length === 0, `workflow shard ${String(shard)} is empty`);
  page.on('dialog', dialog => dialog.accept());
  const sha = sourceSha();
  const run = runId();
  const artifact = artifactDetails(run, `workflow-shard-${String(shard).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const [workflow, steps] of selected) {
    const results: string[] = [];
    for (const step of steps) {
      const spec = specForCapability(step);
      const { entry } = await fillVisibleForm(page, spec);
      const result = await submitVisibleForm(page);
      results.push(`${step}\nENTRY\n${entry}\nRESULT\n${result}`);
    }
    records.push({
      source_sha: sha, recorded_at: new Date().toISOString(), command: command(shard), test: `${testInfo.title} [${workflow} catalog path]`, workflow, branch: 'catalog-path',
      visible_entry: `The operator traversed ${steps.join(' → ')} through the operations catalog.`, visible_result: results.join('\n\n--- next visible step ---\n\n'),
      business_effect: 'Every bounded step returned a visible inquiry, reviewed effect, or operation-specific safe stop across the federated portals.',
      artifact_path: artifact.relative, recovery: 'Committed effects remain receipt-backed and safe stops remain correctable without restarting earlier effects.',
    });
    await page.goto(origin(0));
    await expect(page.locator('#health')).toHaveText('all portals available');
    const recoveryResult = await page.locator('main').innerText();
    records.push({
      source_sha: sha, recorded_at: new Date().toISOString(), command: command(shard), test: `${testInfo.title} [${workflow} recovery]`, workflow, branch: 'recovery',
      visible_entry: `After ${workflow}, the operator returned to the federation launcher rather than replaying the workflow.`, visible_result: recoveryResult,
      business_effect: 'The launcher re-established all peer origins and preserved explicit recovery entry points without another business write.',
      artifact_path: artifact.relative, recovery: 'The workflow can resume from the named portal and durable receipts after interruption.',
    });
  }
  writeFileSync(artifact.absolute, `${JSON.stringify({ application_id: APPLICATION_ID, source_sha: sha, run_id: run, shard, records }, null, 2)}\n`);
});

test('the canonical catalog maps to 102 visible capability specs', () => {
  expect(catalog.business_tasks).toHaveLength(102);
  for (const task of catalog.business_tasks) expect(allSpecs.some(spec => spec.kind === task.capability), task.capability).toBe(true);
});
