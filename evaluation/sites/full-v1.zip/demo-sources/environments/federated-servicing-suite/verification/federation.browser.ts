import { expect, test } from '@playwright/test';

import { INQUIRIES, OPERATIONS } from '../src/operation-registry.js';

const origin = (offset: number): string => `http://127.0.0.1:${String(4380 + offset)}`;

test('the launcher exposes four healthy top-level origins', async ({ page, request }) => {
  await page.goto(origin(0));
  await expect(page.getByRole('heading', { name: 'Choose an operating portal' })).toBeVisible();
  await expect(page.locator('#health')).toHaveText('all portals available');
  await expect(page.locator('article.card')).toHaveCount(3);
  const portals = await Promise.all([0, 1, 2, 3].map(async (offset) => {
    const response = await request.get(`${origin(offset)}/healthz`);
    expect(response.ok()).toBe(true);
    return (await response.json()) as { portal: string; origin: string };
  }));
  expect(portals.map((entry) => entry.portal)).toEqual(['launcher', 'member', 'payment', 'document']);
  expect(new Set(portals.map((entry) => entry.origin)).size).toBe(4);
});

test('every registered capability renders its ordinary fields in a peer portal', async ({ page }) => {
  await page.goto(`${origin(2)}/operations`);
  const specs = [...OPERATIONS, ...INQUIRIES];
  await expect(page.locator('#kind option')).toHaveCount(specs.length + 1);
  for (const spec of specs) {
    await page.locator('#kind').selectOption(spec.kind);
    await expect(page.locator('#operationForm')).toContainText('Review capability');
    await expect(page.locator('#operationForm label')).toHaveCount(spec.fields.length);
  }
});

test('a payment-origin deposit is recovered visibly from the document origin', async ({ page, context }) => {
  await page.goto(`${origin(2)}/?memberId=northstar-member-1`);
  await expect(page.locator('#record')).toContainText('NM000001');
  await page.locator('#depositAmount').fill('1.25');
  page.once('dialog', async (dialog) => dialog.accept());
  await page.locator('#deposit').click();
  await expect(page.locator('#commandResult')).toContainText('cash.deposit');
  const text = await page.locator('#commandResult').innerText();
  const receiptNumber = text.match(/RCP\d+/u)?.[0];
  expect(receiptNumber).toBeDefined();

  const documentPortal = await context.newPage();
  await documentPortal.goto(`${origin(3)}/?memberId=northstar-member-1`);
  await documentPortal.locator('#receiptId').fill(receiptNumber ?? 'missing');
  await documentPortal.locator('#lookupReceipt').click();
  await expect(documentPortal.locator('#commandResult')).toContainText(receiptNumber ?? 'missing');
  await expect(documentPortal.locator('#commandResult')).toContainText('cash.deposit');
  await documentPortal.close();
});

test('the document origin downloads real CSV bytes and keeps institution scope', async ({ page }) => {
  await page.goto(`${origin(3)}/?memberId=northstar-member-1`);
  await expect(page.locator('#record')).toContainText('Northstar Mutual');
  const download = page.waitForEvent('download');
  await page.locator('#download').click();
  const artifact = await download;
  expect(artifact.suggestedFilename()).toMatch(/\.csv$/u);
  expect((await artifact.createReadStream())?.readable).toBe(true);

  await page.goto(`${origin(3)}/?memberId=southridge-member-1`);
  await expect(page.locator('#record')).toContainText('Peer or shared data unavailable');
  await expect(page.locator('#record')).not.toContainText('Southridge');
});
