import { copyFileSync, mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';

import { defineConfig } from '@playwright/test';

import { ensureTemplate, TEST_WORLD } from '../../vendor-portal/test/template.js';

const runName = process.env.FEDERATED_VERIFICATION_RUN ?? `${new Date().toISOString().replaceAll(':', '-')}-${String(process.pid)}`;
process.env.FEDERATED_VERIFICATION_RUN = runName;
const runtimeDirectory = resolve(import.meta.dirname, '..', '.runtime');
const databasePath = join(runtimeDirectory, `browser-${runName}.sqlite`);
const mainPath = resolve(import.meta.dirname, '..', 'dist', 'main.js');
mkdirSync(runtimeDirectory, { recursive: true });
copyFileSync((await ensureTemplate()).path, databasePath);

export default defineConfig({
  testDir: '.',
  testMatch: '**/*.browser.ts',
  timeout: 120_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list'], ['json', { outputFile: join(import.meta.dirname, 'artifacts', runName, 'results.json') }]],
  outputDir: `artifacts/${runName}/browser`,
  webServer: {
    command: `node ${JSON.stringify(mainPath)} --port 4380 --database ${JSON.stringify(databasePath)} --world ${TEST_WORLD}`,
    url: 'http://127.0.0.1:4380/healthz',
    reuseExistingServer: false,
    timeout: 30_000,
  },
  use: {
    actionTimeout: 10_000,
    viewport: { width: 1280, height: 900 },
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    acceptDownloads: true,
  },
});
