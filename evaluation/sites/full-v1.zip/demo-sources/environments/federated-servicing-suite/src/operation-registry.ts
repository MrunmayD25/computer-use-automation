/**
 * Metadata for the generic operation surface. Each entry describes one shared command (or authorized
 * inquiry) as visible form fields; the shared services still own validation, authorization, reviews,
 * approvals, and outcomes. Fields named for expected fingerprints or versions are bound at load or
 * pick time so the reviewed facts are exactly the ones the command claims.
 */

export type FieldInput =
  | 'text' | 'textarea' | 'int' | 'money' | 'date' | 'instant' | 'bool' | 'select' | 'ids'
  | 'record' | 'pick' | 'address' | 'file' | 'json' | 'owners' | 'requestedCommand' | 'mergePlan';

export interface OpField {
  name: string;
  label: string;
  input: FieldInput;
  /** Static options for select; for ids these are offered as checkboxes. */
  options?: readonly string[];
  /** Record pickers: 'member' | 'account' | 'case' | a finance list resource. */
  resource?: string;
  /** Pick sources: a servicing reader, or a record list resource. Args values starting with '@' resolve from fields/context. */
  read?: { reader?: string | undefined; resource?: string | undefined; args?: Record<string, string> | undefined } | undefined;
  /** Option row field used as the value; 'fingerprint' resolves the record's snapshot fingerprint. */
  pickValue?: string | undefined;
  /** Option row field(s) joined for the option label. */
  pickLabel?: string | undefined;
  /** Extra form fields filled from a picked row's fields (e.g. expectedUpdatedAt ← updatedAt). */
  also?: Record<string, string> | undefined;
  nullable?: boolean | undefined;
  optional?: boolean | undefined;
  auto?: boolean | undefined;
  /** Money: name of the field/context key carrying the currency. Defaults to the context currency or a currency select. */
  currencyField?: string | undefined;
  hint?: string | undefined;
}

export interface OpSpec {
  kind: string;
  title: string;
  review?: boolean;
  approval?: boolean;
  wide?: boolean;
  hint?: string;
  fields: readonly OpField[];
}

const member = (name = 'memberId', label = 'Member'): OpField => ({ name, label, input: 'record', resource: 'member' });
const account = (name = 'accountId', label = 'Account'): OpField => ({ name, label, input: 'record', resource: 'account' });
const record = (name: string, label: string, resource: string): OpField => ({ name, label, input: 'record', resource });
const version = (name = 'expectedVersion', label = 'Current version'): OpField => ({ name, label, input: 'int', hint: 'Version shown on the record now; it is rechecked at review.' });
const fingerprint = (name = 'expectedFingerprint'): OpField => ({ name, label: 'Record fingerprint', input: 'text', auto: true, hint: 'Captured when the record loads; the service rejects if the record changed.' });
const pick = (name: string, label: string, read: OpField['read'], extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'pick', read, pickValue: 'id', pickLabel: 'label', ...extra });
const evidence = (name = 'evidenceId', memberArg = 'memberId'): OpField => pick(name, 'Identity evidence', { reader: 'identity-evidence', args: { memberId: `@${memberArg}` } }, { pickValue: 'id', pickLabel: 'reference' });
const documentVersion = (name: string, label: string, memberArg = 'memberId', extra: Partial<OpField> = {}): OpField =>
  pick(name, label, { resource: 'document-version', args: { memberId: `@${memberArg}` } }, { pickValue: 'id', pickLabel: 'displayName', ...extra });
const text = (name: string, label: string, extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'text', ...extra });
const textarea = (name: string, label: string, extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'textarea', ...extra });
const money = (name: string, label: string, extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'money', ...extra });
const date = (name: string, label: string, extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'date', ...extra });
const instant = (name: string, label: string, extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'instant', ...extra });
const int = (name: string, label: string, extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'int', ...extra });
const bool = (name: string, label: string, extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'bool', ...extra });
const select = (name: string, label: string, options: readonly string[], extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'select', options, ...extra });
const ids = (name: string, label: string, read?: OpField['read'], extra: Partial<OpField> = {}): OpField => ({ name, label, input: 'ids', ...(read === undefined ? {} : { read }), ...extra });
const policies = (name = 'policyVersionId'): OpField => pick(name, 'Policy version', { reader: 'policies' }, { pickLabel: 'name' });
const email = { name: 'email', label: 'Email', input: 'text' as const, nullable: true };
const phone = { name: 'phone', label: 'Phone', input: 'text' as const, nullable: true };

export const OPERATIONS: readonly OpSpec[] = [
  // ── Member servicing ───────────────────────────────────────────────────────────
  { kind: 'member.organization.create', title: 'New organization member', wide: true, fields: [
    text('legalName', 'Legal name'), text('registrationNumber', 'Registration number'),
    select('organizationType', 'Type', ['corporation', 'nonprofit']), email, phone,
    { name: 'address', label: 'Address', input: 'address', nullable: true },
  ] },
  { kind: 'member.identity_evidence.register', title: 'Register identity evidence', wide: true, fields: [
    member(), documentVersion('documentVersionId', 'Evidence document version'), text('evidenceId', 'Evidence id', { nullable: true }),
    select('evidenceKind', 'Kind', ['passport', 'drivers-license', 'national-id', 'state-id']), instant('issuedAt', 'Issued at'), instant('expiresAt', 'Expires at'), text('reference', 'Reference'),
  ] },
  { kind: 'member.identity.verify', title: 'Verify member identity', fields: [
    member(), evidence(), text('method', 'Verification method'),
  ] },
  { kind: 'member.legal_name.update', title: 'Update legal name', review: true, approval: true, fields: [
    member(), version(), text('legalGiven', 'Legal given name'), text('legalFamily', 'Legal family name'), evidence(),
  ] },
  { kind: 'member.preferred_name.update', title: 'Update preferred name', fields: [
    member(), version(), text('preferredName', 'Preferred name', { nullable: true }), text('communicationScope', 'Communication scope'),
  ] },
  { kind: 'member.deceased.record', title: 'Record member deceased', review: true, approval: true, fields: [
    member(), version(), evidence(), date('effectiveDate', 'Effective date'),
  ] },
  { kind: 'member.beneficial_owners.update', title: 'Update beneficial owners', review: true, approval: true, wide: true, fields: [
    member('organizationMemberId', 'Organization member'), version(), { name: 'owners', label: 'Beneficial owners', input: 'owners' }, date('effectiveDate', 'Effective date'),
  ] },
  { kind: 'member.tax_classification.update', title: 'Update tax classification', review: true, approval: true, fields: [
    member(), version(), select('classification', 'Classification', ['individual', 'organization', 'tax-exempt', 'nonresident', 'backup-withholding']), int('effectiveYear', 'Effective year'), evidence(),
  ] },
  { kind: 'member.merge', title: 'Merge duplicate member', review: true, approval: true, wide: true, hint: 'Choose a reviewed merge plan; the source accounts, versions and inventory fingerprint are bound when the plan loads.', fields: [
    { name: 'mergePlanId', label: 'Merge plan', input: 'mergePlan', pickValue: 'id' },
    member('sourceMemberId', 'Duplicate member (source)'), member('targetMemberId', 'Surviving member'),
    int('expectedSourceVersion', 'Source version'), int('expectedTargetVersion', 'Survivor version'),
    ids('relationshipAccountIds', 'Source member accounts', { resource: 'account', args: { memberId: '@sourceMemberId' } }),
    text('expectedInventoryFingerprint', 'Inventory fingerprint', { auto: true }),
  ] },

  // ── Accounts ───────────────────────────────────────────────────────────────────
  { kind: 'account.product.convert', title: 'Convert product', review: true, approval: true, fields: [
    account(), version(), pick('targetProductId', 'Target product', { resource: 'product' }), date('effectiveDate', 'Effective date'), bool('feeDisclosureAccepted', 'Fee disclosure accepted'),
  ] },
  { kind: 'account.owner.add', title: 'Add account owner', review: true, approval: true, wide: true, fields: [
    account(), version(), member('memberId', 'Additional member'), select('role', 'Role', ['owner', 'joint-owner']), date('effectiveDate', 'Effective date'),
    evidence('identityEvidenceId', 'memberId'), pick('consentId', 'Consent', { reader: 'consents', args: { memberId: '@memberId' } }, { pickValue: 'id', pickLabel: 'purpose' }),
  ] },
  { kind: 'account.signer.remove', title: 'Remove signer', review: true, approval: true, fields: [
    account(), version(), pick('signerMemberId', 'Signer to remove', { resource: 'account-party', args: { accountId: '@accountId' } }, { pickValue: 'memberId', pickLabel: 'displayName' }), instant('effectiveAt', 'Effective at'),
  ] },
  { kind: 'account.overdraft_limit.update', title: 'Update overdraft limit', review: true, approval: true, fields: [
    account(), version(),
    pick('expectedFacilityFingerprint', 'Current facility', { resource: 'facility', args: { accountId: '@accountId' } }, { pickValue: 'fingerprint', pickLabel: 'kind', nullable: true, also: {} }),
    money('limit', 'New limit'), date('effectiveDate', 'Effective date'), date('expiresAt', 'Expires on', { nullable: true }),
  ] },
  { kind: 'account.hold.place', title: 'Place hold', review: true, fields: [
    account(), version(), money('amount', 'Amount'), text('reason', 'Reason'), instant('expiresAt', 'Expires at'), text('releaseAuthority', 'Release authority'),
  ] },
  { kind: 'account.hold.release', title: 'Release hold', review: true, fields: [
    record('holdId', 'Hold', 'hold'), fingerprint('expectedFingerprint'), int('amountMinorUnits', 'Amount (minor units)'), text('releaseAuthority', 'Release authority'), text('evidenceReference', 'Evidence reference'),
  ] },
  { kind: 'account.restriction.apply', title: 'Apply restriction', review: true, approval: true, fields: [
    account(), version(), select('restrictionType', 'Type', ['debit-block', 'credit-block', 'closure-block', 'fraud-review', 'legal-hold']),
    textarea('reason', 'Reason'), text('authority', 'Authority'), record('caseId', 'Supporting case', 'case'),
  ] },
  { kind: 'account.restriction.release', title: 'Release restriction', review: true, approval: true, fields: [
    record('restrictionId', 'Restriction', 'restriction'), fingerprint('expectedFingerprint'), pick('clearanceEvidenceId', 'Clearance evidence', { reader: 'identity-evidence', args: { memberId: '@memberId' } }, { pickLabel: 'reference' }),
  ] },
  { kind: 'account.maturity.instruct', title: 'Maturity instruction', review: true, approval: true, wide: true, fields: [
    account(), version(),
    pick('expectedInstructionFingerprint', 'Current instruction', { resource: 'maturity-instruction', args: { accountId: '@accountId' } }, { pickValue: 'fingerprint', pickLabel: 'disposition', nullable: true }),
    select('disposition', 'Disposition', ['renew', 'transfer', 'hold']), account('destinationAccountId', 'Destination account'), int('termMonths', 'Term (months)', { nullable: true }), int('approvedAnnualRateBps', 'Rate (bps)', { nullable: true }),
  ] },
  { kind: 'fee.assess', title: 'Assess fee', review: true, fields: [
    account(), version(), text('feeCode', 'Fee code'), money('amount', 'Amount'), text('basis', 'Basis'), policies(),
  ] },
  { kind: 'fee.waiver.create', title: 'Create fee waiver', review: true, approval: true, fields: [
    account(), text('feeCode', 'Fee code'), date('validFrom', 'Valid from'), date('validThrough', 'Valid through'), money('amountLimit', 'Amount limit'), int('maxOccurrences', 'Max occurrences'), textarea('reason', 'Reason'),
  ] },
  { kind: 'fee.refund', title: 'Refund fee', review: true, fields: [
    record('feeId', 'Fee', 'fee'), fingerprint('expectedFingerprint'), money('amount', 'Amount'), text('reason', 'Reason'),
  ] },
  { kind: 'cash.deposit.reverse', title: 'Reverse deposit', review: true, approval: true, fields: [
    record('journalId', 'Deposit journal', 'journal'), fingerprint('expectedFingerprint'), documentVersion('correctionEvidenceId', 'Correction evidence', 'memberId'),
  ] },
  { kind: 'cash.withdrawal.reverse', title: 'Reverse withdrawal', review: true, approval: true, fields: [
    record('journalId', 'Withdrawal journal', 'journal'), fingerprint('expectedFingerprint'), textarea('reason', 'Reason'),
  ] },
  { kind: 'transfer.internal.reverse', title: 'Reverse transfer', review: true, approval: true, fields: [
    record('transferJournalId', 'Transfer journal', 'transfer'), fingerprint('expectedFingerprint'), money('amount', 'Amount'), textarea('reason', 'Reason'),
  ] },
  { kind: 'interest.adjust', title: 'Adjust interest', review: true, approval: true, fields: [
    account(), record('calculationId', 'Interest calculation', 'interest-calculation'), fingerprint('expectedFingerprint'), money('approvedDelta', 'Approved delta'),
  ] },
  { kind: 'transaction.effective_date.correct', title: 'Correct effective date', review: true, approval: true, fields: [
    record('journalId', 'Journal', 'journal'), fingerprint('expectedFingerprint'), date('correctedDate', 'Corrected date'), policies(), textarea('reason', 'Reason'),
  ] },
  { kind: 'transaction.description.update', title: 'Update description', fields: [
    record('journalId', 'Journal', 'journal'), fingerprint('expectedFingerprint'), text('description', 'New description'),
  ] },

  // ── Payments, schedules, beneficiaries ─────────────────────────────────────────
  { kind: 'beneficiary.create', title: 'Create beneficiary', wide: true, fields: [
    member(), int('expectedMemberVersion', 'Member version'), text('displayName', 'Beneficiary name'),
    select('routingKind', 'Routing kind', ['ach', 'internal', 'wire', 'card']), text('maskedDestination', 'Masked destination'), text('simulatedToken', 'Simulated token'),
    ids('allowedRails', 'Allowed rails', undefined, { options: ['ach', 'internal', 'wire', 'card'], hint: 'The selected routing kind must be included.' }),
  ] },
  { kind: 'beneficiary.verify', title: 'Verify beneficiary route', review: true, approval: true, fields: [
    { name: 'beneficiaryId', label: 'Beneficiary', input: 'record', resource: 'beneficiary', also: { memberId: 'memberId' } },
    pick('routeId', 'Route', { resource: 'beneficiary-route', args: { parentId: '@beneficiaryId' } }, { pickLabel: 'maskedDestination', also: { expectedFingerprint: 'fingerprint' } }),
    fingerprint('expectedFingerprint'), evidence('evidenceId', 'memberId'),
  ] },
  { kind: 'beneficiary.routing.update', title: 'Update beneficiary routing', review: true, approval: true, fields: [
    record('beneficiaryId', 'Beneficiary', 'beneficiary'),
    pick('expectedRouteFingerprint', 'Route', { resource: 'beneficiary-route', args: { parentId: '@beneficiaryId' } }, { pickValue: 'fingerprint', pickLabel: 'maskedDestination' }),
    select('routingKind', 'Routing kind', ['ach', 'internal', 'wire', 'card']), text('maskedDestination', 'Masked destination'), text('simulatedToken', 'Simulated token'), date('effectiveDate', 'Effective date'),
  ] },
  { kind: 'beneficiary.retire', title: 'Retire beneficiary', review: true, fields: [
    record('beneficiaryId', 'Beneficiary', 'beneficiary'), fingerprint('expectedFingerprint'), select('dependentDisposition', 'Dependent drafts', ['reject-if-active', 'cancel-drafts']), textarea('reason', 'Reason'),
  ] },
  { kind: 'payment.create', title: 'Create payment', review: true, wide: true, fields: [
    account('sourceAccountId', 'Source account'), int('expectedSourceVersion', 'Account version'),
    pick('beneficiaryRouteId', 'Beneficiary route', { resource: 'beneficiary-route' }, { pickLabel: 'maskedDestination', also: { expectedRouteFingerprint: 'fingerprint' } }),
    fingerprint('expectedRouteFingerprint'), money('amount', 'Amount'), select('rail', 'Rail', ['ach', 'internal', 'wire', 'card']),
    date('requestedDate', 'Requested date'),
    pick('calendarVersion', 'Business calendar', { resource: 'calendar-day' }, { pickValue: 'calendarVersion', pickLabel: 'localDate', also: { cutoffAt: 'paymentCutoffAt' } }),
    instant('cutoffAt', 'Cutoff at'), text('reference', 'Reference'), select('targetState', 'Initial state', ['draft', 'pending-approval']),
  ] },
  { kind: 'payment.submit', title: 'Submit payment', review: true, fields: [record('paymentId', 'Payment', 'payment'), version('expectedVersion')] },
  { kind: 'payment.approve_release', title: 'Approve and release payment', review: true, approval: true, fields: [
    record('paymentId', 'Payment', 'payment'), version('expectedVersion'), date('requestedDate', 'Requested date'),
    pick('calendarVersion', 'Business calendar', { resource: 'calendar-day' }, { pickValue: 'calendarVersion', pickLabel: 'localDate', also: { cutoffAt: 'paymentCutoffAt' } }),
    instant('cutoffAt', 'Cutoff at'),
  ] },
  { kind: 'payment.settle', title: 'Settle payment', review: true, fields: [record('paymentId', 'Payment', 'payment'), version('expectedVersion'), text('settlementReference', 'Settlement reference')] },
  { kind: 'payment.cancel', title: 'Cancel payment', review: true, fields: [record('paymentId', 'Payment', 'payment'), version('expectedVersion'), textarea('reason', 'Reason')] },
  { kind: 'payment.return.resolve', title: 'Resolve payment return', review: true, approval: true, fields: [
    record('returnId', 'Return', 'payment-return'), fingerprint('expectedFingerprint'), record('paymentId', 'Payment', 'payment'), select('disposition', 'Disposition', ['credit-source', 'investigate']),
  ] },
  { kind: 'payment.schedule.create', title: 'Create payment schedule', review: true, approval: true, wide: true, fields: [
    account('sourceAccountId', 'Source account'), int('expectedSourceVersion', 'Account version'),
    pick('beneficiaryRouteId', 'Beneficiary route', { resource: 'beneficiary-route' }, { pickLabel: 'maskedDestination', also: { expectedRouteFingerprint: 'fingerprint' } }),
    fingerprint('expectedRouteFingerprint'), money('amount', 'Amount'), select('frequency', 'Frequency', ['daily', 'weekly', 'monthly']),
    int('interval', 'Every N periods'), date('startDate', 'Start date'), date('endDate', 'End date'),
  ] },
  { kind: 'payment.schedule.materialize', title: 'Materialize occurrence', review: true, fields: [record('occurrenceId', 'Occurrence', 'schedule-occurrence'), fingerprint('expectedFingerprint')] },
  { kind: 'payment.occurrence.amend', title: 'Amend occurrence', review: true, fields: [record('occurrenceId', 'Occurrence', 'schedule-occurrence'), fingerprint('expectedFingerprint'), money('newAmount', 'New amount'), date('newDate', 'New date')] },
  { kind: 'payment.schedule.end', title: 'End payment schedule', review: true, approval: true, fields: [
    record('scheduleId', 'Schedule', 'payment-schedule'), fingerprint('expectedFingerprint'), date('endFromDate', 'End from'), select('pendingDisposition', 'Pending occurrences', ['cancel-planned', 'retain-released']),
  ] },

  // ── Cards and disputes ─────────────────────────────────────────────────────────
  { kind: 'card.replace', title: 'Replace card', review: true, wide: true, fields: [
    { name: 'cardId', label: 'Card', input: 'record', resource: 'card', also: { memberId: 'memberId' } }, fingerprint('expectedFingerprint'), textarea('reason', 'Reason'),
    evidence('identityEvidenceId'), pick('deliveryDestinationId', 'Delivery destination', { reader: 'destinations', args: { memberId: '@memberId' } }, { pickLabel: 'address' }),
    pick('deliveryAddressId', 'Delivery address', { reader: 'addresses', args: { memberId: '@memberId' } }, { pickLabel: 'line1' }),
  ] },
  { kind: 'card.lock.update', title: 'Update card lock', review: true, fields: [
    record('cardId', 'Card', 'card'), fingerprint('expectedFingerprint'), select('requestedState', 'Requested state', ['locked', 'unlocked']), text('authority', 'Authority'),
  ] },
  { kind: 'card.limit.update', title: 'Update card limit', review: true, approval: true, fields: [
    record('cardId', 'Card', 'card'), fingerprint('expectedFingerprint'), select('limitKind', 'Limit', ['daily-purchase', 'cash', 'online']),
    money('amount', 'Amount'), instant('effectiveAt', 'Effective at'), instant('expiresAt', 'Expires at', { nullable: true }),
  ] },
  { kind: 'dispute.open', title: 'Open dispute', review: true, wide: true, fields: [
    { name: 'cardTransactionId', label: 'Card transaction', input: 'record', resource: 'card-transaction', also: { memberId: 'memberId' } }, fingerprint('expectedFingerprint'), textarea('reason', 'Reason'),
    money('assertedAmount', 'Asserted amount'), ids('evidenceIds', 'Evidence documents', { resource: 'document-version', args: { memberId: '@memberId' } }),
  ] },
  { kind: 'dispute.provisional_credit.issue', title: 'Issue provisional credit', review: true, approval: true, fields: [
    { name: 'disputeId', label: 'Dispute', input: 'record', resource: 'dispute', also: { memberId: 'memberId' } }, fingerprint('expectedFingerprint'), money('amount', 'Amount'),
  ] },
  { kind: 'dispute.evidence.submit', title: 'Submit dispute evidence', review: true, approval: true, wide: true, fields: [
    { name: 'disputeId', label: 'Dispute', input: 'record', resource: 'dispute', also: { memberId: 'memberId' } }, fingerprint('expectedFingerprint'),
    ids('documentVersionIds', 'Evidence versions', { resource: 'document-version', args: { memberId: '@memberId' } }),
    instant('deadline', 'Deadline'), text('recipient', 'Recipient'), text('channel', 'Channel'),
  ] },
  { kind: 'dispute.settle', title: 'Settle dispute', review: true, approval: true, fields: [
    { name: 'disputeId', label: 'Dispute', input: 'record', resource: 'dispute', also: { memberId: 'memberId' } }, fingerprint('expectedFingerprint'), select('decision', 'Decision', ['approved', 'denied']), money('finalAmount', 'Final amount'),
  ] },

  // ── Loans ──────────────────────────────────────────────────────────────────────
  { kind: 'loan.application.prepare', title: 'Prepare loan application', wide: true, fields: [
    member(), int('expectedMemberVersion', 'Member version'), pick('productId', 'Loan product', { resource: 'product' }),
    money('requestedAmount', 'Requested amount'), int('termMonths', 'Term (months)'), text('purpose', 'Purpose'),
    ids('evidenceIds', 'Evidence documents', { resource: 'document-version', args: { memberId: '@memberId' } }),
  ] },
  { kind: 'loan.payment.allocate', title: 'Allocate loan payment', review: true, fields: [
    { name: 'loanId', label: 'Loan', input: 'record', resource: 'loan', also: { memberId: 'memberId' } }, fingerprint('expectedFingerprint'),
    pick('receivedFundsReference', 'Received funds', { resource: 'received-funds', args: { memberId: '@memberId' } }, { pickValue: 'reference', pickLabel: 'reference' }),
    money('amount', 'Amount'), select('allocationPolicy', 'Allocation', ['fees-interest-principal', 'fees-interest-principal-hold-remainder']),
  ] },
  { kind: 'loan.payoff.quote', title: 'Request payoff quote', fields: [
    record('loanId', 'Loan', 'loan'), fingerprint('expectedFingerprint'), date('payoffDate', 'Payoff date'), policies(),
  ] },
  { kind: 'loan.close', title: 'Close loan', review: true, approval: true, fields: [
    { name: 'loanId', label: 'Loan', input: 'record', resource: 'loan', also: { memberId: 'memberId' } }, fingerprint('expectedFingerprint'), documentVersion('payoffEvidenceId', 'Payoff evidence', 'memberId'),
  ] },
  { kind: 'document.loan_closure.issue', title: 'Issue loan closure document', review: true, approval: true, wide: true, fields: [
    record('loanId', 'Loan', 'loan'),
    pick('expectedClosureFingerprint', 'Loan closure', { resource: 'loan-closure', args: { parentId: '@loanId' } }, { pickValue: 'fingerprint', pickLabel: 'closedAt' }),
    pick('templateVersionId', 'Template version', { resource: 'document-version' }, { pickLabel: 'displayName' }),
    { name: 'recipientPartyId', label: 'Recipient member', input: 'record', resource: 'member', pickValue: 'partyId' }, select('documentType', 'Document type', ['loan-closure-confirmation', 'simulated-lien-release']),
  ] },

  // ── Reconciliation and batches ─────────────────────────────────────────────────
  { kind: 'reconciliation.suspense.investigate', title: 'Investigate suspense item', review: true, fields: [
    record('suspenseId', 'Suspense item', 'suspense-item'), fingerprint('expectedFingerprint'),
    ids('evidenceReferences', 'Evidence references'), account('proposedAccountId', 'Proposed account'),
  ] },
  { kind: 'reconciliation.suspense.clear', title: 'Clear suspense item', review: true, approval: true, fields: [
    record('suspenseId', 'Suspense item', 'suspense-item'), fingerprint('expectedFingerprint'), account('destinationAccountId', 'Destination account'), money('amount', 'Amount'), text('evidenceReference', 'Evidence reference'),
  ] },
  { kind: 'batch.import', title: 'Import batch', review: true, fields: [
    pick('documentVersionId', 'Input document version', { resource: 'document-version' }, { pickLabel: 'displayName', also: { inputDigest: 'digest' } }),
    text('inputDigest', 'Input digest', { auto: true }), text('batchNumber', 'Batch number'),
    select('batchKind', 'Kind', ['contact-update', 'fee-refund']), select('currency', 'Currency', ['USD', 'EUR', 'JPY', 'KWD'], { nullable: true }),
  ] },
  { kind: 'batch.contacts.apply', title: 'Apply contact batch item', review: true, approval: true, fields: [
    record('batchId', 'Batch', 'batch'),
    pick('itemId', 'Item', { resource: 'batch-item', args: { parentId: '@batchId' } }, { pickLabel: 'sourceKey', also: { expectedFingerprint: 'fingerprint' } }),
    fingerprint('expectedFingerprint'), select('conflictPolicy', 'On stale', ['skip-stale', 'reject-all']),
  ] },
  { kind: 'batch.fee_refunds.apply', title: 'Apply fee refund batch item', review: true, approval: true, fields: [
    record('batchId', 'Batch', 'batch'),
    pick('itemId', 'Item', { resource: 'batch-item', args: { parentId: '@batchId' } }, { pickLabel: 'sourceKey', also: { expectedFingerprint: 'fingerprint' } }),
    fingerprint('expectedFingerprint'),
  ] },

  // ── Documents, consent, communication ──────────────────────────────────────────
  { kind: 'document.index', title: 'Index document', wide: true, fields: [
    { name: 'memberId', label: 'Member', input: 'record', resource: 'member', also: { ownerPartyId: 'partyId' } }, text('ownerPartyId', 'Owner party', { auto: true }), { name: 'accountId', label: 'Account', input: 'record', resource: 'account', nullable: true }, text('documentId', 'Document id', { nullable: true }),
    text('documentType', 'Document type'), text('displayName', 'Display name'), text('retentionClass', 'Retention class'),
    { name: 'bytes', label: 'Document file', input: 'file' }, text('mediaType', 'Media type', { nullable: true }), int('pageCount', 'Page count', { nullable: true }),
    text('source', 'Source', { nullable: true }), text('sourceDigest', 'Source digest', { nullable: true }),
  ] },
  { kind: 'document.bundle.redact', title: 'Create redacted bundle', review: true, wide: true, hint: 'Approved excerpts are exact text copied from the listed source versions.', fields: [
    member(), ids('sourceVersionIds', 'Source versions', { resource: 'document-version', args: { memberId: '@memberId' } }),
    text('recipientPurpose', 'Recipient purpose'), pick('redactionPolicyVersionId', 'Redaction policy', { reader: 'policies' }, { pickLabel: 'name' }),
    { name: 'approvedExcerpts', label: 'Approved excerpts (JSON array of {sourceVersionId, text})', input: 'json' }, text('displayName', 'Display name', { nullable: true }),
  ] },
  { kind: 'document.signature.collect', title: 'Collect document signature', wide: true, fields: [
    select('action', 'Action', ['request', 'sign', 'decline', 'expire']), pick('documentVersionId', 'Document version', { resource: 'document-version' }, { pickLabel: 'displayName' }),
    ids('signerPartyIds', 'Signer parties', { resource: 'account-party', args: { accountId: '@accountId' } }, { pickValue: 'partyId', hint: 'Party ids, or choose from account parties when an account is in context.' }),
    text('channel', 'Channel'), text('evidenceReference', 'Evidence reference', { nullable: true }),
  ] },
  { kind: 'consent.delivery.record', title: 'Record consent', fields: [
    { name: 'partyId', label: 'Member (party)', input: 'record', resource: 'member', pickValue: 'partyId' },
    { name: 'accountId', label: 'Account', input: 'record', resource: 'account', nullable: true }, text('purpose', 'Purpose'), text('channel', 'Channel'),
    policies('disclosureVersionId'), text('evidence', 'Evidence'),
  ] },
  { kind: 'consent.withdraw', title: 'Withdraw consent', review: true, fields: [
    pick('consentId', 'Consent', { reader: 'consents', args: { memberId: '@memberId' } }, { pickLabel: 'purpose' }),
    instant('effectiveAt', 'Effective at', { nullable: true }), ids('affectedChannels', 'Affected channels'),
  ] },
  { kind: 'document.customer_export.create', title: 'Create customer export', review: true, approval: true, wide: true, fields: [
    member(), ids('categories', 'Categories', undefined, { options: ['profile', 'contact', 'accounts', 'documents', 'cases', 'transactions'] }),
    date('from', 'From', { nullable: true }), date('through', 'Through', { nullable: true }), text('destination', 'Destination'),
    ids('documentVersionIds', 'Included document versions', { resource: 'document-version', args: { memberId: '@memberId' } }),
  ] },
  { kind: 'document.retention_hold.apply', title: 'Apply retention hold', review: true, approval: true, fields: [
    { name: 'documentId', label: 'Document', input: 'record', resource: 'document', nullable: true }, { name: 'caseId', label: 'Case', input: 'record', resource: 'case', nullable: true }, textarea('reason', 'Reason'), instant('reviewAt', 'Review at'),
  ] },
  { kind: 'document.annotation.update', title: 'Update annotation', wide: true, fields: [
    pick('annotationId', 'Existing annotation', { reader: 'annotations', args: { documentVersionId: '@documentVersionId' } }, { pickLabel: 'text', nullable: true, also: { expectedAnnotationFingerprint: 'fingerprint' } }),
    documentVersion('documentVersionId', 'Document version'), int('pageNumber', 'Page'),
    { name: 'regionMicros', label: 'Region (x, y, width, height micros)', input: 'json', hint: 'e.g. {"x":0,"y":0,"width":500000,"height":300000}' },
    select('action', 'Action', ['create', 'amend', 'remove']), text('expectedAnnotationFingerprint', 'Annotation fingerprint', { auto: true, nullable: true }), textarea('text', 'Text', { nullable: true }),
  ] },
  { kind: 'document.metadata.update', title: 'Update document metadata', review: true, wide: true, fields: [
    record('documentId', 'Document', 'document'),
    { name: 'expectedMetadata', label: 'Current metadata (auto-filled when the document is chosen)', input: 'json', auto: true },
    text('documentType', 'New document type'), text('displayName', 'New display name'),
    { name: 'ownerPartyId', label: 'New owner (member)', input: 'record', resource: 'member', pickValue: 'partyId' },
    account('accountId', 'New account'), text('retentionClass', 'Retention class'),
    pick('approvalId', 'Approval (required when owner or account changes)', { resource: 'approval' }, { pickLabel: 'targetKind', nullable: true }),
  ] },
  { kind: 'communication.preference.update', title: 'Update communication preference', fields: [
    { name: 'partyId', label: 'Member (party)', input: 'record', resource: 'member', pickValue: 'partyId' },
    text('purpose', 'Purpose'), text('channel', 'Channel'), select('state', 'State', ['enabled', 'disabled']),
  ] },
  { kind: 'communication.send', title: 'Send communication', wide: true, fields: [
    { name: 'partyId', label: 'Member (party)', input: 'record', resource: 'member', pickValue: 'partyId' },
    text('channel', 'Channel'), text('destination', 'Destination', { nullable: true }),
    pick('addressDestinationId', 'Address destination', { reader: 'destinations', args: { memberId: '@memberId' } }, { pickLabel: 'address', nullable: true }),
    text('purpose', 'Purpose'), documentVersion('documentVersionId', 'Document version'), text('jobId', 'Job id', { nullable: true }),
  ] },
  { kind: 'communication.delivery.update', title: 'Update delivery state', review: true, fields: [
    pick('jobId', 'Communication job', { resource: 'communication-job' }, { pickLabel: 'purpose' }),
    select('expectedState', 'Current state', ['queued', 'accepted']), select('action', 'Action', ['accept', 'deliver', 'bounce', 'cancel']), text('detail', 'Detail'),
  ] },

  // ── Cases and maintenance ──────────────────────────────────────────────────────
  { kind: 'case.information.request', title: 'Request case information', review: true, wide: true, fields: [
    record('caseId', 'Case', 'case'), version(), ids('fields', 'Requested fields'),
    { name: 'recipientPartyId', label: 'Recipient (member)', input: 'record', resource: 'member', pickValue: 'partyId' },
    text('channel', 'Channel'), instant('dueAt', 'Due at'), documentVersion('documentVersionId', 'Request document', 'memberId', { nullable: true }), text('destination', 'Destination', { nullable: true }),
  ] },
  { kind: 'case.escalate', title: 'Escalate case', review: true, fields: [record('caseId', 'Case', 'case'), version(), text('escalationRule', 'Escalation rule')] },
  { kind: 'case.close', title: 'Close case', review: true, fields: [
    record('caseId', 'Case', 'case'), version(), text('resolutionCode', 'Resolution code'), documentVersion('effectEvidenceVersionId', 'Effect evidence', 'memberId'),
  ] },
  { kind: 'case.reopen', title: 'Reopen case', review: true, fields: [
    record('caseId', 'Case', 'case'), version(), documentVersion('evidenceVersionId', 'Reopening evidence', 'memberId'), textarea('reopeningBasis', 'Basis'), instant('dueAt', 'Due at', { nullable: true }),
  ] },
  { kind: 'maintenance.address.reconcile', title: 'Reconcile conflicting address', review: true, approval: true, wide: true, fields: [
    member(), int('expectedMemberVersion', 'Member version'),
    pick('conflictingAddressId', 'Conflicting address', { reader: 'addresses', args: { memberId: '@memberId' } }, { pickLabel: 'line1' }),
    documentVersion('winningEvidenceVersionId', 'Winning evidence'), text('winningEvidenceDigest', 'Winning digest'),
    select('precedence', 'Precedence', ['documented', 'member-declared', 'operational']), { name: 'address', label: 'Canonical address', input: 'address' },
  ] },
  { kind: 'maintenance.address.destination.update', title: 'Update address destination', review: true, approval: true, wide: true, fields: [
    member(), select('context', 'Context', ['member-mailing', 'account-statement', 'card-shipping', 'loan-notice']),
    { name: 'targetId', label: 'Target record (account, card or loan)', input: 'record', resource: 'account|card|loan' }, pick('addressId', 'Address', { reader: 'addresses', args: { memberId: '@memberId' } }, { pickLabel: 'line1' }),
    documentVersion('evidenceVersionId', 'Evidence'), date('effectiveDate', 'Effective date'),
    pick('expectedCurrentDestinationId', 'Current destination', { reader: 'destinations', args: { memberId: '@memberId' } }, { pickLabel: 'context', nullable: true }),
    pick('consentId', 'Postal consent', { reader: 'consents', args: { memberId: '@memberId' } }, { pickLabel: 'purpose', nullable: true }),
  ] },
  { kind: 'maintenance.draft.save', title: 'Save maintenance draft', wide: true, hint: 'Durable catalog draft: shared with the institution, distinct from an unsaved browser change.', fields: [
    member(), account('accountId', 'Account'), pick('requestId', 'Existing request', { resource: 'maintenance-request', args: { memberId: '@memberId' } }, { pickLabel: 'requestNumber', nullable: true }),
    text('requestNumber', 'Request number', { nullable: true }), text('category', 'Category'), text('subject', 'Subject'),
    { name: 'requestedCommand', label: 'Requested change', input: 'requestedCommand' },
    textarea('note', 'Note', { nullable: true }), ids('missingFields', 'Missing fields'),
    ids('evidenceDocumentVersionIds', 'Evidence versions', { resource: 'document-version', args: { memberId: '@memberId' } }, { nullable: true }),
  ] },
  { kind: 'maintenance.draft.amend', title: 'Amend maintenance draft', wide: true, fields: [
    pick('requestId', 'Request', { resource: 'maintenance-request' }, { pickLabel: 'requestNumber', also: { expectedUpdatedAt: 'updatedAt' } }),
    text('expectedUpdatedAt', 'Updated at', { auto: true }),
    text('patch.subject', 'New subject', { optional: true }), textarea('patch.note', 'New note', { optional: true }),
    ids('patch.missingFields', 'New missing fields', undefined, { optional: true }),
    pick('patch.evidenceVersionId', 'New evidence version', { resource: 'document-version' }, { pickLabel: 'displayName', optional: true }),
  ] },
  { kind: 'maintenance.request.submit', title: 'Submit maintenance request', fields: [
    pick('requestId', 'Request', { resource: 'maintenance-request' }, { pickLabel: 'requestNumber', also: { expectedUpdatedAt: 'updatedAt' } }),
    text('expectedUpdatedAt', 'Updated at', { auto: true }), { name: 'declaredState', label: 'Declared state', input: 'select', options: ['submitted'] },
  ] },
  { kind: 'maintenance.request.withdraw', title: 'Withdraw maintenance request', review: true, fields: [
    pick('requestId', 'Request', { resource: 'maintenance-request' }, { pickLabel: 'requestNumber', also: { expectedUpdatedAt: 'updatedAt' } }),
    text('expectedUpdatedAt', 'Updated at', { auto: true }), textarea('reason', 'Reason'),
  ] },
  { kind: 'maintenance.request.review', title: 'Review maintenance request', review: true, fields: [
    pick('requestId', 'Request', { resource: 'maintenance-request' }, { pickLabel: 'requestNumber', also: { expectedUpdatedAt: 'updatedAt' } }),
    text('expectedUpdatedAt', 'Updated at', { auto: true }), select('decision', 'Decision', ['approve', 'reject', 'return-for-information']), textarea('reason', 'Reason'), ids('missingFields', 'Missing fields', undefined, { optional: true }),
  ] },
  { kind: 'maintenance.request.process', title: 'Process maintenance request', review: true, fields: [
    pick('requestId', 'Request', { resource: 'maintenance-request' }, { pickLabel: 'requestNumber', also: { expectedUpdatedAt: 'updatedAt' } }),
    text('expectedUpdatedAt', 'Updated at', { auto: true }), select('disposition', 'Disposition', ['apply', 'reject']), textarea('reason', 'Reason'), text('appliedReceiptId', 'Applied receipt id', { optional: true }),
  ] },
  { kind: 'edit.cancel', title: 'Cancel open draft request', fields: [
    pick('requestId', 'Request', { resource: 'maintenance-request' }, { pickLabel: 'requestNumber', also: { expectedUpdatedAt: 'updatedAt' } }),
    text('expectedUpdatedAt', 'Updated at', { auto: true }),
  ] },
  { kind: 'approval.decide', title: 'Decide approval', review: true, fields: [
    pick('approvalId', 'Approval', { resource: 'approval' }, { pickLabel: 'targetKind', also: { expectedFingerprint: 'fingerprint' } }),
    text('expectedFingerprint', 'Approval fingerprint', { auto: true }), select('decision', 'Decision', ['approve', 'deny']), textarea('reason', 'Reason'),
  ] },

  // ── Core member, account, money and servicing operations ───────────────────────
  { kind: 'member.create', title: 'Create member', wide: true, fields: [text('legalGiven', 'Legal given name'), text('legalFamily', 'Legal family name'), text('preferredName', 'Preferred name', { optional: true }), date('birthDate', 'Birth date'), text('email', 'Email', { optional: true }), text('phone', 'Phone', { optional: true })] },
  { kind: 'contact.update', title: 'Update contact details', fields: [member(), version(), text('email', 'Email', { optional: true }), text('phone', 'Phone', { optional: true })] },
  { kind: 'member.note.add', title: 'Add member note', fields: [member(), select('visibility', 'Visibility', ['general', 'restricted']), textarea('text', 'Note text')] },
  { kind: 'account.open', title: 'Open account', fields: [member(), text('productId', 'Product id'), text('nickname', 'Nickname'), select('statementDelivery', 'Statement delivery', ['paper', 'electronic'])] },
  { kind: 'account.nickname.update', title: 'Update account nickname', fields: [account(), version(), text('nickname', 'Nickname')] },
  { kind: 'account.statement_delivery.update', title: 'Update statement delivery', fields: [account(), version(), select('statementDelivery', 'Statement delivery', ['paper', 'electronic'])] },
  { kind: 'account.close', title: 'Close account', review: true, fields: [account(), version(), textarea('reason', 'Closure reason')] },
  { kind: 'cash.deposit', title: 'Cash deposit', review: true, fields: [account(), version(), money('amount', 'Amount'), text('description', 'Description')] },
  { kind: 'cash.withdraw', title: 'Cash withdrawal', review: true, fields: [account(), version(), money('amount', 'Amount'), text('description', 'Description')] },
  { kind: 'transfer.internal', title: 'Internal transfer', review: true, fields: [account('sourceAccountId', 'Source account'), account('destinationAccountId', 'Destination account'), version('expectedSourceVersion', 'Source version'), version('expectedDestinationVersion', 'Destination version'), money('amount', 'Amount'), text('description', 'Description')] },
  { kind: 'case.open', title: 'Open servicing case', fields: [member(), text('accountId', 'Account id', { optional: true }), text('queueId', 'Queue id'), text('category', 'Category'), select('priority', 'Priority', ['low', 'normal', 'high', 'urgent']), textarea('summary', 'Summary'), date('dueDate', 'Due date')] },
  { kind: 'case.assign', title: 'Route case', fields: [record('caseId', 'Case', 'case'), version(), text('queueId', 'Queue id'), text('assignedActorId', 'Assigned actor', { optional: true }), textarea('reason', 'Reason')] },
  { kind: 'case.transition', title: 'Transition case', fields: [record('caseId', 'Case', 'case'), version(), select('toState', 'Target state', ['open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened']), textarea('reason', 'Reason')] },
  { kind: 'case.note.add', title: 'Add case note', fields: [record('caseId', 'Case', 'case'), select('visibility', 'Visibility', ['general', 'restricted']), textarea('text', 'Note text')] },
  { kind: 'search.saved.create', title: 'Create saved search', fields: [text('name', 'Name'), select('visibility', 'Visibility', ['private', 'shared']), select('entity', 'Entity', ['members', 'accounts', 'cases']), textarea('definition', 'Search definition JSON')] },

  { kind: 'member.identity.resolve', title: 'Resolve member identity', fields: [text('query', 'Name or identifier'), text('email', 'Email', { optional: true }), text('phone', 'Phone', { optional: true })] },
  { kind: 'case.route', title: 'Route case', fields: [record('caseId', 'Case', 'case'), version(), text('queueId', 'Queue id'), text('assignedActorId', 'Assigned actor', { optional: true }), textarea('reason', 'Reason')] },
  { kind: 'case.subject.correct', title: 'Correct case subject', review: true, approval: true, fields: [record('caseId', 'Case', 'case'), version(), member('correctMemberId', 'Correct member'), text('correctAccountId', 'Correct account', { optional: true }), text('evidenceVersionId', 'Evidence version'), text('approvalId', 'Approval id')] },
  { kind: 'search.saved.manage', title: 'Manage saved search', fields: [text('name', 'Name'), select('visibility', 'Visibility', ['private', 'shared']), select('entity', 'Entity', ['members', 'accounts', 'cases']), textarea('definition', 'Search definition JSON')] },
];

/** Authorized finance inquiries presented as operation forms; the result is shown instead of a receipt. */
export interface InquirySpec {
  kind: string;
  title: string;
  fields: readonly OpField[];
}

export const INQUIRIES: readonly InquirySpec[] = [
  { kind: 'institution.context.verify', title: 'Verify institution context', fields: [] },
  { kind: 'operation.review', title: 'Review operation terms', fields: [textarea('requestedCommand', 'Requested capability JSON')] },
  { kind: 'member.search', title: 'Search members', fields: [text('query', 'Name or member number')] },
  { kind: 'account.list', title: 'List member accounts', fields: [member()] },
  { kind: 'transaction.search', title: 'Search account transactions', fields: [account(), date('dateFrom', 'From date'), date('dateThrough', 'Through date')] },
  { kind: 'activity.inspect', title: 'Inspect activity and receipts', fields: [member(), account('accountId', 'Account')] },
  { kind: 'account.inquire', title: 'Inquire account balance', fields: [account('accountId', 'Account'), select('balanceType', 'Balance type', ['posted', 'available'])] },
  { kind: 'document.statement.retrieve', title: 'Retrieve historical statement', fields: [account(), text('period', 'Statement period'), select('format', 'Format', ['csv', 'pdf'])] },
  { kind: 'statement.export', title: 'Export account statement', fields: [account('accountId', 'Account'), select('format', 'Format', ['csv', 'pdf'])] },
  { kind: 'reconciliation.transfer', title: 'Reconcile transfer', fields: [
    record('transferJournalId', 'Transfer journal', 'transfer'), fingerprint('expectedFingerprint'),
  ] },
  { kind: 'reconciliation.settlement_batch', title: 'Reconcile settlement batch', fields: [
    record('settlementBatchId', 'Settlement batch', 'settlement-batch'), fingerprint('expectedFingerprint'), text('settlementFileDigest', 'Settlement file digest'), instant('cutoff', 'Cutoff'),
  ] },
  { kind: 'batch.preview', title: 'Preview batch', fields: [
    record('batchId', 'Batch', 'batch'), fingerprint('expectedFingerprint'), text('inputDigest', 'Input digest'), text('schemaVersion', 'Schema version'),
    ids('allowedMemberIds', 'Allowed members', { resource: 'member' }), ids('allowedAccountIds', 'Allowed accounts', { resource: 'account' }),
  ] },
  { kind: 'reconciliation.cash_day', title: 'Reconcile cash day', fields: [
    date('businessDate', 'Business date'),
    ids('cashSessionIds', 'Cash sessions', { resource: 'cash-session', args: { dateFrom: '@businessDate', dateThrough: '@businessDate' } }),
    money('declaredTotal', 'Declared total'),
  ] },
];

export function operationFor(kind: string): OpSpec | undefined {
  return OPERATIONS.find((spec) => spec.kind === kind);
}
