# federated-servicing-suite coverage

## Full-v1 qualification

Release verdict: FULL-V1 COMPLETE

- Source commit: `e07a1cab972b866d075c7414851a620bc3a66458`
- Evidence run: `full-v1-e07a1ca-20260920`
- Visible task options: 102/102
- Workflow path and recovery branches: 30/30
- Family mechanism: multi-origin-federated-handoffs
- Shared-world checks: 3/3
- Durable records: `environments/federated-servicing-suite/verification/evidence/full-v1-e07a1ca-20260920/`

The option-level matrix and exact commands, tests, visible entries/results, business effects, artifact paths, and recovery observations are in `capability-manifest.json` and the evidence directory.

## Reproduce the release audit

Run `npm --prefix environments run audit:full-v1` from the repository root. The audit fails closed on missing, stale, ignored, untracked, or wrong-application artifacts.
