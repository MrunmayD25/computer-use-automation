# Virtualized service workspace

A data-heavy service workspace in the style of a modern CRM, built over the shared financial database. Operators search and browse virtualized member, account, case, document and activity grids, edit inline, open records in tabs, move money through review and confirmation, and keep saved searches and column layouts. [SPEC.md](SPEC.md) is the contract, IMPLEMENTATION.md (historical material omitted from this bundle) records decisions and evidence, and capability-manifest.json (historical material omitted from this bundle) grades each catalog capability.

## Run the application

Seed the shared database once, if it does not exist yet:

```sh
npm --prefix environments/database/financial run seed
```

Then start the workspace from `environments/`:

```sh
npm run start:virtualized-service-workspace
```

It serves `http://127.0.0.1:4350` over `environments/database/financial/.runtime/financial.sqlite` and never seeds or resets it. Useful options, passed after `--` to `npm start -w virtualized-service-workspace`:

| Option | Default | Meaning |
| --- | --- | --- |
| `--port <n>` | 4350, or `VSW_PORT` | Listener port |
| `--database <path>` | the shared file, or `FINANCIAL_DATABASE_PATH` | Seeded financial database |
| `--world <name>` | the default seed world | Named world to bind |
| `--operators <list>` | `OP0002,OP0003,OP0005,OP0001` | Operators allowed to sign on; the first is the default |
| `--preferences <path>` | `.runtime/preferences.json`, or `VSW_PREFERENCES` | Per-operator column layouts |
| `--verbose` | off | Log each request with status and latency |

To try changes without touching shared state, copy the database first and point `--database` at the copy:

```sh
sqlite3 environments/database/financial/.runtime/financial.sqlite ".backup /tmp/vsw/demo.sqlite"
npm start -w virtualized-service-workspace -- --database /tmp/vsw/demo.sqlite --preferences /tmp/vsw/prefs.json
```

In a worktree, pass the canonical path explicitly when you mean to share updates with other applications. Identical seeds in different files do not share changes.

SIGINT or SIGTERM closes the listener and the database, then exits.

## Using the workspace

- **Lists.** Nineteen tabs: Members, Accounts, Cases, Documents and Activity, plus finance lists for payments, payment schedules, beneficiaries, cards, disputes, loans, fees, holds, maintenance requests, communications, approvals, batches, suspense items and settlement batches. Each has a search box or filters, a Columns menu, a pager and a "Go to row" field. The status line shows which rows are in view out of the total.
- **Operations.** The Operations menu and record buttons open metadata-driven dialogs for every shared command: deposits and payments, holds and restrictions, fees, beneficiaries and schedules, cards, disputes, loans, documents and signatures, consents, maintenance requests, reconciliation and approvals. Fields that need a member, account, case or finance record use pickers backed by the shared readers; versions and fingerprints are bound when the record loads. Commands that need an independent checker show an approval section that matches an existing approval or requests a new one.
- **Grid keys.** The grid is one tab stop. Arrows, Page Up and Page Down, Home and End (with Ctrl for the first and last row) move the active cell. Enter opens a record or edits an editable cell, F2 edits, Space selects, Shift+F10, the context menu key or a right-click opens row actions, and Alt+Shift+Left or Right moves the active column.
- **Columns.** Drag a header to reorder it, drag its right edge to resize, or use its ⋮ menu to sort, pin, move, widen, narrow or hide it. Layouts are saved per operator.
- **Inline edits.** Nickname and statement delivery on accounts, and email and phone on members, edit in place. Enter keeps the draft, Ctrl+Enter saves, and Esc cancels. If the row scrolls away or leaves the results, the editor docks at the bottom of the grid and offers to scroll back, keep the draft or cancel.
- **Changes.** The Changes button lists every draft with its phase (draft, pending, unknown, rejected or committed), a "Changed elsewhere" warning when the stored record moved on, and Save, Retry, Use current version and Discard actions.
- **Selection.** Tick rows, or use the ☐ menu to select a page or all matching records. The bar explains selected records that the current search hides, and exports the selection as CSV.
- **Records.** Opening a row adds a record tab — a member, account or case page, or a generic record for finance resources. Member, account and case pages carry scoped panels of related records (identity evidence, consents, beneficiaries, payments, cards, loans, disputes, documents, maintenance, communications; holds, restrictions, fees, maturity and parties) that open their own tabs. Tabs keep their scroll and state, and at most 12 stay open. The context bar shows the institution, member, account and operator in view.
- **Money.** Deposit, Withdraw and Transfer open a dialog that reviews current balances before confirmation. The receipt link opens the committed result.

## Evaluator mode

An evaluator starts the workspace in-process against its own run:

```ts
import { verificationRunStore } from '@computer-use/financial-database/services';
import { startWorkspace } from './src/server/app.js';
import { memoryPreferenceStore } from './src/server/preferences.js';

const handle = await startWorkspace({
  store: verificationRunStore(session), bindings: [binding], mode: 'verification',
  operator: { actorNumbers: ['OP0002'], fixed: true }, principalKind: 'automation',
  preferences: memoryPreferenceStore(), port: 0, publicDirectory,
});
```

The operator is fixed and cannot be switched from the browser. Closing the handle detaches from the run without disposing it, so the evaluator can still read and verify its database. [verification/evaluator-run.spec.ts](verification/evaluator-run.spec.ts) is a complete example using the T005 contract in `evaluation/verifier/app-qualification/virtualized-service-workspace-nickname.mjs`.

## Checks

```sh
npm run check -w virtualized-service-workspace   # typecheck, lint, API and model tests
npm run verify -w virtualized-service-workspace  # build, then Playwright browser verification
```

Tests copy a small seeded template under `.runtime/` and never open the shared database. The browser verification fingerprints the shared database before and after the run and fails if it changed. The cross-application spec needs a built `desktop-mdi-console` (`npm run build -w desktop-mdi-console`). Artifacts, including screenshots and per-test `evidence.json` files with browser and database observations kept apart, go to `verification/artifacts/<run>/`.

