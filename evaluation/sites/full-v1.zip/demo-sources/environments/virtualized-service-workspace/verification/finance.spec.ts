import { expect, grid, openList, row, shot, test } from './fixtures.js';

test('finance lists page real records and open a generic record view', async ({ page, workspace, evidence, pageErrors }, info) => {
  for (const list of ['payments', 'cards', 'disputes', 'loans', 'holds', 'maintenance', 'communications', 'batches', 'suspense', 'settlements'] as const) {
    await openList(page, workspace.origin, list);
    evidence.browser(`rendered ${list}`, { rows: (await page.locator(`.grid-scroller[data-grid-key="list-${list}"] [data-row-id]`).count()) });
  }
  await openList(page, workspace.origin, 'payments');
  const firstRow = grid(page, 'payments').locator('[data-row-id]').first();
  const paymentId = await firstRow.getAttribute('data-row-id');
  expect(paymentId).not.toBeNull();
  await firstRow.locator('[data-col="reference"]').click();
  await grid(page, 'payments').press('Enter');
  const record = page.locator(`[data-record-kind="resource"][data-resource="payment"][data-record-id="${paymentId ?? ''}"]`);
  await expect(record).toBeVisible();
  await expect(page).toHaveURL(new RegExp(`/northstar/resource/payment/${paymentId ?? ''}$`, 'u'));
  await expect(record.locator('dl.facts')).toContainText('northstar-account-');
  await shot(page, info, 'finance-1-payment-record');
  evidence.browser('payment record opened as a resource tab', { id: paymentId });
  expect(pageErrors).toEqual([]);
});

test('an account record scopes finance panels and places a hold through the dialog', async ({ page, workspace, evidence, pageErrors }, info) => {
  await openList(page, workspace.origin, 'accounts');
  await page.locator('[data-row-id="northstar-account-8"] [data-col="account_number"]').click();
  await grid(page, 'accounts').press('Enter');
  const account = page.locator('[data-record-kind="account"][data-record-id="northstar-account-8"]');
  await expect(account).toBeVisible();
  const accountVersion = await account.getAttribute('data-record-version');
  for (const heading of ['Holds', 'Fees', 'Restrictions', 'Maturity instructions', 'Interest calculations', 'Parties']) {
    await expect(account.getByRole('heading', { name: new RegExp(`^${heading}`, 'u') }).first()).toBeAttached();
  }
  await account.getByRole('button', { name: 'Place hold…' }).click();
  const dialog = page.getByRole('dialog', { name: 'Place hold' });
  await expect(dialog).toBeVisible();
  await expect(dialog.getByLabel('Current version')).toHaveValue(accountVersion ?? '');
  await dialog.locator('.money-input input').fill('42.50');
  await dialog.getByLabel('Reason').fill('Verification hold');
  await dialog.getByLabel('Expires at').fill('2026-12-31T00:00');
  await dialog.getByLabel('Release authority').fill('ops-holds');
  await dialog.getByRole('button', { name: 'Review' }).click();
  await expect(page.getByRole('region', { name: 'Review' })).toBeVisible();
  await page.getByRole('button', { name: 'Confirm place hold' }).click();
  await expect(page.getByRole('dialog').getByText(/committed \(RCP/u)).toBeVisible();
  await page.getByRole('button', { name: 'Done' }).click();
  const persisted = workspace.query<{ amount_minor_units: number; reason: string }>("SELECT amount_minor_units, reason FROM holds WHERE dataset_id=? AND account_id='northstar-account-8' AND reason='Verification hold'", workspace.datasetId('northstar'));
  evidence.database('hold persisted through the UI command', persisted);
  expect(persisted).toEqual([{ amount_minor_units: 4250, reason: 'Verification hold' }]);
  await expect(account.locator('tr[data-resource="hold"][data-row-id]')).toHaveCount(1);
  await shot(page, info, 'finance-2-account-hold');
  expect(pageErrors).toEqual([]);
});

test('the approvals board decides a request and the checker executes the approved action', async ({ page, workspace, evidence, pageErrors }, info) => {
  const subject = workspace.query<{ id: string; member_id: string; account_id: string }>("SELECT c.id, c.member_id, c.account_id FROM cases c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? AND c.account_id IS NOT NULL AND a.status='open' ORDER BY c.case_number LIMIT 1", workspace.datasetId('northstar'))[0];
  if (subject === undefined) throw new Error('No case with an open account in the template.');
  const target = {
    kind: 'account.restriction.apply', accountId: subject.account_id,
    expectedVersion: workspace.query<{ version: number }>('SELECT version FROM accounts WHERE dataset_id=? AND id=?', workspace.datasetId('northstar'), subject.account_id)[0]?.version ?? 0,
    restrictionType: 'legal-hold', reason: 'Court freeze pending', authority: 'court-order-77',
    caseId: subject.id,
    approvalId: '',
  };
  const policies = await (await page.request.post(`${workspace.origin}/api/i/northstar/servicing/read`, { data: { reader: 'policies', args: {} } })).json() as { id: string }[];
  const checkers = await (await page.request.post(`${workspace.origin}/api/i/northstar/servicing/read`, { data: { reader: 'checkers', args: { commandKind: 'account.restriction.apply' } } })).json() as { id: string; actorNumber: string }[];
  const requested = await (await page.request.post(`${workspace.origin}/api/i/northstar/commands`, {
    data: { command: { kind: 'approval.request', target, checkerActorId: checkers.find((row) => row.actorNumber === 'OP0005')?.id ?? '', policyVersionId: policies[0]?.id ?? '', expiresAt: '2026-09-20T00:00:00.000Z', amountLimit: null }, idempotencyKey: 'vsw-ui-approval-request' },
  })).json() as { kind: string; receipt?: { affected: { kind: string; id: string }[] } };
  const approvalId = requested.receipt?.affected.find((item) => item.kind === 'approval')?.id ?? '';
  evidence.database('approval requested for the restriction command', { request: requested.kind, approvalId });
  expect(approvalId).not.toBe('');

  await openList(page, workspace.origin, 'approvals');
  const approvalRow = row(page, 'approvals', approvalId);
  await expect(approvalRow).toBeVisible();
  await expect(approvalRow).toContainText(/restriction/i);
  await expect(approvalRow).toContainText('Casey Patel');
  await expect(approvalRow).toContainText('Riley Chen');
  await shot(page, info, 'finance-3-approval-board');

  const operator = page.getByRole('button', { name: /Casey Patel/u });
  await operator.click();
  await page.getByRole('menuitemcheckbox', { name: /Riley Chen/u }).click();
  await expect(page.locator('.context-bar')).toContainText('Riley Chen (OP0005)');

  await approvalRow.click({ button: 'right' });
  await page.getByRole('menuitem', { name: 'Decide…' }).click();
  const decide = page.getByRole('dialog', { name: 'Decide approval' });
  await expect(decide.getByLabel('Approval fingerprint')).not.toHaveValue('');
  await decide.getByLabel('Decision').selectOption('approve');
  await decide.getByLabel('Reason').fill('Reviewed the court order.');
  await decide.getByRole('button', { name: 'Review' }).click();
  await page.getByRole('button', { name: 'Confirm decide approval' }).click();
  await expect(page.getByRole('dialog').getByText(/committed \(RCP/u)).toBeVisible();
  await page.getByRole('button', { name: 'Done' }).click();

  await approvalRow.click({ button: 'right' });
  await page.getByRole('menuitem', { name: /Prepare Account\.restriction\.apply/u }).click();
  const prepare = page.getByRole('dialog', { name: 'Apply restriction' });
  await expect(prepare).toBeVisible();
  await prepare.getByRole('button', { name: 'Review' }).click();
  await page.getByRole('button', { name: 'Confirm apply restriction' }).click();
  await expect(page.getByRole('dialog').getByText(/committed \(RCP/u)).toBeVisible();
  const applied = workspace.query<{ kind: string; account_id: string }>('SELECT kind, account_id FROM restrictions WHERE dataset_id=? AND account_id=? AND authority LIKE \'%court-order-77%\'', workspace.datasetId('northstar'), subject.account_id);
  evidence.database('restriction persisted after the approved command executed', applied);
  expect(applied).toEqual([{ kind: 'legal-hold', account_id: subject.account_id }]);
  await shot(page, info, 'finance-4-restriction-applied');
  expect(pageErrors).toEqual([]);
});

test('a member record shows scoped servicing and finance records', async ({ page, workspace, evidence, pageErrors }, info) => {
  await openList(page, workspace.origin, 'members');
  await page.locator('[data-row-id="northstar-member-2"] [data-col="member_number"]').click();
  await grid(page, 'members').press('Enter');
  const member = page.locator('[data-record-kind="member"][data-record-id="northstar-member-2"]');
  await expect(member).toBeVisible();
  for (const heading of ['Identity evidence', 'Consents', 'Beneficiaries', 'Maintenance requests', 'Payments', 'Communications']) {
    await expect(member.getByRole('heading', { name: new RegExp(`^${heading}`, 'u') }).first()).toBeAttached();
  }
  const panels = await member.locator('tr[data-resource]').evaluateAll((nodes) => [...new Set(nodes.map((node) => node.getAttribute('data-resource') ?? ''))].sort());
  evidence.browser('scoped panels on the member record', { panels });
  expect(panels).toEqual(expect.arrayContaining(['consent', 'maintenance-request', 'payment']));
  const requests = member.locator('tr[data-resource="maintenance-request"]');
  expect(await requests.count()).toBeGreaterThan(0);
  const requestId = await requests.first().getAttribute('data-row-id');
  await requests.first().click();
  await expect(page.locator(`[data-record-kind="resource"][data-resource="maintenance-request"][data-record-id="${requestId ?? ''}"]`)).toBeVisible();
  await shot(page, info, 'finance-5-member-scoped');
  expect(pageErrors).toEqual([]);
});
