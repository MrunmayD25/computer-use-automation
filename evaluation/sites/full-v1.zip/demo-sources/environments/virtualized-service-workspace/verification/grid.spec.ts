import { readFileSync } from 'node:fs';

import { cell, editor, expect, goToRow, grid, headerColumns, listView, openList, renderedIds, row, shot, test } from './fixtures.js';

const accountNumber = (index: number): string => `AC${String(index).padStart(7, '0')}`;

test('rows and columns are virtualized and recycled by identity, and every record stays reachable', async ({ page, workspace, evidence, pageErrors }, info) => {
  await openList(page, workspace.origin, 'accounts');
  const accounts = grid(page, 'accounts');
  await expect(listView(page, 'accounts').locator('[data-total]')).toHaveAttribute('data-total', '165');
  const slotsAtTop = await accounts.locator('[data-row-id]').evaluateAll((nodes) => nodes.map((node) => [node.getAttribute('data-slot'), node.getAttribute('data-row-id')]));
  expect(slotsAtTop.length).toBeLessThan(60);

  await goToRow(page, 'accounts', 120);
  const window = await accounts.locator('[data-row-id]').evaluateAll((nodes) => nodes.map((node) => ({
    slot: node.getAttribute('data-slot'), id: node.getAttribute('data-row-id'), label: node.getAttribute('data-row-label'), index: Number(node.getAttribute('aria-rowindex')) - 1,
  })));
  const windowSlots = new Set(window.map((item) => item.slot));
  expect(slotsAtTop.filter(([slot]) => !windowSlots.has(slot ?? null))).toEqual([]);
  expect(window.every((item) => item.label === accountNumber(item.index))).toBe(true);
  expect(new Set(window.map((item) => item.id)).size).toBe(window.length);
  evidence.browser('recycled slots carry the record at their index', { renderedAtTop: slotsAtTop.length, renderedAt120: window.length, reusedSlots: window.length, sample: window.slice(0, 3) });

  await cell(page, 'accounts', 'northstar-account-120', 'account_number').click();
  await accounts.press('Control+End');
  const last = accounts.locator('[aria-rowindex="166"][data-row-id]');
  await expect(last).toBeVisible();
  await expect(accounts).toHaveAttribute('aria-activedescendant', /northstar-loan-account-/u);
  evidence.browser('keyboard reaches the last record', { label: await last.getAttribute('data-row-label'), activeDescendant: await accounts.getAttribute('aria-activedescendant') });

  const atLeft = await headerColumns(page, 'accounts');
  expect(atLeft).not.toContain('opened_at');
  await accounts.evaluate((element) => { element.scrollLeft = element.scrollWidth; });
  await expect(accounts.locator('.grid-header [data-header-col="opened_at"]')).toBeVisible();
  const atRight = await headerColumns(page, 'accounts');
  expect(atRight).toContain('account_number');
  expect(atRight).not.toContain('member_number');
  const gridBox = await accounts.boundingBox();
  const pinnedBox = await accounts.locator('.grid-header [data-header-col="account_number"]').boundingBox();
  expect(Math.abs((pinnedBox?.x ?? 0) - (gridBox?.x ?? 0) - 64)).toBeLessThanOrEqual(1);
  evidence.browser('horizontal virtualization keeps the pinned column in place', { atLeft, atRight });
  expect(pageErrors).toEqual([]);
  await shot(page, info, 'grid-1-scrolled-right');
});

test('column order, pinning, width and visibility are operator preferences that survive a reload', async ({ page, workspace, evidence, pageErrors }, info) => {
  await openList(page, workspace.origin, 'accounts');
  const accounts = grid(page, 'accounts');
  await cell(page, 'accounts', 'northstar-account-1', 'status').click();
  await accounts.press('Alt+Shift+ArrowLeft');
  await accounts.press('Alt+Shift+ArrowLeft');
  let order = await headerColumns(page, 'accounts');
  expect(order.indexOf('status')).toBeLessThan(order.indexOf('product_name'));

  const nickname = accounts.locator('.grid-header [data-header-col="nickname"]');
  await nickname.getByRole('button', { name: 'Column options for Nickname' }).click({ force: true });
  await page.getByRole('menu', { name: 'Column options' }).getByRole('menuitem', { name: 'Pin column to the left' }).click();
  await expect(nickname).toHaveClass(/pinned/u);
  const widthBefore = (await nickname.boundingBox())?.width ?? 0;
  await nickname.getByRole('button', { name: 'Column options for Nickname' }).click({ force: true });
  await page.getByRole('menu', { name: 'Column options' }).getByRole('menuitem', { name: 'Wider' }).click();
  await expect.poll(async () => Math.round((await nickname.boundingBox())?.width ?? 0)).toBe(Math.round(widthBefore + 40));

  await listView(page, 'accounts').getByRole('button', { name: 'Columns ▾' }).click();
  await page.getByRole('menu', { name: 'Columns' }).getByRole('menuitemcheckbox', { name: 'Currency' }).click();
  await expect(accounts.locator('.grid-header [data-header-col="currency"]')).toHaveCount(0);

  await accounts.evaluate((element) => { element.scrollLeft = element.scrollWidth; });
  await expect(nickname).toBeVisible();
  order = await headerColumns(page, 'accounts');
  evidence.browser('layout after changes', { order, nicknameWidth: widthBefore + 40 });
  await shot(page, info, 'grid-2-pinned-reordered');

  await page.waitForTimeout(600);
  await page.reload();
  await expect(accounts.locator('[data-row-id]').first()).toBeVisible();
  const reloaded = await headerColumns(page, 'accounts');
  expect(reloaded.slice(0, 2)).toEqual(['account_number', 'nickname']);
  expect(reloaded).not.toContain('currency');
  expect(reloaded.indexOf('status')).toBeLessThan(reloaded.indexOf('product_name'));
  await expect(accounts.locator('.grid-header [data-header-col="nickname"]')).toHaveClass(/pinned/u);
  evidence.browser('layout restored after reload', { reloaded });
  expect(pageErrors).toEqual([]);
});

test('a draft and a selection survive sorting, filtering and recycling, and hidden selections are explained', async ({ page, workspace, evidence, pageErrors }, info) => {
  await openList(page, workspace.origin, 'accounts');
  const view = listView(page, 'accounts');
  await page.getByLabel('Select AC0000002').check();
  await goToRow(page, 'accounts', 29);
  await page.getByLabel('Select AC0000029').check();
  await goToRow(page, 'accounts', 4);
  await cell(page, 'accounts', 'northstar-account-4', 'nickname').dblclick();
  await page.getByLabel('Nickname for AC0000004').fill('Emergency');
  await page.getByLabel('Nickname for AC0000004').press('Enter');
  await expect(editor(page)).toHaveCount(0);
  await expect(row(page, 'accounts', 'northstar-account-4')).toHaveAttribute('data-row-state', 'draft');
  await expect(page.getByRole('button', { name: 'Changes (1)' })).toBeVisible();

  await grid(page, 'accounts').locator('.grid-header [data-header-col="nickname"]').getByRole('button', { name: 'Column options for Nickname' }).click({ force: true });
  await page.getByRole('menu', { name: 'Column options' }).getByRole('menuitemcheckbox', { name: 'Sort descending' }).click();
  await expect(page).toHaveURL(/sort=nickname%3Adesc/u);
  await expect(view.locator('.selection-bar')).toHaveAttribute('data-selected-count', '2');
  const sortedFirst = await renderedIds(page, 'accounts');
  evidence.browser('after sort the draft and selection are still attached to their records', { firstRows: sortedFirst.slice(0, 3), changes: 1, selected: 2 });

  await view.getByRole('combobox', { name: 'Status' }).selectOption('closed');
  await expect(view.locator('[data-total]')).toHaveAttribute('data-total', '7');
  const hidden = view.locator('.hidden-selection');
  await expect(hidden).toHaveAttribute('data-hidden-count', '1');
  await expect(hidden).toContainText('AC0000002');
  await expect(page.getByLabel('Select AC0000029')).toBeChecked();
  await expect(row(page, 'accounts', 'northstar-account-4')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Changes (1)' })).toBeVisible();
  evidence.browser('hidden selection explained under a filter', { hiddenText: await hidden.innerText() });
  await shot(page, info, 'grid-3-hidden-selection');

  await view.getByRole('button', { name: 'Selection options' }).click();
  await page.getByRole('menu', { name: 'Selection' }).getByRole('menuitem', { name: 'Select all 7 matching' }).click();
  await expect(view.locator('.selection-bar')).toHaveAttribute('data-selection-mode', 'matching');
  await expect(view.locator('.selection-bar')).toContainText('covers every matching record, not only loaded rows');
  const download = page.waitForEvent('download');
  await view.getByRole('button', { name: 'Export CSV (7)' }).click();
  const csv = readFileSync(await (await download).path(), 'utf8').trim().split(/\r?\n/u);
  expect(csv.length).toBe(8);
  evidence.browser('select all matching exports every matching record', { header: csv[0], rows: csv.length - 1 });

  await view.getByRole('combobox', { name: 'Status' }).selectOption('');
  await expect(view.locator('.selection-bar .notice')).toBeVisible();
  await expect(view.locator('.selection-bar')).toHaveAttribute('data-selected-count', '0');
  await view.locator('.selection-bar').getByRole('button', { name: 'Dismiss' }).click();

  await page.getByRole('button', { name: 'Changes (1)' }).click();
  const change = page.locator('[data-draft-key="northstar/account:northstar-account-4"]');
  await expect(change).toContainText('Emergency');
  await change.getByRole('button', { name: 'Discard' }).click();
  await expect(page.getByRole('button', { name: 'Changes (0)' })).toBeVisible();
  const stored = workspace.query<{ nickname: string; version: number }>('SELECT nickname, version FROM accounts WHERE id=?', 'northstar-account-4');
  expect(stored).toEqual([{ nickname: 'Primary', version: 5 }]);
  evidence.database('discarded draft never reached the database', stored);
  expect(pageErrors).toEqual([]);
});

test('portal menus and editors keep focus, close or dock when their owner leaves, and return focus', async ({ page, workspace, evidence, pageErrors }, info) => {
  await openList(page, workspace.origin, 'accounts');
  const accounts = grid(page, 'accounts');
  await row(page, 'accounts', 'northstar-account-3').getByRole('button', { name: 'Actions for AC0000003' }).click({ force: true });
  const menu = page.getByRole('menu');
  await expect(menu).toBeVisible();
  await expect(menu.getByRole('menuitem', { name: 'Open AC0000003' })).toBeFocused();
  await page.keyboard.press('ArrowDown');
  await expect(menu.getByRole('menuitem', { name: /^Open owner NM\d{6}$/u })).toBeFocused();
  expect(await menu.evaluate((element) => element.closest('.grid-scroller') === null)).toBe(true);
  await accounts.hover();
  await page.mouse.wheel(0, 3000);
  await expect(menu).toHaveCount(0);
  await expect(row(page, 'accounts', 'northstar-account-3')).toHaveCount(0);
  evidence.browser('row menu closed when its row was recycled away', { menuOpen: false });

  await goToRow(page, 'accounts', 3);
  await cell(page, 'accounts', 'northstar-account-3', 'account_number').click();
  await accounts.press('Shift+F10');
  await expect(page.getByRole('menu')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('menu')).toHaveCount(0);
  await expect(accounts).toBeFocused();

  await accounts.press('ArrowRight');
  for (let step = 0; step < 6; step += 1) await accounts.press('ArrowRight');
  await expect(accounts).toHaveAttribute('aria-activedescendant', /northstar-account-3-nickname$/u);
  await accounts.press('F2');
  const input = page.getByLabel('Nickname for AC0000003');
  await expect(input).toBeFocused();
  await input.fill('Scrolling draft');
  await accounts.hover({ position: { x: 400, y: 300 } });
  await page.mouse.wheel(0, 90);
  await expect(editor(page)).toHaveAttribute('data-anchor-state', /scrolled|absent/u);
  await expect(input).toBeFocused();
  await shot(page, info, 'grid-4-docked-while-scrolling');
  await editor(page).getByRole('button', { name: 'Scroll to row' }).click();
  await expect(editor(page)).toHaveAttribute('data-anchor-state', 'visible');
  await input.press('Escape');
  await expect(editor(page)).toHaveCount(0);
  await expect(accounts).toBeFocused();
  await expect(page.getByRole('button', { name: 'Changes (0)' })).toBeVisible();
  evidence.browser('cancel restored the stored value and removed the draft', { nickname: await cell(page, 'accounts', 'northstar-account-3', 'nickname').innerText() });

  await cell(page, 'accounts', 'northstar-account-3', 'nickname').dblclick();
  await input.fill('Filtered away');
  await listView(page, 'accounts').getByRole('combobox', { name: 'Status' }).selectOption('closed');
  await expect(editor(page)).toHaveAttribute('data-anchor-state', 'absent');
  await expect(editor(page)).toContainText('not in the current results');
  await expect(editor(page).getByRole('button', { name: 'Scroll to row' })).toHaveCount(0);
  await shot(page, info, 'grid-5-owner-filtered-away');
  await editor(page).getByRole('button', { name: 'Keep as draft' }).click();
  await expect(page.getByRole('button', { name: 'Changes (1)' })).toBeVisible();
  evidence.browser('editor whose owner left the results offered explicit keep or cancel', { kept: true });
  expect(pageErrors).toEqual([]);
});
