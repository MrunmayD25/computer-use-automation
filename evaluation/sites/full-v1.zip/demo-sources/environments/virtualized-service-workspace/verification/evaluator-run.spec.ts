import { join } from 'node:path';

import { verificationRunStore } from '@computer-use/financial-database/services';

import { startWorkspace } from '../src/server/app.js';
import { filePreferenceStore } from '../src/server/preferences.js';
import { ensureTemplate } from '../test/template.js';
import { loadVerifier } from './evaluator.js';
import { bindingFor, cell, editor, expect, goToRow, openList, PUBLIC_DIRECTORY, renderedIds, row, shot, statusBar, test } from './fixtures.js';

test('an offscreen inline nickname edit inside an isolated verification run passes the database verifier', async ({ page, evidence, pageErrors }, info) => {
  const { startTaskRun, workspaceNicknameContract, workspaceNicknameCase: facts } = await loadVerifier();
  const template = await ensureTemplate();
  const binding = bindingFor(template.bindings, 'northstar');
  const root = info.outputPath('evaluator');
  const session = await startTaskRun({ root, sourcePath: template.path, contract: workspaceNicknameContract(binding) });
  const handle = await startWorkspace({
    store: verificationRunStore(session), bindings: [binding], mode: 'verification', operator: { actorNumbers: ['OP0002'], fixed: true },
    principalKind: 'automation', preferences: filePreferenceStore(join(root, 'preferences.json')), port: 0, publicDirectory: PUBLIC_DIRECTORY,
  });
  let outputs: Record<string, unknown>;
  try {
    await openList(page, handle.origin, 'accounts');
    await expect(page.locator('.context-bar')).toContainText('OP0002');
    await expect(page.locator('.context-bar')).toContainText('Verification run');
    const initial = await renderedIds(page, 'accounts');
    expect(initial).not.toContain(facts.accountId);
    evidence.browser('target not rendered at first', { renderedRows: initial.length, firstRendered: initial.slice(0, 3) });

    await goToRow(page, 'accounts', 159);
    const target = row(page, 'accounts', facts.accountId);
    await expect(target).toHaveAttribute('data-row-label', facts.accountNumber);
    await expect(cell(page, 'accounts', facts.accountId, 'nickname')).toHaveText(facts.nicknameBefore);
    await cell(page, 'accounts', facts.accountId, 'nickname').dblclick();
    await expect(editor(page)).toHaveAttribute('data-editor-for', facts.accountId);
    await expect(editor(page)).toHaveAttribute('data-anchor-state', 'visible');
    await page.getByLabel(`Nickname for ${facts.accountNumber}`).fill(facts.nickname);
    await expect(target).toHaveAttribute('data-row-state', 'draft');

    await goToRow(page, 'accounts', 1);
    await expect(target).toHaveCount(0);
    await expect(editor(page)).toHaveAttribute('data-anchor-state', 'absent');
    await expect(editor(page)).toHaveAttribute('data-editor-for', facts.accountId);
    await expect(editor(page)).toContainText(`Your edit is kept on ${facts.accountNumber} only.`);
    const draftedElsewhere = await page.locator('.grid-scroller [data-row-state]').count();
    expect(draftedElsewhere).toBe(0);
    evidence.browser('editor docked after its row was recycled', { anchorState: 'absent', rowsWithDraftMarker: draftedElsewhere, rendered: (await renderedIds(page, 'accounts')).slice(0, 3) });
    await shot(page, info, 'evaluator-1-docked-editor');

    await editor(page).getByRole('button', { name: 'Scroll to row' }).click();
    await expect(target).toBeVisible();
    await expect(editor(page)).toHaveAttribute('data-anchor-state', 'visible');
    await page.getByLabel(`Nickname for ${facts.accountNumber}`).press('Control+Enter');
    const notice = statusBar(page).getByRole('button', { name: /^View receipt RCP\d{8}$/u });
    await expect(notice).toBeVisible();
    await expect(statusBar(page)).toContainText(`${facts.accountNumber} saved.`);
    const receiptNumber = (await notice.innerText()).replace('View receipt ', '');
    await expect(cell(page, 'accounts', facts.accountId, 'nickname')).toHaveText(facts.nickname);
    await shot(page, info, 'evaluator-2-saved');

    await notice.click();
    const receipt = page.locator(`[data-record-kind="receipt"][data-record-id="${receiptNumber}"]`);
    await expect(receipt).toBeVisible();
    await expect(receipt).toContainText(facts.accountNumber);
    evidence.browser('ui-receipt', { receiptNumber, gridNickname: facts.nickname, receiptShowsAccount: facts.accountNumber });
    await shot(page, info, 'evaluator-3-receipt');
    outputs = { accountNumber: facts.accountNumber, nickname: facts.nickname, receiptNumber };
    expect(pageErrors).toEqual([]);
  } finally {
    await handle.close();
  }

  const operations = session.read((database) => database.prepare('SELECT actor_id, operation_kind, status FROM operations WHERE dataset_id=? AND business_reference=? AND operation_kind=?').all(binding.datasetId, facts.accountNumber, 'account.nickname.update'));
  expect(operations).toEqual([{ actor_id: facts.actorId, operation_kind: 'account.nickname.update', status: 'committed' }]);
  evidence.database('run still readable after the application closed', { operations });

  const reportPath = join(root, 'report.json');
  const report = await session.verify({ disposition: 'completed', outputs }, { reportPath, dispose: true });
  session.close();
  const failing = report.checks.filter((check) => check.status !== 'pass');
  evidence.database('verifier report', { reportPath, databaseVerdict: report.databaseVerdict, checks: report.checks.length, failing, capturedBindings: report.capturedBindings });
  await info.attach('verifier-report', { path: reportPath, contentType: 'application/json' });
  expect(failing).toEqual([]);
  expect(report.databaseVerdict).toBe('pass');
});
