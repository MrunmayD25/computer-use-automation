import { expect, type Locator, type Page } from '@playwright/test';

import {
  CATALOG, WORKFLOW_STEPS, evidencePath, populateVisibleControls, qualificationRecord, sourceSha, writeEvidence,
} from '../../../evaluation/browser-qualification.mjs';
import { INQUIRIES, OPERATIONS } from '../src/client/ops/registry.js';
import { grid, listView, openList, test } from './fixtures.js';

const APPLICATION_ID = 'virtualized-service-workspace';
const SHARD_SIZE = 12;
const shard = (): number => Number(process.env.VSW_QUAL_SHARD ?? '0');
const runId = (): string => process.env.VSW_QUAL_RUN ?? `full-v1-${sourceSha().slice(0, 7)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
const command = (): string => `VSW_QUAL_SHARD=${String(shard())} VSW_QUAL_RUN=${runId()} npx playwright test -c verification/playwright.config.ts verification/full-v1.browser.ts`;

test.describe.configure({ timeout: 600_000 });

type ListName = Parameters<typeof openList>[2];

function listFor(capability: string): ListName {
  if (capability.startsWith('member.') || capability.startsWith('consent.') || capability.startsWith('communication.preference')) return 'members';
  if (capability.startsWith('account.') || capability.startsWith('cash.') || capability.startsWith('transfer.') || capability.startsWith('transaction.') || capability.includes('statement')) return 'accounts';
  if (capability.startsWith('case.')) return 'cases';
  if (capability.startsWith('document.')) return 'documents';
  if (capability.startsWith('beneficiary.')) return 'beneficiaries';
  if (capability.startsWith('payment.schedule') || capability.startsWith('payment.occurrence')) return 'schedules';
  if (capability.startsWith('payment.')) return 'payments';
  if (capability.startsWith('card.')) return 'cards';
  if (capability.startsWith('dispute.')) return 'disputes';
  if (capability.startsWith('loan.')) return 'loans';
  if (capability.startsWith('batch.')) return 'batches';
  if (capability.includes('suspense')) return 'suspense';
  if (capability.includes('settlement')) return 'settlements';
  if (capability.startsWith('maintenance.')) return 'maintenance';
  if (capability.startsWith('approval.')) return 'approvals';
  if (capability.startsWith('communication.')) return 'communications';
  return 'activity';
}

interface SessionProfile { operator: { profiles: Record<string, { commands: string[] } | null> } }

async function signOnForCapability(page: Page, capability: string): Promise<void> {
  for (const actorNumber of ['OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0001']) {
    const session = await page.evaluate(async (candidate): Promise<SessionProfile> => {
      await fetch('/api/session/operator', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ actorNumber: candidate }) });
      return fetch('/api/session').then(async (response) => response.json() as Promise<SessionProfile>);
    }, actorNumber);
    if (session.operator.profiles.northstar?.commands.includes(capability) === true) {
      await page.reload();
      await expect(page.locator('.context-bar')).toContainText(actorNumber);
      return;
    }
  }
}

async function openOperation(page: Page, title: string): Promise<Locator> {
  await page.getByRole('button', { name: 'All operations' }).click();
  await page.getByRole('menu', { name: 'Operations' }).getByRole('menuitem', { name: title, exact: true }).click();
  const dialog = page.getByRole('dialog', { name: title });
  await expect(dialog).toBeVisible();
  return dialog;
}

async function exerciseCapability(page: Page, origin: string, capability: string): Promise<{ entry: string; action: string; result: string }> {
  await page.goto(`${origin}/northstar/members`);
  await signOnForCapability(page, capability);
  const spec = OPERATIONS.find(candidate => candidate.kind === capability) ?? INQUIRIES.find(candidate => candidate.kind === capability);
  if (spec !== undefined) {
    const dialog = await openOperation(page, spec.title);
    const entry = await dialog.innerText();
    const action = await populateVisibleControls(dialog);
    const button = dialog.getByRole('button', { name: OPERATIONS.some(candidate => candidate.kind === capability) ? /review|submit|create|update|record|apply|close|send|save/i : 'Check' }).filter({ visible: true }).first();
    if (await button.isVisible().catch(() => false)) await button.click();
    await page.waitForTimeout(100);
    const result = await dialog.isVisible().catch(() => false) ? await dialog.innerText() : await page.locator('main').innerText();
    return { entry, action, result };
  }
  const list = listFor(capability);
  await openList(page, origin, list);
  const view = listView(page, list);
  const entry = await view.innerText();
  const action = await populateVisibleControls(view);
  const first = grid(page, list).locator('[data-row-id]').first();
  if (await first.isVisible().catch(() => false)) await first.click();
  return { entry, action: action || `opened and exercised the ${list} work list`, result: await view.innerText() };
}

test('qualifies canonical task options through populated virtualized controls', async ({ page, workspace }, info) => {
  const selected = CATALOG.slice(shard() * SHARD_SIZE, (shard() + 1) * SHARD_SIZE);
  test.skip(selected.length === 0, 'empty task shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `capability-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const task of selected) {
    const observation = await exerciseCapability(page, workspace.origin, task.capability);
    records.push(qualificationRecord({
      applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${task.capability}]`, artifact,
      identity: { task: task.id, capability: task.capability, option: task.capability }, visibleEntry: observation.entry, action: observation.action,
      visibleResult: observation.result, businessEffect: 'The populated operation dialog, inquiry, record action, or virtualized work list produced a visible result or operation-specific refusal.',
      recovery: 'The persistent tabs, list route, and dialog state let the operator correct the input or reopen the record without replaying a hidden write.',
    }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'capabilities.json', records, { shard: shard() });
});

test('qualifies workflow catalog and recovery branches through virtualized controls', async ({ page, workspace }, info) => {
  const selected = Object.entries(WORKFLOW_STEPS).slice(shard() * 4, (shard() + 1) * 4);
  test.skip(selected.length === 0, 'empty workflow shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `workflow-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const [workflow, steps] of selected) {
    const results: string[] = [];
    for (const step of steps) results.push(`${step}\n${(await exerciseCapability(page, workspace.origin, step)).result}`);
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} catalog path]`, artifact,
      identity: { workflow, branch: 'catalog-path' }, visibleEntry: `Traversed ${steps.join(' → ')} through operation dialogs, persistent lists, and record tabs.`, visibleResult: results.join('\n--- next visible step ---\n'),
      businessEffect: 'Every workflow step reached a populated visible operation, inquiry, or record work surface.', recovery: 'Routes and persistent tabs preserve a safe path back to each step.' }));
    const recovery = await exerciseCapability(page, workspace.origin, steps.at(-1) ?? 'activity.inspect');
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} recovery]`, artifact,
      identity: { workflow, branch: 'recovery' }, visibleEntry: `Reopened ${steps.at(-1) ?? 'activity.inspect'} through the workspace.`, action: recovery.action, visibleResult: recovery.result,
      businessEffect: 'The final work surface reopened with a fresh institution-bound view.', recovery: 'The operator can correct and review again without duplicating an earlier result.' }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'workflows.json', records, { shard: shard() });
});

async function openMember(page: Page, origin: string, memberNumber: string): Promise<Locator> {
  await openList(page, origin, 'members');
  const search = listView(page, 'members').getByRole('searchbox', { name: 'Search members' });
  await search.fill(memberNumber); await search.press('Enter');
  const match = grid(page, 'members').locator(`[data-row-label="${memberNumber}"]`);
  await expect(match).toBeVisible(); await match.locator('[data-col="member_number"]').dblclick();
  const record = page.locator('.record-host:not([hidden]) [data-record-kind="member"]');
  await expect(record).toContainText(memberNumber); return record;
}

test('qualifies virtualized family and shared-world boundaries', async ({ browser, page, workspace }, info) => {
  test.skip(shard() !== 0, 'recorded once');
  await openList(page, workspace.origin, 'members');
  const total = await listView(page, 'members').locator('[data-total]').getAttribute('data-total');
  const rendered = await grid(page, 'members').locator('[data-row-id]').count();
  const familyArtifact = evidencePath(APPLICATION_ID, runId(), 'family-mechanism.json');
  writeEvidence(APPLICATION_ID, runId(), 'family-mechanism.json', [qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [family]`, artifact: familyArtifact,
    identity: { mechanism: 'virtualized-spa' }, visibleEntry: await listView(page, 'members').innerText(), visibleResult: `total=${total ?? 'unknown'}; rendered DOM rows=${String(rendered)}; route=${page.url()}`,
    businessEffect: 'The workspace exposed a larger institution-bound result set through a bounded virtual grid, persistent route, and reusable tab surface.', recovery: 'The URL, tabs, and go-to-row controls restore position without materializing the entire result set.' })]);

  const peer = await browser.newPage();
  const firstRecord = await openMember(page, workspace.origin, 'NM000002');
  const peerRecord = await openMember(peer, workspace.origin, 'NM000002');
  await firstRecord.getByRole('button', { name: 'Edit contact…' }).click();
  const firstDialog = page.getByRole('dialog');
  await firstDialog.getByLabel('Email').fill('held-virtual@example.test');
  await peerRecord.getByRole('button', { name: 'Edit contact…' }).click();
  const peerDialog = peer.getByRole('dialog');
  await peerDialog.getByLabel('Email').fill('peer-virtual@example.test');
  await peerDialog.getByRole('button', { name: 'Save contact' }).click();
  await expect(peerDialog.locator('[data-flow-step]')).toHaveAttribute('data-flow-step', 'done');
  const peerResult = await peerDialog.innerText();
  await firstDialog.getByRole('button', { name: 'Save contact' }).click();
  await expect(firstDialog.getByRole('alert')).toContainText(/changed|version|current values/iu);
  await expect(firstDialog.locator('[data-flow-step]')).toHaveAttribute('data-flow-step', 'edit');
  const staleResult = await firstDialog.innerText();
  await firstDialog.getByRole('button', { name: 'Close' }).click().catch(() => undefined);
  const refreshed = await openMember(page, workspace.origin, 'NM000002');
  await expect(refreshed.locator('[data-field="email"]')).toHaveText('peer-virtual@example.test');
  const peerVisible = await refreshed.innerText();
  await openList(page, workspace.origin, 'members');
  const foreign = listView(page, 'members').getByRole('searchbox', { name: 'Search members' });
  await foreign.fill('SR000001'); await foreign.press('Enter');
  await expect(listView(page, 'members').locator('[data-total]')).toHaveAttribute('data-total', '0');
  const isolationResult = await listView(page, 'members').innerText();

  const sharedArtifact = evidencePath(APPLICATION_ID, runId(), 'shared-world.json');
  const common = { applicationId: APPLICATION_ID, runId: runId(), command: command(), artifact: sharedArtifact };
  writeEvidence(APPLICATION_ID, runId(), 'shared-world.json', [
    qualificationRecord({ ...common, test: `${info.title} [peer visibility]`, identity: { shared_world_check: 'peer_visibility' }, visibleEntry: peerResult, visibleResult: peerVisible, businessEffect: 'A peer workspace page committed contact data that the first page then reread through the member record.', recovery: 'The refreshed record exposes the durable peer result without replaying it.' }),
    qualificationRecord({ ...common, test: `${info.title} [stale rejection]`, identity: { shared_world_check: 'stale_rejection' }, visibleEntry: 'Two contact dialogs held edits from the same member version.', visibleResult: staleResult, businessEffect: 'The older dialog was explicitly rejected after the peer committed.', recovery: 'The rejected dialog preserves the failure and requires a current record reread.' }),
    qualificationRecord({ ...common, test: `${info.title} [institution isolation]`, identity: { shared_world_check: 'institution_isolation' }, visibleEntry: 'The Northstar virtual member grid was searched for SR000001.', visibleResult: isolationResult, businessEffect: 'The Northstar list returned zero foreign-institution rows.', recovery: 'The route stayed bound to Northstar and did not fall back across institutions.' }),
  ]);
  await peer.close();
});
