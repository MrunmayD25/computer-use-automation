import { createHash } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, statSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

/** The shared demonstration database. Verification only ever copies the small test template, never this file. */
const CANONICAL = resolve(import.meta.dirname, '..', '..', 'database', 'financial', '.runtime', 'financial.sqlite');

interface Fingerprint { path: string; bytes: number; modifiedMs: number; sha256: string }

async function fingerprint(path: string): Promise<Fingerprint> {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk as Buffer);
  const stat = statSync(path);
  return { path, bytes: stat.size, modifiedMs: stat.mtimeMs, sha256: hash.digest('hex') };
}

/** Fingerprints the canonical database before the run and returns a teardown that fails the run if it changed. */
export default async function canonicalGuard(): Promise<(() => Promise<void>) | undefined> {
  if (!existsSync(CANONICAL)) return undefined;
  const before = await fingerprint(CANONICAL);
  return async () => {
    const after = await fingerprint(CANONICAL);
    const directory = join(import.meta.dirname, 'artifacts', process.env.VSW_VERIFICATION_RUN ?? 'unnamed');
    mkdirSync(directory, { recursive: true });
    const unchanged = before.sha256 === after.sha256 && before.bytes === after.bytes;
    writeFileSync(join(directory, 'canonical-database.json'), `${JSON.stringify({ unchanged, before, after }, null, 2)}\n`);
    if (!unchanged) throw new Error(`The canonical database ${CANONICAL} changed during verification.`);
  };
}
