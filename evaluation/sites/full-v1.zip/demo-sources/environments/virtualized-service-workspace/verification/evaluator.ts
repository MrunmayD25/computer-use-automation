import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

import type { DatasetBinding } from '@computer-use/financial-database';
import type { VerificationRun } from '@computer-use/financial-database/verification';

/** The evaluator owns grading definitions; this module only types the parts browser verification calls. */
const VERIFIER_DIRECTORY = resolve(import.meta.dirname, '..', '..', '..', 'evaluation', 'verifier');

export interface VerifierCheck { id: string; status: string; requirementId?: string; message?: string; actual?: unknown; expected?: unknown }

export interface VerifierReport {
  runId: string;
  databaseVerdict: string;
  overallTaskVerdict: string;
  checks: VerifierCheck[];
  externalRequirements: unknown[];
  capturedBindings?: Record<string, unknown>;
}

export interface TaskRunSession extends Pick<VerificationRun, 'read' | 'write'> {
  descriptor: () => { runId: string; databasePath: string; evidencePath: string };
  verify: (submission: unknown, options: { reportPath: string; dispose: boolean }) => Promise<VerifierReport>;
  dispose: (options: { reportPath: string }) => void;
  close: () => void;
}

export interface NicknameCase {
  accountId: string;
  accountNumber: string;
  nicknameBefore: string;
  nickname: string;
  versionBefore: number;
  actorId: string;
}

interface Verifier {
  startTaskRun: (options: { root: string; sourcePath: string; contract: unknown }) => Promise<TaskRunSession>;
}

interface NicknameQualification {
  workspaceNicknameCase: NicknameCase;
  workspaceNicknameContract: (binding: DatasetBinding) => unknown;
}

export async function loadVerifier(): Promise<Verifier & NicknameQualification> {
  const verifier = await import(pathToFileURL(join(VERIFIER_DIRECTORY, 'index.mjs')).href) as Verifier;
  const nickname = await import(pathToFileURL(join(VERIFIER_DIRECTORY, 'app-qualification', 'virtualized-service-workspace-nickname.mjs')).href) as NicknameQualification;
  return { startTaskRun: verifier.startTaskRun, workspaceNicknameCase: nickname.workspaceNicknameCase, workspaceNicknameContract: nickname.workspaceNicknameContract };
}
