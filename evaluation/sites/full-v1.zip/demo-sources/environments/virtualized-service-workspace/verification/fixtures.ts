import { copyFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';
import { test as base, expect, type Locator, type Page, type TestInfo } from '@playwright/test';

import { startWorkspace, type WorkspaceHandle } from '../src/server/app.js';
import { filePreferenceStore } from '../src/server/preferences.js';
import { ensureTemplate } from '../test/template.js';

export const PUBLIC_DIRECTORY = resolve(import.meta.dirname, '..', 'dist', 'public');

export interface LaunchedWorkspace {
  origin: string;
  /** Path of this test's disposable copy of the template world. */
  databasePath: string;
  bindings: readonly DatasetBinding[];
  datasetId: (institutionId: string) => string;
  /** Read-only query against the disposable copy. */
  query: <T>(sql: string, ...params: SQLInputValue[]) => T[];
}

/** Browser observations and database observations are recorded separately and written per test. */
export interface EvidenceLog {
  browser: (label: string, detail: unknown) => void;
  database: (label: string, detail: unknown) => void;
}

interface Fixtures {
  workspace: LaunchedWorkspace;
  evidence: EvidenceLog;
  /** Uncaught exceptions and console errors, excluding the browser's own log line for an expected 4xx response. */
  pageErrors: string[];
}

export function bindingFor(bindings: readonly DatasetBinding[], institutionId: string): DatasetBinding {
  const binding = bindings.find((item) => item.institutionId === institutionId);
  if (binding === undefined) throw new Error(`The template world has no ${institutionId} dataset.`);
  return binding;
}

export const test = base.extend<Fixtures>({
  workspace: async ({ browserName: _browserName }, use) => {
    const template = await ensureTemplate();
    const directory = mkdtempSync(join(tmpdir(), 'vsw-verify-'));
    const path = join(directory, 'financial.sqlite');
    let handle: WorkspaceHandle | undefined;
    try {
      copyFileSync(template.path, path);
      const store = openFinancialStore({ path });
      handle = await startWorkspace({
        store, bindings: template.bindings, mode: 'shared', operator: { actorNumbers: ['OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0001'], fixed: false },
        preferences: filePreferenceStore(join(directory, 'preferences.json')), port: 0, publicDirectory: PUBLIC_DIRECTORY, onClose: () => { store.close(); },
      });
      await use({
        origin: handle.origin,
        databasePath: path,
        bindings: template.bindings,
        datasetId: (institutionId) => bindingFor(template.bindings, institutionId).datasetId,
        query<T>(sql: string, ...params: SQLInputValue[]): T[] {
          using database = new DatabaseSync(path, { readOnly: true });
          return database.prepare(sql).all(...params) as T[];
        },
      });
    } finally {
      await handle?.close();
      rmSync(directory, { recursive: true, force: true });
    }
  },
  evidence: async ({ browserName: _browserName }, use, info) => {
    const browser: { label: string; detail: unknown }[] = [];
    const database: { label: string; detail: unknown }[] = [];
    await use({ browser: (label, detail) => { browser.push({ label, detail }); }, database: (label, detail) => { database.push({ label, detail }); } });
    const path = info.outputPath('evidence.json');
    writeFileSync(path, `${JSON.stringify({ test: info.titlePath.slice(1), status: info.status, browser, database }, null, 2)}\n`);
    await info.attach('evidence', { path, contentType: 'application/json' });
  },
  pageErrors: async ({ page }, use) => {
    const errors: string[] = [];
    page.on('pageerror', (error) => { errors.push(error.message); });
    page.on('console', (message) => { if (message.type() === 'error' && !message.text().startsWith('Failed to load resource')) errors.push(message.text()); });
    await use(errors);
  },
});

export { expect };

export async function shot(page: Page, info: TestInfo, name: string): Promise<void> {
  const path = info.outputPath(`${name}.png`);
  await page.screenshot({ path });
  await info.attach(name, { path, contentType: 'image/png' });
}

export type ListName = 'members' | 'accounts' | 'cases' | 'documents' | 'activity'
  | 'payments' | 'schedules' | 'beneficiaries' | 'cards' | 'disputes' | 'loans' | 'fees' | 'holds' | 'maintenance'
  | 'communications' | 'approvals' | 'batches' | 'suspense' | 'settlements';
const TITLES: Record<ListName, string> = {
  members: 'Members', accounts: 'Accounts', cases: 'Cases', documents: 'Documents', activity: 'Activity',
  payments: 'Payments', schedules: 'Payment schedules', beneficiaries: 'Beneficiaries', cards: 'Cards', disputes: 'Disputes', loans: 'Loans', fees: 'Fees', holds: 'Holds', maintenance: 'Maintenance requests',
  communications: 'Communications', approvals: 'Approvals', batches: 'Batches', suspense: 'Suspense items', settlements: 'Settlement batches',
};

export const listView = (page: Page, list: ListName): Locator => page.locator(`section.list-view[data-list="${list}"]`);
export const grid = (page: Page, list: ListName): Locator => page.locator(`.grid-scroller[data-grid-key="list-${list}"]`);
export const row = (page: Page, list: ListName, id: string): Locator => grid(page, list).locator(`[data-row-id="${id}"]`);
export const cell = (page: Page, list: ListName, id: string, column: string): Locator => row(page, list, id).locator(`[data-col="${column}"]`);
export const renderedIds = (page: Page, list: ListName): Promise<string[]> =>
  grid(page, list).locator('[data-row-id]').evaluateAll((nodes) => nodes.map((node) => node.getAttribute('data-row-id') ?? ''));
export const headerColumns = (page: Page, list: ListName): Promise<string[]> =>
  grid(page, list).locator('.grid-header [data-header-col]').evaluateAll((nodes) => nodes.map((node) => node.getAttribute('data-header-col') ?? ''));
export const statusBar = (page: Page): Locator => page.locator('footer.status-bar');
export const editor = (page: Page): Locator => page.locator('.cell-editor');

export async function openList(page: Page, origin: string, list: ListName, institutionId = 'northstar'): Promise<void> {
  await page.goto(`${origin}/${institutionId}/${list}`);
  await expect(page.getByRole('grid', { name: `${TITLES[list]} results` })).toBeVisible();
  await expect(grid(page, list).locator('[data-row-id]').first()).toBeVisible();
}

/** Scrolls a list with its "Go to row" control, as an operator would, and waits for the row to render. */
export async function goToRow(page: Page, list: ListName, rowNumber: number): Promise<void> {
  const input = listView(page, list).getByLabel('Go to row');
  await input.fill(String(rowNumber));
  await input.press('Enter');
  await expect(grid(page, list).locator(`[aria-rowindex="${String(rowNumber + 1)}"][data-row-id]`)).toBeVisible();
}
