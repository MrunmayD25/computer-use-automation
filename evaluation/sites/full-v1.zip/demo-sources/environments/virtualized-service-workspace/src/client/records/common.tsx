import type { ActivityRow, PageResult } from '@computer-use/financial-database/services';
import { useCallback, useEffect, useState, type ReactNode } from 'react';

import { download, getJson, institutionPath, listRecords, queryString, type FinanceListRow } from '../api.js';
import { useColumnLayout } from '../grid/useColumnLayout.js';
import { VirtualGrid } from '../grid/VirtualGrid.js';
import type { ActivityGridRow } from '../lists/cells.js';
import { renderCell } from '../lists/cells.js';
import { useFlatRows } from '../lists/sources.js';
import { formatInstant, label } from '../format.js';
import { INQUIRIES, operationFor } from '../ops/registry.js';
import type { OperationContext } from '../ops/OperationDialog.js';
import { useShell, type RecordContext } from '../shell.js';
import { useStamp, useWorkspace, type StampKind } from '../workspace.js';

export function Panel({ title, actions, children, className }: { title: string; actions?: ReactNode; children: ReactNode; className?: string }): ReactNode {
  return (
    <section className={`panel${className === undefined ? '' : ` ${className}`}`} aria-label={title}>
      <header className="panel-header"><h3>{title}</h3>{actions}</header>
      <div className="panel-body">{children}</div>
    </section>
  );
}

/** Reload key of a record tab: changes after local commits and when the record changes elsewhere. */
export function useRecordRefresh(kind: StampKind, id: string): string {
  const { dataVersion } = useWorkspace();
  const stamp = useStamp(kind, id);
  return `${String(dataVersion)}:${stamp?.stamp ?? ''}`;
}

export function usePublishContext(tabKey: string, context: RecordContext | null): void {
  const { publishContext } = useShell();
  const serialized = JSON.stringify(context);
  useEffect(() => { publishContext(tabKey, JSON.parse(serialized) as RecordContext | null); }, [publishContext, tabKey, serialized]);
  useEffect(() => () => publishContext(tabKey, null), [publishContext, tabKey]);
}

export function useDownload(): (path: string) => void {
  const { notify } = useWorkspace();
  return useCallback((path: string) => {
    download(path).then(
      (result) => notify('success', `Downloaded ${result.filename}${result.digest === null ? '' : ` (SHA-256 ${result.digest.slice(0, 12)}…)`}.`),
      (error: unknown) => notify('error', `Download failed: ${error instanceof Error ? error.message : String(error)}`),
    );
  }, [notify]);
}

/** Opens a registry operation or inquiry dialog by kind, binding command fields from context. */
export function useOpenOperation(): (kind: string, context?: Record<string, unknown>) => void {
  const { openDialog } = useShell();
  return useCallback((kind, initial = {}) => {
    const spec = operationFor(kind) ?? INQUIRIES.find((inquiry) => inquiry.kind === kind);
    if (spec === undefined) return;
    const context: OperationContext = { initial };
    for (const key of ['memberId', 'accountId', 'caseId', 'currency'] as const) {
      const value = initial[key];
      if (typeof value === 'string' && value !== '') context[key] = value;
    }
    openDialog({ kind: 'operation', spec, inquiry: !operationFor(kind), context });
  }, [openDialog]);
}

/** A bounded, scoped read of one finance/servicing resource under a parent, member, or account. */
export function ScopedRecords({ resource, scope, title, onOpen }: {
  resource: string;
  scope: { memberId?: string; accountId?: string; parentId?: string };
  title: string;
  onOpen?: (resource: string, id: string) => void;
}): ReactNode {
  const { institution, dataVersion } = useWorkspace();
  const { openRecord } = useShell();
  const [rows, setRows] = useState<FinanceListRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const scopeKey = JSON.stringify(scope);
  useEffect(() => {
    let live = true;
    setRows(null);
    void listRecords(institution.institutionId, resource, { ...scope, limit: 100 }).then(
      (page) => { if (live) { setRows(page.items); setError(null); } },
      (cause: unknown) => { if (live) { setRows([]); setError(cause instanceof Error ? cause.message : String(cause)); } },
    );
    return () => { live = false; };
  }, [institution.institutionId, resource, scopeKey, dataVersion]);
  const open = onOpen ?? ((target: string, id: string) => openRecord('resource', id, target));
  return (
    <Panel title={`${title}${rows === null ? '' : ` (${String(rows.length)})`}`} className="child-list">
      {error !== null ? <p className="error">{error}</p> : null}
      <table className="plain clickable">
        <tbody>
          {(rows ?? []).map((row) => (
            <tr key={row.id} tabIndex={0} data-resource={resource} data-row-id={row.id} onClick={() => open(resource, row.id)} onKeyDown={(event) => { if (event.key === 'Enter') open(resource, row.id); }}>
              <td>{row.label}</td>
              <td>{row.status === null ? '' : <span className={`badge status-${row.status}`}>{label(row.status)}</span>}</td>
              <td className="muted">{['occurredAt', 'createdAt', 'placedAt', 'issuedAt', 'dueAt'].map((key) => row.fields[key]).filter((value) => value !== null && value !== undefined).map((value) => formatInstant(String(value))).join(' · ')}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows !== null && rows.length === 0 ? <p className="muted">None.</p> : null}
    </Panel>
  );
}

/** Committed business events of one record and its children, newest first, in an independently scrolling grid. */
export function ActivityPanel({ scope, gridKey }: { scope: { memberId?: string; accountId?: string; caseId?: string }; gridKey: string }): ReactNode {
  const { institution, session, notify, dataVersion } = useWorkspace();
  const { openRecord } = useShell();
  const { layout, apply } = useColumnLayout('activity', session.operator.actorNumber, (message) => notify('error', message));
  const institutionId = institution.institutionId;
  const key = `${institutionId}|${JSON.stringify(scope)}`;
  const { source, snapshot } = useFlatRows<ActivityGridRow>(key, async (offset, limit, signal) => {
    const page = await getJson<PageResult<ActivityRow>>(institutionPath(institutionId, `/activity${queryString({ ...scope, limit, offset })}`), signal);
    return { ...page, items: page.items.map((row) => ({ ...row, id: String(row.sequence) })) };
  }, dataVersion);
  return (
    <Panel title={`Activity${snapshot.total === null ? '' : ` (${snapshot.total.toLocaleString('en-US')})`}`} className="grid-panel">
      <VirtualGrid<ActivityGridRow>
        gridId="activity" gridKey={gridKey} label="Activity history" source={source} layout={layout} onColumnAction={apply} sort={null} sortable={() => false} onSort={() => undefined}
        cell={(row, column) => renderCell('activity', row, column)} rowLabel={(row) => `Event ${String(row.sequence)}`}
        onOpen={(row) => { if (row.receiptNumber !== null) openRecord('receipt', row.receiptNumber); }} emptyText="No activity recorded."
      />
    </Panel>
  );
}
