import type { Receipt } from '@computer-use/financial-database/services';
import type { ReactNode } from 'react';

import { institutionPath } from '../api.js';
import { formatInstant, formatMoney } from '../format.js';
import { tabKeyOf, useShell } from '../shell.js';
import { useResource } from '../useResource.js';
import { useWorkspace } from '../workspace.js';
import { Panel, usePublishContext } from './common.js';

/** A committed operation as stored: receipts are rebuilt from durable rows on every read. */
export function ReceiptRecord({ id }: { id: string }): ReactNode {
  const { institution, reference } = useWorkspace();
  const { openRecord } = useShell();
  const institutionId = institution.institutionId;
  const { data, error } = useResource<Receipt>(institutionPath(institutionId, `/receipts/${encodeURIComponent(id)}`));
  usePublishContext(tabKeyOf(institutionId, 'receipt', id), data === undefined ? null : { title: data.receiptNumber, member: null, account: null });
  if (data === undefined) return <div className="record-loading">{error ?? 'Loading receipt…'}</div>;
  const exponent = (currency: string): number => reference?.currencies.find((item) => item.code === currency)?.exponent ?? 2;
  return (
    <article className="record" data-record-kind="receipt" data-record-id={id}>
      <header className="record-header">
        <div>
          <h2>Receipt <code>{data.receiptNumber}</code></h2>
          <p className="muted"><code>{data.operationKind}</code> · {data.status} · committed {formatInstant(data.committedAt)} by {data.actor.displayName} ({data.actor.actorNumber}) · reference {data.businessReference}</p>
        </div>
      </header>
      <div className="record-panels">
        <Panel title="Affected records">
          <ul className="link-list">
            {data.affected.map((item) => (
              <li key={`${item.kind}-${item.id}`}>
                {item.kind === 'member' || item.kind === 'account' || item.kind === 'case'
                  ? <button type="button" className="link" onClick={() => openRecord(item.kind as 'member' | 'account' | 'case', item.id)}>{item.kind} {item.label}</button>
                  : <span>{item.kind} {item.label}</span>}
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Business events">
          <ol className="timeline">{data.events.map((event) => <li key={event.sequence}><code>{event.kind}</code> · {event.summary}</li>)}</ol>
        </Panel>
        {data.journals.map((journal) => (
          <Panel key={journal.id} title={`Journal ${journal.reference}`} className="wide-panel">
            <p className="muted">{journal.description} · effective {journal.effectiveDate}</p>
            <table className="plain">
              <thead><tr><th>#</th><th>Ledger</th><th>Account</th><th className="end">Debit</th><th className="end">Credit</th><th>Memo</th></tr></thead>
              <tbody>
                {journal.lines.map((line) => (
                  <tr key={line.lineNumber}>
                    <td>{line.lineNumber}</td><td>{line.ledgerCode}</td><td>{line.accountNumber ?? '—'}</td>
                    <td className="money end">{line.debitMinorUnits === 0 ? '' : formatMoney(line.debitMinorUnits, line.currency, exponent(line.currency))}</td>
                    <td className="money end">{line.creditMinorUnits === 0 ? '' : formatMoney(line.creditMinorUnits, line.currency, exponent(line.currency))}</td>
                    <td>{line.memo}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Panel>
        ))}
      </div>
    </article>
  );
}
