import type { AccountDetail, DocumentRow, PageResult, TransactionRow } from '@computer-use/financial-database/services';
import { useState, type ReactNode } from 'react';

import { getJson, institutionPath, queryString } from '../api.js';
import { formatDate, formatMoney, label } from '../format.js';
import { useColumnLayout } from '../grid/useColumnLayout.js';
import { VirtualGrid } from '../grid/VirtualGrid.js';
import { renderCell, type TransactionGridRow } from '../lists/cells.js';
import { useFlatRows } from '../lists/sources.js';
import { draftKey } from '../model/drafts.js';
import { parseMoney } from '../model/money.js';
import type { SortState } from '../model/route.js';
import { tabKeyOf, useShell } from '../shell.js';
import { useResource } from '../useResource.js';
import { useWorkspace } from '../workspace.js';
import { ActivityPanel, Panel, ScopedRecords, useDownload, useOpenOperation, usePublishContext, useRecordRefresh } from './common.js';

interface TransactionFilters { startDate: string; endDate: string; direction: string; status: string; minAmount: string; maxAmount: string; text: string; reference: string }

/** Server query for the panel's filters, with amount bounds converted to exact minor units. */
function transactionQuery(filters: TransactionFilters, exponent: number): Record<string, string | number> | { error: string } {
  const { minAmount, maxAmount, ...rest } = filters;
  const query: Record<string, string | number> = { ...rest };
  for (const [key, text, name] of [['minMinorUnits', minAmount, 'from'], ['maxMinorUnits', maxAmount, 'to']] as const) {
    if (text.trim() === '') continue;
    const parsed = parseMoney(text, exponent);
    if (!parsed.ok) return { error: `Amount ${name}: ${parsed.message}` };
    query[key] = parsed.minorUnits;
  }
  return query;
}

function TransactionsPanel({ detail }: { detail: AccountDetail }): ReactNode {
  const { institution, session, notify, dataVersion } = useWorkspace();
  const { openRecord } = useShell();
  const save = useDownload();
  const { account } = detail;
  const institutionId = institution.institutionId;
  const { layout, apply } = useColumnLayout('transactions', session.operator.actorNumber, (message) => notify('error', message));
  const [filters, setFilters] = useState({ startDate: '', endDate: '', direction: '', status: '', minAmount: '', maxAmount: '', text: '', reference: '' });
  const [sort, setSort] = useState<SortState | null>({ field: 'effective_date', direction: 'desc' });
  const order = sort?.direction === 'asc' ? 'oldest' : 'newest';
  const path = institutionPath(institutionId, `/accounts/${encodeURIComponent(account.id)}`);
  const query = transactionQuery(filters, account.exponent);
  // An amount bound that does not parse is reported and nothing is fetched, rather than silently widening the search.
  const { source, snapshot } = useFlatRows<TransactionGridRow>('error' in query ? null : `${path}|${JSON.stringify(query)}|${order}`, async (offset, limit, signal) => {
    const page = await getJson<PageResult<TransactionRow>>(`${path}/transactions${queryString({ ...('error' in query ? {} : query), order, limit, offset })}`, signal);
    return { ...page, items: page.items.map((row) => ({ ...row, id: `${row.journalId}:${String(row.lineNumber)}`, currency: account.currency, exponent: account.exponent })) };
  }, dataVersion);
  const set = (key: keyof typeof filters, value: string): void => setFilters((previous) => ({ ...previous, [key]: value }));
  return (
    <Panel title={`Transactions${snapshot.total === null ? '' : ` (${snapshot.total.toLocaleString('en-US')})`}`} className="grid-panel wide-panel" actions={
      <button type="button" onClick={() => save(`${path}/transactions.csv${queryString({ startDate: filters.startDate, endDate: filters.endDate })}`)}>Export CSV</button>
    }>
      <div className="toolbar compact">
        <label className="filter">From<input type="date" value={filters.startDate} onChange={(event) => set('startDate', event.target.value)} /></label>
        <label className="filter">Before<input type="date" value={filters.endDate} onChange={(event) => set('endDate', event.target.value)} /></label>
        <label className="filter">Direction<select value={filters.direction} onChange={(event) => set('direction', event.target.value)}><option value="">Both</option><option value="credit">Credits</option><option value="debit">Debits</option></select></label>
        <label className="filter">Status<select value={filters.status} onChange={(event) => set('status', event.target.value)}><option value="">Posted and reversed</option><option value="posted">Posted</option><option value="reversed">Reversed</option></select></label>
        <label className="filter">Amount from<input inputMode="decimal" size={9} value={filters.minAmount} onChange={(event) => set('minAmount', event.target.value)} /></label>
        <label className="filter">to<input inputMode="decimal" size={9} value={filters.maxAmount} onChange={(event) => set('maxAmount', event.target.value)} /></label>
        <label className="filter">Text<input value={filters.text} onChange={(event) => set('text', event.target.value)} /></label>
        <label className="filter">Reference<input value={filters.reference} placeholder="exact" onChange={(event) => set('reference', event.target.value)} /></label>
        {'error' in query ? <span className="error" role="alert">{query.error}</span> : null}
      </div>
      <VirtualGrid<TransactionGridRow>
        gridId="transactions" gridKey={`tx-${account.id}`} label={`Transactions of ${account.accountNumber}`} source={source} layout={layout} onColumnAction={apply}
        sort={sort} sortable={(column) => column === 'effective_date'} onSort={setSort} cell={(row, column) => renderCell('transactions', row, column)} rowLabel={(row) => row.reference}
        onOpen={(row) => { if (row.receiptNumber !== null) openRecord('receipt', row.receiptNumber); }} emptyText="No transactions match."
        rowMenu={(row) => {
          const receiptNumber = row.receiptNumber;
          return [
            { id: 'journal', label: 'Open journal', onSelect: () => openRecord('resource', row.journalId, 'journal') },
            ...(receiptNumber === null ? [] : [{ id: 'receipt', label: 'Open receipt', onSelect: () => openRecord('receipt', receiptNumber) }]),
          ];
        }}
      />
    </Panel>
  );
}

function StatementsPanel({ accountId }: { accountId: string }): ReactNode {
  const { institution } = useWorkspace();
  const save = useDownload();
  const path = institutionPath(institution.institutionId, `/accounts/${encodeURIComponent(accountId)}`);
  const { data } = useResource<{ periods: string[]; documents: DocumentRow[] }>(`${path}/statements`);
  return (
    <Panel title="Statements and documents">
      <h4>Generated statements</h4>
      <ul className="link-list">{(data?.periods ?? []).slice(0, 24).map((period) => <li key={period}><button type="button" className="link" onClick={() => save(`${path}/statement.pdf?period=${period}`)}>Statement {period} (PDF)</button></li>)}</ul>
      <h4>Stored documents</h4>
      <ul className="link-list">{(data?.documents ?? []).map((document) => <li key={document.versionId}><button type="button" className="link" onClick={() => save(institutionPath(institution.institutionId, `/documents/${encodeURIComponent(document.versionId)}/content`))}>{document.displayName}</button> <span className="muted">{label(document.documentType)} · {formatDate(document.issuedAt)} · v{document.version}</span></li>)}</ul>
    </Panel>
  );
}

/** Nickname and statement delivery edits share the record's draft with the account grid. */
function MaintenancePanel({ detail }: { detail: AccountDetail }): ReactNode {
  const { institution, drafts, dispatchDrafts, saveDraft, rebaseDraft, can } = useWorkspace();
  const { openRecord } = useShell();
  const { account } = detail;
  const key = draftKey(institution.institutionId, 'account', account.id);
  const draft = drafts.get(key);
  const locked = draft?.status.phase === 'pending' || draft?.status.phase === 'unknown';
  const inactive = account.status === 'closed' || account.status === 'matured';
  const edit = (field: 'nickname' | 'statement_delivery', value: string): void => dispatchDrafts({
    type: 'edit', institutionId: institution.institutionId, kind: 'account', recordId: account.id, label: account.accountNumber, version: account.version, field, value,
    original: field === 'nickname' ? account.nickname : account.statementDelivery,
  });
  const nickname = draft?.status.phase === 'committed' ? account.nickname : draft?.fields.nickname ?? account.nickname;
  const delivery = draft?.status.phase === 'committed' ? account.statementDelivery : draft?.fields.statement_delivery ?? account.statementDelivery;
  return (
    <Panel title="Maintenance">
      <div className="form">
        <label className="field">Nickname<input value={nickname} maxLength={60} disabled={locked || inactive || !can('account.nickname.update')} onChange={(event) => edit('nickname', event.target.value)} /></label>
        <label className="field">Statement delivery
          <select value={delivery} disabled={locked || inactive || !can('account.statement_delivery.update')} onChange={(event) => edit('statement_delivery', event.target.value)}>
            <option value="electronic">Electronic</option><option value="paper">Paper</option>
          </select>
        </label>
        {draft === undefined ? <p className="muted">No unsaved changes.</p> : (
          <div className="draft-status" data-draft-phase={draft.status.phase}>
            <p>
              {draft.status.phase === 'draft' ? `Draft against version ${String(draft.baseVersion)}.` : null}
              {draft.status.phase === 'pending' ? 'Saving…' : null}
              {draft.status.phase === 'unknown' ? draft.status.message : null}
              {draft.status.phase === 'rejected' ? `Rejected: ${draft.status.message}` : null}
              {draft.status.phase === 'committed' ? 'Saved.' : null}
              {draft.receipts.map((number) => <button key={number} type="button" className="link" onClick={() => openRecord('receipt', number)}> {number}</button>)}
            </p>
            <div className="button-row">
              {draft.status.phase === 'draft' || draft.status.phase === 'rejected' || draft.status.phase === 'unknown'
                ? <button type="button" className="primary" onClick={() => { void saveDraft(key); }}>{draft.status.phase === 'unknown' ? 'Retry save' : 'Save changes'}</button> : null}
              {draft.status.phase === 'rejected' && draft.status.code === 'stale_version' ? <button type="button" onClick={() => { void rebaseDraft(key); }}>Use current version</button> : null}
              {draft.status.phase === 'pending' ? null : <button type="button" onClick={() => dispatchDrafts({ type: 'discard', key })}>{draft.status.phase === 'committed' ? 'Dismiss' : 'Discard'}</button>}
            </div>
          </div>
        )}
      </div>
    </Panel>
  );
}

export function AccountRecord({ id }: { id: string }): ReactNode {
  const { institution, can } = useWorkspace();
  const { openRecord, openDialog } = useShell();
  const openOperation = useOpenOperation();
  const institutionId = institution.institutionId;
  const refresh = useRecordRefresh('accounts', id);
  const { data, error } = useResource<AccountDetail>(institutionPath(institutionId, `/accounts/${encodeURIComponent(id)}`), refresh);
  usePublishContext(tabKeyOf(institutionId, 'account', id), data === undefined ? null : {
    title: data.account.accountNumber, member: { id: data.account.memberId, number: data.account.memberNumber, name: data.account.ownerName },
    account: { id, number: data.account.accountNumber, currency: data.account.currency },
  });
  if (data === undefined) return <div className="record-loading">{error ?? 'Loading account…'}</div>;
  const { account, eligibility } = data;
  const inactive = account.status === 'closed' || account.status === 'matured';
  const money = (minor: number): string => formatMoney(minor, account.currency, account.exponent);
  return (
    <article className="record" data-record-kind="account" data-record-id={id} data-record-version={account.version}>
      <header className="record-header">
        <div>
          <h2>{account.nickname === '' ? account.productName : account.nickname} <code>{account.accountNumber}</code></h2>
          <p className="muted">
            <span className={`badge status-${account.status}`}>{label(account.status)}</span> {account.productName} · owner{' '}
            <button type="button" className="link" onClick={() => openRecord('member', account.memberId)}>{account.ownerName} ({account.memberNumber})</button> · version {account.version}
          </p>
        </div>
        <div className="button-row">
          <button type="button" disabled={inactive || !can('cash.deposit')} onClick={() => openDialog({ kind: 'money', mode: 'deposit', account })}>Deposit…</button>
          <button type="button" disabled={inactive || !can('cash.withdraw')} onClick={() => openDialog({ kind: 'money', mode: 'withdraw', account })}>Withdraw…</button>
          <button type="button" disabled={inactive || !can('transfer.internal')} onClick={() => openDialog({ kind: 'money', mode: 'transfer', account })}>Transfer…</button>
          <button type="button" disabled={inactive || !can('account.close')} title={eligibility.closure.eligible ? undefined : eligibility.closure.reasons.join('; ')} onClick={() => openDialog({ kind: 'account.close', account })}>Close account…</button>
          <button type="button" disabled={!can('case.open')} onClick={() => openDialog({ kind: 'case.open', member: { id: account.memberId, memberNumber: account.memberNumber, displayName: account.ownerName }, accountId: account.id })}>New case…</button>
        </div>
        <div className="button-row secondary-actions" aria-label="Account operations">
          <button type="button" disabled={inactive || !can('account.hold.place')} onClick={() => openOperation('account.hold.place', { accountId: id, expectedVersion: account.version, currency: account.currency })}>Place hold…</button>
          <button type="button" disabled={inactive || !can('account.restriction.apply')} onClick={() => openOperation('account.restriction.apply', { accountId: id, expectedVersion: account.version, memberId: account.memberId })}>Apply restriction…</button>
          <button type="button" disabled={inactive || !can('fee.assess')} onClick={() => openOperation('fee.assess', { accountId: id, expectedVersion: account.version, currency: account.currency, memberId: account.memberId })}>Assess fee…</button>
          <button type="button" disabled={inactive || !can('fee.waiver.create')} onClick={() => openOperation('fee.waiver.create', { accountId: id, currency: account.currency, memberId: account.memberId })}>Fee waiver…</button>
          <button type="button" disabled={inactive || !can('account.product.convert')} onClick={() => openOperation('account.product.convert', { accountId: id, expectedVersion: account.version })}>Convert product…</button>
          <button type="button" disabled={inactive || !can('account.owner.add')} onClick={() => openOperation('account.owner.add', { accountId: id, expectedVersion: account.version })}>Add owner…</button>
          <button type="button" disabled={inactive || !can('account.signer.remove')} onClick={() => openOperation('account.signer.remove', { accountId: id, expectedVersion: account.version })}>Remove signer…</button>
          <button type="button" disabled={inactive || !can('account.overdraft_limit.update')} onClick={() => openOperation('account.overdraft_limit.update', { accountId: id, expectedVersion: account.version, currency: account.currency })}>Overdraft limit…</button>
          <button type="button" disabled={!can('account.maturity.instruct')} onClick={() => openOperation('account.maturity.instruct', { accountId: id, expectedVersion: account.version })}>Maturity instruction…</button>
          <button type="button" disabled={inactive || !can('payment.create')} onClick={() => openOperation('payment.create', { sourceAccountId: id, expectedSourceVersion: account.version, currency: account.currency, memberId: account.memberId })}>New payment…</button>
          <button type="button" disabled={inactive || !can('payment.schedule.create')} onClick={() => openOperation('payment.schedule.create', { sourceAccountId: id, expectedSourceVersion: account.version, currency: account.currency, memberId: account.memberId })}>New schedule…</button>
          <button type="button" disabled={inactive || !can('interest.adjust')} onClick={() => openOperation('interest.adjust', { accountId: id, currency: account.currency, memberId: account.memberId })}>Adjust interest…</button>
        </div>
      </header>
      <div className="record-panels">
        <Panel title="Balances">
          <dl className="facts">
            <dt>Posted</dt><dd className="money" data-field="posted">{money(account.postedMinorUnits)}</dd>
            <dt>Available</dt><dd className="money" data-field="available">{money(account.availableMinorUnits)}</dd>
            <dt>Currency</dt><dd>{account.currency}</dd>
            <dt>Opened</dt><dd>{formatDate(account.openedAt)}</dd>
            {account.closedAt === null ? null : <><dt>Closed</dt><dd>{formatDate(account.closedAt)}</dd></>}
            <dt>Nickname</dt><dd data-field="nickname">{account.nickname === '' ? '—' : account.nickname}</dd>
            <dt>Statements</dt><dd data-field="statement_delivery">{label(account.statementDelivery)}</dd>
            <dt>Debits</dt><dd>{eligibility.debit.eligible ? 'Allowed' : eligibility.debit.reasons.join('; ')}</dd>
            <dt>Credits</dt><dd>{eligibility.credit.eligible ? 'Allowed' : eligibility.credit.reasons.join('; ')}</dd>
            <dt>Closure</dt><dd>{eligibility.closure.eligible ? 'Eligible' : eligibility.closure.reasons.join('; ')}</dd>
          </dl>
          {data.holds.length === 0 && data.restrictions.length === 0 ? null : (
            <ul className="notes">
              {data.holds.map((hold) => <li key={hold.id}>Hold {money(hold.amountMinorUnits)} · {hold.status} · {hold.reason}</li>)}
              {data.restrictions.map((restriction) => <li key={restriction.id}>Restriction {restriction.kind} · {restriction.status} · {restriction.authority}</li>)}
            </ul>
          )}
        </Panel>
        <MaintenancePanel detail={data} />
        <ScopedRecords resource="hold" scope={{ accountId: id }} title="Holds" />
        <ScopedRecords resource="restriction" scope={{ accountId: id }} title="Restrictions" />
        <ScopedRecords resource="facility" scope={{ accountId: id }} title="Facilities" />
        <ScopedRecords resource="maturity-instruction" scope={{ accountId: id }} title="Maturity instructions" />
        <ScopedRecords resource="fee" scope={{ accountId: id }} title="Fees" />
        <ScopedRecords resource="payment" scope={{ accountId: id }} title="Payments" />
        <ScopedRecords resource="payment-schedule" scope={{ accountId: id }} title="Payment schedules" />
        <ScopedRecords resource="card" scope={{ accountId: id }} title="Cards" />
        <ScopedRecords resource="loan" scope={{ accountId: id }} title="Loans" />
        <ScopedRecords resource="dispute" scope={{ accountId: id }} title="Disputes" />
        <ScopedRecords resource="interest-calculation" scope={{ accountId: id }} title="Interest calculations" />
        <ScopedRecords resource="account-party" scope={{ accountId: id }} title="Parties" />
        <ScopedRecords resource="deposit-maturity-term" scope={{ accountId: id }} title="Maturity terms" />
        <TransactionsPanel detail={data} />
        <StatementsPanel accountId={id} />
        <ActivityPanel scope={{ accountId: id }} gridKey={`account-activity-${id}`} />
      </div>
    </article>
  );
}
