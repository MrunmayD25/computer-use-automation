import type { AccountRow, CaseRow, MemberRow, PageResult, Receipt, ServiceCommand } from '@computer-use/financial-database/services';
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

import {
  executeCommand, financeQuery, getJson, institutionPath, listApprovalsApi, listRecords, queryString, readRecord, servicingRead,
  type ApprovalRow,
} from '../api.js';
import { CommandDialog, type BuildResult } from '../commands.js';
import type { NoticeTone } from '../workspace.js';
import { formatInstant, label, text as asText } from '../format.js';
import { parseMoney } from '../model/money.js';
import { Dialog } from '../ui/Dialog.js';
import { useWorkspace } from '../workspace.js';
import type { InquirySpec, OpField, OpSpec } from './registry.js';

/** Values the host view already knows and the dialog may reference as '@name' args or auto fields. */
export interface OperationContext {
  memberId?: string | undefined;
  accountId?: string | undefined;
  caseId?: string | undefined;
  currency?: string | undefined;
  /** Pre-bound command fields (versions, fingerprints, ids). */
  initial?: Record<string, unknown> | undefined;
}

interface Option {
  value: string;
  label: string;
  /** Raw option row fields used by `also` mappings. */
  fields: Record<string, unknown>;
}

type Values = Record<string, unknown>;

function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value !== null && typeof value === 'object') {
    return `{${Object.keys(value as Record<string, unknown>).sort().map((key) => `${JSON.stringify(key)}:${canonical((value as Record<string, unknown>)[key])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

async function toBase64(file: File): Promise<string> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let text = '';
  for (let index = 0; index < bytes.length; index += 0x8000) text += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  return btoa(text);
}

function Field({ label: text, children, hint }: { label: string; children: ReactNode; hint?: string | undefined }): ReactNode {
  return <label className="field">{text}{children}{hint === undefined ? null : <span className="hint">{hint}</span>}</label>;
}

function resolveArg(template: string, values: Values, context: OperationContext): string | undefined {
  if (!template.startsWith('@')) return template;
  const name = template.slice(1);
  const value = values[name] ?? context.initial?.[name] ?? (context as Record<string, unknown>)[name];
  return typeof value === 'string' && value !== '' ? value : undefined;
}

function readArgs(field: OpField, values: Values, context: OperationContext): Record<string, string> | null {
  const args: Record<string, string> = {};
  for (const [key, template] of Object.entries(field.read?.args ?? {})) {
    const value = resolveArg(template, values, context);
    if (value === undefined) return null;
    args[key] = value;
  }
  return args;
}

async function approvalOptions(institutionId: string, commandKind: string | null): Promise<Option[]> {
  const page = await listApprovalsApi(institutionId);
  return page.approvals
    .filter((row) => commandKind === null || (typeof row.target === 'object' && row.target !== null && Reflect.get(row.target, 'kind') === commandKind))
    .map((row) => ({
      value: row.id,
      label: `${row.id} · ${String(typeof row.target === 'object' && row.target !== null ? Reflect.get(row.target, 'kind') : '')} · ${row.status} · expires ${formatInstant(row.expiresAt)}`,
      fields: { fingerprint: row.fingerprint, status: row.status, targetKind: String(typeof row.target === 'object' && row.target !== null ? Reflect.get(row.target, 'kind') : ''), target: row.target },
    }));
}

/** Loads pick options from a servicing reader or a scoped record list. */
function useOptions(institutionId: string, field: OpField, values: Values, context: OperationContext, enabled: boolean): { options: Option[]; loading: boolean; error: string | null } {
  const args = readArgs(field, values, context);
  const argsKey = JSON.stringify(args);
  const [state, setState] = useState<{ key: string; options: Option[]; loading: boolean; error: string | null }>({ key: '', options: [], loading: false, error: null });
  useEffect(() => {
    if (!enabled || field.read === undefined) return undefined;
    const read = field.read;
    if (args === null) { setState({ key: argsKey, options: [], loading: false, error: null }); return undefined; }
    let live = true;
    setState((previous) => previous.key === argsKey ? { ...previous, loading: true } : { key: argsKey, options: [], loading: true, error: null });
    const load = async (): Promise<Option[]> => {
      if (read.reader !== undefined) {
        const result = await servicingRead<unknown>(institutionId, read.reader, args);
        const named = result !== null && typeof result === 'object' && !Array.isArray(result) ? result as Record<string, unknown> : {};
        const items = Array.isArray(result) ? result : named[read.reader.replace('subject-history', 'subjectHistory').replace('identity-evidence', 'identityEvidence')] ?? named.items ?? named.policies ?? [];
        const list = (Array.isArray(items) ? items : []) as Record<string, unknown>[];
        return list.map((item) => {
          const record = item;
          const summary = (record.summary as Record<string, unknown> | undefined) ?? record;
          return {
            value: String(record[field.pickValue ?? 'id'] ?? record.id),
            label: optionLabel(field, { ...summary, ...record }),
            fields: flattenFields(record),
          };
        });
      }
      if (read.resource === 'approval') return approvalOptions(institutionId, null);
      if (read.resource === 'member') {
        const page = await getJson<PageResult<MemberRow>>(institutionPath(institutionId, `/members${queryString({ ...args, limit: 200 })}`));
        return page.items.map((row) => ({ value: row.id, label: `${row.memberNumber} · ${row.displayName}`, fields: { ...row, memberId: row.id } }));
      }
      if (read.resource === 'account') {
        const page = await getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ ...args, limit: 200 })}`));
        return page.items.map((row) => ({ value: row.id, label: `${row.accountNumber} · ${row.ownerName} · ${row.status}`, fields: { ...row } }));
      }
      if (read.resource === 'case') {
        const page = await getJson<PageResult<CaseRow>>(institutionPath(institutionId, `/cases${queryString({ ...args, limit: 200 })}`));
        return page.items.map((row) => ({ value: row.id, label: `${row.caseNumber} · ${row.summary}`, fields: { ...row } }));
      }
      if (read.resource !== undefined) {
        const page = await listRecords(institutionId, read.resource, { ...args, limit: 200 });
        return page.items.map((row) => ({ value: String(row.fields[field.pickValue ?? 'id'] ?? row.id), label: optionLabel(field, row.fields, row), fields: row.fields }));
      }
      return [];
    };
    load().then(
      (options) => { if (live) setState({ key: argsKey, options, loading: false, error: null }); },
      (error: unknown) => { if (live) setState({ key: argsKey, options: [], loading: false, error: error instanceof Error ? error.message : String(error) }); },
    );
    return () => { live = false; };
  }, [institutionId, argsKey, enabled]);
  return { options: state.key === argsKey ? state.options : [], loading: state.key === argsKey && state.loading, error: state.key === argsKey ? state.error : null };
}

function flattenFields(record: Record<string, unknown>): Record<string, unknown> {
  const fields: Record<string, unknown> = { ...record };
  for (const key of ['summary', 'member', 'account', 'destination']) {
    const nested = record[key];
    if (nested !== null && typeof nested === 'object' && !Array.isArray(nested)) Object.assign(fields, nested);
  }
  return fields;
}

function optionLabel(field: OpField, fields: Record<string, unknown>, row?: { label: string }): string {
  const key = field.pickLabel;
  const text = key !== undefined && fields[key] !== undefined && fields[key] !== null && fields[key] !== '' ? asText(fields[key]) : row?.label ?? asText(fields[field.pickValue ?? 'id']);
  const extras = ['id', 'status', 'state'].map((extra) => fields[extra]).filter((value) => typeof value === 'string' && value !== '' && value !== text);
  return `${text}${extras.length === 0 ? '' : ` · ${extras.join(' · ')}`}`;
}

/** Search-as-you-type record picker bound to one command field; `resource` may list several kinds split by '|'. */
function RecordPicker({ institutionId, field, value, onPick, values, context }: {
  institutionId: string; field: OpField; value: string; onPick: (id: string, option: Option | null) => void; values: Values; context: OperationContext;
}): ReactNode {
  const [text, setText] = useState('');
  const [rows, setRows] = useState<Option[]>([]);
  const [open, setOpen] = useState(false);
  const resource = field.resource ?? 'member';
  const scope = readArgs(field, values, context) ?? {};
  useEffect(() => {
    if (!open) return undefined;
    const timer = setTimeout(() => {
      const load = async (): Promise<Option[]> => {
        const resources = resource.split('|');
        if (resources.length === 1 && resource === 'member') {
          const page = await getJson<PageResult<MemberRow>>(institutionPath(institutionId, `/members${queryString({ query: text, limit: 8 })}`));
          return page.items.map((row) => ({ value: row.id, label: `${row.memberNumber} · ${row.displayName} · ${row.status}`, fields: { id: row.id, memberId: row.id, memberNumber: row.memberNumber, displayName: row.displayName, status: row.status } }));
        }
        if (resources.length === 1 && resource === 'account') {
          const page = await getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ query: text, ...scope, limit: 8 })}`));
          return page.items.map((row) => ({ value: row.id, label: `${row.accountNumber} · ${row.ownerName} · ${row.status}`, fields: { ...row } }));
        }
        if (resources.length === 1 && resource === 'case') {
          const page = await getJson<PageResult<CaseRow>>(institutionPath(institutionId, `/cases${queryString({ query: text, limit: 8 })}`));
          return page.items.map((row) => ({ value: row.id, label: `${row.caseNumber} · ${row.summary} · ${row.state}`, fields: { ...row } }));
        }
        const parts = await Promise.all(resources.map(async (item) => {
          if (item === 'account') {
            const page = await getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ query: text, ...scope, limit: 4 })}`));
            return page.items.map((row) => ({ value: row.id, label: `account · ${row.accountNumber} · ${row.ownerName}`, fields: { ...row } }));
          }
          const page = await listRecords(institutionId, item, { query: text, ...scope, limit: 4 });
          return page.items.map((row) => ({ value: row.id, label: `${item} · ${row.label}${row.status === null ? '' : ` · ${row.status}`}`, fields: { id: row.id, ...row.fields } }));
        }));
        return parts.flat();
      };
      load().then(setRows, () => setRows([]));
    }, 200);
    return () => clearTimeout(timer);
  }, [institutionId, resource, text, open, JSON.stringify(scope)]);
  return (
    <div className="picker">
      <input
        aria-label={field.label} placeholder={value === '' ? `Search ${field.label.toLowerCase()}…` : value}
        value={open ? text : value} onFocus={() => { setOpen(true); setText(''); }} onBlur={() => setTimeout(() => setOpen(false), 150)}
        onChange={(event) => { setOpen(true); setText(event.target.value); onPick(event.target.value, null); }}
      />
      {open && rows.length > 0 ? (
        <ul className="picker-options" role="listbox">
          {rows.map((row) => <li key={row.value}><button type="button" role="option" aria-selected={row.value === value} onMouseDown={(event) => { event.preventDefault(); onPick(row.value, row); setOpen(false); }}>{row.label}</button></li>)}
        </ul>
      ) : null}
    </div>
  );
}

interface WidgetProps {
  field: OpField;
  values: Values;
  set: (name: string, value: unknown) => void;
  setMany: (patch: Values) => void;
  institutionId: string;
  context: OperationContext;
  notify: (tone: NoticeTone, text: string) => void;
}

/** Resolves a picked option into the command value and any `also` mappings, fetching fingerprints or party ids as needed. */
function applyPick(props: WidgetProps, field: OpField, option: Option | null): void {
  const patch: Values = {};
  const also = field.also ?? {};
  const pickValue = field.pickValue ?? 'id';
  const finish = (fingerprint: string | null, partyId: string | null): void => {
    if (!(field.name in patch) || patch[field.name] === undefined) {
      patch[field.name] = pickValue === 'fingerprint' ? (fingerprint ?? option?.value ?? '') : pickValue === 'partyId' ? (partyId ?? '') : option === null ? props.values[field.name] : option.value;
    }
    for (const [target, source] of Object.entries(also)) {
      patch[target] = source === 'fingerprint' ? (fingerprint ?? '') : source === 'partyId' ? (partyId ?? '') : option === null ? '' : option.fields[source];
    }
    props.setMany(patch);
  };
  const needsFingerprint = pickValue === 'fingerprint' || Object.values(also).includes('fingerprint');
  const needsParty = pickValue === 'partyId' || Object.values(also).includes('partyId');
  if (option === null) { finish(null, null); return; }
  const fetchParty = needsParty
    ? getJson<{ member: { partyId: string } }>(institutionPath(props.institutionId, `/members/${encodeURIComponent(asText(option.fields.memberId) || option.value)}`)).then((detail) => detail.member.partyId, () => null)
    : Promise.resolve<string | null>(null);
  if (needsFingerprint) {
    const resource = field.read?.resource ?? field.resource;
    const fetchPrint = resource !== undefined && resource !== 'approval' && field.read?.reader === undefined && !resource.includes('|')
      ? readRecord(props.institutionId, resource, option.value).then((snapshot) => snapshot.fingerprint, () => null)
      : Promise.resolve<string | null>(asText(option.fields.fingerprint));
    void Promise.all([fetchPrint, fetchParty]).then(([print, party]) => finish(print, party));
    return;
  }
  void fetchParty.then((party) => finish(null, party));
}

function FieldWidget(props: WidgetProps): ReactNode {
  const { field, values, set, setMany, institutionId, context } = props;
  const { reference } = useWorkspace();
  const raw = values[field.name];
  const name = field.name;
  const str = asText(raw);
  const options = useOptions(institutionId, field, values, context, field.input === 'pick' || (field.input === 'ids' && field.read !== undefined));
  const apply = (option: Option | null): void => applyPick(props, field, option);

  if (field.auto && field.input !== 'json' && field.input !== 'requestedCommand') {
    return <Field label={field.label} hint={field.hint}><input value={str} readOnly disabled aria-readonly="true" className="auto" /></Field>;
  }
  switch (field.input) {
    case 'text': return <Field label={field.label} hint={field.hint}><input value={str} onChange={(event) => set(name, event.target.value)} /></Field>;
    case 'textarea': return <Field label={field.label} hint={field.hint}><textarea rows={3} value={str} onChange={(event) => set(name, event.target.value)} /></Field>;
    case 'int': return <Field label={field.label} hint={field.hint}><input inputMode="numeric" value={str} onChange={(event) => set(name, event.target.value)} /></Field>;
    case 'date': return <Field label={field.label} hint={field.hint}><input type="date" value={str} onChange={(event) => set(name, event.target.value)} /></Field>;
    case 'instant': return <Field label={field.label} hint={field.hint}><input type="datetime-local" step={1} value={str.slice(0, 19)} onChange={(event) => set(name, event.target.value)} /></Field>;
    case 'bool': return <Field label={field.label} hint={field.hint}><input type="checkbox" checked={raw === true} onChange={(event) => set(name, event.target.checked)} /></Field>;
    case 'select': return (
      <Field label={field.label} hint={field.hint}>
        <select value={str} onChange={(event) => set(name, event.target.value)}>
          <option value="">{field.nullable === true || field.optional === true ? '(none)' : 'Choose…'}</option>
          {(field.options ?? []).map((option) => <option key={option} value={option}>{label(option)}</option>)}
        </select>
      </Field>
    );
    case 'money': {
      const moneyValue = (raw ?? {}) as { minorUnits?: unknown; currency?: unknown; amount?: string };
      const currency = typeof moneyValue.currency === 'string' ? moneyValue.currency : context.currency ?? 'USD';
      const amount = typeof moneyValue.amount === 'string' ? moneyValue.amount : '';
      const setPart = (patch: Record<string, unknown>): void => set(name, { ...moneyValue, currency, ...patch });
      return (
        <Field label={field.label} hint={field.hint}>
          <span className="money-input">
            <input inputMode="decimal" value={amount} aria-label={`${field.label} amount`} onChange={(event) => setPart({ amount: event.target.value })} />
            <select aria-label={`${field.label} currency`} value={currency} onChange={(event) => setPart({ currency: event.target.value })}>
              {(reference?.currencies ?? [{ code: currency }]).map((item) => <option key={item.code} value={item.code}>{item.code}</option>)}
            </select>
          </span>
        </Field>
      );
    }
    case 'ids': {
      const current = Array.isArray(raw) ? raw as string[] : [];
      if (field.read !== undefined) {
        return (
          <Field label={field.label} hint={field.hint}>
            {options.loading ? <span className="muted">Loading options…</span> : null}
            {options.error !== null ? <span className="error">{options.error}</span> : null}
            <span className="checkbox-list">
              {options.options.map((option) => (
                <label key={option.value} className="checkbox"><input type="checkbox" checked={current.includes(option.value)}
                  onChange={(event) => set(name, event.target.checked ? [...current, option.value] : current.filter((item) => item !== option.value))} /> {option.label}</label>
              ))}
            </span>
            {options.options.length === 0 && !options.loading ? <input value={current.join(',')} placeholder="Comma-separated ids" onChange={(event) => set(name, event.target.value.split(',').map((item) => item.trim()).filter((item) => item !== ''))} /> : null}
          </Field>
        );
      }
      if (field.options !== undefined) {
        return (
          <Field label={field.label} hint={field.hint}>
            <span className="checkbox-list">
              {field.options.map((option) => (
                <label key={option} className="checkbox"><input type="checkbox" checked={current.includes(option)}
                  onChange={(event) => set(name, event.target.checked ? [...current, option] : current.filter((item) => item !== option))} /> {label(option)}</label>
              ))}
            </span>
          </Field>
        );
      }
      return <Field label={field.label} hint={field.hint}><input value={current.join(',')} placeholder="Comma-separated ids" onChange={(event) => set(name, event.target.value.split(',').map((item) => item.trim()).filter((item) => item !== ''))} /></Field>;
    }
    case 'record': return (
      <Field label={field.label} hint={field.hint}>
        <RecordPicker institutionId={institutionId} field={field} value={str} values={values} context={context} onPick={(id, option) => { if (field.pickValue === 'partyId' || field.also !== undefined || field.pickValue === 'fingerprint') apply(option === null ? null : { ...option, value: id }); else set(name, id); }} />
      </Field>
    );
    case 'pick': return (
      <Field label={field.label} hint={field.hint}>
        <select value={str} disabled={options.loading} onChange={(event) => apply(options.options.find((option) => option.value === event.target.value) ?? null)}>
          <option value="">{options.loading ? 'Loading…' : field.nullable === true || field.optional === true ? '(none)' : 'Choose…'}</option>
          {options.options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
        {options.error !== null ? <span className="error">{options.error}</span> : null}
      </Field>
    );
    case 'address': {
      const address = (raw ?? {}) as Record<string, string>;
      const part = (key: string): string => address[key] ?? '';
      const setPart = (key: string, value: string): void => set(name, { ...address, [key]: value });
      return (
        <fieldset className="subform"><legend>{field.label}</legend>
          <div className="form-grid">
            <Field label="Line 1"><input value={part('line1')} onChange={(event) => setPart('line1', event.target.value)} /></Field>
            <Field label="Line 2"><input value={part('line2')} onChange={(event) => setPart('line2', event.target.value)} /></Field>
            <Field label="City"><input value={part('city')} onChange={(event) => setPart('city', event.target.value)} /></Field>
            <Field label="Region"><input value={part('region')} onChange={(event) => setPart('region', event.target.value)} /></Field>
            <Field label="Postal code"><input value={part('postalCode')} onChange={(event) => setPart('postalCode', event.target.value)} /></Field>
            <Field label="Country"><input value={part('country')} maxLength={2} onChange={(event) => setPart('country', event.target.value)} /></Field>
          </div>
        </fieldset>
      );
    }
    case 'file': return <Field label={field.label} hint={field.hint}><input type="file" onChange={(event) => { const file = event.target.files?.[0]; if (file !== undefined) void toBase64(file).then((base64) => set(name, { base64 })); }} /></Field>;
    case 'json': return <Field label={field.label} hint={field.hint}><textarea rows={3} value={str === '' && raw !== undefined && raw !== null && typeof raw !== 'string' ? JSON.stringify(raw, null, 2) : str} onChange={(event) => set(name, event.target.value)} /></Field>;
    case 'owners': {
      const owners = Array.isArray(raw) ? raw as Record<string, unknown>[] : [];
      const update = (index: number, patch: Record<string, unknown>): void => set(name, owners.map((owner, at) => at === index ? { ...owner, ...patch } : owner));
      return (
        <fieldset className="subform"><legend>{field.label}</legend>
          {owners.map((owner, index) => (
            <div key={index} className="owner-row">
              <RecordPicker institutionId={institutionId} field={{ name: 'memberId', label: 'Owner member', input: 'record', resource: 'member' }} value={asText(owner.memberId)} values={values} context={context}
                onPick={(id) => update(index, { memberId: id })} />
              <input inputMode="numeric" placeholder="Ownership bps" value={asText(owner.ownershipBps)} onChange={(event) => update(index, { ownershipBps: event.target.value })} />
              <label className="checkbox"><input type="checkbox" checked={owner.isControlPerson === true} onChange={(event) => update(index, { isControlPerson: event.target.checked })} /> Control person</label>
              <input placeholder="Evidence id" value={asText(owner.evidenceId)} onChange={(event) => update(index, { evidenceId: event.target.value })} />
              <button type="button" onClick={() => set(name, owners.filter((_item, at) => at !== index))}>Remove</button>
            </div>
          ))}
          <button type="button" onClick={() => set(name, [...owners, { memberId: '', ownershipBps: '', isControlPerson: false, evidenceId: '' }])}>Add owner</button>
        </fieldset>
      );
    }
    case 'requestedCommand': {
      const request = (raw ?? {}) as Record<string, unknown>;
      const templates: Record<string, unknown> = {
        'contact.update': { kind: 'contact.update', email: '' },
        'account.nickname.update': { kind: 'account.nickname.update', nickname: '' },
        'account.statement_delivery.update': { kind: 'account.statement_delivery.update', statementDelivery: 'electronic' },
        'account.hold.place': { kind: 'account.hold.place', amount: { minorUnits: 0, currency: context.currency ?? 'USD' }, reason: '', expiresAt: '', releaseAuthority: '' },
        'maintenance.address.reconcile': { kind: 'maintenance.address.reconcile', address: { line1: '', line2: null, city: '', region: '', postalCode: '', country: '' } },
      };
      const chosen = typeof request.kind === 'string' ? request.kind : '';
      return (
        <fieldset className="subform"><legend>{field.label}</legend>
          <Field label="Requested operation"><select value={chosen} onChange={(event) => set(name, event.target.value === '' ? {} : { ...(templates[event.target.value] ?? { kind: event.target.value }) })}>
            <option value="">Choose…</option>
            {Object.keys(templates).map((kind) => <option key={kind} value={kind}>{kind}</option>)}
          </select></Field>
          <Field label="Request fields (JSON)" hint="Subject ids, versions and fingerprints are bound when the request is applied."><textarea rows={5} value={JSON.stringify(request, null, 2)} onChange={(event) => { try { set(name, JSON.parse(event.target.value) as unknown); } catch { set(name, event.target.value); } }} /></Field>
        </fieldset>
      );
    }
    case 'mergePlan': return (
      <Field label={field.label} hint={field.hint}>
        <select value={str} disabled={options.loading} onChange={(event) => {
          const id = event.target.value;
          setMany({ mergePlanId: id });
          if (id !== '') {
            const memberVersion = async (memberId: string): Promise<number> => getJson<{ member: { version: number } }>(institutionPath(institutionId, `/members/${encodeURIComponent(memberId)}`)).then((detail) => detail.member.version);
            const fail = (error: unknown): void => props.notify('error', error instanceof Error ? error.message : String(error));
            void getJson<{ kind: string; sourceMemberId: string; targetMemberId: string; fingerprint: string }>(institutionPath(institutionId, `/merge-plans/${encodeURIComponent(id)}`)).then(async (plan) => {
              const [sourceVersion, targetVersion, accounts] = await Promise.all([
                memberVersion(plan.sourceMemberId), memberVersion(plan.targetMemberId),
                getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ memberId: plan.sourceMemberId, limit: 100 })}`)).then((page) => page.items.map((item) => item.id)),
              ]);
              setMany({
                mergePlanId: id, sourceMemberId: plan.sourceMemberId, targetMemberId: plan.targetMemberId,
                expectedSourceVersion: sourceVersion, expectedTargetVersion: targetVersion,
                expectedInventoryFingerprint: plan.fingerprint, relationshipAccountIds: accounts,
              });
            }, fail);
          }
        }}>
          <option value="">{options.loading ? 'Loading…' : 'Choose…'}</option>
          {options.options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
      </Field>
    );
    default: return null;
  }
}

interface ApprovalSectionProps {
  institutionId: string;
  spec: OpSpec;
  values: Values;
  context: OperationContext;
  command: Record<string, unknown> | null;
  approvalId: string;
  onPickApproval: (id: string) => void;
  notify: (tone: 'info' | 'success' | 'error', text: string, receiptNumber?: string) => void;
}

/** Matching approvals for the built command plus the maker's request form. */
function ApprovalSection({ institutionId, spec, values, context, command, approvalId, onPickApproval, notify }: ApprovalSectionProps): ReactNode {
  const { profile } = useWorkspace();
  const [approvals, setApprovals] = useState<ApprovalRow[] | null>(null);
  const [checkerId, setCheckerId] = useState('');
  const [policyId, setPolicyId] = useState('');
  const [expiresAt, setExpiresAt] = useState('');
  const [amount, setAmount] = useState('');
  const [amountCurrency, setAmountCurrency] = useState(context.currency ?? 'USD');
  const [requestBusy, setRequestBusy] = useState(false);
  const [requestError, setRequestError] = useState<string | null>(null);
  const { reference } = useWorkspace();

  const refresh = useCallback(() => { void listApprovalsApi(institutionId).then((page) => setApprovals(page.approvals), () => setApprovals([])); }, [institutionId]);
  useEffect(refresh, [refresh]);

  const matching = useMemo(() => {
    if (command === null || approvals === null) return [];
    const scope = { ...command };
    delete scope.approvalId;
    const wanted = canonical(scope);
    return approvals.filter((row) => row.status !== 'consumed' && canonical(row.target) === wanted);
  }, [command, approvals]);

  const checkers = useOptions(institutionId, { name: 'checker', label: 'Checker', input: 'pick', read: { reader: 'checkers', args: { commandKind: spec.kind } } }, values, context, true);
  const policies = useOptions(institutionId, { name: 'policy', label: 'Policy', input: 'pick', read: { reader: 'policies' } }, values, context, true);

  const request = (): void => {
    if (command === null) return;
    const target = { ...command, approvalId: '' };
    setRequestBusy(true);
    setRequestError(null);
    const parsed = parseMoney(amount, 2);
    const amountLimit = amount.trim() === '' ? null : parsed.ok ? { minorUnits: parsed.minorUnits, currency: amountCurrency } : null;
    if (amount.trim() !== '' && amountLimit === null) { setRequestBusy(false); setRequestError('The amount limit is not a valid amount.'); return; }
    void executeCommand(institutionId, {
      kind: 'approval.request', target, checkerActorId: checkerId, policyVersionId: policyId, expiresAt: new Date(expiresAt).toISOString(), amountLimit,
    } as unknown as ServiceCommand, `approval.request:${crypto.randomUUID()}`).then((outcome) => {
      setRequestBusy(false);
      if (outcome.kind === 'committed' || outcome.kind === 'duplicate') { notify('success', `Approval ${outcome.receipt.receiptNumber} requested; the assigned checker sees it under Approvals.`); refresh(); }
      else setRequestError(outcome.message);
    }, (error: unknown) => { setRequestBusy(false); setRequestError(error instanceof Error ? error.message : String(error)); });
  };

  return (
    <fieldset className="subform approval-section"><legend>Independent approval</legend>
      {matching.length === 0 ? <p className="muted">No approval covers this action yet.</p> : (
        <div role="radiogroup" aria-label="Matching approvals">
          {matching.map((row) => (
            <label key={row.id} className="radio"><input type="radio" name="approval" checked={approvalId === row.id} onChange={() => onPickApproval(row.id)} />
              {row.id} · <span className={`badge status-${row.status}`}>{row.status}</span> · checker {row.checker.displayName} · expires {formatInstant(row.expiresAt)}</label>
          ))}
        </div>
      )}
      <div className="inline-form">
        <label className="field">Checker
          <select value={checkerId} onChange={(event) => setCheckerId(event.target.value)}>
            <option value="">Choose…</option>
            {checkers.options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select>
        </label>
        <label className="field">Policy
          <select value={policyId} onChange={(event) => setPolicyId(event.target.value)}>
            <option value="">Choose…</option>
            {policies.options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select>
        </label>
        <label className="field">Expires at<input type="datetime-local" step={1} value={expiresAt} onChange={(event) => setExpiresAt(event.target.value)} /></label>
        <label className="field">Amount limit<span className="money-input"><input inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} />
          <select value={amountCurrency} onChange={(event) => setAmountCurrency(event.target.value)}>{(reference?.currencies ?? []).map((item) => <option key={item.code} value={item.code}>{item.code}</option>)}</select></span></label>
        <button type="button" disabled={requestBusy || command === null || checkerId === '' || policyId === '' || expiresAt === '' || checkerId === profile?.actorId} onClick={request}>{requestBusy ? 'Requesting…' : 'Request approval'}</button>
      </div>
      {requestError === null ? null : <p className="error" role="alert">{requestError}</p>}
    </fieldset>
  );
}

function setNested(command: Record<string, unknown>, name: string, value: unknown): void {
  if (!name.includes('.')) { command[name] = value; return; }
  const parts = name.split('.');
  const head = parts[0] as string;
  const inner = (command[head] ?? {}) as Record<string, unknown>;
  let target = inner;
  for (const key of parts.slice(1, -1)) { target[key] = target[key] ?? {}; target = target[key] as Record<string, unknown>; }
  target[parts[parts.length - 1] as string] = value;
  command[head] = inner;
}

function convert(field: OpField, raw: unknown): { ok: true; value: unknown } | { ok: false; message: string } {
  const empty = raw === undefined || raw === null || raw === '' || (typeof raw === 'object' && !Array.isArray(raw) && Object.keys(raw).length === 0);
  if (empty) {
    if (field.nullable === true) return { ok: true, value: null };
    if (field.optional === true) return { ok: true, value: undefined };
    return { ok: false, message: `${field.label} is required.` };
  }
  switch (field.input) {
    case 'int': {
      const parsed = Number(raw);
      return Number.isSafeInteger(parsed) ? { ok: true, value: parsed } : { ok: false, message: `${field.label} must be a whole number.` };
    }
    case 'money': {
      const moneyValue = raw as { amount?: string; currency?: string; minorUnits?: number };
      if (typeof moneyValue.minorUnits === 'number') return { ok: true, value: { minorUnits: moneyValue.minorUnits, currency: moneyValue.currency } };
      const parsed = parseMoney(moneyValue.amount ?? '', 2);
      return parsed.ok ? { ok: true, value: { minorUnits: parsed.minorUnits, currency: moneyValue.currency ?? 'USD' } } : { ok: false, message: `${field.label}: ${parsed.message}` };
    }
    case 'instant': {
      const text = asText(raw);
      const parsed = Date.parse(text.endsWith('Z') || text.includes('+') ? text : `${text}Z`);
      return Number.isFinite(parsed) ? { ok: true, value: new Date(parsed).toISOString() } : { ok: false, message: `${field.label} must be a date and time.` };
    }
    case 'ids': {
      const list = Array.isArray(raw) ? raw.filter((item) => typeof item === 'string' && item !== '') : [];
      return list.length === 0 && field.nullable !== true && field.optional !== true ? { ok: false, message: `${field.label} needs at least one entry.` } : { ok: true, value: list };
    }
    case 'json': {
      if (typeof raw !== 'string') return { ok: true, value: raw };
      try { return { ok: true, value: JSON.parse(asText(raw)) as unknown }; } catch { return { ok: false, message: `${field.label} is not valid JSON.` }; }
    }
    case 'owners': {
      const owners = raw as Record<string, unknown>[];
      const clean = owners.filter((owner) => asText(owner.memberId) !== '');
      return { ok: true, value: clean.map((owner) => ({ memberId: asText(owner.memberId), ownershipBps: Number(owner.ownershipBps), isControlPerson: owner.isControlPerson === true, evidenceId: asText(owner.evidenceId) })) };
    }
    case 'requestedCommand': {
      if (typeof raw === 'object' && !Array.isArray(raw)) return { ok: true, value: raw };
      try { return { ok: true, value: JSON.parse(asText(raw)) as unknown }; } catch { return { ok: false, message: 'The requested command is not valid JSON.' }; }
    }
    case 'file': {
      const file = raw as { base64?: string };
      return typeof file.base64 === 'string' && file.base64 !== '' ? { ok: true, value: { base64: file.base64 } } : { ok: false, message: `Choose a file for ${field.label}.` };
    }
    case 'address': {
      const address = raw as Record<string, string>;
      const line1 = (address.line1 ?? '').trim();
      if (line1 === '') return { ok: false, message: `${field.label}: line 1 is required.` };
      const line2 = (address.line2 ?? '').trim();
      return { ok: true, value: { line1, line2: line2 === '' ? null : line2, city: (address.city ?? '').trim(), region: (address.region ?? '').trim(), postalCode: (address.postalCode ?? '').trim(), country: (address.country ?? '').trim() } };
    }
    default: return { ok: true, value: typeof raw === 'string' ? raw.trim() : raw };
  }
}

export interface OperationDialogProps {
  spec: OpSpec | InquirySpec;
  inquiry?: boolean;
  institutionId: string;
  context: OperationContext;
  onClose: () => void;
  onCommitted?: (receipt: Receipt) => void;
  onOpenReceipt: (receiptNumber: string) => void;
}

/** One metadata-driven form for a shared command or inquiry. */
export function OperationDialog({ spec, inquiry: isInquiry = false, institutionId, context, onClose, onCommitted, onOpenReceipt }: OperationDialogProps): ReactNode {
  const op = spec as OpSpec;
  const { notify } = useWorkspace();
  const [values, setValues] = useState<Values>(() => {
    const initial: Values = {};
    for (const field of spec.fields) {
      const seeded = context.initial?.[field.name];
      if (seeded !== undefined) initial[field.name] = seeded;
      else if (field.auto) {
        const fromContext = field.name === 'expectedVersion' ? context.initial?.expectedVersion : undefined;
        if (fromContext !== undefined) initial[field.name] = fromContext;
      }
      if (field.input === 'money') initial[field.name] = { amount: '', currency: context.currency ?? 'USD' };
      if (field.input === 'ids') initial[field.name] = initial[field.name] ?? [];
      if (field.input === 'bool') initial[field.name] = initial[field.name] ?? false;
    }
    for (const [key, seeded] of Object.entries(context.initial ?? {})) if (initial[key] === undefined) initial[key] = seeded;
    return initial;
  });
  const set = useCallback((name: string, value: unknown): void => setValues((previous) => ({ ...previous, [name]: value })), []);
  const setMany = useCallback((patch: Values): void => setValues((previous) => ({ ...previous, ...patch })), []);
  const [inquiryState, setInquiryState] = useState<{ busy: boolean; result: unknown; error: string | null }>({ busy: false, result: undefined, error: null });
  const commandPreview = useRef<Record<string, unknown> | null>(null);

  const buildCommand = (): { command: Record<string, unknown> } | { error: string; field?: string } => {
    const command: Record<string, unknown> = { kind: spec.kind };
    for (const field of spec.fields) {
      const converted = convert(field, values[field.name]);
      if (!converted.ok) return { error: converted.message, field: field.name };
      if (converted.value !== undefined) setNested(command, field.name, converted.value);
    }
    if (op.approval === true) {
      const approvalId = asText(values.approvalId);
      if (approvalId === '') return { error: 'Choose or request an approval for this action.', field: 'approvalId' };
      command.approvalId = approvalId;
    }
    return { command };
  };

  const built = buildCommand();
  commandPreview.current = 'error' in built ? null : built.command;

  if (isInquiry) {
    return (
      <Dialog title={spec.title} onClose={onClose} wide footer={
        <>
          <button type="button" onClick={onClose}>Close</button>
          <button type="button" className="primary" disabled={inquiryState.busy} onClick={() => {
            const built = buildCommand();
            if ('error' in built) { setInquiryState({ busy: false, result: undefined, error: built.error }); return; }
            setInquiryState({ busy: true, result: undefined, error: null });
            void financeQuery(institutionId, built.command).then(
              (result) => setInquiryState({ busy: false, result, error: null }),
              (error: unknown) => setInquiryState({ busy: false, result: undefined, error: error instanceof Error ? error.message : String(error) }),
            );
          }}>{inquiryState.busy ? 'Checking…' : 'Check'}</button>
        </>
      }>
        <div className="form-grid">
          {spec.fields.map((field) => <FieldWidget key={field.name} field={field} values={values} set={set} setMany={setMany} institutionId={institutionId} context={context} notify={notify} />)}
        </div>
        {inquiryState.error === null ? null : <p className="error" role="alert">{inquiryState.error}</p>}
        {inquiryState.result === undefined ? null : <pre className="inquiry-result" data-inquiry={spec.kind}>{JSON.stringify(inquiryState.result, null, 2)}</pre>}
      </Dialog>
    );
  }

  return (
    <CommandDialog
      title={spec.title} institutionId={institutionId} review={op.review === true} submitLabel={spec.title} onClose={onClose} wide={op.wide === true}
      onOpenReceipt={onOpenReceipt} onCommitted={onCommitted} successText={(receipt) => `${spec.title} committed (${receipt.receiptNumber}).`}
      build={(): BuildResult => {
        const built = buildCommand();
        return 'error' in built ? (built.field === undefined ? { error: built.error } : { error: built.error, field: built.field }) : { command: built.command as unknown as ServiceCommand };
      }}
    >
      {() => (
        <div className="form-grid">
          {op.hint === undefined ? null : <p className="muted span">{op.hint}</p>}
          {spec.fields.map((field) => <FieldWidget key={field.name} field={field} values={values} set={set} setMany={setMany} institutionId={institutionId} context={context} notify={notify} />)}
          {op.approval === true ? (
            <ApprovalSection
              institutionId={institutionId} spec={op} values={values} context={context} command={commandPreview.current}
              approvalId={asText(values.approvalId)} onPickApproval={(id) => set('approvalId', id)} notify={notify}
            />
          ) : null}
        </div>
      )}
    </CommandDialog>
  );
}
