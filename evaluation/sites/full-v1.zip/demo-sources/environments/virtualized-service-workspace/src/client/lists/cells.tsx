import type { ActivityRow, DocumentListRow, TransactionRow } from '@computer-use/financial-database/services';
import type { ReactNode } from 'react';

import { fieldOf, type GridId } from '../../shared/columns.js';
import { formatBytes, formatDate, formatInstant, formatMoney, label } from '../format.js';
import type { ResolvedColumn } from '../model/columns.js';

export type DocumentGridRow = DocumentListRow & { id: string };
export type ActivityGridRow = ActivityRow & { id: string };
export type TransactionGridRow = TransactionRow & { id: string; currency: string; exponent: number };

const BADGE_COLUMNS = new Set(['status', 'state', 'priority']);

function money(value: unknown, currency: unknown, exponent: unknown): string {
  return typeof value === 'number' && typeof currency === 'string' ? formatMoney(value, currency, typeof exponent === 'number' ? exponent : 2) : '';
}

/** Display of one stored field. Identity and editing are handled by the grid, never by the text shown here. */
export function renderCell(grid: GridId, row: object, column: ResolvedColumn): ReactNode {
  const record = row as Record<string, unknown>;
  const id = column.id;
  if (grid === 'transactions') {
    if (id === 'amount') return <span className={Number(record.amountMinorUnits) < 0 ? 'debit' : 'credit'}>{money(record.amountMinorUnits, record.currency, record.exponent)}</span>;
    if (id === 'running_balance') return money(record.runningBalanceMinorUnits, record.currency, record.exponent);
  }
  if (grid === 'activity') {
    if (id === 'actor') { const actor = record.actor as ActivityRow['actor']; return actor === null ? 'System' : `${actor.displayName} (${actor.actorNumber})`; }
    if (id === 'occurred_at') return formatInstant(String(record.occurredAt));
    if (id === 'kind') return <code>{String(record.kind)}</code>;
  }
  if (grid === 'documents') {
    if (id === 'period') return typeof record.periodStart === 'string' ? `${formatDate(record.periodStart)} – ${formatDate(typeof record.periodEnd === 'string' ? record.periodEnd : null)}` : '';
    if (id === 'byte_length') return formatBytes(Number(record.byteLength));
    if (id === 'document_type') return label(String(record.documentType));
  }
  if (id.endsWith('_minor_units')) return money(record[fieldOf(id)], record.currency, record.exponent);
  const value = record[fieldOf(id)];
  if (id === 'overdue') return value === true ? <span className="badge status-overdue">Overdue</span> : '';
  if (typeof value === 'string' && BADGE_COLUMNS.has(id)) return <span className={`badge status-${value}`}>{label(value)}</span>;
  if (id === 'statement_delivery' && typeof value === 'string') return label(value);
  if (id.endsWith('_at') || id === 'effective_date') return formatDate(typeof value === 'string' ? value : null);
  if (typeof value === 'number') return value.toLocaleString('en-US');
  if (typeof value === 'string') return value;
  return value === null || value === undefined ? '' : JSON.stringify(value);
}
