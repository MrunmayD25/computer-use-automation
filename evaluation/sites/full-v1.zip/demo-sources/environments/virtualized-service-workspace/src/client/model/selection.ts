/**
 * Row selection by business identity. `ids` holds explicit records with their business numbers; `matching`
 * means every record matching one search at the time an action runs, minus explicit exclusions.
 */
export type Selection =
  | { mode: 'ids'; ids: ReadonlyMap<string, string> }
  | { mode: 'matching'; matchKey: string; total: number; excluded: ReadonlySet<string>; description: string };

export const EMPTY_SELECTION: Selection = { mode: 'ids', ids: new Map() };

export function isSelected(selection: Selection, id: string): boolean {
  return selection.mode === 'ids' ? selection.ids.has(id) : !selection.excluded.has(id);
}

export function selectedCount(selection: Selection): number {
  return selection.mode === 'ids' ? selection.ids.size : Math.max(0, selection.total - selection.excluded.size);
}

export function toggleSelected(selection: Selection, id: string, label: string): Selection {
  if (selection.mode === 'matching') {
    const excluded = new Set(selection.excluded);
    if (excluded.has(id)) excluded.delete(id); else excluded.add(id);
    return { ...selection, excluded };
  }
  const ids = new Map(selection.ids);
  if (ids.has(id)) ids.delete(id); else ids.set(id, label);
  return { mode: 'ids', ids };
}

/** Adds explicit records. Records already covered by an all-matching selection stay covered. */
export function selectRecords(selection: Selection, records: readonly (readonly [string, string])[]): Selection {
  if (selection.mode === 'matching') {
    const excluded = new Set(selection.excluded);
    for (const [id] of records) excluded.delete(id);
    return { ...selection, excluded };
  }
  return { mode: 'ids', ids: new Map([...selection.ids, ...records]) };
}

export function selectAllMatching(matchKey: string, total: number, description: string): Selection {
  return { mode: 'matching', matchKey, total, excluded: new Set(), description };
}

/**
 * Sorting keeps every selection. A changed search keeps explicit records (some may now be hidden) but
 * ends an all-matching selection, because its membership was defined by the previous search.
 */
export function afterSearchChange(selection: Selection, matchKey: string): { selection: Selection; notice: string | null } {
  if (selection.mode === 'matching' && selection.matchKey !== matchKey) {
    return { selection: EMPTY_SELECTION, notice: `The selection of all ${String(selectedCount(selection))} records matching ${selection.description} was cleared because the search changed.` };
  }
  return { selection, notice: null };
}
