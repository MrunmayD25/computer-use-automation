import { createRoot } from 'react-dom/client';

import type { SessionInfo } from '../shared/api.js';
import { getJson } from './api.js';
import { App } from './App.js';

const container = document.getElementById('root');
if (container === null) throw new Error('The page has no #root element.');
const root = createRoot(container);
getJson<SessionInfo>('/api/session').then(
  (session) => root.render(<App initialSession={session} />),
  (error: unknown) => root.render(<p className="boot">The workspace backend is unavailable: {error instanceof Error ? error.message : String(error)}</p>),
);
