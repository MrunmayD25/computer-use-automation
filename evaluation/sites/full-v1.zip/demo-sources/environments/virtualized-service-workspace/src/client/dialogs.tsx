import type { AccountDetail, AccountRow, CaseDetail, CasePriority, CaseState, CaseSubjectCorrectionEvidenceDocument, IdentityEvidenceSummary, MemberDetail, PageResult, PolicyVersionSummary, Receipt, ServiceCommand, ServicingApprovalCheckerSummary } from '@computer-use/financial-database/services';
import { useState, type ReactNode } from 'react';

import { getJson, institutionPath, queryString } from './api.js';
import { CommandDialog, type BuildResult } from './commands.js';
import { formatMoney, label } from './format.js';
import { parseMoney } from './model/money.js';
import { OperationDialog } from './ops/OperationDialog.js';
import type { DialogSpec } from './shell.js';
import { useShell } from './shell.js';
import { Dialog } from './ui/Dialog.js';
import { useResource } from './useResource.js';
import { useWorkspace } from './workspace.js';

interface Props<S extends DialogSpec['kind']> {
  spec: Extract<DialogSpec, { kind: S }>;
  onClose: () => void;
}

function affected(receipt: Receipt, kind: string): string | undefined {
  return receipt.affected.find((item) => item.kind === kind)?.id;
}

function Field({ label: text, children }: { label: string; children: ReactNode }): ReactNode {
  return <label className="field">{text}{children}</label>;
}

function MemberCreateDialog({ onClose }: Props<'member.create'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  const [form, setForm] = useState({ legalGiven: '', legalFamily: '', preferredName: '', birthDate: '', email: '', phone: '', line1: '', line2: '', city: '', region: '', postalCode: '', country: 'US' });
  const set = (key: keyof typeof form) => (event: { target: { value: string } }): void => setForm((previous) => ({ ...previous, [key]: event.target.value }));
  const optional = (value: string): string | null => (value.trim() === '' ? null : value.trim());
  return (
    <CommandDialog
      title="New member" institutionId={institution.institutionId} review={false} submitLabel="Create member" onClose={onClose} onOpenReceipt={(number) => openRecord('receipt', number)}
      successText={(receipt) => `Member ${receipt.affected.find((item) => item.kind === 'member')?.label ?? ''} created.`}
      onCommitted={(receipt) => { const id = affected(receipt, 'member'); if (id !== undefined) openRecord('member', id); }}
      build={() => ({ command: {
        kind: 'member.create', legalGiven: form.legalGiven.trim(), legalFamily: form.legalFamily.trim(), preferredName: optional(form.preferredName), birthDate: form.birthDate,
        email: optional(form.email), phone: optional(form.phone),
        address: form.line1.trim() === '' ? null : { line1: form.line1.trim(), line2: optional(form.line2), city: form.city.trim(), region: form.region.trim(), postalCode: form.postalCode.trim(), country: form.country.trim() },
      } })}
    >
      {() => (
        <div className="form-grid">
          <Field label="Given name"><input value={form.legalGiven} onChange={set('legalGiven')} /></Field>
          <Field label="Family name"><input value={form.legalFamily} onChange={set('legalFamily')} /></Field>
          <Field label="Preferred name"><input value={form.preferredName} onChange={set('preferredName')} /></Field>
          <Field label="Birth date"><input type="date" value={form.birthDate} onChange={set('birthDate')} /></Field>
          <Field label="Email"><input type="email" value={form.email} onChange={set('email')} /></Field>
          <Field label="Phone"><input value={form.phone} onChange={set('phone')} /></Field>
          <Field label="Address line 1"><input value={form.line1} onChange={set('line1')} /></Field>
          <Field label="Address line 2"><input value={form.line2} onChange={set('line2')} /></Field>
          <Field label="City"><input value={form.city} onChange={set('city')} /></Field>
          <Field label="Region"><input value={form.region} onChange={set('region')} /></Field>
          <Field label="Postal code"><input value={form.postalCode} onChange={set('postalCode')} /></Field>
          <Field label="Country"><input value={form.country} maxLength={2} onChange={set('country')} /></Field>
        </div>
      )}
    </CommandDialog>
  );
}

function ContactDialog({ spec, onClose }: Props<'contact.update'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  const detail = spec.member;
  const [email, setEmail] = useState(detail.email?.value ?? '');
  const [phone, setPhone] = useState(detail.phone?.value ?? '');
  const [address, setAddress] = useState({ line1: detail.address?.line1 ?? '', line2: detail.address?.line2 ?? '', city: detail.address?.city ?? '', region: detail.address?.region ?? '', postalCode: detail.address?.postalCode ?? '', country: detail.address?.country ?? 'US' });
  const setPart = (key: keyof typeof address) => (event: { target: { value: string } }): void => setAddress((previous) => ({ ...previous, [key]: event.target.value }));
  const build = (): BuildResult => {
    const command: Extract<ServiceCommand, { kind: 'contact.update' }> = { kind: 'contact.update', memberId: detail.member.id, expectedVersion: detail.member.version };
    if (email.trim() !== (detail.email?.value ?? '')) command.email = email.trim() === '' ? null : email.trim();
    if (phone.trim() !== (detail.phone?.value ?? '')) command.phone = phone.trim() === '' ? null : phone.trim();
    const before = detail.address;
    if (address.line1.trim() !== '' && (before === null || address.line1 !== before.line1 || address.line2 !== (before.line2 ?? '') || address.city !== before.city || address.region !== before.region || address.postalCode !== before.postalCode || address.country !== before.country)) {
      command.address = { line1: address.line1.trim(), line2: address.line2.trim() === '' ? null : address.line2.trim(), city: address.city.trim(), region: address.region.trim(), postalCode: address.postalCode.trim(), country: address.country.trim() };
    }
    return { command };
  };
  return (
    <CommandDialog title={`Contact details of ${detail.member.memberNumber}`} institutionId={institution.institutionId} review={false} submitLabel="Save contact" onClose={onClose}
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={() => `Contact details of ${detail.member.memberNumber} updated.`} build={build}>
      {() => (
        <div className="form-grid">
          <Field label="Email"><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} /></Field>
          <Field label="Phone"><input value={phone} onChange={(event) => setPhone(event.target.value)} /></Field>
          <Field label="Address line 1"><input value={address.line1} onChange={setPart('line1')} /></Field>
          <Field label="Address line 2"><input value={address.line2} onChange={setPart('line2')} /></Field>
          <Field label="City"><input value={address.city} onChange={setPart('city')} /></Field>
          <Field label="Region"><input value={address.region} onChange={setPart('region')} /></Field>
          <Field label="Postal code"><input value={address.postalCode} onChange={setPart('postalCode')} /></Field>
          <Field label="Country"><input value={address.country} maxLength={2} onChange={setPart('country')} /></Field>
          <p className="muted span">Edits apply against version {detail.member.version}. Leave a field unchanged to keep it; clear email or phone to remove it.</p>
        </div>
      )}
    </CommandDialog>
  );
}

function NoteDialog({ spec, onClose }: Props<'note'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  const [text, setText] = useState('');
  const [visibility, setVisibility] = useState<'general' | 'restricted'>('general');
  const { owner } = spec;
  return (
    <CommandDialog title={`Note on ${owner.label}`} institutionId={institution.institutionId} review={false} submitLabel="Add note" onClose={onClose}
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={() => `Note added to ${owner.label}.`}
      build={() => ({ command: owner.kind === 'member' ? { kind: 'member.note.add', memberId: owner.id, visibility, text } : { kind: 'case.note.add', caseId: owner.id, visibility, text } })}>
      {() => (
        <>
          <Field label="Note"><textarea rows={5} value={text} onChange={(event) => setText(event.target.value)} /></Field>
          <Field label="Visibility"><select value={visibility} onChange={(event) => setVisibility(event.target.value === 'restricted' ? 'restricted' : 'general')}><option value="general">General</option><option value="restricted">Restricted</option></select></Field>
        </>
      )}
    </CommandDialog>
  );
}

function AccountOpenDialog({ spec, onClose }: Props<'account.open'>): ReactNode {
  const { institution, reference } = useWorkspace();
  const { openRecord } = useShell();
  const [productId, setProductId] = useState('');
  const [nickname, setNickname] = useState('');
  const [delivery, setDelivery] = useState<'electronic' | 'paper'>('electronic');
  return (
    <CommandDialog title={`Open account for ${spec.member.memberNumber}`} institutionId={institution.institutionId} review={false} submitLabel="Open account" onClose={onClose}
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={(receipt) => `Account ${receipt.affected.find((item) => item.kind === 'account')?.label ?? ''} opened for ${spec.member.memberNumber}.`}
      onCommitted={(receipt) => { const id = affected(receipt, 'account'); if (id !== undefined) openRecord('account', id); }}
      build={() => (productId === '' ? { error: 'Choose a product.', field: 'productId' } : { command: { kind: 'account.open', memberId: spec.member.id, productId, nickname, statementDelivery: delivery } })}>
      {() => (
        <>
          <p>Owner: {spec.member.displayName} ({spec.member.memberNumber})</p>
          <Field label="Product"><select value={productId} onChange={(event) => setProductId(event.target.value)}><option value="">Choose…</option>{(reference?.products ?? []).map((product) => <option key={product.id} value={product.id}>{product.code} · {product.name} ({product.currency})</option>)}</select></Field>
          <Field label="Nickname"><input value={nickname} maxLength={60} onChange={(event) => setNickname(event.target.value)} /></Field>
          <Field label="Statement delivery"><select value={delivery} onChange={(event) => setDelivery(event.target.value === 'paper' ? 'paper' : 'electronic')}><option value="electronic">Electronic</option><option value="paper">Paper</option></select></Field>
        </>
      )}
    </CommandDialog>
  );
}

function MoneyDialog({ spec, onClose }: Props<'money'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  const fresh = useResource<AccountDetail>(institutionPath(institution.institutionId, `/accounts/${encodeURIComponent(spec.account.id)}`));
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [destinationQuery, setDestinationQuery] = useState('');
  const [candidates, setCandidates] = useState<AccountRow[]>([]);
  const [destination, setDestination] = useState<AccountRow | null>(null);
  const account = fresh.data?.account ?? spec.account;
  const title = spec.mode === 'deposit' ? 'Deposit' : spec.mode === 'withdraw' ? 'Withdrawal' : 'Internal transfer';
  const search = (): void => {
    getJson<PageResult<AccountRow>>(institutionPath(institution.institutionId, `/accounts${queryString({ query: destinationQuery, currency: account.currency, status: 'open', limit: 8 })}`)).then(
      (page) => setCandidates(page.items.filter((item) => item.id !== account.id)), () => setCandidates([]),
    );
  };
  const build = (): BuildResult => {
    const parsed = parseMoney(amount, account.exponent);
    if (!parsed.ok) return { error: parsed.message, field: 'amount' };
    const money = { minorUnits: parsed.minorUnits, currency: account.currency };
    if (spec.mode === 'transfer') {
      if (destination === null) return { error: 'Choose the destination account.', field: 'destinationAccountId' };
      return { command: { kind: 'transfer.internal', sourceAccountId: account.id, destinationAccountId: destination.id, expectedSourceVersion: account.version, expectedDestinationVersion: destination.version, amount: money, description } };
    }
    return { command: { kind: spec.mode === 'deposit' ? 'cash.deposit' : 'cash.withdraw', accountId: account.id, expectedVersion: account.version, amount: money, description } };
  };
  return (
    <CommandDialog title={`${title} · ${account.accountNumber}`} institutionId={institution.institutionId} review submitLabel={title} onClose={onClose} wide
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={(receipt) => `${title} of ${amount} ${account.currency} committed on ${account.accountNumber} (${receipt.receiptNumber}).`} build={build}>
      {() => (
        <>
          <p>
            {account.ownerName} ({account.memberNumber}) · available <strong className="money">{formatMoney(account.availableMinorUnits, account.currency, account.exponent)}</strong> · version {account.version}
            {fresh.data === undefined ? ' · checking current balance…' : ''}
          </p>
          <Field label={`Amount (${account.currency})`}><input inputMode="decimal" value={amount} onChange={(event) => setAmount(event.target.value)} /></Field>
          {spec.mode === 'transfer' ? (
            <fieldset className="destination">
              <legend>Destination account ({account.currency})</legend>
              <div className="inline-form">
                <input aria-label="Find destination account" placeholder="Account number or owner" value={destinationQuery} onChange={(event) => setDestinationQuery(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); search(); } }} />
                <button type="button" onClick={search}>Find</button>
              </div>
              <div role="radiogroup" aria-label="Destination candidates">
                {candidates.map((candidate) => (
                  <label key={candidate.id} className="radio"><input type="radio" name="destination" checked={destination?.id === candidate.id} onChange={() => setDestination(candidate)} /> <code>{candidate.accountNumber}</code> {candidate.ownerName} · {candidate.productName}</label>
                ))}
              </div>
              {destination === null ? null : <p>To <code>{destination.accountNumber}</code> ({destination.ownerName}).</p>}
            </fieldset>
          ) : null}
          <Field label="Description"><input value={description} maxLength={120} onChange={(event) => setDescription(event.target.value)} /></Field>
        </>
      )}
    </CommandDialog>
  );
}

function AccountCloseDialog({ spec, onClose }: Props<'account.close'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  const fresh = useResource<AccountDetail>(institutionPath(institution.institutionId, `/accounts/${encodeURIComponent(spec.account.id)}`));
  const [reason, setReason] = useState('');
  const account = fresh.data?.account ?? spec.account;
  const closure = fresh.data?.eligibility.closure;
  return (
    <CommandDialog title={`Close ${account.accountNumber}`} institutionId={institution.institutionId} review submitLabel="Close account" onClose={onClose}
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={(receipt) => `Account ${account.accountNumber} closed (${receipt.receiptNumber}).`}
      build={() => ({ command: { kind: 'account.close', accountId: account.id, expectedVersion: account.version, reason } })}>
      {() => (
        <>
          <p>Posted balance {formatMoney(account.postedMinorUnits, account.currency, account.exponent)}. Only zero-balance accounts without holds or dependencies can close.</p>
          {closure === undefined || closure.eligible ? null : <p className="warning">Currently ineligible: {closure.reasons.join('; ')}</p>}
          <Field label="Reason"><input value={reason} onChange={(event) => setReason(event.target.value)} /></Field>
        </>
      )}
    </CommandDialog>
  );
}

function nextWeek(asOf: string): string {
  const date = new Date(`${asOf.slice(0, 10)}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + 7);
  return date.toISOString().slice(0, 10);
}

function CaseOpenDialog({ spec, onClose }: Props<'case.open'>): ReactNode {
  const { institution, reference } = useWorkspace();
  const { openRecord } = useShell();
  const member = useResource<MemberDetail>(institutionPath(institution.institutionId, `/members/${encodeURIComponent(spec.member.id)}`));
  const [form, setForm] = useState({ accountId: spec.accountId ?? '', queueId: '', assignedActorId: '', category: '', priority: 'normal' as CasePriority, summary: '', dueDate: nextWeek(institution.asOf) });
  const set = (key: keyof typeof form) => (event: { target: { value: string } }): void => setForm((previous) => ({ ...previous, [key]: event.target.value }));
  return (
    <CommandDialog title={`New case for ${spec.member.memberNumber}`} institutionId={institution.institutionId} review={false} submitLabel="Open case" onClose={onClose} wide
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={(receipt) => `Case ${receipt.affected.find((item) => item.kind === 'case')?.label ?? ''} opened.`}
      onCommitted={(receipt) => { const id = affected(receipt, 'case'); if (id !== undefined) openRecord('case', id); }}
      build={() => ({ command: {
        kind: 'case.open', memberId: spec.member.id, accountId: form.accountId === '' ? null : form.accountId, queueId: form.queueId, assignedActorId: form.assignedActorId === '' ? null : form.assignedActorId,
        category: form.category, priority: form.priority, summary: form.summary, dueDate: form.dueDate,
      } })}>
      {() => (
        <div className="form-grid">
          <Field label="Account"><select value={form.accountId} onChange={set('accountId')}><option value="">No account</option>{(member.data?.accounts ?? []).map((account) => <option key={account.id} value={account.id}>{account.accountNumber} · {account.productName}</option>)}</select></Field>
          <Field label="Queue"><select value={form.queueId} onChange={set('queueId')}><option value="">Choose…</option>{(reference?.queues ?? []).map((queue) => <option key={queue.id} value={queue.id}>{queue.code} · {queue.name}</option>)}</select></Field>
          <Field label="Assignee"><select value={form.assignedActorId} onChange={set('assignedActorId')}><option value="">Unassigned</option>{(reference?.caseWorkers ?? []).map((actor) => <option key={actor.id} value={actor.id}>{actor.displayName} ({actor.actorNumber})</option>)}</select></Field>
          <Field label="Category"><select value={form.category} onChange={set('category')}><option value="">Choose…</option>{(reference?.caseCategories ?? []).map((category) => <option key={category.code} value={category.code}>{category.label}</option>)}</select></Field>
          <Field label="Priority"><select value={form.priority} onChange={set('priority')}>{['low', 'normal', 'high', 'urgent'].map((priority) => <option key={priority} value={priority}>{label(priority)}</option>)}</select></Field>
          <Field label="Due date"><input type="date" value={form.dueDate} onChange={set('dueDate')} /></Field>
          <label className="field span">Summary<input value={form.summary} maxLength={200} onChange={set('summary')} /></label>
        </div>
      )}
    </CommandDialog>
  );
}

function CaseAssignDialog({ spec, onClose }: Props<'case.assign'>): ReactNode {
  const { institution, reference } = useWorkspace();
  const { openRecord } = useShell();
  const fresh = useResource<CaseDetail>(institutionPath(institution.institutionId, `/cases/${encodeURIComponent(spec.record.id)}`));
  const record = fresh.data?.case ?? spec.record;
  const [queueId, setQueueId] = useState(spec.record.queueId);
  const [assignee, setAssignee] = useState(spec.record.assignedActorId ?? '');
  const [reason, setReason] = useState('');
  return (
    <CommandDialog title={`Assign ${record.caseNumber}`} institutionId={institution.institutionId} review={false} submitLabel="Assign" onClose={onClose}
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={() => `Case ${record.caseNumber} assigned.`}
      build={() => ({ command: { kind: 'case.assign', caseId: record.id, expectedVersion: record.version, queueId, assignedActorId: assignee === '' ? null : assignee, reason } })}>
      {() => (
        <>
          <p>Currently {record.queueCode} · {record.assignedName ?? 'unassigned'} (version {record.version}).</p>
          <Field label="Queue"><select value={queueId} onChange={(event) => setQueueId(event.target.value)}>{(reference?.queues ?? []).map((queue) => <option key={queue.id} value={queue.id}>{queue.code} · {queue.name}</option>)}</select></Field>
          <Field label="Assignee"><select value={assignee} onChange={(event) => setAssignee(event.target.value)}><option value="">Unassigned</option>{(reference?.caseWorkers ?? []).map((actor) => <option key={actor.id} value={actor.id}>{actor.displayName} ({actor.actorNumber})</option>)}</select></Field>
          <Field label="Reason"><input value={reason} onChange={(event) => setReason(event.target.value)} /></Field>
        </>
      )}
    </CommandDialog>
  );
}

function CaseTransitionDialog({ spec, onClose }: Props<'case.transition'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  const fresh = useResource<CaseDetail>(institutionPath(institution.institutionId, `/cases/${encodeURIComponent(spec.record.id)}`));
  const record = fresh.data?.case ?? spec.record;
  const [toState, setToState] = useState<CaseState | ''>('');
  const [reason, setReason] = useState('');
  const [evidenceVersionId, setEvidenceVersionId] = useState('');
  const transitions = [...(fresh.data?.allowedTransitions ?? []), ...(record.state === 'resolved' ? ['closed' as const, 'reopened' as const] : record.state === 'closed' ? ['reopened' as const] : [])];
  return (
    <CommandDialog title={`Change status of ${record.caseNumber}`} institutionId={institution.institutionId} review={false} submitLabel="Change status" onClose={onClose}
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={() => `Case ${record.caseNumber} is now ${label(toState)}.`}
      build={() => (toState === '' ? { error: 'Choose the new status.', field: 'toState' } : { command: toState === 'closed' ? { kind: 'case.close', caseId: record.id, expectedVersion: record.version, resolutionCode: reason, effectEvidenceVersionId: evidenceVersionId } : toState === 'reopened' ? { kind: 'case.reopen', caseId: record.id, expectedVersion: record.version, reopeningBasis: reason, evidenceVersionId } : { kind: 'case.transition', caseId: record.id, expectedVersion: record.version, toState, reason } })}>
      {() => (
        <>
          <p>Currently {label(record.state)} (version {record.version}).</p>
          <Field label="New status">
            <select value={toState} onChange={(event) => setToState(event.target.value as CaseState | '')}>
              <option value="">{fresh.data === undefined ? 'Loading allowed transitions…' : 'Choose…'}</option>
              {transitions.map((state) => <option key={state} value={state}>{label(state)}</option>)}
            </select>
          </Field>
          <Field label={toState === 'closed' ? 'Resolution code' : toState === 'reopened' ? 'Reopening basis' : 'Reason'}><input value={reason} onChange={(event) => setReason(event.target.value)} /></Field>
          {toState === 'closed' || toState === 'reopened' ? <Field label="Evidence document version"><input value={evidenceVersionId} onChange={(event) => setEvidenceVersionId(event.target.value)} required /></Field> : null}
          {toState === 'reopened' ? <p>Creates an evidence work item due in seven days.</p> : null}
        </>
      )}
    </CommandDialog>
  );
}

interface CaseSubjectCorrectionPrerequisites {
  identityEvidence: IdentityEvidenceSummary[] | { kind: 'rejected'; message: string };
  evidenceDocuments: CaseSubjectCorrectionEvidenceDocument[];
  approvalCheckers: ServicingApprovalCheckerSummary[] | { kind: 'rejected'; message: string };
  policyVersions: PolicyVersionSummary[] | { kind: 'rejected'; message: string };
  approvals: { kind: 'found'; approvals: { id: string; status: string; target: unknown }[] } | { kind: 'rejected'; message: string };
}

function CaseSubjectCorrectionDialog({ spec, onClose }: Props<'case.subject.correct'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  const fresh = useResource<CaseDetail>(institutionPath(institution.institutionId, `/cases/${encodeURIComponent(spec.record.id)}`));
  const record = fresh.data?.case ?? spec.record;
  const [memberId, setMemberId] = useState(spec.record.memberId);
  const [accountId, setAccountId] = useState(spec.record.accountId ?? '');
  const [evidenceVersionId, setEvidenceVersionId] = useState('');
  const [approvalId, setApprovalId] = useState('');
  const prerequisites = useResource<CaseSubjectCorrectionPrerequisites>(institutionPath(institution.institutionId,
    `/servicing/case-subject-correction/${encodeURIComponent(spec.record.memberId)}${queryString({ correctedMemberId: memberId.trim() })}`));
  const evidence = prerequisites.data?.evidenceDocuments ?? [];
  const checkers = Array.isArray(prerequisites.data?.approvalCheckers) ? prerequisites.data.approvalCheckers : [];
  const policies = Array.isArray(prerequisites.data?.policyVersions) ? prerequisites.data.policyVersions : [];
  const approvals = prerequisites.data?.approvals.kind === 'found' ? prerequisites.data.approvals.approvals.filter((item) => item.status === 'approved') : [];
  return (
    <CommandDialog title={`Correct the subject of ${record.caseNumber}`} institutionId={institution.institutionId} review submitLabel="Correct subject" onClose={onClose}
      submitDisabled={prerequisites.loading || prerequisites.error !== null}
      onOpenReceipt={(number) => openRecord('receipt', number)} successText={() => `Case ${record.caseNumber} subject corrected and restricted for access review.`}
      build={() => evidenceVersionId === '' ? { error: 'Choose current versioned evidence.', field: 'evidenceVersionId' }
        : approvalId === '' ? { error: 'Choose an approved independent decision.', field: 'approvalId' }
          : { command: { kind: 'case.subject.correct', caseId: record.id, expectedVersion: record.version, correctMemberId: memberId.trim(), correctAccountId: accountId.trim() === '' ? null : accountId.trim(), evidenceVersionId, approvalId } }}>
      {() => (
        <>
          <p>This consequential correction preserves case history, restricts linked evidence, and requires current versioned evidence plus an approval assigned to the acting checker.</p>
          {prerequisites.loading ? <p className="muted" role="status">Loading evidence and approval prerequisites…</p> : null}
          {prerequisites.error === null ? null : <p className="error" role="alert">Prerequisites could not be loaded: {prerequisites.error}</p>}
          <Field label="Correct member ID"><input value={memberId} onChange={(event) => { setMemberId(event.target.value); setEvidenceVersionId(''); setApprovalId(''); }} required /></Field>
          <Field label="Correct account ID"><input value={accountId} onChange={(event) => { setAccountId(event.target.value); setApprovalId(''); }} placeholder="Leave blank for member only" /></Field>
          <Field label="Evidence document version"><select value={evidenceVersionId} onChange={(event) => { setEvidenceVersionId(event.target.value); setApprovalId(''); }} required><option value="">Choose current evidence…</option>{evidence.map((item) => <option key={item.versionId} value={item.versionId}>{item.memberId === record.memberId ? 'Original' : 'Corrected'} · {item.documentType} · {item.displayName} · {item.versionId}</option>)}</select></Field>
          <Field label="Approved decision"><select value={approvalId} onChange={(event) => setApprovalId(event.target.value)} required><option value="">Choose approved decision…</option>{approvals.map((item) => <option key={item.id} value={item.id}>{item.id}</option>)}</select></Field>
          <p className="muted">The proposal must be requested under an effective policy ({policies.map((item) => item.version).join(', ') || 'none available'}) and independently decided by an eligible checker ({checkers.map((item) => item.actorNumber).join(', ') || 'none available'}). The approval binds the exact member, account, evidence, case version, and action.</p>
        </>
      )}
    </CommandDialog>
  );
}

/** Renders the dialog for a spec. Each dialog submits one shared command and reports its receipt or rejection. */
export function DialogHost({ spec, onClose }: { spec: DialogSpec; onClose: () => void }): ReactNode {
  switch (spec.kind) {
    case 'member.create': return <MemberCreateDialog spec={spec} onClose={onClose} />;
    case 'contact.update': return <ContactDialog spec={spec} onClose={onClose} />;
    case 'note': return <NoteDialog spec={spec} onClose={onClose} />;
    case 'account.open': return <AccountOpenDialog spec={spec} onClose={onClose} />;
    case 'money': return <MoneyDialog spec={spec} onClose={onClose} />;
    case 'account.close': return <AccountCloseDialog spec={spec} onClose={onClose} />;
    case 'case.open': return <CaseOpenDialog spec={spec} onClose={onClose} />;
    case 'case.assign': return <CaseAssignDialog spec={spec} onClose={onClose} />;
    case 'case.transition': return <CaseTransitionDialog spec={spec} onClose={onClose} />;
    case 'case.subject.correct': return <CaseSubjectCorrectionDialog spec={spec} onClose={onClose} />;
    case 'operation': return <OperationDialogContainer spec={spec} onClose={onClose} />;
  }
}

function OperationDialogContainer({ spec, onClose }: Props<'operation'>): ReactNode {
  const { institution } = useWorkspace();
  const { openRecord } = useShell();
  return (
    <OperationDialog
      spec={spec.spec} inquiry={spec.inquiry === true} institutionId={institution.institutionId} context={spec.context ?? {}}
      onClose={onClose} onOpenReceipt={(number) => openRecord('receipt', number)}
    />
  );
}

export function ConfirmDialog({ title, children, onConfirm, onClose, confirmLabel }: { title: string; children: ReactNode; onConfirm: () => void; onClose: () => void; confirmLabel: string }): ReactNode {
  return (
    <Dialog title={title} onClose={onClose} footer={<><button type="button" onClick={onClose}>Cancel</button><button type="button" className="primary" onClick={() => { onConfirm(); onClose(); }}>{confirmLabel}</button></>}>
      {children}
    </Dialog>
  );
}
