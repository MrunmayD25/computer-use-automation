import { useRef, useState, type ReactNode } from 'react';

import { GRID_COLUMNS, type GridId } from '../../shared/columns.js';
import { listApprovalsApi, listRecords, type FinanceListRow } from '../api.js';
import { formatInstant, label as displayLabel, text as asText } from '../format.js';
import { useColumnLayout } from '../grid/useColumnLayout.js';
import { VirtualGrid, type GridHandle, type GridRange } from '../grid/VirtualGrid.js';
import { cleanFilters, type ListId, type ListParams } from '../model/route.js';
import { operationFor, INQUIRIES } from '../ops/registry.js';
import { navigate } from '../router.js';
import { useShell } from '../shell.js';
import { MenuButton, type MenuItem } from '../ui/Menu.js';
import { renderCell } from './cells.js';
import { useFlatRows } from './sources.js';
import { useWorkspace } from '../workspace.js';

export type RecordListId = Exclude<ListId, 'members' | 'accounts' | 'cases' | 'documents' | 'activity'>;

export interface RecordListRow extends Record<string, unknown> {
  id: string;
  label: string;
  status: string | null;
}

export interface RecordListConfig {
  grid: GridId;
  /** Finance list resource; 'approval' is served by the approvals endpoint. */
  resource: string;
  title: string;
  noun: string;
  /** The record kinds rows open into; 'resource' routes to `/resource/<resource>/<id>`. */
  opens: 'resource' | 'approval';
  /** Operation kinds offered on the toolbar as creation actions. */
  create?: string;
  /** Operation/inquiry kinds offered on a row, given the row fields. */
  rowActions?: (row: RecordListRow) => { kind: string; label: string; context: Record<string, unknown> }[];
}

const CFG: Readonly<Record<RecordListId, RecordListConfig>> = {
  payments: { grid: 'payments', resource: 'payment', title: 'Payments', noun: 'payment', opens: 'resource', create: 'payment.create' },
  schedules: { grid: 'schedules', resource: 'payment-schedule', title: 'Payment schedules', noun: 'schedule', opens: 'resource', create: 'payment.schedule.create' },
  beneficiaries: { grid: 'beneficiaries', resource: 'beneficiary', title: 'Beneficiaries', noun: 'beneficiary', opens: 'resource', create: 'beneficiary.create' },
  cards: { grid: 'cards', resource: 'card', title: 'Cards', noun: 'card', opens: 'resource' },
  disputes: { grid: 'disputes', resource: 'dispute', title: 'Disputes', noun: 'dispute', opens: 'resource', create: 'dispute.open' },
  loans: { grid: 'loans', resource: 'loan', title: 'Loans', noun: 'loan', opens: 'resource', create: 'loan.application.prepare' },
  fees: { grid: 'fees', resource: 'fee', title: 'Fees', noun: 'fee', opens: 'resource', create: 'fee.assess' },
  holds: { grid: 'holds', resource: 'hold', title: 'Holds', noun: 'hold', opens: 'resource', create: 'account.hold.place' },
  maintenance: { grid: 'maintenance', resource: 'maintenance-request', title: 'Maintenance requests', noun: 'request', opens: 'resource', create: 'maintenance.draft.save' },
  communications: { grid: 'communications', resource: 'communication-job', title: 'Communications', noun: 'communication', opens: 'resource', create: 'communication.send' },
  approvals: { grid: 'approvals', resource: 'approval', title: 'Approvals', noun: 'approval', opens: 'approval' },
  batches: { grid: 'batches', resource: 'batch', title: 'Batches', noun: 'batch', opens: 'resource', create: 'batch.import' },
  suspense: { grid: 'suspense', resource: 'suspense-item', title: 'Suspense items', noun: 'suspense item', opens: 'resource' },
  settlements: { grid: 'settlements', resource: 'settlement-batch', title: 'Settlement batches', noun: 'settlement batch', opens: 'resource' },
};

export function isRecordList(list: ListId): list is RecordListId {
  return Object.hasOwn(CFG, list);
}

export function recordListConfig(list: RecordListId): RecordListConfig {
  return CFG[list];
}

export function listForResource(resource: string): RecordListId | undefined {
  return (Object.keys(CFG) as RecordListId[]).find((key) => CFG[key].resource === resource);
}

function approvalRows(items: { id: string; status: string; fingerprint: string; target: unknown; expiresAt: string; amountLimit: { minorUnits: number; currency: string } | null; maker: { displayName: string }; checker: { displayName: string } }[]): RecordListRow[] {
  return items.map((row) => {
    const target = row.target !== null && typeof row.target === 'object' ? row.target as Record<string, unknown> : {};
    return {
      id: row.id, label: asText(target.kind) || row.id, status: row.status,
      targetKind: asText(target.kind), target, makerName: row.maker.displayName, checkerName: row.checker.displayName,
      amountMinorUnits: row.amountLimit?.minorUnits ?? null, currency: row.amountLimit?.currency ?? null, expiresAt: row.expiresAt, fingerprint: row.fingerprint,
    };
  });
}

function SearchBox({ value, onCommit, label }: { value: string; onCommit: (text: string) => void; label: string }): ReactNode {
  const [text, setText] = useState(value);
  const [seen, setSeen] = useState(value);
  if (seen !== value) { setSeen(value); setText(value); }
  return <input type="search" className="search-box" aria-label={label} placeholder={label} value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') onCommit(text); }} onBlur={() => onCommit(text)} />;
}

/** One institution-scoped finance record list, virtualized through the shared grid. */
export function RecordList({ list, params, active }: { list: RecordListId; params: ListParams; active: boolean }): ReactNode {
  const workspace = useWorkspace();
  const { institution, session, can, notify, dataVersion } = workspace;
  const { openRecord, openDialog } = useShell();
  const config = CFG[list];
  const institutionId = institution.institutionId;
  const { layout, apply } = useColumnLayout(config.grid, session.operator.actorNumber, (message) => notify('error', message));
  const [range, setRange] = useState<GridRange>({ first: 0, last: 0 });
  const [activeRow, setActiveRow] = useState<RecordListRow | null>(null);
  const gridHandle = useRef<GridHandle>(null);
  const gridKey = `list-${list}`;

  const filters = cleanFilters(list, params.filters);
  const window = `${institutionId}|${list}|${JSON.stringify(filters)}`;
  const { source, snapshot } = useFlatRows<RecordListRow>(window, async (offset, pageSize, signal) => {
    if (config.resource === 'approval') {
      const page = await listApprovalsApi(institutionId);
      const state = typeof filters.state === 'string' ? filters.state : '';
      const rows = approvalRows(page.approvals).filter((row) => state === '' || row.status === state);
      return { items: rows.slice(offset, offset + pageSize), total: rows.length, offset, limit: pageSize };
    }
    const page = await listRecords(institutionId, config.resource, { ...filters, offset, limit: pageSize }, signal);
    return { items: page.items.map((row: FinanceListRow) => ({ id: row.id, label: row.label, status: row.status, ...row.fields })), total: page.total, offset: page.offset, limit: page.limit };
  }, dataVersion);

  const update = (patch: Partial<ListParams>): void => navigate({ view: 'list', institutionId, list, params: { ...params, ...patch } });
  const setFilter = (key: string, value: string): void => update({ filters: { ...params.filters, [key]: value } });

  const open = (row: RecordListRow): void => {
    if (config.opens === 'resource') openRecord('resource', row.id, config.resource);
  };

  const rowMenu = (row: RecordListRow): MenuItem[] => {
    const items: MenuItem[] = [];
    if (config.opens === 'resource') items.push({ id: 'open', label: `Open ${row.label}`, onSelect: () => open(row) });
    if (config.resource === 'approval') {
      const target = row.target as Record<string, unknown>;
      const kind = asText(target.kind);
      const decide = operationFor('approval.decide');
      if (decide !== undefined) items.push({ id: 'decide', label: 'Decide…', disabled: row.status !== 'pending' || !can('approval.decide'), disabledReason: 'Only a pending approval can be decided.', onSelect: () => openDialog({ kind: 'operation', spec: decide, context: { initial: { approvalId: row.id, expectedFingerprint: String(row.fingerprint) } } }) });
      const spec = operationFor(kind);
      if (spec !== undefined) items.push({ id: 'prepare', label: `Prepare ${displayLabel(kind)}…`, disabled: row.status !== 'approved' || !can(spec.kind as never), disabledReason: row.status === 'approved' ? 'Not granted to this operator.' : 'Only an approved request can be executed.', onSelect: () => openDialog({ kind: 'operation', spec, context: { initial: { ...target, approvalId: row.id } } }) });
      return items;
    }
    for (const action of config.rowActions?.(row) ?? []) {
      const spec = operationFor(action.kind) ?? INQUIRIES.find((inquiry) => inquiry.kind === action.kind);
      if (spec === undefined) continue;
      items.push({ id: action.kind, label: `${action.label}…`, disabled: !can(action.kind as never), onSelect: () => openDialog({ kind: 'operation', spec, inquiry: INQUIRIES.includes(spec), context: { initial: action.context } }) });
    }
    return items;
  };

  const createSpec = config.create === undefined ? undefined : operationFor(config.create);
  const scopeLabels: ReactNode = Object.entries(filters).filter(([key]) => key === 'memberId' || key === 'accountId').map(([key, value]) => (
    <span key={key} className="badge scope">{key === 'memberId' ? 'Member' : 'Account'} {String(value)} <button type="button" className="link" onClick={() => { const next = Object.fromEntries(Object.entries(params.filters).filter(([filter]) => filter !== key)); update({ filters: next }); }}>×</button></span>
  ));

  const total = snapshot.total ?? 0;
  return (
    <section className="list-view" hidden={!active} aria-label={`${config.title} list`} data-list={list}>
      <div className="toolbar" role="toolbar" aria-label={`${config.title} search`}>
        {Object.hasOwn(filters, 'query') || !['schedules', 'fees', 'approvals'].includes(list) ? <SearchBox label={`Search ${config.title.toLowerCase()}`} value={typeof filters.query === 'string' ? filters.query : ''} onCommit={(text) => setFilter('query', text)} /> : null}
        <label className="filter">Status
          <select value={typeof filters.state === 'string' ? filters.state : ''} onChange={(event) => setFilter('state', event.target.value)}>
            <option value="">Any</option>
            {(list === 'approvals' ? ['pending', 'approved', 'denied', 'expired', 'consumed'] : ['draft', 'pending-approval', 'approved', 'released', 'settled', 'cancelled', 'open', 'submitted', 'under-review', 'applied', 'rejected', 'withdrawn', 'active', 'ended', 'queued', 'accepted', 'delivered', 'bounced', 'planned', 'held', 'cleared', 'matched', 'unmatched', 'imported', 'reviewed', 'posted', 'open_']).map((state) => <option key={state} value={state}>{displayLabel(state)}</option>)}
          </select>
        </label>
        {scopeLabels}
        <MenuButton label="Columns" items={() => [
          ...GRID_COLUMNS[config.grid].map((column, index) => ({
            id: column.id, label: `${column.label}${layout.pinned.includes(column.id) ? ' (pinned)' : ''}`, checked: !layout.hidden.includes(column.id),
            ...(index === 0 ? { section: 'Show columns' } : {}), onSelect: () => apply({ kind: 'toggleHidden', column: column.id }),
          })),
          { id: 'reset', label: 'Reset to default layout', section: 'Layout', onSelect: () => apply({ kind: 'reset' }) },
        ]}>Columns ▾</MenuButton>
        {createSpec === undefined ? null : <button type="button" className="tool-button" disabled={!can(createSpec.kind as never)} onClick={() => openDialog({ kind: 'operation', spec: createSpec, context: { initial: { memberId: filters.memberId, accountId: filters.accountId } } })}>New {config.noun}…</button>}
        {Object.keys(filters).length > 0 ? <button type="button" className="tool-button" onClick={() => update({ filters: {} })}>Clear filters</button> : null}
      </div>
      <div className="list-body">
        <div className="list-grid">
          <VirtualGrid<RecordListRow>
            key={window} gridId={config.grid} gridKey={gridKey} label={`${config.title} results`} source={source} layout={layout} onColumnAction={apply}
            sort={null} sortable={() => false} onSort={() => undefined}
            cell={(row, column) => renderCell(config.grid, row, column)} rowLabel={(row) => row.label}
            onActiveRow={setActiveRow} onOpen={open} rowMenu={rowMenu}
            onRange={setRange} handle={gridHandle}
            emptyText={snapshot.loading ? 'Loading…' : `No ${config.noun}s match.`}
          />
        </div>
        <aside className="preview" aria-label="Selected record">
          {activeRow === null ? <p className="muted">Choose a row to preview it.</p> : (
            <>
              <h3>{activeRow.label}</h3>
              <dl className="facts">
                {Object.entries(activeRow).filter(([key, value]) => !['id', 'label', 'target'].includes(key) && value !== null && typeof value !== 'object').slice(0, 12).map(([key, value]) => (
                  <div key={key}><dt>{displayLabel(key.replace(/[A-Z]/gu, (letter) => ` ${letter.toLowerCase()}`))}</dt><dd>{key === 'expiresAt' || key.endsWith('At') ? formatInstant(String(value)) : String(value)}</dd></div>
                ))}
              </dl>
            </>
          )}
        </aside>
      </div>
      <footer className="list-status">
        <span data-range-first={range.first} data-total={total}>{total === 0 ? 'No rows' : `Rows ${(range.first + 1).toLocaleString('en-US')}–${(range.last + 1).toLocaleString('en-US')} of ${total.toLocaleString('en-US')}`}</span>
        <span className="pager">
          <button type="button" disabled={range.first === 0} onClick={() => gridHandle.current?.scrollToIndex(Math.max(0, range.first - 200))}>Previous</button>
          <button type="button" disabled={range.last + 1 >= total} onClick={() => gridHandle.current?.scrollToIndex(range.last + 1)}>Next</button>
        </span>
        {snapshot.error === null ? null : <span className="error">{snapshot.error}</span>}
      </footer>
    </section>
  );
}
