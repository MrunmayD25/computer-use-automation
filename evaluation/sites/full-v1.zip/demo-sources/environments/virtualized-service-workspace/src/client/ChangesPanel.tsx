import type { ReactNode } from 'react';

import { label } from './format.js';
import type { Draft } from './model/drafts.js';
import { useShell } from './shell.js';
import { useStamp, useWorkspace } from './workspace.js';

function DraftItem({ draft, current }: { draft: Draft; current: boolean }): ReactNode {
  const { saveDraft, rebaseDraft, dispatchDrafts } = useWorkspace();
  const { openRecord } = useShell();
  const stamp = useStamp(draft.kind === 'account' ? 'accounts' : 'members', current ? draft.recordId : null);
  const { status } = draft;
  const changedElsewhere = stamp != null && status.phase === 'draft' && stamp.version > draft.baseVersion;
  return (
    <li className={`draft-item phase-${status.phase}`} data-draft-key={draft.key} data-draft-phase={status.phase}>
      <div className="draft-title">
        <strong>{draft.label}</strong> <span className="muted">{draft.kind} · {draft.institutionId}</span>
        <span className={`badge phase-${status.phase}`}>{status.phase}</span>
      </div>
      <ul className="draft-fields">
        {Object.entries(draft.fields).map(([field, value]) => (
          <li key={field}>{label(field.replace('_', ' '))}: <del>{draft.original[field] === '' ? '(empty)' : draft.original[field]}</del> → <ins>{value === '' ? '(cleared)' : value}</ins>
            {status.phase === 'draft' || status.phase === 'rejected' ? <button type="button" className="link" onClick={() => dispatchDrafts({ type: 'discardField', key: draft.key, field })}>Undo</button> : null}
          </li>
        ))}
      </ul>
      {status.phase === 'rejected' ? <p className="error">Rejected ({status.code}): {status.message}</p> : null}
      {status.phase === 'unknown' ? <p className="warning">{status.message}</p> : null}
      {changedElsewhere ? <p className="warning">{draft.label} changed elsewhere (now version {stamp.version}, your edit started at {draft.baseVersion}). Saving will be rejected until you use the current version.</p> : null}
      {draft.receipts.length > 0 ? <p>Receipts: {draft.receipts.map((number) => <button key={number} type="button" className="link" onClick={() => openRecord('receipt', number)}>{number}</button>)}</p> : null}
      <div className="button-row">
        {current ? <button type="button" onClick={() => openRecord(draft.kind, draft.recordId)}>Open</button> : null}
        {status.phase === 'draft' || status.phase === 'rejected' || status.phase === 'unknown' ? <button type="button" className="primary" onClick={() => { void saveDraft(draft.key); }}>{status.phase === 'unknown' ? 'Retry' : 'Save'}</button> : null}
        {changedElsewhere || (status.phase === 'rejected' && status.code === 'stale_version') ? <button type="button" onClick={() => { void rebaseDraft(draft.key); }}>Use current version</button> : null}
        {status.phase === 'pending' ? <span className="muted">Saving…</span> : <button type="button" onClick={() => dispatchDrafts({ type: 'discard', key: draft.key })}>{status.phase === 'committed' ? 'Dismiss' : 'Discard'}</button>}
      </div>
    </li>
  );
}

/** Every unsaved, submitted, rejected and recently committed edit, one entry per record. */
export function ChangesPanel({ onClose }: { onClose: () => void }): ReactNode {
  const { drafts, institution, saveDraft } = useWorkspace();
  const list = [...drafts.values()];
  const saveable = list.filter((draft) => draft.institutionId === institution.institutionId && draft.status.phase === 'draft');
  return (
    <aside className="changes-panel" aria-label="Changes">
      <header className="panel-header">
        <h2>Changes ({list.length})</h2>
        <div className="button-row">
          <button type="button" disabled={saveable.length === 0} onClick={() => { void (async () => { for (const draft of saveable) await saveDraft(draft.key); })(); }}>Save all ({saveable.length})</button>
          <button type="button" className="icon-button" aria-label="Close changes" onClick={onClose}>×</button>
        </div>
      </header>
      {list.length === 0 ? <p className="muted">No unsaved changes. Edits you make in grids and records appear here per record until saved or discarded.</p> : (
        <ul className="draft-list">{list.map((draft) => <DraftItem key={draft.key} draft={draft} current={draft.institutionId === institution.institutionId} />)}</ul>
      )}
    </aside>
  );
}
