export type ListId =
  | 'members' | 'accounts' | 'cases' | 'documents' | 'activity'
  | 'payments' | 'schedules' | 'beneficiaries' | 'cards' | 'disputes' | 'loans' | 'fees' | 'holds'
  | 'maintenance' | 'communications' | 'approvals' | 'batches' | 'suspense' | 'settlements';
export type RecordKind = 'member' | 'account' | 'case' | 'receipt' | 'document' | 'resource';
export type FilterValue = string | boolean | readonly string[];

export interface SortState {
  field: string;
  direction: 'asc' | 'desc';
}

export interface ListParams {
  /** Filter values by saved-search filter name; `query` is the free-text search. */
  filters: Readonly<Record<string, FilterValue>>;
  sort: SortState | null;
  groupBy: string | null;
  /** Saved search the list was opened from, if any. */
  savedSearchId: string | null;
  /** Result limit carried over from a saved search. */
  maxResults: number | null;
}

export type Route =
  | { view: 'list'; institutionId: string; list: ListId; params: ListParams }
  | { view: 'record'; institutionId: string; kind: RecordKind; id: string; resource?: string };

type FilterKind = 'text' | 'list' | 'boolean';

/** Filters each list understands, with how they appear in the URL. */
export const LIST_FILTERS: Readonly<Record<ListId, Readonly<Record<string, FilterKind>>>> = {
  members: { query: 'text', status: 'text' },
  accounts: { query: 'text', status: 'text', currency: 'text' },
  cases: { query: 'text', states: 'list', queueIds: 'list', priority: 'text', assignedActorId: 'text', overdue: 'boolean' },
  documents: { query: 'text', documentType: 'text' },
  activity: { query: 'text', kind: 'text' },
  payments: { query: 'text', state: 'text', memberId: 'text', accountId: 'text' },
  schedules: { state: 'text', memberId: 'text', accountId: 'text' },
  beneficiaries: { query: 'text', state: 'text', memberId: 'text' },
  cards: { query: 'text', state: 'text', memberId: 'text', accountId: 'text' },
  disputes: { query: 'text', state: 'text', memberId: 'text', accountId: 'text' },
  loans: { query: 'text', state: 'text', memberId: 'text', accountId: 'text' },
  fees: { state: 'text', memberId: 'text', accountId: 'text' },
  holds: { query: 'text', state: 'text', memberId: 'text', accountId: 'text' },
  maintenance: { query: 'text', state: 'text', memberId: 'text' },
  communications: { query: 'text', state: 'text', memberId: 'text' },
  approvals: { state: 'text' },
  batches: { query: 'text', state: 'text' },
  suspense: { query: 'text', state: 'text' },
  settlements: { query: 'text', state: 'text' },
};

const URL_NAMES: Readonly<Record<string, string>> = { query: 'q', states: 'status', queueIds: 'queue', assignedActorId: 'assignee', documentType: 'type', memberId: 'member', accountId: 'account', parentId: 'parent' };
const LISTS: readonly ListId[] = ['members', 'accounts', 'cases', 'documents', 'activity', 'payments', 'schedules', 'beneficiaries', 'cards', 'disputes', 'loans', 'fees', 'holds', 'maintenance', 'communications', 'approvals', 'batches', 'suspense', 'settlements'];
const RECORDS: readonly RecordKind[] = ['member', 'account', 'case', 'receipt', 'document'];

export const EMPTY_PARAMS: ListParams = { filters: {}, sort: null, groupBy: null, savedSearchId: null, maxResults: null };

function urlName(filter: string): string {
  return URL_NAMES[filter] ?? filter;
}

export function parseRoute(pathname: string, search: string): Route | null {
  const parts = pathname.split('/').filter((part) => part.length > 0).map((part) => decodeURIComponent(part));
  const [institutionId, second, third, fourth] = parts;
  if (institutionId === undefined || second === undefined) return null;
  if (second === 'resource' && third !== undefined && fourth !== undefined && parts.length === 4) return { view: 'record', institutionId, kind: 'resource', resource: third, id: fourth };
  if (parts.length === 2 && (LISTS as readonly string[]).includes(second)) {
    const list = second as ListId;
    const query = new URLSearchParams(search);
    const filters: Record<string, FilterValue> = {};
    for (const [filter, kind] of Object.entries(LIST_FILTERS[list])) {
      const raw = query.get(urlName(filter));
      if (raw === null || raw === '') continue;
      if (kind === 'list') filters[filter] = raw.split(',').filter((value) => value.length > 0);
      else if (kind === 'boolean') { if (raw === '1' || raw === 'true') filters[filter] = true; }
      else filters[filter] = raw;
    }
    const sortRaw = query.get('sort');
    const [field, direction] = sortRaw === null ? [] : sortRaw.split(':');
    const sort: SortState | null = field !== undefined && field !== '' && (direction === 'asc' || direction === 'desc') ? { field, direction } : null;
    const max = Number(query.get('max') ?? '');
    const maxResults = Number.isInteger(max) && max >= 1 && max <= 10_000 ? max : null;
    return { view: 'list', institutionId, list, params: { filters, sort, groupBy: query.get('group'), savedSearchId: query.get('saved'), maxResults } };
  }
  if (parts.length === 3 && third !== undefined && (RECORDS as readonly string[]).includes(second)) return { view: 'record', institutionId, kind: second as RecordKind, id: third };
  return null;
}

export function formatRoute(route: Route): string {
  const base = `/${encodeURIComponent(route.institutionId)}`;
  if (route.view === 'record' && route.kind === 'resource') return `${base}/resource/${encodeURIComponent(route.resource ?? '')}/${encodeURIComponent(route.id)}`;
  if (route.view === 'record') return `${base}/${route.kind}/${encodeURIComponent(route.id)}`;
  const query = new URLSearchParams();
  for (const [filter, kind] of Object.entries(LIST_FILTERS[route.list])) {
    const value = route.params.filters[filter];
    if (value === undefined) continue;
    if (kind === 'list' && Array.isArray(value) && value.length > 0) query.set(urlName(filter), value.join(','));
    else if (kind === 'boolean' && value === true) query.set(urlName(filter), '1');
    else if (kind === 'text' && typeof value === 'string' && value !== '') query.set(urlName(filter), value);
  }
  if (route.params.sort !== null) query.set('sort', `${route.params.sort.field}:${route.params.sort.direction}`);
  if (route.params.groupBy !== null) query.set('group', route.params.groupBy);
  if (route.params.savedSearchId !== null) query.set('saved', route.params.savedSearchId);
  if (route.params.maxResults !== null) query.set('max', String(route.params.maxResults));
  const text = query.toString();
  return `${base}/${route.list}${text === '' ? '' : `?${text}`}`;
}

/** Filters without empty values, in canonical order, so equal meanings compare equal. */
export function cleanFilters(list: ListId, filters: Readonly<Record<string, FilterValue>>): Record<string, FilterValue> {
  const clean: Record<string, FilterValue> = {};
  for (const [filter, kind] of Object.entries(LIST_FILTERS[list])) {
    const value = filters[filter];
    if (kind === 'list' && Array.isArray(value) && value.length > 0) clean[filter] = [...(value as readonly string[])];
    else if (kind === 'boolean' && value === true) clean[filter] = true;
    else if (kind === 'text' && typeof value === 'string' && value.trim() !== '') clean[filter] = value.trim();
  }
  return clean;
}

/**
 * Identity of the set of matching records. Sort and grouping reorder a result set without changing its
 * members, except under a result limit, where the sort decides which records fall inside the limit.
 */
export function matchKey(institutionId: string, list: ListId, params: ListParams): string {
  return JSON.stringify([institutionId, list, cleanFilters(list, params.filters), params.maxResults, params.maxResults === null ? null : params.sort]);
}

/** Identity of one ordered result window. */
export function windowKey(institutionId: string, list: ListId, params: ListParams): string {
  return JSON.stringify([institutionId, list, cleanFilters(list, params.filters), params.maxResults, params.sort, params.groupBy]);
}
