export interface GroupSpan {
  key: string;
  count: number;
}

export type GroupPosition = { kind: 'header'; group: number } | { kind: 'row'; group: number; offset: number };

export interface GroupLayout {
  /** Number of display rows: one header per group plus the rows of expanded groups. */
  length: number;
  locate: (index: number) => GroupPosition | null;
  headerIndex: (group: number) => number;
}

/** Flattens groups into display rows so a single virtualizer can scroll headers and grouped rows together. */
export function groupLayout(groups: readonly GroupSpan[], expanded: ReadonlySet<string>): GroupLayout {
  const starts: number[] = [];
  let length = 0;
  for (const group of groups) {
    starts.push(length);
    length += 1 + (expanded.has(group.key) ? group.count : 0);
  }
  return {
    length,
    headerIndex: (group) => starts[group] ?? -1,
    locate(index) {
      if (!Number.isInteger(index) || index < 0 || index >= length) return null;
      let low = 0;
      let high = starts.length - 1;
      while (low < high) {
        const middle = Math.ceil((low + high) / 2);
        if ((starts[middle] ?? 0) <= index) low = middle; else high = middle - 1;
      }
      const offset = index - (starts[low] ?? 0);
      return offset === 0 ? { kind: 'header', group: low } : { kind: 'row', group: low, offset: offset - 1 };
    },
  };
}
