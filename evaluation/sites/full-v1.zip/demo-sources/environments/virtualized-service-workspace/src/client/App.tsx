import { useCallback, useEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';

import type { SessionInfo } from '../shared/api.js';
import { ChangesPanel } from './ChangesPanel.js';
import { DialogHost } from './dialogs.js';
import { formatInstant } from './format.js';
import { LIST_CONFIG, ListView } from './lists/ListView.js';
import { isRecordList, RecordList, recordListConfig } from './lists/RecordList.js';
import { EMPTY_PARAMS, type ListId, type ListParams, type RecordKind, type Route } from './model/route.js';
import { AccountRecord } from './records/AccountRecord.js';
import { CaseRecord } from './records/CaseRecord.js';
import { MemberRecord } from './records/MemberRecord.js';
import { ReceiptRecord } from './records/ReceiptRecord.js';
import { ResourceRecord } from './records/ResourceRecord.js';
import { INQUIRIES, OPERATIONS } from './ops/registry.js';
import { navigate, useRoute } from './router.js';
import { resourceTabKey, ShellContext, tabKeyOf, type DialogSpec, type RecordContext, type ShellValue } from './shell.js';
import { MenuButton } from './ui/Menu.js';
import { WorkspaceProvider, useWorkspace } from './workspace.js';

const LISTS: readonly ListId[] = ['members', 'accounts', 'cases', 'documents', 'activity', 'payments', 'schedules', 'beneficiaries', 'cards', 'disputes', 'loans', 'fees', 'holds', 'maintenance', 'communications', 'approvals', 'batches', 'suspense', 'settlements'];
const MAX_RECORD_TABS = 12;
const TAB_STORAGE = 'vsw:tabs:v1';

interface RecordTab {
  key: string;
  institutionId: string;
  kind: RecordKind;
  id: string;
  resource?: string;
}

function storedTabs(): RecordTab[] {
  try {
    const parsed = JSON.parse(sessionStorage.getItem(TAB_STORAGE) ?? '[]') as RecordTab[];
    return Array.isArray(parsed) ? parsed.slice(0, MAX_RECORD_TABS) : [];
  } catch {
    return [];
  }
}

function RecordView({ tab }: { tab: RecordTab }): ReactNode {
  switch (tab.kind) {
    case 'member': return <MemberRecord id={tab.id} />;
    case 'account': return <AccountRecord id={tab.id} />;
    case 'case': return <CaseRecord id={tab.id} />;
    case 'receipt': return <ReceiptRecord id={tab.id} />;
    case 'document': return <ResourceRecord resource="document" id={tab.id} />;
    case 'resource': return <ResourceRecord resource={tab.resource ?? ''} id={tab.id} />;
  }
}

function Shell({ route }: { route: Route | null }): ReactNode {
  const workspace = useWorkspace();
  const { session, institution, profile, drafts, notices, switchOperator, notify } = workspace;
  const institutionId = institution.institutionId;
  const [tabs, setTabs] = useState<RecordTab[]>(storedTabs);
  const [contexts, setContexts] = useState<ReadonlyMap<string, RecordContext>>(new Map());
  const [dialog, setDialog] = useState<DialogSpec | null>(null);
  const [changesOpen, setChangesOpen] = useState(false);
  const lastLists = useRef(new Map<string, ListParams>());
  const recency = useRef(new Map<string, number>());
  const [visited, setVisited] = useState<ReadonlySet<ListId>>(new Set());

  const routeKey = (route: Extract<Route, { view: 'record' }>): string => route.kind === 'resource' ? resourceTabKey(route.institutionId, route.resource ?? '', route.id) : tabKeyOf(route.institutionId, route.kind, route.id);
  const activeKey = route?.view === 'record' ? routeKey(route) : null;
  const activeList = route?.view === 'list' ? route.list : null;
  if (route?.view === 'list') lastLists.current.set(`${route.institutionId}/${route.list}`, route.params);
  if (activeList !== null && !visited.has(activeList)) setVisited(new Set([...visited, activeList]));

  useEffect(() => { sessionStorage.setItem(TAB_STORAGE, JSON.stringify(tabs)); }, [tabs]);

  useEffect(() => {
    if (route?.view !== 'record') return;
    const key = routeKey(route);
    recency.current.set(key, Date.now());
    setTabs((previous) => {
      if (previous.some((tab) => tab.key === key)) return previous;
      const next = [...previous, { key, institutionId: route.institutionId, kind: route.kind, id: route.id, ...(route.resource === undefined ? {} : { resource: route.resource }) }];
      if (next.length <= MAX_RECORD_TABS) return next;
      const evicted = next.filter((tab) => tab.key !== key).sort((a, b) => (recency.current.get(a.key) ?? 0) - (recency.current.get(b.key) ?? 0))[0];
      if (evicted !== undefined) notify('info', `Closed the least recently used tab to keep ${String(MAX_RECORD_TABS)} records open. Unsaved changes stay in Changes.`);
      return next.filter((tab) => tab !== evicted);
    });
  }, [route, notify]);

  const listRoute = useCallback((list: ListId): Route => ({ view: 'list', institutionId, list, params: lastLists.current.get(`${institutionId}/${list}`) ?? EMPTY_PARAMS }), [institutionId]);

  const shell = useMemo<ShellValue>(() => ({
    openRecord: (kind, id, resource) => navigate({ view: 'record', institutionId, kind, id, ...(resource === undefined ? {} : { resource }) }),
    openDialog: setDialog,
    publishContext: (tabKey, context) => setContexts((previous) => {
      if (context === null ? !previous.has(tabKey) : JSON.stringify(previous.get(tabKey)) === JSON.stringify(context)) return previous;
      const next = new Map(previous);
      if (context === null) next.delete(tabKey); else next.set(tabKey, context);
      return next;
    }),
  }), [institutionId]);

  const closeTab = (key: string): void => {
    const index = tabs.findIndex((tab) => tab.key === key);
    setTabs((previous) => previous.filter((tab) => tab.key !== key));
    if (key === activeKey) {
      const neighbour = tabs.filter((tab) => tab.key !== key && tab.institutionId === institutionId)[Math.max(0, index - 1)];
      navigate(neighbour === undefined ? listRoute('members') : { view: 'record', institutionId, kind: neighbour.kind, id: neighbour.id });
    }
  };

  const visibleTabs = tabs.filter((tab) => tab.institutionId === institutionId);
  const activeContext = activeKey === null ? null : contexts.get(activeKey) ?? null;
  const draftCount = drafts.size;
  const tabOrder = [...LISTS.map((list) => `list:${list}`), ...visibleTabs.map((tab) => tab.key)];
  const onTabKey = (event: KeyboardEvent<HTMLDivElement>): void => {
    if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
    const buttons = [...event.currentTarget.querySelectorAll<HTMLButtonElement>('[role="tab"]')];
    const index = buttons.indexOf(document.activeElement as HTMLButtonElement);
    const next = buttons[(index + (event.key === 'ArrowRight' ? 1 : buttons.length - 1)) % buttons.length];
    next?.focus();
    next?.click();
    event.preventDefault();
  };

  const [searchText, setSearchText] = useState('');
  const globalSearch = (): void => {
    const text = searchText.trim();
    if (text === '') return;
    const list: ListId = /^AC\d+/iu.test(text) ? 'accounts' : /^CS\d+/iu.test(text) ? 'cases' : 'members';
    navigate({ view: 'list', institutionId, list, params: { ...EMPTY_PARAMS, filters: { query: text } } });
  };

  return (
    <ShellContext value={shell}>
      <div className="app">
        <header className="app-header">
          <strong className="brand">Service Workspace</strong>
          <label className="institution-switch">Institution
            <select value={institutionId} onChange={(event) => navigate({ view: 'list', institutionId: event.target.value, list: activeList ?? 'members', params: EMPTY_PARAMS })}>
              {session.institutions.map((item) => <option key={item.institutionId} value={item.institutionId}>{item.displayName}</option>)}
            </select>
          </label>
          <form className="global-search" role="search" onSubmit={(event) => { event.preventDefault(); globalSearch(); }}>
            <input type="search" aria-label="Find member, account or case" placeholder="Find member, account (AC…) or case (CS…)" value={searchText} onChange={(event) => setSearchText(event.target.value)} />
          </form>
          <MenuButton label="Operations" className="tool-button" buttonLabel="All operations" items={() => [
            ...OPERATIONS.map((spec, index) => ({ id: spec.kind, label: spec.title, ...(index === 0 ? { section: 'Commands' } : {}), disabled: !(profile?.commands.includes(spec.kind) ?? false), disabledReason: 'Not granted to this operator.', onSelect: () => setDialog({ kind: 'operation', spec, context: {} }) })),
            ...INQUIRIES.map((spec, index) => ({ id: spec.kind, label: spec.title, ...(index === 0 ? { section: 'Inquiries' } : {}), onSelect: () => setDialog({ kind: 'operation', spec, inquiry: true, context: {} }) })),
          ]}>Operations ▾</MenuButton>
          <button type="button" className={`tool-button${draftCount > 0 ? ' attention' : ''}`} aria-expanded={changesOpen} onClick={() => setChangesOpen((value) => !value)}>Changes ({draftCount})</button>
          {session.operatorChoices.length === 0 ? <span className="operator">{profile?.displayName ?? session.operator.actorNumber}</span> : (
            <MenuButton label="Operator" className="tool-button operator" items={() => session.operatorChoices.map((choice) => ({
              id: choice.actorNumber, label: `${choice.displayName} (${choice.actorNumber})`, hint: choice.roles.join(', '), checked: choice.actorNumber === session.operator.actorNumber,
              disabled: draftCount > 0 && choice.actorNumber !== session.operator.actorNumber, disabledReason: 'Save or discard your changes before signing on as someone else; drafts are saved under the operator who submits them.',
              onSelect: () => { void switchOperator(choice.actorNumber).then(() => notify('info', `Signed on as ${choice.displayName} (${choice.actorNumber}).`), (error: unknown) => notify('error', String(error))); },
            }))}>{profile?.displayName ?? session.operator.actorNumber} ▾</MenuButton>
          )}
        </header>
        <div className="context-bar" aria-label="Current context" data-institution={institutionId}>
          <span><span className="muted">Institution</span> <strong>{institution.displayName}</strong> <span className="muted">as of {formatInstant(institution.asOf)}</span></span>
          <span data-context-member={activeContext?.member?.id}><span className="muted">Member</span> {activeContext?.member === null || activeContext === null ? '—' : <strong>{activeContext.member.number} · {activeContext.member.name}</strong>}</span>
          <span data-context-account={activeContext?.account?.id}><span className="muted">Account</span> {activeContext?.account == null ? '—' : <strong>{activeContext.account.number}</strong>}</span>
          <span><span className="muted">Operator</span> <strong>{profile === null ? `${session.operator.actorNumber} (not registered here)` : `${profile.displayName} (${profile.actorNumber})`}</strong> <span className="muted">{profile?.roles.join(', ')}</span></span>
          {session.mode === 'verification' ? <span className="badge mode">Verification run</span> : null}
        </div>
        <div className="tab-strip" role="tablist" aria-label="Open views" onKeyDown={onTabKey}>
          {LISTS.map((list) => (
            <button key={list} type="button" role="tab" aria-selected={activeList === list} tabIndex={activeList === list || (activeList === null && list === 'members' && activeKey === null) ? 0 : -1}
              className="tab list-tab" onClick={() => navigate(listRoute(list))}>{isRecordList(list) ? recordListConfig(list).title : LIST_CONFIG[list].title}</button>
          ))}
          {visibleTabs.map((tab) => {
            const context = contexts.get(tab.key);
            const selected = tab.key === activeKey;
            const hasDraft = [...drafts.keys()].some((key) => key === `${tab.institutionId}/${tab.kind}:${tab.id}`);
            return (
              <span key={tab.key} className={`tab record-tab${selected ? ' selected' : ''}`} data-tab-key={tab.key}>
                <button type="button" role="tab" aria-selected={selected} tabIndex={selected ? 0 : -1} onClick={() => navigate({ view: 'record', institutionId, kind: tab.kind, id: tab.id })}>
                  <span className="tab-kind">{tab.kind}</span> {context?.title ?? '…'}{hasDraft ? ' •' : ''}
                </button>
                <button type="button" className="tab-close" aria-label={`Close ${context?.title ?? tab.kind}`} onClick={() => closeTab(tab.key)}>×</button>
              </span>
            );
          })}
          <span className="muted tab-count">{visibleTabs.length}/{MAX_RECORD_TABS} records · {tabOrder.length} tabs</span>
        </div>
        <main className="workspace-main">
          {LISTS.filter((list) => visited.has(list)).map((list) => {
            const params = activeList === list && route?.view === 'list' ? route.params : lastLists.current.get(`${institutionId}/${list}`) ?? EMPTY_PARAMS;
            return isRecordList(list)
              ? <RecordList key={`${institutionId}/${list}`} list={list} params={params} active={activeList === list} />
              : <ListView key={`${institutionId}/${list}`} list={list} params={params} active={activeList === list} />;
          })}
          {visibleTabs.map((tab) => <div key={tab.key} className="record-host" hidden={tab.key !== activeKey}><RecordView tab={tab} /></div>)}
          {route === null ? <p className="muted">Unknown address. Choose a list above.</p> : null}
        </main>
        {changesOpen ? <ChangesPanel onClose={() => setChangesOpen(false)} /> : null}
        <footer className="status-bar" role="status" aria-live="polite">
          {notices.slice(0, 1).map((notice) => (
            <span key={notice.id} className={`notice-${notice.tone}`} data-notice-tone={notice.tone}>
              {notice.text}{notice.receiptNumber === undefined ? null : <> <button type="button" className="link" onClick={() => { if (notice.receiptNumber !== undefined) shell.openRecord('receipt', notice.receiptNumber); }}>View receipt {notice.receiptNumber}</button></>}
            </span>
          ))}
        </footer>
        {dialog === null ? null : <DialogHost spec={dialog} onClose={() => setDialog(null)} />}
      </div>
    </ShellContext>
  );
}

export function App({ initialSession }: { initialSession: SessionInfo }): ReactNode {
  const [session, setSession] = useState(initialSession);
  const route = useRoute();
  const first = session.institutions[0];
  useEffect(() => {
    if (route === null && first !== undefined) navigate({ view: 'list', institutionId: first.institutionId, list: 'members', params: EMPTY_PARAMS }, { replace: true });
  }, [route, first]);
  if (first === undefined) return <p className="boot">This workspace has no institution bindings.</p>;
  const institutionId = route?.institutionId ?? first.institutionId;
  if (!session.institutions.some((item) => item.institutionId === institutionId)) {
    return <p className="boot">This workspace is not bound to institution “{institutionId}”. <a href={`/${first.institutionId}/members`}>Go to {first.displayName}</a></p>;
  }
  return (
    <WorkspaceProvider session={session} institutionId={institutionId} onSessionChange={setSession}>
      <Shell route={route} />
    </WorkspaceProvider>
  );
}
