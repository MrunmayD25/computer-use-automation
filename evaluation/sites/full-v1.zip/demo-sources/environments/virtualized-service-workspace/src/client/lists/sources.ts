import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';

import type { GridSource } from '../grid/VirtualGrid.js';
import { groupLayout } from '../model/groups.js';
import { PagedRows, type FetchPage, type PagedSnapshot } from '../model/paged.js';

export const PAGE_SIZE = 100;

const EMPTY_SNAPSHOT: PagedSnapshot = { total: null, version: 0, error: null, drifted: false, limitedTo: null, matched: null, loading: true };
const noSubscription = (): (() => void) => () => undefined;

export interface FlatRows<T extends { id: string }> {
  source: GridSource<T>;
  snapshot: PagedSnapshot;
  paged: PagedRows<T> | null;
}

/**
 * One paged query shown as a flat grid. A new key disposes the previous query, so its late responses
 * cannot reach the new one; `refresh` reloads loaded pages in place after commits.
 */
export function useFlatRows<T extends { id: string }>(key: string | null, fetchPage: FetchPage<T>, refresh: number): FlatRows<T> {
  const [paged, setPaged] = useState<PagedRows<T> | null>(null);
  const fetchRef = useRef(fetchPage);
  useEffect(() => { fetchRef.current = fetchPage; });
  useEffect(() => {
    if (key === null) { setPaged(null); return undefined; }
    const rows = new PagedRows<T>(key, PAGE_SIZE, (offset, limit, signal) => fetchRef.current(offset, limit, signal));
    setPaged(rows);
    rows.ensure(0, PAGE_SIZE - 1);
    return () => rows.dispose();
  }, [key]);
  const seenRefresh = useRef(refresh);
  useEffect(() => { if (seenRefresh.current !== refresh) { seenRefresh.current = refresh; paged?.refresh(); } }, [refresh, paged]);
  const current = paged !== null && paged.key === key ? paged : null;
  const snapshot = useSyncExternalStore(current?.subscribe ?? noSubscription, current?.getSnapshot ?? (() => EMPTY_SNAPSHOT));
  const source = useMemo<GridSource<T>>(() => ({
    length: snapshot.total ?? 0,
    version: snapshot.version,
    at: (index) => { const row = current?.get(index); return row === undefined ? { kind: 'pending' } : { kind: 'row', row }; },
    indexOf: (id) => current?.indexOf(id),
    ensure: (start, end) => current?.ensure(start, end),
  }), [current, snapshot]);
  return { source, snapshot, paged: current };
}

export interface GroupInfo {
  key: string;
  label: string;
  count: number;
  filter: Readonly<Record<string, unknown>>;
}

/** Per-group paged queries under one grouped search. Groups load their rows only while expanded and visible. */
class GroupedRows<T extends { id: string }> {
  private readonly children = new Map<string, { rows: PagedRows<T>; unsubscribe: () => void }>();
  private readonly listeners = new Set<() => void>();
  private version = 0;
  private disposed = false;

  constructor(readonly key: string, private readonly fetchGroup: (group: GroupInfo) => FetchPage<T>, readonly groups: readonly GroupInfo[]) {}

  readonly subscribe = (listener: () => void): (() => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  readonly getSnapshot = (): number => this.version;

  rows(group: GroupInfo): PagedRows<T> {
    const existing = this.children.get(group.key);
    if (existing !== undefined) return existing.rows;
    const rows = new PagedRows<T>(`${this.key}|${group.key}`, PAGE_SIZE, this.fetchGroup(group));
    const unsubscribe = rows.subscribe(() => { this.version += 1; for (const listener of this.listeners) listener(); });
    if (!this.disposed) this.children.set(group.key, { rows, unsubscribe });
    return rows;
  }

  refresh(): void { for (const child of this.children.values()) child.rows.refresh(); }

  dispose(): void {
    this.disposed = true;
    for (const child of this.children.values()) { child.unsubscribe(); child.rows.dispose(); }
    this.children.clear();
    this.listeners.clear();
  }
}

const MAX_ENSURE_SPAN = 400;

export function useGroupedRows<T extends { id: string }>(key: string | null, groups: readonly GroupInfo[] | undefined, expanded: ReadonlySet<string>, fetchGroup: (group: GroupInfo) => FetchPage<T>, refresh: number): GridSource<T> {
  const [grouped, setGrouped] = useState<GroupedRows<T> | null>(null);
  const fetchRef = useRef(fetchGroup);
  useEffect(() => { fetchRef.current = fetchGroup; });
  const groupsKey = key === null || groups === undefined ? null : `${key}#${JSON.stringify(groups.map((group) => [group.key, group.count]))}`;
  useEffect(() => {
    if (groupsKey === null || groups === undefined) { setGrouped(null); return undefined; }
    const created = new GroupedRows<T>(groupsKey, (group) => (offset, limit, signal) => fetchRef.current(group)(offset, limit, signal), groups);
    setGrouped(created);
    return () => created.dispose();
  }, [groupsKey]);
  const seenRefresh = useRef(refresh);
  useEffect(() => { if (seenRefresh.current !== refresh) { seenRefresh.current = refresh; grouped?.refresh(); } }, [refresh, grouped]);
  const current = grouped !== null && grouped.key === groupsKey ? grouped : null;
  const version = useSyncExternalStore(current?.subscribe ?? noSubscription, current?.getSnapshot ?? (() => 0));
  return useMemo<GridSource<T>>(() => {
    const list = current?.groups ?? [];
    const layout = groupLayout(list.map((group) => ({ key: group.key, count: group.count })), expanded);
    return {
      length: current === null ? 0 : layout.length,
      version,
      at(index) {
        const position = layout.locate(index);
        const group = position === null ? undefined : list[position.group];
        if (position === null || group === undefined || current === null) return { kind: 'pending' };
        if (position.kind === 'header') return { kind: 'header', key: group.key, label: group.label, count: group.count, expanded: expanded.has(group.key) };
        const row = current.rows(group).get(position.offset);
        return row === undefined ? { kind: 'pending' } : { kind: 'row', row };
      },
      indexOf(id) {
        if (current === null) return undefined;
        for (const [index, group] of list.entries()) {
          if (!expanded.has(group.key)) continue;
          const offset = current.rows(group).indexOf(id);
          if (offset !== undefined) return layout.headerIndex(index) + 1 + offset;
        }
        return undefined;
      },
      ensure(start, end) {
        if (current === null) return;
        const spans = new Map<number, [number, number]>();
        for (let index = start; index <= Math.min(end, start + MAX_ENSURE_SPAN); index += 1) {
          const position = layout.locate(index);
          if (position?.kind !== 'row') continue;
          const span = spans.get(position.group);
          spans.set(position.group, span === undefined ? [position.offset, position.offset] : [Math.min(span[0], position.offset), Math.max(span[1], position.offset)]);
        }
        for (const [groupIndex, [from, to]] of spans) { const group = list[groupIndex]; if (group !== undefined) current.rows(group).ensure(from, to); }
      },
    };
  }, [current, expanded, version]);
}
