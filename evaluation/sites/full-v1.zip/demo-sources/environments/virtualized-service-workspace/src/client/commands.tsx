import type { OperationReview, Receipt, ServiceCommand } from '@computer-use/financial-database/services';
import { useCallback, useLayoutEffect, useRef, useState, type ReactNode, type SyntheticEvent } from 'react';

import { executeCommand, isNetworkFailure, newIdempotencyKey, reviewCommand } from './api.js';
import { formatMoney, label } from './format.js';
import { Dialog } from './ui/Dialog.js';
import { useWorkspace } from './workspace.js';

/**
 * Submission states of one command. The idempotency key is fixed when the operator confirms and reused
 * for retries after an unknown outcome, so a repeated or retried confirmation returns the first receipt.
 */
export type FlowState =
  | { step: 'edit'; error: string | null; field: string | null }
  | { step: 'reviewing' }
  | { step: 'review'; review: OperationReview; command: ServiceCommand; key: string }
  | { step: 'submitting'; command: ServiceCommand; key: string; review: OperationReview | null }
  | { step: 'unknown'; command: ServiceCommand; key: string; review: OperationReview | null; message: string }
  | { step: 'done'; outcome: 'committed' | 'duplicate' | 'unchanged'; receipt: Receipt | null; message: string };

export type BuildResult = { command: ServiceCommand } | { error: string; field?: string | undefined };

export interface CommandFlow {
  state: FlowState;
  start: (built: BuildResult) => void;
  confirm: () => void;
  retry: () => void;
  backToEdit: () => void;
  busy: boolean;
}

export function useCommandFlow(institutionId: string, options: { review: boolean; onCommitted?: (receipt: Receipt) => void; successText: (receipt: Receipt) => string }): CommandFlow {
  const [state, setState] = useState<FlowState>({ step: 'edit', error: null, field: null });
  const { committed } = useWorkspace();
  const optionsRef = useRef(options);
  useLayoutEffect(() => { optionsRef.current = options; });
  const running = useRef(false);

  const submit = useCallback(async (command: ServiceCommand, key: string, review: OperationReview | null) => {
    if (running.current) return;
    running.current = true;
    setState({ step: 'submitting', command, key, review });
    try {
      const outcome = await executeCommand(institutionId, command, key);
      if (outcome.kind === 'committed' || outcome.kind === 'duplicate') {
        const text = optionsRef.current.successText(outcome.receipt);
        setState({ step: 'done', outcome: outcome.kind, receipt: outcome.receipt, message: outcome.kind === 'duplicate' ? `Already applied by an earlier submission. ${text}` : text });
        committed(outcome.receipt, text);
        optionsRef.current.onCommitted?.(outcome.receipt);
      } else if (outcome.kind === 'unchanged') {
        setState({ step: 'done', outcome: 'unchanged', receipt: null, message: outcome.message });
      } else {
        setState({ step: 'edit', error: outcome.message, field: outcome.field ?? null });
      }
    } catch (error) {
      if (isNetworkFailure(error)) setState({ step: 'unknown', command, key, review, message: 'No response arrived, so the outcome is unknown. Retry: the same submission is sent again and cannot apply twice.' });
      else setState({ step: 'edit', error: error instanceof Error ? error.message : String(error), field: null });
    } finally {
      running.current = false;
    }
  }, [institutionId, committed]);

  const start = useCallback((built: BuildResult) => {
    if ('error' in built) { setState({ step: 'edit', error: built.error, field: built.field ?? null }); return; }
    const key = newIdempotencyKey(built.command.kind);
    if (!optionsRef.current.review) { void submit(built.command, key, null); return; }
    setState({ step: 'reviewing' });
    reviewCommand(institutionId, built.command).then((outcome) => {
      if (outcome.kind === 'reviewable') setState({ step: 'review', review: outcome.review, command: built.command, key });
      else if (outcome.kind === 'unchanged') setState({ step: 'done', outcome: 'unchanged', receipt: null, message: outcome.message });
      else setState({ step: 'edit', error: outcome.message, field: outcome.field ?? null });
    }, (error: unknown) => setState({ step: 'edit', error: error instanceof Error ? error.message : String(error), field: null }));
  }, [institutionId, submit]);

  return {
    state, start,
    confirm: () => { if (state.step === 'review') void submit(state.command, state.key, state.review); },
    retry: () => { if (state.step === 'unknown') void submit(state.command, state.key, state.review); },
    backToEdit: () => setState({ step: 'edit', error: null, field: null }),
    busy: state.step === 'reviewing' || state.step === 'submitting',
  };
}

export function ReviewPanel({ review }: { review: OperationReview }): ReactNode {
  const exponent = review.exponent ?? 2;
  return (
    <section className="review" aria-label="Review">
      <p className="review-lead">Check these terms against current data. Nothing has changed yet.</p>
      <dl className="facts">
        <dt>Operation</dt><dd>{label(review.commandKind.replaceAll('.', ' '))}</dd>
        <dt>Institution</dt><dd>{review.institutionName}</dd>
        {review.amount === null ? null : <><dt>Amount</dt><dd className="money">{formatMoney(review.amount.minorUnits, review.amount.currency, exponent)}</dd></>}
        {review.description === null ? null : <><dt>Description</dt><dd>{review.description}</dd></>}
      </dl>
      {review.accounts.length === 0 ? null : (
        <table className="plain">
          <thead><tr><th>Account</th><th>Owner</th><th>Posted before → after</th><th>Available before → after</th></tr></thead>
          <tbody>
            {review.accounts.map((account) => (
              <tr key={account.id}>
                <td><code>{account.accountNumber}</code> <span className="muted">v{account.version}</span></td>
                <td>{account.ownerName} ({account.memberNumber})</td>
                <td className="money">{formatMoney(account.postedBeforeMinorUnits, account.currency, account.exponent)} → {formatMoney(account.postedAfterMinorUnits, account.currency, account.exponent)}</td>
                <td className="money">{formatMoney(account.availableBeforeMinorUnits, account.currency, account.exponent)} → {formatMoney(account.availableAfterMinorUnits, account.currency, account.exponent)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {review.consequences.length === 0 ? null : <ul className="consequences">{review.consequences.map((text) => <li key={text}>{text}</li>)}</ul>}
    </section>
  );
}

export function ReceiptLink({ receipt, onOpen }: { receipt: Receipt; onOpen: (receiptNumber: string) => void }): ReactNode {
  return <button type="button" className="link" onClick={() => onOpen(receipt.receiptNumber)}>Receipt {receipt.receiptNumber}</button>;
}

interface CommandDialogProps {
  title: string;
  institutionId: string;
  review: boolean;
  build: () => BuildResult;
  successText: (receipt: Receipt) => string;
  onClose: () => void;
  onCommitted?: ((receipt: Receipt) => void) | undefined;
  onOpenReceipt: (receiptNumber: string) => void;
  submitLabel: string;
  submitDisabled?: boolean;
  wide?: boolean | undefined;
  children: (flow: CommandFlow) => ReactNode;
}

/** Dialog that edits, optionally reviews, confirms and reports one shared command. */
export function CommandDialog({ title, institutionId, review, build, successText, onClose, onCommitted, onOpenReceipt, submitLabel, submitDisabled = false, wide, children }: CommandDialogProps): ReactNode {
  const flow = useCommandFlow(institutionId, { review, successText, ...(onCommitted === undefined ? {} : { onCommitted }) });
  const { state } = flow;
  const close = (): void => { if (!flow.busy) onClose(); };
  const submitForm = (event: SyntheticEvent): void => { event.preventDefault(); if (state.step === 'edit') flow.start(build()); };
  const footer = state.step === 'edit' || state.step === 'reviewing' ? (
    <>
      <button type="button" onClick={close}>Cancel</button>
      <button type="submit" form="command-form" className="primary" disabled={flow.busy || submitDisabled}>{state.step === 'reviewing' ? 'Checking…' : review ? 'Review' : submitLabel}</button>
    </>
  ) : state.step === 'review' || state.step === 'submitting' ? (
    <>
      <button type="button" onClick={flow.backToEdit} disabled={flow.busy}>Back to edit</button>
      <button type="button" className="primary" onClick={flow.confirm} disabled={flow.busy}>{state.step === 'submitting' ? 'Submitting…' : `Confirm ${submitLabel.toLowerCase()}`}</button>
    </>
  ) : state.step === 'unknown' ? (
    <>
      <button type="button" onClick={onClose}>Close</button>
      <button type="button" className="primary" onClick={flow.retry}>Retry safely</button>
    </>
  ) : <button type="button" className="primary" onClick={onClose}>Done</button>;
  return (
    <Dialog title={title} onClose={close} footer={footer} {...(wide === undefined ? {} : { wide })}>
      <div data-flow-step={state.step}>
        {state.step === 'edit' || state.step === 'reviewing' ? (
          <form id="command-form" className="form" onSubmit={submitForm} noValidate>
            {state.step === 'edit' && state.error !== null ? <p className="error" role="alert">{state.field === null ? '' : `${state.field}: `}{state.error}</p> : null}
            <fieldset disabled={flow.busy}>{children(flow)}</fieldset>
          </form>
        ) : null}
        {state.step === 'review' ? <ReviewPanel review={state.review} /> : null}
        {state.step === 'submitting' ? (state.review === null ? <p className="muted" role="status">Submitting…</p> : <ReviewPanel review={state.review} />) : null}
        {state.step === 'unknown' ? <p className="warning" role="alert">{state.message}</p> : null}
        {state.step === 'done' ? (
          <div className="result" role="status">
            <p className={state.outcome === 'unchanged' ? 'muted' : 'success'}>{state.message}</p>
            {state.receipt === null ? null : <ReceiptLink receipt={state.receipt} onOpen={(number) => { onClose(); onOpenReceipt(number); }} />}
          </div>
        ) : null}
      </div>
    </Dialog>
  );
}
