import { useCallback, useEffect, useRef, useState } from 'react';

import type { ColumnLayout, PreferenceResponse } from '../../shared/api.js';
import type { GridId } from '../../shared/columns.js';
import { getJson, sendJson } from '../api.js';
import { applyColumnAction, defaultLayout, normalizeLayout, type ColumnAction } from '../model/columns.js';

const SAVE_DELAY_MS = 400;

/**
 * The signed-on operator's layout of one grid. Changes apply at once and are saved to the workspace
 * backend shortly after, so reordering, resizing, hiding and pinning survive reloads and sign-ons.
 */
export function useColumnLayout(grid: GridId, operator: string, onError: (message: string) => void): { layout: ColumnLayout; apply: (action: ColumnAction) => void; loaded: boolean } {
  const [state, setState] = useState<{ operator: string; layout: ColumnLayout; loaded: boolean }>({ operator, layout: defaultLayout(grid), loaded: false });
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const errorRef = useRef(onError);
  useEffect(() => { errorRef.current = onError; });

  useEffect(() => {
    let live = true;
    getJson<PreferenceResponse>(`/api/preferences/${grid}`).then(
      (response) => { if (live) setState({ operator, layout: normalizeLayout(grid, response.layout), loaded: true }); },
      (error: unknown) => { if (live) { setState({ operator, layout: defaultLayout(grid), loaded: true }); errorRef.current(`Column layout could not be loaded: ${error instanceof Error ? error.message : String(error)}`); } },
    );
    return () => { live = false; };
  }, [grid, operator]);

  useEffect(() => () => { if (timer.current !== null) clearTimeout(timer.current); }, []);

  const apply = useCallback((action: ColumnAction) => {
    setState((previous) => {
      const layout = applyColumnAction(grid, previous.layout, action);
      if (timer.current !== null) clearTimeout(timer.current);
      timer.current = setTimeout(() => {
        const request = action.kind === 'reset' ? sendJson('DELETE', `/api/preferences/${grid}`) : sendJson('PUT', `/api/preferences/${grid}`, layout);
        request.catch((error: unknown) => errorRef.current(`Column layout was not saved: ${error instanceof Error ? error.message : String(error)}`));
      }, SAVE_DELAY_MS);
      return { ...previous, layout };
    });
  }, [grid]);

  return { layout: state.layout, apply, loaded: state.loaded };
}
