import { formatMoney } from './model/money.js';

export { formatMoney };

const STATUS_LABELS: Readonly<Record<string, string>> = {
  'pending-customer': 'Pending customer', 'pending-internal': 'Pending internal', electronic: 'Electronic', paper: 'Paper',
};

export function text(value: unknown): string {
  return typeof value === 'string' ? value : typeof value === 'number' || typeof value === 'boolean' ? String(value) : '';
}

export function label(value: string): string {
  return STATUS_LABELS[value] ?? value.charAt(0).toUpperCase() + value.slice(1).replaceAll('-', ' ');
}

export function formatDate(value: string | null | undefined): string {
  if (value === null || value === undefined || value === '') return '';
  return value.slice(0, 10);
}

export function formatInstant(value: string | null | undefined): string {
  if (value === null || value === undefined || value === '') return '';
  return value.replace('T', ' ').replace(/(\.\d+)?Z$/u, ' UTC');
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${String(bytes)} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function plural(count: number, noun: string, many = `${noun}s`): string {
  return `${count.toLocaleString('en-US')} ${count === 1 ? noun : many}`;
}
