import { useCallback, useSyncExternalStore } from 'react';

import { formatRoute, parseRoute, type Route } from './model/route.js';

const listeners = new Set<() => void>();
let current = window.location.pathname + window.location.search;

function notify(): void {
  current = window.location.pathname + window.location.search;
  for (const listener of listeners) listener();
}

window.addEventListener('popstate', notify);

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

/** Pushes a new history entry, or replaces the current one for refinements that should not add a Back step. */
export function navigate(route: Route, options: { replace?: boolean } = {}): void {
  const url = formatRoute(route);
  if (url === current) return;
  if (options.replace === true) window.history.replaceState(null, '', url); else window.history.pushState(null, '', url);
  notify();
}

export function useLocation(): string {
  return useSyncExternalStore(subscribe, () => current);
}

/** The route in the address bar. Browser Back and Forward change it like any other navigation. */
export function useRoute(): Route | null {
  const location = useLocation();
  const [pathname, search = ''] = location.split('?');
  return parseRoute(pathname ?? '/', search);
}

export function useNavigate(): typeof navigate {
  return useCallback(navigate, []);
}
