import type { AccountRow, CaseRow, MemberRow, SavedSearchDefinition, SavedSearchRow } from '@computer-use/financial-database/services';
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

import { GRID_COLUMNS, GRID_SORTS, type GridId, type SearchEntity } from '../../shared/columns.js';
import { download, getJson, institutionPath, queryString, sendJson } from '../api.js';
import { label as displayLabel, plural } from '../format.js';
import { CellEditor, type EditTarget } from '../grid/CellEditor.js';
import { useColumnLayout } from '../grid/useColumnLayout.js';
import { VirtualGrid, type GridHandle, type GridRange } from '../grid/VirtualGrid.js';
import { displayedColumnIds, visibleColumns, type ResolvedColumn } from '../model/columns.js';
import { EDITABLE_FIELDS, draftKey, type DraftRecordKind } from '../model/drafts.js';
import type { FetchPage, PageResponse } from '../model/paged.js';
import { cleanFilters, matchKey, windowKey, type FilterValue, type ListParams, type SortState } from '../model/route.js';
import { EMPTY_SELECTION, afterSearchChange, isSelected, selectAllMatching, selectRecords, selectedCount, toggleSelected, type Selection } from '../model/selection.js';
import { navigate } from '../router.js';
import { useShell } from '../shell.js';
import { MenuButton, type MenuItem } from '../ui/Menu.js';
import { useResource } from '../useResource.js';
import { useWorkspace } from '../workspace.js';
import { renderCell, type ActivityGridRow, type DocumentGridRow } from './cells.js';
import { Preview, type ListRow } from './Preview.js';
import { SavedSearches } from './SavedSearches.js';
import { PAGE_SIZE, useFlatRows, useGroupedRows, type GroupInfo } from './sources.js';

interface ListConfig {
  grid: GridId;
  title: string;
  path: string;
  entity: SearchEntity | null;
  noun: string;
  editKind: DraftRecordKind | null;
}

export type CoreListId = 'members' | 'accounts' | 'cases' | 'documents' | 'activity';

export const LIST_CONFIG: Readonly<Record<CoreListId, ListConfig>> = {
  members: { grid: 'members', title: 'Members', path: '/members', entity: 'members', noun: 'member', editKind: 'member' },
  accounts: { grid: 'accounts', title: 'Accounts', path: '/accounts', entity: 'accounts', noun: 'account', editKind: 'account' },
  cases: { grid: 'cases', title: 'Cases', path: '/cases', entity: 'cases', noun: 'case', editKind: null },
  documents: { grid: 'documents', title: 'Documents', path: '/documents', entity: null, noun: 'document', editKind: null },
  activity: { grid: 'activity', title: 'Activity', path: '/activity', entity: null, noun: 'event', editKind: null },
};

const DOCUMENT_TYPES = ['account-statement', 'servicing-notice', 'delivery-disclosure', 'signature-evidence', 'loan-payoff-quote', 'address-evidence', 'dispute-evidence', 'redacted-evidence', 'loan-closure-confirmation', 'batch-input', 'statement-csv'];
const CASE_STATES = ['open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened'];
const INACTIVE_ACCOUNT = new Set(['closed', 'matured']);

/** Remembered scroll offsets per ordered result window, so Back returns to the same place in a list. */
const scrollMemory = new Map<string, number>();

export function rowLabel(list: CoreListId, row: ListRow): string {
  switch (list) {
    case 'members': return (row as MemberRow).memberNumber;
    case 'accounts': return (row as AccountRow).accountNumber;
    case 'cases': return (row as CaseRow).caseNumber;
    case 'documents': return (row as DocumentGridRow).displayName;
    case 'activity': return `Event ${String((row as ActivityGridRow).sequence)}`;
  }
}

function adapt(list: CoreListId, row: Record<string, unknown>): ListRow {
  if (list === 'documents') return { ...row, id: String(row.versionId) } as unknown as DocumentGridRow;
  if (list === 'activity') return { ...row, id: String(row.sequence) } as unknown as ActivityGridRow;
  return row as unknown as ListRow;
}

function groupFilterValues(filter: Readonly<Record<string, unknown>>): Record<string, FilterValue> {
  const values: Record<string, FilterValue> = {};
  for (const [key, value] of Object.entries(filter)) {
    if (value === null) values[key] = 'unassigned';
    else if (typeof value === 'string' || typeof value === 'boolean') values[key] = value;
    else if (Array.isArray(value)) values[key] = value.map(String);
  }
  return values;
}

export function describeFilters(list: CoreListId, params: ListParams): string {
  const entries = Object.entries(cleanFilters(list, params.filters));
  if (entries.length === 0) return 'no filters';
  return entries.map(([key, value]) => `${key} ${Array.isArray(value) ? value.join('/') : String(value)}`).join(', ');
}

function storedValue(kind: DraftRecordKind, row: ListRow, column: string): string {
  if (kind === 'account') { const account = row as AccountRow; return column === 'nickname' ? account.nickname : account.statementDelivery; }
  const member = row as MemberRow;
  return (column === 'email' ? member.email : member.phone) ?? '';
}

interface EditSession extends EditTarget {
  recordKind: DraftRecordKind;
  stored: string;
  version: number;
  /** Draft value the field had before this editing session, restored on cancel. */
  initial: string | null;
}

function SearchBox({ value, onCommit, label }: { value: string; onCommit: (text: string) => void; label: string }): ReactNode {
  const [text, setText] = useState(value);
  const [seen, setSeen] = useState(value);
  if (seen !== value) { setSeen(value); setText(value); }
  const commit = useRef(onCommit);
  useEffect(() => { commit.current = onCommit; });
  useEffect(() => {
    if (text === value) return undefined;
    const timer = setTimeout(() => commit.current(text), 350);
    return () => clearTimeout(timer);
  }, [text, value]);
  return <input type="search" className="search-box" aria-label={label} placeholder={label} value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') commit.current(text); }} />;
}

function Filters({ list, params, update }: { list: CoreListId; params: ListParams; update: (patch: Partial<ListParams>) => void }): ReactNode {
  const { reference } = useWorkspace();
  const setFilter = (key: string, value: FilterValue): void => update({ filters: { ...params.filters, [key]: value } });
  const text = (key: string): string => { const value = params.filters[key]; return typeof value === 'string' ? value : ''; };
  const select = (key: string, labelText: string, options: readonly (readonly [string, string])[]): ReactNode => (
    <label className="filter">{labelText}
      <select value={text(key)} onChange={(event) => setFilter(key, event.target.value)}>
        <option value="">Any</option>
        {options.map(([value, optionLabel]) => <option key={value} value={value}>{optionLabel}</option>)}
      </select>
    </label>
  );
  switch (list) {
    case 'members': return select('status', 'Status', ['active', 'inactive', 'deceased', 'merged'].map((value) => [value, displayLabel(value)] as const));
    case 'accounts': return (
      <>
        {select('status', 'Status', ['open', 'dormant', 'restricted', 'closed', 'matured'].map((value) => [value, displayLabel(value)] as const))}
        {select('currency', 'Currency', (reference?.currencies ?? []).map((currency) => [currency.code, currency.code] as const))}
      </>
    );
    case 'cases': {
      const states = Array.isArray(params.filters.states) ? params.filters.states as readonly string[] : [];
      const queue = Array.isArray(params.filters.queueIds) ? (params.filters.queueIds as readonly string[])[0] ?? '' : '';
      return (
        <>
          <MenuButton label="Case status filter" items={() => CASE_STATES.map((state) => ({
            id: state, label: displayLabel(state), checked: states.includes(state),
            onSelect: () => setFilter('states', states.includes(state) ? states.filter((item) => item !== state) : [...states, state]),
          }))}>Status: {states.length === 0 ? 'Any' : states.map(displayLabel).join(', ')} ▾</MenuButton>
          <label className="filter">Queue
            <select value={queue} onChange={(event) => setFilter('queueIds', event.target.value === '' ? [] : [event.target.value])}>
              <option value="">Any</option>
              {(reference?.queues ?? []).map((item) => <option key={item.id} value={item.id}>{item.code} · {item.name}</option>)}
            </select>
          </label>
          {select('priority', 'Priority', ['urgent', 'high', 'normal', 'low'].map((value) => [value, displayLabel(value)] as const))}
          {select('assignedActorId', 'Assignee', [['unassigned', 'Unassigned'] as const, ...(reference?.caseWorkers ?? []).map((actor) => [actor.id, `${actor.displayName} (${actor.actorNumber})`] as const)])}
          <label className="filter checkbox"><input type="checkbox" checked={params.filters.overdue === true} onChange={(event) => setFilter('overdue', event.target.checked)} /> Overdue</label>
          <label className="filter">Group by
            <select value={params.groupBy ?? ''} disabled={params.maxResults !== null} title={params.maxResults === null ? undefined : 'Grouping is unavailable while a saved-search result limit applies.'} onChange={(event) => update({ groupBy: event.target.value === '' ? null : event.target.value })}>
              <option value="">None</option><option value="state">Status</option><option value="queue">Queue</option><option value="priority">Priority</option><option value="assignee">Assignee</option>
            </select>
          </label>
        </>
      );
    }
    case 'documents': return select('documentType', 'Type', DOCUMENT_TYPES.map((value) => [value, displayLabel(value)] as const));
    case 'activity': return <label className="filter">Operation<input value={text('kind')} placeholder="e.g. account.nickname.update" onChange={(event) => setFilter('kind', event.target.value)} /></label>;
  }
}

interface ListViewProps {
  list: CoreListId;
  params: ListParams;
  active: boolean;
}

/** One searchable, virtualized result list with its filters, selection, inline editing and preview. */
export function ListView({ list, params, active }: ListViewProps): ReactNode {
  const workspace = useWorkspace();
  const { institution, session, drafts, dispatchDrafts, saveDraft, can, notify, dataVersion } = workspace;
  const { openRecord, openDialog } = useShell();
  const config = LIST_CONFIG[list];
  const institutionId = institution.institutionId;
  const { layout, apply } = useColumnLayout(config.grid, session.operator.actorNumber, (message) => notify('error', message));
  const currentWindow = windowKey(institutionId, list, params);
  const currentMatch = matchKey(institutionId, list, params);
  const grouped = list === 'cases' && params.groupBy !== null && params.maxResults === null;
  const gridHandle = useRef<GridHandle>(null);
  const [scroller, setScroller] = useState<HTMLDivElement | null>(null);
  const [range, setRange] = useState<GridRange>({ first: 0, last: 0 });
  const [activeRow, setActiveRow] = useState<ListRow | null>(null);
  const [editing, setEditing] = useState<EditSession | null>(null);
  const [collapsed, setCollapsed] = useState<ReadonlySet<string>>(new Set());
  const [goTo, setGoTo] = useState('');

  const update = useCallback((patch: Partial<ListParams>) => {
    navigate({ view: 'list', institutionId, list, params: { ...params, ...patch } });
  }, [institutionId, list, params]);

  const fetchWith = useCallback((extra: Readonly<Record<string, FilterValue>>): FetchPage<ListRow> => async (offset, limit, signal) => {
    const query = queryString({
      ...cleanFilters(list, params.filters), ...extra, sort: params.sort?.field, direction: params.sort?.direction,
      maxResults: config.entity === null ? undefined : params.maxResults, limit, offset,
    });
    const page = await getJson<PageResponse<Record<string, unknown>>>(institutionPath(institutionId, `${config.path}${query}`), signal);
    return { ...page, items: page.items.map((row) => adapt(list, row)) };
  }, [config, institutionId, list, params]);

  const flat = useFlatRows<ListRow>(grouped ? null : currentWindow, fetchWith({}), dataVersion);
  const groupsPath = grouped ? institutionPath(institutionId, `/case-groups${queryString({ ...cleanFilters(list, params.filters), groupBy: params.groupBy })}`) : null;
  const groups = useResource<GroupInfo[]>(groupsPath, dataVersion);
  const expanded = useMemo(() => new Set((groups.data ?? []).map((group) => group.key).filter((key) => !collapsed.has(key))), [groups.data, collapsed]);
  const groupedSource = useGroupedRows<ListRow>(grouped ? currentWindow : null, groups.data, expanded, (group) => fetchWith(groupFilterValues(group.filter)), dataVersion);
  const source = grouped ? groupedSource : flat.source;
  const total = grouped ? (groups.data ?? []).reduce((sum, group) => sum + group.count, 0) : flat.snapshot.total ?? 0;

  const [selection, setSelection] = useState<Selection>(EMPTY_SELECTION);
  const [selectionNotice, setSelectionNotice] = useState<string | null>(null);
  const seenMatch = useRef(currentMatch);
  useEffect(() => {
    if (seenMatch.current === currentMatch) return;
    seenMatch.current = currentMatch;
    const result = afterSearchChange(selection, currentMatch);
    if (result.selection !== selection) setSelection(result.selection);
    if (result.notice !== null) setSelectionNotice(result.notice);
  }, [currentMatch, selection]);

  const [hidden, setHidden] = useState<{ match: string; ids: string[] } | null>(null);
  useEffect(() => {
    if (config.entity === null || selection.mode !== 'ids' || selection.ids.size === 0) { setHidden(null); return undefined; }
    const ids = [...selection.ids.keys()].slice(0, 500);
    let live = true;
    const timer = setTimeout(() => {
      sendJson<{ matching: string[] }>('POST', institutionPath(institutionId, `/membership/${config.grid}`), { ids, filters: cleanFilters(list, params.filters) }).then(
        (response) => { if (live) { const matching = new Set(response.matching); setHidden({ match: currentMatch, ids: ids.filter((id) => !matching.has(id)) }); } },
        () => undefined,
      );
    }, 250);
    return () => { live = false; clearTimeout(timer); };
  }, [config, institutionId, list, params.filters, selection, currentMatch]);
  const hiddenIds = hidden?.match === currentMatch ? hidden.ids : [];

  const label = (row: ListRow): string => rowLabel(list, row);
  const editKind = config.editKind;
  const isEditable = (row: ListRow, column: string): boolean => {
    if (editKind === 'account') {
      const account = row as AccountRow;
      if (INACTIVE_ACCOUNT.has(account.status)) return false;
      return (column === 'nickname' && can('account.nickname.update')) || (column === 'statement_delivery' && can('account.statement_delivery.update'));
    }
    if (editKind === 'member') return (column === 'email' || column === 'phone') && can('contact.update') && (row as MemberRow).status !== 'merged';
    return false;
  };

  const startEdit = (row: ListRow, column: string): void => {
    if (editKind === null) return;
    const key = draftKey(institutionId, editKind, row.id);
    const draft = drafts.get(key);
    if (draft !== undefined && (draft.status.phase === 'pending' || draft.status.phase === 'unknown')) {
      notify('info', `${label(row)} has a save in progress or an unknown outcome. Finish it in Changes first.`);
      return;
    }
    const stored = storedValue(editKind, row, column);
    const initial = draft?.status.phase === 'committed' ? null : draft?.fields[column] ?? null;
    setEditing({
      rowId: row.id, column, label: label(row), columnLabel: GRID_COLUMNS[config.grid].find((item) => item.id === column)?.label ?? column,
      kind: column === 'statement_delivery' ? 'delivery' : 'text', value: initial ?? stored, recordKind: editKind, stored, version: (row as AccountRow | MemberRow).version, initial,
    });
  };

  const writeDraft = (session: EditSession, value: string): void => {
    dispatchDrafts({ type: 'edit', institutionId, kind: session.recordKind, recordId: session.rowId, label: session.label, version: session.version, field: session.column, value, original: session.stored });
  };

  const focusGrid = (): void => gridHandle.current?.focus();
  const cell = (row: ListRow, column: ResolvedColumn): ReactNode => {
    const base = renderCell(config.grid, row, column);
    if (editKind === null || !EDITABLE_FIELDS[editKind].includes(column.id)) return base;
    const draft = drafts.get(draftKey(institutionId, editKind, row.id));
    const value = draft?.fields[column.id];
    if (draft === undefined || value === undefined) return base;
    return <span className="drafted" title={`Unsaved change. Stored value: ${draft.original[column.id] ?? ''}`}>{column.id === 'statement_delivery' ? displayLabel(value) : value === '' ? '(cleared)' : value}</span>;
  };
  const rowState = (row: ListRow): string | null => (editKind === null ? null : drafts.get(draftKey(institutionId, editKind, row.id))?.status.phase ?? null);

  const open = (row: ListRow): void => {
    switch (list) {
      case 'members': openRecord('member', row.id); return;
      case 'accounts': openRecord('account', row.id); return;
      case 'cases': openRecord('case', row.id); return;
      case 'documents': openRecord('document', (row as DocumentGridRow).documentId); return;
      case 'activity': {
        const event = row as ActivityGridRow;
        if (event.receiptNumber !== null) openRecord('receipt', event.receiptNumber);
        else if (event.resourceKind === 'member' || event.resourceKind === 'account' || event.resourceKind === 'case') openRecord(event.resourceKind, event.resourceId);
      }
    }
  };

  const toggle = (row: ListRow): void => setSelection((previous) => toggleSelected(previous, row.id, label(row)));
  const rowMenu = (row: ListRow): MenuItem[] => {
    const select: MenuItem = { id: 'select', label: isSelected(selection, row.id) ? 'Deselect' : 'Select', onSelect: () => toggle(row) };
    const edit = (column: string, text: string): MenuItem => ({ id: `edit-${column}`, label: text, disabled: !isEditable(row, column), disabledReason: 'Not editable for this record or operator.', onSelect: () => startEdit(row, column) });
    switch (list) {
      case 'members': {
        const member = row as MemberRow;
        const ref = { id: member.id, memberNumber: member.memberNumber, displayName: member.displayName };
        return [
          { id: 'open', label: `Open ${member.memberNumber}`, onSelect: () => open(row) },
          edit('email', 'Edit email'), edit('phone', 'Edit phone'),
          { id: 'account', label: 'Open new account…', disabled: !can('account.open'), onSelect: () => openDialog({ kind: 'account.open', member: ref }) },
          { id: 'case', label: 'New service case…', disabled: !can('case.open'), onSelect: () => openDialog({ kind: 'case.open', member: ref, accountId: null }) },
          select,
        ];
      }
      case 'accounts': {
        const account = row as AccountRow;
        const inactive = INACTIVE_ACCOUNT.has(account.status);
        return [
          { id: 'open', label: `Open ${account.accountNumber}`, onSelect: () => open(row) },
          { id: 'owner', label: `Open owner ${account.memberNumber}`, onSelect: () => openRecord('member', account.memberId) },
          edit('nickname', 'Edit nickname'), edit('statement_delivery', 'Edit statement delivery'),
          { id: 'deposit', label: 'Deposit…', section: 'Money', disabled: inactive || !can('cash.deposit'), onSelect: () => openDialog({ kind: 'money', mode: 'deposit', account }) },
          { id: 'withdraw', label: 'Withdraw…', disabled: inactive || !can('cash.withdraw'), onSelect: () => openDialog({ kind: 'money', mode: 'withdraw', account }) },
          { id: 'transfer', label: 'Transfer…', disabled: inactive || !can('transfer.internal'), onSelect: () => openDialog({ kind: 'money', mode: 'transfer', account }) },
          select,
        ];
      }
      case 'cases': {
        const record = row as CaseRow;
        return [
          { id: 'open', label: `Open ${record.caseNumber}`, onSelect: () => open(row) },
          { id: 'member', label: `Open member ${record.memberNumber}`, onSelect: () => openRecord('member', record.memberId) },
          { id: 'assign', label: 'Assign…', disabled: !can('case.assign'), onSelect: () => openDialog({ kind: 'case.assign', record }) },
          { id: 'transition', label: 'Change status…', disabled: !can('case.transition'), onSelect: () => openDialog({ kind: 'case.transition', record }) },
          select,
        ];
      }
      case 'documents': {
        const document = row as DocumentGridRow;
        return [
          { id: 'open', label: `Open ${document.displayName}`, onSelect: () => openRecord('document', document.documentId) },
          { id: 'download', label: 'Download', onSelect: () => { void download(institutionPath(institutionId, `/documents/${encodeURIComponent(document.versionId)}/content`)).then((result) => notify('success', `Downloaded ${result.filename}.`), (error: unknown) => notify('error', String(error))); } },
          { id: 'owner', label: `Open owner ${document.memberNumber}`, onSelect: () => openRecord('member', document.memberId) },
          ...(document.accountId === null ? [] : [{ id: 'account', label: `Open account ${document.accountNumber ?? ''}`, onSelect: () => { if (document.accountId !== null) openRecord('account', document.accountId); } }]),
        ];
      }
      case 'activity': return [{ id: 'open', label: 'Open receipt or record', onSelect: () => open(row) }];
    }
  };

  const count = selectedCount(selection);
  const pageIndex = Math.floor(range.first / PAGE_SIZE);
  const selectionHeader = config.entity === null ? null : (
    <MenuButton label="Selection" className="selection-toggle" buttonLabel="Selection options" items={() => {
      const pageRows = flat.paged?.page(pageIndex);
      const from = pageIndex * PAGE_SIZE + 1;
      const to = Math.min(total, (pageIndex + 1) * PAGE_SIZE);
      return [
        {
          id: 'page', label: `Select rows ${from.toLocaleString('en-US')}–${to.toLocaleString('en-US')} (this page)`, disabled: grouped || pageRows === undefined,
          disabledReason: grouped ? 'Page selection is unavailable while grouped; select all matching instead.' : 'This page is still loading.',
          onSelect: () => { if (pageRows !== undefined) setSelection((previous) => selectRecords(previous, pageRows.map((row) => [row.id, label(row)] as const))); },
        },
        {
          id: 'all', label: `Select all ${total.toLocaleString('en-US')} matching`, disabled: params.maxResults !== null || total === 0,
          ...(params.maxResults === null ? {} : { disabledReason: 'This saved search is limited; select rows explicitly.' }),
          onSelect: () => setSelection(selectAllMatching(currentMatch, total, describeFilters(list, params))),
        },
        { id: 'clear', label: 'Clear selection', disabled: count === 0, onSelect: () => setSelection(EMPTY_SELECTION) },
      ];
    }}>{selection.mode === 'matching' ? '☑' : count > 0 ? '▣' : '☐'}</MenuButton>
  );

  const exportSelection = (): void => {
    if (config.entity === null) return;
    const columns = displayedColumnIds(config.grid, layout);
    const body = selection.mode === 'ids'
      ? { selection: { mode: 'ids', ids: [...selection.ids.keys()] }, columns }
      : { selection: { mode: 'matching', filters: cleanFilters(list, params.filters), sort: params.sort, excludedIds: [...selection.excluded] }, columns };
    download(institutionPath(institutionId, `/exports/${config.grid}`), { method: 'POST', body }).then(
      (result) => notify('success', `Exported ${plural(result.count ?? 0, 'record')} to ${result.filename} (SHA-256 ${result.digest?.slice(0, 12) ?? '?'}…).`),
      (error: unknown) => notify('error', `Export refused: ${error instanceof Error ? error.message : String(error)}`),
    );
  };

  const applySaved = (search: SavedSearchRow & { definition: SavedSearchDefinition }): void => {
    const definition = search.definition;
    apply({ kind: 'showOnly', columns: definition.columns });
    navigate({ view: 'list', institutionId, list, params: { filters: definition.filters, sort: definition.sort[0] ?? null, groupBy: null, savedSearchId: search.id, maxResults: definition.maxResults ?? null } });
  };

  const { snapshot } = flat;
  const sortable = (column: string): boolean => Object.hasOwn(GRID_SORTS[config.grid], column);
  const rangeText = total === 0 ? 'No rows' : `Rows ${(range.first + 1).toLocaleString('en-US')}–${(range.last + 1).toLocaleString('en-US')} of ${total.toLocaleString('en-US')}${grouped ? ' (grouped)' : ''}`;
  const editingIndex = editing === null ? undefined : source.indexOf(editing.rowId);
  const editDraft = editing === null || editKind === null ? undefined : drafts.get(draftKey(institutionId, editKind, editing.rowId));
  const { pinned } = visibleColumns(config.grid, layout);

  return (
    <section className="list-view" hidden={!active} aria-label={`${config.title} list`} data-list={list}>
      <div className="toolbar" role="toolbar" aria-label={`${config.title} search`}>
        <SearchBox label={`Search ${config.title.toLowerCase()}`} value={typeof params.filters.query === 'string' ? params.filters.query : ''} onCommit={(text) => update({ filters: { ...params.filters, query: text } })} />
        <Filters list={list} params={params} update={update} />
        {config.entity === null ? null : (
          <SavedSearches
            entity={config.entity} params={params} columns={displayedColumnIds(config.grid, layout)} onOpen={applySaved}
            onSaved={(searchId) => navigate({ view: 'list', institutionId, list, params: { ...params, savedSearchId: searchId } }, { replace: true })}
          />
        )}
        <MenuButton label="Columns" items={() => [
          ...GRID_COLUMNS[config.grid].map((column, index) => ({
            id: column.id, label: `${column.label}${layout.pinned.includes(column.id) ? ' (pinned)' : ''}`, checked: !layout.hidden.includes(column.id),
            ...(index === 0 ? { section: 'Show columns' } : {}), onSelect: () => apply({ kind: 'toggleHidden', column: column.id }),
          })),
          { id: 'reset', label: 'Reset to default layout', section: 'Layout', onSelect: () => apply({ kind: 'reset' }) },
        ]}>Columns ▾</MenuButton>
        {list === 'members' ? <button type="button" className="tool-button" disabled={!can('member.create')} onClick={() => openDialog({ kind: 'member.create' })}>New member…</button> : null}
        {Object.keys(cleanFilters(list, params.filters)).length > 0 || params.sort !== null || params.savedSearchId !== null ? (
          <button type="button" className="tool-button" onClick={() => update({ filters: {}, sort: null, groupBy: null, savedSearchId: null, maxResults: null })}>Clear search</button>
        ) : null}
      </div>
      {config.entity === null || (count === 0 && selectionNotice === null) ? null : (
        <div className="selection-bar" role="status" data-selection-mode={selection.mode} data-selected-count={count}>
          {selection.mode === 'matching'
            ? <span>All <strong>{selection.total.toLocaleString('en-US')}</strong> {config.noun}s matching {selection.description} selected{selection.excluded.size > 0 ? `, except ${String(selection.excluded.size)}` : ''}. This covers every matching record, not only loaded rows; changing the search clears it.</span>
            : count > 0 ? <span><strong>{count}</strong> {count === 1 ? config.noun : `${config.noun}s`} selected{hiddenIds.length > 0 ? '' : ' (all visible in this search)'}.</span> : null}
          {hiddenIds.length > 0 && selection.mode === 'ids' ? (
            <span className="hidden-selection" data-hidden-count={hiddenIds.length}>
              {' '}{hiddenIds.length} of them {hiddenIds.length === 1 ? 'is' : 'are'} hidden by the current search: {hiddenIds.slice(0, 6).map((id) => selection.ids.get(id) ?? id).join(', ')}{hiddenIds.length > 6 ? '…' : ''}.
              <button type="button" className="link" onClick={() => setSelection({ mode: 'ids', ids: new Map([...selection.ids].filter(([id]) => !hiddenIds.includes(id))) })}>Deselect hidden</button>
            </span>
          ) : null}
          {count > 0 ? <button type="button" onClick={exportSelection}>Export CSV ({count.toLocaleString('en-US')})</button> : null}
          {count > 0 ? <button type="button" onClick={() => setSelection(EMPTY_SELECTION)}>Clear selection</button> : null}
          {selectionNotice === null ? null : <span className="notice">{selectionNotice} <button type="button" className="link" onClick={() => setSelectionNotice(null)}>Dismiss</button></span>}
        </div>
      )}
      <div className="list-body">
        <div className="list-grid">
          <VirtualGrid<ListRow>
            key={currentWindow} gridId={config.grid} gridKey={`list-${list}`} label={`${config.title} results`} source={source} layout={layout} onColumnAction={apply}
            sort={params.sort} sortable={sortable} onSort={(sort: SortState | null) => update({ sort })} cell={cell} rowLabel={label}
            selection={config.entity === null ? null : { isSelected: (id) => isSelected(selection, id), toggle, header: selectionHeader }}
            isEditable={isEditable} onEdit={startEdit} onActiveRow={setActiveRow} onOpen={open} rowMenu={rowMenu} rowState={rowState}
            onToggleGroup={(key) => setCollapsed((previous) => { const next = new Set(previous); if (next.has(key)) next.delete(key); else next.add(key); return next; })}
            initialScrollTop={scrollMemory.get(currentWindow) ?? 0} onScrollTop={(top) => scrollMemory.set(currentWindow, top)} onRange={setRange} onScroller={setScroller} handle={gridHandle}
            emptyText={snapshot.loading && !grouped ? 'Loading…' : `No ${config.noun}s match this search.`}
          />
        </div>
        <Preview list={list} row={activeRow} />
      </div>
      <footer className="list-status">
        <span data-range-first={range.first} data-total={total}>{rangeText}</span>
        {grouped ? null : (
          <span className="pager">
            <button type="button" disabled={range.first === 0} onClick={() => gridHandle.current?.scrollToIndex(Math.max(0, (pageIndex - 1) * PAGE_SIZE))}>Previous page</button>
            <button type="button" disabled={(pageIndex + 1) * PAGE_SIZE >= total} onClick={() => gridHandle.current?.scrollToIndex((pageIndex + 1) * PAGE_SIZE)}>Next page</button>
            <form onSubmit={(event) => { event.preventDefault(); const row = Number(goTo); if (Number.isInteger(row) && row >= 1) { gridHandle.current?.scrollToIndex(row - 1); gridHandle.current?.focus(); } }}>
              <label>Go to row <input value={goTo} inputMode="numeric" size={6} onChange={(event) => setGoTo(event.target.value)} /></label>
            </form>
          </span>
        )}
        {snapshot.limitedTo === null ? null : <span className="warning">Limited to the first {snapshot.limitedTo.toLocaleString('en-US')} of {(snapshot.matched ?? 0).toLocaleString('en-US')} matching (saved-search limit).</span>}
        {snapshot.drifted ? <span className="warning">Results changed while you browsed. <button type="button" className="link" onClick={() => flat.paged?.refresh()}>Reload rows</button></span> : null}
        {snapshot.error === null ? null : <span className="error">{snapshot.error}</span>}
        {groups.error === null ? null : <span className="error">{groups.error}</span>}
        <span className="muted">{pinned.length} pinned · Alt+Shift+←/→ moves a column</span>
      </footer>
      {active && editing !== null ? (
        <CellEditor
          key={`${editing.rowId}:${editing.column}`} target={editing} gridKey={`list-${list}`} scroller={scroller}
          status={editDraft === undefined ? null : editDraft.status.phase === 'rejected' ? `Rejected: ${editDraft.status.message}` : editDraft.status.phase}
          onChange={(value) => writeDraft(editing, value)}
          onClose={(then) => {
            const key = draftKey(institutionId, editing.recordKind, editing.rowId);
            setEditing(null);
            focusGrid();
            if (then === 'save') void saveDraft(key);
          }}
          onCancel={() => {
            if (editing.initial === null) dispatchDrafts({ type: 'discardField', key: draftKey(institutionId, editing.recordKind, editing.rowId), field: editing.column });
            else writeDraft(editing, editing.initial);
            setEditing(null);
            focusGrid();
          }}
          onScrollTo={editingIndex === undefined ? null : () => gridHandle.current?.scrollToIndex(editingIndex)}
        />
      ) : null}
    </section>
  );
}
