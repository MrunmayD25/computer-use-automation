/** Formats exact integer minor units with the currency's exponent, for example 596614 USD → "5,966.14 USD". */
export function formatMoney(minorUnits: number, currency: string, exponent: number): string {
  const digits = String(Math.abs(minorUnits)).padStart(exponent + 1, '0');
  const whole = digits.slice(0, digits.length - exponent).replace(/\B(?=(\d{3})+(?!\d))/gu, ',');
  const fraction = exponent > 0 ? `.${digits.slice(digits.length - exponent)}` : '';
  return `${minorUnits < 0 ? '-' : ''}${whole}${fraction} ${currency}`;
}

export type MoneyParse = { ok: true; minorUnits: number } | { ok: false; message: string };

/** Parses a typed positive amount into exact minor units without floating-point arithmetic. */
export function parseMoney(text: string, exponent: number): MoneyParse {
  const cleaned = text.trim().replaceAll(',', '');
  const pattern = exponent > 0 ? new RegExp(`^(\\d{1,13})(?:\\.(\\d{1,${String(exponent)}}))?$`, 'u') : /^(\d{1,13})$/u;
  const match = pattern.exec(cleaned);
  if (match === null) return { ok: false, message: exponent > 0 ? `Enter a positive amount with at most ${String(exponent)} decimal places.` : 'Enter a positive whole amount.' };
  const minorUnits = Number(`${match[1] ?? '0'}${(match[2] ?? '').padEnd(exponent, '0')}`);
  if (!Number.isSafeInteger(minorUnits) || minorUnits <= 0) return { ok: false, message: 'Enter an amount greater than zero.' };
  return { ok: true, minorUnits };
}
