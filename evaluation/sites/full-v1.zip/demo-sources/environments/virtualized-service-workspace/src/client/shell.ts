import type { AccountRow, CaseRow, MemberDetail } from '@computer-use/financial-database/services';
import { createContext, useContext } from 'react';

import type { RecordKind } from './model/route.js';
import type { OperationContext } from './ops/OperationDialog.js';
import type { InquirySpec, OpSpec } from './ops/registry.js';

export interface MemberRef {
  id: string;
  memberNumber: string;
  displayName: string;
}

/** Every dialog the workspace can open, with the records it acts on. */
export type DialogSpec =
  | { kind: 'member.create' }
  | { kind: 'contact.update'; member: MemberDetail }
  | { kind: 'note'; owner: { kind: 'member' | 'case'; id: string; label: string } }
  | { kind: 'account.open'; member: MemberRef }
  | { kind: 'money'; mode: 'deposit' | 'withdraw' | 'transfer'; account: AccountRow }
  | { kind: 'account.close'; account: AccountRow }
  | { kind: 'case.open'; member: MemberRef; accountId: string | null }
  | { kind: 'case.assign'; record: CaseRow }
  | { kind: 'case.transition'; record: CaseRow }
  | { kind: 'case.subject.correct'; record: CaseRow }
  | { kind: 'operation'; spec: OpSpec | InquirySpec; inquiry?: boolean; context?: OperationContext };

/** Member and account a record tab is about, shown in the context bar while the tab is active. */
export interface RecordContext {
  title: string;
  member: { id: string; number: string; name: string } | null;
  account: { id: string; number: string; currency: string } | null;
}

export interface ShellValue {
  openRecord: (kind: RecordKind, id: string, resource?: string) => void;
  openDialog: (spec: DialogSpec) => void;
  /** Record tabs report what they show, keyed by their own tab, so one tab can never label another. */
  publishContext: (tabKey: string, context: RecordContext | null) => void;
}

export const ShellContext = createContext<ShellValue | null>(null);

export function useShell(): ShellValue {
  const value = useContext(ShellContext);
  if (value === null) throw new Error('useShell is used outside the workspace shell.');
  return value;
}

export function tabKeyOf(institutionId: string, kind: RecordKind, id: string): string {
  return `${institutionId}/${kind}/${id}`;
}

export function resourceTabKey(institutionId: string, resource: string, id: string): string {
  return `${institutionId}/resource/${resource}/${id}`;
}
