import type { CommandOutcome, ReviewOutcome, ServiceCommand } from '@computer-use/financial-database/services';

import type { ApiErrorBody } from '../shared/api.js';

export class ApiError extends Error {
  constructor(readonly status: number, readonly code: string, message: string, readonly field?: string) { super(message); }
}

/** A request whose outcome is unknown because no response arrived. */
export function isNetworkFailure(error: unknown): boolean {
  return error instanceof ApiError && error.status === 0;
}

async function send(path: string, init: RequestInit): Promise<Response> {
  let response: Response;
  try {
    response = await fetch(path, { ...init, credentials: 'same-origin', headers: { accept: 'application/json', ...(init.body === undefined ? {} : { 'content-type': 'application/json' }) } });
  } catch (error) {
    if (init.signal?.aborted === true) throw error;
    throw new ApiError(0, 'network', 'The workspace backend could not be reached. Nothing was lost; retry when the connection returns.');
  }
  if (!response.ok) {
    let body: ApiErrorBody | undefined;
    try { body = await response.json() as ApiErrorBody; } catch { body = undefined; }
    throw new ApiError(response.status, body?.error.code ?? `http_${String(response.status)}`, body?.error.message ?? `The request failed with status ${String(response.status)}.`, body?.error.field);
  }
  return response;
}

export async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  return await (await send(path, signal === undefined ? {} : { signal })).json() as T;
}

export async function sendJson<T>(method: 'POST' | 'PUT' | 'DELETE', path: string, body?: unknown): Promise<T> {
  return await (await send(path, { method, ...(body === undefined ? {} : { body: JSON.stringify(body) }) })).json() as T;
}

/** Path below one bound institution. The backend maps it to its trusted dataset. */
export function institutionPath(institutionId: string, path: string): string {
  return `/api/i/${encodeURIComponent(institutionId)}${path}`;
}

export function queryString(parameters: Readonly<Record<string, string | number | boolean | readonly string[] | null | undefined>>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(parameters)) {
    if (value === undefined || value === null || value === '' || value === false) continue;
    search.set(key, Array.isArray(value) ? value.join(',') : String(value));
  }
  const text = search.toString();
  return text === '' ? '' : `?${text}`;
}

export function reviewCommand(institutionId: string, command: ServiceCommand): Promise<ReviewOutcome> {
  return sendJson<ReviewOutcome>('POST', institutionPath(institutionId, '/commands/review'), { command });
}

/** Runs a command. Retrying with the same key returns the original receipt instead of repeating the effect. */
export function executeCommand(institutionId: string, command: ServiceCommand, idempotencyKey: string): Promise<CommandOutcome> {
  return sendJson<CommandOutcome>('POST', institutionPath(institutionId, '/commands'), { command, idempotencyKey });
}

export function newIdempotencyKey(kind: string): string {
  return `${kind}:${crypto.randomUUID()}`;
}

export interface FinanceListRow {
  id: string;
  label: string;
  status: string | null;
  fields: Record<string, string | number | null>;
}

export interface FinanceListPage {
  kind: 'listed';
  resource: string;
  items: FinanceListRow[];
  total: number;
  offset: number;
  limit: number;
}

export interface FinanceRecordSnapshot {
  kind: string;
  id: string;
  fingerprint: string | null;
  record: Record<string, unknown>;
  observedAt: string;
}

export function listRecords(institutionId: string, resource: string, parameters: Readonly<Record<string, string | number | null | undefined>>, signal?: AbortSignal): Promise<FinanceListPage> {
  return getJson<FinanceListPage>(institutionPath(institutionId, `/records/${encodeURIComponent(resource)}${queryString(parameters)}`), signal);
}

export function readRecord(institutionId: string, resource: string, id: string, signal?: AbortSignal): Promise<FinanceRecordSnapshot> {
  return getJson<FinanceRecordSnapshot>(institutionPath(institutionId, `/records/${encodeURIComponent(resource)}/${encodeURIComponent(id)}`), signal);
}

export function financeQuery<T>(institutionId: string, query: unknown): Promise<T> {
  return sendJson<T>('POST', institutionPath(institutionId, '/query/finance'), { query });
}

export function coreQuery<T>(institutionId: string, query: unknown): Promise<T> {
  return sendJson<T>('POST', institutionPath(institutionId, '/query/core'), { query });
}

export function servicingRead<T>(institutionId: string, reader: string, args: Readonly<Record<string, string | null>> = {}): Promise<T> {
  return sendJson<T>('POST', institutionPath(institutionId, '/servicing/read'), { reader, args });
}

export interface ApprovalRow {
  id: string;
  status: string;
  fingerprint: string;
  target: unknown;
  expiresAt: string;
  amountLimit: { minorUnits: number; currency: string } | null;
  maker: { id: string; actorNumber: string; displayName: string };
  checker: { id: string; actorNumber: string; displayName: string };
}

export function listApprovalsApi(institutionId: string): Promise<{ kind: 'found'; approvals: ApprovalRow[]; total: number; truncated: boolean }> {
  return getJson(institutionPath(institutionId, '/approvals'));
}

export interface IdentityCandidate {
  memberId: string;
  memberNumber: string;
  displayName: string;
  status: string;
  match: readonly string[];
}

export function resolveIdentity(institutionId: string, criteria: Readonly<Record<string, string | undefined>>): Promise<unknown> {
  return getJson(institutionPath(institutionId, `/identity-resolve${queryString(criteria)}`));
}

export interface DownloadResult {
  filename: string;
  digest: string | null;
  count: number | null;
}

/** Downloads a server-rendered file through a real browser download, reporting its name and digest. */
export async function download(path: string, init: { method?: 'GET' | 'POST'; body?: unknown } = {}): Promise<DownloadResult> {
  const response = await send(path, init.method === 'POST' ? { method: 'POST', body: JSON.stringify(init.body) } : {});
  const disposition = response.headers.get('content-disposition') ?? '';
  const filename = /filename="([^"]+)"/u.exec(disposition)?.[1] ?? 'download';
  const url = URL.createObjectURL(await response.blob());
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
  const count = response.headers.get('x-export-count');
  return { filename, digest: response.headers.get('x-document-digest'), count: count === null ? null : Number(count) };
}
