import type { AccountDetail, AccountRow, CaseDetail, CaseRow, MemberDetail, MemberRow } from '@computer-use/financial-database/services';
import type { ReactNode } from 'react';

import { institutionPath } from '../api.js';
import { formatDate, formatInstant, formatMoney, label } from '../format.js';
import type { ListId } from '../model/route.js';
import { useShell } from '../shell.js';
import { useResource } from '../useResource.js';
import { useWorkspace } from '../workspace.js';
import type { ActivityGridRow, DocumentGridRow } from './cells.js';

export type ListRow = MemberRow | AccountRow | CaseRow | DocumentGridRow | ActivityGridRow;

function detailPath(list: ListId, row: ListRow | null): string | null {
  if (row === null) return null;
  if (list === 'members') return `/members/${encodeURIComponent(row.id)}`;
  if (list === 'accounts') return `/accounts/${encodeURIComponent(row.id)}`;
  if (list === 'cases') return `/cases/${encodeURIComponent(row.id)}`;
  return null;
}

/**
 * Detail of the active row in an independently scrolling side panel. Each response is tied to the record
 * it was requested for, so moving quickly through rows can never show one record's detail under another.
 */
export function Preview({ list, row }: { list: ListId; row: ListRow | null }): ReactNode {
  const { institution, dataVersion } = useWorkspace();
  const { openRecord } = useShell();
  const path = detailPath(list, row);
  const { data, error } = useResource<MemberDetail | AccountDetail | CaseDetail>(path === null ? null : institutionPath(institution.institutionId, path), dataVersion);
  let body: ReactNode = <p className="muted">Select a row to preview it.</p>;
  if (row !== null && path !== null && data === undefined) body = error === null ? <p className="muted">Loading…</p> : <p className="error">{error}</p>;
  else if (row !== null && list === 'members' && data !== undefined) {
    const detail = data as MemberDetail;
    body = (
      <>
        <h3>{detail.member.displayName}</h3>
        <dl className="facts">
          <dt>Member</dt><dd><code>{detail.member.memberNumber}</code> · {label(detail.member.status)}</dd>
          <dt>Email</dt><dd>{detail.email?.value ?? '—'}</dd>
          <dt>Phone</dt><dd>{detail.phone?.value ?? '—'}</dd>
          <dt>Address</dt><dd>{detail.address === null ? '—' : `${detail.address.line1}, ${detail.address.city} ${detail.address.postalCode}`}</dd>
          <dt>Accounts</dt><dd>{detail.accounts.length} ({detail.member.openAccounts} open)</dd>
          <dt>Cases</dt><dd>{detail.cases.length}</dd>
        </dl>
        <button type="button" onClick={() => openRecord('member', detail.member.id)}>Open member</button>
      </>
    );
  } else if (row !== null && list === 'accounts' && data !== undefined) {
    const { account, eligibility } = data as AccountDetail;
    body = (
      <>
        <h3>{account.nickname === '' ? account.productName : account.nickname}</h3>
        <dl className="facts">
          <dt>Account</dt><dd><code>{account.accountNumber}</code> · {label(account.status)}</dd>
          <dt>Owner</dt><dd><button type="button" className="link" onClick={() => openRecord('member', account.memberId)}>{account.ownerName} ({account.memberNumber})</button></dd>
          <dt>Product</dt><dd>{account.productName}</dd>
          <dt>Posted</dt><dd className="money">{formatMoney(account.postedMinorUnits, account.currency, account.exponent)}</dd>
          <dt>Available</dt><dd className="money">{formatMoney(account.availableMinorUnits, account.currency, account.exponent)}</dd>
          <dt>Statements</dt><dd>{label(account.statementDelivery)}</dd>
          <dt>Debits</dt><dd>{eligibility.debit.eligible ? 'Allowed' : eligibility.debit.reasons.join('; ')}</dd>
          <dt>Version</dt><dd>{account.version}</dd>
        </dl>
        <button type="button" onClick={() => openRecord('account', account.id)}>Open account</button>
      </>
    );
  } else if (row !== null && list === 'cases' && data !== undefined) {
    const detail = data as CaseDetail;
    const record = detail.case;
    body = (
      <>
        <h3>{record.summary}</h3>
        <dl className="facts">
          <dt>Case</dt><dd><code>{record.caseNumber}</code> · {label(record.state)} · {label(record.priority)}</dd>
          <dt>Member</dt><dd><button type="button" className="link" onClick={() => openRecord('member', record.memberId)}>{record.memberName} ({record.memberNumber})</button></dd>
          <dt>Queue</dt><dd>{record.queueCode} · {record.queueName}</dd>
          <dt>Assignee</dt><dd>{record.assignedName ?? 'Unassigned'}</dd>
          <dt>Due</dt><dd>{formatInstant(record.dueAt)}{record.overdue ? ' (overdue)' : ''}</dd>
        </dl>
        <h4>Latest events</h4>
        <ul className="timeline">{detail.events.slice(-4).reverse().map((event) => <li key={event.sequence}>{formatDate(event.occurredAt)} · {label(event.state)} · {event.detail}</li>)}</ul>
        <button type="button" onClick={() => openRecord('case', record.id)}>Open case</button>
      </>
    );
  } else if (row !== null && list === 'documents') {
    const document = row as DocumentGridRow;
    body = (
      <>
        <h3>{document.displayName}</h3>
        <dl className="facts">
          <dt>Type</dt><dd>{label(document.documentType)}</dd><dt>Issued</dt><dd>{formatDate(document.issuedAt)}</dd>
          <dt>Owner</dt><dd><button type="button" className="link" onClick={() => openRecord('member', document.memberId)}>{document.ownerName} ({document.memberNumber})</button></dd>
          <dt>Account</dt><dd>{document.accountId === null ? '—' : <button type="button" className="link" onClick={() => { if (document.accountId !== null) openRecord('account', document.accountId); }}>{document.accountNumber}</button>}</dd>
          <dt>Version</dt><dd>{document.version} · <code>{document.digest.slice(0, 16)}…</code></dd>
        </dl>
      </>
    );
  } else if (row !== null && list === 'activity') {
    const event = row as ActivityGridRow;
    body = (
      <>
        <h3>Event {event.sequence}</h3>
        <dl className="facts">
          <dt>When</dt><dd>{formatInstant(event.occurredAt)}</dd><dt>Operation</dt><dd><code>{event.kind}</code></dd>
          <dt>Record</dt><dd>{event.resourceKind} {event.resourceId}</dd><dt>By</dt><dd>{event.actor === null ? 'System' : `${event.actor.displayName} (${event.actor.actorNumber})`}</dd>
          <dt>Summary</dt><dd>{event.summary}</dd>
        </dl>
        {event.receiptNumber === null ? null : <button type="button" onClick={() => { if (event.receiptNumber !== null) openRecord('receipt', event.receiptNumber); }}>Open receipt {event.receiptNumber}</button>}
      </>
    );
  }
  return <aside className="preview" aria-label="Preview" data-preview-for={row?.id} data-preview-loaded={data === undefined ? undefined : 'true'}>{body}</aside>;
}
