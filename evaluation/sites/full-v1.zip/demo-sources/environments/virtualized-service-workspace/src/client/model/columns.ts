import type { ColumnLayout } from '../../shared/api.js';
import { COLUMN_WIDTH_LIMITS, GRID_COLUMNS, type ColumnSpec, type GridId } from '../../shared/columns.js';

export interface ResolvedColumn extends ColumnSpec {
  pinned: boolean;
}

export interface VisibleColumns {
  /** Pinned columns stay at the left edge while the rest scroll horizontally. */
  pinned: ResolvedColumn[];
  scrolling: ResolvedColumn[];
}

export type ColumnAction =
  | { kind: 'shift'; column: string; delta: -1 | 1 }
  | { kind: 'moveBefore'; column: string; before: string | null }
  | { kind: 'resize'; column: string; width: number }
  | { kind: 'toggleHidden'; column: string }
  | { kind: 'togglePinned'; column: string }
  | { kind: 'showOnly'; columns: readonly string[] }
  | { kind: 'reset' };

export function defaultLayout(grid: GridId): ColumnLayout {
  const specs = GRID_COLUMNS[grid];
  return {
    order: specs.map((column) => column.id), widths: {},
    hidden: specs.filter((column) => column.hiddenByDefault === true).map((column) => column.id),
    pinned: specs.filter((column) => column.pinnedByDefault === true).map((column) => column.id),
  };
}

/** Brings a stored layout in line with the current column catalog: unknown ids drop, new columns append. */
export function normalizeLayout(grid: GridId, layout: ColumnLayout | null): ColumnLayout {
  if (layout === null) return defaultLayout(grid);
  const known = GRID_COLUMNS[grid].map((column) => column.id);
  const order = [...new Set(layout.order.filter((id) => known.includes(id))), ...known.filter((id) => !layout.order.includes(id))];
  const widths = Object.fromEntries(Object.entries(layout.widths).filter(([id]) => known.includes(id)).map(([id, width]) => [id, clampWidth(width)]));
  const hidden = layout.hidden.filter((id) => known.includes(id));
  return { order, widths, hidden: hidden.length >= known.length ? [] : hidden, pinned: layout.pinned.filter((id) => known.includes(id)) };
}

export function clampWidth(width: number): number {
  return Math.round(Math.min(COLUMN_WIDTH_LIMITS.max, Math.max(COLUMN_WIDTH_LIMITS.min, width)));
}

export function visibleColumns(grid: GridId, layout: ColumnLayout): VisibleColumns {
  const specs = new Map(GRID_COLUMNS[grid].map((column) => [column.id, column]));
  const resolved = layout.order.flatMap((id): ResolvedColumn[] => {
    const spec = specs.get(id);
    if (spec === undefined || layout.hidden.includes(id)) return [];
    return [{ ...spec, width: layout.widths[id] ?? spec.width, pinned: layout.pinned.includes(id) }];
  });
  return { pinned: resolved.filter((column) => column.pinned), scrolling: resolved.filter((column) => !column.pinned) };
}

/** Visible column ids in on-screen order: pinned first, then scrolling. */
export function displayedColumnIds(grid: GridId, layout: ColumnLayout): string[] {
  const { pinned, scrolling } = visibleColumns(grid, layout);
  return [...pinned, ...scrolling].map((column) => column.id);
}

function moveBefore(order: readonly string[], column: string, before: string | null): string[] {
  const without = order.filter((id) => id !== column);
  const index = before === null ? without.length : without.indexOf(before);
  return index < 0 ? [...order] : [...without.slice(0, index), column, ...without.slice(index)];
}

export function applyColumnAction(grid: GridId, layout: ColumnLayout, action: ColumnAction): ColumnLayout {
  switch (action.kind) {
    case 'reset': return defaultLayout(grid);
    case 'resize': return { ...layout, widths: { ...layout.widths, [action.column]: clampWidth(action.width) } };
    case 'toggleHidden': {
      if (layout.hidden.includes(action.column)) return { ...layout, hidden: layout.hidden.filter((id) => id !== action.column) };
      const visible = layout.order.filter((id) => !layout.hidden.includes(id));
      if (visible.length <= 1) return layout;
      return { ...layout, hidden: [...layout.hidden, action.column] };
    }
    case 'togglePinned':
      return { ...layout, pinned: layout.pinned.includes(action.column) ? layout.pinned.filter((id) => id !== action.column) : [...layout.pinned, action.column] };
    case 'moveBefore': {
      if (action.column === action.before) return layout;
      const pinned = action.before === null ? layout.pinned.includes(action.column) : layout.pinned.includes(action.before);
      const nextPinned = pinned ? [...new Set([...layout.pinned, action.column])] : layout.pinned.filter((id) => id !== action.column);
      return { ...layout, order: moveBefore(layout.order, action.column, action.before), pinned: nextPinned };
    }
    case 'shift': {
      const { pinned, scrolling } = visibleColumns(grid, layout);
      const section = (layout.pinned.includes(action.column) ? pinned : scrolling).map((column) => column.id);
      const index = section.indexOf(action.column);
      const target = index + action.delta;
      if (index < 0 || target < 0 || target >= section.length) return layout;
      const neighbour = section[target];
      if (neighbour === undefined) return layout;
      const order = action.delta < 0 ? moveBefore(layout.order, action.column, neighbour)
        : moveBefore(layout.order, action.column, layout.order[layout.order.indexOf(neighbour) + 1] ?? null);
      return { ...layout, order };
    }
    case 'showOnly': {
      const known = GRID_COLUMNS[grid].map((column) => column.id);
      const shown = action.columns.filter((id) => known.includes(id));
      if (shown.length === 0) return layout;
      const unpinnedShown = shown.filter((id) => !layout.pinned.includes(id));
      const pinnedShown = shown.filter((id) => layout.pinned.includes(id));
      return { ...layout, order: [...pinnedShown, ...unpinnedShown, ...layout.order.filter((id) => !shown.includes(id))], hidden: known.filter((id) => !shown.includes(id)) };
    }
  }
}
