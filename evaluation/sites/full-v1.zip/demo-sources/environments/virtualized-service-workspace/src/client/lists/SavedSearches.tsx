import type { SavedSearchDefinition, SavedSearchFilterValue, SavedSearchRow } from '@computer-use/financial-database/services';
import { useState, type ReactNode } from 'react';

import type { SearchEntity } from '../../shared/columns.js';
import { institutionPath } from '../api.js';
import { CommandDialog } from '../commands.js';
import { cleanFilters, type ListParams } from '../model/route.js';
import { useShell } from '../shell.js';
import { MenuButton, type MenuItem } from '../ui/Menu.js';
import { useResource } from '../useResource.js';
import { useWorkspace } from '../workspace.js';

/** The current list state expressed in the shared saved-search vocabulary. */
export function currentDefinition(entity: SearchEntity, params: ListParams, columns: readonly string[]): SavedSearchDefinition {
  const filters: Record<string, SavedSearchFilterValue> = {};
  for (const [key, value] of Object.entries(cleanFilters(entity, params.filters))) filters[key] = typeof value === 'string' || typeof value === 'boolean' ? value : [...new Set(value)];
  return { entity, filters, sort: params.sort === null ? [] : [params.sort], columns: [...columns], ...(params.maxResults === null ? {} : { maxResults: params.maxResults }) };
}

function canonical(definition: SavedSearchDefinition): string {
  const filters = Object.entries(definition.filters).sort(([a], [b]) => a.localeCompare(b));
  return JSON.stringify([filters, definition.sort, definition.columns, definition.maxResults ?? null]);
}

type Pending = { kind: 'create' } | { kind: 'rename'; search: SavedSearchRow } | { kind: 'delete'; search: SavedSearchRow } | { kind: 'update'; search: SavedSearchRow };

interface SavedSearchesProps {
  entity: SearchEntity;
  params: ListParams;
  columns: readonly string[];
  onOpen: (search: SavedSearchRow & { definition: SavedSearchDefinition }) => void;
  onSaved: (searchId: string | null) => void;
}

/** Saved-search menu of one list. Filters, sort, columns and limit keep their stored meaning when reopened. */
export function SavedSearches({ entity, params, columns, onOpen, onSaved }: SavedSearchesProps): ReactNode {
  const { institution, dataVersion, profile, can } = useWorkspace();
  const { openRecord } = useShell();
  const institutionId = institution.institutionId;
  const { data, error } = useResource<SavedSearchRow[]>(institutionPath(institutionId, `/saved-searches?entity=${entity}`), dataVersion);
  const [pending, setPending] = useState<Pending | null>(null);
  const [name, setName] = useState('');
  const [visibility, setVisibility] = useState<'private' | 'shared'>('private');
  const current = data?.find((search) => search.id === params.savedSearchId);
  const definition = currentDefinition(entity, params, columns);
  const modified = current?.definition != null && canonical(current.definition) !== canonical(definition);
  const ownerOnly = (search: SavedSearchRow): string | undefined => (search.mine ? undefined : `Only its owner ${search.owner.displayName} (${search.owner.actorNumber}) can change this search.`);

  const items = (): MenuItem[] => {
    const mine = data?.filter((search) => search.mine) ?? [];
    const shared = data?.filter((search) => !search.mine) ?? [];
    const open = (search: SavedSearchRow, section: string | undefined, index: number): MenuItem => ({
      id: `open-${search.id}`, label: search.name, hint: search.visibility, checked: search.id === params.savedSearchId,
      ...(index === 0 && section !== undefined ? { section } : {}),
      ...(search.definition === null ? { disabled: true, disabledReason: search.problem ?? 'This search can no longer be applied.' } : {}),
      onSelect: () => { if (search.definition !== null) onOpen({ ...search, definition: search.definition }); },
    });
    const list: MenuItem[] = [
      ...mine.map((search, index) => open(search, 'My searches', index)),
      ...shared.map((search, index) => open(search, 'Shared with the team', index)),
      { id: 'create', label: 'Save current search as…', section: 'Actions', disabled: !can('search.saved.create'), onSelect: () => { setName(''); setVisibility('private'); setPending({ kind: 'create' }); } },
    ];
    if (current !== undefined) {
      const reason = ownerOnly(current);
      list.push(
        { id: 'update', label: `Save changes to “${current.name}”`, disabled: reason !== undefined || !modified, ...(reason === undefined ? (modified ? {} : { disabledReason: 'The list matches the saved search.' }) : { disabledReason: reason }), onSelect: () => setPending({ kind: 'update', search: current }) },
        { id: 'rename', label: `Rename “${current.name}”…`, disabled: reason !== undefined, ...(reason === undefined ? {} : { disabledReason: reason }), onSelect: () => { setName(current.name); setVisibility(current.visibility === 'shared' ? 'shared' : 'private'); setPending({ kind: 'rename', search: current }); } },
        { id: 'delete', label: `Delete “${current.name}”…`, disabled: reason !== undefined, ...(reason === undefined ? {} : { disabledReason: reason }), onSelect: () => setPending({ kind: 'delete', search: current }) },
      );
    }
    return list;
  };

  const close = (): void => setPending(null);
  return (
    <div className="saved-searches">
      <MenuButton label="Saved searches" items={items}>Saved searches ▾</MenuButton>
      {current === undefined ? null : (
        <span className="chip" data-saved-search={current.id}>
          {current.name}{current.visibility === 'shared' ? ' · shared' : ''}{current.mine ? '' : ` · by ${current.owner.actorNumber}`}{modified ? ' · modified' : ''}
        </span>
      )}
      {params.savedSearchId !== null && data !== undefined && current === undefined ? <span className="chip warning">Saved search no longer available</span> : null}
      {error === null ? null : <span className="error">{error}</span>}
      {pending?.kind === 'create' || pending?.kind === 'rename' ? (
        <CommandDialog
          title={pending.kind === 'create' ? 'Save search' : `Rename “${pending.search.name}”`} institutionId={institutionId} review={false} submitLabel="Save" onClose={close}
          onOpenReceipt={(number) => openRecord('receipt', number)}
          successText={(receipt) => `Saved search “${name.trim()}” ${pending.kind === 'create' ? 'created' : 'updated'} (${receipt.receiptNumber}).`}
          onCommitted={(receipt) => { if (pending.kind === 'create') onSaved(receipt.affected.find((item) => item.kind === 'saved-search')?.id ?? null); }}
          build={() => (pending.kind === 'create'
            ? { command: { kind: 'search.saved.create', name, visibility, definition } }
            : { command: { kind: 'search.saved.update', searchId: pending.search.id, expectedRevision: pending.search.revision, name, visibility } })}
        >
          {() => (
            <>
              <label className="field">Name<input value={name} maxLength={80} onChange={(event) => setName(event.target.value)} /></label>
              <label className="field">Visibility
                <select value={visibility} onChange={(event) => setVisibility(event.target.value === 'shared' ? 'shared' : 'private')}>
                  <option value="private">Private (only me)</option>
                  <option value="shared" disabled={profile?.canShareSearches !== true}>Shared with the team{profile?.canShareSearches === true ? '' : ' (needs case management or supervision)'}</option>
                </select>
              </label>
              {pending.kind === 'create' ? <p className="muted">Saves {Object.keys(definition.filters).length === 0 ? 'no filters' : Object.entries(definition.filters).map(([key, value]) => `${key} = ${Array.isArray(value) ? value.join(', ') : String(value)}`).join('; ')}, sort {definition.sort[0] === undefined ? 'default' : `${definition.sort[0].field} ${definition.sort[0].direction}`}, {definition.columns.length} columns{definition.maxResults === undefined ? '' : `, limit ${String(definition.maxResults)}`}.</p> : null}
            </>
          )}
        </CommandDialog>
      ) : null}
      {pending?.kind === 'update' ? (
        <CommandDialog
          title={`Save changes to “${pending.search.name}”`} institutionId={institutionId} review={false} submitLabel="Save changes" onClose={close}
          onOpenReceipt={(number) => openRecord('receipt', number)} successText={(receipt) => `Saved search “${pending.search.name}” updated (${receipt.receiptNumber}).`}
          build={() => ({ command: { kind: 'search.saved.update', searchId: pending.search.id, expectedRevision: pending.search.revision, definition } })}
        >
          {() => <p>Replace the stored filters, sort and columns of “{pending.search.name}” with the current list. {pending.search.visibility === 'shared' ? 'Everyone it is shared with will see the change.' : ''}</p>}
        </CommandDialog>
      ) : null}
      {pending?.kind === 'delete' ? (
        <CommandDialog
          title={`Delete “${pending.search.name}”`} institutionId={institutionId} review={false} submitLabel="Delete" onClose={close}
          onOpenReceipt={(number) => openRecord('receipt', number)} successText={(receipt) => `Saved search “${pending.search.name}” deleted (${receipt.receiptNumber}).`}
          onCommitted={() => onSaved(null)}
          build={() => ({ command: { kind: 'search.saved.delete', searchId: pending.search.id, expectedRevision: pending.search.revision } })}
        >
          {() => <p>Delete this saved search? {pending.search.visibility === 'shared' ? 'It is shared, so it disappears for the team too.' : ''}</p>}
        </CommandDialog>
      ) : null}
    </div>
  );
}
