import { useVirtualizer } from '@tanstack/react-virtual';
import { useEffect, useImperativeHandle, useLayoutEffect, useRef, useState, type CSSProperties, type KeyboardEvent, type ReactNode, type Ref } from 'react';

import type { ColumnLayout } from '../../shared/api.js';
import type { GridId } from '../../shared/columns.js';
import { applyColumnAction, visibleColumns, type ColumnAction, type ResolvedColumn } from '../model/columns.js';
import type { SortState } from '../model/route.js';
import { assignSlots } from '../model/slots.js';
import { AnchoredMenu, type MenuItem } from '../ui/Menu.js';

export const ROW_HEIGHT = 36;
export const HEADER_HEIGHT = 38;
const SELECTION_WIDTH = 64;

export type GridEntry<T> =
  | { kind: 'row'; row: T }
  | { kind: 'header'; key: string; label: string; count: number; expanded: boolean }
  | { kind: 'pending' };

/** Rows of one query, flat or grouped. `version` changes whenever loaded rows change. */
export interface GridSource<T> {
  length: number;
  version: number;
  at: (index: number) => GridEntry<T>;
  indexOf: (id: string) => number | undefined;
  ensure: (start: number, end: number) => void;
}

export interface GridSelection<T> {
  isSelected: (id: string) => boolean;
  toggle: (row: T) => void;
  /** Control in the selection column header, for page or all-matching selection. */
  header: ReactNode;
}

export interface GridHandle {
  scrollToIndex: (index: number) => void;
  focus: () => void;
}

export interface GridRange {
  first: number;
  last: number;
}

interface VirtualGridProps<T extends { id: string }> {
  gridId: GridId;
  /** Distinguishes grids of the same kind on one page; editors and menus find cells below it. */
  gridKey: string;
  label: string;
  source: GridSource<T>;
  layout: ColumnLayout;
  onColumnAction: (action: ColumnAction) => void;
  sort: SortState | null;
  sortable: (column: string) => boolean;
  onSort: (sort: SortState | null) => void;
  cell: (row: T, column: ResolvedColumn) => ReactNode;
  rowLabel: (row: T) => string;
  selection?: GridSelection<T> | null;
  isEditable?: (row: T, column: string) => boolean;
  onEdit?: (row: T, column: string) => void;
  onActiveRow?: (row: T | null) => void;
  onOpen?: (row: T) => void;
  rowMenu?: (row: T) => MenuItem[];
  onToggleGroup?: (key: string) => void;
  /** Draft or submission marker of a row, keyed by business identity. */
  rowState?: (row: T) => string | null;
  initialScrollTop?: number;
  onScrollTop?: (top: number) => void;
  onRange?: (range: GridRange) => void;
  onScroller?: (element: HTMLDivElement | null) => void;
  handle?: Ref<GridHandle>;
  emptyText?: string;
}

function cellId(gridKey: string, rowId: string, column: string): string {
  return `${gridKey}-cell-${rowId}-${column}`.replaceAll(/[^A-Za-z0-9_-]/gu, '_');
}

/**
 * A grid that virtualizes both rows and columns. Only rows and scrolling columns near the viewport are
 * mounted, and their DOM nodes are reused for other records as the viewport moves (keyed by slot, not by
 * record). Business identity lives on `data-row-id`; nothing here keys state by row index or DOM node.
 */
export function VirtualGrid<T extends { id: string }>(props: VirtualGridProps<T>): ReactNode {
  const { gridId, gridKey, label, source, onColumnAction, sort, sortable, onSort, cell, rowLabel, selection = null, isEditable, onEdit, onActiveRow, onOpen, rowMenu, onToggleGroup, rowState } = props;
  const scroller = useRef<HTMLDivElement | null>(null);
  const [resizing, setResizing] = useState<{ column: string; width: number } | null>(null);
  const layout = resizing === null ? props.layout : applyColumnAction(gridId, props.layout, { kind: 'resize', column: resizing.column, width: resizing.width });
  const { pinned, scrolling } = visibleColumns(gridId, layout);
  const displayed = [...pinned, ...scrolling];
  const selectionWidth = selection === null ? 0 : SELECTION_WIDTH;
  const pinnedOffsets: number[] = [];
  let pinnedWidth = selectionWidth;
  for (const column of pinned) { pinnedOffsets.push(pinnedWidth); pinnedWidth += column.width; }

  const rows = useVirtualizer({
    count: source.length, getScrollElement: () => scroller.current, estimateSize: () => ROW_HEIGHT, overscan: 8,
    scrollMargin: HEADER_HEIGHT, scrollPaddingStart: HEADER_HEIGHT, initialOffset: props.initialScrollTop ?? 0,
  });
  const columns = useVirtualizer({
    horizontal: true, count: scrolling.length, getScrollElement: () => scroller.current, estimateSize: (index) => scrolling[index]?.width ?? 120,
    overscan: 2, paddingStart: pinnedWidth, scrollPaddingStart: pinnedWidth,
  });
  const widthKey = scrolling.map((column) => `${column.id}:${String(column.width)}`).join('|');
  useLayoutEffect(() => { columns.measure(); }, [columns, widthKey, pinnedWidth]);

  const virtualRows = rows.getVirtualItems();
  const virtualColumns = columns.getVirtualItems();
  const rowSlots = useRef(new Map<number, number>());
  rowSlots.current = assignSlots(rowSlots.current, virtualRows.map((item) => item.index));
  const columnSlots = useRef(new Map<number, number>());
  columnSlots.current = assignSlots(columnSlots.current, virtualColumns.map((item) => item.index));
  const totalWidth = Math.max(columns.getTotalSize(), pinnedWidth);

  const [active, setActive] = useState<{ index: number; rowId: string | null; column: string }>({ index: 0, rowId: null, column: displayed[0]?.id ?? '' });
  const [menu, setMenu] = useState<{ kind: 'row'; rowId: string; items: MenuItem[] } | { kind: 'column'; column: string } | null>(null);
  const [dragging, setDragging] = useState<string | null>(null);

  const first = virtualRows[0]?.index ?? 0;
  const last = virtualRows.at(-1)?.index ?? -1;
  useEffect(() => { if (last >= first) source.ensure(first, last); }, [source, first, last]);

  // Identity follows the record: after a sort or refresh the active row is found again by id.
  useEffect(() => {
    if (active.rowId === null) return;
    const entry = source.at(active.index);
    if (entry.kind === 'row' && entry.row.id === active.rowId) return;
    const moved = source.indexOf(active.rowId);
    if (moved !== undefined) setActive((previous) => ({ ...previous, index: moved }));
  }, [source, source.version, active.index, active.rowId]);

  const activeEntry = source.at(active.index);
  const activeRow = activeEntry.kind === 'row' && (active.rowId === null || activeEntry.row.id === active.rowId) ? activeEntry.row : null;
  useEffect(() => { onActiveRow?.(activeRow); }, [onActiveRow, activeRow]);
  useEffect(() => {
    if (active.rowId === null && activeEntry.kind === 'row') setActive((previous) => ({ ...previous, rowId: activeEntry.row.id }));
  }, [active.rowId, activeEntry]);
  const activeColumn = displayed.some((column) => column.id === active.column) ? active.column : displayed[0]?.id ?? '';

  const { onRange, onScrollTop } = props;
  const visibleCount = Math.max(1, Math.floor(((scroller.current?.clientHeight ?? 400) - HEADER_HEIGHT) / ROW_HEIGHT));
  const visibleFirst = Math.min(Math.max(0, Math.floor(rows.scrollOffset === null ? 0 : rows.scrollOffset / ROW_HEIGHT)), Math.max(0, source.length - 1));
  const visibleLast = Math.min(source.length - 1, visibleFirst + visibleCount - 1);
  useEffect(() => { onRange?.({ first: visibleFirst, last: visibleLast }); }, [onRange, visibleFirst, visibleLast]);

  const focusGrid = (): void => { scroller.current?.focus({ preventScroll: true }); };
  useImperativeHandle(props.handle, () => ({
    scrollToIndex(index) {
      const target = Math.max(0, Math.min(source.length - 1, index));
      rows.scrollToIndex(target, { align: 'center' });
      const entry = source.at(target);
      setActive((previous) => ({ ...previous, index: target, rowId: entry.kind === 'row' ? entry.row.id : null }));
    },
    focus: focusGrid,
  }), [rows, source]);

  const moveTo = (index: number, column = activeColumn): void => {
    const target = Math.max(0, Math.min(source.length - 1, index));
    const entry = source.at(target);
    setActive({ index: target, rowId: entry.kind === 'row' ? entry.row.id : null, column });
    rows.scrollToIndex(target, { align: 'auto' });
    const scrollingIndex = scrolling.findIndex((item) => item.id === column);
    if (scrollingIndex >= 0) columns.scrollToIndex(scrollingIndex, { align: 'auto' });
  };

  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>): void => {
    if (event.target !== event.currentTarget) return;
    const columnIndex = displayed.findIndex((column) => column.id === activeColumn);
    const entry = source.at(active.index);
    const row = entry.kind === 'row' ? entry.row : null;
    const handled = (): void => { event.preventDefault(); event.stopPropagation(); };
    if (event.altKey && event.shiftKey && (event.key === 'ArrowLeft' || event.key === 'ArrowRight')) {
      handled();
      onColumnAction({ kind: 'shift', column: activeColumn, delta: event.key === 'ArrowLeft' ? -1 : 1 });
      return;
    }
    switch (event.key) {
      case 'ArrowDown': handled(); moveTo(active.index + 1); return;
      case 'ArrowUp': handled(); moveTo(active.index - 1); return;
      case 'PageDown': handled(); moveTo(active.index + visibleCount); return;
      case 'PageUp': handled(); moveTo(active.index - visibleCount); return;
      case 'ArrowRight': handled(); moveTo(active.index, displayed[Math.min(displayed.length - 1, columnIndex + 1)]?.id); return;
      case 'ArrowLeft': handled(); moveTo(active.index, displayed[Math.max(0, columnIndex - 1)]?.id); return;
      case 'Home': handled(); if (event.ctrlKey || event.metaKey) moveTo(0); else moveTo(active.index, displayed[0]?.id); return;
      case 'End': handled(); if (event.ctrlKey || event.metaKey) moveTo(source.length - 1); else moveTo(active.index, displayed.at(-1)?.id); return;
      case 'Enter':
        handled();
        if (entry.kind === 'header') onToggleGroup?.(entry.key);
        else if (row !== null && isEditable?.(row, activeColumn) === true) onEdit?.(row, activeColumn);
        else if (row !== null) onOpen?.(row);
        return;
      case 'F2': if (row !== null && isEditable?.(row, activeColumn) === true) { handled(); onEdit?.(row, activeColumn); } return;
      case ' ': if (row !== null && selection !== null) { handled(); selection.toggle(row); } return;
      case 'ContextMenu': if (row !== null && rowMenu !== undefined) { handled(); setMenu({ kind: 'row', rowId: row.id, items: rowMenu(row) }); } return;
      case 'F10': if (event.shiftKey && row !== null && rowMenu !== undefined) { handled(); setMenu({ kind: 'row', rowId: row.id, items: rowMenu(row) }); } return;
      default:
    }
  };

  const startResize = (column: ResolvedColumn, clientX: number, element: HTMLElement, pointerId: number): void => {
    element.setPointerCapture(pointerId);
    const startWidth = column.width;
    let width = startWidth;
    const move = (event: PointerEvent): void => { width = startWidth + event.clientX - clientX; setResizing({ column: column.id, width }); };
    const up = (): void => {
      element.removeEventListener('pointermove', move);
      element.removeEventListener('pointerup', up);
      setResizing(null);
      if (width !== startWidth) onColumnAction({ kind: 'resize', column: column.id, width });
    };
    element.addEventListener('pointermove', move);
    element.addEventListener('pointerup', up);
  };

  const columnMenuItems = (column: string): MenuItem[] => {
    const spec = displayed.find((item) => item.id === column);
    if (spec === undefined) return [];
    const canSort = sortable(column);
    const section = spec.pinned ? pinned : scrolling;
    const position = section.findIndex((item) => item.id === column);
    return [
      { id: 'asc', label: 'Sort ascending', checked: sort?.field === column && sort.direction === 'asc', disabled: !canSort, ...(canSort ? {} : { disabledReason: 'This field cannot be sorted on the server.' }), onSelect: () => onSort({ field: column, direction: 'asc' }) },
      { id: 'desc', label: 'Sort descending', checked: sort?.field === column && sort.direction === 'desc', disabled: !canSort, onSelect: () => onSort({ field: column, direction: 'desc' }) },
      { id: 'pin', label: spec.pinned ? 'Unpin column' : 'Pin column to the left', section: 'Layout', onSelect: () => onColumnAction({ kind: 'togglePinned', column }) },
      { id: 'left', label: 'Move left', hint: 'Alt+Shift+←', disabled: position <= 0, onSelect: () => onColumnAction({ kind: 'shift', column, delta: -1 }) },
      { id: 'right', label: 'Move right', hint: 'Alt+Shift+→', disabled: position >= section.length - 1, onSelect: () => onColumnAction({ kind: 'shift', column, delta: 1 }) },
      { id: 'wider', label: 'Wider', onSelect: () => onColumnAction({ kind: 'resize', column, width: spec.width + 40 }) },
      { id: 'narrower', label: 'Narrower', onSelect: () => onColumnAction({ kind: 'resize', column, width: spec.width - 40 }) },
      { id: 'hide', label: 'Hide column', disabled: displayed.length <= 1, onSelect: () => onColumnAction({ kind: 'toggleHidden', column }) },
    ];
  };

  const headerCell = (column: ResolvedColumn, style: CSSProperties, slot: number | null, colIndex: number): ReactNode => {
    const direction = sort?.field === column.id ? sort.direction : null;
    const canSort = sortable(column.id);
    return (
      <div
        key={slot === null ? `p-${column.id}` : `s-${String(slot)}`}
        role="columnheader" aria-colindex={colIndex} aria-sort={direction === null ? 'none' : direction === 'asc' ? 'ascending' : 'descending'}
        data-header-col={column.id} className={`header-cell${column.pinned ? ' pinned' : ''}${dragging === column.id ? ' dragging' : ''}${column.align === 'end' ? ' end' : ''}`} style={style}
        draggable onDragStart={(event) => { event.dataTransfer.setData('text/x-column', column.id); event.dataTransfer.effectAllowed = 'move'; setDragging(column.id); }}
        onDragEnd={() => setDragging(null)}
        onDragOver={(event) => { if (event.dataTransfer.types.includes('text/x-column')) event.preventDefault(); }}
        onDrop={(event) => { event.preventDefault(); const moved = event.dataTransfer.getData('text/x-column'); setDragging(null); if (moved !== '' && moved !== column.id) onColumnAction({ kind: 'moveBefore', column: moved, before: column.id }); }}
      >
        <button
          type="button" className="header-label" tabIndex={-1} disabled={!canSort}
          title={canSort ? `Sort by ${column.label}` : `${column.label} (not sortable)`}
          onClick={() => onSort(direction === 'asc' ? { field: column.id, direction: 'desc' } : direction === 'desc' ? null : { field: column.id, direction: 'asc' })}
        >{column.label}{direction === null ? '' : direction === 'asc' ? ' ▲' : ' ▼'}</button>
        <button type="button" className="header-menu" tabIndex={-1} aria-label={`Column options for ${column.label}`} aria-haspopup="menu" onClick={() => setMenu({ kind: 'column', column: column.id })}>⋮</button>
        <div className="resize-handle" aria-hidden="true" onPointerDown={(event) => { event.preventDefault(); event.stopPropagation(); startResize(column, event.clientX, event.currentTarget, event.pointerId); }} />
      </div>
    );
  };

  const renderCell = (row: T, column: ResolvedColumn, style: CSSProperties, key: string, colIndex: number): ReactNode => {
    const isActive = active.rowId === row.id && activeColumn === column.id;
    const editable = isEditable?.(row, column.id) === true;
    return (
      <div
        key={key} role="gridcell" id={cellId(gridKey, row.id, column.id)} aria-colindex={colIndex} data-col={column.id}
        className={`cell${column.pinned ? ' pinned' : ''}${column.align === 'end' ? ' end' : ''}${isActive ? ' active' : ''}${editable ? ' editable' : ''}`} style={style}
        onMouseDown={() => { const index = source.indexOf(row.id); if (index !== undefined) setActive({ index, rowId: row.id, column: column.id }); }}
        onDoubleClick={() => { if (editable) onEdit?.(row, column.id); else onOpen?.(row); }}
      >{cell(row, column)}</div>
    );
  };

  const rowsHeight = rows.getTotalSize() - HEADER_HEIGHT;
  const activeCellId = activeRow !== null && virtualRows.some((item) => item.index === active.index) ? cellId(gridKey, activeRow.id, activeColumn) : undefined;
  return (
    <div className="grid-frame">
      <div
        ref={(element) => { scroller.current = element; props.onScroller?.(element); }}
        className="grid-scroller" role="grid" aria-label={label} aria-rowcount={source.length + 1} aria-colcount={displayed.length + (selection === null ? 0 : 1)}
        aria-multiselectable={selection === null ? undefined : true} tabIndex={0} data-grid-key={gridKey} data-pinned-width={pinnedWidth}
        aria-activedescendant={activeCellId}
        onKeyDown={onKeyDown} onScroll={(event) => onScrollTop?.(event.currentTarget.scrollTop)}
      >
        <div className="grid-header" role="row" aria-rowindex={1} style={{ width: totalWidth, height: HEADER_HEIGHT }}>
          {selection === null ? null : <div role="columnheader" aria-colindex={1} className="header-cell pinned selection-cell" style={{ left: 0, width: selectionWidth }}>{selection.header}</div>}
          {pinned.map((column, index) => headerCell(column, { left: pinnedOffsets[index], width: column.width }, null, index + 1 + (selection === null ? 0 : 1)))}
          {virtualColumns.map((item) => {
            const column = scrolling[item.index];
            return column === undefined ? null : headerCell(column, { position: 'absolute', left: item.start, width: item.size, top: 0 }, columnSlots.current.get(item.index) ?? item.index, pinned.length + item.index + 1 + (selection === null ? 0 : 1));
          })}
        </div>
        <div className="grid-body" style={{ height: Math.max(rowsHeight, 0), width: totalWidth }}>
          {source.length === 0 ? <div className="grid-empty">{props.emptyText ?? 'No records match.'}</div> : null}
          {virtualRows.map((item) => {
            const slot = rowSlots.current.get(item.index) ?? item.index;
            const entry = source.at(item.index);
            const style: CSSProperties = { top: item.start - HEADER_HEIGHT, width: totalWidth, height: ROW_HEIGHT };
            if (entry.kind === 'header') {
              return (
                <div key={`slot-${String(slot)}`} role="row" aria-rowindex={item.index + 2} aria-expanded={entry.expanded} data-group-key={entry.key} data-slot={slot} className="grid-row group-row" style={style}>
                  <div role="gridcell" className="cell pinned group-cell" style={{ left: 0 }}>
                    <button type="button" tabIndex={-1} className="group-toggle" aria-expanded={entry.expanded} onClick={() => onToggleGroup?.(entry.key)}>
                      {entry.expanded ? '▾' : '▸'} {entry.label} <span className="count">{entry.count.toLocaleString('en-US')}</span>
                    </button>
                  </div>
                </div>
              );
            }
            if (entry.kind === 'pending') {
              return (
                <div key={`slot-${String(slot)}`} role="row" aria-rowindex={item.index + 2} aria-busy="true" data-slot={slot} className="grid-row pending-row" style={style}>
                  <div role="gridcell" className="cell pinned" style={{ left: 0, width: pinnedWidth }}>Loading row {(item.index + 1).toLocaleString('en-US')}…</div>
                </div>
              );
            }
            const { row } = entry;
            const selected = selection?.isSelected(row.id) === true;
            const state = rowState?.(row) ?? null;
            return (
              <div
                key={`slot-${String(slot)}`} role="row" aria-rowindex={item.index + 2} aria-selected={selection === null ? undefined : selected}
                data-row-id={row.id} data-row-label={rowLabel(row)} data-slot={slot} data-row-state={state ?? undefined}
                className={`grid-row${selected ? ' selected' : ''}${active.rowId === row.id ? ' active-row' : ''}${state === null ? '' : ` state-${state}`}`} style={style}
                onContextMenu={(event) => { if (rowMenu !== undefined) { event.preventDefault(); setMenu({ kind: 'row', rowId: row.id, items: rowMenu(row) }); } }}
              >
                {selection === null ? null : (
                  <div role="gridcell" aria-colindex={1} className="cell pinned selection-cell" style={{ left: 0, width: selectionWidth }}>
                    <input type="checkbox" tabIndex={-1} checked={selected} aria-label={`Select ${rowLabel(row)}`} onChange={() => selection.toggle(row)} />
                    {rowMenu === undefined ? null : <button type="button" tabIndex={-1} className="row-menu-button" aria-label={`Actions for ${rowLabel(row)}`} aria-haspopup="menu" onClick={() => setMenu({ kind: 'row', rowId: row.id, items: rowMenu(row) })}>⋯</button>}
                    {state === null ? null : <span className={`row-marker ${state}`} title={`Unsaved change: ${state}`} aria-label={`Change ${state}`} />}
                  </div>
                )}
                {pinned.map((column, index) => renderCell(row, column, { left: pinnedOffsets[index], width: column.width }, `p-${column.id}`, index + 1 + (selection === null ? 0 : 1)))}
                {virtualColumns.map((columnItem) => {
                  const column = scrolling[columnItem.index];
                  return column === undefined ? null : renderCell(row, column, { position: 'absolute', left: columnItem.start, width: columnItem.size, top: 0 }, `s-${String(columnSlots.current.get(columnItem.index) ?? columnItem.index)}`, pinned.length + columnItem.index + 1 + (selection === null ? 0 : 1));
                })}
              </div>
            );
          })}
        </div>
      </div>
      {menu?.kind === 'row' ? (
        <AnchoredMenu
          label="Row actions" items={menu.items}
          anchor={() => scroller.current?.querySelector(`[data-row-id="${CSS.escape(menu.rowId)}"]`) ?? null}
          onClose={() => { setMenu(null); focusGrid(); }}
        />
      ) : null}
      {menu?.kind === 'column' ? (
        <AnchoredMenu
          label="Column options" items={columnMenuItems(menu.column)}
          anchor={() => scroller.current?.querySelector(`[data-header-col="${CSS.escape(menu.column)}"]`) ?? null}
          onClose={() => { setMenu(null); focusGrid(); }}
        />
      ) : null}
    </div>
  );
}
