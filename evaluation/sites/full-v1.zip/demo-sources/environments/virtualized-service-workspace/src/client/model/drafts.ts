import type { ServiceCommand } from '@computer-use/financial-database/services';

export type DraftRecordKind = 'member' | 'account';

/**
 * Lifecycle of an edit. `unknown` means a submission was sent but its outcome was not received; retrying
 * reuses the same idempotency keys, so a submission that did commit returns its stored receipt.
 */
export type DraftStatus =
  | { phase: 'draft' }
  | { phase: 'pending' }
  | { phase: 'unknown'; message: string }
  | { phase: 'rejected'; code: string; message: string; field: string | null; currentVersion: number | null }
  | { phase: 'committed'; receiptNumber: string };

export interface Draft {
  key: string;
  /** Institution whose backend receives the commands. */
  institutionId: string;
  kind: DraftRecordKind;
  recordId: string;
  /** Business number shown to people, for example AC0001234. */
  label: string;
  /** Record version the edit was made against; commands carry it for stale-edit detection. */
  baseVersion: number;
  /** Edited fields by grid column id, as entered. */
  fields: Readonly<Record<string, string>>;
  /** Stored values when editing began, for display and cancellation. */
  original: Readonly<Record<string, string>>;
  status: DraftStatus;
  receipts: readonly string[];
  /** Idempotency key prefix of the submission in flight or with an unknown outcome. */
  attempt: string | null;
}

export type Drafts = ReadonlyMap<string, Draft>;

export type DraftAction =
  | { type: 'edit'; institutionId: string; kind: DraftRecordKind; recordId: string; label: string; version: number; field: string; value: string; original: string }
  | { type: 'discardField'; key: string; field: string }
  | { type: 'discard'; key: string }
  | { type: 'submit'; key: string; attempt: string }
  | { type: 'committed'; key: string; fields: readonly string[]; receiptNumber: string; version: number }
  | { type: 'unchanged'; key: string; fields: readonly string[] }
  | { type: 'rejected'; key: string; code: string; message: string; field: string | null; currentVersion: number | null }
  | { type: 'interrupted'; key: string; message: string }
  | { type: 'rebase'; key: string; version: number; original: Readonly<Record<string, string>> }
  | { type: 'acknowledge'; key: string }
  | { type: 'restore'; drafts: readonly Draft[] };

export const EDITABLE_FIELDS: Readonly<Record<DraftRecordKind, readonly string[]>> = {
  account: ['nickname', 'statement_delivery'],
  member: ['email', 'phone'],
};

export function draftKey(institutionId: string, kind: DraftRecordKind, recordId: string): string {
  return `${institutionId}/${kind}:${recordId}`;
}

const editable = (status: DraftStatus): boolean => status.phase === 'draft' || status.phase === 'rejected' || status.phase === 'committed';

function withFields(draft: Draft, fields: Record<string, string>, original: Record<string, string>): Draft | null {
  return Object.keys(fields).length === 0 ? null : { ...draft, fields, original };
}

function without(values: Readonly<Record<string, string>>, keys: readonly string[]): Record<string, string> {
  return Object.fromEntries(Object.entries(values).filter(([key]) => !keys.includes(key)));
}

function put(state: Drafts, key: string, draft: Draft | null): Map<string, Draft> {
  const next = new Map(state);
  if (draft === null) next.delete(key); else next.set(key, draft);
  return next;
}

export function draftsReducer(state: Drafts, action: DraftAction): Drafts {
  if (action.type === 'restore') {
    return new Map(action.drafts.map((draft) => [draft.key, draft.status.phase === 'pending' ? { ...draft, status: { phase: 'unknown', message: 'The page reloaded before the save finished. Check the record or activity, then retry; a retry cannot apply the change twice.' } } : draft]));
  }
  if (action.type === 'edit') {
    const key = draftKey(action.institutionId, action.kind, action.recordId);
    const existing = state.get(key);
    if (existing !== undefined && !editable(existing.status)) return state;
    const fresh = existing === undefined || existing.status.phase === 'committed';
    const base: Draft = fresh
      ? { key, institutionId: action.institutionId, kind: action.kind, recordId: action.recordId, label: action.label, baseVersion: action.version, fields: {}, original: {}, status: { phase: 'draft' }, receipts: [], attempt: null }
      : existing;
    const before = base.original[action.field] ?? action.original;
    const fields = action.value === before ? without(base.fields, [action.field]) : { ...base.fields, [action.field]: action.value };
    const original = action.value === before ? without(base.original, [action.field]) : { ...base.original, [action.field]: before };
    const next = withFields({ ...base, status: { phase: 'draft' }, attempt: null }, fields, original);
    return put(state, key, next);
  }
  const draft = state.get(action.key);
  if (draft === undefined) return state;
  switch (action.type) {
    case 'discard':
    case 'acknowledge':
      return draft.status.phase === 'pending' ? state : put(state, action.key, null);
    case 'discardField': {
      if (!editable(draft.status)) return state;
      return put(state, action.key, withFields(draft, without(draft.fields, [action.field]), without(draft.original, [action.field])));
    }
    case 'submit':
      if (draft.status.phase !== 'draft' && draft.status.phase !== 'rejected' && draft.status.phase !== 'unknown') return state;
      return put(state, action.key, { ...draft, status: { phase: 'pending' }, attempt: draft.status.phase === 'unknown' && draft.attempt !== null ? draft.attempt : action.attempt });
    case 'committed':
    case 'unchanged': {
      const fields = without(draft.fields, action.fields);
      const original = without(draft.original, action.fields);
      const receipts = action.type === 'committed' ? [...draft.receipts, action.receiptNumber] : draft.receipts;
      const version = action.type === 'committed' ? action.version : draft.baseVersion;
      if (Object.keys(fields).length > 0) return put(state, action.key, { ...draft, fields, original, receipts, baseVersion: version });
      const last = receipts.at(-1);
      return put(state, action.key, last === undefined ? null : { ...draft, fields, original, receipts, baseVersion: version, status: { phase: 'committed', receiptNumber: last }, attempt: null });
    }
    case 'rejected':
      return put(state, action.key, { ...draft, status: { phase: 'rejected', code: action.code, message: action.message, field: action.field, currentVersion: action.currentVersion }, attempt: null });
    case 'interrupted':
      return put(state, action.key, { ...draft, status: { phase: 'unknown', message: action.message } });
    case 'rebase':
      return put(state, action.key, { ...draft, baseVersion: action.version, original: { ...draft.original, ...action.original }, status: { phase: 'draft' }, attempt: null });
  }
}

export interface DraftCommand {
  fields: readonly string[];
  command: ServiceCommand;
}

/**
 * Shared commands that apply a draft, in submission order. Each command after the first expects the
 * version the previous one produces, because every committed record command bumps it by one.
 */
export function draftCommands(draft: Draft): DraftCommand[] {
  const version = draft.baseVersion;
  if (draft.kind === 'member') {
    const fields = Object.keys(draft.fields).filter((field) => field === 'email' || field === 'phone');
    if (fields.length === 0) return [];
    const value = (field: string): string | null => { const text = (draft.fields[field] ?? '').trim(); return text === '' ? null : text; };
    return [{ fields, command: { kind: 'contact.update', memberId: draft.recordId, expectedVersion: version, ...(fields.includes('email') ? { email: value('email') } : {}), ...(fields.includes('phone') ? { phone: value('phone') } : {}) } }];
  }
  const commands: DraftCommand[] = [];
  const nickname = draft.fields.nickname;
  if (nickname !== undefined) commands.push({ fields: ['nickname'], command: { kind: 'account.nickname.update', accountId: draft.recordId, expectedVersion: version + commands.length, nickname } });
  const delivery = draft.fields.statement_delivery;
  if (delivery === 'paper' || delivery === 'electronic') {
    commands.push({ fields: ['statement_delivery'], command: { kind: 'account.statement_delivery.update', accountId: draft.recordId, expectedVersion: version + commands.length, statementDelivery: delivery } });
  }
  return commands;
}
