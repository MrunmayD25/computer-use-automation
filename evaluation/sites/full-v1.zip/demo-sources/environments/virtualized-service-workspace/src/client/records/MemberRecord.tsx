import type { MemberDetail } from '@computer-use/financial-database/services';
import type { ReactNode } from 'react';

import { institutionPath } from '../api.js';
import { formatDate, formatInstant, formatMoney, label } from '../format.js';
import { draftKey } from '../model/drafts.js';
import { tabKeyOf, useShell } from '../shell.js';
import { useResource } from '../useResource.js';
import { useWorkspace } from '../workspace.js';
import { ActivityPanel, Panel, ScopedRecords, useOpenOperation, usePublishContext, useRecordRefresh } from './common.js';

export function MemberRecord({ id }: { id: string }): ReactNode {
  const { institution, can, drafts } = useWorkspace();
  const { openRecord, openDialog } = useShell();
  const openOperation = useOpenOperation();
  const institutionId = institution.institutionId;
  const refresh = useRecordRefresh('members', id);
  const { data, error } = useResource<MemberDetail>(institutionPath(institutionId, `/members/${encodeURIComponent(id)}`), refresh);
  usePublishContext(tabKeyOf(institutionId, 'member', id), data === undefined ? null : { title: data.member.memberNumber, member: { id, number: data.member.memberNumber, name: data.member.displayName }, account: null });
  if (data === undefined) return <div className="record-loading">{error ?? 'Loading member…'}</div>;
  const { member } = data;
  const ref = { id: member.id, memberNumber: member.memberNumber, displayName: member.displayName };
  const draft = drafts.get(draftKey(institutionId, 'member', id));
  const merged = member.status === 'merged';
  return (
    <article className="record" data-record-kind="member" data-record-id={id} data-record-version={member.version}>
      <header className="record-header">
        <div>
          <h2>{member.displayName} <code>{member.memberNumber}</code></h2>
          <p className="muted"><span className={`badge status-${member.status}`}>{label(member.status)}</span> {label(member.kind)} · joined {formatDate(member.joinedAt)} · version {member.version}</p>
        </div>
        <div className="button-row">
          <button type="button" disabled={merged || !can('contact.update')} onClick={() => openDialog({ kind: 'contact.update', member: data })}>Edit contact…</button>
          <button type="button" disabled={!can('member.note.add')} onClick={() => openDialog({ kind: 'note', owner: { kind: 'member', id, label: member.memberNumber } })}>Add note…</button>
          <button type="button" disabled={merged || !can('account.open')} onClick={() => openDialog({ kind: 'account.open', member: ref })}>Open account…</button>
          <button type="button" disabled={!can('case.open')} onClick={() => openDialog({ kind: 'case.open', member: ref, accountId: null })}>New case…</button>
        </div>
        <div className="button-row secondary-actions" aria-label="Member operations">
          <button type="button" disabled={merged || !can('member.identity_evidence.register')} onClick={() => openOperation('member.identity_evidence.register', { memberId: id })}>Register evidence…</button>
          <button type="button" disabled={merged || !can('member.identity.verify')} onClick={() => openOperation('member.identity.verify', { memberId: id })}>Verify identity…</button>
          <button type="button" disabled={merged || !can('member.legal_name.update')} onClick={() => openOperation('member.legal_name.update', { memberId: id, expectedVersion: member.version })}>Legal name…</button>
          <button type="button" disabled={merged || !can('member.preferred_name.update')} onClick={() => openOperation('member.preferred_name.update', { memberId: id, expectedVersion: member.version })}>Preferred name…</button>
          <button type="button" disabled={merged || !can('member.deceased.record')} onClick={() => openOperation('member.deceased.record', { memberId: id, expectedVersion: member.version })}>Record deceased…</button>
          <button type="button" disabled={merged || !can('member.tax_classification.update')} onClick={() => openOperation('member.tax_classification.update', { memberId: id, expectedVersion: member.version })}>Tax classification…</button>
          {member.kind !== 'organization' ? null : <button type="button" disabled={merged || !can('member.beneficial_owners.update')} onClick={() => openOperation('member.beneficial_owners.update', { organizationMemberId: id, expectedVersion: member.version })}>Beneficial owners…</button>}
          <button type="button" disabled={merged || !can('beneficiary.create')} onClick={() => openOperation('beneficiary.create', { memberId: id, expectedMemberVersion: member.version })}>New beneficiary…</button>
          <button type="button" disabled={merged || !can('loan.application.prepare')} onClick={() => openOperation('loan.application.prepare', { memberId: id, expectedMemberVersion: member.version })}>Loan application…</button>
          <button type="button" disabled={merged || !can('consent.delivery.record')} onClick={() => openOperation('consent.delivery.record', { memberId: id })}>Record consent…</button>
          <button type="button" disabled={merged || !can('communication.preference.update')} onClick={() => openOperation('communication.preference.update', { memberId: id })}>Communication preference…</button>
          <button type="button" disabled={merged || !can('communication.send')} onClick={() => openOperation('communication.send', { memberId: id })}>Send communication…</button>
          <button type="button" disabled={merged || !can('document.index')} onClick={() => openOperation('document.index', { memberId: id, ownerPartyId: member.partyId })}>Index document…</button>
          <button type="button" disabled={merged || !can('document.bundle.redact')} onClick={() => openOperation('document.bundle.redact', { memberId: id })}>Redacted bundle…</button>
          <button type="button" disabled={merged || !can('document.customer_export.create')} onClick={() => openOperation('document.customer_export.create', { memberId: id })}>Customer export…</button>
          <button type="button" disabled={merged || !can('maintenance.address.reconcile')} onClick={() => openOperation('maintenance.address.reconcile', { memberId: id, expectedMemberVersion: member.version })}>Reconcile address…</button>
          <button type="button" disabled={merged || !can('maintenance.address.destination.update')} onClick={() => openOperation('maintenance.address.destination.update', { memberId: id })}>Address destination…</button>
          <button type="button" disabled={merged || !can('maintenance.draft.save')} onClick={() => openOperation('maintenance.draft.save', { memberId: id })}>Maintenance draft…</button>
          <button type="button" disabled={merged || !can('member.merge')} onClick={() => openOperation('member.merge', {})}>Merge member…</button>
        </div>
      </header>
      {data.redirectTo === null ? null : <p className="warning">This member was merged into <button type="button" className="link" onClick={() => { if (data.redirectTo !== null) openRecord('member', data.redirectTo.memberId); }}>{data.redirectTo.memberNumber}</button>.</p>}
      {draft === undefined ? null : <p className="notice">Unsaved contact change ({draft.status.phase}): {Object.entries(draft.fields).map(([field, value]) => `${field} → ${value === '' ? '(cleared)' : value}`).join('; ')}. Review it in Changes.</p>}
      <div className="record-panels">
        <Panel title="Profile and contact">
          <dl className="facts">
            {data.person === null ? null : <><dt>Legal name</dt><dd>{data.person.legalGiven} {data.person.legalFamily}</dd><dt>Preferred</dt><dd>{data.person.preferredName ?? '—'}</dd><dt>Born</dt><dd>{data.person.birthDate}</dd></>}
            {data.organization === null ? null : <><dt>Organization</dt><dd>{data.organization.legalName} ({data.organization.organizationType})</dd><dt>Registration</dt><dd>{data.organization.registrationNumber}</dd></>}
            <dt>Email</dt><dd data-field="email">{data.email?.value ?? '—'}{data.email?.verifiedAt == null ? '' : ' (verified)'}</dd>
            <dt>Phone</dt><dd data-field="phone">{data.phone?.value ?? '—'}</dd>
            <dt>Address</dt><dd>{data.address === null ? '—' : <>{data.address.line1}{data.address.line2 === null ? '' : `, ${data.address.line2}`}<br />{data.address.city}, {data.address.region} {data.address.postalCode} {data.address.country} <span className="muted">({data.address.evidenceStatus})</span></>}</dd>
            <dt>Tax</dt><dd>{member.taxClassification}</dd>
          </dl>
        </Panel>
        <Panel title={`Accounts (${String(data.accounts.length)})`}>
          <table className="plain clickable">
            <thead><tr><th>Account</th><th>Product</th><th>Status</th><th className="end">Available</th></tr></thead>
            <tbody>
              {data.accounts.map((account) => (
                <tr key={account.id} tabIndex={0} onClick={() => openRecord('account', account.id)} onKeyDown={(event) => { if (event.key === 'Enter') openRecord('account', account.id); }}>
                  <td><code>{account.accountNumber}</code>{account.nickname === '' ? '' : ` · ${account.nickname}`}</td><td>{account.productName}</td>
                  <td>{label(account.status)}</td><td className="money end">{formatMoney(account.availableMinorUnits, account.currency, account.exponent)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
        <Panel title={`Service cases (${String(data.cases.length)})`}>
          <table className="plain clickable">
            <thead><tr><th>Case</th><th>Status</th><th>Summary</th><th>Due</th></tr></thead>
            <tbody>
              {data.cases.map((record) => (
                <tr key={record.id} tabIndex={0} onClick={() => openRecord('case', record.id)} onKeyDown={(event) => { if (event.key === 'Enter') openRecord('case', record.id); }}>
                  <td><code>{record.caseNumber}</code></td><td>{label(record.state)}</td><td>{record.summary}</td><td>{formatDate(record.dueAt)}{record.overdue ? ' ⚠' : ''}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
        <Panel title={`Notes (${String(data.notes.length)})`}>
          <ul className="notes">{data.notes.map((note) => <li key={note.id}><p>{note.text}</p><span className="muted">{formatInstant(note.createdAt)} · {note.actor?.displayName ?? 'System'} · {note.visibility}</span></li>)}</ul>
        </Panel>
        <ScopedRecords resource="identity-evidence" scope={{ memberId: id }} title="Identity evidence" />
        <ScopedRecords resource="name-history" scope={{ memberId: id }} title="Name history" />
        <ScopedRecords resource="tax-history" scope={{ memberId: id }} title="Tax history" />
        <ScopedRecords resource="consent" scope={{ memberId: id }} title="Consents" />
        <ScopedRecords resource="beneficiary" scope={{ memberId: id }} title="Beneficiaries" />
        <ScopedRecords resource="payment" scope={{ memberId: id }} title="Payments" />
        <ScopedRecords resource="card" scope={{ memberId: id }} title="Cards" />
        <ScopedRecords resource="loan" scope={{ memberId: id }} title="Loans" />
        <ScopedRecords resource="dispute" scope={{ memberId: id }} title="Disputes" />
        <ScopedRecords resource="document-version" scope={{ memberId: id }} title="Documents" />
        <ScopedRecords resource="maintenance-request" scope={{ memberId: id }} title="Maintenance requests" />
        <ScopedRecords resource="communication-job" scope={{ memberId: id }} title="Communications" />
        <ScopedRecords resource="merge-plan" scope={{ memberId: id }} title="Merge plans" />
        <ActivityPanel scope={{ memberId: id }} gridKey={`member-activity-${id}`} />
      </div>
    </article>
  );
}
