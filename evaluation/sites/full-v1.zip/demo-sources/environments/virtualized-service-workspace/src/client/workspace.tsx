import type { CommandKind, Receipt, RecordStamp, ReferenceData, StampResponse } from '@computer-use/financial-database/services';
import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState, type Dispatch, type ReactNode } from 'react';

import type { InstitutionInfo, OperatorInstitutionProfile, SessionInfo } from '../shared/api.js';
import { ApiError, executeCommand, getJson, institutionPath, isNetworkFailure, newIdempotencyKey, sendJson } from './api.js';
import { draftCommands, draftsReducer, type Draft, type DraftAction, type Drafts } from './model/drafts.js';

export type StampKind = keyof StampResponse;
export type NoticeTone = 'info' | 'success' | 'error';

export interface Notice {
  id: number;
  tone: NoticeTone;
  text: string;
  receiptNumber?: string;
}

interface WorkspaceValue {
  session: SessionInfo;
  institution: InstitutionInfo;
  profile: OperatorInstitutionProfile | null;
  reference: ReferenceData | null;
  /** Whether the signed-on operator holds a grant for the command here. The backend decides again on every write. */
  can: (kind: CommandKind) => boolean;
  drafts: Drafts;
  dispatchDrafts: Dispatch<DraftAction>;
  saveDraft: (key: string) => Promise<void>;
  /** Moves a rejected or stale draft onto the record's current version, keeping the operator's values. */
  rebaseDraft: (key: string) => Promise<void>;
  notices: readonly Notice[];
  notify: (tone: NoticeTone, text: string, receiptNumber?: string) => void;
  /** Increments after every commit made here, so visible lists and records reload. */
  dataVersion: number;
  committed: (receipt: Receipt | undefined, text: string) => void;
  /** Latest version and change stamp of watched records, keyed `kind:id`. */
  stamps: ReadonlyMap<string, RecordStamp | null>;
  watch: (kind: StampKind, id: string) => () => void;
  switchOperator: (actorNumber: string) => Promise<void>;
}

const WorkspaceContext = createContext<WorkspaceValue | null>(null);

export function useWorkspace(): WorkspaceValue {
  const value = useContext(WorkspaceContext);
  if (value === null) throw new Error('useWorkspace is used outside the workspace provider.');
  return value;
}

const DRAFT_STORAGE = 'vsw:drafts:v1';
const STAMP_INTERVAL_MS = 5_000;
const MAX_STAMPS_PER_KIND = 100;

function storedDrafts(): Drafts {
  try {
    const raw = sessionStorage.getItem(DRAFT_STORAGE);
    const drafts = raw === null ? [] : JSON.parse(raw) as Draft[];
    return draftsReducer(new Map(), { type: 'restore', drafts: Array.isArray(drafts) ? drafts : [] });
  } catch {
    return new Map();
  }
}

interface ProviderProps {
  session: SessionInfo;
  institutionId: string;
  onSessionChange: (session: SessionInfo) => void;
  children: ReactNode;
}

export function WorkspaceProvider({ session, institutionId, onSessionChange, children }: ProviderProps): ReactNode {
  const institution = session.institutions.find((item) => item.institutionId === institutionId) ?? session.institutions[0];
  if (institution === undefined) throw new Error('The workspace has no institutions.');
  const profile = session.operator.profiles[institution.institutionId] ?? null;
  const [reference, setReference] = useState<ReferenceData | null>(null);
  const [drafts, dispatchDrafts] = useReducer(draftsReducer, undefined, storedDrafts);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [dataVersion, setDataVersion] = useState(0);
  const [stamps, setStamps] = useState<ReadonlyMap<string, RecordStamp | null>>(new Map());
  const watched = useRef(new Map<string, number>());
  const draftsRef = useRef(drafts);
  const noticeId = useRef(0);

  useEffect(() => { draftsRef.current = drafts; sessionStorage.setItem(DRAFT_STORAGE, JSON.stringify([...drafts.values()])); }, [drafts]);

  useEffect(() => {
    let live = true;
    setReference(null);
    getJson<ReferenceData>(institutionPath(institution.institutionId, '/reference')).then((data) => { if (live) setReference(data); }, () => undefined);
    return () => { live = false; };
  }, [institution.institutionId]);

  const notify = useCallback((tone: NoticeTone, text: string, receiptNumber?: string) => {
    noticeId.current += 1;
    const notice: Notice = { id: noticeId.current, tone, text, ...(receiptNumber === undefined ? {} : { receiptNumber }) };
    setNotices((previous) => [notice, ...previous].slice(0, 20));
  }, []);

  const committed = useCallback((receipt: Receipt | undefined, text: string) => {
    setDataVersion((value) => value + 1);
    notify('success', text, receipt?.receiptNumber);
  }, [notify]);

  const watch = useCallback((kind: StampKind, id: string) => {
    const key = `${kind}:${id}`;
    watched.current.set(key, (watched.current.get(key) ?? 0) + 1);
    return () => {
      const count = (watched.current.get(key) ?? 1) - 1;
      if (count <= 0) watched.current.delete(key); else watched.current.set(key, count);
    };
  }, []);

  useEffect(() => {
    let live = true;
    const poll = async (): Promise<void> => {
      if (document.visibilityState !== 'visible' || watched.current.size === 0) return;
      const request: Record<StampKind, string[]> = { members: [], accounts: [], cases: [] };
      for (const key of watched.current.keys()) {
        const [kind, id] = key.split(/:(.*)/su) as [StampKind, string];
        if (request[kind].length < MAX_STAMPS_PER_KIND) request[kind].push(id);
      }
      try {
        const response = await sendJson<StampResponse>('POST', institutionPath(institution.institutionId, '/stamps'), request);
        if (!live) return;
        setStamps((previous) => {
          let changed = false;
          const next = new Map(previous);
          for (const kind of ['members', 'accounts', 'cases'] as const) {
            for (const [id, stamp] of Object.entries(response[kind])) {
              const key = `${kind}:${id}`;
              if (previous.get(key)?.stamp !== stamp?.stamp || !previous.has(key)) { next.set(key, stamp); changed = true; }
            }
          }
          return changed ? next : previous;
        });
      } catch {
        // Polling resumes on the next tick; a failed poll only delays change detection.
      }
    };
    const timer = setInterval(() => { void poll(); }, STAMP_INTERVAL_MS);
    const first = setTimeout(() => { void poll(); }, 300);
    return () => { live = false; clearInterval(timer); clearTimeout(first); };
  }, [institution.institutionId]);

  const saveDraft = useCallback(async (key: string) => {
    const draft = draftsRef.current.get(key);
    if (draft === undefined) return;
    if (draft.status.phase !== 'draft' && draft.status.phase !== 'rejected' && draft.status.phase !== 'unknown') return;
    const attempt = draft.status.phase === 'unknown' && draft.attempt !== null ? draft.attempt : newIdempotencyKey('draft');
    dispatchDrafts({ type: 'submit', key, attempt });
    const commands = draftCommands(draft);
    let lastReceipt: Receipt | undefined;
    try {
      for (const [index, { fields, command }] of commands.entries()) {
        const outcome = await executeCommand(draft.institutionId, command, `${attempt}.${String(index)}`);
        if (outcome.kind === 'committed' || outcome.kind === 'duplicate') {
          lastReceipt = outcome.receipt;
          const expected = 'expectedVersion' in command ? command.expectedVersion : draft.baseVersion;
          dispatchDrafts({ type: 'committed', key, fields, receiptNumber: outcome.receipt.receiptNumber, version: expected + 1 });
        } else if (outcome.kind === 'unchanged') {
          dispatchDrafts({ type: 'unchanged', key, fields });
        } else {
          dispatchDrafts({ type: 'rejected', key, code: outcome.code, message: outcome.message, field: outcome.field ?? null, currentVersion: outcome.currentVersion ?? null });
          notify('error', `${draft.label}: ${outcome.message}`);
          if (lastReceipt !== undefined) setDataVersion((value) => value + 1);
          return;
        }
      }
      committed(lastReceipt, lastReceipt === undefined ? `${draft.label}: nothing to change.` : `${draft.label} saved.`);
    } catch (error) {
      if (isNetworkFailure(error)) {
        dispatchDrafts({ type: 'interrupted', key, message: 'The save did not get a response. Retry to finish it; a retry cannot apply the change twice.' });
        notify('error', `${draft.label}: the save outcome is unknown. Retry from Changes.`);
      } else {
        const message = error instanceof Error ? error.message : String(error);
        dispatchDrafts({ type: 'rejected', key, code: error instanceof ApiError ? error.code : 'error', message, field: error instanceof ApiError ? error.field ?? null : null, currentVersion: null });
        notify('error', `${draft.label}: ${message}`);
      }
    }
  }, [committed, notify]);

  const rebaseDraft = useCallback(async (key: string) => {
    const draft = draftsRef.current.get(key);
    if (draft === undefined) return;
    try {
      if (draft.kind === 'account') {
        const detail = await getJson<{ account: { version: number; nickname: string; statementDelivery: string } }>(institutionPath(draft.institutionId, `/accounts/${encodeURIComponent(draft.recordId)}`));
        dispatchDrafts({ type: 'rebase', key, version: detail.account.version, original: { nickname: detail.account.nickname, statement_delivery: detail.account.statementDelivery } });
      } else {
        const detail = await getJson<{ member: { version: number; email: string | null; phone: string | null } }>(institutionPath(draft.institutionId, `/members/${encodeURIComponent(draft.recordId)}`));
        dispatchDrafts({ type: 'rebase', key, version: detail.member.version, original: { email: detail.member.email ?? '', phone: detail.member.phone ?? '' } });
      }
    } catch (error) {
      notify('error', `${draft.label}: could not load the current record. ${error instanceof Error ? error.message : ''}`);
    }
  }, [notify]);

  const switchOperator = useCallback(async (actorNumber: string) => {
    await sendJson('POST', '/api/session/operator', { actorNumber });
    onSessionChange(await getJson<SessionInfo>('/api/session'));
    setDataVersion((value) => value + 1);
  }, [onSessionChange]);

  const can = useCallback((kind: CommandKind) => profile?.commands.includes(kind) === true, [profile]);

  const value = useMemo<WorkspaceValue>(() => ({
    session, institution, profile, reference, can, drafts, dispatchDrafts, saveDraft, rebaseDraft, notices, notify, dataVersion, committed, stamps, watch, switchOperator,
  }), [session, institution, profile, reference, can, drafts, saveDraft, rebaseDraft, notices, notify, dataVersion, committed, stamps, watch, switchOperator]);
  return <WorkspaceContext value={value}>{children}</WorkspaceContext>;
}

/** Watches a record's change stamp while the caller is mounted and returns the latest one seen. */
export function useStamp(kind: StampKind, id: string | null): RecordStamp | null | undefined {
  const { watch, stamps } = useWorkspace();
  useEffect(() => (id === null ? undefined : watch(kind, id)), [watch, kind, id]);
  return id === null ? undefined : stamps.get(`${kind}:${id}`);
}
