/**
 * Assigns render slots to the item indices currently in the viewport. An index that stays in range keeps
 * its slot; a slot freed by an index that left is handed to an index that entered. Rendering keyed by slot
 * therefore reuses the same DOM node for a different record as the viewport moves, the way recycling grids
 * do, so nothing may treat a node or its index as the record's identity.
 *
 * The function is idempotent for an unchanged range, which keeps it safe to call during render.
 */
export function assignSlots(previous: ReadonlyMap<number, number>, indices: readonly number[]): Map<number, number> {
  const next = new Map<number, number>();
  const wanted = new Set(indices);
  const free: number[] = [];
  for (const [index, slot] of previous) {
    if (wanted.has(index)) next.set(index, slot);
    else free.push(slot);
  }
  free.sort((a, b) => a - b);
  let fresh = previous.size === 0 ? 0 : Math.max(...previous.values()) + 1;
  for (const index of indices) {
    if (next.has(index)) continue;
    const slot = free.shift() ?? fresh++;
    next.set(index, slot);
  }
  return next;
}
