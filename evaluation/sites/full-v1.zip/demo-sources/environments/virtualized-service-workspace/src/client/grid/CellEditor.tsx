import { FloatingPortal, autoUpdate, useFloating, type Middleware } from '@floating-ui/react';
import { useCallback, useId, useLayoutEffect, useMemo, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';

import { HEADER_HEIGHT } from './VirtualGrid.js';

export type AnchorState = 'visible' | 'scrolled' | 'absent';

export interface EditTarget {
  rowId: string;
  column: string;
  /** Business number of the record, for example AC0001234. */
  label: string;
  columnLabel: string;
  kind: 'text' | 'delivery';
  /** Value when the editor opened: the draft value if one existed, otherwise the stored value. */
  value: string;
}

interface CellEditorProps {
  target: EditTarget;
  gridKey: string;
  scroller: HTMLElement | null;
  /** Writes the value into the record's draft; the draft outlives the editor and any row node. */
  onChange: (value: string) => void;
  /** Closes the editor and keeps the draft. `save` also submits it. */
  onClose: (then: 'keep' | 'save') => void;
  /** Restores the value the field had when the editor opened, then closes. */
  onCancel: () => void;
  /** Scrolls the grid to the record, or null when the record is not in the current results. */
  onScrollTo: (() => void) | null;
  status: string | null;
}

const DELIVERY = [{ value: 'electronic', label: 'Electronic' }, { value: 'paper', label: 'Paper' }] as const;

function findAnchor(scroller: HTMLElement | null, rowId: string, column: string): Element | null {
  return scroller?.querySelector(`[data-row-id="${CSS.escape(rowId)}"] [data-col="${CSS.escape(column)}"]`) ?? null;
}

/**
 * Inline editor rendered in a portal outside the grid. It anchors to its cell by business identity on every
 * frame, so it follows the record through scrolling, sorting and recycling. When the cell is not visible (it
 * scrolled away, moved, or left the results) the editor docks at the bottom of the grid with explicit
 * choices instead of attaching to whichever record now occupies the old row node.
 */
export function CellEditor({ target, gridKey, scroller, onChange, onClose, onCancel, onScrollTo, status }: CellEditorProps): ReactNode {
  const [value, setValue] = useState(target.value);
  const anchorState = useRef<AnchorState>('absent');
  const scrollerRef = useRef(scroller);
  useLayoutEffect(() => { scrollerRef.current = scroller; }, [scroller]);
  const reference = useMemo(() => ({
    getBoundingClientRect(): DOMRect {
      const container = scrollerRef.current;
      const anchor = findAnchor(container, target.rowId, target.column);
      if (container === null || anchor === null) { anchorState.current = 'absent'; return container?.getBoundingClientRect() ?? new DOMRect(); }
      const box = container.getBoundingClientRect();
      const rect = anchor.getBoundingClientRect();
      const pinnedWidth = Number(container.dataset.pinnedWidth ?? 0);
      const pinned = anchor.classList.contains('pinned');
      const inside = rect.top >= box.top + HEADER_HEIGHT - 1 && rect.bottom <= box.top + container.clientHeight + 1
        && (pinned || (rect.left >= box.left + pinnedWidth - 1 && rect.right <= box.left + container.clientWidth + 1));
      anchorState.current = inside ? 'visible' : 'scrolled';
      return rect;
    },
  }), [target.rowId, target.column]);
  const dock = useMemo<Middleware>(() => ({
    name: 'dock',
    fn({ rects }) {
      const state = anchorState.current;
      if (state === 'visible') return { data: { state, width: Math.max(rects.reference.width, 220) } };
      const box = scrollerRef.current?.getBoundingClientRect() ?? new DOMRect(8, window.innerHeight - 8, 0, 0);
      return { x: box.left + 12, y: Math.max(8, box.bottom - rects.floating.height - 12), data: { state, width: 420 } };
    },
  }), []);
  const { refs, floatingStyles, middlewareData } = useFloating({
    strategy: 'fixed', placement: 'bottom-start', middleware: [dock],
    whileElementsMounted: (referenceElement, floating, update) => autoUpdate(referenceElement, floating, update, { animationFrame: true }),
  });
  useLayoutEffect(() => { refs.setPositionReference(reference); }, [refs, reference]);
  const data = middlewareData.dock as { state: AnchorState; width: number } | undefined;
  const state = data?.state ?? 'visible';

  // The portal mounts its children after this component's effects run, so focus is taken when the node attaches.
  const focusOnAttach = useCallback((node: HTMLElement | null) => { node?.focus(); }, []);

  const change = (next: string): void => { setValue(next); onChange(next); };
  const onKeyDown = (event: KeyboardEvent): void => {
    if (event.key === 'Escape') { event.preventDefault(); onCancel(); return; }
    if (event.key === 'Enter') { event.preventDefault(); onClose(event.ctrlKey || event.metaKey ? 'save' : 'keep'); return; }
    if (target.kind === 'delivery' && (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
      event.preventDefault();
      const index = DELIVERY.findIndex((option) => option.value === value);
      const next = DELIVERY[(index + (event.key === 'ArrowDown' ? 1 : DELIVERY.length - 1)) % DELIVERY.length];
      if (next !== undefined) change(next.value);
    }
  };
  const optionId = useId();
  const reason = state === 'scrolled' ? 'The row is scrolled out of view.' : 'The row is not in the current results. It may be filtered out, moved by sorting, or on a page that is not loaded.';
  return (
    <FloatingPortal>
      <div
        ref={(node) => refs.setFloating(node)} role="dialog" aria-label={`Edit ${target.columnLabel} of ${target.label}`} data-editor-for={target.rowId} data-editor-column={target.column}
        data-grid-key={gridKey} data-anchor-state={state} className={`cell-editor${state === 'visible' ? '' : ' docked'}`}
        style={{ ...floatingStyles, width: data?.width ?? 240 }} onKeyDown={onKeyDown}
      >
        {state === 'visible' ? null : (
          <div className="docked-header">
            <strong>{target.label} · {target.columnLabel}</strong>
            <p>{reason} Your edit is kept on {target.label} only.</p>
            <div className="button-row">
              {onScrollTo === null ? null : <button type="button" onClick={onScrollTo}>Scroll to row</button>}
              <button type="button" onClick={() => onClose('keep')}>Keep as draft</button>
              <button type="button" onClick={onCancel}>Cancel edit</button>
            </div>
          </div>
        )}
        {target.kind === 'text' ? (
          <input ref={focusOnAttach} className="editor-input" aria-label={`${target.columnLabel} for ${target.label}`} value={value} maxLength={200} onChange={(event) => change(event.target.value)} />
        ) : (
          <div ref={focusOnAttach} role="listbox" tabIndex={0} className="editor-listbox" aria-label={`${target.columnLabel} for ${target.label}`} aria-activedescendant={`${optionId}-${value}`}>
            {DELIVERY.map((option) => (
              <div
                key={option.value} id={`${optionId}-${option.value}`} role="option" aria-selected={value === option.value} className="editor-option"
                onMouseDown={(event) => event.preventDefault()} onClick={() => { change(option.value); onClose('keep'); }}
              >{option.label}</div>
            ))}
          </div>
        )}
        <div className="editor-footer">
          {status === null ? null : <span className="editor-status">{status}</span>}
          <span className="muted">Enter keeps the draft · Ctrl+Enter saves · Esc cancels</span>
          <button type="button" className="primary small" onClick={() => onClose('save')}>Save</button>
        </div>
      </div>
    </FloatingPortal>
  );
}
