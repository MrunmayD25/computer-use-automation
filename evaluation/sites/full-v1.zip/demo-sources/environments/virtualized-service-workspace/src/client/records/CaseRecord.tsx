import type { CaseDetail } from '@computer-use/financial-database/services';
import type { ReactNode } from 'react';

import { institutionPath } from '../api.js';
import { formatDate, formatInstant, label } from '../format.js';
import { tabKeyOf, useShell } from '../shell.js';
import { useResource } from '../useResource.js';
import { useWorkspace } from '../workspace.js';
import { ActivityPanel, Panel, ScopedRecords, useDownload, useOpenOperation, usePublishContext, useRecordRefresh } from './common.js';

export function CaseRecord({ id }: { id: string }): ReactNode {
  const { institution, can } = useWorkspace();
  const { openRecord, openDialog } = useShell();
  const openOperation = useOpenOperation();
  const save = useDownload();
  const institutionId = institution.institutionId;
  const refresh = useRecordRefresh('cases', id);
  const { data, error } = useResource<CaseDetail>(institutionPath(institutionId, `/cases/${encodeURIComponent(id)}`), refresh);
  usePublishContext(tabKeyOf(institutionId, 'case', id), data === undefined ? null : {
    title: data.case.caseNumber, member: { id: data.case.memberId, number: data.case.memberNumber, name: data.case.memberName },
    account: data.case.accountId === null || data.case.accountNumber === null ? null : { id: data.case.accountId, number: data.case.accountNumber, currency: '' },
  });
  if (data === undefined) return <div className="record-loading">{error ?? 'Loading case…'}</div>;
  const record = data.case;
  const closed = record.state === 'closed';
  return (
    <article className="record" data-record-kind="case" data-record-id={id} data-record-version={record.version}>
      <header className="record-header">
        <div>
          <h2>{record.summary} <code>{record.caseNumber}</code></h2>
          <p className="muted">
            <span className={`badge status-${record.state}`}>{label(record.state)}</span> <span className={`badge status-${record.priority}`}>{label(record.priority)}</span>{' '}
            {record.categoryLabel} · member <button type="button" className="link" onClick={() => openRecord('member', record.memberId)}>{record.memberName} ({record.memberNumber})</button>
            {record.accountId === null ? null : <> · account <button type="button" className="link" onClick={() => { if (record.accountId !== null) openRecord('account', record.accountId); }}>{record.accountNumber}</button></>}
            {' '}· version {record.version}
          </p>
        </div>
        <div className="button-row">
          <button type="button" disabled={closed || !can('case.assign')} onClick={() => openDialog({ kind: 'case.assign', record })}>Assign…</button>
          <button type="button" disabled={(data.allowedTransitions.length === 0 && !['resolved', 'closed'].includes(record.state)) || !can('case.transition')} onClick={() => openDialog({ kind: 'case.transition', record })}>Change status…</button>
          <button type="button" disabled={!can('case.subject.correct')} onClick={() => openDialog({ kind: 'case.subject.correct', record })}>Correct subject…</button>
          <button type="button" disabled={!can('case.note.add')} onClick={() => openDialog({ kind: 'note', owner: { kind: 'case', id, label: record.caseNumber } })}>Add note…</button>
        </div>
        <div className="button-row secondary-actions" aria-label="Case operations">
          <button type="button" disabled={closed || !can('case.information.request')} onClick={() => openOperation('case.information.request', { caseId: id, expectedVersion: record.version, memberId: record.memberId })}>Request information…</button>
          <button type="button" disabled={closed || !can('case.escalate')} onClick={() => openOperation('case.escalate', { caseId: id, expectedVersion: record.version })}>Escalate…</button>
          <button type="button" disabled={!can('document.retention_hold.apply')} onClick={() => openOperation('document.retention_hold.apply', { caseId: id })}>Retention hold…</button>
        </div>
      </header>
      <div className="record-panels">
        <Panel title="Details">
          <dl className="facts">
            <dt>Queue</dt><dd data-field="queue">{record.queueCode} · {record.queueName}</dd>
            <dt>Assignee</dt><dd data-field="assignee">{record.assignedName ?? 'Unassigned'}</dd>
            <dt>Opened</dt><dd>{formatInstant(record.openedAt)}</dd>
            <dt>Due</dt><dd>{formatInstant(record.dueAt)}{record.overdue ? <span className="badge status-overdue">Overdue</span> : null}</dd>
            <dt>Member status</dt><dd>{label(data.memberStatus)}</dd>
          </dl>
          <h4>Service-level intervals</h4>
          <ul className="notes">{data.sla.map((interval) => <li key={`${interval.state}-${interval.startsAt}`}>{label(interval.state)} · {formatInstant(interval.startsAt)} → {interval.endsAt === null ? 'now' : formatInstant(interval.endsAt)}{interval.reason === null ? '' : ` · ${interval.reason}`}</li>)}</ul>
        </Panel>
        <Panel title={`Events (${String(data.events.length)})`}>
          <ol className="timeline">{data.events.map((event) => <li key={event.sequence}><strong>{label(event.state)}</strong> · {formatInstant(event.occurredAt)} · {event.actor?.displayName ?? 'System'}<br />{event.detail}</li>)}</ol>
        </Panel>
        <Panel title={`Notes (${String(data.notes.length)})`}>
          <ul className="notes">{data.notes.map((note) => <li key={note.id}><p>{note.text}</p><span className="muted">{formatInstant(note.createdAt)} · {note.actor?.displayName ?? 'System'} · {note.visibility}</span></li>)}</ul>
        </Panel>
        <Panel title="Documents and dependencies">
          <ul className="link-list">{data.documents.map((document) => <li key={document.versionId}><button type="button" className="link" onClick={() => save(institutionPath(institutionId, `/documents/${encodeURIComponent(document.versionId)}/content`))}>{document.displayName}</button> <span className="muted">{document.purpose} · {formatDate(document.issuedAt)}</span></li>)}</ul>
          <ul className="notes">{data.dependencies.map((dependency) => <li key={dependency.id}>{dependency.kind} {dependency.referenceId} · {dependency.state}{dependency.dueAt === null ? '' : ` · due ${formatDate(dependency.dueAt)}`}</li>)}</ul>
        </Panel>
        <ScopedRecords resource="retention-hold" scope={{ parentId: id }} title="Retention holds" />
        <ScopedRecords resource="case-dependency" scope={{ parentId: id }} title="Dependencies (record store)" />
        <ActivityPanel scope={{ caseId: id }} gridKey={`case-activity-${id}`} />
      </div>
    </article>
  );
}
