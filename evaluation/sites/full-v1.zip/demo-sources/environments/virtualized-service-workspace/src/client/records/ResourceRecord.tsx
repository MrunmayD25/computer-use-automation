import { useEffect, useState, type ReactNode } from 'react';

import { readRecord, type FinanceRecordSnapshot } from '../api.js';
import { formatInstant, label, text } from '../format.js';
import { INQUIRIES, operationFor, type OpSpec } from '../ops/registry.js';
import { resourceTabKey, useShell } from '../shell.js';
import { useWorkspace } from '../workspace.js';
import { Panel, ScopedRecords, usePublishContext } from './common.js';

/** Reads one field of a record row, tolerating camel and snake naming. */
function field(record: Record<string, unknown>, name: string): unknown {
  return record[name] ?? record[name.replace(/[A-Z]/gu, (letter) => `_${letter.toLowerCase()}`)];
}

interface ChildSpec {
  resource: string;
  title: string;
  scope: 'parentId' | 'accountId' | 'memberId';
}

interface ActionSpec {
  kind: string;
  label: string;
  inquiry?: boolean;
  /** Row states the action applies to; empty means always. */
  states?: readonly string[];
  /** Command fields bound from the record snapshot and its fingerprint. */
  bind: (record: Record<string, unknown>, snapshot: FinanceRecordSnapshot) => Record<string, unknown>;
}

const id = (name: string): ActionSpec['bind'] => (record, snapshot) => ({ [name]: record.id, expectedFingerprint: snapshot.fingerprint });
const version = (name: string): ActionSpec['bind'] => (record) => ({ [name]: record.id, expectedVersion: field(record, 'version') });

const CHILDREN: Readonly<Record<string, readonly ChildSpec[]>> = {
  beneficiary: [{ resource: 'beneficiary-route', title: 'Routes', scope: 'parentId' }],
  'beneficiary-route': [],
  payment: [
    { resource: 'payment-event', title: 'Events', scope: 'parentId' },
    { resource: 'payment-return', title: 'Returns', scope: 'parentId' },
    { resource: 'payment-cancel-request', title: 'Cancel requests', scope: 'parentId' },
    { resource: 'reservation', title: 'Reservations', scope: 'parentId' },
  ],
  'payment-schedule': [{ resource: 'schedule-occurrence', title: 'Occurrences', scope: 'parentId' }],
  card: [
    { resource: 'card-transaction', title: 'Card transactions', scope: 'parentId' },
    { resource: 'card-limit', title: 'Limits', scope: 'parentId' },
    { resource: 'card-lock', title: 'Locks', scope: 'parentId' },
    { resource: 'card-event', title: 'Events', scope: 'parentId' },
    { resource: 'card-replacement-order', title: 'Replacement orders', scope: 'parentId' },
  ],
  dispute: [
    { resource: 'dispute-evidence', title: 'Evidence', scope: 'parentId' },
    { resource: 'dispute-credit', title: 'Credits', scope: 'parentId' },
  ],
  loan: [
    { resource: 'loan-component', title: 'Components', scope: 'parentId' },
    { resource: 'loan-obligation', title: 'Obligations', scope: 'parentId' },
    { resource: 'loan-allocation', title: 'Allocations', scope: 'parentId' },
    { resource: 'payoff-quote', title: 'Payoff quotes', scope: 'parentId' },
    { resource: 'loan-closure', title: 'Closure', scope: 'parentId' },
  ],
  journal: [
    { resource: 'correction-link', title: 'Correction links', scope: 'parentId' },
    { resource: 'effective-date-correction', title: 'Effective-date corrections', scope: 'parentId' },
    { resource: 'transaction-amendment', title: 'Description amendments', scope: 'parentId' },
  ],
  transaction: [],
  transfer: [],
  fee: [{ resource: 'fee-refund', title: 'Refunds', scope: 'parentId' }],
  hold: [{ resource: 'hold-release', title: 'Releases', scope: 'parentId' }],
  restriction: [],
  facility: [],
  'maturity-instruction': [],
  'interest-calculation': [],
  'received-funds': [{ resource: 'received-funds-use', title: 'Uses', scope: 'parentId' }],
  'settlement-batch': [{ resource: 'settlement-item', title: 'Items', scope: 'parentId' }],
  'suspense-item': [],
  batch: [{ resource: 'batch-item', title: 'Items', scope: 'parentId' }],
  'loan-closure': [],
  document: [{ resource: 'document-version', title: 'Versions', scope: 'parentId' }],
  'document-version': [
    { resource: 'signature', title: 'Signatures', scope: 'parentId' },
    { resource: 'document-annotation', title: 'Annotations', scope: 'parentId' },
  ],
  'maintenance-request': [{ resource: 'request-attachment', title: 'Attachments', scope: 'parentId' }],
  'communication-job': [{ resource: 'communication-event', title: 'Delivery events', scope: 'parentId' }],
  consent: [],
  'identity-evidence': [],
  'merge-plan': [],
  'account-party': [],
  'loan-application': [],
  'fee-waiver': [],
  'payoff-quote': [],
  'deposit-maturity-term': [],
  'cash-session': [{ resource: 'cash-declaration', title: 'Declarations', scope: 'parentId' }],
  'reconciliation-run': [{ resource: 'reconciliation-match', title: 'Matches', scope: 'parentId' }],
  'communication-preference': [],
  'retention-hold': [],
};

const ACTIONS: Readonly<Record<string, readonly ActionSpec[]>> = {
  payment: [
    { kind: 'payment.submit', label: 'Submit', states: ['draft'], bind: version('paymentId') },
    { kind: 'payment.cancel', label: 'Cancel', states: ['draft', 'pending-approval'], bind: version('paymentId') },
    { kind: 'payment.approve_release', label: 'Approve and release', states: ['pending-approval'], bind: version('paymentId') },
    { kind: 'payment.settle', label: 'Settle', states: ['released'], bind: version('paymentId') },
  ],
  beneficiary: [
    { kind: 'beneficiary.verify', label: 'Verify route', states: ['pending', 'active'], bind: (record) => ({ beneficiaryId: record.id, memberId: field(record, 'memberId') }) },
    { kind: 'beneficiary.routing.update', label: 'Update routing', bind: (record) => ({ beneficiaryId: record.id, memberId: field(record, 'memberId') }) },
    { kind: 'beneficiary.retire', label: 'Retire', states: ['active', 'pending'], bind: id('beneficiaryId') },
  ],
  'payment-schedule': [
    { kind: 'payment.schedule.end', label: 'End schedule', states: ['active'], bind: id('scheduleId') },
  ],
  'schedule-occurrence': [
    { kind: 'payment.schedule.materialize', label: 'Materialize', states: ['planned'], bind: id('occurrenceId') },
    { kind: 'payment.occurrence.amend', label: 'Amend', states: ['planned'], bind: id('occurrenceId') },
  ],
  card: [
    { kind: 'card.replace', label: 'Replace', bind: (record, snapshot) => ({ cardId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
    { kind: 'card.lock.update', label: 'Lock or unlock', bind: (record, snapshot) => ({ cardId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
    { kind: 'card.limit.update', label: 'Change limit', bind: (record, snapshot) => ({ cardId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
  ],
  'card-transaction': [
    { kind: 'dispute.open', label: 'Open dispute', states: ['posted', 'settled'], bind: (record, snapshot) => ({ cardTransactionId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
  ],
  dispute: [
    { kind: 'dispute.provisional_credit.issue', label: 'Issue provisional credit', bind: (record, snapshot) => ({ disputeId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
    { kind: 'dispute.evidence.submit', label: 'Submit evidence', bind: (record, snapshot) => ({ disputeId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
    { kind: 'dispute.settle', label: 'Settle', bind: (record, snapshot) => ({ disputeId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
  ],
  loan: [
    { kind: 'loan.payment.allocate', label: 'Allocate payment', states: ['open', 'delinquent'], bind: (record, snapshot) => ({ loanId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
    { kind: 'loan.payoff.quote', label: 'Payoff quote', states: ['open', 'delinquent'], bind: (record, snapshot) => ({ loanId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
    { kind: 'loan.close', label: 'Close loan', bind: (record, snapshot) => ({ loanId: record.id, expectedFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) },
    { kind: 'document.loan_closure.issue', label: 'Issue closure document', bind: (record) => ({ loanId: record.id, memberId: field(record, 'memberId') }) },
  ],
  'loan-closure': [
    { kind: 'document.loan_closure.issue', label: 'Issue closure document', bind: (record) => ({ loanId: field(record, 'loanId') }) },
  ],
  fee: [{ kind: 'fee.refund', label: 'Refund', states: ['posted', 'charged'], bind: id('feeId') }],
  hold: [{ kind: 'account.hold.release', label: 'Release', states: ['active'], bind: id('holdId') }],
  restriction: [{ kind: 'account.restriction.release', label: 'Release', states: ['active'], bind: id('restrictionId') }],
  facility: [{ kind: 'account.overdraft_limit.update', label: 'Update overdraft limit', bind: (record, snapshot) => ({ accountId: field(record, 'accountId'), expectedFacilityFingerprint: snapshot.fingerprint, memberId: field(record, 'memberId') }) }],
  'interest-calculation': [{ kind: 'interest.adjust', label: 'Adjust interest', states: ['calculated'], bind: id('calculationId') }],
  'maturity-instruction': [{ kind: 'account.maturity.instruct', label: 'Change instruction', bind: (record, snapshot) => ({ accountId: field(record, 'accountId'), expectedInstructionFingerprint: snapshot.fingerprint }) }],
  journal: [
    { kind: 'transaction.description.update', label: 'Update description', bind: id('journalId') },
    { kind: 'transaction.effective_date.correct', label: 'Correct effective date', bind: id('journalId') },
    { kind: 'cash.deposit.reverse', label: 'Reverse deposit', states: ['posted'], bind: id('journalId') },
    { kind: 'cash.withdrawal.reverse', label: 'Reverse withdrawal', states: ['posted'], bind: id('journalId') },
  ],
  transfer: [
    { kind: 'transfer.internal.reverse', label: 'Reverse transfer', bind: id('transferJournalId') },
    { kind: 'finance.reconcile_transfer', label: 'Reconcile', inquiry: true, bind: id('transferJournalId') },
  ],
  'suspense-item': [
    { kind: 'reconciliation.suspense.investigate', label: 'Investigate', states: ['open', 'unresolved'], bind: id('suspenseId') },
    { kind: 'reconciliation.suspense.clear', label: 'Clear', states: ['open', 'unresolved', 'investigating'], bind: id('suspenseId') },
  ],
  'settlement-batch': [{ kind: 'finance.reconcile_settlement_batch', label: 'Reconcile', inquiry: true, bind: id('settlementBatchId') }],
  batch: [
    { kind: 'finance.preview_batch', label: 'Preview', inquiry: true, bind: id('batchId') },
    { kind: 'batch.contacts.apply', label: 'Apply contact item', bind: id('batchId') },
    { kind: 'batch.fee_refunds.apply', label: 'Apply refund item', bind: id('batchId') },
  ],
  'maintenance-request': [
    { kind: 'maintenance.draft.amend', label: 'Amend draft', states: ['draft'], bind: (record) => ({ requestId: record.id, expectedUpdatedAt: field(record, 'updatedAt') }) },
    { kind: 'maintenance.request.submit', label: 'Submit', states: ['draft', 'returned'], bind: (record) => ({ requestId: record.id, expectedUpdatedAt: field(record, 'updatedAt') }) },
    { kind: 'maintenance.request.withdraw', label: 'Withdraw', states: ['submitted', 'under-review'], bind: (record) => ({ requestId: record.id, expectedUpdatedAt: field(record, 'updatedAt') }) },
    { kind: 'maintenance.request.review', label: 'Review', states: ['submitted', 'under-review'], bind: (record) => ({ requestId: record.id, expectedUpdatedAt: field(record, 'updatedAt') }) },
    { kind: 'maintenance.request.process', label: 'Process', states: ['approved'], bind: (record) => ({ requestId: record.id, expectedUpdatedAt: field(record, 'updatedAt') }) },
    { kind: 'edit.cancel', label: 'Cancel request', states: ['draft', 'submitted', 'under-review', 'returned'], bind: (record) => ({ requestId: record.id, expectedUpdatedAt: field(record, 'updatedAt') }) },
  ],
  'communication-job': [{ kind: 'communication.delivery.update', label: 'Update delivery', bind: (record) => ({ jobId: record.id, memberId: field(record, 'memberId') }) }],
  'merge-plan': [{ kind: 'member.merge', label: 'Execute merge', states: ['reviewed'], bind: (record) => ({ mergePlanId: record.id }) }],
  document: [{ kind: 'document.metadata.update', label: 'Update metadata', bind: (record) => ({ documentId: record.id }) }],
  'document-version': [
    { kind: 'document.signature.collect', label: 'Collect signature', bind: (record) => ({ documentVersionId: record.id }) },
    { kind: 'document.annotation.update', label: 'Annotate', bind: (record) => ({ documentVersionId: record.id }) },
  ],
  consent: [{ kind: 'consent.withdraw', label: 'Withdraw', states: ['granted', 'active'], bind: (record) => ({ consentId: record.id, memberId: field(record, 'memberId') }) }],
  'identity-evidence': [{ kind: 'member.identity.verify', label: 'Verify identity', bind: (record) => ({ evidenceId: record.id, memberId: field(record, 'memberId') }) }],
};

function valueText(value: unknown): string {
  if (value === null || value === undefined || value === '') return '—';
  if (typeof value === 'object') return JSON.stringify(value);
  return text(value);
}

/** One finance or servicing record tab: current snapshot, actions bound to its fingerprint, child records. */
export function ResourceRecord({ resource, id }: { resource: string; id: string }): ReactNode {
  const { institution, can, dataVersion } = useWorkspace();
  const { openDialog, openRecord } = useShell();
  const institutionId = institution.institutionId;
  const [snapshot, setSnapshot] = useState<FinanceRecordSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    setSnapshot(null);
    void readRecord(institutionId, resource, id).then(
      (found) => { if (live) { setSnapshot(found); setError(null); } },
      (cause: unknown) => { if (live) { setSnapshot(null); setError(cause instanceof Error ? cause.message : String(cause)); } },
    );
    return () => { live = false; };
  }, [institutionId, resource, id, dataVersion]);
  const record = snapshot?.record ?? {};
  const title = valueText(record.reference ?? record.label ?? record.displayName ?? record.caseNumber ?? record.case_number ?? record.requestNumber ?? record.request_number ?? record.id ?? id);
  const memberId = field(record, 'memberId');
  const accountId = field(record, 'accountId');
  usePublishContext(resourceTabKey(institutionId, resource, id), snapshot === null ? null : {
    title: `${resource} ${title}`,
    member: typeof memberId === 'string' && memberId !== '' ? { id: memberId, number: valueText(field(record, 'memberNumber')), name: valueText(field(record, 'displayName') ?? field(record, 'memberName')) } : null,
    account: typeof accountId === 'string' && accountId !== '' ? { id: accountId, number: valueText(field(record, 'accountNumber')), currency: valueText(field(record, 'currency')) } : null,
  });
  if (snapshot === null) return <div className="record-loading">{error ?? 'Loading record…'}</div>;
  const state = text(field(record, 'state') ?? field(record, 'status'));
  const children = CHILDREN[resource] ?? [];
  const actions = (ACTIONS[resource] ?? []).filter((action) => action.states === undefined || action.states.includes(state));
  return (
    <article className="record" data-record-kind="resource" data-resource={resource} data-record-id={id}>
      <header className="record-header">
        <div>
          <h2>{title} <code className="muted">{resource}</code></h2>
          <p className="muted">{state === '' ? '' : <span className={`badge status-${state}`}>{label(state)}</span>} {snapshot.fingerprint === null ? 'Read through the bounded record list.' : <>fingerprint <code>{snapshot.fingerprint.slice(0, 16)}…</code></>} observed {formatInstant(snapshot.observedAt)}</p>
        </div>
        <div className="button-row">
          {actions.map((action) => {
            const spec: OpSpec | undefined = operationFor(action.kind);
            const inquiry = action.inquiry === true ? INQUIRIES.find((item) => item.kind === action.kind) : undefined;
            const target = spec ?? inquiry;
            if (target === undefined) return null;
            return <button key={action.kind} type="button" disabled={inquiry === undefined && (spec === undefined || !can(spec.kind as never))} onClick={() => openDialog({ kind: 'operation', spec: target, inquiry: inquiry !== undefined, context: { initial: action.bind(record, snapshot), memberId: typeof memberId === 'string' ? memberId : undefined, accountId: typeof accountId === 'string' ? accountId : undefined, currency: typeof record.currency === 'string' ? record.currency : undefined } })}>{action.label}…</button>;
          })}
          {typeof memberId === 'string' && memberId !== '' ? <button type="button" onClick={() => openRecord('member', memberId)}>Open member</button> : null}
          {typeof accountId === 'string' && accountId !== '' ? <button type="button" onClick={() => openRecord('account', accountId)}>Open account</button> : null}
        </div>
      </header>
      <div className="record-panels">
        <Panel title="Record">
          <dl className="facts">
            {Object.entries(record).filter(([_key, value]) => value !== null && value !== '' && !Array.isArray(value)).map(([key, value]) => (
              <div key={key}><dt>{label(key.replace(/_/gu, ' '))}</dt><dd>{key.endsWith('_at') || key.endsWith('At') ? formatInstant(String(value)) : valueText(value)}</dd></div>
            ))}
          </dl>
        </Panel>
        {children.map((child) => <ScopedRecords key={child.resource} resource={child.resource} title={child.title} scope={child.scope === 'parentId' ? { parentId: id } : child.scope === 'accountId' ? { accountId: id } : { memberId: id }} />)}
      </div>
    </article>
  );
}
