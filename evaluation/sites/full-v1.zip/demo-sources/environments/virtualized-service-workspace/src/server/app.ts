import { randomBytes } from 'node:crypto';
import { existsSync } from 'node:fs';
import { createServer, type Server } from 'node:http';
import { join } from 'node:path';

import type { DatasetBinding } from '@computer-use/financial-database';
import {
  authorizeQuery, CAPABILITY_GRANTS, SHARED_SEARCH_GRANTS, accountDetail, accountDocuments, accountTransactions, caseDetail, caseGroupCounts, documentContent, executeCommand,
  institutionSummary, listActivity, listSavedSearches, memberDetail, operatorProfile, receiptByNumber, recordStamps, referenceData, renderCsv,
  listApprovals, listCaseSubjectCorrectionEvidence, listEffectivePolicyVersions, listServicingApprovalCheckers, renderGeneratedStatement, reviewCommand, searchAccounts, searchCases, searchDocuments, searchMembers, statementData, statementPeriods, transactionsCsv,
  communicationJob, documentAnnotation, exportStatement, listDocumentAnnotations, listDocumentSignatures, listFinanceRecords, listMemberAddressDestinations, listMemberAddresses,
  listMemberCommunicationJobs, listMemberCommunicationPreferences, listMemberConsents, listMemberDocumentVersions, listMemberIdentityEvidence, listMemberMaintenanceRequests,
  listMemberRetentionHolds, listServicingQueues, maintenanceRequest, queryCore, queryFinance, queryMemberMergePlan, resolveMemberIdentity, retrieveCustomerExportArtifact,
  retrieveHistoricalStatement, servicingCaseDetail, validateFinanceQuery, validateServiceCommand,
  type CaseFilter, type FinancialStore, type PageResult, type ServicingQueryResult, type SqlDatabase, type TransactionRow, type WritePrincipal,
} from '@computer-use/financial-database/services';
import express, { type NextFunction, type Request, type Response } from 'express';
import type { z } from 'zod';

import { APPLICATION_ID, type ApiErrorBody, type ExportSelection, type InstitutionInfo, type OperatorChoice, type OperatorInstitutionProfile, type SessionInfo } from '../shared/api.js';
import { GRID_COLUMNS, GRID_SORTS, fieldOf, isGridId, type GridId, type SearchEntity } from '../shared/columns.js';
import { layoutProblem, type PreferenceStore } from './preferences.js';
import type { caseFilterSchema } from './schemas.js';
import {
  accountQuerySchema, activityQuerySchema, caseGroupQuerySchema, caseQuerySchema, columnLayoutSchema, coreQueryBodySchema, defined, documentQuerySchema, executeBodySchema,
  exportBodySchema, exportQuerySchema, financeQueryBodySchema, identityResolveQuerySchema, memberQuerySchema, membershipBodySchema,
  operatorBodySchema, recordListQuerySchema, reviewBodySchema, savedSearchQuerySchema, servicingReadBodySchema, stampBodySchema, statementExportQuerySchema, statementQuerySchema,
  transactionQuerySchema,
} from './schemas.js';

export const APPLICATION_VERSION = '0.1.0';
const MAX_CSV_TRANSACTIONS = 10_000;
const MAX_SESSIONS = 500;
const DEFAULT_EXPORT_LIMIT = 5_000;

export interface OperatorConfig {
  /** Actor numbers allowed to sign on, resolved per institution. The first is the default. */
  actorNumbers: readonly string[];
  /** When true the backend fixes the operator and the browser cannot switch it. */
  fixed: boolean;
}

export interface WorkspaceOptions {
  store: FinancialStore;
  bindings: readonly DatasetBinding[];
  operator: OperatorConfig;
  mode: 'shared' | 'verification';
  /** Per-operator column layouts. Presentation state stays outside the shared database. */
  preferences: PreferenceStore;
  /** Principal kind recorded with each write; evaluator runs normally use `automation`. */
  principalKind?: WritePrincipal['kind'];
  /** Approved local destinations for derived statement export artifacts. */
  exportDestinations?: readonly string[];
  publicDirectory?: string;
  host?: string;
  port?: number;
  verbose?: boolean;
  /** Largest selection an export resolves; larger selections are refused, never truncated. */
  exportLimit?: number;
  /** Called when the listener stops; the shared CLI closes its store here, an evaluator keeps its run. */
  onClose?: () => void;
}

export interface WorkspaceHandle {
  origin: string;
  close: () => Promise<void>;
}

class HttpError extends Error {
  constructor(readonly status: number, readonly code: string, message: string, readonly field?: string) { super(message); }
}

interface UiSession {
  id: string;
  actorNumber: string;
  lastSeen: number;
}

function parse<T>(schema: z.ZodType<T>, value: unknown): T {
  const result = schema.safeParse(value);
  if (!result.success) {
    const issue = result.error.issues[0];
    throw new HttpError(400, 'invalid_request', issue === undefined ? 'The request is invalid.' : `${issue.path.join('.') || 'request'}: ${issue.message}`, issue?.path.join('.'));
  }
  return result.data;
}

function servicingValue<T>(result: ServicingQueryResult<T>): T {
  if (result.kind === 'authorized') return result.value;
  throw new HttpError(result.code === 'not_authorized' ? 403 : 400, result.code, result.message, result.field);
}

function parseCookies(header: string | undefined): Map<string, string> {
  const cookies = new Map<string, string>();
  for (const part of header?.split(';') ?? []) {
    const index = part.indexOf('=');
    if (index > 0) cookies.set(part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim()));
  }
  return cookies;
}

function contentDisposition(filename: string): string {
  return `attachment; filename="${filename.replaceAll(/[^A-Za-z0-9._-]/gu, '_')}"`;
}

/** Maps a grid column id to the server sort key, refusing columns the grid cannot sort by. */
function sortKey(grid: GridId, column: string | undefined): string | undefined {
  if (column === undefined || column === '') return undefined;
  const key = GRID_SORTS[grid][column];
  if (key === undefined) throw new HttpError(400, 'invalid_sort', `The ${grid} list cannot be sorted by ${column}.`, 'sort');
  return key;
}

/** Applies a saved search's result limit: the total and pages stop at the limit instead of silently continuing. */
function capped<T>(page: PageResult<T>, maxResults: number | undefined): PageResult<T> & { limitedTo: number | null; matched: number } {
  if (maxResults === undefined) return { ...page, limitedTo: null, matched: page.total };
  const items = page.offset >= maxResults ? [] : page.items.slice(0, maxResults - page.offset);
  return { ...page, items, total: Math.min(page.total, maxResults), limitedTo: maxResults, matched: page.total };
}

function listFrom(value: string | undefined): string[] | undefined {
  if (value === undefined || value === '') return undefined;
  return value.split(',').map((item) => item.trim()).filter((item) => item.length > 0);
}

function caseFilterFromQuery(query: z.infer<typeof caseFilterSchema>): CaseFilter {
  return defined({
    memberId: query.memberId, accountId: query.accountId, states: listFrom(query.states), queueIds: listFrom(query.queueIds), priority: query.priority, query: query.query,
    assignedActorId: query.assignedActorId === undefined || query.assignedActorId === '' ? undefined : query.assignedActorId === 'unassigned' ? null : query.assignedActorId,
    overdue: query.overdue === undefined ? undefined : query.overdue === 'true',
  });
}

/** Saved-search filter vocabulary (the same one the grids use) translated into list-query criteria. */
function filtersFor(entity: SearchEntity, filters: Record<string, string | boolean | string[]>): Record<string, unknown> {
  const text = (key: string): string | undefined => { const value = filters[key]; return typeof value === 'string' && value !== '' ? value : undefined; };
  const list = (key: string): string[] | undefined => { const value = filters[key]; return Array.isArray(value) && value.length > 0 ? value : undefined; };
  const allowed: Record<SearchEntity, readonly string[]> = { members: ['query', 'status'], accounts: ['query', 'status', 'currency'], cases: ['query', 'states', 'queueIds', 'priority', 'assignedActorId', 'overdue'] };
  const unknown = Object.keys(filters).find((key) => !allowed[entity].includes(key));
  if (unknown !== undefined) throw new HttpError(400, 'invalid_filter', `The ${entity} list has no ${unknown} filter.`, `selection.filters.${unknown}`);
  if (entity === 'cases') {
    const assignee = text('assignedActorId');
    return defined({ query: text('query'), states: list('states'), queueIds: list('queueIds'), priority: text('priority'),
      assignedActorId: assignee === undefined ? undefined : assignee === 'unassigned' ? null : assignee, overdue: filters.overdue === true ? true : undefined });
  }
  return defined({ query: text('query'), status: text('status'), currency: entity === 'accounts' ? text('currency') : undefined });
}

/** Builds the HTTP application. Browser input selects institutions and records, never datasets or actors. */
export function createWorkspaceApp(options: WorkspaceOptions): express.Express {
  const { store, preferences } = options;
  const exportLimit = options.exportLimit ?? DEFAULT_EXPORT_LIMIT;
  if (options.operator.actorNumbers.length === 0) throw new Error('At least one operator actor number is required.');
  const institutions = new Map<string, { binding: DatasetBinding; info: InstitutionInfo }>();
  store.read((database) => {
    for (const binding of options.bindings) {
      const summary = institutionSummary(database, binding.datasetId);
      if (summary.institutionId !== binding.institutionId) throw new Error(`Dataset ${binding.datasetId} does not belong to ${binding.institutionId}.`);
      institutions.set(binding.institutionId, { binding, info: { institutionId: summary.institutionId, displayName: summary.displayName, legalName: summary.legalName, timeZone: summary.timeZone, defaultCurrency: summary.defaultCurrency, asOf: summary.asOf } });
    }
  });
  if (institutions.size === 0) throw new Error('At least one institution binding is required.');
  const sessions = new Map<string, UiSession>();
  const app = express();
  app.disable('x-powered-by');
  app.set('query parser', 'simple');

  if (options.verbose === true) {
    app.use((request, response, next) => {
      const started = process.hrtime.bigint();
      response.on('finish', () => console.error(`${request.method} ${request.originalUrl} ${response.statusCode} ${Number(process.hrtime.bigint() - started) / 1e6}ms`));
      next();
    });
  }
  app.use('/api', (request, response, next) => {
    response.setHeader('Cache-Control', 'no-store');
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      const origin = request.get('origin');
      if (origin !== undefined && origin !== `${request.protocol}://${request.get('host') ?? ''}`) { next(new HttpError(403, 'cross_origin', 'Cross-origin requests are not accepted.')); return; }
    }
    next();
  });
  app.use('/api', express.json({ limit: '32mb' }));

  const session = (request: Request, response: Response): UiSession => {
    const cookie = parseCookies(request.get('cookie')).get('vsw_session');
    const existing = cookie === undefined ? undefined : sessions.get(cookie);
    if (existing !== undefined) { existing.lastSeen = Date.now(); return existing; }
    if (sessions.size >= MAX_SESSIONS) {
      const oldest = [...sessions.values()].sort((a, b) => a.lastSeen - b.lastSeen)[0];
      if (oldest !== undefined) sessions.delete(oldest.id);
    }
    const created: UiSession = { id: randomBytes(18).toString('base64url'), actorNumber: options.operator.actorNumbers[0] ?? '', lastSeen: Date.now() };
    sessions.set(created.id, created);
    response.setHeader('Set-Cookie', `vsw_session=${created.id}; Path=/; HttpOnly; SameSite=Strict`);
    return created;
  };

  const institution = (request: Request): { binding: DatasetBinding; info: InstitutionInfo } => {
    const found = institutions.get(String(request.params.institutionId));
    if (found === undefined) throw new HttpError(404, 'unknown_institution', 'This workspace is not bound to that institution.');
    return found;
  };

  const profile = (actorNumber: string, binding: DatasetBinding): OperatorInstitutionProfile | null => store.read((database) => {
    const found = operatorProfile(database, binding.datasetId, binding.institutionId, actorNumber);
    if (found === undefined) return null;
    const active = found.status === 'active';
    const commands = active ? Object.entries(CAPABILITY_GRANTS).filter(([, grants]) => grants.some((grant) => found.permissions.includes(grant))).map(([kind]) => kind) : [];
    return {
      actorId: found.actor.id, actorNumber: found.actor.actorNumber, displayName: found.actor.displayName, status: found.status, roles: found.roles, permissions: found.permissions,
      commands, canShareSearches: active && SHARED_SEARCH_GRANTS.some((grant) => found.permissions.includes(grant)),
    };
  });

  const actorFor = (request: Request, response: Response, binding: DatasetBinding): { actorId: string; ui: UiSession } => {
    const ui = session(request, response);
    const found = profile(ui.actorNumber, binding);
    if (found === null) throw new HttpError(403, 'operator_unavailable', `Operator ${ui.actorNumber} is not registered at this institution.`);
    return { actorId: found.actorId, ui };
  };

  const read = <T>(request: Request, query: (database: SqlDatabase, datasetId: string) => T): T => {
    const { binding } = institution(request);
    return store.read((database) => query(database, binding.datasetId));
  };

  const notFound = (what: string): HttpError => new HttpError(404, 'not_found', `The ${what} does not exist at this institution.`);

  app.get('/healthz', (_request, response) => { response.json({ status: 'ok', applicationId: APPLICATION_ID }); });

  app.get('/api/session', (request, response) => {
    const ui = session(request, response);
    const first = [...institutions.values()][0];
    const choices: OperatorChoice[] = options.operator.fixed ? [] : options.operator.actorNumbers.map((actorNumber) => {
      const found = first === undefined ? null : profile(actorNumber, first.binding);
      return { actorNumber, displayName: found?.displayName ?? actorNumber, roles: found?.roles ?? [] };
    });
    const body: SessionInfo = {
      applicationId: APPLICATION_ID, applicationVersion: APPLICATION_VERSION, mode: options.mode,
      institutions: [...institutions.values()].map((entry) => entry.info),
      operator: { actorNumber: ui.actorNumber, profiles: Object.fromEntries([...institutions.values()].map((entry) => [entry.info.institutionId, profile(ui.actorNumber, entry.binding)])) },
      operatorChoices: choices, exportLimit,
    };
    response.json(body);
  });

  app.post('/api/session/operator', (request, response) => {
    const ui = session(request, response);
    const { actorNumber } = parse(operatorBodySchema, request.body);
    if (options.operator.fixed) throw new HttpError(403, 'operator_fixed', 'The operator for this workspace is fixed by its backend.');
    if (!options.operator.actorNumbers.includes(actorNumber)) throw new HttpError(403, 'operator_not_configured', `Operator ${actorNumber} is not configured for sign-on.`);
    ui.actorNumber = actorNumber;
    response.json({ actorNumber });
  });

  const gridParam = (request: Request): GridId => {
    const grid = String(request.params.grid);
    if (!isGridId(grid)) throw new HttpError(404, 'unknown_grid', `There is no ${grid} grid.`);
    return grid;
  };

  app.get('/api/preferences/:grid', (request, response) => {
    const grid = gridParam(request);
    response.json({ grid, layout: preferences.get(session(request, response).actorNumber, grid) });
  });

  app.put('/api/preferences/:grid', (request, response) => {
    const grid = gridParam(request);
    const layout = parse(columnLayoutSchema, request.body);
    const problem = layoutProblem(grid, layout);
    if (problem !== null) throw new HttpError(400, 'invalid_layout', problem);
    preferences.put(session(request, response).actorNumber, grid, layout);
    response.json({ grid, layout });
  });

  app.delete('/api/preferences/:grid', (request, response) => {
    const grid = gridParam(request);
    preferences.remove(session(request, response).actorNumber, grid);
    response.json({ grid, layout: null });
  });

  const router = express.Router({ mergeParams: true });
  app.use('/api/i/:institutionId', router);
  const documentReaders = new WeakMap<Request,{institutionId:string;actorId:string}>();
  router.use((request, response, next) => {
    const { binding } = institution(request);
    const { actorId } = actorFor(request, response, binding);
    const denied = store.read(database => authorizeQuery(database, { binding, actorId, reference: APPLICATION_ID }));
    if (denied !== null) throw new HttpError(403, denied.code, denied.message);
    documentReaders.set(request,{institutionId:binding.institutionId,actorId});
    next();
  });

  router.get('/reference', (request, response) => {
    const { binding } = institution(request);
    response.json(store.read((database) => referenceData(database, binding.datasetId, binding.institutionId)));
  });

  router.get('/members', (request, response) => {
    const { sort, maxResults, ...query } = parse(memberQuerySchema, request.query);
    const key = sortKey('members', sort);
    response.json(capped(read(request, (database, datasetId) => searchMembers(database, datasetId, defined({ ...query, sort: key }))), maxResults));
  });

  router.get('/members/:memberId', (request, response) => {
    const detail = read(request, (database, datasetId) => memberDetail(database, datasetId, request.params.memberId, documentReader(request)));
    if (detail === undefined) throw notFound('member');
    response.json(detail);
  });

  router.get('/servicing/case-subject-correction/:memberId', (request, response) => {
    const context = serviceContext(request, response);
    const correctedMemberId = typeof request.query.correctedMemberId === 'string' && request.query.correctedMemberId.trim() !== '' ? request.query.correctedMemberId.trim() : request.params.memberId;
    const prerequisites = store.read((database) => ({
      ...servicingValue(listCaseSubjectCorrectionEvidence(database, context, request.params.memberId, correctedMemberId)),
      approvalCheckers: servicingValue(listServicingApprovalCheckers(database, context, 'case.subject.correct')),
      policyVersions: servicingValue(listEffectivePolicyVersions(database, context)),
    }));
    response.json({ ...prerequisites, approvals: listApprovals(store, context) });
  });

  router.get('/accounts', (request, response) => {
    const { sort, maxResults, ...query } = parse(accountQuerySchema, request.query);
    const key = sortKey('accounts', sort);
    response.json(capped(read(request, (database, datasetId) => searchAccounts(database, datasetId, defined({ ...query, sort: key }))), maxResults));
  });

  router.get('/accounts/:accountId', (request, response) => {
    const detail = read(request, (database, datasetId) => accountDetail(database, datasetId, request.params.accountId));
    if (detail === undefined) throw notFound('account');
    response.json(detail);
  });

  router.get('/accounts/:accountId/transactions', (request, response) => {
    const query = parse(transactionQuerySchema, request.query);
    const accountId = request.params.accountId;
    const result = read(request, (database, datasetId) => accountDetail(database, datasetId, accountId) === undefined ? undefined : accountTransactions(database, datasetId, accountId, defined(query)));
    if (result === undefined) throw notFound('account');
    response.json(result);
  });

  router.get('/accounts/:accountId/statements', (request, response) => {
    const accountId = request.params.accountId;
    const result = read(request, (database, datasetId) => accountDetail(database, datasetId, accountId) === undefined ? undefined
      : { periods: statementPeriods(database, datasetId, accountId), documents: accountDocuments(database, datasetId, accountId, documentReader(request)) });
    if (result === undefined) throw notFound('account');
    response.json(result);
  });

  router.get('/accounts/:accountId/statement.pdf', async (request, response) => {
    const { period } = parse(statementQuerySchema, request.query);
    const { binding, info } = institution(request);
    const statement = store.read((database) => statementData(database, binding.datasetId, request.params.accountId, period));
    if (statement === undefined) throw notFound('account');
    const artifact = await renderGeneratedStatement(statement, info.asOf);
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${statement.account.accountNumber}-statement-${period}.pdf`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.setHeader('X-Document-Kind', 'generated-statement');
    response.end(Buffer.from(artifact.bytes));
  });

  router.get('/accounts/:accountId/transactions.csv', (request, response) => {
    const query = parse(exportQuerySchema, request.query);
    const { binding, info } = institution(request);
    const accountId = request.params.accountId;
    const result = store.read((database) => {
      const detail = accountDetail(database, binding.datasetId, accountId);
      if (detail === undefined) return undefined;
      const rows: TransactionRow[] = [];
      for (let offset = 0; ; offset += 200) {
        const page = accountTransactions(database, binding.datasetId, accountId, { ...defined(query), order: 'oldest', limit: 200, offset });
        rows.push(...page.items);
        if (rows.length > MAX_CSV_TRANSACTIONS) throw new HttpError(413, 'export_too_large', `The export exceeds ${MAX_CSV_TRANSACTIONS} rows; narrow the date range.`);
        if (offset + page.limit >= page.total) break;
      }
      return { detail, rows };
    });
    if (result === undefined) throw notFound('account');
    const artifact = transactionsCsv(result.detail.account, result.rows);
    response.setHeader('Content-Type', 'text/csv; charset=utf-8');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${result.detail.account.accountNumber}-transactions-${query.startDate ?? 'start'}_${query.endDate ?? 'now'}.csv`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.end(Buffer.from(artifact.bytes));
  });

  router.get('/cases', (request, response) => {
    const { sort, direction, maxResults, limit, offset, ...filter } = parse(caseQuerySchema, request.query);
    const key = sortKey('cases', sort);
    response.json(capped(read(request, (database, datasetId) => searchCases(database, datasetId, defined({ ...caseFilterFromQuery(filter), sort: key, direction, limit, offset }))), maxResults));
  });

  router.get('/case-groups', (request, response) => {
    const { groupBy, ...filter } = parse(caseGroupQuerySchema, request.query);
    response.json(read(request, (database, datasetId) => caseGroupCounts(database, datasetId, caseFilterFromQuery(filter), groupBy)));
  });

  router.get('/cases/:caseId', (request, response) => {
    const detail = read(request, (database, datasetId) => caseDetail(database, datasetId, request.params.caseId, documentReader(request)));
    if (detail === undefined) throw notFound('case');
    response.json(detail);
  });

  router.get('/documents', (request, response) => {
    const { sort, ...query } = parse(documentQuerySchema, request.query);
    const key = sortKey('documents', sort);
    response.json(read(request, (database, datasetId) => searchDocuments(database, datasetId, defined({ ...query, sort: key }), documentReader(request))));
  });

  router.get('/documents/:versionId/content', (request, response) => {
    const { binding, info } = institution(request);
    const document = store.read((database) => documentContent(database, binding.datasetId, request.params.versionId, documentReader(request)));
    if (document === undefined) throw notFound('document version');
    const extension = document.mediaType === 'application/pdf' ? 'pdf' : document.mediaType === 'text/csv' ? 'csv' : document.mediaType === 'image/png' ? 'png' : 'bin';
    response.setHeader('Content-Type', document.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${document.displayName.replace(/\.[a-z]+$/iu, '')}-v${document.version}.${extension}`));
    response.setHeader('X-Document-Digest', document.digest);
    response.setHeader('X-Document-Version', document.versionId);
    response.end(Buffer.from(document.bytes));
  });

  router.get('/activity', (request, response) => {
    const query = parse(activityQuerySchema, request.query);
    response.json(read(request, (database, datasetId) => listActivity(database, datasetId, defined(query))));
  });

  router.get('/receipts/:receiptNumber', (request, response) => {
    const receipt = read(request, (database, datasetId) => receiptByNumber(database, datasetId, request.params.receiptNumber));
    if (receipt === undefined) throw new HttpError(404, 'not_found', 'No receipt with that number exists at this institution.');
    response.json(receipt);
  });

  router.post('/stamps', (request, response) => {
    const body = parse(stampBodySchema, request.body);
    response.json(read(request, (database, datasetId) => recordStamps(database, datasetId, defined(body))));
  });

  router.get('/saved-searches', (request, response) => {
    const { entity } = parse(savedSearchQuerySchema, request.query);
    const { binding } = institution(request);
    const { actorId } = actorFor(request, response, binding);
    response.json(store.read((database) => listSavedSearches(database, binding.datasetId, actorId, entity)));
  });

  router.post('/exports/:grid', (request, response) => {
    const grid = gridParam(request);
    if (grid !== 'members' && grid !== 'accounts' && grid !== 'cases') throw new HttpError(404, 'unknown_grid', `The ${grid} grid cannot be exported as a selection.`);
    const body = parse(exportBodySchema, request.body);
    const known = GRID_COLUMNS[grid].map((column) => column.id);
    const unknown = body.columns.find((column) => !known.includes(column));
    if (unknown !== undefined) throw new HttpError(400, 'invalid_column', `The ${grid} grid has no ${unknown} column.`, 'columns');
    const columns = [...new Set(body.columns)];
    if (columns.some((column) => column.endsWith('_minor_units')) && !columns.includes('currency')) columns.push('currency');
    const { binding, info } = institution(request);
    const rows = store.read((database) => exportRows(database, binding.datasetId, grid, body.selection));
    const artifact = renderCsv({
      displayName: `${info.institutionId}-${grid}-selection.csv`, columns,
      rows: rows.map((row) => columns.map((column) => {
        const value = row[fieldOf(column)];
        return typeof value === 'number' || typeof value === 'string' ? value : typeof value === 'boolean' ? (value ? 'yes' : 'no') : '';
      })),
    });
    response.setHeader('Content-Type', 'text/csv; charset=utf-8');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${grid}-selection-${String(rows.length)}.csv`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.setHeader('X-Export-Count', String(rows.length));
    response.setHeader('X-Export-Mode', body.selection.mode);
    response.end(Buffer.from(artifact.bytes));
  });

  /** Which of the given records match a search, so the client can say how many selected records the search hides. */
  router.post('/membership/:grid', (request, response) => {
    const grid = gridParam(request);
    if (grid !== 'members' && grid !== 'accounts' && grid !== 'cases') throw new HttpError(404, 'unknown_grid', `The ${grid} grid has no selection membership.`);
    const { ids, filters } = parse(membershipBodySchema, request.body);
    const criteria = { ...filtersFor(grid, filters), ids: [...new Set(ids)], limit: 200 };
    const matching = read(request, (database, datasetId) => {
      const found: string[] = [];
      for (let offset = 0; offset < criteria.ids.length; offset += 200) {
        const page: PageResult<{ id: string }> = grid === 'members' ? searchMembers(database, datasetId, { ...criteria, offset })
          : grid === 'accounts' ? searchAccounts(database, datasetId, { ...criteria, offset }) : searchCases(database, datasetId, { ...criteria, offset });
        found.push(...page.items.map((item) => item.id));
      }
      return found;
    });
    response.json({ matching });
  });

  /** Resolves an export selection inside one read snapshot, refusing selections above the export limit. */
  const exportRows = (database: SqlDatabase, datasetId: string, grid: SearchEntity, selection: ExportSelection): Record<string, unknown>[] => {
    const tooLarge = (count: number): HttpError => new HttpError(413, 'export_too_large', `The selection holds ${count} records; exports are limited to ${exportLimit}. Narrow the search or select fewer records.`);
    if (selection.mode === 'ids') {
      const ids = [...new Set(selection.ids)];
      if (ids.length > exportLimit) throw tooLarge(ids.length);
      return ids.map((recordId) => {
        const row = grid === 'members' ? memberDetail(database, datasetId, recordId)?.member : grid === 'accounts' ? accountDetail(database, datasetId, recordId)?.account : caseDetail(database, datasetId, recordId)?.case;
        if (row === undefined) throw new HttpError(400, 'unknown_record', `Selected record ${recordId} does not exist at this institution.`, 'selection.ids');
        return { ...row };
      });
    }
    const criteria = filtersFor(grid, selection.filters);
    const key = selection.sort === null ? undefined : sortKey(grid, selection.sort.field);
    const sort = key === undefined || selection.sort === null ? {} : { sort: key, direction: selection.sort.direction };
    const excluded = new Set(selection.excludedIds);
    const page = (offset: number): PageResult<object> => grid === 'members' ? searchMembers(database, datasetId, { ...criteria, ...sort, limit: 200, offset })
      : grid === 'accounts' ? searchAccounts(database, datasetId, { ...criteria, ...sort, limit: 200, offset })
        : searchCases(database, datasetId, { ...criteria, ...sort, limit: 200, offset });
    const first = page(0);
    const excludedPresent = selection.excludedIds.length;
    if (first.total - excludedPresent > exportLimit) throw tooLarge(first.total - excludedPresent);
    const rows: Record<string, unknown>[] = [];
    for (let current = first, offset = 0; ; offset += 200, current = page(offset)) {
      for (const item of current.items) { const row = { ...item } as Record<string, unknown>; if (!excluded.has(String(row.id))) rows.push(row); }
      if (offset + 200 >= current.total) break;
    }
    if (rows.length > exportLimit) throw tooLarge(rows.length);
    return rows;
  };

  const documentReader = (request: Request) => { const reader=documentReaders.get(request); if(reader===undefined) throw new HttpError(403,'operator_unavailable','The request has no authorized operator.'); return reader; };

  const serviceContext = (request: Request, response: Response): Parameters<typeof executeCommand>[1] => {
    const { binding } = institution(request);
    const { actorId, ui } = actorFor(request, response, binding);
    return { binding, actorId, principalKind: options.principalKind ?? 'human', reference: `${APPLICATION_ID}:${ui.id.slice(0, 12)}` };
  };

  /** Decodes wire-only encodings (document bytes as base64) into the shapes the service contract declares. */
  const decodeCommand = (value: unknown): Record<string, unknown> => {
    const command = value as Record<string, unknown>;
    const bytes = command.bytes;
    if (bytes !== null && typeof bytes === 'object' && typeof (bytes as { base64?: unknown }).base64 === 'string') {
      const decoded = Buffer.from((bytes as { base64: string }).base64, 'base64');
      if (decoded.byteLength === 0) throw new HttpError(400, 'invalid_request', 'The document bytes are empty.', 'command.bytes');
      return { ...command, bytes: new Uint8Array(decoded) };
    }
    return command;
  };

  const checkedCommand = (value: unknown): Parameters<typeof executeCommand>[2] => {
    const command = decodeCommand(value);
    const invalid = validateServiceCommand(command);
    if (invalid !== null) throw new HttpError(400, invalid.code, invalid.message, invalid.field);
    return command as Parameters<typeof executeCommand>[2];
  };

  router.get('/records/:resource', (request, response) => {
    const query = parse(recordListQuerySchema, request.query);
    const result = listFinanceRecords(store, serviceContext(request, response), defined({ resource: request.params.resource, ...query }));
    if (result.kind === 'rejected') throw new HttpError(result.code === 'not_authorized' ? 403 : 400, result.code, result.message, result.field);
    response.json(result);
  });

  router.get('/records/:resource/:recordId', (request, response) => {
    const context = serviceContext(request, response);
    const result = queryFinance(store, context, { kind: 'finance.record', resource: request.params.resource as never, id: request.params.recordId });
    if (result.kind === 'found') { response.json(result.snapshot); return; }
    if (result.kind === 'rejected' && result.code === 'validation') {
      // Listed resources outside the finance record kinds (requests, consents, plans, versions, …) are
      // read through the bounded list query instead; they carry no service fingerprint.
      const listed = listFinanceRecords(store, context, { resource: request.params.resource, id: request.params.recordId, limit: 1, offset: 0 });
      if (listed.kind === 'listed' && listed.items.length === 1) {
        const row = listed.items[0];
        if (row === undefined) throw notFound('record');
        response.json({ kind: row.id, id: row.id, fingerprint: null, record: row.fields, observedAt: new Date().toISOString() });
        return;
      }
      if (listed.kind === 'listed') throw notFound('record');
      throw new HttpError(listed.code === 'not_authorized' ? 403 : 400, listed.code, listed.message, listed.field);
    }
    if (result.kind === 'rejected') throw new HttpError(result.code === 'not_authorized' ? 403 : result.code === 'not_found' ? 404 : 400, result.code, result.message, result.field);
    throw notFound('record');
  });

  router.post('/query/finance', (request, response) => {
    const { query } = parse(financeQueryBodySchema, request.body);
    const invalid = validateFinanceQuery(query);
    if (invalid !== null) throw new HttpError(400, invalid.code, invalid.message, invalid.field);
    response.json(queryFinance(store, serviceContext(request, response), query));
  });

  router.post('/query/core', (request, response) => {
    const { query } = parse(coreQueryBodySchema, request.body);
    response.json(queryCore(store, serviceContext(request, response), query as Parameters<typeof queryCore>[2]));
  });

  router.get('/approvals', (request, response) => {
    const result = listApprovals(store, serviceContext(request, response));
    if (result.kind === 'rejected') throw new HttpError(result.code === 'not_authorized' ? 403 : 400, result.code, result.message, result.field);
    response.json(result);
  });

  router.post('/servicing/read', (request, response) => {
    const { reader, args } = parse(servicingReadBodySchema, request.body);
    const context = serviceContext(request, response);
    const need = (key: string): string => {
      const value = args[key];
      if (typeof value !== 'string' || value === '') throw new HttpError(400, 'invalid_request', `The ${key} argument is required for ${reader}.`, `args.${key}`);
      return value;
    };
    const result: ServicingQueryResult<unknown> = store.read((database) => {
      switch (reader) {
        case 'identity-evidence': return listMemberIdentityEvidence(database, context, need('memberId'));
        case 'addresses': return listMemberAddresses(database, context, need('memberId'));
        case 'consents': return listMemberConsents(database, context, need('memberId'));
        case 'destinations': return listMemberAddressDestinations(database, context, need('memberId'));
        case 'preferences': return listMemberCommunicationPreferences(database, context, need('memberId'));
        case 'maintenance-requests': return listMemberMaintenanceRequests(database, context, need('memberId'));
        case 'maintenance-request': return maintenanceRequest(database, context, need('requestId'));
        case 'case-detail': return servicingCaseDetail(database, context, need('caseId'));
        case 'communication-jobs': return listMemberCommunicationJobs(database, context, need('memberId'));
        case 'communication-job': return communicationJob(database, context, need('jobId'));
        case 'document-versions': return listMemberDocumentVersions(database, context, need('memberId'), args.documentType ?? undefined);
        case 'signatures': return listDocumentSignatures(database, context, need('documentVersionId'));
        case 'annotations': return listDocumentAnnotations(database, context, need('documentVersionId'));
        case 'annotation': return documentAnnotation(database, context, need('annotationId'));
        case 'checkers': return listServicingApprovalCheckers(database, context, need('commandKind'));
        case 'queues': return listServicingQueues(database, context);
        case 'policies': return listEffectivePolicyVersions(database, context);
        case 'retention-holds': return listMemberRetentionHolds(database, context, need('memberId'));
        case 'correction-evidence': return listCaseSubjectCorrectionEvidence(database, context, need('originalMemberId'), need('correctedMemberId'));
        case 'historical-statement': return retrieveHistoricalStatement(database, context, need('accountId'), need('start'), need('through'), args.format ?? undefined);
        case 'customer-export': return retrieveCustomerExportArtifact(database, context, need('memberId'), need('versionId'));
      }
    });
    if (result.kind !== 'authorized') throw new HttpError(result.code === 'not_authorized' ? 403 : 400, result.code, result.message, result.field);
    response.json(result.value);
  });

  router.get('/identity-resolve', (request, response) => {
    const query = parse(identityResolveQuerySchema, request.query);
    const context = serviceContext(request, response);
    const result = store.read((database) => resolveMemberIdentity(database, context, defined(query)));
    if (result.kind !== 'authorized') throw new HttpError(result.code === 'not_authorized' ? 403 : 400, result.code, result.message, result.field);
    response.json(result.value);
  });

  router.get('/merge-plans/:planId', (request, response) => {
    const result = queryMemberMergePlan(store, serviceContext(request, response), request.params.planId);
    if (result.kind === 'rejected') throw new HttpError(result.code === 'not_authorized' ? 403 : result.code === 'not_found' ? 404 : 400, result.code, result.message);
    response.json(result);
  });

  router.get('/members/:memberId/exports/:versionId', (request, response) => {
    const context = serviceContext(request, response);
    const { info } = institution(request);
    const result = store.read((database) => retrieveCustomerExportArtifact(database, context, request.params.memberId, request.params.versionId));
    if (result.kind !== 'authorized') throw new HttpError(result.code === 'not_authorized' ? 403 : 400, result.code, result.message, result.field);
    if (result.value === undefined) throw notFound('customer export');
    const artifact = result.value;
    response.setHeader('Content-Type', artifact.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${request.params.memberId}-customer-export.json`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.end(Buffer.from(artifact.bytes));
  });

  router.get('/accounts/:accountId/statement-export', async (request, response) => {
    const { period, format, destination } = parse(statementExportQuerySchema, request.query);
    const { binding, info } = institution(request);
    const context = serviceContext(request, response);
    const detail = store.read((database) => accountDetail(database, binding.datasetId, request.params.accountId));
    if (detail === undefined) throw notFound('account');
    const result = await exportStatement(store, context, { memberId: detail.account.memberId, accountId: request.params.accountId, period, formats: [format], destinationId: destination }, options.exportDestinations ?? ['browser-download']);
    if (result.kind === 'rejected') throw new HttpError(result.code === 'not_authorized' ? 403 : result.code === 'not_found' ? 404 : 400, result.code, result.message, result.field);
    const artifact = result.artifacts[0];
    if (artifact === undefined) throw new HttpError(500, 'internal_error', 'The export produced no artifact.');
    response.setHeader('Content-Type', artifact.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${artifact.displayName}`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.setHeader('X-Statement-Source', result.source);
    response.setHeader('X-Statement-Observed-At', result.observedAt);
    response.end(Buffer.from(artifact.bytes));
  });

  router.post('/commands/review', (request, response) => {
    const { command } = parse(reviewBodySchema, request.body);
    response.json(reviewCommand(store, serviceContext(request, response), checkedCommand(command)));
  });

  router.post('/commands', (request, response) => {
    const { command, idempotencyKey } = parse(executeBodySchema, request.body);
    response.json(executeCommand(store, serviceContext(request, response), checkedCommand(command), idempotencyKey));
  });

  app.use('/api', (_request, _response, next) => { next(new HttpError(404, 'not_found', 'Unknown API route.')); });

  const publicDirectory = options.publicDirectory;
  if (publicDirectory !== undefined && existsSync(join(publicDirectory, 'index.html'))) {
    app.use(express.static(publicDirectory, { index: false, maxAge: '1h', setHeaders: (response, path) => { if (path.endsWith('.html')) response.setHeader('Cache-Control', 'no-store'); } }));
    app.get('/{*path}', (_request, response) => { response.setHeader('Cache-Control', 'no-store'); response.sendFile(join(publicDirectory, 'index.html')); });
  } else {
    app.get('/', (_request, response) => { response.status(503).type('text/plain').send('The workspace client is not built. Run npm run build in environments/virtualized-service-workspace.'); });
  }

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    const failure = error instanceof HttpError ? error
      : error instanceof RangeError ? new HttpError(400, 'invalid_request', error.message)
        : error instanceof SyntaxError ? new HttpError(400, 'invalid_json', 'The request body is not valid JSON.')
          : new HttpError(500, 'internal_error', 'The workspace backend failed to complete the request.');
    if (failure.status === 500) console.error(error);
    const body: ApiErrorBody = { error: { code: failure.code, message: failure.message, ...(failure.field === undefined ? {} : { field: failure.field }) } };
    response.status(failure.status).json(body);
  });
  return app;
}

/**
 * Starts the workspace on a loopback listener. The caller owns the store: the CLI closes its shared
 * connection in `onClose`, while an evaluator keeps its verification run alive after the listener stops.
 */
export async function startWorkspace(options: WorkspaceOptions): Promise<WorkspaceHandle> {
  const app = createWorkspaceApp(options);
  const host = options.host ?? '127.0.0.1';
  const server: Server = createServer(app);
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(options.port ?? 4350, host, () => { server.off('error', reject); resolve(); });
  });
  const address = server.address();
  if (address === null || typeof address === 'string') throw new Error('Listener has no TCP address.');
  const origin = `http://${host}:${String(address.port)}`;
  let closing: Promise<void> | undefined;
  return {
    origin,
    close() {
      closing ??= new Promise<void>((resolve, reject) => {
        server.closeIdleConnections();
        const force = setTimeout(() => server.closeAllConnections(), 2_000);
        server.close((error) => {
          clearTimeout(force);
          try { options.onClose?.(); } catch (closeError) { reject(closeError instanceof Error ? closeError : new Error(String(closeError))); return; }
          if (error === undefined) resolve(); else reject(error);
        });
      });
      return closing;
    },
  };
}
