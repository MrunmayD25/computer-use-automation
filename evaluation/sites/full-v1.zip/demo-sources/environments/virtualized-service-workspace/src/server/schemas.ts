import { z } from 'zod';

import { COLUMN_WIDTH_LIMITS } from '../shared/columns.js';

const id = z.string().min(1).max(200);
const filterValue = z.union([z.string().max(200), z.boolean(), z.array(z.string().max(200)).max(20)]);
const sortKey = z.strictObject({ field: z.string().max(60), direction: z.enum(['asc', 'desc']) });

/**
 * Commands are validated by the shared `validateServiceCommand` at the service boundary; this schema
 * only guarantees an object arrives. Document bytes travel as `{ base64 }` and are decoded before
 * validation so the service sees the exact `Uint8Array` its contract declares.
 */
export const commandSchema = z.unknown().refine((value) => value !== null && typeof value === 'object' && !Array.isArray(value), 'A command must be an object.');

export const executeBodySchema = z.strictObject({ command: commandSchema, idempotencyKey: z.string().regex(/^[A-Za-z0-9._:-]{8,128}$/u) });
export const reviewBodySchema = z.strictObject({ command: commandSchema });
export const operatorBodySchema = z.strictObject({ actorNumber: z.string().regex(/^[A-Z]{2}\d{4}$/u) });
export const stampBodySchema = z.strictObject({ members: z.array(id).max(100).optional(), accounts: z.array(id).max(100).optional(), cases: z.array(id).max(100).optional() });

const limit = z.coerce.number().int().min(1).max(200).default(50);
const offset = z.coerce.number().int().min(0).max(1_000_000).default(0);
const direction = z.enum(['asc', 'desc']).optional();
const optionalText = z.string().max(200).optional();
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/u).optional();
const optionalAmount = z.coerce.number().int().min(0).max(1_000_000_000_000).optional();
const maxResults = z.coerce.number().int().min(1).max(10_000).optional();
const commaList = z.string().max(2_000).optional();

export const memberQuerySchema = z.strictObject({ query: optionalText, status: optionalText, sort: optionalText, direction, maxResults, limit, offset });
export const accountQuerySchema = z.strictObject({ memberId: optionalText, query: optionalText, status: optionalText, currency: optionalText, sort: optionalText, direction, maxResults, limit, offset });
export const caseFilterSchema = z.strictObject({
  memberId: optionalText, accountId: optionalText, states: commaList, queueIds: commaList, assignedActorId: optionalText, priority: optionalText,
  overdue: z.enum(['true', 'false']).optional(), query: optionalText,
});
export const caseQuerySchema = caseFilterSchema.extend({ sort: optionalText, direction, maxResults, limit, offset });
export const caseGroupQuerySchema = caseFilterSchema.extend({ groupBy: z.enum(['state', 'queue', 'priority', 'assignee']) });
export const transactionQuerySchema = z.strictObject({
  startDate: isoDate, endDate: isoDate, direction: z.enum(['credit', 'debit']).optional(), minMinorUnits: optionalAmount, maxMinorUnits: optionalAmount,
  text: optionalText, reference: optionalText, order: z.enum(['newest', 'oldest']).optional(), status: z.enum(['posted', 'reversed']).optional(), limit, offset,
});
export const exportQuerySchema = z.strictObject({ startDate: isoDate, endDate: isoDate });
export const statementQuerySchema = z.strictObject({ period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/u) });
export const activityQuerySchema = z.strictObject({ memberId: optionalText, accountId: optionalText, caseId: optionalText, kind: optionalText, actorId: optionalText, query: optionalText, limit, offset });
export const documentQuerySchema = z.strictObject({ query: optionalText, documentType: optionalText, memberId: optionalText, accountId: optionalText, sort: optionalText, direction, limit, offset });
export const savedSearchQuerySchema = z.strictObject({ entity: z.enum(['members', 'accounts', 'cases']).optional() });

const width = z.number().int().min(COLUMN_WIDTH_LIMITS.min).max(COLUMN_WIDTH_LIMITS.max);
export const columnLayoutSchema = z.strictObject({
  order: z.array(z.string().max(60)).max(40),
  widths: z.record(z.string().max(60), width),
  hidden: z.array(z.string().max(60)).max(40),
  pinned: z.array(z.string().max(60)).max(40),
});

export const exportBodySchema = z.strictObject({
  selection: z.discriminatedUnion('mode', [
    z.strictObject({ mode: z.literal('ids'), ids: z.array(id).min(1).max(10_000) }),
    z.strictObject({ mode: z.literal('matching'), filters: z.record(z.string().max(60), filterValue), sort: sortKey.nullable(), excludedIds: z.array(id).max(10_000) }),
  ]),
  columns: z.array(z.string().max(60)).min(1).max(40),
});

export const membershipBodySchema = z.strictObject({ ids: z.array(id).max(500), filters: z.record(z.string().max(60), filterValue) });

const recordLimit = z.coerce.number().int().min(1).max(500).default(100);
export const recordListQuerySchema = z.strictObject({
  memberId: optionalText, accountId: optionalText, parentId: optionalText, state: optionalText, query: optionalText,
  dateFrom: isoDate, dateThrough: isoDate, limit: recordLimit, offset,
});
/** Finance and reconciliation inquiries are validated by the shared `validateFinanceQuery`. */
export const financeQueryBodySchema = z.strictObject({ query: z.unknown().refine((value) => value !== null && typeof value === 'object' && !Array.isArray(value), 'A query must be an object.') });
export const coreQueryBodySchema = financeQueryBodySchema;

const servicingReaders = [
  'identity-evidence', 'addresses', 'consents', 'destinations', 'preferences', 'maintenance-requests', 'maintenance-request',
  'case-detail', 'communication-jobs', 'communication-job', 'document-versions', 'signatures', 'annotations', 'annotation',
  'checkers', 'queues', 'policies', 'retention-holds', 'correction-evidence', 'historical-statement', 'customer-export',
] as const;
export type ServicingReaderName = (typeof servicingReaders)[number];
export const servicingReadBodySchema = z.strictObject({
  reader: z.enum(servicingReaders),
  /** Reader arguments, text or null; each reader names which keys it consumes. */
  args: z.record(z.string().max(40), z.union([z.string().max(400), z.null()])).default({}),
});
export const statementExportQuerySchema = z.strictObject({ period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/u), format: z.enum(['html', 'pdf', 'csv']), destination: id });
export const identityResolveQuerySchema = z.strictObject({ memberNumber: optionalText, displayName: optionalText, birthDate: isoDate, email: optionalText, phone: optionalText });

/** Removes absent optional properties so parsed values satisfy exact optional property types. */
export function defined<T extends Record<string, unknown>>(value: T): { [K in keyof T]: Exclude<T[K], undefined> } {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined)) as { [K in keyof T]: Exclude<T[K], undefined> };
}
