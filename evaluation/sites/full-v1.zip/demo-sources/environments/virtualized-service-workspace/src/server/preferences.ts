import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';

import type { ColumnLayout } from '../shared/api.js';
import { columnIds, type GridId } from '../shared/columns.js';

/**
 * Per-operator grid presentation. It is application state, not business data, so it never enters the
 * shared financial database and a verification run never captures it.
 */
export interface PreferenceStore {
  get(operator: string, grid: GridId): ColumnLayout | null;
  put(operator: string, grid: GridId, layout: ColumnLayout): void;
  remove(operator: string, grid: GridId): void;
}

type Stored = Record<string, Partial<Record<GridId, ColumnLayout>>>;

const MAX_OPERATORS = 1_000;

/** Rejects layouts that name unknown columns, repeat a column or omit one from the order. */
export function layoutProblem(grid: GridId, layout: ColumnLayout): string | null {
  const known = columnIds(grid);
  const knownSet = new Set(known);
  const all = [...layout.order, ...layout.hidden, ...layout.pinned, ...Object.keys(layout.widths)];
  const unknown = all.find((column) => !knownSet.has(column));
  if (unknown !== undefined) return `The ${grid} grid has no ${unknown} column.`;
  if (new Set(layout.order).size !== layout.order.length || layout.order.length !== known.length) return `The column order must list each ${grid} column exactly once.`;
  if (new Set(layout.hidden).size !== layout.hidden.length || new Set(layout.pinned).size !== layout.pinned.length) return 'A column may be hidden or pinned only once.';
  if (layout.hidden.length >= known.length) return 'At least one column must stay visible.';
  return null;
}

export function memoryPreferenceStore(): PreferenceStore {
  const stored: Stored = {};
  return {
    get: (operator, grid) => stored[operator]?.[grid] ?? null,
    put: (operator, grid, layout) => { (stored[operator] ??= {})[grid] = layout; },
    remove: (operator, grid) => { const entry = stored[operator]; if (entry !== undefined) Reflect.deleteProperty(entry, grid); },
  };
}

/** A JSON file rewritten atomically on every change. Unreadable files are reported, never silently replaced. */
export function filePreferenceStore(path: string): PreferenceStore {
  let stored: Stored = {};
  if (existsSync(path)) {
    const parsed: unknown = JSON.parse(readFileSync(path, 'utf8'));
    if (parsed === null || typeof parsed !== 'object' || !('operators' in parsed) || parsed.operators === null || typeof parsed.operators !== 'object') {
      throw new Error(`Preference file ${path} is not a workspace preference file.`);
    }
    stored = parsed.operators as Stored;
  }
  const persist = (): void => {
    mkdirSync(dirname(path), { recursive: true });
    const pending = `${path}.${String(process.pid)}.tmp`;
    writeFileSync(pending, `${JSON.stringify({ version: 1, operators: stored }, null, 2)}\n`);
    renameSync(pending, path);
  };
  return {
    get: (operator, grid) => stored[operator]?.[grid] ?? null,
    put(operator, grid, layout) {
      if (stored[operator] === undefined && Object.keys(stored).length >= MAX_OPERATORS) throw new Error('The preference file already holds the maximum number of operators.');
      (stored[operator] ??= {})[grid] = layout;
      persist();
    },
    remove(operator, grid) {
      const entry = stored[operator];
      if (entry === undefined || entry[grid] === undefined) return;
      Reflect.deleteProperty(entry, grid);
      persist();
    },
  };
}
