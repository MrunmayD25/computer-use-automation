import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';

import { startWorkspace } from './app.js';
import { filePreferenceStore } from './preferences.js';

const here = dirname(fileURLToPath(import.meta.url));
const packageRoot = resolve(here, '..', '..');
const defaultDatabase = resolve(packageRoot, '..', 'database', 'financial', '.runtime', 'financial.sqlite');
const defaultPreferences = resolve(packageRoot, '.runtime', 'preferences.json');

const usage = `Usage: node dist/server/main.js [options]
  --port <n>            Listener port (default 4350, or VSW_PORT)
  --host <address>      Listener address (default 127.0.0.1)
  --database <path>     Seeded financial SQLite file (default ${defaultDatabase}, or FINANCIAL_DATABASE_PATH)
  --world <name>        Named world to bind (default ${DEFAULT_SEED_MANIFEST.name})
  --operators <list>    Comma-separated operator actor numbers allowed to sign on (default OP0002,OP0003,OP0005,OP0001)
  --preferences <path>  Per-operator column layout file (default ${defaultPreferences}, or VSW_PREFERENCES)
  --verbose             Log each request with status and latency`;

const { values } = parseArgs({
  options: {
    port: { type: 'string' }, host: { type: 'string' }, database: { type: 'string' }, world: { type: 'string' }, operators: { type: 'string' },
    preferences: { type: 'string' }, verbose: { type: 'boolean', default: false }, help: { type: 'boolean', default: false },
  },
  strict: true,
});
if (values.help) { console.log(usage); process.exit(0); }

const port = Number(values.port ?? process.env.VSW_PORT ?? 4350);
if (!Number.isInteger(port) || port < 0 || port > 65_535) throw new Error(`Invalid port ${String(values.port)}.\n${usage}`);
const databasePath = resolve(values.database ?? process.env.FINANCIAL_DATABASE_PATH ?? defaultDatabase);
if (!existsSync(databasePath)) {
  throw new Error(`Financial database ${databasePath} does not exist. Seed it once with:\n  npm --prefix environments/database/financial run seed -- --path ${databasePath}`);
}
const worldName = values.world ?? DEFAULT_SEED_MANIFEST.name;
const bindings = (() => {
  using database = openFinancialDatabase({ path: databasePath });
  return database.getNamedWorld(worldName);
})();
if (bindings.length === 0) throw new Error(`World ${worldName} is not seeded in ${databasePath}. The workspace never seeds shared data itself.`);
const actorNumbers = (values.operators ?? 'OP0002,OP0003,OP0005,OP0001').split(',').map((value) => value.trim()).filter((value) => value.length > 0);
const preferencesPath = resolve(values.preferences ?? process.env.VSW_PREFERENCES ?? defaultPreferences);

const store = openFinancialStore({ path: databasePath });
const handle = await startWorkspace({
  store, bindings, mode: 'shared', operator: { actorNumbers, fixed: false }, preferences: filePreferenceStore(preferencesPath),
  publicDirectory: join(packageRoot, 'dist', 'public'), host: values.host ?? '127.0.0.1', port, verbose: values.verbose,
  onClose: () => { store.close(); },
});
console.log(`Virtualized service workspace listening on ${handle.origin} (${bindings.map((binding) => binding.institutionId).join(', ')})`);
if (values.verbose) console.error(`Database ${databasePath}; preferences ${preferencesPath}`);

let stopping = false;
const stop = (signal: string): void => {
  if (stopping) return;
  stopping = true;
  if (values.verbose) console.error(`Received ${signal}; closing listener and database.`);
  handle.close().then(() => process.exit(0), (error: unknown) => { console.error(error); process.exit(1); });
};
process.once('SIGINT', () => { stop('SIGINT'); });
process.once('SIGTERM', () => { stop('SIGTERM'); });
