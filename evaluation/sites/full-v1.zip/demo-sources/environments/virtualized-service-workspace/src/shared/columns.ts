/**
 * Column vocabulary of every workspace grid. Member, account and case column ids are the stored field
 * names of the shared saved-search vocabulary, so a saved search and a grid layout name the same fields.
 */

export type GridId =
  | 'members' | 'accounts' | 'cases' | 'activity' | 'documents' | 'transactions'
  | 'payments' | 'schedules' | 'beneficiaries' | 'cards' | 'disputes' | 'loans' | 'fees' | 'holds'
  | 'maintenance' | 'communications' | 'approvals' | 'batches' | 'suspense' | 'settlements';
export type SearchEntity = 'members' | 'accounts' | 'cases';

export interface ColumnSpec {
  id: string;
  label: string;
  /** Default width in CSS pixels. */
  width: number;
  align?: 'end';
  /** Shown only after the operator chooses it in the column menu. */
  hiddenByDefault?: boolean;
  /** Pinned to the left edge by default. */
  pinnedByDefault?: boolean;
}

export const COLUMN_WIDTH_LIMITS = { min: 64, max: 640 } as const;

export const GRID_COLUMNS: Readonly<Record<GridId, readonly ColumnSpec[]>> = {
  members: [
    { id: 'member_number', label: 'Member #', width: 120, pinnedByDefault: true },
    { id: 'display_name', label: 'Name', width: 220 },
    { id: 'kind', label: 'Party', width: 110 },
    { id: 'status', label: 'Status', width: 110 },
    { id: 'email', label: 'Email', width: 240 },
    { id: 'phone', label: 'Phone', width: 160 },
    { id: 'open_accounts', label: 'Open accounts', width: 130, align: 'end' },
    { id: 'joined_at', label: 'Joined', width: 130 },
    { id: 'version', label: 'Version', width: 90, align: 'end', hiddenByDefault: true },
  ],
  accounts: [
    { id: 'account_number', label: 'Account #', width: 130, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'owner_name', label: 'Owner', width: 210 },
    { id: 'product_code', label: 'Product code', width: 150 },
    { id: 'product_name', label: 'Product', width: 210 },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'status', label: 'Status', width: 110 },
    { id: 'nickname', label: 'Nickname', width: 210 },
    { id: 'statement_delivery', label: 'Statements', width: 140 },
    { id: 'posted_minor_units', label: 'Posted balance', width: 170, align: 'end' },
    { id: 'available_minor_units', label: 'Available balance', width: 170, align: 'end' },
    { id: 'opened_at', label: 'Opened', width: 130 },
    { id: 'closed_at', label: 'Closed', width: 130 },
    { id: 'version', label: 'Version', width: 90, align: 'end' },
  ],
  cases: [
    { id: 'case_number', label: 'Case #', width: 120, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'member_name', label: 'Member', width: 200 },
    { id: 'account_number', label: 'Account #', width: 130 },
    { id: 'queue_code', label: 'Queue', width: 130 },
    { id: 'assigned_name', label: 'Assignee', width: 180 },
    { id: 'state', label: 'Status', width: 150 },
    { id: 'priority', label: 'Priority', width: 110 },
    { id: 'category', label: 'Category', width: 190 },
    { id: 'summary', label: 'Summary', width: 320 },
    { id: 'opened_at', label: 'Opened', width: 130 },
    { id: 'due_at', label: 'Due', width: 150 },
    { id: 'overdue', label: 'Overdue', width: 100 },
    { id: 'version', label: 'Version', width: 90, align: 'end', hiddenByDefault: true },
  ],
  activity: [
    { id: 'sequence', label: 'Event #', width: 100, align: 'end', pinnedByDefault: true },
    { id: 'occurred_at', label: 'When', width: 190 },
    { id: 'kind', label: 'Operation', width: 220 },
    { id: 'resource_kind', label: 'Record type', width: 130 },
    { id: 'summary', label: 'Summary', width: 460 },
    { id: 'actor', label: 'Operator', width: 190 },
    { id: 'receipt_number', label: 'Receipt', width: 140 },
  ],
  documents: [
    { id: 'display_name', label: 'Document', width: 260, pinnedByDefault: true },
    { id: 'document_type', label: 'Type', width: 190 },
    { id: 'issued_at', label: 'Issued', width: 150 },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'owner_name', label: 'Owner', width: 200 },
    { id: 'account_number', label: 'Account #', width: 130 },
    { id: 'period', label: 'Period', width: 200 },
    { id: 'version', label: 'Version', width: 90, align: 'end' },
    { id: 'media_type', label: 'Format', width: 150 },
    { id: 'byte_length', label: 'Size', width: 110, align: 'end' },
    { id: 'digest', label: 'SHA-256', width: 200, hiddenByDefault: true },
  ],
  transactions: [
    { id: 'effective_date', label: 'Date', width: 120, pinnedByDefault: true },
    { id: 'reference', label: 'Reference', width: 150 },
    { id: 'description', label: 'Description', width: 280 },
    { id: 'amount', label: 'Amount', width: 150, align: 'end' },
    { id: 'running_balance', label: 'Running balance', width: 170, align: 'end' },
    { id: 'status', label: 'Status', width: 110 },
    { id: 'counterparty', label: 'Counterparty', width: 240 },
    { id: 'operation_kind', label: 'Operation', width: 180 },
    { id: 'receipt_number', label: 'Receipt', width: 140 },
  ],
  payments: [
    { id: 'reference', label: 'Reference', width: 150, pinnedByDefault: true },
    { id: 'account_number', label: 'Source account', width: 140 },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'owner_name', label: 'Owner', width: 190 },
    { id: 'beneficiary_name', label: 'Beneficiary', width: 190 },
    { id: 'masked_destination', label: 'Destination', width: 170 },
    { id: 'amount_minor_units', label: 'Amount', width: 140, align: 'end' },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'requested_date', label: 'Requested', width: 120 },
    { id: 'state', label: 'Status', width: 150 },
    { id: 'version', label: 'Version', width: 90, align: 'end', hiddenByDefault: true },
  ],
  schedules: [
    { id: 'account_number', label: 'Source account', width: 140, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'beneficiary_name', label: 'Beneficiary', width: 200 },
    { id: 'rule', label: 'Rule', width: 240 },
    { id: 'start_date', label: 'Starts', width: 120 },
    { id: 'end_date', label: 'Ends', width: 120 },
    { id: 'occurrences', label: 'Occurrences', width: 120, align: 'end' },
    { id: 'state', label: 'Status', width: 120 },
  ],
  beneficiaries: [
    { id: 'display_name', label: 'Beneficiary', width: 230, pinnedByDefault: true },
    { id: 'owner_member_number', label: 'Member #', width: 120 },
    { id: 'status', label: 'Status', width: 130 },
  ],
  cards: [
    { id: 'account_number', label: 'Account', width: 140, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'last_four', label: 'Card', width: 110 },
    { id: 'expiry_month', label: 'Exp. month', width: 110, align: 'end' },
    { id: 'expiry_year', label: 'Exp. year', width: 100, align: 'end' },
    { id: 'status', label: 'Status', width: 150 },
  ],
  disputes: [
    { id: 'case_number', label: 'Dispute #', width: 130, pinnedByDefault: true },
    { id: 'account_number', label: 'Account', width: 140 },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'claimed_amount_minor_units', label: 'Claimed', width: 140, align: 'end' },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'state', label: 'Status', width: 150 },
    { id: 'deadline', label: 'Deadline', width: 130 },
  ],
  loans: [
    { id: 'account_number', label: 'Loan account', width: 150, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'principal_minor_units', label: 'Principal', width: 150, align: 'end' },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'annual_rate_bps', label: 'Rate (bps)', width: 110, align: 'end' },
    { id: 'state', label: 'Status', width: 120 },
    { id: 'opened_at', label: 'Opened', width: 150 },
  ],
  fees: [
    { id: 'account_number', label: 'Account', width: 140, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'journal_id', label: 'Journal', width: 210 },
    { id: 'original_amount_minor_units', label: 'Amount', width: 130, align: 'end' },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'refunded_minor_units', label: 'Refunded', width: 120, align: 'end' },
    { id: 'state', label: 'Status', width: 120 },
  ],
  holds: [
    { id: 'account_number', label: 'Account', width: 140, pinnedByDefault: true },
    { id: 'amount_minor_units', label: 'Amount', width: 140, align: 'end' },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'state', label: 'Status', width: 120 },
    { id: 'reason', label: 'Reason', width: 260 },
    { id: 'release_authority', label: 'Release authority', width: 180 },
    { id: 'placed_at', label: 'Placed', width: 160 },
    { id: 'expires_at', label: 'Expires', width: 160 },
  ],
  maintenance: [
    { id: 'request_number', label: 'Request #', width: 130, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'category', label: 'Category', width: 170 },
    { id: 'subject', label: 'Subject', width: 260 },
    { id: 'state', label: 'Status', width: 140 },
    { id: 'created_at', label: 'Created', width: 160 },
    { id: 'updated_at', label: 'Updated', width: 160 },
  ],
  communications: [
    { id: 'purpose', label: 'Purpose', width: 180, pinnedByDefault: true },
    { id: 'member_number', label: 'Member #', width: 120 },
    { id: 'channel', label: 'Channel', width: 120 },
    { id: 'destination', label: 'Destination', width: 220 },
    { id: 'state', label: 'Status', width: 120 },
    { id: 'created_at', label: 'Created', width: 160 },
  ],
  approvals: [
    { id: 'target_kind', label: 'Operation', width: 240, pinnedByDefault: true },
    { id: 'maker_name', label: 'Requested by', width: 190 },
    { id: 'checker_name', label: 'Checker', width: 190 },
    { id: 'status', label: 'Status', width: 120 },
    { id: 'amount_minor_units', label: 'Amount limit', width: 140, align: 'end' },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'expires_at', label: 'Expires', width: 170 },
    { id: 'fingerprint', label: 'Fingerprint', width: 200, hiddenByDefault: true },
  ],
  batches: [
    { id: 'batch_number', label: 'Batch #', width: 130, pinnedByDefault: true },
    { id: 'kind', label: 'Kind', width: 150 },
    { id: 'state', label: 'Status', width: 200 },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'items', label: 'Items', width: 90, align: 'end' },
    { id: 'created_at', label: 'Created', width: 160 },
  ],
  suspense: [
    { id: 'journal_reference', label: 'Journal', width: 190, pinnedByDefault: true },
    { id: 'original_amount_minor_units', label: 'Original', width: 140, align: 'end' },
    { id: 'remaining_amount_minor_units', label: 'Remaining', width: 140, align: 'end' },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'state', label: 'Status', width: 150 },
    { id: 'evidence_reference', label: 'Evidence', width: 220 },
  ],
  settlements: [
    { id: 'reference', label: 'Batch', width: 140, pinnedByDefault: true },
    { id: 'currency', label: 'Currency', width: 100 },
    { id: 'declared_total_minor_units', label: 'Declared total', width: 160, align: 'end' },
    { id: 'state', label: 'Status', width: 130 },
    { id: 'cutoff_at', label: 'Cutoff', width: 170 },
  ],
};

/** Sortable column ids of each grid mapped to the server's list-query sort key. */
export const GRID_SORTS: Readonly<Record<GridId, Readonly<Record<string, string>>>> = {
  members: { member_number: 'memberNumber', display_name: 'name', status: 'status', joined_at: 'joined' },
  accounts: {
    account_number: 'accountNumber', member_number: 'memberNumber', owner_name: 'owner', product_code: 'product', status: 'status', nickname: 'nickname',
    posted_minor_units: 'posted', available_minor_units: 'available', opened_at: 'opened',
  },
  cases: { case_number: 'caseNumber', due_at: 'due', opened_at: 'opened', state: 'state', priority: 'priority', member_number: 'member', queue_code: 'queue', assigned_name: 'assignee' },
  activity: {},
  documents: { issued_at: 'issued', document_type: 'type', member_number: 'member', account_number: 'account', display_name: 'name' },
  transactions: { effective_date: 'date' },
  payments: {}, schedules: {}, beneficiaries: {}, cards: {}, disputes: {}, loans: {}, fees: {}, holds: {},
  maintenance: {}, communications: {}, approvals: {}, batches: {}, suspense: {}, settlements: {},
};

export function isGridId(value: string): value is GridId {
  return Object.hasOwn(GRID_COLUMNS, value);
}

/** The camel-case property of a list row that holds a stored field, for example `posted_minor_units` → `postedMinorUnits`. */
export function fieldOf(column: string): string {
  return column.replace(/_([a-z])/gu, (_match, letter: string) => letter.toUpperCase());
}

export function columnIds(grid: GridId): string[] {
  return GRID_COLUMNS[grid].map((column) => column.id);
}
