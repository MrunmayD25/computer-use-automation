/** Wire types shared by the workspace client and its backend. Business shapes come from the financial services. */

import type { GridId } from './columns.js';

export const APPLICATION_ID = 'virtualized-service-workspace';

export interface InstitutionInfo {
  institutionId: string;
  displayName: string;
  legalName: string;
  timeZone: string;
  defaultCurrency: string;
  asOf: string;
}

export interface OperatorInstitutionProfile {
  actorId: string;
  actorNumber: string;
  displayName: string;
  status: string;
  roles: string[];
  permissions: string[];
  /** Command kinds this operator may run here, derived on the server from the shared capability grants. */
  commands: string[];
  /** Whether saved searches created here may be shared with the team. */
  canShareSearches: boolean;
}

export interface OperatorChoice {
  actorNumber: string;
  displayName: string;
  roles: string[];
}

export interface SessionInfo {
  applicationId: typeof APPLICATION_ID;
  applicationVersion: string;
  mode: 'shared' | 'verification';
  institutions: InstitutionInfo[];
  operator: { actorNumber: string; profiles: Record<string, OperatorInstitutionProfile | null> };
  /** Configured sign-on identities; empty when the backend fixes the operator. */
  operatorChoices: OperatorChoice[];
  /** Largest selection an export resolves before refusing rather than truncating. */
  exportLimit: number;
}

export interface ApiErrorBody {
  error: { code: string; message: string; field?: string };
}

/** Per-operator presentation of one grid. Column ids come from `GRID_COLUMNS`. */
export interface ColumnLayout {
  order: string[];
  widths: Record<string, number>;
  hidden: string[];
  pinned: string[];
}

export interface PreferenceResponse {
  grid: GridId;
  layout: ColumnLayout | null;
}

/** Which records an export covers: explicit identities, or every record matching a search at export time. */
export type ExportSelection =
  | { mode: 'ids'; ids: string[] }
  | { mode: 'matching'; filters: Record<string, string | boolean | string[]>; sort: { field: string; direction: 'asc' | 'desc' } | null; excludedIds: string[] };

export interface ExportRequest {
  selection: ExportSelection;
  columns: string[];
}
