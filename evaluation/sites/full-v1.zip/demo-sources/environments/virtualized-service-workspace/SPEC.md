# Virtualized service workspace specification

## Identity and scope

Application 5 of the environment set, listed as number 4 of the additional applications in the environment catalog (historical material omitted from this bundle). It is a single-page service workspace in the style of a data-heavy CRM. Its difficulty comes from real row and column virtualization with recycled DOM nodes, independently scrolling panels, editors and menus rendered in portal layers, and several record tabs open at once. The business rules are the shared ones. The workspace adds presentation, navigation and per-operator column layouts, and nothing else.

## Shared data

- All reads and writes go through `@computer-use/financial-database/services` against one SQLite file. The workspace never writes tables itself and never seeds or resets data on startup.
- Reads are bounded. List pages hold at most 100 rows, identity membership checks at most 500 ids, and exports at most the configured limit (5,000 by default). A larger request is refused with the reason, never truncated.
- Money is exact minor units with an explicit currency and exponent. Amounts typed by the operator are parsed digit by digit, never through floating point.
- Every record command carries the version the operator reviewed. The shared stale-review check rejects a mismatch as `stale_version`, and the workspace never retries around it.
- Column layouts are presentation state. They live in a separate preferences file keyed by operator, never in the financial database.

## Operator identity

The server session holds an operator number, and the server resolves the actor per institution. The browser never supplies an actor id. Commands the operator's roles do not grant are disabled with the reason. In verification mode the operator and principal kind come from trusted options, sign-on changes are refused, and the context bar shows "Verification run".

## Modules

| Module | Operations |
| --- | --- |
| Members | Browse, search, inquiry, create, contact maintenance, notes |
| Accounts | List, inquiry, open, nickname and statement-delivery maintenance, zero-balance closure with eligibility reasons |
| Money | Transaction history with date, direction, status, amount-band, text and exact-reference filters; deposits, withdrawals and internal transfers with review, confirmation and receipts |
| Statements | Stored document downloads, generated statement PDFs, transaction CSV, list exports; navigation to owner and account |
| Activity | Audit events filtered by operation or text, opening receipts and affected records |
| Service cases | Create, inspect, assign, change status, notes, link or unlink an account, group by status, queue, priority or assignee |
| Saved searches | Create, rename, update, delete and reopen member, account and case searches, private or shared, with filters, sort, columns and an optional result limit |
| Columns | Reorder, resize, hide, show and pin per grid, persisted per operator |

## Workspace mechanisms

1. **Virtualization.** Rows and columns are virtualized with overscan. Only the rows and scrolling columns near the viewport exist in the DOM. Pinned columns stay in place with sticky positioning.
2. **Recycling by identity.** Row and cell nodes are recycled through slot keys. Every node carries `data-row-id`, and every consumer resolves records by that id, never by index or node.
3. **Reachability.** Every record is reachable by scrolling, paging, "Go to row" or Ctrl+End. Pages load on demand, and unloaded rows show as pending rows.
4. **Groups and panels.** Case lists group into collapsible headers that are themselves virtualized rows. The list, preview and record panels scroll independently.
5. **Editing.** Inline cell editors and row, column, selection and saved-search menus render in portals outside the grid.
6. **Navigation.** Every list state and record has a URL. Back and Forward restore lists with their scroll position. Record tabs stay mounted and are capped at 12, closing the least recently used.
7. **Draft states.** Each record's edit is a draft with a phase: draft, pending, unknown, rejected or committed. Drafts outlive editors and rows and are listed in the Changes panel.
8. **Selection.** Selection is by record id. A selection hidden by the current search is explained by record. "Select all N matching" selects the whole result set, not only loaded rows, and is cleared when the search changes.
9. **Latest wins.** A response for an older search, record or page never replaces a newer one.
10. **Moving edits.** When an edited row scrolls away, is sorted elsewhere or leaves the results, its editor docks with explicit "Scroll to row", "Keep as draft" and "Cancel edit" choices. It never attaches to whichever record now occupies the old node.
11. **Portal positioning.** Portals follow their anchor on every frame. A menu closes when its anchor row is recycled, and focus returns to its owner.
12. **Keyboard.** The grid is a single tab stop with an active cell. Arrows, Page keys, Home and End move. Enter opens or edits, F2 edits, Space selects, Shift+F10 opens the row menu, and Alt+Shift+arrows move a column. The context bar always shows the institution, member, account and operator in view.

## Editing and submission rules

- Money commands and account closure show a review of current terms before confirmation. Nothing is written until the operator confirms.
- The idempotency key is fixed when review starts. A repeated click, Enter or retry after a lost response sends the same key and returns the first receipt as "Already applied".
- A lost response is reported as an unknown outcome with a safe retry, never as success or failure.
- Inline draft saves use one key per save attempt, reused for its retries.
- A stale draft is rejected with the current version. "Use current version" rebases the draft on it and keeps the operator's fields.
- Operator switching is disabled while drafts exist, because drafts are saved as the operator who submits them.

## Evaluator integration

The server is created from explicit options: a store, bindings, an operator policy, a mode and a preference store. An evaluator passes `verificationRunStore(run)` as the store, fixes the operator and sets the principal kind to `automation`. Closing the workspace detaches from the run and never disposes the evaluator's database. Task contracts, expected results and grading live under `evaluation/`. The application does not import them.

## Completion criteria

- The capability floor and the three modules above work end to end in the browser against a disposable copy.
- The browser verification demonstrates every mechanism above, including an evaluator run with its forbidden effects checked.
- Tests never touch the canonical database, and the verification run proves it unchanged.
- capability-manifest.json (historical material omitted from this bundle) grades each catalog capability honestly for `core-v1`, `servicing-v1` and `full-v1`.

