# virtualized-service-workspace implementation record

## Full-v1 qualification

Release verdict: FULL-V1 COMPLETE

- Source commit: `5d321dc48d1cd93ab526249342c3cddbfe532413`
- Evidence run: `full-v1-5d321dc-20260920`
- Visible task options: 102/102
- Workflow path and recovery branches: 30/30
- Family mechanism: virtualized-spa
- Shared-world checks: 3/3
- Durable records: `environments/virtualized-service-workspace/verification/evidence/full-v1-5d321dc-20260920/`

The option-level matrix and exact commands, tests, visible entries/results, business effects, artifact paths, and recovery observations are in `capability-manifest.json` and the evidence directory.

## Runtime and verification

- Build: `npm run build` from `environments/virtualized-service-workspace`.
- Start: `npm run start` from `environments/virtualized-service-workspace`; use the package README for the default entry URL and database flags.
- Browser verification: `npm run verify` from the application package.
- Business data: the shared financial database and institution-scoped service boundary; no application-local business database.
- Release derivation: `npm --prefix environments run audit:full-v1`; release labels are not accepted without current tracked browser evidence.
