import type { CommandOutcome, PageResult } from '@computer-use/financial-database/services';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { startTestWorkspace, type TestWorkspace } from './support.js';

let workspace: TestWorkspace;

beforeEach(async () => { workspace = await startTestWorkspace(); });
afterEach(async () => { await workspace.close(); });

const northstar = '/api/i/northstar';
const riverton = '/api/i/riverton';

interface ListRow { id: string; label: string; status: string | null; fields: Record<string, string | number | null> }
interface Snapshot { kind: string; id: string; fingerprint: string | null; record: Record<string, unknown>; observedAt: string }
interface ApprovalListRow { id: string; status: string; fingerprint: string; target: unknown; maker: { displayName: string; actorNumber: string }; checker: { displayName: string; actorNumber: string } }

const list = async (client: ReturnType<TestWorkspace['client']>, institution: string, resource: string, query = ''): Promise<PageResult<ListRow>> =>
  client.json<PageResult<ListRow>>(`${institution}/records/${resource}?limit=200${query}`);

function firstOf<T>(items: readonly T[], what = 'row'): T {
  const first = items.at(0);
  if (first === undefined) throw new Error(`Expected at least one ${what}.`);
  return first;
}

function found<T>(items: readonly T[], predicate: (item: T) => boolean, what = 'row'): T {
  const item = items.find(predicate);
  if (item === undefined) throw new Error(`Expected a matching ${what}.`);
  return item;
}

describe('finance record lists', () => {
  it('lists payments scoped to the institution with bounded, filterable pages', async () => {
    const client = workspace.client();
    const page = await list(client, northstar, 'payment');
    expect(page.total).toBeGreaterThan(10);
    const first = firstOf(page.items, 'payment');
    expect(first.label).toMatch(/^[A-Z]/u);
    expect(typeof first.fields.memberId).toBe('string');
    const scoped = await list(client, northstar, 'payment', `&memberId=${String(first.fields.memberId)}`);
    expect(scoped.total).toBeGreaterThan(0);
    expect(scoped.items.every((row) => row.fields.memberId === first.fields.memberId)).toBe(true);
    const searched = await list(client, northstar, 'payment', `&query=${encodeURIComponent(String(first.fields.reference).slice(0, 6))}`);
    expect(searched.items.some((row) => row.id === first.id)).toBe(true);
    const state = await list(client, northstar, 'payment', `&state=${String(first.fields.state)}`);
    expect(state.items.every((row) => row.fields.state === first.fields.state)).toBe(true);
  });

  it('never returns another institution\'s records', async () => {
    const client = workspace.client();
    const north = await list(client, northstar, 'payment');
    const river = await list(client, riverton, 'payment');
    expect(north.items.map((row) => row.id).some((id) => river.items.map((item) => item.id).includes(id))).toBe(false);
    const northIds = new Set(north.items.map((row) => row.id));
    const riverAccounts = await client.json<PageResult<{ id: string }>>(`${riverton}/accounts?limit=200`);
    for (const account of riverAccounts.items.slice(0, 3)) {
      const leaked = await list(client, northstar, 'payment', `&accountId=${account.id}`);
      expect(leaked.items.filter((row) => northIds.has(row.id)).length).toBe(0);
    }
  });

  it('rejects unknown resources, unknown filters and unbounded limits', async () => {
    const client = workspace.client();
    expect((await client.get(`${northstar}/records/employees`)).status).toBe(400);
    expect((await client.get(`${northstar}/records/payment?limit=501`)).status).toBe(400);
    expect((await client.get(`${northstar}/records/payment?bogus=1`)).status).toBe(400);
    expect((await client.get(`${northstar}/records/calendar-day?memberId=x`)).status).toBe(400);
    expect((await client.get(`${northstar}/records/payment?state=not-a-state`)).status).toBe(200);
  });

  it('serves cards, disputes, loans, holds and maintenance requests with member scoping', async () => {
    const client = workspace.client();
    for (const resource of ['card', 'dispute', 'loan', 'hold', 'maintenance-request', 'communication-job', 'consent', 'beneficiary', 'payment-schedule', 'fee', 'document-version', 'received-funds', 'loan-application'] as const) {
      const page = await list(client, northstar, resource);
      expect(page.total, resource).toBeGreaterThan(0);
      const memberId = page.items[0]?.fields.memberId;
      if (typeof memberId === 'string') {
        const scoped = await list(client, northstar, resource, `&memberId=${memberId}`);
        expect(scoped.total, `${resource} scoped`).toBeGreaterThan(0);
      }
    }
  });
});

describe('finance record detail', () => {
  it('returns a fingerprinted snapshot for finance record kinds and rejects unknown ids', async () => {
    const client = workspace.client();
    const payments = await list(client, northstar, 'payment');
    const snapshot = await client.json<Snapshot>(`${northstar}/records/payment/${firstOf(payments.items, 'payment').id}`);
    expect(snapshot.fingerprint).toEqual(expect.stringMatching(/^[0-9a-f]{16,}$/u));
    expect(snapshot.record).toMatchObject({ id: firstOf(payments.items, 'payment').id });
    expect((await client.get(`${northstar}/records/payment/no-such-payment`)).status).toBe(404);
    const requests = await list(client, northstar, 'maintenance-request');
    const detail = await client.json<Snapshot>(`${northstar}/records/maintenance-request/${firstOf(requests.items, 'request').id}`);
    expect(typeof detail.record.requestNumber).toBe('string');
    expect(detail.fingerprint).toBeNull();
  });
});

describe('finance inquiries and servicing readers', () => {
  it('runs bounded finance queries and rejects malformed input', async () => {
    const client = workspace.client();
    const payments = await list(client, northstar, 'payment');
    const found = await client.json<{ kind: string }>(`${northstar}/query/finance`, { query: { kind: 'finance.record', resource: 'payment', id: firstOf(payments.items, 'payment').id } });
    expect(found.kind).toBe('found');
    const invalid = await client.send('POST', `${northstar}/query/finance`, { query: { kind: 'finance.record', resource: 'employees', id: 'x' } });
    expect(invalid.status).toBe(400);
    const sessions = await list(client, northstar, 'cash-session');
    const day = String(sessions.items[0]?.fields.businessDate ?? '2026-09-12');
    const cash = await client.json<{ kind: string }>(`${northstar}/query/finance`, { query: { kind: 'reconciliation.cash_day', businessDate: day, cashSessionIds: [], declaredTotal: { minorUnits: 0, currency: 'USD' } } });
    expect(['reconciled', 'rejected']).toContain(cash.kind);
  });

  it('exposes servicing prerequisite readers for policies, checkers and evidence', async () => {
    const client = workspace.client();
    const policies = await client.json<unknown[]>(`${northstar}/servicing/read`, { reader: 'policies', args: {} });
    expect(policies.length).toBeGreaterThan(0);
    const checkers = await client.json<{ actorId: string; actorNumber: string }[]>(`${northstar}/servicing/read`, { reader: 'checkers', args: { commandKind: 'account.restriction.apply' } });
    expect(checkers.map((row) => row.actorNumber)).toContain('OP0005');
    const financeCheckers = await client.json<{ actorNumber: string }[]>(`${northstar}/servicing/read`, { reader: 'checkers', args: { commandKind: 'payment.approve_release' } });
    expect(financeCheckers.map((row) => row.actorNumber)).toContain('OP0004');
    const member = firstOf((await client.json<PageResult<{ id: string; memberNumber: string }>>(`${northstar}/members?limit=1`)).items, 'member');
    const evidence = await client.json<unknown[]>(`${northstar}/servicing/read`, { reader: 'identity-evidence', args: { memberId: member.id } });
    expect(Array.isArray(evidence)).toBe(true);
    const resolved = await client.json<{ resolution: string; candidates: { memberId: string }[] }>(`${northstar}/identity-resolve?memberNumber=${member.memberNumber}`);
    expect(resolved.resolution).toBe('unique');
    expect(resolved.candidates.map((item) => item.memberId)).toEqual([member.id]);
    const ambiguous = await client.json<{ resolution: string; candidates: unknown[] }>(`${northstar}/identity-resolve?displayName=no-such-person`);
    expect(ambiguous.resolution).toBe('none');
  });
});

describe('generic command boundary', () => {
  it('rejects unknown kinds, missing fields and over-posted commands', async () => {
    const client = workspace.client();
    const post = (command: unknown) => client.send('POST', `${northstar}/commands`, { command, idempotencyKey: 'vsw-finance-x1' });
    expect((await post({ kind: 'employee.promote' })).status).toBe(400);
    expect((await post({ kind: 'account.hold.place', accountId: 'a' })).status).toBe(400);
    const review = await client.send('POST', `${northstar}/commands/review`, { command: { kind: 'card.replace', cardId: 'x', expectedFingerprint: 'y', reason: 'z', extra: 1 } });
    expect(review.status).toBe(400);
  });

  it('places a hold end to end, rejects stale versions and repeats idempotently', async () => {
    const client = workspace.client();
    const account = found((await client.json<PageResult<{ id: string; version: number; status: string; currency: string }>>(`${northstar}/accounts?limit=100`)).items, (row) => row.status === 'open' && row.currency === 'USD', 'open USD account');
    const command = { kind: 'account.hold.place', accountId: account.id, expectedVersion: account.version, amount: { minorUnits: 2500, currency: 'USD' }, reason: 'Court order verification', expiresAt: '2026-12-31T00:00:00.000Z', releaseAuthority: 'ops-holds' };
    const committed = await client.json<CommandOutcome>(`${northstar}/commands`, { command, idempotencyKey: 'vsw-finance-hold-1' });
    expect(committed.kind).toBe('committed');
    const again = await client.json<CommandOutcome>(`${northstar}/commands`, { command, idempotencyKey: 'vsw-finance-hold-1' });
    expect(again.kind).toBe('duplicate');
    const holds = await list(client, northstar, 'hold', `&accountId=${account.id}`);
    expect(holds.items.some((row) => row.fields.reason === 'Court order verification' && row.fields.amountMinorUnits === 2500)).toBe(true);
    const stale = await client.json<CommandOutcome>(`${northstar}/commands`, { command: { ...command, expectedVersion: account.version - 1 }, idempotencyKey: 'vsw-finance-hold-2' });
    expect(stale.kind === 'rejected' ? stale.code : null).toBe('stale_version');
    const datasetId = workspace.datasetId('northstar');
    const persisted = workspace.query<{ amount_minor_units: number }>('SELECT amount_minor_units FROM holds WHERE dataset_id=? AND account_id=? AND reason=?', datasetId, account.id, 'Court order verification');
    expect(persisted).toEqual([{ amount_minor_units: 2500 }]);
  });
});

describe('maker-checker approvals', () => {
  it('requests, lists and decides an approval that then binds the restricted command', async () => {
    const maker = workspace.client();
    const account = firstOf((await maker.json<PageResult<{ id: string }>>(`${northstar}/accounts?limit=50`)).items, 'account');
    const detail = await maker.json<{ account: { id: string; version: number; memberId: string } }>(`${northstar}/accounts/${account.id}`);
        const caseRow = (await maker.json<PageResult<{ id: string }>>(`${northstar}/cases?memberId=${detail.account.memberId}&limit=1`)).items[0];
    if (caseRow === undefined) throw new Error('No case on the restriction member.');
    const target = { kind: 'account.restriction.apply', accountId: detail.account.id, expectedVersion: detail.account.version, restrictionType: 'legal-hold', reason: 'Court freeze pending', authority: 'court-order-1', caseId: caseRow.id, approvalId: '' };
    const policies = await maker.json<{ id: string }[]>(`${northstar}/servicing/read`, { reader: 'policies', args: {} });
    const checkers = await maker.json<{ id: string; actorNumber: string }[]>(`${northstar}/servicing/read`, { reader: 'checkers', args: { commandKind: 'account.restriction.apply' } });
    const checker = found(checkers, (row) => row.actorNumber === 'OP0005', 'checker');
    const requested = await maker.json<CommandOutcome>(`${northstar}/commands`, {
      command: { kind: 'approval.request', target, checkerActorId: checker.id, policyVersionId: firstOf(policies, 'policy').id, expiresAt: '2026-09-20T00:00:00.000Z', amountLimit: null },
      idempotencyKey: 'vsw-finance-approval-1',
    });
    if (requested.kind !== 'committed') throw new Error(JSON.stringify(requested));
    const approvals = await maker.json<{ approvals: ApprovalListRow[] }>(`${northstar}/approvals`);
    const approval = found(approvals.approvals, (row) => row.status === 'pending' && row.checker.actorNumber === 'OP0005', 'approval');
    expect(approval.maker.actorNumber).toBe('OP0002');
    const decided = await maker.json<CommandOutcome>(`${northstar}/commands`, {
      command: { kind: 'approval.decide', approvalId: approval.id, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Verified the court order.' },
      idempotencyKey: 'vsw-finance-approval-2',
    });
    expect(decided.kind === 'rejected' ? decided.code : decided.kind).toBe('not_authorized');
    const checkerClient = workspace.client();
    await checkerClient.json('/api/session/operator', { actorNumber: 'OP0005' });
    const approved = await checkerClient.json<CommandOutcome>(`${northstar}/commands`, {
      command: { kind: 'approval.decide', approvalId: approval.id, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Verified the court order.' },
      idempotencyKey: 'vsw-finance-approval-3',
    });
    expect(approved.kind).toBe('committed');
    const applied = await checkerClient.json<CommandOutcome>(`${northstar}/commands`, { command: { ...target, approvalId: approval.id }, idempotencyKey: 'vsw-finance-approval-4' });
    if (applied.kind !== 'committed') throw new Error(JSON.stringify(applied));
    const restrictions = await list(maker, northstar, 'restriction', `&accountId=${detail.account.id}`);
    expect(restrictions.items.some((row) => row.fields.kind === 'legal-hold' && String(row.fields.authority).includes('court-order-1'))).toBe(true);
  });
});
