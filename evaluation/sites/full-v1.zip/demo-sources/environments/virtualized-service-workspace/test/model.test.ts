import { describe, expect, it } from 'vitest';

import { applyColumnAction, defaultLayout, displayedColumnIds, normalizeLayout, visibleColumns } from '../src/client/model/columns.js';
import { draftCommands, draftKey, draftsReducer, type Drafts } from '../src/client/model/drafts.js';
import { groupLayout } from '../src/client/model/groups.js';
import { formatMoney, parseMoney } from '../src/client/model/money.js';
import { LatestOnly, PagedRows, type PageResponse } from '../src/client/model/paged.js';
import { EMPTY_PARAMS, formatRoute, matchKey, parseRoute, windowKey } from '../src/client/model/route.js';
import { EMPTY_SELECTION, afterSearchChange, isSelected, selectAllMatching, selectRecords, selectedCount, toggleSelected } from '../src/client/model/selection.js';
import { assignSlots } from '../src/client/model/slots.js';

function deferred<T>(): { promise: Promise<T>; resolve: (value: T) => void } {
  let resolve: (value: T) => void = () => undefined;
  const promise = new Promise<T>((settle) => { resolve = settle; });
  return { promise, resolve };
}

describe('column layout', () => {
  it('pins, hides, reorders and resizes by column identity', () => {
    let layout = defaultLayout('accounts');
    expect(visibleColumns('accounts', layout).pinned.map((column) => column.id)).toEqual(['account_number']);
    layout = applyColumnAction('accounts', layout, { kind: 'togglePinned', column: 'nickname' });
    layout = applyColumnAction('accounts', layout, { kind: 'toggleHidden', column: 'product_code' });
    layout = applyColumnAction('accounts', layout, { kind: 'shift', column: 'posted_minor_units', delta: -1 });
    layout = applyColumnAction('accounts', layout, { kind: 'resize', column: 'owner_name', width: 5_000 });
    const { pinned, scrolling } = visibleColumns('accounts', layout);
    expect(pinned.map((column) => column.id)).toEqual(['account_number', 'nickname']);
    expect(scrolling.map((column) => column.id)).toEqual(['member_number', 'owner_name', 'product_name', 'currency', 'status', 'posted_minor_units', 'statement_delivery', 'available_minor_units', 'opened_at', 'closed_at', 'version']);
    expect(scrolling.find((column) => column.id === 'owner_name')?.width).toBe(640);
  });

  it('moves a dropped column into the section of its target and never hides the last column', () => {
    let layout = applyColumnAction('members', defaultLayout('members'), { kind: 'moveBefore', column: 'email', before: 'member_number' });
    expect(displayedColumnIds('members', layout).slice(0, 2)).toEqual(['email', 'member_number']);
    expect(layout.pinned).toEqual(['member_number', 'email']);
    layout = applyColumnAction('members', layout, { kind: 'showOnly', columns: ['display_name'] });
    expect(displayedColumnIds('members', layout)).toEqual(['display_name']);
    expect(applyColumnAction('members', layout, { kind: 'toggleHidden', column: 'display_name' })).toBe(layout);
  });

  it('repairs stored layouts against the catalog', () => {
    const repaired = normalizeLayout('cases', { order: ['summary', 'retired', 'summary'], widths: { summary: 10, retired: 90 }, hidden: ['retired'], pinned: ['case_number'] });
    expect(repaired.order[0]).toBe('summary');
    expect(repaired.order).toHaveLength(14);
    expect(repaired.widths).toEqual({ summary: 64 });
    expect(repaired.hidden).toEqual([]);
  });
});

describe('slot recycling', () => {
  it('hands the slot of a row that left the viewport to the row that entered', () => {
    const first = assignSlots(new Map(), [0, 1, 2, 3]);
    const scrolled = assignSlots(first, [1, 2, 3, 4]);
    expect(scrolled.get(4)).toBe(first.get(0));
    expect(scrolled.get(2)).toBe(first.get(2));
    expect(assignSlots(scrolled, [1, 2, 3, 4])).toEqual(scrolled);
    const jumped = assignSlots(scrolled, [900, 901, 902, 903, 904]);
    expect([...jumped.values()].sort()).toEqual([0, 1, 2, 3, 4]);
  });
});

describe('group layout', () => {
  it('locates headers and grouped rows across collapsed and expanded groups', () => {
    const layout = groupLayout([{ key: 'open', count: 3 }, { key: 'closed', count: 2 }, { key: 'resolved', count: 4 }], new Set(['open', 'resolved']));
    expect(layout.length).toBe(1 + 3 + 1 + 1 + 4);
    expect(layout.locate(0)).toEqual({ kind: 'header', group: 0 });
    expect(layout.locate(3)).toEqual({ kind: 'row', group: 0, offset: 2 });
    expect(layout.locate(4)).toEqual({ kind: 'header', group: 1 });
    expect(layout.locate(5)).toEqual({ kind: 'header', group: 2 });
    expect(layout.locate(9)).toEqual({ kind: 'row', group: 2, offset: 3 });
    expect(layout.locate(10)).toBeNull();
    expect(layout.headerIndex(2)).toBe(5);
  });
});

describe('selection', () => {
  it('keeps explicit selections through search changes and ends all-matching selections', () => {
    let selection = toggleSelected(EMPTY_SELECTION, 'a-1', 'AC0000001');
    selection = selectRecords(selection, [['a-2', 'AC0000002'], ['a-3', 'AC0000003']]);
    selection = toggleSelected(selection, 'a-2', 'AC0000002');
    expect(selectedCount(selection)).toBe(2);
    expect(afterSearchChange(selection, 'other').selection).toBe(selection);
    const all = toggleSelected(selectAllMatching('k', 1_887, 'status open'), 'a-9', 'AC0000009');
    expect(selectedCount(all)).toBe(1_886);
    expect(isSelected(all, 'a-9')).toBe(false);
    expect(isSelected(all, 'a-10')).toBe(true);
    expect(afterSearchChange(all, 'k').notice).toBeNull();
    expect(afterSearchChange(all, 'changed')).toEqual({ selection: EMPTY_SELECTION, notice: 'The selection of all 1886 records matching status open was cleared because the search changed.' });
  });
});

describe('drafts', () => {
  const edit = (state: Drafts, recordId: string, field: string, value: string, original: string, version = 3): Drafts =>
    draftsReducer(state, { type: 'edit', institutionId: 'northstar', kind: 'account', recordId, label: recordId.toUpperCase(), version, field, value, original });

  it('keeps separate drafts per record and drops fields edited back to their stored value', () => {
    let state = edit(new Map(), 'a-1', 'nickname', 'Holiday', 'Everyday');
    state = edit(state, 'a-2', 'nickname', 'Rent', 'Bills');
    state = edit(state, 'a-1', 'statement_delivery', 'paper', 'electronic');
    expect(state.get(draftKey('northstar', 'account', 'a-1'))?.fields).toEqual({ nickname: 'Holiday', statement_delivery: 'paper' });
    expect(state.get(draftKey('northstar', 'account', 'a-2'))?.fields).toEqual({ nickname: 'Rent' });
    state = edit(state, 'a-2', 'nickname', 'Bills', 'Bills');
    expect(state.has(draftKey('northstar', 'account', 'a-2'))).toBe(false);
  });

  it('builds chained commands, commits field by field and records rejections', () => {
    let state = edit(new Map(), 'a-1', 'nickname', 'Holiday', 'Everyday');
    state = edit(state, 'a-1', 'statement_delivery', 'paper', 'electronic');
    const key = draftKey('northstar', 'account', 'a-1');
    const draft = state.get(key);
    if (draft === undefined) throw new Error('No draft.');
    expect(draftCommands(draft).map((item) => item.command)).toEqual([
      { kind: 'account.nickname.update', accountId: 'a-1', expectedVersion: 3, nickname: 'Holiday' },
      { kind: 'account.statement_delivery.update', accountId: 'a-1', expectedVersion: 4, statementDelivery: 'paper' },
    ]);
    state = draftsReducer(state, { type: 'submit', key, attempt: 'attempt-1' });
    expect(edit(state, 'a-1', 'nickname', 'Changed while pending', 'Everyday')).toBe(state);
    state = draftsReducer(state, { type: 'committed', key, fields: ['nickname'], receiptNumber: 'RCP00000001', version: 4 });
    expect(state.get(key)).toMatchObject({ status: { phase: 'pending' }, fields: { statement_delivery: 'paper' }, baseVersion: 4 });
    state = draftsReducer(state, { type: 'rejected', key, code: 'stale_version', message: 'Changed elsewhere', field: null, currentVersion: 6 });
    expect(state.get(key)?.status).toEqual({ phase: 'rejected', code: 'stale_version', message: 'Changed elsewhere', field: null, currentVersion: 6 });
    state = draftsReducer(state, { type: 'rebase', key, version: 6, original: { statement_delivery: 'electronic' } });
    expect(draftCommands(state.get(key) ?? draft)[0]?.command).toEqual({ kind: 'account.statement_delivery.update', accountId: 'a-1', expectedVersion: 6, statementDelivery: 'paper' });
    state = draftsReducer(state, { type: 'submit', key, attempt: 'attempt-2' });
    state = draftsReducer(state, { type: 'committed', key, fields: ['statement_delivery'], receiptNumber: 'RCP00000002', version: 7 });
    expect(state.get(key)).toMatchObject({ status: { phase: 'committed', receiptNumber: 'RCP00000002' }, receipts: ['RCP00000001', 'RCP00000002'] });
  });

  it('retries an interrupted submission with its original idempotency attempt', () => {
    let state = edit(new Map(), 'a-1', 'nickname', 'Holiday', 'Everyday');
    const key = draftKey('northstar', 'account', 'a-1');
    state = draftsReducer(state, { type: 'submit', key, attempt: 'first' });
    state = draftsReducer(state, { type: 'interrupted', key, message: 'Network error' });
    state = draftsReducer(state, { type: 'submit', key, attempt: 'second' });
    expect(state.get(key)?.attempt).toBe('first');
    const restored = draftsReducer(new Map(), { type: 'restore', drafts: [...state.values()] });
    expect(restored.get(key)?.status.phase).toBe('unknown');
  });

  it('turns member contact drafts into one contact update that can clear a field', () => {
    let state = draftsReducer(new Map(), { type: 'edit', institutionId: 'northstar', kind: 'member', recordId: 'm-1', label: 'NM000001', version: 2, field: 'phone', value: ' ', original: '312-555-0100' });
    state = draftsReducer(state, { type: 'edit', institutionId: 'northstar', kind: 'member', recordId: 'm-1', label: 'NM000001', version: 2, field: 'email', value: 'new@example.test', original: 'old@example.test' });
    const draft = state.get(draftKey('northstar', 'member', 'm-1'));
    expect(draft === undefined ? [] : draftCommands(draft).map((item) => item.command)).toEqual([{ kind: 'contact.update', memberId: 'm-1', expectedVersion: 2, email: 'new@example.test', phone: null }]);
  });
});

describe('paged rows', () => {
  it('loads pages for a range and ignores responses that arrive after the source was replaced', async () => {
    const pending: { offset: number; answer: ReturnType<typeof deferred<PageResponse<{ id: string }>>> }[] = [];
    const fetchPage = (offset: number): Promise<PageResponse<{ id: string }>> => { const answer = deferred<PageResponse<{ id: string }>>(); pending.push({ offset, answer }); return answer.promise; };
    const older = new PagedRows('older', 10, fetchPage);
    older.ensure(0, 5);
    const newer = new PagedRows('newer', 10, fetchPage);
    newer.ensure(0, 5);
    older.dispose();
    const [oldRequest, newRequest] = pending;
    newRequest?.answer.resolve({ items: [{ id: 'new-0' }], total: 1, offset: 0, limit: 10 });
    await Promise.resolve();
    oldRequest?.answer.resolve({ items: [{ id: 'old-0' }], total: 99, offset: 0, limit: 10 });
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(newer.get(0)).toEqual({ id: 'new-0' });
    expect(newer.getSnapshot().total).toBe(1);
    expect(older.get(0)).toBeUndefined();
  });

  it('flags a changed total between pages and evicts far pages', async () => {
    let total = 50;
    const source = new PagedRows<{ id: string }>('k', 10, (offset) => Promise.resolve({ items: Array.from({ length: 10 }, (_, index) => ({ id: `r-${String(offset + index)}` })), total: total++, offset, limit: 10 }), 2);
    source.ensure(0, 9);
    await new Promise((resolve) => setTimeout(resolve, 0));
    source.ensure(40, 49);
    source.ensure(20, 29);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(source.getSnapshot().drifted).toBe(true);
    expect(source.get(45)).toEqual({ id: 'r-45' });
    expect(source.get(0)).toBeUndefined();
    expect(source.indexOf('r-25')).toBe(25);
  });
});

describe('latest-only requests', () => {
  it('applies only the newest response when earlier ones resolve later', async () => {
    const latest = new LatestOnly();
    const applied: string[] = [];
    const slow = deferred<string>();
    const fast = deferred<string>();
    latest.run(() => slow.promise, (value) => applied.push(value), () => undefined);
    latest.run(() => fast.promise, (value) => applied.push(value), () => undefined);
    fast.resolve('member B');
    slow.resolve('member A');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(applied).toEqual(['member B']);
  });
});

describe('routes', () => {
  it('round-trips list state and record links through the URL', () => {
    const route = { view: 'list', institutionId: 'northstar', list: 'cases', params: { filters: { query: 'CS00', states: ['open', 'reopened'], overdue: true }, sort: { field: 'due_at', direction: 'desc' }, groupBy: 'queue', savedSearchId: 'saved-1', maxResults: 200 } } as const;
    const url = formatRoute(route);
    expect(url).toBe('/northstar/cases?q=CS00&status=open%2Creopened&overdue=1&sort=due_at%3Adesc&group=queue&saved=saved-1&max=200');
    const [pathname, search] = url.split('?');
    expect(parseRoute(pathname ?? '', search ?? '')).toEqual(route);
    expect(parseRoute('/riverton/account/riverton-account-0001', '')).toEqual({ view: 'record', institutionId: 'riverton', kind: 'account', id: 'riverton-account-0001' });
    expect(parseRoute('/northstar/widgets', '')).toBeNull();
  });

  it('keys result membership independently of sort and grouping', () => {
    const base = { ...EMPTY_PARAMS, filters: { status: 'open' } };
    const sorted = { ...base, sort: { field: 'nickname', direction: 'asc' as const }, groupBy: 'state' };
    expect(matchKey('northstar', 'accounts', base)).toBe(matchKey('northstar', 'accounts', sorted));
    expect(windowKey('northstar', 'accounts', base)).not.toBe(windowKey('northstar', 'accounts', sorted));
    expect(matchKey('northstar', 'accounts', base)).not.toBe(matchKey('riverton', 'accounts', base));
  });
});

describe('money', () => {
  it('formats and parses exact minor units for each exponent', () => {
    expect(formatMoney(596614, 'USD', 2)).toBe('5,966.14 USD');
    expect(formatMoney(-5, 'USD', 2)).toBe('-0.05 USD');
    expect(formatMoney(1234567, 'JPY', 0)).toBe('1,234,567 JPY');
    expect(formatMoney(1500, 'KWD', 3)).toBe('1.500 KWD');
    expect(parseMoney('1,234.5', 2)).toEqual({ ok: true, minorUnits: 123450 });
    expect(parseMoney('0.10', 2)).toEqual({ ok: true, minorUnits: 10 });
    expect(parseMoney('1.005', 2).ok).toBe(false);
    expect(parseMoney('-3', 2).ok).toBe(false);
    expect(parseMoney('12.5', 0).ok).toBe(false);
  });
});
