import { readFileSync } from 'node:fs';
import { join } from 'node:path';

import { SAVED_SEARCH_ENTITIES, type AccountRow, type CaseDetail, type CaseGroup, type CaseRow, type CaseSubjectCorrectionEvidenceDocument, type CommandOutcome, type IdentityEvidenceSummary, type MemberRow, type PageResult, type PolicyVersionSummary, type ReviewOutcome, type SavedSearchRow, type ServiceCommand, type ServicingApprovalCheckerSummary, type TransactionRow } from '@computer-use/financial-database/services';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { startWorkspace } from '../src/server/app.js';
import { memoryPreferenceStore } from '../src/server/preferences.js';
import type { ColumnLayout, SessionInfo } from '../src/shared/api.js';
import { GRID_COLUMNS, GRID_SORTS, columnIds } from '../src/shared/columns.js';
import { startTestWorkspace, type TestWorkspace } from './support.js';

let workspace: TestWorkspace;

beforeEach(async () => { workspace = await startTestWorkspace({ exportLimit: 25 }); });
afterEach(async () => { await workspace.close(); });

const northstar = '/api/i/northstar';

describe('column vocabulary', () => {
  it('names the same fields as the shared saved-search vocabulary', () => {
    for (const entity of ['members', 'accounts', 'cases'] as const) {
      expect(columnIds(entity)).toEqual(SAVED_SEARCH_ENTITIES[entity].columns);
      expect(GRID_SORTS[entity]).toEqual(SAVED_SEARCH_ENTITIES[entity].sorts);
    }
  });
});

describe('transaction history', () => {
  it('narrows by exact reference, journal status and an amount band in minor units', async () => {
    const client = workspace.client();
    const path = `${northstar}/accounts/northstar-account-1/transactions`;
    const all = await client.json<PageResult<TransactionRow>>(`${path}?limit=100`);
    const exact = await client.json<PageResult<TransactionRow>>(`${path}?reference=jr-activity-1-2`);
    expect(exact.items.map((item) => [item.reference, item.amountMinorUnits])).toEqual([['JR-activity-1-2', -9260]]);
    expect((await client.json<PageResult<TransactionRow>>(`${path}?status=reversed`)).total).toBe(0);
    expect((await client.json<PageResult<TransactionRow>>(`${path}?status=posted`)).total).toBe(all.total);
    const band = await client.json<PageResult<TransactionRow>>(`${path}?minMinorUnits=9000&maxMinorUnits=10000`);
    expect(band.items.map((item) => item.reference)).toContain('JR-activity-1-2');
    expect(band.items.every((item) => Math.abs(item.amountMinorUnits) >= 9000 && Math.abs(item.amountMinorUnits) <= 10000)).toBe(true);
    expect((await client.get(`${path}?status=pending`)).status).toBe(400);
  });
});

describe('workspace API', () => {
  it('reports institutions, the signed-on operator and what each operator may do', async () => {
    const client = workspace.client();
    const session = await client.json<SessionInfo>('/api/session');
    expect(session.institutions.map((item) => item.institutionId).sort()).toEqual(['harbor', 'northstar', 'riverton']);
    expect(session.operator.actorNumber).toBe('OP0002');
    expect(session.operator.profiles.northstar).toMatchObject({ actorId: 'northstar-actor-2', canShareSearches: true });
    expect(session.operator.profiles.northstar?.commands).toEqual(expect.arrayContaining(['account.nickname.update', 'approval.request', 'search.saved.create']));
    expect(session.exportLimit).toBe(25);
    await client.json('/api/session/operator', { actorNumber: 'OP0001' });
    const viewer = await client.json<SessionInfo>('/api/session');
    expect(viewer.operator.profiles.northstar).toMatchObject({ actorNumber: 'OP0001', canShareSearches: false, commands: ['loan.payoff.quote', 'search.saved.create', 'search.saved.update', 'search.saved.delete'] });
  });

  it('pages contiguously, sorts by grid column ids, applies result limits and rejects unknown sorts', async () => {
    const client = workspace.client();
    const whole = await client.json<PageResult<MemberRow>>(`${northstar}/members?sort=display_name&direction=desc&limit=10&offset=0`);
    const first = await client.json<PageResult<MemberRow>>(`${northstar}/members?sort=display_name&direction=desc&limit=5&offset=0`);
    const second = await client.json<PageResult<MemberRow>>(`${northstar}/members?sort=display_name&direction=desc&limit=5&offset=5`);
    expect([...first.items, ...second.items].map((row) => row.id)).toEqual(whole.items.map((row) => row.id));
    const limited = await client.json<PageResult<MemberRow> & { limitedTo: number; matched: number }>(`${northstar}/members?maxResults=7&limit=5&offset=5`);
    expect(limited).toMatchObject({ total: 7, limitedTo: 7, matched: whole.total });
    expect(limited.items).toHaveLength(2);
    const refused = await client.get(`${northstar}/accounts?sort=owner_email`);
    expect(refused.status).toBe(400);
    expect(await refused.json()).toEqual({ error: { code: 'invalid_sort', message: 'The accounts list cannot be sorted by owner_email.', field: 'sort' } });
  });

  it('filters cases by several queues and returns group counts that add up to the filtered total', async () => {
    const client = workspace.client();
    const filtered = await client.json<PageResult<CaseRow>>(`${northstar}/cases?queueIds=northstar-queue-1,northstar-queue-2&limit=200`);
    expect(filtered.items.every((row) => ['northstar-queue-1', 'northstar-queue-2'].includes(row.queueId))).toBe(true);
    const groups = await client.json<CaseGroup[]>(`${northstar}/case-groups?groupBy=state&queueIds=northstar-queue-1,northstar-queue-2`);
    expect(groups.reduce((sum, group) => sum + group.count, 0)).toBe(filtered.total);
    const unassigned = await client.json<PageResult<CaseRow>>(`${northstar}/cases?assignedActorId=unassigned&limit=200`);
    expect(unassigned.items.every((row) => row.assignedActorId === null)).toBe(true);
  });

  it('commits a reviewed nickname edit once per key and rejects a stale version without writing', async () => {
    const client = workspace.client();
    const account = (await client.json<PageResult<AccountRow>>(`${northstar}/accounts?query=AC0000030`)).items[0];
    if (account === undefined) throw new Error('AC0000030 is missing from the template world.');
    const command = { kind: 'account.nickname.update', accountId: account.id, expectedVersion: account.version, nickname: 'Rainy day' };
    const review = await client.json<ReviewOutcome>(`${northstar}/commands/review`, { command });
    expect(review.kind).toBe('reviewable');
    const first = await client.json<CommandOutcome>(`${northstar}/commands`, { command, idempotencyKey: 'vsw-api-nickname-1' });
    const again = await client.json<CommandOutcome>(`${northstar}/commands`, { command, idempotencyKey: 'vsw-api-nickname-1' });
    expect(first.kind).toBe('committed');
    expect(again).toEqual({ ...first, kind: 'duplicate' });
    const stale = await client.json<CommandOutcome>(`${northstar}/commands`, { command: { ...command, nickname: 'Overwrite' }, idempotencyKey: 'vsw-api-nickname-2' });
    expect(stale).toMatchObject({ kind: 'rejected', code: 'stale_version', currentVersion: account.version + 1 });
    expect(workspace.query('SELECT nickname,version FROM accounts WHERE dataset_id=? AND id=?', workspace.datasetId('northstar'), account.id))
      .toEqual([{ nickname: 'Rainy day', version: account.version + 1 }]);
  });

  it('corrects a case subject only with current evidence, checker authority, and an exact approved proposal', async () => {
    interface Prerequisites {
      identityEvidence: IdentityEvidenceSummary[];
      evidenceDocuments: CaseSubjectCorrectionEvidenceDocument[];
      approvalCheckers: ServicingApprovalCheckerSummary[];
      policyVersions: PolicyVersionSummary[];
      approvals: { kind: 'found'; approvals: { id: string; status: string; fingerprint: string }[] };
    }
    const client = workspace.client();
    const record = (await client.json<PageResult<CaseRow>>(`${northstar}/cases?query=CS000002`)).items.find((item) => item.caseNumber === 'CS000002');
    if (record === undefined) throw new Error('No case CS000002.');
    const prerequisites = await client.json<Prerequisites>(`${northstar}/servicing/case-subject-correction/${record.memberId}?correctedMemberId=northstar-member-3`);
    const evidenceVersionId = prerequisites.evidenceDocuments.find((item) => item.memberId === 'northstar-member-3')?.versionId;
    const checker = prerequisites.approvalCheckers.find((item) => item.actorNumber === 'OP0005');
    const policy = prerequisites.policyVersions[0];
    if (evidenceVersionId === undefined || checker === undefined || policy === undefined) throw new Error('Corrected-member case correction prerequisites are missing.');
    const target: Extract<ServiceCommand, { kind: 'case.subject.correct' }> = {
      kind: 'case.subject.correct', caseId: record.id, expectedVersion: record.version, correctMemberId: 'northstar-member-3', correctAccountId: 'northstar-account-3', evidenceVersionId, approvalId: 'pending-approval',
    };
    const command = async (value: ServiceCommand, idempotencyKey: string): Promise<CommandOutcome> => client.json(`${northstar}/commands`, { command: value, idempotencyKey });
    expect(await command(target, 'vsw-case-subject-maker-refused')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const requested = await command({ kind: 'approval.request', target, checkerActorId: checker.id, policyVersionId: policy.id, expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: null }, 'vsw-case-subject-request');
    if (requested.kind !== 'committed') throw new Error(JSON.stringify(requested));
    const approvalId = requested.receipt.affected.find((item) => item.kind === 'approval')?.id;
    if (approvalId === undefined) throw new Error('Approval request omitted its ID.');
    await client.json('/api/session/operator', { actorNumber: 'OP0005' });
    expect(await command({ ...target, evidenceVersionId: 'missing-version', approvalId }, 'vsw-case-subject-missing-evidence')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    const checkerView = await client.json<Prerequisites>(`${northstar}/servicing/case-subject-correction/${record.memberId}`);
    const approval = checkerView.approvals.approvals.find((item) => item.id === approvalId);
    if (approval === undefined) throw new Error('Checker cannot see the pending approval.');
    const decided = await command({ kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Exact subject and evidence reviewed.' }, 'vsw-case-subject-approve');
    expect(decided.kind).toBe('committed');
    expect(await command({ ...target, approvalId: 'missing-approval' }, 'vsw-case-subject-no-approval')).toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'approvalId' });
    expect((await command({ ...target, approvalId }, 'vsw-case-subject-correct')).kind).toBe('committed');
    const detail = await client.json<CaseDetail>(`${northstar}/cases/${record.id}`);
    expect([detail.case.memberId, detail.case.accountId, detail.case.queueCode]).toEqual(['northstar-member-3', 'northstar-account-3', 'RESTRICTED']);
  });

  it('manages saved searches through shared commands and never lists another operator\'s private searches', async () => {
    const owner = workspace.client();
    const definition = { entity: 'accounts', filters: { query: 'AC00000', currency: 'USD' }, sort: [{ field: 'posted_minor_units', direction: 'desc' }], columns: ['account_number', 'nickname', 'posted_minor_units'] };
    const created = await owner.json<CommandOutcome>(`${northstar}/commands`, { command: { kind: 'search.saved.create', name: 'Largest USD balances', visibility: 'private', definition }, idempotencyKey: 'vsw-api-search-1' });
    if (created.kind !== 'committed') throw new Error(JSON.stringify(created));
    const mine = await owner.json<SavedSearchRow[]>(`${northstar}/saved-searches?entity=accounts`);
    expect(mine.map((row) => [row.name, row.visibility, row.mine, row.definition])).toEqual([['Largest USD balances', 'private', true, definition]]);
    const other = workspace.client();
    await other.json('/api/session/operator', { actorNumber: 'OP0005' });
    expect(await other.json<SavedSearchRow[]>(`${northstar}/saved-searches?entity=accounts`)).toEqual([]);
    const renamed = await owner.json<CommandOutcome>(`${northstar}/commands`, { command: { kind: 'search.saved.update', searchId: mine[0]?.id, expectedRevision: mine[0]?.revision, name: 'Top USD balances' }, idempotencyKey: 'vsw-api-search-2' });
    expect(renamed.kind).toBe('committed');
    const refused = await owner.json<CommandOutcome>(`${northstar}/commands`, { command: { kind: 'search.saved.create', name: 'x', visibility: 'private', definition: { ...definition, owner: 'OP0005' } }, idempotencyKey: 'vsw-api-search-3' });
    expect([refused.kind, refused.kind === 'rejected' ? refused.code : null]).toEqual(['rejected', 'validation']);
  });

  it('keeps column layouts per operator and persists them across a restart', async () => {
    const casey = workspace.client();
    const layout: ColumnLayout = { order: [...columnIds('accounts')].reverse(), widths: { nickname: 320 }, hidden: ['version'], pinned: ['account_number', 'nickname'] };
    await casey.json('/api/preferences/accounts', layout, 'PUT');
    const morgan = workspace.client();
    await morgan.json('/api/session/operator', { actorNumber: 'OP0003' });
    expect(await morgan.json('/api/preferences/accounts')).toEqual({ grid: 'accounts', layout: null });
    const invalid = await casey.send('PUT', '/api/preferences/accounts', { ...layout, order: ['nickname'] });
    expect(invalid.status).toBe(400);
    await workspace.restart();
    const stored = JSON.parse(readFileSync(join(workspace.directory, 'preferences.json'), 'utf8')) as { operators: Record<string, Record<string, ColumnLayout>> };
    expect(stored.operators.OP0002?.accounts).toEqual(layout);
    const reopened = workspace.client();
    expect(await reopened.json('/api/preferences/accounts')).toEqual({ grid: 'accounts', layout });
    await reopened.json('/api/preferences/accounts', undefined, 'DELETE');
    expect(await reopened.json('/api/preferences/accounts')).toEqual({ grid: 'accounts', layout: null });
  });

  it('exports explicit and matching selections with exact minor units and refuses oversize selections', async () => {
    const client = workspace.client();
    const page = await client.json<PageResult<AccountRow>>(`${northstar}/accounts?limit=3&sort=account_number`);
    const ids = page.items.map((row) => row.id);
    const explicit = await client.send('POST', `${northstar}/exports/accounts`, { selection: { mode: 'ids', ids }, columns: ['account_number', 'posted_minor_units'] });
    expect(explicit.headers.get('x-export-count')).toBe('3');
    const lines = (await explicit.text()).trim().split(/\r?\n/u);
    expect(lines).toEqual(['account_number,posted_minor_units,currency', ...page.items.map((row) => `${row.accountNumber},${String(row.postedMinorUnits)},${row.currency}`)]);
    const matching = await client.send('POST', `${northstar}/exports/accounts`, { selection: { mode: 'matching', filters: { query: 'AC000000' }, sort: { field: 'account_number', direction: 'asc' }, excludedIds: [ids[0]] }, columns: ['account_number'] });
    expect(matching.status).toBe(200);
    const matchingLines = (await matching.text()).trim().split(/\r?\n/u);
    expect(matchingLines[0]).toBe('account_number');
    expect(matchingLines).not.toContain(page.items[0]?.accountNumber);
    expect(matchingLines.slice(1).every((line) => line.startsWith('AC000000'))).toBe(true);
    const oversize = await client.send('POST', `${northstar}/exports/accounts`, { selection: { mode: 'matching', filters: {}, sort: null, excludedIds: [] }, columns: ['account_number'] });
    expect(oversize.status).toBe(413);
    expect(((await oversize.json()) as { error: { code: string } }).error.code).toBe('export_too_large');
  });

  it('reports which selected records the current search hides', async () => {
    const client = workspace.client();
    const open = await client.json<PageResult<AccountRow>>(`${northstar}/accounts?status=open&limit=2&sort=account_number`);
    const closed = await client.json<PageResult<AccountRow>>(`${northstar}/accounts?status=closed&limit=1`);
    const ids = [...open.items, ...closed.items].map((row) => row.id);
    expect(ids).toHaveLength(3);
    const result = await client.json<{ matching: string[] }>(`${northstar}/membership/accounts`, { ids, filters: { status: 'open' } });
    expect(result.matching.sort()).toEqual(open.items.map((row) => row.id).sort());
    const refused = await client.send('POST', `${northstar}/membership/accounts`, { ids, filters: { states: ['open'] } });
    expect(refused.status).toBe(400);
  });

  it('binds requests to institutions and rejects cross-origin writes', async () => {
    const client = workspace.client();
    const riverton = await client.get('/api/i/riverton/accounts/northstar-account-1');
    expect(riverton.status).toBe(404);
    const crossOrigin = await client.send('POST', `${northstar}/commands/review`, { command: { kind: 'member.note.add', memberId: 'northstar-member-1', visibility: 'general', text: 'x' } }, { origin: 'http://evil.example' });
    expect(crossOrigin.status).toBe(403);
    expect((await client.get('/api/i/elsewhere/members')).status).toBe(404);
  });

  it('fixes the operator in verification mode and keeps layouts out of the financial store', async () => {
    const preferences = memoryPreferenceStore();
    const { openFinancialStore } = await import('@computer-use/financial-database/services');
    const path = join(workspace.directory, 'financial.sqlite');
    const store = openFinancialStore({ path });
    const binding = workspace.bindings.find((item) => item.institutionId === 'northstar');
    if (binding === undefined) throw new Error('No Northstar binding.');
    const fixed = await startWorkspace({ store, bindings: [binding], mode: 'verification', operator: { actorNumbers: ['OP0002'], fixed: true }, preferences, principalKind: 'automation', port: 0, onClose: () => { store.close(); } });
    try {
      const response = await fetch(`${fixed.origin}/api/session/operator`, { method: 'POST', body: JSON.stringify({ actorNumber: 'OP0003' }), headers: { 'content-type': 'application/json' } });
      expect(response.status).toBe(403);
      const session = await (await fetch(`${fixed.origin}/api/session`)).json() as SessionInfo;
      expect(session).toMatchObject({ mode: 'verification', operatorChoices: [] });
      expect(session.institutions.map((item) => item.institutionId)).toEqual(['northstar']);
    } finally {
      await fixed.close();
    }
    expect(GRID_COLUMNS.accounts.length).toBe(14);
  });
});
