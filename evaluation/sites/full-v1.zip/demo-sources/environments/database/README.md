# Shared financial database

`environments/database/financial` is the single database foundation for the environment workflows. It owns the schema, deterministic seed profiles, documents, business rules, authorization, bounded reads, approvals, immutable evidence, durable receipts, and transactional mutations. Applications are consumers of this contract and do not own a second business database.

## Install, seed, and verify

Use Node.js 25.9 or newer. From this directory:

```sh
npm ci --prefix financial
npm --prefix .. run check:database-verifier
npm run seed --prefix financial -- --path financial/.runtime/financial.sqlite
npm run verify --prefix financial -- --path financial/.runtime/financial.sqlite
```

The default named world is `financial-demo-v1`, seed `20260911`, with Northstar, Riverton, and Harbor institution bindings. Use a new world name or temporary path for disposable work. Never use the ignored runtime database as a mutation target in tests; service and evaluator checks create isolated runs.

The workspace-level commands are available from `environments/`:

```sh
npm run build
npm run check
npm run check:database-verifier
```

The financial package is intentionally invoked by path because it is the canonical storage boundary rather than an application workspace. Applications link it with `file:../database/financial`; there is no legacy database package or compatibility API.

## Ownership and public boundary

The database owns business records and their invariants. Public consumers use the typed exports from `@computer-use/financial-database`, `@computer-use/financial-database/services`, and `@computer-use/financial-database/verification`. The service layer validates inputs, authorizes the trusted actor and institution binding, applies bounded reads, and runs writes transactionally. UI code never writes tables or derives expected effects from executed mutations.

The canonical discovery API is `listFinanceRecords` in `financial/src/services/finance-lists.ts`. It provides one finite resource vocabulary, typed row metadata, member/account/parent/state/text/date filters, deterministic paging, explicit `exhausted` status, and a 500-row maximum. `queryFinance` exposes the same service through the `finance.records` transport and translates domain scope names at the boundary. Direct institution-wide directories are permitted only where the database contract requires them; relationship-scoped transport reads require an explicit scope.

Command intent digests exclude only top-level `expected*` binding fields. Payload, actor, dataset, approval, evidence, and command kind remain bound to the idempotency key. Atomic batch parents hash child intent digests. A retry with refreshed stale bindings returns the original receipt; a changed business payload, actor, dataset, approval scope, or immutable evidence conflicts. Approval summaries carry maker and checker identities, and checker lookup accepts the grants authorized for the command while excluding the current actor.

## Coverage

The maintained database evidence covers 102 business tasks, 30 workflows, 90 adversarial conditions, 24 fixture families, and eight exact cases. The current inventories report 102/102 task database options implemented and verified, 30/30 workflows with graded public-service scenarios, 101 executable database scenarios, 414 database scenario regression variants, and 135 workflow scenario regression variants. These are database contracts and executable branches; they do not claim every UI permutation, browser gesture, human approval gesture, scheduler restart, external delivery, or agent outcome. Those remain explicit external boundaries in the evaluation inventories.

`evaluation/verifier/foundation-coverage.json` and `evaluation/verifier/coverage.json` are the maintained machine-readable evidence. `FOUNDATION-IMPLEMENTATION.md` records the broader service and seed checks. When a capability is marked database-verified, the evidence means its database option and relevant failure semantics are exercised; it does not promote an application profile.

## Safe usage

Open a financial store with an explicit path and bind every operation to a trusted actor and dataset:

```ts
import { openFinancialStore, queryFinance, executeCommand } from '@computer-use/financial-database/services';

const store = openFinancialStore({ path: sharedDatabasePath });
const context = { binding, actorId: 'northstar-actor-2', reference: 'workflow-run' };
const page = queryFinance(store, context, {
  kind: 'finance.records', resource: 'payment',
  scope: { memberId }, limit: 50, offset: 0,
});
const outcome = executeCommand(store, context, command, idempotencyKey);
```

Keep expected values, fault schedules, fixtures, reports, leases, and graders under `evaluation/`, outside the product package and web roots. For evaluator runs, pass `verificationRunStore(run)` so writes stay inside the evaluator-owned disposable world.
