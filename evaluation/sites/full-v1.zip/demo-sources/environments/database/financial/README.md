# Shared synthetic financial database

This package owns the comprehensive banking population for all application environments. Each application should open the same SQLite path and select the same institution/dataset binding when it needs to share state. Application-specific databases and embedded seed copies would break that contract.

This is the sole database API. This package provides seeded business state, documents, bounded reads, and the mutation services described under [Mutation services](#mutation-services). It does not implement application screens or an agent runtime.

## Run

Use Node 25.9 or newer. Run these commands from this directory.

```sh
npm ci
npm run seed -- --path .runtime/financial.sqlite --verbose
npm run verify -- --path .runtime/financial.sqlite --verbose
```

The default named world is `financial-demo-v1`, seed `20260911`, with a fixed clock of `2026-09-14T15:00:00.000Z`. It contains separately bound Northstar, Riverton and Harbor datasets. Repeating the identical manifest preserves existing state. A changed manifest under the same world name is rejected. Use a new name/path for a new population; clone a dataset for an isolated trial.

`--scale small` retains rare business states with a smaller ordinary population. `standard` is the normal exploration dataset. `capacity` increases the workload; applications still need to define their own explicit resource limits and near-limit trial manifests.

## Financial model

People and organizations own member records. Account-party links distinguish ownership and signing roles. Products, effective policies, operator grants, evidence, consent and business approvals have separate identities. Monetary amounts use integer minor units with USD/EUR, JPY and KWD exponent metadata; there is no implicit currency conversion.

Posted balances derive from balanced double-entry journals. Cash and settlement counterparties are explicit general-ledger accounts. Holds, payment reservations and credit facilities determine available funds separately from posted balances. Original postings and corrective effects remain individually identifiable. A loan's `principal_minor_units` is its origination amount; current obligations come from its components. Those components distinguish principal, interest and fees; a zero principal balance does not establish closure.

Documents store actual immutable PDF, PNG and CSV bytes inside SQLite, keyed by SHA-256. Metadata, versions, owners, signatures, annotations, derivations, case filings and delivery jobs link to those bytes. The bundled Noto Sans font and its license are in `src/assets/`. All identities, routes, card tokens, signatures and correspondence are synthetic. Communications are local records, with no external delivery integration.

## Application binding

```ts
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '@computer-use/financial-database';
import { openFinancialStore, queryCore } from '@computer-use/financial-database/services';

using database = openFinancialDatabase({ path: sharedDatabasePath });
const binding = database.getNamedWorld(DEFAULT_SEED_MANIFEST.name)
  .find(candidate => candidate.institutionId === 'northstar');
if (!binding) throw new Error('Northstar dataset is not available.');
const store = openFinancialStore({ path: sharedDatabasePath });
try {
  const context = { binding, actorId: authenticatedSession.actorId, reference: authenticatedSession.id };
  const result = queryCore(store, context, {
    kind: 'member.search', search: { query: '', offset: 0, limit: 25 },
  });
  // Handle queried and rejected explicitly in the application adapter.
} finally {
  store.close();
}
```

Seed the shared world through the administration command before application startup. Business numbers intentionally collide between institutions; retain both institution ID and dataset ID. The authenticated session must authorize that binding. Shared service queries then enforce current actor permissions and record scope.

The lower-level dataset readers are administration and fixture tools. Keep them outside end-user routes: unlike the service queries above, they do not accept an authenticated actor. They expose bounded relational inspection for seeding and evaluation:

```ts
const dataset = database.dataset(binding);
const routes = dataset.records.list('beneficiary_routes', { limit: 25 });
if (routes.nextCursor) {
  const nextRoutes = dataset.records.list('beneficiary_routes', {
    limit: 25,
    cursor: routes.nextCursor,
  });
}
```

Record pages contain scalar SQL fields and follow primary-key order, including composite keys. Limits are 1–100; cursors are scoped to their dataset and resource. Raw BLOB tables are excluded: use `dataset.documents.bytes(versionId)` for document content. These backend readers do not grant end users access to every table. App backends must enforce operator permissions before exposing records.

`database.cloneDataset(binding, name?)` copies a coherent dataset snapshot, including its revision and documents. A clone has a new identity and evolves independently. Repeated `seedWorld` calls with the identical named manifest preserve edits; they are not a reset mechanism.

## Mutation services

The `./services` export holds shared core, finance, servicing and approval rules. The foundation implementation record (historical material omitted from this bundle) records the completed database-verifiable scope: all 102 business task option assessments, 30 workflow contracts, applicable system/adversarial database slices, 24 fixture families and eight exact cases. The current shared-foundation verification passed 269/269 service tests and the unrestricted database evaluator suite passed 1,955/1,955. The maintained foundation matrix (historical material omitted from this bundle) separates declarations, exercised options and external verification. Applications call these services instead of writing tables themselves; each application still needs its own UI and agent qualification.

```ts
import { executeCommand, openFinancialStore, reviewCommand } from '@computer-use/financial-database/services';

const store = openFinancialStore({ path: sharedDatabasePath });
const context = { binding, actorId: 'northstar-actor-2', reference: 'my-app:session-1' };
const review = reviewCommand(store, context, command);
const outcome = executeCommand(store, context, command, idempotencyKey);
```

### Servicing prerequisite reads

The `./services` export includes authenticated reads for the stable identities and current state needed to construct servicing commands. Call them inside `store.read(database => ...)` with the same trusted `ServiceContext` that will review or execute the command. Every function returns `{ kind: 'authorized', value }` or a typed rejection; callers must not turn a rejection into an empty list.

| Public function | Scope and command inputs it supplies |
| --- | --- |
| `listMemberIdentityEvidence` | Member-scoped evidence ID, state, kind, expiry, and immutable `documentVersionId`/`digest` binding for identity verification and legal-name changes. Requires `maintain` or `supervise`. |
| `listMemberAddresses` | Stable party-address and address IDs, dated purpose, postal fields, evidence state, and evidence version for address reconciliation. |
| `listMemberConsents` | Consent ID, exact party/account scope, purpose, channel, disclosure version, state, and effective instant. |
| `listDocumentSignatures` | Signature ID, signer party, current status, request/signing times, and response evidence for one readable immutable document version. |
| `listMemberRetentionHolds` | Hold ID, exact document-or-case scope, state, reason, review time, and release time. Restricted cases and documents follow current reader visibility. |
| `listMemberCommunicationPreferences` | Preference ID and current purpose/channel/state with `updatedAt`. |
| `listMemberAddressDestinations` | Destination ID, context and target ID, party-address ID, evidence version, optional consent, and effective interval. |
| `listDocumentAnnotations` | Annotation ID and complete-state `fingerprint` for amend/remove, plus page, region, text, status, actor, and creation time. |
| `listMemberMaintenanceRequests` | Request ID/number, current `state` and `updatedAt` concurrency token, requested draft, applied receipt, and bounded attachment version IDs. |
| `listMemberCommunicationJobs` | Job ID, document version, purpose/channel/destination, and current `state`; use `communicationJob` when the ordered event history is required. |
| `listServicingQueues` | Queue ID, code, display name, and visibility for case creation and routing. |
| `listEffectivePolicyVersions` | Policy version ID/name/version effective at `context.now`, or at the dataset clock when no trusted time override is supplied. |
| `listServicingApprovalCheckers` | Other active actor IDs currently holding a grant accepted by the named servicing command; the current actor is excluded and grants are evaluated at the trusted clock. |

List limits default to 200 and must be safe integers from 1 through 500. Each read fetches one extra row and returns `limit_exceeded` when the requested bound cannot represent the full scoped result; it never silently truncates. `listMemberMaintenanceRequests` applies the same 1–500 rule independently to requests and each request's attachments. Checker discovery also rejects an active-operator directory above 500 rather than returning a partial authority list. Missing members return `not_found`, invalid limits and command kinds return `validation`, and a mismatched institution/dataset binding returns `not_authorized`.

Treat every returned ID as opaque and keep it with its institution/dataset binding. Before a write, retain the current token required by that command: annotation `fingerprint`, maintenance-request `updatedAt`, communication-job `state`, immutable evidence version/digest, and the selected queue, policy, checker, consent, destination, signature, or hold ID. Document-linked results use the same document-read policy as direct retrieval, so an absent row must not be used to infer that restricted evidence does not exist. After `stale_version` or a changed fingerprint/state, reread and review the new terms instead of replaying the old command.

- Core commands cover members, contact information, notes, accounts, cash, transfers, cases, saved searches and durable draft cancellation. Finance commands cover dated ownership/product/facility decisions, holds/restrictions, fees/reversals/corrections, beneficiaries/payments/schedules, cards/disputes/loans, reconciliation and batches. Servicing commands cover identity evidence, documents/signatures/redaction, consent/preferences, information requests, retention, escalation, annotations, notices and maintenance requests. Their strict input types are exported from `./services`; use `validateServiceCommand` at untyped boundaries.
- `queryCore` and `queryFinance` authorize ordinary inquiries within one database snapshot. Servicing readers accept a trusted `ServiceContext`. Lower-level `SqlDatabase` helpers are backend primitives; authorization is required before exposing their results. Supply trusted reader identity to member/case/document helpers to enforce restricted evidence visibility.
- `queryMemberMergePlan(store, context, planId)` requires supervisory authority and returns the source/survivor, plan decisions, and complete connected record identities with fingerprints. Bind its `fingerprint` as `member.merge.expectedInventoryFingerprint` before requesting independent approval. The transaction rechecks both member versions and the complete inventory, including related cards, loans, consent, document bytes, servicing history, audit and receipts. Reconcile conflicting identity/contact facts before that approval; merging retains separate historical party and consent scopes and the survivor's current contact details. A new relationship or changed plan requires a fresh review and approval. Inventory refuses more than 10,000 records, 64 MiB of evidence, or 32 relationship levels instead of approving a partial snapshot. Shared blobs and household addresses do not pull unrelated identities into scope.
- `approval.request` and `approval.decide` preserve an exact reviewed target and independent maker/checker authority. Neither executes the approved target. Submit the target command separately with its approval ID, current fingerprint/version and the original authorized terms. A receipt for an unrelated action cannot establish that a maintenance request was applied.
- Saved searches store a validated definition (entity, filters, sort, columns, optional result limit) with an owner, a visibility and a revision. Updates and deletes carry the revision the caller read, and only the owner may change a search. A definition that no longer validates is returned with a `problem` instead of being applied.
- `reviewCommand` validates against current data and returns the exact terms without writing. `executeCommand` commits the effect, an operation, a receipt and audit events in one transaction. The outcome is `committed`, `duplicate`, `unchanged` or `rejected` with a stable code.
- An idempotency key makes a retry return the stored receipt. A reused key with a different command or actor is rejected as `idempotency_conflict`.
- The optional business clock must be a valid instant with an explicit timezone offset. Services normalize it to UTC; date-only decisions resolve against the institution timezone. Effective product and facility revisions preserve the opening historical baseline. Facility expiry removes that authority without reviving an older limit. Writes older than a committed event for the same resource are rejected.
- Durable receipts retain canonical result JSON and its digest, so a retry returns the same output. Pending, issued, queued, delivered and committed remain distinct states. Trusted system callbacks record synthetic delivery and signature outcomes; a browser cannot select its own principal kind.
- Electronic statement delivery requires effective consent for the account. An exact account decision overrides a party-wide decision; a withdrawn account grant does not withdraw another account's grant. Opening a new electronic account requires party-wide consent. Paper remains available, and selecting an already stored preference returns unchanged. Apps without consent-entry UI must expose the service's eligibility reason and may offer an explicitly selected paper option.
- Monetary preparation checks exact resulting account balances, and journal writers reject a posting that would exceed the supported exact ledger balance range. Account and ledger business numbers allocate independently under the transaction lock, preserving datasets that use different account-number formats.
- Account closure checks outstanding obligations independently of their display state: nonzero facility usage blocks even when suspended or closed, and paused schedules or unresolved planned/materialized/released occurrences remain blocking. Retire those obligations through their separately authorized commands; a zero posted balance alone does not make closure eligible.
- Record commands carry the version the caller reviewed. A stale version is rejected as `stale_version`, and changes to other records do not invalidate it.
- `exportStatement` returns a coherent HTML/CSV/PDF bundle with hashes and an approved destination identifier. The app must save the returned bytes and report the actual save outcome; artifact generation does not establish file persistence. Historical issued statements use `retrieveHistoricalStatement`. A generated month exceeding 10,000 journal lines rejects explicitly, with no partial artifact.
- Query helpers return bounded pages, record details, stamps for stale-edit polling, receipts, statement data, generated statement PDFs and transaction CSV artifacts with digests. Member, account and case searches also accept `ids` (at most 500) to ask which of a known set of records match the current filters.
- The actor always comes from the caller's trusted context. `verificationRunStore(run)` adapts an evaluator run's `read` and `write`, so an application can act inside a verification run without opening its own connection. Closing that store only detaches it.

## Evaluation boundaries

The [evaluation seed tools](../../../evaluation/seed/README.md) map all 284 catalog entries to data prerequisites or explicit runtime requirements. The mapping includes connected workflow witnesses rather than unrelated table counts. Exact worked cases use nine additional isolated datasets for C01–C08, including C07's two-institution comparison.

Case selection, approved inputs, expected answers, injected events, replay artifacts, browser ownership and grading remain under `evaluation/`. They are not columns on customer records. Realistic historical receipts belong in business data; future agent effects do not.

A passing database audit establishes the checked data invariants. It does not establish that an application implements a capability or that an agent can execute a task. Timed peer edits, lost acknowledgements, stale views, crashes, takeover races and structural UI changes need their own runtime implementation.

Fixture-family assessment is recorded per declared variant. A variant is database-verified only when an executable seed invariant proves the exact stored shape or a named service test executes that fixture boundary. Seed-generator declarations alone remain partial, and a verified fixture proves reusable test data rather than task behavior, application presentation, or agent success.

## Verification

```sh
npm run check
node ../../../evaluation/seed/coverage.mjs .runtime/financial.sqlite ../../../evaluation/seed/coverage-report.json
node --test ../../../evaluation/seed/*.test.mjs
```

Document indexing and redaction require Poppler (`pdfinfo` and `pdftotext`) on the backend PATH. PDF inspection is bounded to five seconds and 1MiB of diagnostic output; malformed or unavailable inspection rejects the operation. Document tests additionally use Tesseract (`tesseract`) to verify actual scan pixels. PDF generation uses package dependencies and the bundled font. PNG and JPEG indexing and independent audit fully decode bounded image content.

Tests cover SQLite persistence, binding, cloning, pagination, financial/reference/lifecycle invariants, deliberately corrupted databases, document bytes, deterministic generation, connected catalog prerequisites and exact worked-case starting states. The generated SQLite file is local runtime data and is ignored by Git; commit the reproducible generator and verification tools instead.

`npm run check` also runs the database-only evaluation suite. It includes seed coverage and concrete expected-effect, forbidden-effect, output, and workflow tests from `evaluation/verifier/`. All 102 business task IDs and all 30 workflows have selected executable database cases. The verifier coverage inventory (historical material omitted from this bundle) records individual variants and limits; passing these cases does not qualify application or agent behavior.

See the implementation and verification record (historical material omitted from this bundle) for the actual population counts, reviewed artifacts, commands that passed and remaining integration work. Evaluation's untranspiled integration test requires Node 24.2 or newer; the recorded verification used Node 25.9.0.

## Isolated verification runs

The `./verification` package export provides `createRun` and `loadRunEvidence`. It captures committed row events and coherent snapshots in disposable copies of this database. The trusted evaluator owns task contracts, grading, and report retention in [evaluation/verifier](../../../evaluation/verifier/README.md). Verifier capture requires Node 25.9 or newer with SQLite authorizer support. Desktop MDI, terminal host and virtualized workspace include executable evaluator-run adapter examples. Current application qualification and downstream setup are linked from the handoff guide (historical material omitted from this bundle).


## Application-agent handoff

1. Select one institution/dataset binding on the shared database. Derive actor identity, principal kind and allowed export destinations from trusted backend/session configuration. Keep business numbers as strings, including leading zeros. Never infer institution scope from a matching number.
2. Use the shared query APIs to obtain current identities, versions/fingerprints, document versions and business exceptions. Pass exact integer minor units with explicit currency. Display those reviewed terms before consequential submission.
3. Use one stable idempotency key for one intent; retain it across a lost acknowledgement. Reconcile through the stored receipt before creating another intent. A changed payload requires a new review and intent. Treat `rejected`, `unchanged`, `duplicate` and `committed` explicitly; preserve rejection diagnostics.
4. For evaluator qualification, the evaluator creates a private `startTaskRun` or `startWorkflowRun` contract and gives the backend a `verificationRunStore(session)`. Route every application write through that store. Application closure detaches the store; only the evaluator seals, grades and disposes its run. Keep expected values, fault schedules and reports outside application code and web roots.
5. Submit actual application outputs and collected artifacts to the evaluator. Inspect named failed assertions and the retained baseline/effect report. Qualify positive, rejected, cancelled, stale, retry and applicable peer-interleaving paths through the real UI. Database reports prove only their explicit effects and outputs, not navigation or agent decisions.

All eleven applications consume this financial package; the three white-label deployments share the vendor implementation. Application readiness is maintained in each `capability-manifest.json` and derived by `npm --prefix environments run audit:full-v1` from the repository root. Use the downstream handoff (historical material omitted from this bundle) for the current application inventory, ports, and qualification commands. Database verification alone does not promote an application or qualify a downstream agent.
