import { APPROVAL_GRANTS } from './approval-types.js';
import { FINANCE_GRANTS } from './finance-types.js';
import { SERVICING_GRANTS } from './servicing-types.js';
import type { CaseState, CommandKind, Eligibility, OrganizationType } from './types.js';

/** Current facts that determine whether an account may be debited, credited or closed. */
export interface AccountFacts {
  status: string;
  postedMinorUnits: number;
  activeHolds: number;
  activeReservations: number;
  activeRestrictions: readonly string[];
  facilityUsedMinorUnits: number;
  openLoans: number;
  activeCards: number;
  pendingPayments: number;
  activeSchedules: number;
}

const RESTRICTION_EFFECTS: Readonly<Record<string, { debit: boolean; credit: boolean; closure: boolean; label: string }>> = {
  'debit-block': { debit: true, credit: false, closure: false, label: 'Debit block' },
  'credit-block': { debit: false, credit: true, closure: false, label: 'Credit block' },
  'closure-block': { debit: false, credit: false, closure: true, label: 'Closure block' },
  'fraud-review': { debit: true, credit: true, closure: true, label: 'Fraud review' },
  'legal-hold': { debit: true, credit: false, closure: true, label: 'Legal hold' },
};

function statusReason(status: string): string | null {
  return status === 'open' ? null : `Account status is ${status}; money movement requires an open account.`;
}

function restrictionReasons(facts: AccountFacts, effect: 'debit' | 'credit' | 'closure'): string[] {
  return facts.activeRestrictions.flatMap((kind) => {
    const rule = RESTRICTION_EFFECTS[kind];
    if (rule === undefined) return [`Active ${kind} restriction blocks this action.`];
    return rule[effect] ? [`Active ${rule.label.toLowerCase()} restriction blocks ${effect === 'closure' ? 'closure' : `${effect}s`}.`] : [];
  });
}

function eligibility(reasons: readonly (string | null)[]): Eligibility {
  const present = reasons.filter((reason): reason is string => reason !== null);
  return { eligible: present.length === 0, reasons: present };
}

export function debitEligibility(facts: AccountFacts): Eligibility {
  return eligibility([statusReason(facts.status), ...restrictionReasons(facts, 'debit')]);
}

export function creditEligibility(facts: AccountFacts): Eligibility {
  return eligibility([statusReason(facts.status), ...restrictionReasons(facts, 'credit')]);
}

/**
 * Closure never moves or writes off funds, so every obligation must already be absent.
 * Any active restriction blocks closure until it is released through its own authority.
 */
export function closureEligibility(facts: AccountFacts): Eligibility {
  return eligibility([
    facts.status === 'open' ? null : `Account status is ${facts.status}; only open accounts can be closed.`,
    facts.postedMinorUnits === 0 ? null : 'Posted balance must be exactly zero.',
    facts.activeHolds === 0 ? null : `${facts.activeHolds} active hold(s) must be released first.`,
    facts.activeReservations === 0 ? null : `${facts.activeReservations} active payment reservation(s) remain.`,
    ...facts.activeRestrictions.map((kind) => `Active ${RESTRICTION_EFFECTS[kind]?.label.toLowerCase() ?? kind} restriction must be released first.`),
    facts.facilityUsedMinorUnits === 0 ? null : 'An overdraft or credit facility has a used balance.',
    facts.openLoans === 0 ? null : 'A loan on this account is not closed.',
    facts.activeCards === 0 ? null : `${facts.activeCards} active card(s) must be blocked or replaced first.`,
    facts.pendingPayments === 0 ? null : `${facts.pendingPayments} payment(s) are still in progress.`,
    facts.activeSchedules === 0 ? null : `${facts.activeSchedules} unretired payment schedule(s) use this account.`,
  ]);
}

/** Allowed case transitions. Closing and reopening are explicit so history is never rewritten. */
export const CASE_TRANSITIONS: Readonly<Record<CaseState, readonly CaseState[]>> = {
  open: ['pending-customer', 'pending-internal', 'resolved'],
  'pending-customer': ['open', 'pending-internal', 'resolved'],
  'pending-internal': ['open', 'pending-customer', 'resolved'],
  resolved: [],
  closed: [],
  reopened: ['pending-customer', 'pending-internal', 'resolved'],
};

export function caseTransitionAllowed(from: CaseState, to: CaseState): boolean {
  return CASE_TRANSITIONS[from].includes(to);
}

export const CASE_CATEGORIES: Readonly<Record<string, string>> = {
  'account-servicing': 'Account servicing',
  'address-evidence': 'Address evidence',
  'contact-evidence': 'Contact evidence',
  'statement-copy': 'Statement copy',
  'transaction-inquiry': 'Transaction inquiry',
  'fee-inquiry': 'Fee inquiry',
  complaint: 'Complaint',
  general: 'General servicing',
};

/**
 * Saved searches are a servicing workspace tool: viewers, servicers and supervisors keep their own.
 * Payments roles hold none of these grants and cannot save searches.
 */
const SAVED_SEARCH_GRANTS: readonly string[] = ['read', 'maintain', 'case.manage', 'supervise'];

/**
 * Seeded role permissions that authorize each capability. The seed grants `maintain` to servicers
 * and `transfer.internal` to payments makers; there is no separate cash grant, so branch cash
 * handling uses the servicer's maintenance authority.
 */
export const CAPABILITY_GRANTS: Readonly<Record<CommandKind, readonly string[]>> = {
  ...FINANCE_GRANTS, ...SERVICING_GRANTS, ...APPROVAL_GRANTS,
  'edit.cancel': ['maintain'],
  'member.create': ['maintain'],
  'member.organization.create': ['maintain'],
  'contact.update': ['maintain'],
  'member.note.add': ['member.note.add'],
  'account.open': ['maintain'],
  'account.nickname.update': ['maintain'],
  'account.statement_delivery.update': ['maintain'],
  'account.close': ['maintain'],
  'cash.deposit': ['maintain'],
  'cash.withdraw': ['maintain'],
  'transfer.internal': ['transfer.internal'],
  'case.open': ['case.manage'],
  'case.assign': ['case.manage', 'supervise'],
  'case.transition': ['case.manage'],
  'case.note.add': ['case.manage'],
  'search.saved.create': SAVED_SEARCH_GRANTS,
  'search.saved.update': SAVED_SEARCH_GRANTS,
  'search.saved.delete': SAVED_SEARCH_GRANTS,
};

/** Sharing a search with the institution's team additionally needs case or supervisory authority. */
export const SHARED_SEARCH_GRANTS: readonly string[] = ['case.manage', 'supervise'];

/**
 * Reading or writing a restricted member or case note needs case or supervisory authority. Readers
 * without it, and reads that do not name a reader, see general notes and a count of withheld ones.
 */
export const RESTRICTED_NOTE_GRANTS: readonly string[] = ['case.manage', 'supervise'];

/**
 * Routing a case out of a restricted or supervisor queue into a queue of other visibility widens the
 * team that works it and sees its evidence, so it needs supervisory authority; supervisors may route
 * cases for that reason. Case managers route among general queues and into narrower ones.
 */
export const QUEUE_WIDENING_GRANTS: readonly string[] = ['supervise'];

export function routeWidensExposure(fromVisibility: string, toVisibility: string): boolean {
  return fromVisibility !== 'general' && toVisibility !== fromVisibility;
}

/** Tax classification recorded for a new organization member, as the seed classifies organizations. */
export const ORGANIZATION_TAX_CLASSIFICATIONS: Readonly<Record<OrganizationType, string>> = {
  corporation: 'organization',
  nonprofit: 'tax-exempt',
};

export const LIMITS = {
  savedSearchNameLength: 80,
  savedSearchesPerActor: 50,
  maxOpenAccountsPerMember: 50,
  nicknameLength: 40,
  descriptionLength: 120,
  noteLength: 2_000,
  reasonLength: 500,
  summaryLength: 200,
  nameLength: 60,
  organizationNameLength: 120,
  emailLength: 254,
  addressLineLength: 80,
  cityLength: 60,
  regionLength: 40,
  postalCodeLength: 12,
} as const;
