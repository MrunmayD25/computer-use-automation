import { createHash } from 'node:crypto';
import type { DatabaseSync, SQLOutputValue } from 'node:sqlite';
import { PDFDocument } from 'pdf-lib';
import { PNG } from 'pngjs';
import { decode as decodeJpeg } from 'jpeg-js';

interface AuditQuery {
  name: string;
  sql: string;
}

export interface AuditFailure {
  name: string;
  witnesses: Record<string, SQLOutputValue>[];
}

function lifecycleQuery(parent: string, events: string, foreignKey: string, stateColumn = 'state'): string {
  const resource = parent === 'communication_jobs' ? 'communication-job' : parent === 'payments' ? 'payment' : parent === 'cards' ? 'card' : 'case';
  const lifecycleState = parent === 'payments' ? " AND e.state<>'return-resolved'" : '';
  return `WITH ordered AS (
    SELECT e.*, LAG(occurred_at) OVER (PARTITION BY dataset_id,${foreignKey} ORDER BY sequence) AS previous_at,
      ROW_NUMBER() OVER (PARTITION BY dataset_id,${foreignKey} ORDER BY sequence) AS expected_sequence
    FROM ${events} e
  )
  SELECT e.dataset_id,e.id,'chronology' AS failure FROM ordered e JOIN datasets d ON d.id=e.dataset_id
  WHERE julianday(e.occurred_at) IS NULL OR (julianday(e.occurred_at)>julianday(d.as_of) AND NOT EXISTS (SELECT 1 FROM business_events b JOIN operations o ON o.dataset_id=b.dataset_id AND o.id=b.operation_id WHERE b.dataset_id=e.dataset_id AND b.resource_kind='${resource}' AND b.resource_id=e.${foreignKey} AND b.occurred_at=e.occurred_at AND o.occurred_at=e.occurred_at))
    OR julianday(e.occurred_at)<julianday(e.previous_at) OR e.sequence<>e.expected_sequence
  UNION ALL
  SELECT p.dataset_id,p.id,'final state' FROM ${parent} p
  WHERE NOT EXISTS (SELECT 1 FROM ${events} e WHERE e.dataset_id=p.dataset_id AND e.${foreignKey}=p.id)
    OR p.${stateColumn}<>(SELECT e.state FROM ${events} e
      WHERE e.dataset_id=p.dataset_id AND e.${foreignKey}=p.id${lifecycleState} ORDER BY e.sequence DESC LIMIT 1)`;
}

export const auditQueries: readonly AuditQuery[] = [
  { name: 'SQLite integrity', sql: "SELECT integrity_check FROM pragma_integrity_check WHERE integrity_check<>'ok'" },
  { name: 'foreign keys', sql: 'PRAGMA foreign_key_check' },
  { name: 'deposit maturity contract scope', sql: `SELECT c.dataset_id,c.id,c.account_id,c.currency,c.maturity_date,c.cutoff_at FROM deposit_maturity_terms c
      JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
      JOIN product_terms t ON t.dataset_id=c.dataset_id AND t.id=c.product_term_id
      JOIN products p ON p.dataset_id=t.dataset_id AND p.id=t.product_id
      WHERE c.currency<>a.currency OR c.currency<>p.currency OR p.family<>'deposit'
        OR date(c.maturity_date) IS NULL OR date(c.maturity_date)<>c.maturity_date
        OR julianday(c.cutoff_at) IS NULL OR julianday(c.cutoff_at)>=julianday(c.maturity_date)
        OR c.projected_proceeds_minor_units<0` },
  {
    name: 'payment ledger evidence',
    sql: `SELECT p.dataset_id,p.id,'missing or unexpected posting' AS failure FROM payments p
      WHERE (p.state='settled' AND (
          (SELECT count(*) FROM payment_postings pp WHERE pp.dataset_id=p.dataset_id AND pp.payment_id=p.id AND pp.kind='settlement')<>1
          OR (SELECT count(*) FROM payment_postings pp WHERE pp.dataset_id=p.dataset_id AND pp.payment_id=p.id AND pp.kind='return')<>0))
        OR (p.state='returned' AND (
          (SELECT count(*) FROM payment_postings pp WHERE pp.dataset_id=p.dataset_id AND pp.payment_id=p.id AND pp.kind='settlement')<>1
          OR (SELECT count(*) FROM payment_postings pp WHERE pp.dataset_id=p.dataset_id AND pp.payment_id=p.id AND pp.kind='return') NOT IN (0,1)))
        OR (p.state NOT IN ('settled','returned') AND
          (SELECT count(*) FROM payment_postings pp WHERE pp.dataset_id=p.dataset_id AND pp.payment_id=p.id)<>0)
      UNION ALL
      SELECT p.dataset_id,p.id,'posting amount or direction' FROM payments p
      JOIN payment_postings pp ON pp.dataset_id=p.dataset_id AND pp.payment_id=p.id
      WHERE NOT EXISTS (SELECT 1 FROM journals j JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id
        JOIN ledger_accounts la ON la.dataset_id=l.dataset_id AND la.id=l.ledger_account_id
        JOIN operation_receipts r ON r.dataset_id=j.dataset_id AND r.operation_id=j.operation_id
        WHERE j.dataset_id=pp.dataset_id AND j.id=pp.journal_id AND la.customer_account_id=p.source_account_id
          AND l.currency=p.currency AND CASE pp.kind WHEN 'settlement' THEN l.debit_minor_units-l.credit_minor_units
            ELSE l.credit_minor_units-l.debit_minor_units END=p.amount_minor_units)
      UNION ALL
      SELECT pp.dataset_id,pp.id,'posting lifecycle date' FROM payment_postings pp
      JOIN journals j ON j.dataset_id=pp.dataset_id AND j.id=pp.journal_id
      WHERE NOT EXISTS(SELECT 1 FROM payment_events e WHERE e.dataset_id=pp.dataset_id AND e.payment_id=pp.payment_id
        AND ((pp.kind='settlement' AND e.state='settled') OR (pp.kind='return' AND e.state IN ('returned','return-resolved')))
        AND e.occurred_at=j.posted_at)`,
  },
  {
    name: 'institution dataset identity',
    sql: `SELECT w.world_name,w.institution_id,w.dataset_id FROM world_datasets w
      LEFT JOIN datasets d ON d.id=w.dataset_id LEFT JOIN institutions i ON i.id=w.institution_id
      WHERE d.id IS NULL OR i.id IS NULL OR w.institution_id<>d.institution_id`,
  },
  {
    name: 'world dataset completeness',
    sql: `SELECT w.name,COUNT(d.dataset_id) AS dataset_count FROM worlds w
      LEFT JOIN world_datasets d ON d.world_name=w.name GROUP BY w.name HAVING dataset_count<>3`,
  },
  {
    name: 'balanced journals',
    sql: `SELECT j.dataset_id,j.id,l.currency,COUNT(l.line_number) AS lines,
        SUM(l.debit_minor_units) AS debit,SUM(l.credit_minor_units) AS credit
      FROM journals j LEFT JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id
      GROUP BY j.dataset_id,j.id,l.currency
      HAVING COUNT(l.line_number)<2 OR SUM(l.debit_minor_units)<>SUM(l.credit_minor_units)`,
  },
  {
    name: 'journal reversal evidence',
    sql: `SELECT r.dataset_id,r.id,'reversal chronology' AS failure FROM journals r
      JOIN journals original ON original.dataset_id=r.dataset_id AND original.id=r.reversal_of_id
      WHERE r.id=original.id OR julianday(r.posted_at)<julianday(original.posted_at)
      UNION ALL
      SELECT r.dataset_id,r.id,'reversal amount' FROM journals r
      JOIN journal_lines l ON l.dataset_id=r.dataset_id AND l.journal_id IN (r.id,r.reversal_of_id)
      WHERE r.reversal_of_id IS NOT NULL
      GROUP BY r.dataset_id,r.id,l.ledger_account_id,l.currency
      HAVING SUM(l.debit_minor_units-l.credit_minor_units)<>0`,
  },
  {
    name: 'consistent accounting currencies',
    sql: `SELECT l.dataset_id,l.journal_id AS id,'ledger line' AS failure FROM journal_lines l
      JOIN ledger_accounts a ON a.dataset_id=l.dataset_id AND a.id=l.ledger_account_id WHERE l.currency<>a.currency
      UNION ALL SELECT a.dataset_id,a.id,'account product' FROM accounts a
      JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id WHERE a.currency<>p.currency
      UNION ALL SELECT l.dataset_id,l.id,'customer ledger' FROM ledger_accounts l
      JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.customer_account_id WHERE l.currency<>a.currency
      UNION ALL SELECT p.dataset_id,p.id,'payment account' FROM payments p
      JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE p.currency<>a.currency
      UNION ALL SELECT f.dataset_id,f.id,'fee account' FROM fees f
      JOIN accounts a ON a.dataset_id=f.dataset_id AND a.id=f.account_id WHERE f.currency<>a.currency`,
  },
  {
    name: 'independent available balances',
    sql: `WITH ledger_totals AS (
      SELECT l.dataset_id,l.customer_account_id AS account_id,SUM(
        CASE l.normal_side WHEN 'debit' THEN e.debit_minor_units-e.credit_minor_units
          ELSE e.credit_minor_units-e.debit_minor_units END) AS amount
      FROM ledger_accounts l JOIN journal_lines e ON e.dataset_id=l.dataset_id AND e.ledger_account_id=l.id
      JOIN journals j ON j.dataset_id=e.dataset_id AND j.id=e.journal_id
      WHERE l.customer_account_id IS NOT NULL AND j.status='posted'
      GROUP BY l.dataset_id,l.customer_account_id
    ), held_totals AS (
      SELECT dataset_id,account_id,SUM(amount_minor_units) AS amount FROM holds
      WHERE status='active' AND (expires_at IS NULL OR expires_at>(SELECT as_of FROM datasets WHERE id=holds.dataset_id)) GROUP BY dataset_id,account_id
    ), reserved_totals AS (
      SELECT dataset_id,account_id,SUM(amount_minor_units) AS amount FROM reservations
      WHERE status='active' GROUP BY dataset_id,account_id
    ), dated_limits AS (
      SELECT term.*,ROW_NUMBER() OVER(PARTITION BY term.dataset_id,term.facility_id ORDER BY term.effective_at DESC,term.id DESC) AS rank
      FROM facility_limit_terms term JOIN datasets clock ON clock.id=term.dataset_id WHERE term.effective_at<=clock.as_of
    ), credit_totals AS (
      SELECT f.dataset_id,f.account_id,SUM(MAX(0,CASE WHEN t.id IS NULL THEN f.limit_minor_units WHEN t.expires_at IS NOT NULL AND t.expires_at<=d.as_of THEN 0 ELSE t.limit_minor_units END-f.used_minor_units)) AS amount FROM facilities f
      LEFT JOIN dated_limits t ON t.dataset_id=f.dataset_id AND t.facility_id=f.id AND t.rank=1 JOIN datasets d ON d.id=f.dataset_id
      WHERE f.status='active' GROUP BY f.dataset_id,f.account_id
    ), posted AS (
      SELECT a.dataset_id,a.id,COALESCE(l.amount,0) AS amount,COALESCE(h.amount,0) AS held,
        COALESCE(r.amount,0) AS reserved,COALESCE(f.amount,0) AS credit
      FROM accounts a
      LEFT JOIN ledger_totals l ON l.dataset_id=a.dataset_id AND l.account_id=a.id
      LEFT JOIN held_totals h ON h.dataset_id=a.dataset_id AND h.account_id=a.id
      LEFT JOIN reserved_totals r ON r.dataset_id=a.dataset_id AND r.account_id=a.id
      LEFT JOIN credit_totals f ON f.dataset_id=a.dataset_id AND f.account_id=a.id
    ) SELECT p.*,b.posted_balance_minor_units,b.available_balance_minor_units FROM posted p
      JOIN account_balances b ON b.dataset_id=p.dataset_id AND b.account_id=p.id
      WHERE p.amount<>b.posted_balance_minor_units OR p.amount-p.held-p.reserved+p.credit<>b.available_balance_minor_units`,
  },
  {
    name: 'remaining fee entitlement',
    sql: `SELECT f.dataset_id,f.id,f.status,f.original_amount_minor_units,
        COALESCE(SUM(r.amount_minor_units),0) AS refunded
      FROM fees f LEFT JOIN fee_refunds r ON r.dataset_id=f.dataset_id AND r.fee_id=f.id
      GROUP BY f.dataset_id,f.id
      HAVING refunded>f.original_amount_minor_units
        OR (f.status='fully-refunded' AND refunded<>f.original_amount_minor_units)
        OR (f.status='partially-refunded' AND (refunded<=0 OR refunded>=f.original_amount_minor_units))
        OR (f.status IN ('assessed','waived') AND refunded<>0)`,
  },
  {
    name: 'refund journal evidence',
    sql: `SELECT r.dataset_id,r.id FROM fee_refunds r JOIN fees f ON f.dataset_id=r.dataset_id AND f.id=r.fee_id
      JOIN journals j ON j.dataset_id=r.dataset_id AND j.id=r.journal_id
      WHERE r.journal_id=f.journal_id OR julianday(r.refunded_at) IS NULL
        OR julianday(r.refunded_at)<(SELECT julianday(posted_at) FROM journals WHERE dataset_id=f.dataset_id AND id=f.journal_id)
        OR r.amount_minor_units<>(SELECT COALESCE(SUM(l.credit_minor_units-l.debit_minor_units),0)
          FROM journal_lines l JOIN ledger_accounts a ON a.dataset_id=l.dataset_id AND a.id=l.ledger_account_id
          WHERE l.dataset_id=r.dataset_id AND l.journal_id=r.journal_id AND a.customer_account_id=f.account_id AND l.currency=f.currency)`,
  },
  {
    name: 'loan component accounting',
    sql: `SELECT c.dataset_id,c.id,'component ledger' AS failure FROM loan_components c
      JOIN loans n ON n.dataset_id=c.dataset_id AND n.id=c.loan_id
      JOIN ledger_accounts a ON a.dataset_id=c.dataset_id AND a.id=c.ledger_account_id
      WHERE a.currency<>n.currency OR a.kind<>'loan-'||c.kind OR a.normal_side<>'debit'
        OR c.balance_minor_units<>(SELECT COALESCE(SUM(l.debit_minor_units-l.credit_minor_units),0)
          FROM journal_lines l WHERE l.dataset_id=c.dataset_id AND l.ledger_account_id=c.ledger_account_id)
      UNION ALL SELECT n.dataset_id,n.id,'principal component' FROM loans n
      WHERE NOT EXISTS (SELECT 1 FROM loan_components c
        WHERE c.dataset_id=n.dataset_id AND c.loan_id=n.id AND c.kind='principal')
      UNION ALL SELECT a.dataset_id,a.id,'allocation ownership' FROM loan_allocations a
      JOIN loan_components c ON c.dataset_id=a.dataset_id AND c.id=a.component_id WHERE c.loan_id<>a.loan_id`,
  },
  {
    name: 'loan payment allocation evidence',
    sql: `SELECT a.dataset_id,a.payment_journal_id,c.ledger_account_id,SUM(a.amount_minor_units) AS allocated
      FROM loan_allocations a JOIN loan_components c ON c.dataset_id=a.dataset_id AND c.id=a.component_id
      GROUP BY a.dataset_id,a.payment_journal_id,c.ledger_account_id
      HAVING allocated<>(SELECT COALESCE(SUM(l.credit_minor_units-l.debit_minor_units),0)
        FROM journal_lines l WHERE l.dataset_id=a.dataset_id AND l.journal_id=a.payment_journal_id
          AND l.ledger_account_id=c.ledger_account_id)`,
  },
  {
    name: 'loan currency and application identity',
    sql: `SELECT n.dataset_id,n.id FROM loans n
      JOIN accounts a ON a.dataset_id=n.dataset_id AND a.id=n.account_id
      JOIN loan_applications p ON p.dataset_id=n.dataset_id AND p.id=n.application_id
      WHERE n.currency<>a.currency OR n.currency<>p.currency OR a.member_id<>p.member_id OR p.state<>'approved'
        OR (n.state IN ('paid-off','closed') AND EXISTS (SELECT 1 FROM loan_components c
          WHERE c.dataset_id=n.dataset_id AND c.loan_id=n.id AND c.balance_minor_units<>0))`,
  },
  {
    name: 'remaining dispute entitlement',
    sql: `SELECT d.dataset_id,d.id,d.claimed_amount_minor_units,
        COALESCE(SUM(CASE c.kind WHEN 'reversal' THEN -c.amount_minor_units ELSE c.amount_minor_units END),0) AS credited
      FROM disputes d LEFT JOIN dispute_credits c ON c.dataset_id=d.dataset_id AND c.dispute_id=d.id
      GROUP BY d.dataset_id,d.id HAVING credited<0 OR credited>d.claimed_amount_minor_units`,
  },
  {
    name: 'approval separation and scope',
    sql: `SELECT a.dataset_id,a.id FROM business_approvals a JOIN datasets d ON d.id=a.dataset_id
      WHERE json_valid(a.scope_json)=0 OR a.action_fingerprint=''
        OR (a.status IN ('approved','consumed') AND a.maker_actor_id=a.checker_actor_id)
        OR (a.amount_limit_minor_units IS NOT NULL AND (a.amount_limit_minor_units<0 OR a.currency IS NULL))
        OR (a.status='approved' AND julianday(a.expires_at)<=julianday(d.as_of))`,
  },
  { name: 'payment lifecycle', sql: lifecycleQuery('payments', 'payment_events', 'payment_id') },
  {
    name: 'payment execution evidence',
    sql: `SELECT p.dataset_id,p.id,'settled before requested date' AS failure FROM payments p
      JOIN payment_events e ON e.dataset_id=p.dataset_id AND e.payment_id=p.id
      WHERE e.state='settled' AND date(e.occurred_at)<p.requested_date
      UNION ALL SELECT r.dataset_id,r.id,'reservation ownership' FROM reservations r
      JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id
      WHERE r.account_id<>p.source_account_id OR r.amount_minor_units<>p.amount_minor_units
        OR (r.status='active' AND p.state NOT IN ('pending-approval','released','cancellation-requested'))
      UNION ALL SELECT r.dataset_id,r.id,'accepted cancellation chronology' FROM payment_cancel_requests r
      WHERE r.state='accepted' AND NOT EXISTS (SELECT 1 FROM payment_events e
        WHERE e.dataset_id=r.dataset_id AND e.payment_id=r.payment_id AND e.state='cancelled'
          AND julianday(e.occurred_at)>=julianday(r.requested_at))
      UNION ALL SELECT r.dataset_id,r.id,'return chronology' FROM payment_returns r
      WHERE NOT EXISTS (SELECT 1 FROM payment_events e WHERE e.dataset_id=r.dataset_id AND e.payment_id=r.payment_id
        AND e.state='settled' AND julianday(e.occurred_at)<=julianday(r.occurred_at))
        OR NOT EXISTS (SELECT 1 FROM payment_events e WHERE e.dataset_id=r.dataset_id AND e.payment_id=r.payment_id
          AND e.state='returned' AND julianday(e.occurred_at)>=julianday(r.occurred_at))`,
  },
  {
    name: 'schedule occurrence ownership',
    sql: `SELECT o.dataset_id,o.id FROM schedule_occurrences o
      JOIN payment_schedules s ON s.dataset_id=o.dataset_id AND s.id=o.schedule_id
      LEFT JOIN payments p ON p.dataset_id=o.dataset_id AND p.id=o.payment_id
      WHERE (o.state IN ('released','settled') AND p.id IS NULL)
        OR (p.id IS NOT NULL AND (p.source_account_id<>s.source_account_id
          OR p.beneficiary_route_id<>s.beneficiary_route_id OR p.requested_date<>o.local_date))
        OR o.local_date<s.start_date
        OR (s.end_date IS NOT NULL AND o.local_date>s.end_date AND NOT (s.state='ended' AND o.state IN ('cancelled','released','settled')))`,
  },
  { name: 'card lifecycle', sql: lifecycleQuery('cards', 'card_events', 'card_id', 'status') },
  { name: 'case lifecycle', sql: lifecycleQuery('cases', 'case_events', 'case_id') },
  { name: 'communication lifecycle', sql: lifecycleQuery('communication_jobs', 'communication_events', 'job_id') },
  {
    name: 'temporal evidence',
    sql: `SELECT e.dataset_id,e.id,'identity expiration' AS failure FROM identity_evidence e
      JOIN datasets d ON d.id=e.dataset_id
      WHERE (length(e.issued_at)=10 AND (date(e.issued_at) IS NULL OR date(e.issued_at)<>e.issued_at OR e.issued_at>substr(d.as_of,1,10)))
        OR (length(e.issued_at)<>10 AND (julianday(e.issued_at) IS NULL OR julianday(e.issued_at)>julianday(d.as_of)))
        OR julianday(e.expires_at)<julianday(e.issued_at)
        OR (e.status='verified' AND e.expires_at IS NOT NULL AND CASE WHEN length(e.expires_at)=10 THEN e.expires_at<substr(d.as_of,1,10) ELSE julianday(e.expires_at)<=julianday(d.as_of) END)
        OR (e.status='expired' AND (e.expires_at IS NULL OR CASE WHEN length(e.expires_at)=10 THEN e.expires_at>=substr(d.as_of,1,10) ELSE julianday(e.expires_at)>julianday(d.as_of) END))
      UNION ALL SELECT s.dataset_id,s.id,'signature evidence' FROM signatures s
      WHERE (s.status='signed' AND (s.signed_at IS NULL OR s.evidence_reference IS NULL OR s.evidence_reference=''))
        OR julianday(s.signed_at)<julianday(s.requested_at)
      UNION ALL SELECT q.dataset_id,q.id,'payoff validity' FROM payoff_quotes q
      WHERE julianday(q.expires_at)<julianday(q.as_of)
      UNION ALL SELECT a.dataset_id,a.id,'account closure' FROM accounts a
      WHERE (a.status='closed' AND a.closed_at IS NULL) OR julianday(a.closed_at)<julianday(a.opened_at)`,
  },
  {
    name: 'document evidence relationships',
    sql: `SELECT a.dataset_id,a.id,'annotation page' AS failure FROM document_annotations a
      JOIN document_versions v ON v.dataset_id=a.dataset_id AND v.id=a.document_version_id
      WHERE v.page_count IS NULL OR a.page_number>v.page_count OR json_valid(a.region_json)=0
      UNION ALL SELECT v.dataset_id,v.id,'document version' FROM document_versions v
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      WHERE v.media_type<>b.media_type OR julianday(v.issued_at)<julianday(d.created_at)
        OR (v.period_start IS NOT NULL AND (v.period_end IS NULL OR v.period_end<=v.period_start))
      UNION ALL SELECT b.dataset_id,b.id,'batch input digest' FROM batches b
      JOIN document_versions v ON v.dataset_id=b.dataset_id AND v.id=b.input_document_version_id
      WHERE b.input_digest<>v.digest`,
  },
  {
    name: 'positive and negative state witnesses',
    sql: `WITH required(domain,state) AS (VALUES
        ('account','open'),('account','restricted'),('account','closed'),
        ('identity','verified'),('identity','expired'),('identity','contradictory'),
        ('payment','settled'),('payment','rejected'),('payment','pending-approval'),
        ('card','active'),('card','temporarily-locked'),('card','permanently-blocked'),
        ('approval','approved'),('approval','denied'),('approval','expired'),
        ('fee','assessed'),('fee','partially-refunded'),('fee','fully-refunded'),
        ('loan','active'),('loan','delinquent'),('loan','paid-off'),
        ('communication','delivered'),('communication','bounced'),
        ('batch-item','applied'),('batch-item','invalid')),
      actual(dataset_id,domain,state) AS (
        SELECT a.dataset_id,'account',a.status FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
        UNION SELECT e.dataset_id,'identity',e.status FROM identity_evidence e JOIN members m ON m.dataset_id=e.dataset_id AND m.party_id=e.party_id
        UNION SELECT p.dataset_id,'payment',p.state FROM payments p JOIN beneficiary_routes r ON r.dataset_id=p.dataset_id AND r.id=p.beneficiary_route_id
        UNION SELECT c.dataset_id,'card',c.status FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
        UNION SELECT a.dataset_id,'approval',a.status FROM business_approvals a JOIN policy_versions p ON p.dataset_id=a.dataset_id AND p.id=a.policy_version_id
        UNION SELECT f.dataset_id,'fee',f.status FROM fees f JOIN journals j ON j.dataset_id=f.dataset_id AND j.id=f.journal_id
        UNION SELECT n.dataset_id,'loan',n.state FROM loans n JOIN loan_applications p ON p.dataset_id=n.dataset_id AND p.id=n.application_id
        UNION SELECT c.dataset_id,'communication',c.state FROM communication_jobs c JOIN document_versions v ON v.dataset_id=c.dataset_id AND v.id=c.document_version_id
        UNION SELECT i.dataset_id,'batch-item',i.state FROM batch_items i JOIN batches b ON b.dataset_id=i.dataset_id AND b.id=i.batch_id
      ) SELECT d.id AS dataset_id,r.domain,r.state FROM datasets d
      JOIN world_datasets w ON w.dataset_id=d.id CROSS JOIN required r
      WHERE NOT EXISTS (SELECT 1 FROM actual a WHERE a.dataset_id=d.id AND a.domain=r.domain AND a.state=r.state)`,
  },
];

export function findAuditViolations(database: DatabaseSync): AuditFailure[] {
  const receipts: AuditFailure[] = [];
  for (const row of database.prepare('SELECT dataset_id,id,result_json,result_digest FROM operation_receipts WHERE result_json IS NOT NULL').iterate()) {
    if (typeof row.result_json !== 'string' || createHash('sha256').update(row.result_json).digest('hex') !== row.result_digest) receipts.push({name: 'receipt output digest', witnesses: [row]});
  }
  return [...receipts, ...auditQueries.flatMap(({ name, sql }) => {
    const witnesses = database.prepare(sql).all();
    return witnesses.length === 0 ? [] : [{ name, witnesses }];
  })];
}

export async function auditDocuments(database: DatabaseSync): Promise<AuditFailure[]> {
  const failures: AuditFailure[] = [];
  const blobs = database.prepare('SELECT dataset_id,digest,media_type,byte_length,bytes FROM document_blobs').iterate();
  let blobCount = 0;
  for (const blob of blobs) {
    blobCount += 1;
    const witness = { dataset_id: blob.dataset_id ?? null, digest: blob.digest ?? null };
    if (!(blob.bytes instanceof Uint8Array)) {
      failures.push({ name: 'document binary storage', witnesses: [witness] });
      continue;
    }
    if (blob.byte_length !== blob.bytes.length) failures.push({ name: 'document byte length', witnesses: [witness] });
    if (createHash('sha256').update(blob.bytes).digest('hex') !== blob.digest) {
      failures.push({ name: 'document digest', witnesses: [witness] });
      continue;
    }
    if (blob.media_type === 'application/pdf') {
      try {
        const pdf = await PDFDocument.load(blob.bytes);
        const versions = database.prepare('SELECT id,page_count FROM document_versions WHERE dataset_id=? AND digest=?')
          .all(witness.dataset_id, witness.digest);
        if (versions.length === 0 || versions.some((version) => version.page_count !== pdf.getPageCount())
          || pdf.getPageCount() === 0 || pdf.getPages().some((page) => page.getWidth() <= 0
            || page.getHeight() <= 0 || page.node.Contents() === undefined)) {
          failures.push({ name: 'PDF page metadata', witnesses: [witness] });
        }
      } catch (error) {
        failures.push({ name: 'parseable PDF', witnesses: [{ ...witness,
          error: error instanceof Error ? error.message : String(error) }] });
      }
    } else if (blob.media_type === 'image/png') {
      const bytes = Buffer.from(blob.bytes);
      try {
        if (bytes.length < 33 || bytes.length > 20 * 1024 * 1024
          || bytes.subarray(0, 8).toString('hex') !== '89504e470d0a1a0a'
          || bytes.readUInt32BE(16) > 16_384 || bytes.readUInt32BE(20) > 16_384
          || bytes.readUInt32BE(16) * bytes.readUInt32BE(20) > 16_000_000) throw new Error('PNG exceeds decoding bounds or has an invalid header.');
        const decoded = PNG.sync.read(bytes, { checkCRC: true });
        if (decoded.width < 1 || decoded.height < 1) throw new Error('PNG dimensions must be positive.');
      } catch (error) { failures.push({name:'parseable PNG',witnesses:[{...witness,error:error instanceof Error ? error.message : String(error)}]}); }
    } else if (blob.media_type === 'image/jpeg') {
      try {
        const bytes = blob.bytes;
        if (bytes.length > 20 * 1024 * 1024 || bytes.at(-2) !== 255 || bytes.at(-1) !== 217) throw new Error('JPEG exceeds decoding bounds or lacks its end marker.');
        const decoded = decodeJpeg(bytes, {useTArray:true,formatAsRGBA:false,tolerantDecoding:false,maxResolutionInMP:16,maxMemoryUsageInMB:64});
        if (decoded.width < 1 || decoded.height < 1 || decoded.width > 16_384 || decoded.height > 16_384) throw new Error('JPEG dimensions are outside the supported bounds.');
      } catch (error) { failures.push({name:'parseable JPEG',witnesses:[{...witness,error:error instanceof Error ? error.message : String(error)}]}); }
    } else if (blob.media_type === 'application/json') {
      try { JSON.parse(new TextDecoder('utf-8', {fatal:true}).decode(blob.bytes)); }
      catch (error) { failures.push({name: 'JSON document bytes', witnesses: [{...witness,error: error instanceof Error ? error.message : String(error)}]}); }
    } else if (blob.media_type === 'text/csv' || blob.media_type === 'text/html' || blob.media_type === 'text/plain') {
      try {
        const contents = new TextDecoder('utf-8', { fatal: true }).decode(blob.bytes);
        if (contents.trim().length === 0) failures.push({ name: 'nonempty text document', witnesses: [witness] });
      } catch (error) {
        failures.push({ name: 'UTF-8 text document', witnesses: [{ ...witness,
          error: error instanceof Error ? error.message : String(error) }] });
      }
    } else {
      failures.push({ name: 'unsupported document format', witnesses: [witness] });
    }
  }
  if (blobCount === 0) failures.push({ name: 'missing document bytes', witnesses: [] });
  return failures;
}

export async function verifyFinancialDatabase(database: DatabaseSync): Promise<AuditFailure[]> {
  return [...findAuditViolations(database), ...await auditDocuments(database)];
}
