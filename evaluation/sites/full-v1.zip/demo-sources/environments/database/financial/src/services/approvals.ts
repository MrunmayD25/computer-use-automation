import { SERVICING_GRANTS, isServicingCommand, type ServicingCommand } from './servicing-types.js';
import { randomUUID } from 'node:crypto';
import { actorRef, all, authorize, authorizeQuery, canonicalJson, int, one, optionalInt, optionalStr, reject, run, sha256, str, type Row } from './core.js';
import { FINANCE_GRANTS, validateFinanceCommand, type FinanceCommand } from './finance-types.js';
import { contactCampaignApproval, refundCampaignApproval } from './finance-batch-approval.js';
import { financeApprovalFingerprint, financeApprovalScope } from './finance-support.js';
import type { Environment, Preparation } from './commands.js';
import type { FinancialStore } from './store.js';
import type { Money, Rejection, ServiceContext } from './types.js';

import type { ApprovalCommand } from './approval-types.js';
export type { ApprovalCommand } from './approval-types.js';

export function validateApprovalCommand(value: unknown): Rejection | null {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return reject('validation', 'An approval command must be an object.');
  const kind: unknown = Reflect.get(value, 'kind');
  const fields = kind === 'approval.request' ? ['kind', 'target', 'checkerActorId', 'policyVersionId', 'expiresAt', 'amountLimit'] : kind === 'approval.decide' ? ['kind', 'approvalId', 'expectedFingerprint', 'decision', 'reason'] : [];
  if (fields.length === 0 || fields.some(field => !Object.hasOwn(value, field)) || Object.keys(value).some(field => !fields.includes(field))) return reject('validation', 'Invalid approval fields.');
  for (const field of fields.filter(field => field !== 'target' && field !== 'amountLimit')) if (typeof Reflect.get(value, field) !== 'string') return reject('validation', `Invalid ${field}.`, { field });
  if (kind === 'approval.request') {
    const target: unknown = Reflect.get(value, 'target');
    const invalid = isServicingCommand(target) ? null : validateFinanceCommand(target);
    if (invalid !== null) return invalid;
    if (target === null || typeof target !== 'object' || !Object.hasOwn(target, 'approvalId')) return reject('validation', 'The target command does not require independent approval.');
    const amount: unknown = Reflect.get(value, 'amountLimit');
    if (amount !== null && (typeof amount !== 'object' || Object.keys(amount).sort().join(',') !== 'currency,minorUnits' || typeof Reflect.get(amount, 'currency') !== 'string' || !Number.isSafeInteger(Reflect.get(amount, 'minorUnits')))) return reject('validation', 'Approval amount limit must be exact Money or null.');
  } else if (!['approve', 'deny'].includes(String(Reflect.get(value, 'decision')))) return reject('validation', 'Approval decision must be approve or deny.');
  return null;
}

export function approvalFingerprint(row: Row): string {
  return sha256(canonicalJson(row));
}

export function prepareApproval(env: Environment, command: ApprovalCommand): Preparation {
  if (command.kind === 'approval.request') {
    if (command.checkerActorId === env.actorId) return reject('not_authorized', 'Maker and checker must be different operators.');
    const checkerDenied = authorize(env.database, env.datasetId, env.institutionId, command.checkerActorId, env.now, { ...FINANCE_GRANTS, ...SERVICING_GRANTS }[command.target.kind]);
    if (checkerDenied !== null) return checkerDenied;
    const expiry = Date.parse(command.expiresAt);
    if (!/T.*(?:Z|[+-]\d{2}:\d{2})$/u.test(command.expiresAt) || !Number.isFinite(expiry) || expiry <= Date.parse(env.now) || expiry > Date.parse(env.now) + 7 * 86_400_000) return reject('validation', 'Approval expiry must be an explicit instant in the next seven days.');
    const policy = one(env.database, 'SELECT id FROM policy_versions WHERE dataset_id=? AND id=? AND effective_at<=?', env.datasetId, command.policyVersionId, env.now);
    if (policy === undefined) return reject('ineligible', 'The approval policy is not effective.');
    if (command.amountLimit !== null && (command.amountLimit.minorUnits <= 0 || command.amountLimit.minorUnits > 1_000_000_000_000 || one(env.database, 'SELECT code FROM currencies WHERE code=?', command.amountLimit.currency) === undefined)) return reject('validation', 'Approval amount or currency is outside the supported range.');
    const refundCampaign = command.target.kind === 'batch.fee_refunds.apply' ? refundCampaignApproval(env.database, env.datasetId, command.target) : null;
    if (refundCampaign !== null && !('scope' in refundCampaign)) return refundCampaign;
    const contactCampaign = command.target.kind === 'batch.contacts.apply' ? contactCampaignApproval(env.database, env.datasetId, command.target) : null;
    if (contactCampaign !== null && !('scope' in contactCampaign)) return contactCampaign;
    if (refundCampaign !== null && 'scope' in refundCampaign && (command.amountLimit === null || command.amountLimit.currency !== refundCampaign.amount.currency || command.amountLimit.minorUnits !== refundCampaign.amount.minorUnits)) {
      return reject('validation', 'A refund campaign approval amount must exactly match the batch currency and maximum.', { field: 'amountLimit' });
    }
    if (contactCampaign !== null && 'scope' in contactCampaign && command.amountLimit !== null) return reject('validation', 'A contact campaign approval does not accept an amount limit.', { field: 'amountLimit' });
    const campaignScope = refundCampaign !== null && 'scope' in refundCampaign ? refundCampaign.scope
      : contactCampaign !== null && 'scope' in contactCampaign ? contactCampaign.scope : null;
    const scope = campaignScope ?? financeApprovalScope(command.target);
    const fingerprint = campaignScope === null ? financeApprovalFingerprint(command.target) : sha256(canonicalJson(scope));
    const duplicate = one(env.database, "SELECT id FROM business_approvals WHERE dataset_id=? AND maker_actor_id=? AND checker_actor_id=? AND action_fingerprint=? AND status IN ('pending','approved') AND expires_at>?", env.datasetId, env.actorId, command.checkerActorId, fingerprint, env.now);
    if (duplicate !== undefined) return { kind: 'unchanged', message: `Approval ${str(duplicate, 'id')} already covers this pending action.` };
    const id = `approval-${randomUUID()}`;
    return { kind: 'prepared', businessReference: id, result: { approvalId: id, state: 'pending', fingerprint, scope }, review: { amount: command.amountLimit, exponent: null, description: command.target.kind, accounts: [], consequences: [campaignScope === null ? 'Requests independent approval without executing the target business operation.' : `Binds ${campaignScope.items instanceof Array ? campaignScope.items.length : 0} exact immutable ${refundCampaign !== null ? 'refund' : 'contact'} rows for restartable item checkpoints; no item is applied.`] }, apply(apply) {
      run(apply.database, 'INSERT INTO business_approvals (dataset_id,id,maker_actor_id,checker_actor_id,action_fingerprint,scope_json,amount_limit_minor_units,currency,policy_version_id,status,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)', apply.datasetId, id, apply.actorId, command.checkerActorId, fingerprint, canonicalJson(scope), command.amountLimit?.minorUnits ?? null, command.amountLimit?.currency ?? null, command.policyVersionId, 'pending', new Date(expiry).toISOString());
      apply.event({ kind: 'approval', id }, `Independent approval requested for ${command.target.kind}.`);
    } };
  }
  const row = one(env.database, 'SELECT * FROM business_approvals WHERE dataset_id=? AND id=?', env.datasetId, command.approvalId);
  if (row === undefined) return reject('not_found', 'The approval does not exist.');
  if (approvalFingerprint(row) !== command.expectedFingerprint) return reject('stale_version', 'The approval changed after review.');
  if (str(row, 'checker_actor_id') !== env.actorId || str(row, 'maker_actor_id') === env.actorId) return reject('not_authorized', 'Only the assigned independent checker can decide this approval.');
  if (str(row, 'status') !== 'pending' || str(row, 'expires_at') <= env.now) return reject('ineligible', 'The approval is no longer pending and valid.');
  if (command.reason.trim().length === 0 || command.reason.length > 500) return reject('validation', 'A decision reason of 1 to 500 characters is required.');
  const scope: unknown = JSON.parse(str(row, 'scope_json'));
  const kind: unknown = scope !== null && typeof scope === 'object' ? Reflect.get(scope, 'kind') : undefined;
  if (typeof kind !== 'string' || !Object.hasOwn({ ...FINANCE_GRANTS, ...SERVICING_GRANTS }, kind)) return reject('validation', 'The approval target is invalid.');
  const denied = authorize(env.database, env.datasetId, env.institutionId, env.actorId, env.now, { ...FINANCE_GRANTS, ...SERVICING_GRANTS }[kind as (FinanceCommand | ServicingCommand)['kind']]);
  if (denied !== null) return denied;
  const status = command.decision === 'approve' ? 'approved' : 'denied';
  return { kind: 'prepared', businessReference: command.approvalId, result: { approvalId: command.approvalId, status }, review: { amount: optionalInt(row, 'amount_limit_minor_units') === null ? null : { minorUnits: int(row, 'amount_limit_minor_units'), currency: str(row, 'currency') }, exponent: null, description: command.reason, accounts: [], consequences: [`Records an independent ${status} decision; the target operation remains separate.`] }, apply(apply) {
    run(apply.database, 'UPDATE business_approvals SET status=? WHERE dataset_id=? AND id=?', status, apply.datasetId, command.approvalId);
    apply.event({ kind: 'approval', id: command.approvalId }, `${status}: ${command.reason.trim()}`);
  } };
}

/** Bounded pending work for the named maker/checker, with review fingerprints. */
export function listApprovals(store: FinancialStore, context: ServiceContext, limit = 100): { kind: 'found'; approvals: { id: string; status: string; fingerprint: string; target: unknown; expiresAt: string; amountLimit: Money | null; maker: { id: string; actorNumber: string; displayName: string }; checker: { id: string; actorNumber: string; displayName: string } }[]; total: number; truncated: boolean } | Rejection {
  return store.read(database => {
    const denied = authorizeQuery(database, context);
    if (denied !== null) return denied;
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 200) return reject('validation', 'Approval limit must be between 1 and 200.');
    const parameters = [context.binding.datasetId, context.actorId, context.actorId];
    const where = 'dataset_id=? AND (maker_actor_id=? OR checker_actor_id=?)';
    const total = int(one(database, `SELECT COUNT(*) AS n FROM business_approvals WHERE ${where}`, ...parameters), 'n');
    const rows = all(database, `SELECT * FROM business_approvals WHERE ${where} ORDER BY expires_at,id LIMIT ?`, ...parameters, limit);
    return {
      kind: 'found', total, truncated: total > rows.length,
      approvals: rows.map((row) => {
        const maker = actorRef(database, context.binding.datasetId, str(row, 'maker_actor_id'));
        const checker = actorRef(database, context.binding.datasetId, str(row, 'checker_actor_id'));
        if (maker === undefined || checker === undefined) throw new Error(`Approval ${str(row, 'id')} references a missing actor.`);
        return {
          id: str(row, 'id'), status: str(row, 'status'), fingerprint: approvalFingerprint(row), target: JSON.parse(str(row, 'scope_json')) as unknown,
          expiresAt: str(row, 'expires_at'), amountLimit: optionalStr(row, 'currency') === null ? null : { currency: str(row, 'currency'), minorUnits: int(row, 'amount_limit_minor_units') },
          maker, checker,
        };
      }),
    };
  });
}
