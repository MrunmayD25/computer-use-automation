import { actorPermissions, datasetClock, one } from './core.js';
import { RESTRICTED_NOTE_GRANTS } from './rules.js';
import type { SqlDatabase } from './store.js';

export interface DocumentReader { institutionId: string; actorId: string; now?: string }

/** Internal SQL predicate for a document/version join using aliases d and v. */
export function documentReadFilter(database: SqlDatabase, datasetId: string, reader: DocumentReader | undefined): string {
  const clock=datasetClock(database,datasetId);
  const active=reader!==undefined && reader.institutionId===clock.institutionId && one(database,"SELECT id FROM actors WHERE dataset_id=? AND id=? AND status='active'",datasetId,reader.actorId)!==undefined;
  const permissions=active ? actorPermissions(database,datasetId,reader.institutionId,reader.actorId,reader.now??clock.asOf) : new Set<string>();
  const restricted=RESTRICTED_NOTE_GRANTS.some(grant=>permissions.has(grant));
  return `${restricted ? '1' : "NOT EXISTS (SELECT 1 FROM case_documents access_link WHERE access_link.dataset_id=v.dataset_id AND access_link.document_version_id=v.id AND access_link.visibility='restricted') AND NOT EXISTS (SELECT 1 FROM case_note_documents nd JOIN case_notes n ON n.dataset_id=nd.dataset_id AND n.id=nd.note_id WHERE nd.dataset_id=v.dataset_id AND nd.document_version_id=v.id AND n.visibility='restricted')"} AND ${permissions.has('supervise') ? '1' : "d.document_type<>'customer-record-export'"}`;
}

/** Content and metadata share the same access policy, including restrictions inherited from evidence links. */
export function canReadDocument(database: SqlDatabase, datasetId: string, versionId: string, reader: DocumentReader | undefined): boolean {
  return one(database,`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE v.dataset_id=? AND v.id=? AND ${documentReadFilter(database,datasetId,reader)}`,datasetId,versionId)!==undefined;
}
