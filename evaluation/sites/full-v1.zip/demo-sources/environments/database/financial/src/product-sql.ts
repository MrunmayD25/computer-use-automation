/** Product decisions are effective at an explicit instant; the opening product remains the historical baseline. */
export function accountProductSql(clock: string): string {
  return `COALESCE((SELECT decision.product_id FROM account_product_history decision WHERE decision.dataset_id=a.dataset_id AND decision.account_id=a.id AND decision.effective_at<=${clock} ORDER BY decision.effective_at DESC,decision.id DESC LIMIT 1),a.product_id)`;
}
