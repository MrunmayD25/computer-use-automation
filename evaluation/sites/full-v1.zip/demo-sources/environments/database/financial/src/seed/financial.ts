import { createHash } from 'node:crypto';

import type { CoreSeedReferences, ExtendedSeedReferences, SeedContext } from './contract.js';
import { insertTwoLineJournal } from './core.js';

type SqlValue = string | number | bigint | Uint8Array | null;
type SqlRow = Record<string, SqlValue>;
type PaymentState = 'draft' | 'pending-approval' | 'released' | 'settled' | 'rejected' | 'cancellation-requested' | 'cancelled' | 'returned';
type LoanState = 'active' | 'delinquent' | 'paid-off' | 'closed';

interface PaymentSeedRecord {
  id: string;
  sourceAccountId: string;
  beneficiaryRouteId: string;
  requestedDate: string;
  finalState: PaymentState;
}

function at<T>(values: readonly T[], index: number, label: string): T {
  const value = values[index];
  if (value === undefined) throw new Error(`Missing ${label} at index ${index}.`);
  return value;
}

function stringColumn(row: SqlRow, name: string): string {
  const value = row[name];
  if (typeof value !== 'string') throw new Error(`Expected ${name} to be a string.`);
  return value;
}

function accountDetails(context: SeedContext, accountId: string): { memberId: string; currency: string; customerLedgerId: string } {
  const row = context.database.prepare(`
    SELECT a.member_id, a.currency, la.id AS customer_ledger_id
    FROM accounts a JOIN ledger_accounts la ON la.dataset_id=a.dataset_id AND la.customer_account_id=a.id
    WHERE a.dataset_id=? AND a.id=?
  `).get(context.binding.datasetId, accountId) as SqlRow | undefined;
  if (row === undefined) throw new Error(`Account ${accountId} has no customer ledger.`);
  return { memberId: stringColumn(row, 'member_id'), currency: stringColumn(row, 'currency'), customerLedgerId: stringColumn(row, 'customer_ledger_id') };
}

function partyForMember(context: SeedContext, memberId: string): string {
  const row = context.database.prepare('SELECT party_id FROM members WHERE dataset_id=? AND id=?').get(context.binding.datasetId, memberId) as SqlRow | undefined;
  if (row === undefined) throw new Error(`Unknown member ${memberId}.`);
  return stringColumn(row, 'party_id');
}

function dateAfter(isoDate: string, days: number): string {
  const date = new Date(`${isoDate}T15:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString();
}

function statePath(finalState: PaymentState): readonly PaymentState[] {
  switch (finalState) {
    case 'draft': return ['draft'];
    case 'pending-approval': return ['draft', 'pending-approval'];
    case 'released': return ['draft', 'pending-approval', 'released'];
    case 'settled': return ['draft', 'pending-approval', 'released', 'settled'];
    case 'rejected': return ['draft', 'pending-approval', 'rejected'];
    case 'cancellation-requested': return ['draft', 'pending-approval', 'released', 'cancellation-requested'];
    case 'cancelled': return ['draft', 'pending-approval', 'released', 'cancellation-requested', 'cancelled'];
    case 'returned': return ['draft', 'pending-approval', 'released', 'settled', 'returned'];
  }
}

function seedPayments(context: SeedContext, refs: CoreSeedReferences): PaymentSeedRecord[] {
  const payments: PaymentSeedRecord[] = [];
  const count = context.scale === 'small' ? 40 : context.scale === 'standard' ? 1_200 : 2_400;
  const states: readonly PaymentState[] = ['draft', 'pending-approval', 'released', 'settled', 'rejected', 'cancellation-requested', 'cancelled', 'returned'];
  const beneficiaryInsert = context.database.prepare('INSERT INTO beneficiaries (dataset_id,id,owner_party_id,display_name,status) VALUES (?,?,?,?,?)');
  const routeInsert = context.database.prepare('INSERT INTO beneficiary_routes (dataset_id,id,beneficiary_id,version,routing_kind,masked_destination,simulated_token,status,verified_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?)');
  const paymentInsert = context.database.prepare('INSERT INTO payments (dataset_id,id,reference,source_account_id,beneficiary_route_id,amount_minor_units,currency,requested_date,state,version) VALUES (?,?,?,?,?,?,?,?,?,?)');
  const eventInsert = context.database.prepare('INSERT INTO payment_events (dataset_id,id,payment_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?,?,?,?,?)');
  const fundedOpenAccounts = (context.database.prepare(`SELECT a.id FROM accounts a JOIN account_balances b
    ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.status='open'
    AND b.posted_balance_minor_units>100000 ORDER BY a.id`).all(context.binding.datasetId) as SqlRow[]).map((row) => stringColumn(row, 'id'));
  if (fundedOpenAccounts.length === 0) throw new Error('Payments require funded open accounts.');
  for (let index = 0; index < count; index += 1) {
    const accountId = at(fundedOpenAccounts, index % fundedOpenAccounts.length, 'payment source account');
    const account = accountDetails(context, accountId);
    const partyId = partyForMember(context, account.memberId);
    const beneficiaryId = context.id('beneficiary', index + 1);
    const routeId = context.id('beneficiary-route', index + 1);
    const paymentId = context.id('payment', index + 1);
    const finalState = at(states, index % states.length, 'payment state');
    const requestedAt = dateAfter('2026-01-05', index % 220);
    const requestedDate = requestedAt.slice(0, 10);
    const neverReleased = finalState === 'draft' || finalState === 'rejected';
    const routeStatus = neverReleased && index % 17 === 0 ? 'unverified' : index % 13 === 0 ? 'expired' : 'verified';
    beneficiaryInsert.run(context.binding.datasetId, beneficiaryId, partyId, index % 12 === 0 ? 'Community Electric' : `Local Counterparty ${String(index % 37).padStart(2, '0')}`, neverReleased && index % 19 === 0 ? 'disabled' : 'active');
    routeInsert.run(context.binding.datasetId, routeId, beneficiaryId, 1, index % 3 === 0 ? 'ach' : 'internal', `****${String(1000 + (index % 9000)).slice(-4)}`, context.id('simulated-route', index + 1), routeStatus, routeStatus === 'unverified' ? null : '2026-01-01T15:00:00.000Z', routeStatus === 'expired' ? '2026-09-01T00:00:00.000Z' : '2027-08-01T00:00:00.000Z');
    if (index < 8) routeInsert.run(context.binding.datasetId, context.id('beneficiary-route-old', index + 1), beneficiaryId, 2, 'ach', `****${String(8000 + index).slice(-4)}`, context.id('simulated-route-new', index + 1), 'verified', '2026-08-01T00:00:00.000Z', '2027-08-01T00:00:00.000Z');

    const amount = 100 + ((index * 7919) % 150_000);
    const events = statePath(finalState).map((state, sequence) => ({ state, occurredAt: dateAfter(requestedDate, sequence) }));
    payments.push({ id: paymentId, sourceAccountId: accountId, beneficiaryRouteId: routeId, requestedDate, finalState });
    paymentInsert.run(context.binding.datasetId, paymentId, context.businessNumber('PM', index + 1, 9), accountId, routeId, amount, account.currency, requestedDate, finalState, 1 + (index % 4));
    events.forEach((event, sequence) => eventInsert.run(context.binding.datasetId, context.id('payment-event', `${index + 1}-${sequence + 1}`), paymentId, sequence + 1, event.state, event.occurredAt, at(refs.actorIds, (index + sequence) % refs.actorIds.length, 'payment actor'), `${event.state} under synthetic policy`));
    if (finalState === 'pending-approval' || finalState === 'released' || finalState === 'cancellation-requested') {
      context.database.prepare('INSERT INTO reservations (dataset_id,id,account_id,payment_id,amount_minor_units,status,created_at,ended_at) VALUES (?,?,?,?,?,?,?,NULL)').run(context.binding.datasetId, context.id('reservation', index + 1), accountId, paymentId, amount, 'active', at(events, 1, 'reservation event').occurredAt);
    }
    if (finalState === 'returned') {
      const returned = at(events, events.length - 1, 'return event');
      context.database.prepare('INSERT INTO payment_returns (dataset_id,id,payment_id,return_code,amount_minor_units,occurred_at,settlement_reference) VALUES (?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('payment-return', index + 1), paymentId, 'R01', amount, returned.occurredAt, `EXT-RETURN-${context.businessNumber('PM', index + 1, 9)}`);
    }
    if (finalState === 'cancelled' || finalState === 'cancellation-requested') {
      const cancellation = events.find((event) => event.state === 'cancellation-requested');
      if (cancellation === undefined) throw new Error(`Payment ${paymentId} has no cancellation event.`);
      context.database.prepare('INSERT INTO payment_cancel_requests (dataset_id,id,payment_id,actor_id,state,reason,requested_at) VALUES (?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('payment-cancel', index + 1), paymentId, at(refs.actorIds, index % refs.actorIds.length, 'cancellation actor'), finalState === 'cancelled' ? 'accepted' : 'requested', 'Customer requested cancellation', cancellation.occurredAt);
    }
  }

  const schedulable = payments.filter((payment) => payment.finalState === 'released' || payment.finalState === 'settled' || payment.finalState === 'returned');
  if (schedulable.length === 0) throw new Error('Payment schedules require released or settled payments.');
  const scheduleInsert = context.database.prepare('INSERT INTO payment_schedules (dataset_id,id,source_account_id,beneficiary_route_id,rule_json,time_zone,calendar_version,start_date,end_date,state) VALUES (?,?,?,?,?,?,?,?,?,?)');
  const occurrenceInsert = context.database.prepare('INSERT INTO schedule_occurrences (dataset_id,id,schedule_id,local_date,payment_id,state) VALUES (?,?,?,?,?,?)');
  for (let index = 0; index < 16; index += 1) {
    const payment = at(schedulable, index % schedulable.length, 'scheduled payment');
    const scheduleId = context.id('payment-schedule', index + 1);
    const scheduleState = at(['active', 'paused', 'ended'] as const, index % 3, 'schedule state');
    const finalOccurrenceDate = dateAfter(payment.requestedDate, 5).slice(0, 10);
    scheduleInsert.run(context.binding.datasetId, scheduleId, payment.sourceAccountId, payment.beneficiaryRouteId, JSON.stringify({ frequency: 'daily', interval: 1, shift: 'next-business-day' }), context.institution.timeZone, 'US-FI-2026.1', payment.requestedDate, scheduleState === 'ended' ? finalOccurrenceDate : null, scheduleState);
    for (let occurrence = 0; occurrence < 6; occurrence += 1) {
      const linked = occurrence === 0;
      occurrenceInsert.run(context.binding.datasetId, context.id('schedule-occurrence', `${index + 1}-${occurrence + 1}`), scheduleId, dateAfter(payment.requestedDate, occurrence).slice(0, 10), linked ? payment.id : null, linked ? payment.finalState === 'released' ? 'released' : 'settled' : 'planned');
    }
  }
  return payments;
}

function seedFees(context: SeedContext, refs: CoreSeedReferences): void {
  const count = Math.min(context.scale === 'small' ? 20 : 300, refs.accountIds.length);
  for (let index = 0; index < count; index += 1) {
    const accountId = at(refs.accountIds, index, 'fee account');
    const account = accountDetails(context, accountId);
    const gl = refs.glAccountIdsByCurrency[account.currency];
    if (gl === undefined) throw new Error(`Missing general ledger for ${account.currency}.`);
    const amount = 300 + (index % 8) * 100;
    const journalId = insertTwoLineJournal(context, `fee-${index + 1}`, account.customerLedgerId, gl.feeIncome, amount, account.currency, '2026-06-15T15:00:00.000Z', 'Monthly service fee');
    const feeId = context.id('fee', index + 1);
    const refunded = index % 4 === 0;
    const partial = index % 4 === 1;
    context.database.prepare('INSERT INTO fees (dataset_id,id,account_id,journal_id,original_amount_minor_units,currency,policy_version_id,status) VALUES (?,?,?,?,?,?,?,?)').run(context.binding.datasetId, feeId, accountId, journalId, amount, account.currency, context.id('policy', 1), refunded ? 'fully-refunded' : partial ? 'partially-refunded' : 'assessed');
    if (refunded || partial) {
      const refundAmount = refunded ? amount : Math.floor(amount / 2);
      const refundJournal = insertTwoLineJournal(context, `fee-refund-${index + 1}`, gl.feeIncome, account.customerLedgerId, refundAmount, account.currency, '2026-07-15T15:00:00.000Z', 'Linked fee refund');
      context.database.prepare('INSERT INTO fee_refunds (dataset_id,id,fee_id,journal_id,amount_minor_units,actor_id,refunded_at) VALUES (?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('fee-refund', index + 1), feeId, refundJournal, refundAmount, at(refs.actorIds, index % refs.actorIds.length, 'refund actor'), '2026-07-15T15:00:00.000Z');
      context.database.prepare('INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('correction', index + 1), journalId, refundJournal, refundAmount, 'refund');
    }
    if (index % 7 === 0) context.database.prepare('INSERT INTO fee_waivers (dataset_id,id,account_id,fee_id,fee_code,actor_id,amount_limit_minor_units,currency,valid_from,valid_through,max_occurrences,reason,state,created_at) VALUES (?,?,?,NULL,?,?,?,?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('fee-waiver', index + 1), accountId, 'monthly-service', at(refs.actorIds, index % refs.actorIds.length, 'waiver actor'), amount, account.currency, '2026-07-01', '2026-12-31', 3, 'Relationship waiver for future monthly fees', 'approved', '2026-06-16T15:00:00.000Z');
    if (index < 6) context.database.prepare('INSERT INTO transaction_amendments (dataset_id,id,journal_id,actor_id,old_description,new_description,amended_at) VALUES (?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('transaction-amendment', index + 1), journalId, at(refs.actorIds, (index + 1) % refs.actorIds.length, 'amendment actor'), 'Monthly service fee', `Monthly service fee for cycle ${index + 1}`, '2026-06-16T15:00:00.000Z');
    if (index < 3) {
      const actorId = at(refs.actorIds, 2, 'effective-date correction actor');
      const operationId = context.id('effective-date-operation', index + 1);
      const receiptId = context.id('effective-date-receipt', index + 1);
      const command = JSON.stringify({ journalId, oldEffectiveDate: '2026-06-15', newEffectiveDate: `2026-06-${String(12 + index).padStart(2, '0')}`, policyPeriod: ['2026-06-01', '2026-07-01'] });
      const digest = createHash('sha256').update(command).digest('hex');
      context.database.prepare('INSERT INTO operations (dataset_id,id,actor_id,operation_kind,business_reference,idempotency_key,command_digest,status,occurred_at) VALUES (?,?,?,?,?,?,?,?,?)').run(context.binding.datasetId, operationId, actorId, 'transaction.effective-date.correct', context.businessNumber('EC', index + 1, 7), `effective-date-${index + 1}`, digest, 'committed', '2026-06-17T15:00:00.000Z');
      context.database.prepare('INSERT INTO operation_receipts (dataset_id,id,operation_id,receipt_number,result_digest,committed_at) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, receiptId, operationId, context.businessNumber('EDC', index + 1, 7), digest, '2026-06-17T15:00:00.000Z');
      context.database.prepare('INSERT INTO effective_date_corrections (dataset_id,id,journal_id,actor_id,receipt_id,old_effective_date,new_effective_date,policy_version_id,policy_period_start,policy_period_end,reason,corrected_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('effective-date-correction', index + 1), journalId, actorId, receiptId, '2026-06-15', `2026-06-${String(12 + index).padStart(2, '0')}`, context.id('policy', 1), '2026-06-01', '2026-07-01', 'Corrected customer-requested posting date within open policy period', '2026-06-17T15:00:00.000Z');
    }
  }
}

function seedCardsAndDisputes(context: SeedContext, refs: CoreSeedReferences): string[] {
  const cardIds: string[] = [];
  const count = Math.min(context.scale === 'small' ? 36 : 600, refs.accountIds.length);
  const statuses = ['active', 'temporarily-locked', 'permanently-blocked', 'expired', 'replaced'] as const;
  const merchants = ['North Market', 'Metro Fuel', 'Lake Pharmacy'] as const;
  const categories = ['grocery', 'fuel', 'pharmacy'] as const;
  const disputeStates = ['submitted', 'investigating', 'provisional-credit', 'approved', 'denied', 'closed', 'draft', 'submitted'] as const;
  const fundedOpenAccounts = (context.database.prepare(`SELECT a.id FROM accounts a JOIN account_balances b
    ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.status='open'
    AND b.posted_balance_minor_units>100000 ORDER BY a.id`).all(context.binding.datasetId) as SqlRow[]).map((row) => stringColumn(row, 'id'));
  if (fundedOpenAccounts.length === 0) throw new Error('Cards require funded open accounts.');
  let disputeOrdinal = 0;
  for (let index = 0; index < count; index += 1) {
    const accountId = at(fundedOpenAccounts, index % fundedOpenAccounts.length, 'card account');
    const account = accountDetails(context, accountId);
    const cardId = context.id('card', index + 1);
    const status = at(statuses, index % statuses.length, 'card status');
    cardIds.push(cardId);
    context.database.prepare('INSERT INTO cards (dataset_id,id,account_id,token,last_four,expiry_month,expiry_year,status) VALUES (?,?,?,?,?,?,?,?)').run(context.binding.datasetId, cardId, accountId, context.id('card-token', index + 1), String(1000 + index).slice(-4), 1 + (index % 12), status === 'expired' ? 2025 : 2027 + (index % 4), status);
    const eventPath = status === 'active' ? ['active'] : ['active', status];
    eventPath.forEach((eventState, sequence) => context.database.prepare('INSERT INTO card_events (dataset_id,id,card_id,sequence,state,occurred_at,reason) VALUES (?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('card-event', `${index + 1}-${sequence + 1}`), cardId, sequence + 1, eventState, sequence === 0 ? '2024-12-10T15:00:00.000Z' : status === 'expired' ? '2025-12-31T15:00:00.000Z' : '2026-02-10T15:00:00.000Z', eventState === 'active' ? 'Issued' : 'Lifecycle update'));
    context.database.prepare('INSERT INTO card_limits (dataset_id,id,card_id,kind,amount_minor_units,currency,effective_at,expires_at) VALUES (?,?,?,?,?,?,?,NULL)').run(context.binding.datasetId, context.id('card-limit', index + 1), cardId, index % 3 === 0 ? 'cash' : 'daily-purchase', 100_000 + index * 1_000, account.currency, '2026-01-01T00:00:00.000Z');
    if (status.includes('locked') || status.includes('blocked')) context.database.prepare('INSERT INTO card_locks (dataset_id,id,card_id,kind,authority,state,placed_at,released_at) VALUES (?,?,?,?,?,?,?,NULL)').run(context.binding.datasetId, context.id('card-lock', index + 1), cardId, status === 'temporarily-locked' ? 'temporary' : 'permanent', 'card-risk', 'active', '2026-08-01T15:00:00.000Z');
    const transactionState = status === 'active' && index % 5 === 0 ? 'pending' : 'posted';
    const transactionAmount = 1_000 + index * 37;
    const occurredAt = status === 'active' ? '2026-08-20T15:00:00.000Z' : '2025-01-05T15:00:00.000Z';
    const gl = refs.glAccountIdsByCurrency[account.currency];
    if (gl === undefined) throw new Error(`Missing card GL for ${account.currency}.`);
    const journalId = transactionState === 'posted' ? insertTwoLineJournal(context, `card-purchase-${index + 1}`, account.customerLedgerId, gl.settlement, transactionAmount, account.currency, occurredAt, `Card purchase at ${at(merchants, index % merchants.length, 'merchant')}`) : null;
    context.database.prepare('INSERT INTO card_transactions (dataset_id,id,card_id,journal_id,merchant,merchant_category,amount_minor_units,currency,state,occurred_at) VALUES (?,?,?,?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('card-transaction', index + 1), cardId, journalId, at(merchants, index % merchants.length, 'merchant'), at(categories, index % categories.length, 'merchant category'), transactionAmount, account.currency, transactionState, occurredAt);
    if (journalId !== null && disputeOrdinal < disputeStates.length) {
      const disputeId = context.id('dispute', disputeOrdinal + 1);
      const disputeState = at(disputeStates, disputeOrdinal, 'dispute state');
      const claimedAmount = Math.min(transactionAmount, 500 + disputeOrdinal * 100);
      context.database.prepare('INSERT INTO disputes (dataset_id,id,case_number,account_id,journal_id,claimed_amount_minor_units,currency,state,deadline) VALUES (?,?,?,?,?,?,?,?,?)').run(context.binding.datasetId, disputeId, context.businessNumber('DP', disputeOrdinal + 1, 7), accountId, journalId, claimedAmount, account.currency, disputeState, '2026-10-01T00:00:00.000Z');
      if (disputeState === 'provisional-credit' || disputeState === 'approved' || disputeState === 'denied' || disputeState === 'closed') {
        const gl = refs.glAccountIdsByCurrency[account.currency];
        if (gl === undefined) throw new Error(`Missing dispute GL for ${account.currency}.`);
        const creditAmount = Math.floor(claimedAmount / 2);
        const creditJournalId = insertTwoLineJournal(context, `dispute-credit-${disputeOrdinal + 1}`, gl.settlement, account.customerLedgerId, creditAmount, account.currency, '2026-08-21T15:00:00.000Z', 'Provisional dispute credit');
        context.database.prepare('INSERT INTO dispute_credits (dataset_id,id,dispute_id,journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('dispute-credit', disputeOrdinal + 1), disputeId, creditJournalId, creditAmount, 'provisional');
        if (disputeState === 'denied') {
          const reversalJournalId = insertTwoLineJournal(context, `dispute-credit-reversal-${disputeOrdinal + 1}`, account.customerLedgerId, gl.settlement, creditAmount, account.currency, '2026-08-22T15:00:00.000Z', 'Reversed provisional dispute credit');
          context.database.prepare('INSERT INTO dispute_credits (dataset_id,id,dispute_id,journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('dispute-credit-reversal', disputeOrdinal + 1), disputeId, reversalJournalId, creditAmount, 'reversal');
          context.database.prepare('INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('dispute-correction', disputeOrdinal + 1), creditJournalId, reversalJournalId, creditAmount, 'reversal');
        }
      }
      disputeOrdinal += 1;
    }
    if (status === 'replaced') {
      const addressRow = context.database.prepare('SELECT pa.address_id FROM members m JOIN party_addresses pa ON pa.dataset_id=m.dataset_id AND pa.party_id=m.party_id WHERE m.dataset_id=? AND m.id=? LIMIT 1').get(context.binding.datasetId, account.memberId) as SqlRow | undefined;
      if (addressRow !== undefined) context.database.prepare('INSERT INTO card_replacement_orders (dataset_id,id,card_id,address_id,state,requested_at) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('card-replacement', index + 1), cardId, stringColumn(addressRow, 'address_id'), 'delivered', '2026-07-01T15:00:00.000Z');
    }
  }
  return cardIds;
}

function seedLoans(context: SeedContext, refs: CoreSeedReferences): string[] {
  const loanIds: string[] = [];
  const applicationCount = context.scale === 'small' ? 16 : context.scale === 'standard' ? 100 : 240;
  const currencies = ['USD', 'EUR', 'JPY', 'KWD'] as const;
  const applicationStates = ['draft', 'incomplete', 'submitted', 'approved', 'declined', 'expired'] as const;
  const loanStates: readonly LoanState[] = ['active', 'delinquent', 'paid-off', 'closed'];
  const accountInsert = context.database.prepare('INSERT INTO accounts (dataset_id,id,member_id,account_number,product_id,currency,status,nickname,statement_delivery,opened_at,closed_at,version) VALUES (?,?,?,?,?,?,?,?,?,?,?,1)');
  const ledgerInsert = context.database.prepare('INSERT INTO ledger_accounts (dataset_id,id,code,kind,currency,normal_side,customer_account_id) VALUES (?,?,?,?,?,?,?)');
  for (let index = 0; index < applicationCount; index += 1) {
    const currency = at(currencies, index % currencies.length, 'loan currency');
    const memberId = at(refs.memberIds, index % refs.memberIds.length, 'loan member');
    const applicationId = context.id('loan-application', index + 1);
    const applicationState = index < loanStates.length ? 'approved' : at(applicationStates, (index - loanStates.length) % applicationStates.length, 'loan application state');
    const originalPrincipal = 500_000 + index * 10_000;
    context.database.prepare('INSERT INTO loan_applications (dataset_id,id,member_id,product_id,requested_amount_minor_units,currency,terms_json,state) VALUES (?,?,?,?,?,?,?,?)').run(context.binding.datasetId, applicationId, memberId, context.id('product', `${currency}-loan`), originalPrincipal, currency, JSON.stringify({ termMonths: 36 + (index % 3) * 12, purpose: 'synthetic installment loan' }), applicationState);
    if (applicationState !== 'approved') continue;

    const accountId = context.id('loan-account', index + 1);
    const loanId = context.id('loan', index + 1);
    const state = at(loanStates, index % loanStates.length, 'loan state');
    const closedAt = state === 'closed' ? '2026-08-01T15:00:00.000Z' : null;
    accountInsert.run(context.binding.datasetId, accountId, memberId, context.businessNumber('LN', index + 1, 8), context.id('product', `${currency}-loan`), currency, state === 'closed' ? 'closed' : 'open', 'Installment loan', 'electronic', '2024-03-01T15:00:00.000Z', closedAt);
    context.database.prepare('INSERT INTO account_parties (dataset_id,account_id,party_id,role,starts_at,ends_at) VALUES (?,?,?,?,?,NULL)').run(context.binding.datasetId, accountId, partyForMember(context, memberId), 'owner', '2024-03-01T15:00:00.000Z');
    const principalLedger = context.id('loan-principal-ledger', index + 1);
    const interestLedger = context.id('loan-interest-ledger', index + 1);
    const feeLedger = context.id('loan-fee-ledger', index + 1);
    ledgerInsert.run(context.binding.datasetId, principalLedger, `${currency}-LOAN-P-${index + 1}`, 'loan-principal', currency, 'debit', accountId);
    ledgerInsert.run(context.binding.datasetId, interestLedger, `${currency}-LOAN-I-${index + 1}`, 'loan-interest', currency, 'debit', null);
    ledgerInsert.run(context.binding.datasetId, feeLedger, `${currency}-LOAN-F-${index + 1}`, 'loan-fee', currency, 'debit', null);
    const gl = refs.glAccountIdsByCurrency[currency];
    if (gl === undefined) throw new Error(`Missing GL for ${currency}.`);
    insertTwoLineJournal(context, `loan-disbursement-${index + 1}`, principalLedger, gl.settlement, originalPrincipal, currency, '2024-03-01T15:00:00.000Z', 'Loan disbursement');
    const currentPrincipal = state === 'paid-off' || state === 'closed' ? 0 : index === 0 ? 1 : Math.floor(originalPrincipal * (state === 'delinquent' ? 0.82 : 0.55));
    const paid = originalPrincipal - currentPrincipal;
    let paymentJournalId: string | null = null;
    if (paid > 0) paymentJournalId = insertTwoLineJournal(context, `loan-payment-${index + 1}`, gl.settlement, principalLedger, paid, currency, '2026-07-01T15:00:00.000Z', 'Loan payment allocation');
    context.database.prepare('INSERT INTO loans (dataset_id,id,account_id,application_id,principal_minor_units,currency,annual_rate_bps,state,opened_at) VALUES (?,?,?,?,?,?,?,?,?)').run(context.binding.datasetId, loanId, accountId, applicationId, originalPrincipal, currency, 650 + index % 250, state, '2024-03-01T15:00:00.000Z');
    const principalComponent = context.id('loan-component-principal', index + 1);
    const interestBalance = state === 'delinquent' ? 1_001 : 0;
    const feeBalance = state === 'delinquent' ? 500 : 0;
    if (interestBalance > 0) insertTwoLineJournal(context, `loan-interest-accrual-${index + 1}`, interestLedger, gl.feeIncome, interestBalance, currency, '2026-06-30T15:00:00.000Z', 'Loan interest accrual');
    if (feeBalance > 0) insertTwoLineJournal(context, `loan-fee-accrual-${index + 1}`, feeLedger, gl.feeIncome, feeBalance, currency, '2026-06-30T15:01:00.000Z', 'Loan late fee accrual');
    context.database.prepare('INSERT INTO loan_components (dataset_id,id,loan_id,kind,ledger_account_id,balance_minor_units) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, principalComponent, loanId, 'principal', principalLedger, currentPrincipal);
    context.database.prepare('INSERT INTO loan_components (dataset_id,id,loan_id,kind,ledger_account_id,balance_minor_units) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('loan-component-interest', index + 1), loanId, 'interest', interestLedger, interestBalance);
    context.database.prepare('INSERT INTO loan_components (dataset_id,id,loan_id,kind,ledger_account_id,balance_minor_units) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('loan-component-fee', index + 1), loanId, 'fee', feeLedger, feeBalance);
    if (state === 'active' || state === 'delinquent') {
      const receivedAmount = Math.min(currentPrincipal + interestBalance + feeBalance, 10_000);
      const sourceJournalId = insertTwoLineJournal(context, `received-funds-${index + 1}`, gl.cash, gl.settlement, receivedAmount, currency, '2026-09-13T15:00:00.000Z', 'Confirmed incoming loan payment funds');
      context.database.prepare(`INSERT INTO received_funds
        (dataset_id,id,reference,member_id,currency,amount_minor_units,source_journal_id,holding_ledger_account_id,state,received_at)
        VALUES (?,?,?,?,?,?,?,?, 'confirmed',?)`).run(context.binding.datasetId, context.id('received-funds', index + 1), context.businessNumber('RF', index + 1, 9), memberId, currency, receivedAmount, sourceJournalId, gl.settlement, '2026-09-13T15:00:00.000Z');
    }
    if (paymentJournalId !== null) context.database.prepare('INSERT INTO loan_allocations (dataset_id,id,loan_id,payment_journal_id,component_id,amount_minor_units) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('loan-allocation', index + 1), loanId, paymentJournalId, principalComponent, paid);
    context.database.prepare('INSERT INTO payoff_quotes (dataset_id,id,loan_id,as_of,expires_at,total_minor_units,lines_json,policy_version_id) VALUES (?,?,?,?,?,?,?,?)').run(context.binding.datasetId, context.id('payoff-quote', index + 1), loanId, index % 2 === 0 ? '2026-09-01T15:00:00.000Z' : '2026-08-01T15:00:00.000Z', index % 2 === 0 ? '2026-09-20T15:00:00.000Z' : '2026-08-15T15:00:00.000Z', currentPrincipal + interestBalance + feeBalance, JSON.stringify({ principal: currentPrincipal, interest: interestBalance, fees: feeBalance }), context.id('policy', 1));
    context.database.prepare('INSERT INTO loan_obligations (dataset_id,id,loan_id,kind,state,due_at) VALUES (?,?,?,?,?,?)').run(context.binding.datasetId, context.id('loan-obligation', index + 1), loanId, 'final-statement', state === 'paid-off' && index !== 2 ? 'open' : 'satisfied', '2026-10-01T00:00:00.000Z');
    if (state === 'closed') {
      if (closedAt === null || paymentJournalId === null) throw new Error(`Closed loan ${loanId} has no payoff evidence.`);
      context.database.prepare('INSERT INTO loan_closures (dataset_id,id,loan_id,receipt_id,closed_at,closure_document_version_id) VALUES (?,?,?,?,?,NULL)').run(context.binding.datasetId, context.id('loan-closure', index + 1), loanId, context.id('posting-receipt', `loan-payment-${index + 1}`), closedAt);
    }
    loanIds.push(loanId);
  }
  return loanIds;
}

export function seedFinancialDomains(context: SeedContext, refs: CoreSeedReferences): Pick<ExtendedSeedReferences, 'paymentIds' | 'cardIds' | 'loanIds'> {
  seedFees(context, refs);
  const payments = seedPayments(context, refs);
  const cardIds = seedCardsAndDisputes(context, refs);
  const loanIds = seedLoans(context, refs);
  return { paymentIds: payments.map((payment) => payment.id), cardIds, loanIds };
}
