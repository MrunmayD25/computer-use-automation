import { memberMergeInventory } from './member-merge.js';
import { accountProductSql } from '../product-sql.js';
import { all, canonicalJson, int, localDate, nextNumber, one, optionalInt, optionalStr, reject, run, str, zonedInstant, type Row } from './core.js';
import type { Preparation } from './commands.js';
import type { FinanceCommand } from './finance-types.js';
import {
  approvalPrepared, generalLedger, insertJournal, ledgerForAccount, loadAccount, loadMember, newId, noFinanceReview, prepared, requireAccountVersion,
  isEvidenceValidAt, normalizeInstant, requireApproval, requireDate, requireDebit, requireFingerprint, requireInstant, requireMemberVersion, requireMoney, requireText, rowFingerprint,
  type FinanceEnvironment,
} from './finance-support.js';
import type { Rejection } from './types.js';

type FinanceOf<K extends FinanceCommand['kind']> = Extract<FinanceCommand, { kind: K }>;

function validation(problems: readonly (Rejection | null)[]): Rejection | null { return problems.find((problem) => problem !== null) ?? null; }
function isRejection(value: Row | Rejection): value is Rejection { return value.kind === 'rejected'; }
function sorted(values: readonly string[]): string[] { return [...values].sort(); }
function sameStrings(left: readonly string[], right: readonly string[]): boolean { return canonicalJson(sorted(left)) === canonicalJson(sorted(right)); }

function prepareMemberMerge(env: FinanceEnvironment, command: FinanceOf<'member.merge'>): Preparation {
  if (command.sourceMemberId === command.targetMemberId) return reject('validation', 'Source and survivor must be different members.');
  const source = loadMember(env, command.sourceMemberId);
  const target = loadMember(env, command.targetMemberId);
  if (source === undefined || target === undefined) return reject('not_found', 'The source member or survivor does not exist at this institution.');
  const invalid = validation([requireMemberVersion(source, command.expectedSourceVersion), requireMemberVersion(target, command.expectedTargetVersion)]);
  if (invalid !== null) return invalid;
  if (str(source, 'status') === 'merged' || str(target, 'status') !== 'active') return reject('ineligible', 'The source must be unmerged and the survivor must be active.');
  const plan = one(env.database, 'SELECT source_member_id,target_member_id,state,conflicts_json FROM member_merge_plans WHERE dataset_id=? AND id=?', env.datasetId, command.mergePlanId);
  if (plan === undefined) return reject('not_found', 'The reviewed merge plan does not exist.');
  if (str(plan, 'source_member_id') !== command.sourceMemberId || str(plan, 'target_member_id') !== command.targetMemberId) return reject('ownership_mismatch', 'The merge plan names different members.');
  if (!['reviewed','approved'].includes(str(plan, 'state'))) return reject('ineligible', `Merge plan state is ${str(plan, 'state')}.`);
  let conflicts: unknown;
  try { conflicts = JSON.parse(str(plan, 'conflicts_json')); } catch { return reject('ineligible', 'The merge plan contains malformed conflict decisions.'); }
  const unresolved: unknown = conflicts !== null && typeof conflicts === 'object' ? Reflect.get(conflicts, 'unresolved') : undefined;
  if (!Array.isArray(unresolved) || unresolved.length > 0) return reject('ineligible', 'The merge plan must explicitly resolve every identity conflict.');
  const accounts = all(env.database, 'SELECT id FROM accounts WHERE dataset_id=? AND member_id=? ORDER BY id', env.datasetId, command.sourceMemberId).map((row) => str(row, 'id'));
  if (!sameStrings(accounts, command.relationshipAccountIds)) return reject('stale_version', 'The source member account set changed after merge review.');
  const sourceParty = str(source, 'party_id');
  const openCases = all(env.database, "SELECT id FROM cases WHERE dataset_id=? AND member_id=? AND state<>'closed' ORDER BY id", env.datasetId, command.sourceMemberId).map((row) => str(row, 'id'));
  const openRequests = all(env.database, "SELECT id FROM maintenance_requests WHERE dataset_id=? AND member_id=? AND state NOT IN ('applied','rejected','withdrawn','cancelled') ORDER BY id", env.datasetId, command.sourceMemberId).map((row) => str(row, 'id'));
  if (openCases.length > 0 || openRequests.length > 0) return reject('open_dependencies', `Resolve ${openCases.length} open case(s) and ${openRequests.length} active maintenance request(s) before merging this member.`);
  const historicalCaseIds = all(env.database, 'SELECT id FROM cases WHERE dataset_id=? AND member_id=? ORDER BY id', env.datasetId, command.sourceMemberId).map((row) => str(row, 'id'));
  const historicalRequestIds = all(env.database, 'SELECT id FROM maintenance_requests WHERE dataset_id=? AND member_id=? ORDER BY id', env.datasetId, command.sourceMemberId).map((row) => str(row, 'id'));
  const sourceDocumentIds = all(env.database, 'SELECT id FROM documents WHERE dataset_id=? AND owner_party_id=? ORDER BY id', env.datasetId, sourceParty).map((row) => str(row, 'id'));
  const inventory = memberMergeInventory(env.database, env.datasetId, command.mergePlanId);
  if (inventory.kind === 'rejected') return inventory;
  if (inventory.fingerprint !== command.expectedInventoryFingerprint) return reject('stale_version', 'The reviewed merge relationship inventory or plan changed; obtain a new inventory and approval.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({
    businessReference: command.mergePlanId, result: { mergePlanId: command.mergePlanId, redirectedFrom: command.sourceMemberId, survivor: command.targetMemberId, accounts, historicalCaseIds, historicalRequestIds, sourceDocumentIds },
    review: noFinanceReview([`Merges ${str(source, 'member_number')} into survivor ${str(target, 'member_number')}, moves ${accounts.length} enumerated account relationship(s), and retains the source identity on ${historicalCaseIds.length} historical case(s), ${historicalRequestIds.length} historical request(s), and ${sourceDocumentIds.length} document(s) through the redirect.`]),
    apply(apply) {
      const targetParty = str(target, 'party_id');
      for (const accountId of accounts) {
        run(apply.database, 'UPDATE account_parties SET ends_at=? WHERE dataset_id=? AND account_id=? AND party_id=? AND role IN (\'owner\',\'joint-owner\') AND ends_at IS NULL', apply.now, apply.datasetId, accountId, sourceParty);
        run(apply.database, `INSERT INTO account_parties (dataset_id,account_id,party_id,role,starts_at,ends_at) VALUES (?,?,?,?,?,NULL)
          ON CONFLICT(dataset_id,account_id,party_id,role) DO UPDATE SET starts_at=excluded.starts_at,ends_at=NULL`, apply.datasetId, accountId, targetParty, 'owner', apply.now);
        run(apply.database, 'UPDATE accounts SET member_id=?,version=version+1 WHERE dataset_id=? AND id=?', command.targetMemberId, apply.datasetId, accountId);
      }
      run(apply.database, "UPDATE members SET status='merged',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, command.sourceMemberId);
      run(apply.database, 'UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.targetMemberId);
      run(apply.database, "UPDATE member_merge_plans SET state='applied' WHERE dataset_id=? AND id=?", apply.datasetId, command.mergePlanId);
      run(apply.database, 'INSERT INTO member_redirects (dataset_id,source_member_id,target_member_id,merge_plan_id,effective_at) VALUES (?,?,?,?,?)', apply.datasetId, command.sourceMemberId, command.targetMemberId, command.mergePlanId, apply.now);
      apply.event({ kind: 'member', id: command.targetMemberId }, `Member ${str(source, 'member_number')} merged into ${str(target, 'member_number')} under plan ${command.mergePlanId}.`);
    },
  }), command.approvalId);
}

function verifiedEvidence(env: FinanceEnvironment, evidenceId: string, partyId: string): Row | Rejection {
  const evidence = one(env.database, 'SELECT id,party_id,status,issued_at,expires_at FROM identity_evidence WHERE dataset_id=? AND id=?', env.datasetId, evidenceId);
  if (evidence === undefined) return reject('not_found', 'The identity evidence does not exist.');
  if (str(evidence, 'party_id') !== partyId) return reject('ownership_mismatch', 'The evidence belongs to another party.');
  if (str(evidence, 'status') !== 'verified' || !isEvidenceValidAt(str(evidence, 'issued_at'), optionalStr(evidence, 'expires_at'), env.now, env.timeZone)) return reject('ineligible', 'The evidence is not currently verified.');
  return evidence;
}

function verifiedEvidenceAt(env: FinanceEnvironment, evidenceId: string, partyId: string, effectiveAt: string): Row | Rejection {
  const evidence = one(env.database, 'SELECT id,party_id,status,issued_at,expires_at FROM identity_evidence WHERE dataset_id=? AND id=?', env.datasetId, evidenceId);
  if (evidence === undefined) return reject('not_found', 'The identity evidence does not exist.');
  if (str(evidence, 'party_id') !== partyId) return reject('ownership_mismatch', 'The identity evidence belongs to another party.');
  if (str(evidence, 'status') !== 'verified' || !isEvidenceValidAt(str(evidence, 'issued_at'), optionalStr(evidence, 'expires_at'), effectiveAt, env.timeZone)) {
    return reject('ineligible', 'The proposed owner lacks identity evidence valid at the relationship start.', { field: 'identityEvidenceId' });
  }
  return evidence;
}

function requireOwnershipConsent(env: FinanceEnvironment, consentId: string, partyId: string, accountId: string, effectiveAt: string): Rejection | null {
  const consent = one(env.database, `SELECT c.id,c.party_id,c.account_id,c.purpose,c.channel,c.state,c.effective_at,
    d.owner_party_id AS disclosure_owner_party_id,d.account_id AS disclosure_account_id,v.status AS disclosure_status
    FROM consents c JOIN document_versions v ON v.dataset_id=c.dataset_id AND v.id=c.disclosure_version_id
    JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE c.dataset_id=? AND c.id=?`, env.datasetId, consentId);
  if (consent === undefined) return reject('not_found', 'The ownership consent does not exist.', { field: 'consentId' });
  if (str(consent, 'party_id') !== partyId || optionalStr(consent, 'account_id') !== accountId) {
    return reject('ownership_mismatch', 'The ownership consent names another party or account.', { field: 'consentId' });
  }
  if (str(consent, 'purpose') !== 'account-ownership' || str(consent, 'effective_at') > effectiveAt) {
    return reject('ineligible', 'The supplied consent does not authorize this ownership relationship at its start.', { field: 'consentId' });
  }
  if (str(consent, 'disclosure_owner_party_id') !== partyId || optionalStr(consent, 'disclosure_account_id') !== accountId || !['current','signed'].includes(str(consent, 'disclosure_status'))) {
    return reject('ownership_mismatch', 'The ownership consent disclosure is not current and scoped to the proposed owner and account.', { field: 'consentId' });
  }
  const latest = one(env.database, `SELECT id,state FROM consents WHERE dataset_id=? AND party_id=? AND account_id=? AND purpose=? AND channel=? AND effective_at<=?
    ORDER BY effective_at DESC,CASE state WHEN 'withdrawn' THEN 0 WHEN 'expired' THEN 1 WHEN 'pending' THEN 2 ELSE 3 END,id DESC LIMIT 1`,
  env.datasetId, partyId, accountId, str(consent, 'purpose'), str(consent, 'channel'), effectiveAt);
  if (latest === undefined || str(latest, 'id') !== consentId || str(latest, 'state') !== 'granted') {
    return reject('ineligible', 'The ownership consent is incomplete, inactive, or superseded at the relationship start.', { field: 'consentId' });
  }
  return null;
}

function accountAuthorityMinimum(env: FinanceEnvironment, approvalId: string): number | Rejection {
  const policy = one(env.database, `SELECT p.rules_json FROM business_approvals a JOIN policy_versions p ON p.dataset_id=a.dataset_id AND p.id=a.policy_version_id
    WHERE a.dataset_id=? AND a.id=?`, env.datasetId, approvalId);
  if (policy === undefined) return reject('not_authorized', 'The approved account-authority policy is unavailable.', { field: 'approvalId' });
  let rules: unknown;
  try { rules = JSON.parse(str(policy, 'rules_json')); } catch { return reject('not_authorized', 'The approved account-authority policy is malformed.', { field: 'approvalId' }); }
  const authority: unknown = rules !== null && typeof rules === 'object' ? Reflect.get(rules, 'accountAuthority') : undefined;
  const minimum: unknown = authority !== null && typeof authority === 'object' ? Reflect.get(authority, 'minimumActiveNaturalPersonAuthorities') : undefined;
  if (!Number.isSafeInteger(minimum) || Number(minimum) < 1 || Number(minimum) > 100) {
    return reject('not_authorized', 'The approved policy does not define a valid account-authority minimum.', { field: 'approvalId' });
  }
  return Number(minimum);
}

function prepareDeceased(env: FinanceEnvironment, command: FinanceOf<'member.deceased.record'>): Preparation {
  const member = loadMember(env, command.memberId);
  if (member === undefined) return reject('not_found', 'The member does not exist.');
  const invalid = validation([requireMemberVersion(member, command.expectedVersion), requireInstant(command.effectiveDate, 'effectiveDate')]);
  if (invalid !== null) return invalid;
  const effectiveAt = normalizeInstant(command.effectiveDate);
  if (effectiveAt === null) return reject('validation', 'Use a valid ISO-8601 instant with an explicit offset.', { field: 'effectiveDate' });
  if (str(member, 'kind') !== 'person') return reject('ineligible', 'A deceased notification applies only to a person.');
  if (str(member, 'status') === 'deceased') return { kind: 'unchanged', message: 'The member is already recorded as deceased.' };
  const evidence = verifiedEvidence(env, command.evidenceId, str(member, 'party_id'));
  if (isRejection(evidence)) return evidence;
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const accountIds = all(env.database, "SELECT id FROM accounts WHERE dataset_id=? AND member_id=? AND status NOT IN ('closed','matured')", env.datasetId, command.memberId).map((row) => str(row, 'id'));
  const queue = one(env.database, "SELECT id FROM queues WHERE dataset_id=? AND visibility='restricted' ORDER BY id LIMIT 1", env.datasetId);
  if (queue === undefined) return reject('ineligible', 'No restricted estate-review queue is configured.');
  const caseId = newId('case');
  const caseNumber = nextNumber(env.database, 'cases', 'case_number', env.datasetId, 'DC', 7);
  return approvalPrepared(prepared({
    businessReference: str(member, 'member_number'), result: { memberId: command.memberId, caseId, caseNumber, restrictedAccounts: accountIds },
    review: noFinanceReview([`Records verified deceased status and places debit restrictions on ${accountIds.length} account(s); no ownership or funds move.`]),
    apply(apply) {
      run(apply.database, 'UPDATE people SET deceased_at=? WHERE dataset_id=? AND party_id=?', effectiveAt, apply.datasetId, str(member, 'party_id'));
      run(apply.database, "UPDATE members SET status='deceased',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, command.memberId);
      run(apply.database, `INSERT INTO cases (dataset_id,id,case_number,member_id,account_id,queue_id,assigned_actor_id,state,priority,category,summary,opened_at,due_at,version)
        VALUES (?,?,?,?,?,?,NULL,'open','high','estate-review',?,?,?,1)`, apply.datasetId, caseId, caseNumber, command.memberId, accountIds[0] ?? null, str(queue, 'id'), 'Verified deceased-member servicing review', apply.now, new Date(Date.parse(apply.now) + 30 * 86_400_000).toISOString());
      run(apply.database, "INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,1,'open',?,?,?)", apply.datasetId, newId('case-event'), caseId, apply.now, apply.actorId, `Estate review opened from verified deceased-member evidence ${command.evidenceId}.`);
      for (const accountId of accountIds) {
        const authority = JSON.stringify({ authority: 'deceased-member-policy', reason: 'Verified deceased-member notification', caseId });
        run(apply.database, "INSERT INTO restrictions (dataset_id,id,account_id,kind,status,authority,placed_at,released_at) VALUES (?,?,?,?, 'active',?,?,NULL)", apply.datasetId, newId('restriction'), accountId, 'debit-block', authority, apply.now);
        run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, accountId);
      }
      apply.event({ kind: 'case', id: caseId }, `Estate review case ${caseNumber} opened for member ${str(member, 'member_number')}.`);
      apply.event({ kind: 'member', id: command.memberId }, `Verified deceased status recorded; estate case ${caseNumber} opened and ${accountIds.length} account(s) restricted.`);
    },
  }), command.approvalId);
}

function prepareBeneficialOwners(env: FinanceEnvironment, command: FinanceOf<'member.beneficial_owners.update'>): Preparation {
  const organization = loadMember(env, command.organizationMemberId);
  if (organization === undefined) return reject('not_found', 'The organization member does not exist.');
  const invalid = validation([requireMemberVersion(organization, command.expectedVersion), requireInstant(command.effectiveDate, 'effectiveDate')]);
  if (invalid !== null) return invalid;
  const effectiveAt = normalizeInstant(command.effectiveDate);
  if (effectiveAt === null) return reject('validation', 'Use a valid ISO-8601 instant with an explicit offset.', { field: 'effectiveDate' });
  if (str(organization, 'kind') !== 'organization') return reject('ineligible', 'Beneficial owners apply only to organization members.');
  if (command.owners.length === 0 || command.owners.length > 25 || command.owners.reduce((sum, owner) => sum + owner.ownershipBps, 0) !== 10_000) return reject('validation', 'Beneficial-owner shares must be a complete 10,000 basis-point declaration.', { field: 'owners' });
  const seen = new Set<string>();
  const owners: { partyId: string; input: FinanceOf<'member.beneficial_owners.update'>['owners'][number] }[] = [];
  for (const input of command.owners) {
    if (seen.has(input.memberId) || !Number.isSafeInteger(input.ownershipBps) || input.ownershipBps < 1 || input.ownershipBps > 10_000) return reject('validation', 'Owner identities must be unique and shares must be positive basis points.', { field: 'owners' });
    seen.add(input.memberId);
    const owner = loadMember(env, input.memberId);
    if (owner === undefined || str(owner, 'kind') !== 'person' || str(owner, 'status') !== 'active') return reject('ineligible', `Owner ${input.memberId} is not an active person member.`);
    const evidence = verifiedEvidence(env, input.evidenceId, str(owner, 'party_id'));
    if (isRejection(evidence)) return evidence;
    owners.push({ partyId: str(owner, 'party_id'), input });
  }
  if (!owners.some(({ input }) => input.isControlPerson)) return reject('validation', 'At least one declared owner must be a control person.', { field: 'owners' });
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({
    businessReference: str(organization, 'member_number'), result: { organizationMemberId: command.organizationMemberId, ownerCount: owners.length, ownershipBps: 10_000 },
    review: noFinanceReview([`Ends the current declaration and records ${owners.length} evidenced beneficial owner relationship(s) totaling 100%.`]),
    apply(apply) {
      run(apply.database, 'UPDATE organization_ownership SET ends_at=? WHERE dataset_id=? AND organization_party_id=? AND ends_at IS NULL', effectiveAt, apply.datasetId, str(organization, 'party_id'));
      for (const { partyId, input } of owners) run(apply.database, `INSERT INTO organization_ownership
        (dataset_id,id,organization_party_id,owner_party_id,ownership_bps,is_control_person,starts_at,ends_at,evidence_id) VALUES (?,?,?,?,?,?,?,NULL,?)`,
        apply.datasetId, newId('organization-owner'), str(organization, 'party_id'), partyId, input.ownershipBps, input.isControlPerson ? 1 : 0, effectiveAt, input.evidenceId);
      run(apply.database, 'UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.organizationMemberId);
      apply.event({ kind: 'member', id: command.organizationMemberId }, `Complete beneficial-owner declaration recorded for ${owners.length} owner(s).`);
    },
  }), command.approvalId);
}

const TAX_CLASSIFICATIONS = new Set(['individual','organization','tax-exempt','nonresident','backup-withholding']);

function prepareTax(env: FinanceEnvironment, command: FinanceOf<'member.tax_classification.update'>): Preparation {
  const member = loadMember(env, command.memberId);
  if (member === undefined) return reject('not_found', 'The member does not exist.');
  const invalid = validation([requireMemberVersion(member, command.expectedVersion), requireText(command.classification, 'classification', 'Classification', 40)]);
  if (invalid !== null) return invalid;
  if (!TAX_CLASSIFICATIONS.has(command.classification)) return reject('validation', 'The tax classification is unsupported.', { field: 'classification' });
  const currentYear = Number(localDate(env.now, env.timeZone).slice(0, 4));
  if (!Number.isSafeInteger(command.effectiveYear) || command.effectiveYear < currentYear || command.effectiveYear > currentYear + 10) return reject('validation', 'The tax effective year must be the current year or one of the next ten years.', { field: 'effectiveYear' });
  const effective = `${command.effectiveYear}-01-01`;
  const existing = one(env.database, `SELECT id,classification FROM tax_status_history
    WHERE dataset_id=? AND member_id=? AND valid_from=? ORDER BY id DESC LIMIT 1`, env.datasetId, command.memberId, effective);
  if (existing !== undefined) {
    if (str(existing, 'classification') === command.classification) return { kind: 'unchanged', message: 'This dated tax classification is already recorded.' };
    return reject('ineligible', 'A different immutable tax classification already starts in that year.', { field: 'effectiveYear' });
  }
  const atEffectiveDate = one(env.database, `SELECT classification FROM tax_status_history
    WHERE dataset_id=? AND member_id=? AND valid_from<=? AND (valid_to IS NULL OR valid_to>?)
    ORDER BY valid_from DESC,id DESC LIMIT 1`, env.datasetId, command.memberId, effective, effective);
  if ((atEffectiveDate === undefined ? str(member, 'tax_classification') : str(atEffectiveDate, 'classification')) === command.classification) return { kind: 'unchanged', message: 'The member already has this tax classification on the requested effective date.' };
  const evidence = verifiedEvidence(env, command.evidenceId, str(member, 'party_id'));
  if (isRejection(evidence)) return evidence;
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const next = one(env.database, `SELECT valid_from FROM tax_status_history WHERE dataset_id=? AND member_id=? AND valid_from>?
    ORDER BY valid_from,id LIMIT 1`, env.datasetId, command.memberId, effective);
  return approvalPrepared(prepared({
    businessReference: str(member, 'member_number'), result: { memberId: command.memberId, classification: command.classification, effectiveYear: command.effectiveYear },
    review: noFinanceReview([`Records prospective ${command.classification} classification effective ${command.effectiveYear}; prior history remains immutable.`]),
    apply(apply) {
      run(apply.database, `UPDATE tax_status_history SET valid_to=? WHERE dataset_id=? AND member_id=? AND valid_from<?
        AND (valid_to IS NULL OR valid_to>?)`, effective, apply.datasetId, command.memberId, effective, effective);
      run(apply.database, 'INSERT INTO tax_status_history (dataset_id,id,member_id,classification,valid_from,valid_to,evidence_id) VALUES (?,?,?,?,?,?,?)', apply.datasetId, newId('tax-history'), command.memberId, command.classification, effective, optionalStr(next, 'valid_from'), command.evidenceId);
      run(apply.database, 'UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.memberId);
      apply.event({ kind: 'member', id: command.memberId }, `Tax classification ${command.classification} recorded effective ${effective}; prior and future dated history preserved.`);
    },
  }), command.approvalId);
}

function prepareProductConvert(env: FinanceEnvironment, command: FinanceOf<'account.product.convert'>): Preparation {
  const account = loadAccount(env, command.accountId);
  const target = one(env.database, 'SELECT id,code,family,currency,status FROM products WHERE dataset_id=? AND id=?', env.datasetId, command.targetProductId);
  if (account === undefined || target === undefined) return reject('not_found', 'The account or target product does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedVersion), requireDate(command.effectiveDate, 'effectiveDate')]);
  if (invalid !== null) return invalid;
  if (command.effectiveDate < localDate(env.now, env.timeZone)) return reject('validation', 'Product conversion cannot be backdated.', { field: 'effectiveDate' });
  if (!command.feeDisclosureAccepted) return reject('ineligible', 'The current product and fee disclosure must be accepted.', { field: 'feeDisclosureAccepted' });
  if (str(account, 'status') !== 'open' || str(target, 'status') !== 'active' || str(account, 'family') !== 'deposit' || str(target, 'family') !== 'deposit' || str(account, 'currency') !== str(target, 'currency')) return reject('ineligible', 'The account and target product are not eligible for a same-currency deposit conversion.');
  const effectiveAt = zonedInstant(command.effectiveDate, '00:00', env.timeZone);
  const datedDecision = one(env.database, 'SELECT product_id FROM account_product_history WHERE dataset_id=? AND account_id=? AND effective_at=?', env.datasetId, command.accountId, effectiveAt);
  if (datedDecision !== undefined) {
    if (str(datedDecision, 'product_id') === command.targetProductId) return { kind: 'unchanged', message: 'This dated product conversion is already recorded.' };
    return reject('ineligible', 'A different immutable product decision already starts on that date.', { field: 'effectiveDate' });
  }
  const effectiveProduct = one(env.database, `SELECT ${accountProductSql('?')} AS product_id FROM accounts a WHERE a.dataset_id=? AND a.id=?`, effectiveAt, env.datasetId, command.accountId);
  if (effectiveProduct !== undefined && str(effectiveProduct, 'product_id') === command.targetProductId) return { kind: 'unchanged', message: 'The account already uses this product on the requested effective date.' };
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: str(account, 'account_number'), result: { accountId: command.accountId, targetProductId: command.targetProductId, effectiveDate: command.effectiveDate }, review: noFinanceReview(['Changes the product in place and preserves the account, owners, number, currency and ledger history.']), apply(apply) {
    run(apply.database, 'INSERT INTO account_product_history (dataset_id,id,account_id,product_id,effective_at,operation_id) VALUES (?,?,?,?,?,?)', apply.datasetId, newId('account-product-decision'), command.accountId, command.targetProductId, effectiveAt, apply.operationId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'account', id: command.accountId }, `Account product ${str(target, 'code')} recorded effective ${command.effectiveDate}; opening product and ledger continuity preserved.`);
  } }), command.approvalId);
}

function prepareOwnerAdd(env: FinanceEnvironment, command: FinanceOf<'account.owner.add'>): Preparation {
  const account = loadAccount(env, command.accountId);
  const member = loadMember(env, command.memberId);
  if (account === undefined || member === undefined) return reject('not_found', 'The account or proposed owner does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedVersion), requireDate(command.effectiveDate, 'effectiveDate')]);
  if (invalid !== null) return invalid;
  const startsAt = zonedInstant(command.effectiveDate, '00:00', env.timeZone);
  if (command.effectiveDate < localDate(env.now, env.timeZone)) return reject('validation', 'An ownership relationship cannot be backdated.', { field: 'effectiveDate' });
  if (str(account, 'status') !== 'open' || str(member, 'status') !== 'active') return reject('ineligible', 'The account and proposed owner must be active.');
  const current = one(env.database, 'SELECT role,starts_at,ends_at FROM account_parties WHERE dataset_id=? AND account_id=? AND party_id=? AND role=?', env.datasetId, command.accountId, str(member, 'party_id'), command.role);
  if (current !== undefined && optionalStr(current, 'ends_at') === null) return { kind: 'unchanged', message: 'This ownership relationship is already active.' };
  if (current !== undefined && startsAt <= str(current, 'ends_at')) return reject('validation', 'A reactivated ownership relationship must start after its prior end.', { field: 'effectiveDate' });
  const evidence = verifiedEvidenceAt(env, command.identityEvidenceId, str(member, 'party_id'), startsAt);
  if (isRejection(evidence)) return evidence;
  const consent = requireOwnershipConsent(env, command.consentId, str(member, 'party_id'), command.accountId, startsAt);
  if (consent !== null) return consent;
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: str(account, 'account_number'), result: { accountId: command.accountId, memberId: command.memberId, role: command.role }, review: noFinanceReview([`Adds ${str(member, 'member_number')} as ${command.role} effective ${command.effectiveDate}.`]), apply(apply) {
    if (current === undefined) run(apply.database, 'INSERT INTO account_parties (dataset_id,account_id,party_id,role,starts_at,ends_at) VALUES (?,?,?,?,?,NULL)', apply.datasetId, command.accountId, str(member, 'party_id'), command.role, startsAt);
    else run(apply.database, 'UPDATE account_parties SET starts_at=?,ends_at=NULL WHERE dataset_id=? AND account_id=? AND party_id=? AND role=?', startsAt, apply.datasetId, command.accountId, str(member, 'party_id'), command.role);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'account', id: command.accountId }, `${str(member, 'member_number')} added as ${command.role} effective ${command.effectiveDate}.`);
  } }), command.approvalId);
}

function prepareSignerRemove(env: FinanceEnvironment, command: FinanceOf<'account.signer.remove'>): Preparation {
  const account = loadAccount(env, command.accountId);
  const signer = loadMember(env, command.signerMemberId);
  if (account === undefined || signer === undefined) return reject('not_found', 'The account or signer does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedVersion), requireInstant(command.effectiveAt, 'effectiveAt')]);
  if (invalid !== null) return invalid;
  const effectiveAt = normalizeInstant(command.effectiveAt);
  if (effectiveAt === null) return reject('validation', 'Use a valid ISO-8601 instant with an explicit offset.', { field: 'effectiveAt' });
  const link = one(env.database, "SELECT starts_at,ends_at FROM account_parties WHERE dataset_id=? AND account_id=? AND party_id=? AND role='signer'", env.datasetId, command.accountId, str(signer, 'party_id'));
  if (link === undefined || optionalStr(link, 'ends_at') !== null) return reject('ineligible', 'The member is not an active signer on this account.');
  if (effectiveAt <= str(link, 'starts_at')) return reject('validation', 'The signer end must follow its start.', { field: 'effectiveAt' });
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const minimum = accountAuthorityMinimum(env, command.approvalId);
  if (typeof minimum !== 'number') return minimum;
  const remaining = one(env.database, `SELECT COUNT(DISTINCT ap.party_id) AS count FROM account_parties ap
    JOIN parties p ON p.dataset_id=ap.dataset_id AND p.id=ap.party_id
    WHERE ap.dataset_id=? AND ap.account_id=? AND p.kind='person' AND ap.role IN ('owner','joint-owner','signer','guardian')
      AND ap.starts_at<=? AND (ap.ends_at IS NULL OR ap.ends_at>?) AND NOT (ap.party_id=? AND ap.role='signer')`,
  env.datasetId, command.accountId, effectiveAt, effectiveAt, str(signer, 'party_id'));
  if (int(remaining, 'count') < minimum) return reject('ineligible', 'Removing this signer would violate the approved account-authority minimum.');
  return approvalPrepared(prepared({ businessReference: str(account, 'account_number'), result: { accountId: command.accountId, signerMemberId: command.signerMemberId, effectiveAt }, review: noFinanceReview(['Ends signing authority only; ownership is unchanged.']), apply(apply) {
    run(apply.database, "UPDATE account_parties SET ends_at=? WHERE dataset_id=? AND account_id=? AND party_id=? AND role='signer'", effectiveAt, apply.datasetId, command.accountId, str(signer, 'party_id'));
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'account', id: command.accountId }, `Signer ${str(signer, 'member_number')} authority ended at ${effectiveAt}; ownership preserved.`);
  } }), command.approvalId);
}

function prepareOverdraft(env: FinanceEnvironment, command: FinanceOf<'account.overdraft_limit.update'>): Preparation {
  const account = loadAccount(env, command.accountId);
  if (account === undefined) return reject('not_found', 'The account does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedVersion), requireMoney(env, command.limit, 'limit', true), requireDate(command.effectiveDate, 'effectiveDate'), command.expiresAt === null ? null : requireInstant(command.expiresAt, 'expiresAt')]);
  if (invalid !== null) return invalid;
  if (command.effectiveDate < localDate(env.now, env.timeZone)) return reject('validation', 'An overdraft limit cannot be backdated.', { field: 'effectiveDate' });
  const effectiveAt = zonedInstant(command.effectiveDate, '00:00', env.timeZone);
  const expiresAt = command.expiresAt === null ? null : normalizeInstant(command.expiresAt);
  if (command.expiresAt !== null && expiresAt === null) return reject('validation', 'Use a valid ISO-8601 instant with an explicit offset.', { field: 'expiresAt' });
  if (expiresAt !== null && expiresAt <= effectiveAt) return reject('validation', 'An overdraft expiry must follow its effective instant.', { field: 'expiresAt' });
  if (str(account, 'family') !== 'deposit' || str(account, 'status') !== 'open' || str(account, 'currency') !== command.limit.currency) return reject('ineligible', 'Only an open same-currency deposit account may have an overdraft facility.');
  const base = one(env.database, "SELECT id,kind,limit_minor_units,used_minor_units,status FROM facilities WHERE dataset_id=? AND account_id=? AND kind='overdraft' ORDER BY id LIMIT 1", env.datasetId, command.accountId);
  const facility = base === undefined ? undefined : { ...base, terms: canonicalJson(all(env.database, 'SELECT id,limit_minor_units,effective_at,expires_at,operation_id FROM facility_limit_terms WHERE dataset_id=? AND facility_id=? ORDER BY effective_at,id', env.datasetId, str(base, 'id'))) };
  if (facility !== undefined && command.expectedFacilityFingerprint !== rowFingerprint(facility, ['id','kind','limit_minor_units','used_minor_units','status','terms'])) return reject('stale_version', 'The overdraft facility changed after review.');
  if (facility === undefined && command.expectedFacilityFingerprint !== null) return reject('stale_version', 'The reviewed overdraft facility no longer exists.');
  if ((optionalInt(facility, 'used_minor_units') ?? 0) > command.limit.minorUnits) return reject('ineligible', 'The approved limit is below the currently used facility amount.');
  if (facility !== undefined && str(facility, 'status') !== 'active') return reject('ineligible', 'A suspended or closed overdraft facility cannot receive a new limit.');
  const datedTerm = facility === undefined ? undefined : one(env.database, 'SELECT limit_minor_units,expires_at FROM facility_limit_terms WHERE dataset_id=? AND facility_id=? AND effective_at=?', env.datasetId, str(facility, 'id'), effectiveAt);
  if (datedTerm !== undefined) {
    if (int(datedTerm, 'limit_minor_units') === command.limit.minorUnits && optionalStr(datedTerm, 'expires_at') === expiresAt) return { kind: 'unchanged', message: 'This dated overdraft limit is already recorded.' };
    return reject('ineligible', 'A different immutable overdraft limit already starts on that date.', { field: 'effectiveDate' });
  }
  const approval = requireApproval(env, command, command.approvalId, command.limit);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: str(account, 'account_number'), result: { accountId: command.accountId, limit: command.limit, effectiveDate: command.effectiveDate, expiresAt }, review: { amount: command.limit, exponent: null, description: 'Approved overdraft limit', accounts: [], consequences: ['Changes available funds through the overdraft facility; it does not post a balance adjustment.'] }, apply(apply) {
    const facilityId = facility === undefined ? newId('facility') : str(facility, 'id');
    if (facility === undefined) run(apply.database, "INSERT INTO facilities (dataset_id,id,account_id,kind,limit_minor_units,used_minor_units,status) VALUES (?,?,?,'overdraft',0,0,'active')", apply.datasetId, facilityId, command.accountId);
    run(apply.database, 'INSERT INTO facility_limit_terms (dataset_id,id,facility_id,limit_minor_units,effective_at,expires_at,operation_id) VALUES (?,?,?,?,?,?,?)', apply.datasetId, newId('facility-limit-term'), facilityId, command.limit.minorUnits, effectiveAt, expiresAt, apply.operationId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'account', id: command.accountId }, `Overdraft facility set to ${command.limit.minorUnits} ${command.limit.currency} minor units effective ${effectiveAt}${expiresAt === null ? '' : ` through ${expiresAt}`}.`);
  } }), command.approvalId);
}

function prepareHoldPlace(env: FinanceEnvironment, command: FinanceOf<'account.hold.place'>): Preparation {
  const account = loadAccount(env, command.accountId);
  if (account === undefined) return reject('not_found', 'The account does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedVersion), requireMoney(env, command.amount, 'amount'), requireText(command.reason, 'reason', 'Reason'), requireInstant(command.expiresAt, 'expiresAt'), requireText(command.releaseAuthority, 'releaseAuthority', 'Release authority', 120)]);
  if (invalid !== null) return invalid;
  const expiresAt = normalizeInstant(command.expiresAt);
  if (expiresAt === null) return reject('validation', 'Use a valid ISO-8601 instant with an explicit offset.', { field: 'expiresAt' });
  if (expiresAt <= env.now) return reject('validation', 'A hold expiry must be in the future.', { field: 'expiresAt' });
  const debit = requireDebit(env, command.accountId, command.amount);
  if (debit !== null) return debit;
  const holdId = newId('hold');
  return prepared({ businessReference: holdId, result: { holdId, accountId: command.accountId, amount: command.amount, expiresAt }, review: { amount: command.amount, exponent: null, description: command.reason.trim(), accounts: [], consequences: ['Reduces available funds only; posted balance is unchanged.'] }, apply(apply) {
    run(apply.database, "INSERT INTO holds (dataset_id,id,account_id,amount_minor_units,status,reason,release_authority,placed_at,expires_at,released_at) VALUES (?,?,?,?, 'active',?,?,?,?,NULL)", apply.datasetId, holdId, command.accountId, command.amount.minorUnits, command.reason.trim(), command.releaseAuthority.trim(), apply.now, expiresAt);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'hold', id: holdId }, `Hold ${holdId} placed for ${command.amount.minorUnits} ${command.amount.currency} minor units until ${expiresAt}: ${command.reason.trim()}`);
  } });
}

function prepareHoldRelease(env: FinanceEnvironment, command: FinanceOf<'account.hold.release'>): Preparation {
  const hold = one(env.database, `SELECT h.id,h.account_id,h.amount_minor_units,h.status,h.reason,h.release_authority,h.placed_at,h.expires_at,h.released_at,
    COALESCE((SELECT SUM(amount_minor_units) FROM hold_releases r WHERE r.dataset_id=h.dataset_id AND r.hold_id=h.id),0) AS released_minor_units
    FROM holds h WHERE h.dataset_id=? AND h.id=?`, env.datasetId, command.holdId);
  if (hold === undefined) return reject('not_found', 'The hold does not exist.');
  const stale = requireFingerprint(hold, ['id','account_id','amount_minor_units','status','reason','release_authority','placed_at','expires_at','released_at','released_minor_units'], command.expectedFingerprint, 'hold');
  if (stale !== null) return stale;
  if (str(hold, 'status') !== 'active') return reject('ineligible', `Hold status is ${str(hold, 'status')}; it cannot be released again.`);
  if (int(hold, 'amount_minor_units') === 0) return reject('ineligible', 'An active hold with no remaining amount cannot be released.');
  if (str(hold, 'expires_at') <= env.now) return reject('ineligible', 'The hold has expired and requires expiry processing rather than a manual release.');
  if (command.releaseAuthority.trim() !== str(hold, 'release_authority')) return reject('not_authorized', 'The supplied release authority does not match this hold.');
  if (!Number.isSafeInteger(command.amountMinorUnits) || command.amountMinorUnits <= 0 || command.amountMinorUnits > int(hold, 'amount_minor_units')) return reject('validation', 'Release amount must be positive and no greater than the remaining held amount.', { field: 'amountMinorUnits' });
  const invalid = requireText(command.evidenceReference, 'evidenceReference', 'Release evidence', 200);
  if (invalid !== null) return invalid;
  const remaining = int(hold, 'amount_minor_units') - command.amountMinorUnits;
  return prepared({ businessReference: command.holdId, result: { holdId: command.holdId, releasedMinorUnits: command.amountMinorUnits, remainingMinorUnits: remaining }, review: noFinanceReview([`Releases ${command.amountMinorUnits} minor units from hold ${command.holdId}; other holds are unchanged.`]), apply(apply) {
    run(apply.database, 'INSERT INTO hold_releases (dataset_id,id,hold_id,operation_id,actor_id,amount_minor_units,authority,evidence_reference,released_at) VALUES (?,?,?,?,?,?,?,?,?)', apply.datasetId, newId('hold-release'), command.holdId, apply.operationId, apply.actorId, command.amountMinorUnits, command.releaseAuthority.trim(), command.evidenceReference.trim(), apply.now);
    run(apply.database, 'UPDATE holds SET amount_minor_units=?,status=?,released_at=? WHERE dataset_id=? AND id=?', remaining, remaining === 0 ? 'released' : 'active', remaining === 0 ? apply.now : null, apply.datasetId, command.holdId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(hold, 'account_id'));
    apply.event({ kind: 'hold', id: command.holdId }, `Hold ${command.holdId} released by ${command.amountMinorUnits} minor units; ${remaining} remain. Evidence ${command.evidenceReference}.`);
  } });
}

function prepareRestrictionApply(env: FinanceEnvironment, command: FinanceOf<'account.restriction.apply'>): Preparation {
  const account = loadAccount(env, command.accountId);
  if (account === undefined) return reject('not_found', 'The account does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedVersion), requireText(command.reason, 'reason', 'Reason'), requireText(command.authority, 'authority', 'Authority', 120)]);
  if (invalid !== null) return invalid;
  const caseRow = one(env.database, 'SELECT member_id,account_id,state FROM cases WHERE dataset_id=? AND id=?', env.datasetId, command.caseId);
  if (caseRow === undefined || str(caseRow, 'member_id') !== str(account, 'member_id')) return reject('ownership_mismatch', 'The restriction case is absent or belongs to another member.');
  if (optionalStr(caseRow, 'account_id') !== null && optionalStr(caseRow, 'account_id') !== command.accountId) return reject('ownership_mismatch', 'The restriction case is scoped to another account.');
  if (str(caseRow, 'state') === 'closed') return reject('ineligible', 'A closed case cannot support a new restriction.');
  const duplicate = one(env.database, "SELECT id FROM restrictions WHERE dataset_id=? AND account_id=? AND kind=? AND status='active'", env.datasetId, command.accountId, command.restrictionType);
  if (duplicate !== undefined) return { kind: 'unchanged', message: `Equivalent restriction ${str(duplicate, 'id')} is already active.` };
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const restrictionId = newId('restriction');
  return approvalPrepared(prepared({ businessReference: restrictionId, result: { restrictionId, accountId: command.accountId, restrictionType: command.restrictionType, caseId: command.caseId }, review: noFinanceReview([`Applies only ${command.restrictionType} under case ${command.caseId}; other accounts and obligations remain unchanged.`]), apply(apply) {
    const authority = JSON.stringify({ authority: command.authority.trim(), reason: command.reason.trim(), caseId: command.caseId });
    run(apply.database, "INSERT INTO restrictions (dataset_id,id,account_id,kind,status,authority,placed_at,released_at) VALUES (?,?,?,?, 'active',?,?,NULL)", apply.datasetId, restrictionId, command.accountId, command.restrictionType, authority, apply.now);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'restriction', id: restrictionId }, `${command.restrictionType} restriction ${restrictionId} applied under case ${command.caseId}: ${command.reason.trim()}`);
  } }), command.approvalId);
}

function prepareRestrictionRelease(env: FinanceEnvironment, command: FinanceOf<'account.restriction.release'>): Preparation {
  const row = one(env.database, 'SELECT id,account_id,kind,status,authority,placed_at,released_at FROM restrictions WHERE dataset_id=? AND id=?', env.datasetId, command.restrictionId);
  if (row === undefined) return reject('not_found', 'The restriction does not exist.');
  const stale = requireFingerprint(row, ['id','account_id','kind','status','authority','placed_at','released_at'], command.expectedFingerprint, 'restriction');
  if (stale !== null) return stale;
  if (str(row, 'status') !== 'active') return reject('ineligible', `Restriction status is ${str(row, 'status')}; it cannot be released again.`);
  const accountOwner = one(env.database, `SELECT m.party_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
    WHERE a.dataset_id=? AND a.id=?`, env.datasetId, str(row, 'account_id'));
  if (accountOwner === undefined) return reject('not_found', 'The restricted account owner does not exist.');
  const evidence = verifiedEvidence(env, command.clearanceEvidenceId, str(accountOwner, 'party_id'));
  if (isRejection(evidence)) return evidence;
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: command.restrictionId, result: { restrictionId: command.restrictionId, released: true }, review: noFinanceReview(['Releases only the named restriction; independent restrictions remain active.']), apply(apply) {
    run(apply.database, "UPDATE restrictions SET status='released',released_at=? WHERE dataset_id=? AND id=?", apply.now, apply.datasetId, command.restrictionId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(row, 'account_id'));
    apply.event({ kind: 'restriction', id: command.restrictionId }, `Restriction ${command.restrictionId} released using evidence ${command.clearanceEvidenceId}; other restrictions preserved.`);
  } }), command.approvalId);
}

function feeRows(env: FinanceEnvironment, feeId: string): Row | undefined {
  return one(env.database, `SELECT f.id,f.account_id,f.journal_id,f.original_amount_minor_units,f.currency,f.policy_version_id,f.status,
    COALESCE((SELECT SUM(r.amount_minor_units) FROM fee_refunds r WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id),0) AS refunded
    FROM fees f WHERE f.dataset_id=? AND f.id=?`, env.datasetId, feeId);
}

function approvedFeeLimit(policy: Row, feeCode: string, currency: string): number | null {
  let rules: unknown;
  try { rules = JSON.parse(str(policy, 'rules_json')); } catch { return null; }
  if (rules === null || typeof rules !== 'object' || Array.isArray(rules)) return null;
  const fees: unknown = Reflect.get(rules, 'fees');
  if (!Array.isArray(fees)) return null;
  const matched: unknown = fees.find((fee) => fee !== null && typeof fee === 'object' && !Array.isArray(fee)
    && Reflect.get(fee, 'code') === feeCode && Reflect.get(fee, 'currency') === currency);
  if (matched === undefined || matched === null || typeof matched !== 'object') return null;
  const maximum: unknown = Reflect.get(matched, 'maximumMinorUnits');
  return Number.isSafeInteger(maximum) && Number(maximum) > 0 ? Number(maximum) : null;
}

function prepareFeeAssess(env: FinanceEnvironment, command: FinanceOf<'fee.assess'>): Preparation {
  const account = loadAccount(env, command.accountId);
  if (account === undefined) return reject('not_found', 'The account does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedVersion), requireMoney(env, command.amount, 'amount'), requireText(command.feeCode, 'feeCode', 'Fee code', 60), requireText(command.basis, 'basis', 'Fee basis')]);
  if (invalid !== null) return invalid;
  if (str(account, 'currency') !== command.amount.currency) return reject('currency_mismatch', 'The fee currency differs from the account currency.');
  const policy = one(env.database, 'SELECT id,rules_json FROM policy_versions WHERE dataset_id=? AND id=? AND effective_at<=?', env.datasetId, command.policyVersionId, env.now);
  if (policy === undefined) return reject('ineligible', 'The supplied fee policy is absent or not effective.');
  const policyLimit = approvedFeeLimit(policy, command.feeCode, command.amount.currency);
  if (policyLimit === null) return reject('ineligible', 'The supplied policy does not authorize this fee code and currency.');
  if (command.amount.minorUnits > policyLimit) return reject('limit_exceeded', `The fee exceeds the policy maximum of ${policyLimit} minor units.`);
  const today = localDate(env.now, env.timeZone);
  const waiver = one(env.database, `SELECT w.id,w.max_occurrences,COUNT(u.id) AS uses FROM fee_waivers w
    LEFT JOIN fee_waiver_uses u ON u.dataset_id=w.dataset_id AND u.waiver_id=w.id
    WHERE w.dataset_id=? AND w.account_id=? AND w.fee_code=? AND w.state='approved' AND w.valid_from<=? AND w.valid_through>=?
      AND w.amount_limit_minor_units>=? AND w.currency=?
    GROUP BY w.id,w.max_occurrences HAVING COUNT(u.id)<w.max_occurrences ORDER BY w.valid_through,w.id LIMIT 1`,
  env.datasetId, command.accountId, command.feeCode, today, today, command.amount.minorUnits, command.amount.currency);
  if (waiver !== undefined) {
    const useId = newId('fee-waiver-use');
    return prepared({
      businessReference: useId,
      result: { feeId: null, accountId: command.accountId, amount: command.amount, policyVersionId: command.policyVersionId, waived: true, waiverId: str(waiver, 'id'), waiverUseId: useId },
      review: noFinanceReview([`Consumes occurrence ${int(waiver, 'uses') + 1} of ${int(waiver, 'max_occurrences')} from active waiver ${str(waiver, 'id')}; no fee or journal is posted.`]),
      apply(apply) {
        run(apply.database, 'INSERT INTO fee_waiver_uses (dataset_id,id,waiver_id,operation_id,assessed_at) VALUES (?,?,?,?,?)', apply.datasetId, useId, str(waiver, 'id'), apply.operationId, apply.now);
        apply.event({ kind: 'account', id: command.accountId }, `Fee ${command.feeCode} waived under ${str(waiver, 'id')}; no posting created.`);
      },
    });
  }
  const debit = requireDebit(env, command.accountId, command.amount);
  if (debit !== null) return debit;
  const accountLedger = ledgerForAccount(env, command.accountId);
  const income = generalLedger(env, command.amount.currency, 'fee-income');
  if (accountLedger === undefined || income === undefined) return reject('ineligible', 'Required fee ledgers are not configured.');
  const feeId = newId('fee');
  return prepared({ businessReference: feeId, result: { feeId, accountId: command.accountId, amount: command.amount, policyVersionId: command.policyVersionId }, review: { amount: command.amount, exponent: null, description: command.basis.trim(), accounts: [], consequences: [`Posts fee ${command.feeCode} under policy ${command.policyVersionId}.`] }, apply(apply) {
    const journalId = insertJournal(apply, { debitLedgerId: str(accountLedger, 'id'), creditLedgerId: str(income, 'id'), amount: command.amount.minorUnits, currency: command.amount.currency, description: `Fee ${command.feeCode}: ${command.basis.trim()}`, prefix: 'FE' });
    run(apply.database, "INSERT INTO fees (dataset_id,id,account_id,journal_id,original_amount_minor_units,currency,policy_version_id,status) VALUES (?,?,?,?,?,?,?,'assessed')", apply.datasetId, feeId, command.accountId, journalId, command.amount.minorUnits, command.amount.currency, command.policyVersionId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'fee', id: feeId }, `Fee ${feeId} assessed for ${command.amount.minorUnits} ${command.amount.currency} minor units under ${command.policyVersionId}.`);
  } });
}

function prepareFeeWaiver(env: FinanceEnvironment, command: FinanceOf<'fee.waiver.create'>): Preparation {
  const account = loadAccount(env, command.accountId);
  if (account === undefined) return reject('not_found', 'The account does not exist.');
  const invalid = validation([requireMoney(env, command.amountLimit, 'amountLimit'), requireDate(command.validFrom, 'validFrom'), requireDate(command.validThrough, 'validThrough'), requireText(command.feeCode, 'feeCode', 'Fee code', 60), requireText(command.reason, 'reason', 'Reason')]);
  if (invalid !== null) return invalid;
  if (str(account, 'currency') !== command.amountLimit.currency || command.validFrom >= command.validThrough || !Number.isSafeInteger(command.maxOccurrences) || command.maxOccurrences < 1 || command.maxOccurrences > 100) return reject('validation', 'Waiver currency, date window or occurrence limit is invalid.');
  const duplicate = one(env.database, "SELECT id FROM fee_waivers WHERE dataset_id=? AND account_id=? AND fee_code=? AND state='approved' AND valid_from<? AND valid_through>?", env.datasetId, command.accountId, command.feeCode, command.validThrough, command.validFrom);
  if (duplicate !== undefined) return reject('ineligible', `Active waiver ${str(duplicate, 'id')} already overlaps this fee and window.`);
  const approval = requireApproval(env, command, command.approvalId, command.amountLimit);
  if (approval !== null) return approval;
  const waiverId = newId('fee-waiver');
  return approvalPrepared(prepared({ businessReference: waiverId, result: { waiverId, accountId: command.accountId, validFrom: command.validFrom, validThrough: command.validThrough }, review: noFinanceReview(['Creates a prospective waiver only; historical fees are unchanged.']), apply(apply) {
    run(apply.database, `INSERT INTO fee_waivers (dataset_id,id,account_id,fee_id,fee_code,actor_id,amount_limit_minor_units,currency,valid_from,valid_through,max_occurrences,reason,state,created_at)
      VALUES (?,?,?,NULL,?,?,?,?,?,?,?,?, 'approved',?)`, apply.datasetId, waiverId, command.accountId, command.feeCode, apply.actorId, command.amountLimit.minorUnits, command.amountLimit.currency, command.validFrom, command.validThrough, command.maxOccurrences, command.reason.trim(), apply.now);
    apply.event({ kind: 'account', id: command.accountId }, `Prospective ${command.feeCode} waiver ${waiverId} approved for ${command.validFrom} through ${command.validThrough}.`);
  } }), command.approvalId);
}

function prepareFeeRefund(env: FinanceEnvironment, command: FinanceOf<'fee.refund'>): Preparation {
  const fee = feeRows(env, command.feeId);
  if (fee === undefined) return reject('not_found', 'The fee does not exist.');
  const stale = requireFingerprint(fee, ['id','account_id','journal_id','original_amount_minor_units','currency','policy_version_id','status','refunded'], command.expectedFingerprint, 'fee');
  if (stale !== null) return stale;
  const invalid = validation([requireMoney(env, command.amount, 'amount'), requireText(command.reason, 'reason', 'Reason')]);
  if (invalid !== null) return invalid;
  if (str(fee, 'currency') !== command.amount.currency) return reject('currency_mismatch', 'The refund currency differs from the fee currency.');
  const remaining = int(fee, 'original_amount_minor_units') - int(fee, 'refunded');
  if (remaining <= 0) return reject('ineligible', 'The fee was already fully refunded.');
  if (command.amount.minorUnits > remaining) return reject('limit_exceeded', `Only ${remaining} minor units remain refundable.`);
  const accountLedger = ledgerForAccount(env, str(fee, 'account_id'));
  const income = generalLedger(env, command.amount.currency, 'fee-income');
  if (accountLedger === undefined || income === undefined) return reject('ineligible', 'Required refund ledgers are not configured.');
  const refundId = newId('fee-refund');
  return prepared({ businessReference: command.feeId, result: { refundId, feeId: command.feeId, amount: command.amount, remainingMinorUnits: remaining - command.amount.minorUnits }, review: { amount: command.amount, exponent: null, description: command.reason.trim(), accounts: [], consequences: ['Posts one compensating credit linked to the original fee; the assessment remains immutable.'] }, apply(apply) {
    const journalId = insertJournal(apply, { debitLedgerId: str(income, 'id'), creditLedgerId: str(accountLedger, 'id'), amount: command.amount.minorUnits, currency: command.amount.currency, description: `Refund of fee ${command.feeId}: ${command.reason.trim()}`, prefix: 'FR' });
    run(apply.database, 'INSERT INTO fee_refunds (dataset_id,id,fee_id,journal_id,amount_minor_units,actor_id,refunded_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, refundId, command.feeId, journalId, command.amount.minorUnits, apply.actorId, apply.now);
    run(apply.database, 'INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,\'refund\')', apply.datasetId, newId('correction-link'), str(fee, 'journal_id'), journalId, command.amount.minorUnits);
    const nextStatus = command.amount.minorUnits === remaining ? 'fully-refunded' : 'partially-refunded';
    if (str(fee, 'status') !== nextStatus) run(apply.database, 'UPDATE fees SET status=? WHERE dataset_id=? AND id=?', nextStatus, apply.datasetId, command.feeId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(fee, 'account_id'));
    apply.event({ kind: 'fee', id: command.feeId }, `Fee ${command.feeId} refunded by ${command.amount.minorUnits} ${command.amount.currency} minor units: ${command.reason.trim()}`);
  } });
}

function journalWithLines(env: FinanceEnvironment, journalId: string): { row: Row; lines: Row[]; corrections: Row[] } | undefined {
  const row = one(env.database, `SELECT j.id,j.reference,j.operation_id,j.status,j.posted_at,j.effective_date,j.description,j.reversal_of_id,o.operation_kind
    FROM journals j LEFT JOIN operations o ON o.dataset_id=j.dataset_id AND o.id=j.operation_id WHERE j.dataset_id=? AND j.id=?`, env.datasetId, journalId);
  if (row === undefined) return undefined;
  const lines = all(env.database, `SELECT l.line_number,l.ledger_account_id,l.currency,l.debit_minor_units,l.credit_minor_units,la.kind,la.customer_account_id
    FROM journal_lines l JOIN ledger_accounts la ON la.dataset_id=l.dataset_id AND la.id=l.ledger_account_id WHERE l.dataset_id=? AND l.journal_id=? ORDER BY l.line_number`, env.datasetId, journalId);
  const corrections = all(env.database, `SELECT id,old_effective_date,new_effective_date,policy_version_id,policy_period_start,policy_period_end,reason,corrected_at
    FROM effective_date_corrections WHERE dataset_id=? AND journal_id=? ORDER BY corrected_at,id`, env.datasetId, journalId);
  return { row, lines, corrections };
}

function journalFingerprint(journal: { row: Row; lines: Row[]; corrections: Row[] }): string {
  return rowFingerprint({ ...journal.row, lines: canonicalJson(journal.lines), corrections: canonicalJson(journal.corrections) }, ['id','reference','operation_id','status','posted_at','effective_date','description','reversal_of_id','operation_kind','lines','corrections']);
}

function twoLineReversal(env: FinanceEnvironment, command: FinanceOf<'cash.deposit.reverse'> | FinanceOf<'cash.withdrawal.reverse'>, expectedKind: string): Preparation {
  const journal = journalWithLines(env, command.journalId);
  if (journal === undefined) return reject('not_found', 'The original posting does not exist.');
  if (journalFingerprint(journal) !== command.expectedFingerprint) return reject('stale_version', 'The original journal changed after review.');
  if (optionalStr(journal.row, 'operation_kind') !== expectedKind || journal.lines.length !== 2) return reject('ineligible', `The posting is not an eligible ${expectedKind} journal.`);
  if (one(env.database, "SELECT 1 AS found FROM correction_links WHERE dataset_id=? AND original_journal_id=? AND kind='reversal'", env.datasetId, command.journalId) !== undefined) return reject('ineligible', 'The posting was already reversed.');
  const debit = journal.lines.find((line) => int(line, 'credit_minor_units') > 0);
  const credit = journal.lines.find((line) => int(line, 'debit_minor_units') > 0);
  if (debit === undefined || credit === undefined) return reject('ineligible', 'The original journal does not have one exact debit and credit.');
  const amount = int(debit, 'credit_minor_units');
  if (amount !== int(credit, 'debit_minor_units') || str(debit, 'currency') !== str(credit, 'currency')) return reject('ineligible', 'The original journal is not balanced in one currency.');
  const customer = journal.lines.find((line) => optionalStr(line, 'customer_account_id') !== null);
  if (customer === undefined) return reject('ineligible', 'The original journal has no customer account leg.');
  if (expectedKind === 'cash.deposit') {
    if (command.kind !== 'cash.deposit.reverse') return reject('validation', 'Cash-deposit correction evidence is required.');
    const accountOwner = one(env.database, `SELECT m.party_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      WHERE a.dataset_id=? AND a.id=?`, env.datasetId, str(customer, 'customer_account_id'));
    if (accountOwner === undefined) return reject('not_found', 'The credited account owner does not exist.');
    const evidence = verifiedEvidence(env, command.correctionEvidenceId, str(accountOwner, 'party_id'));
    if (isRejection(evidence)) return evidence;
    const funds = requireDebit(env, str(customer, 'customer_account_id'), { minorUnits: amount, currency: str(customer, 'currency') });
    if (funds !== null) return funds;
  }
  const money = { minorUnits: amount, currency: str(debit, 'currency') };
  const approval = requireApproval(env, command, command.approvalId, money);
  if (approval !== null) return approval;
  const reason = command.kind === 'cash.deposit.reverse' ? `Evidence ${command.correctionEvidenceId}` : command.reason.trim();
  return approvalPrepared(prepared({ businessReference: str(journal.row, 'reference'), result: { originalJournalId: command.journalId, amount: money }, review: { amount: money, exponent: null, description: reason, accounts: [], consequences: ['Posts a linked full reversal and leaves the original journal unchanged.'] }, apply(apply) {
    const correction = insertJournal(apply, { debitLedgerId: str(debit, 'ledger_account_id'), creditLedgerId: str(credit, 'ledger_account_id'), amount, currency: money.currency, description: `Reversal of ${str(journal.row, 'reference')}: ${reason}`, effectiveDate: str(journal.row, 'effective_date'), prefix: 'RV' });
    run(apply.database, 'UPDATE journals SET reversal_of_id=? WHERE dataset_id=? AND id=?', command.journalId, apply.datasetId, correction);
    run(apply.database, "INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,'reversal')", apply.datasetId, newId('correction-link'), command.journalId, correction, amount);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(customer, 'customer_account_id'));
    apply.event({ kind: 'journal', id: correction }, `Full reversal of ${str(journal.row, 'reference')} posted and linked; original remains unchanged.`);
  } }), command.approvalId);
}

function prepareTransferReverse(env: FinanceEnvironment, command: FinanceOf<'transfer.internal.reverse'>): Preparation {
  const journal = journalWithLines(env, command.transferJournalId);
  if (journal === undefined) return reject('not_found', 'The original transfer does not exist.');
  if (journalFingerprint(journal) !== command.expectedFingerprint) return reject('stale_version', 'The transfer changed after review.');
  if (optionalStr(journal.row, 'operation_kind') !== 'transfer.internal' || journal.lines.length !== 2) return reject('ineligible', 'The journal is not an eligible internal transfer.');
  const sourceLine = journal.lines.find((line) => int(line, 'debit_minor_units') > 0);
  const destinationLine = journal.lines.find((line) => int(line, 'credit_minor_units') > 0);
  if (sourceLine === undefined || destinationLine === undefined || optionalStr(sourceLine, 'customer_account_id') === null || optionalStr(destinationLine, 'customer_account_id') === null) return reject('ineligible', 'The transfer pair is incomplete.');
  if (str(sourceLine, 'customer_account_id') === str(destinationLine, 'customer_account_id')) return reject('ineligible', 'An internal transfer must move funds between two distinct accounts.');
  const invalid = requireMoney(env, command.amount, 'amount');
  if (invalid !== null) return invalid;
  if (command.amount.currency !== str(sourceLine, 'currency')) return reject('currency_mismatch', 'The reversal currency differs from the original transfer.');
  const original = int(sourceLine, 'debit_minor_units');
  const already = optionalInt(one(env.database, "SELECT SUM(amount_minor_units) AS amount FROM correction_links WHERE dataset_id=? AND original_journal_id=? AND kind='reversal'", env.datasetId, command.transferJournalId), 'amount') ?? 0;
  if (command.amount.minorUnits > original - already) return reject('limit_exceeded', `Only ${original - already} minor units remain reversible.`);
  const funds = requireDebit(env, str(destinationLine, 'customer_account_id'), command.amount);
  if (funds !== null) return funds;
  const approval = requireApproval(env, command, command.approvalId, command.amount);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: str(journal.row, 'reference'), result: { originalJournalId: command.transferJournalId, amount: command.amount, remainingReversibleMinorUnits: original - already - command.amount.minorUnits }, review: { amount: command.amount, exponent: null, description: command.reason.trim(), accounts: [], consequences: ['Posts a balanced compensating transfer across the original two accounts.'] }, apply(apply) {
    const correction = insertJournal(apply, { debitLedgerId: str(destinationLine, 'ledger_account_id'), creditLedgerId: str(sourceLine, 'ledger_account_id'), amount: command.amount.minorUnits, currency: command.amount.currency, description: `Reversal of ${str(journal.row, 'reference')}: ${command.reason.trim()}`, prefix: 'TR' });
    run(apply.database, "INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,'reversal')", apply.datasetId, newId('correction-link'), command.transferJournalId, correction, command.amount.minorUnits);
    for (const accountId of new Set([str(sourceLine, 'customer_account_id'), str(destinationLine, 'customer_account_id')])) run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, accountId);
    apply.event({ kind: 'journal', id: correction }, `Balanced ${command.amount.minorUnits} ${command.amount.currency} reversal linked to transfer ${str(journal.row, 'reference')}.`);
  } }), command.approvalId);
}

function prepareInterest(env: FinanceEnvironment, command: FinanceOf<'interest.adjust'>): Preparation {
  const calculation = one(env.database, `SELECT id,account_id,policy_version_id,period_start,period_end,calculated_interest_minor_units,booked_interest_minor_units,delta_minor_units,original_journal_id,adjustment_journal_id,state
    FROM interest_calculations WHERE dataset_id=? AND id=?`, env.datasetId, command.calculationId);
  if (calculation === undefined || str(calculation, 'account_id') !== command.accountId) return reject('not_found', 'The interest calculation does not exist for this account.');
  const stale = requireFingerprint(calculation, ['id','account_id','policy_version_id','period_start','period_end','calculated_interest_minor_units','booked_interest_minor_units','delta_minor_units','original_journal_id','adjustment_journal_id','state'], command.expectedFingerprint, 'interest calculation');
  if (stale !== null) return stale;
  if (optionalStr(calculation, 'adjustment_journal_id') !== null) return reject('ineligible', 'This calculation already has an adjustment.');
  const account = loadAccount(env, command.accountId);
  if (account === undefined) return reject('not_found', 'The account does not exist.');
  const delta = int(calculation, 'delta_minor_units');
  if (delta === 0) return { kind: 'unchanged', message: 'The approved calculation has no adjustment delta.' };
  const invalid = requireMoney(env, { minorUnits: Math.abs(command.approvedDelta.minorUnits), currency: command.approvedDelta.currency }, 'approvedDelta');
  if (invalid !== null) return invalid;
  if (command.approvedDelta.minorUnits !== delta || command.approvedDelta.currency !== str(account, 'currency')) return reject('validation', 'The approved delta must exactly match the versioned calculation.', { field: 'approvedDelta' });
  const customer = ledgerForAccount(env, command.accountId);
  const expense = generalLedger(env, str(account, 'currency'), 'interest-expense');
  if (customer === undefined || expense === undefined) return reject('ineligible', 'Interest ledgers are not configured.');
  const approval = requireApproval(env, command, command.approvalId, { minorUnits: Math.abs(delta), currency: command.approvedDelta.currency });
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: command.calculationId, result: { calculationId: command.calculationId, delta: command.approvedDelta }, review: { amount: { minorUnits: Math.abs(delta), currency: command.approvedDelta.currency }, exponent: null, description: 'Versioned interest correction', accounts: [], consequences: ['Posts only the signed delta supplied by the stored calculation.'] }, apply(apply) {
    const journal = insertJournal(apply, { debitLedgerId: delta > 0 ? str(expense, 'id') : str(customer, 'id'), creditLedgerId: delta > 0 ? str(customer, 'id') : str(expense, 'id'), amount: Math.abs(delta), currency: command.approvedDelta.currency, description: 'Interest adjustment from versioned calculation', effectiveDate: str(calculation, 'period_end'), prefix: 'IA' });
    run(apply.database, "UPDATE interest_calculations SET adjustment_journal_id=?,state='posted' WHERE dataset_id=? AND id=?", journal, apply.datasetId, command.calculationId);
    run(apply.database, "INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,'adjustment')", apply.datasetId, newId('correction-link'), str(calculation, 'original_journal_id'), journal, Math.abs(delta));
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'journal', id: journal }, `Interest calculation ${command.calculationId} adjusted by ${delta} ${command.approvedDelta.currency} minor units.`);
  } }), command.approvalId);
}

function prepareEffectiveDate(env: FinanceEnvironment, command: FinanceOf<'transaction.effective_date.correct'>): Preparation {
  const journal = journalWithLines(env, command.journalId);
  if (journal === undefined) return reject('not_found', 'The transaction does not exist.');
  if (journalFingerprint(journal) !== command.expectedFingerprint) return reject('stale_version', 'The transaction changed after review.');
  const invalid = validation([requireDate(command.correctedDate, 'correctedDate'), requireText(command.reason, 'reason', 'Reason')]);
  if (invalid !== null) return invalid;
  const latestCorrection = journal.corrections.at(-1);
  const currentEffectiveDate = latestCorrection === undefined ? str(journal.row, 'effective_date') : str(latestCorrection, 'new_effective_date');
  if (currentEffectiveDate === command.correctedDate) return { kind: 'unchanged', message: 'The transaction already has this effective date.' };
  const policy = one(env.database, 'SELECT rules_json FROM policy_versions WHERE dataset_id=? AND id=? AND effective_at<=?', env.datasetId, command.policyVersionId, env.now);
  if (policy === undefined) return reject('ineligible', 'The correction policy is unavailable.');
  const rules = JSON.parse(str(policy, 'rules_json')) as { periodStartInclusive?: string; periodEndExclusive?: string; correctionPeriodStatus?: string };
  if (rules.correctionPeriodStatus !== 'open' || rules.periodStartInclusive === undefined || rules.periodEndExclusive === undefined || command.correctedDate < rules.periodStartInclusive || command.correctedDate >= rules.periodEndExclusive) return reject('ineligible', 'The corrected date is outside the open policy period.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: str(journal.row, 'reference'), result: { journalId: command.journalId, oldEffectiveDate: currentEffectiveDate, newEffectiveDate: command.correctedDate }, review: noFinanceReview(['Appends an immutable effective-date correction; posted time, amount and original journal remain unchanged.']), apply(apply) {
    const receipt = one(apply.database, 'SELECT id FROM operation_receipts WHERE dataset_id=? AND operation_id=?', apply.datasetId, apply.operationId);
    if (receipt === undefined) throw new Error('Effective-date correction operation has no receipt.');
    run(apply.database, `INSERT INTO effective_date_corrections (dataset_id,id,journal_id,actor_id,receipt_id,old_effective_date,new_effective_date,policy_version_id,policy_period_start,policy_period_end,reason,corrected_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, apply.datasetId, newId('effective-date-correction'), command.journalId, apply.actorId, str(receipt, 'id'), currentEffectiveDate, command.correctedDate, command.policyVersionId, rules.periodStartInclusive ?? '', rules.periodEndExclusive ?? '', command.reason.trim(), apply.now);
    apply.event({ kind: 'journal', id: command.journalId }, `Effective-date correction recorded from ${currentEffectiveDate} to ${command.correctedDate}; original posting unchanged.`);
  } }), command.approvalId);
}

export function prepareFinanceMember(env: FinanceEnvironment, command: FinanceCommand): Preparation | null {
  switch (command.kind) {
    case 'member.merge': return prepareMemberMerge(env, command);
    case 'member.deceased.record': return prepareDeceased(env, command);
    case 'member.beneficial_owners.update': return prepareBeneficialOwners(env, command);
    case 'member.tax_classification.update': return prepareTax(env, command);
    case 'account.product.convert': return prepareProductConvert(env, command);
    case 'account.owner.add': return prepareOwnerAdd(env, command);
    case 'account.signer.remove': return prepareSignerRemove(env, command);
    case 'account.overdraft_limit.update': return prepareOverdraft(env, command);
    case 'account.hold.place': return prepareHoldPlace(env, command);
    case 'account.hold.release': return prepareHoldRelease(env, command);
    case 'account.restriction.apply': return prepareRestrictionApply(env, command);
    case 'account.restriction.release': return prepareRestrictionRelease(env, command);
    case 'fee.assess': return prepareFeeAssess(env, command);
    case 'fee.waiver.create': return prepareFeeWaiver(env, command);
    case 'fee.refund': return prepareFeeRefund(env, command);
    case 'cash.deposit.reverse': return twoLineReversal(env, command, 'cash.deposit');
    case 'cash.withdrawal.reverse': return twoLineReversal(env, command, 'cash.withdraw');
    case 'transfer.internal.reverse': return prepareTransferReverse(env, command);
    case 'interest.adjust': return prepareInterest(env, command);
    case 'transaction.effective_date.correct': return prepareEffectiveDate(env, command);
    default: return null;
  }
}

export function financialFingerprint(databaseRow: Row, columns: readonly string[]): string { return rowFingerprint(databaseRow, columns); }
