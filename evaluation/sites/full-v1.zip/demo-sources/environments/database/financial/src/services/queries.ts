import { activityScopePredicate } from './activity-scope.js';
import { accountProductSql } from '../product-sql.js';
import { facilityLimitSql } from '../facility-sql.js';
import { documentReadFilter } from './document-access.js';
import type { SQLInputValue } from 'node:sqlite';

import { renderCsv, renderStatementPdf, type DocumentArtifact } from '../documents.js';
import {
  accountFacts, actorPermissions, actorRef, all, datasetClock, int, isIsoDate, loadReceipt, localDate, one, optionalInt, optionalStr, sha256, str, type Row,
} from './core.js';
import { CASE_CATEGORIES, CASE_TRANSITIONS, closureEligibility, creditEligibility, debitEligibility, RESTRICTED_NOTE_GRANTS } from './rules.js';
import type { SqlDatabase } from './store.js';
import type { ActorRef, CaseState, Eligibility, Receipt } from './types.js';

export interface PageQuery {
  limit: number;
  offset: number;
}

export interface PageResult<T> {
  items: T[];
  total: number;
  offset: number;
  limit: number;
}

export type SortDirection = 'asc' | 'desc';

const MAX_PAGE = 200;
const MAX_OFFSET = 1_000_000;

function validatePage(page: PageQuery): void {
  if (!Number.isSafeInteger(page.limit) || page.limit < 1 || page.limit > MAX_PAGE) throw new RangeError(`Page limit must be an integer from 1 through ${MAX_PAGE}.`);
  if (!Number.isSafeInteger(page.offset) || page.offset < 0 || page.offset > MAX_OFFSET) throw new RangeError(`Page offset must be an integer from 0 through ${MAX_OFFSET}.`);
}

function likeFragment(value: string): string {
  return value.replaceAll('\\', '\\\\').replaceAll('%', '\\%').replaceAll('_', '\\_');
}

function paged<T>(database: SqlDatabase, select: string, from: string, where: string, parameters: SQLInputValue[], order: string, page: PageQuery, map: (row: Row) => T): PageResult<T> {
  validatePage(page);
  const total = int(one(database, `SELECT COUNT(*) AS count ${from} WHERE ${where}`, ...parameters), 'count');
  const items = all(database, `SELECT ${select} ${from} WHERE ${where} ORDER BY ${order} LIMIT ? OFFSET ?`, ...parameters, page.limit, page.offset).map(map);
  return { items, total, offset: page.offset, limit: page.limit };
}

export interface InstitutionSummary {
  institutionId: string;
  datasetId: string;
  displayName: string;
  legalName: string;
  timeZone: string;
  defaultCurrency: string;
  asOf: string;
}

export function institutionSummary(database: SqlDatabase, datasetId: string): InstitutionSummary {
  const row = one(database, 'SELECT d.id,d.as_of,i.id AS institution_id,i.display_name,i.legal_name,i.time_zone,i.default_currency FROM datasets d JOIN institutions i ON i.id=d.institution_id WHERE d.id=?', datasetId);
  if (row === undefined) throw new Error('Unknown dataset.');
  return { institutionId: str(row, 'institution_id'), datasetId: str(row, 'id'), displayName: str(row, 'display_name'), legalName: str(row, 'legal_name'), timeZone: str(row, 'time_zone'), defaultCurrency: str(row, 'default_currency'), asOf: str(row, 'as_of') };
}

export interface OperatorProfile {
  actor: ActorRef;
  status: string;
  roles: string[];
  permissions: string[];
}

export function operatorProfile(database: SqlDatabase, datasetId: string, institutionId: string, actorNumber: string, instant?: string): OperatorProfile | undefined {
  const row = one(database, 'SELECT id,status FROM actors WHERE dataset_id=? AND actor_number=?', datasetId, actorNumber);
  if (row === undefined) return undefined;
  const actorId = str(row, 'id');
  const now = new Date(instant ?? datasetClock(database, datasetId).asOf).toISOString();
  const actor = actorRef(database, datasetId, actorId);
  if (actor === undefined) return undefined;
  const roles = all(database, 'SELECT r.code FROM actor_roles ar JOIN roles r ON r.dataset_id=ar.dataset_id AND r.id=ar.role_id WHERE ar.dataset_id=? AND ar.actor_id=? AND ar.starts_at<=? AND (ar.ends_at IS NULL OR ar.ends_at>?) ORDER BY r.code', datasetId, actorId, now, now).map((role) => str(role, 'code'));
  return { actor, status: str(row, 'status'), roles, permissions: [...actorPermissions(database, datasetId, institutionId, actorId, now)].sort() };
}

export interface MemberRow {
  id: string;
  memberNumber: string;
  displayName: string;
  kind: string;
  status: string;
  joinedAt: string;
  email: string | null;
  phone: string | null;
  openAccounts: number;
  version: number;
}

const MEMBER_SELECT = `m.id,m.member_number,p.display_name,p.kind,m.status,m.joined_at,m.version,
  (SELECT c.value FROM contact_points c WHERE c.dataset_id=m.dataset_id AND c.party_id=m.party_id AND c.kind='email' AND c.valid_to IS NULL ORDER BY c.valid_from DESC,c.id LIMIT 1) AS email,
  (SELECT c.value FROM contact_points c WHERE c.dataset_id=m.dataset_id AND c.party_id=m.party_id AND c.kind='phone' AND c.valid_to IS NULL ORDER BY c.valid_from DESC,c.id LIMIT 1) AS phone,
  (SELECT COUNT(*) FROM accounts a WHERE a.dataset_id=m.dataset_id AND a.member_id=m.id AND a.status NOT IN ('closed','matured')) AS open_accounts`;
const MEMBER_FROM = 'FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id';

function memberRow(row: Row): MemberRow {
  return {
    id: str(row, 'id'), memberNumber: str(row, 'member_number'), displayName: str(row, 'display_name'), kind: str(row, 'kind'), status: str(row, 'status'),
    joinedAt: str(row, 'joined_at'), email: optionalStr(row, 'email'), phone: optionalStr(row, 'phone'), openAccounts: int(row, 'open_accounts'), version: int(row, 'version'),
  };
}

const MEMBER_SORTS: Readonly<Record<string, string>> = { memberNumber: 'm.member_number', name: 'p.display_name COLLATE NOCASE', status: 'm.status', joined: 'm.joined_at' };

/** At most this many explicit record identities may restrict one list query. */
const MAX_ID_FILTER = 500;

function idClause(column: string, ids: readonly string[] | undefined, clauses: string[], parameters: SQLInputValue[]): void {
  if (ids === undefined) return;
  if (ids.length > MAX_ID_FILTER) throw new RangeError(`At most ${MAX_ID_FILTER} record identities can restrict one query.`);
  clauses.push(ids.length === 0 ? '0=1' : `${column} IN (${ids.map(() => '?').join(',')})`);
  parameters.push(...ids);
}

export interface MemberSearch extends PageQuery {
  /** Restricts results to these member identities. */
  ids?: readonly string[];
  query?: string;
  field?: 'memberNumber' | 'name' | 'email' | 'phone' | 'accountNumber';
  match?: 'exact' | 'prefix' | 'contains';
  status?: string;
  sort?: string;
  direction?: SortDirection;
}

/** Finds members by member number, account number prefix, name, email or phone fragment. */
export function searchMembers(database: SqlDatabase, datasetId: string, search: MemberSearch): PageResult<MemberRow> {
  if (search.status !== undefined && !['', 'active', 'inactive', 'deceased', 'merged'].includes(search.status)) throw new RangeError('Unsupported member status.');
  if (search.sort !== undefined && !Object.hasOwn(MEMBER_SORTS, search.sort)) throw new RangeError('Unsupported member sort.');
  if (search.direction !== undefined && !['asc', 'desc'].includes(search.direction)) throw new RangeError('Unsupported sort direction.');
  const clauses = ['m.dataset_id=?'];
  const parameters: SQLInputValue[] = [datasetId];
  const query = search.query?.trim() ?? '';
  if (search.field !== undefined || search.match !== undefined) {
    if (query.length === 0) throw new RangeError('An explicit match requires a nonempty query.');
    if (search.match !== undefined && !['exact', 'prefix', 'contains'].includes(search.match)) throw new RangeError('Unsupported member match mode.');
    if (search.field !== undefined && !['memberNumber', 'name', 'email', 'phone', 'accountNumber'].includes(search.field)) throw new RangeError('Unsupported member search field.');
    const match = search.match ?? 'exact';
    const pattern = match === 'exact' ? query : match === 'prefix' ? `${likeFragment(query)}%` : `%${likeFragment(query)}%`;
    const compare = (column: string): string => match === 'exact' ? `${column}=? COLLATE NOCASE` : `${column} LIKE ? ESCAPE '\\'`;
    const choices = {
      memberNumber: compare('m.member_number'), name: compare('p.display_name'),
      email: `EXISTS (SELECT 1 FROM contact_points c WHERE c.dataset_id=m.dataset_id AND c.party_id=m.party_id AND c.valid_to IS NULL AND c.kind='email' AND ${compare('c.value')})`,
      phone: `EXISTS (SELECT 1 FROM contact_points c WHERE c.dataset_id=m.dataset_id AND c.party_id=m.party_id AND c.valid_to IS NULL AND c.kind='phone' AND ${compare('c.value')})`,
      accountNumber: `EXISTS (SELECT 1 FROM accounts a WHERE a.dataset_id=m.dataset_id AND a.member_id=m.id AND ${compare('a.account_number')})`,
    };
    const predicates = search.field === undefined ? Object.values(choices) : [choices[search.field]];
    clauses.push(`(${predicates.join(' OR ')})`);
    parameters.push(...predicates.map(() => pattern));
  } else if (query.length > 0) {
    const contains = `%${likeFragment(query)}%`;
    const prefix = `${likeFragment(query.toUpperCase())}%`;
    clauses.push(`(m.member_number LIKE ? ESCAPE '\\' OR p.display_name LIKE ? ESCAPE '\\'
      OR EXISTS (SELECT 1 FROM contact_points c WHERE c.dataset_id=m.dataset_id AND c.party_id=m.party_id AND c.valid_to IS NULL AND c.value LIKE ? ESCAPE '\\')
      OR EXISTS (SELECT 1 FROM accounts a WHERE a.dataset_id=m.dataset_id AND a.member_id=m.id AND a.account_number LIKE ? ESCAPE '\\'))`);
    parameters.push(prefix, contains, contains, prefix);
  }
  if (search.status !== undefined && search.status !== '') { clauses.push('m.status=?'); parameters.push(search.status); }
  idClause('m.id', search.ids, clauses, parameters);
  const sort = MEMBER_SORTS[search.sort ?? 'memberNumber'] ?? 'm.member_number';
  const direction = search.direction === 'desc' ? 'DESC' : 'ASC';
  return paged(database, MEMBER_SELECT, MEMBER_FROM, clauses.join(' AND '), parameters, `${sort} ${direction},m.id ${direction}`, search, memberRow);
}

export interface AccountRow {
  id: string;
  accountNumber: string;
  memberId: string;
  memberNumber: string;
  ownerName: string;
  /** Effective roles for the member filter; empty for an unscoped listing. */
  memberRoles: string[];
  productId: string;
  productCode: string;
  productName: string;
  currency: string;
  exponent: number;
  status: string;
  nickname: string;
  statementDelivery: string;
  postedMinorUnits: number;
  availableMinorUnits: number;
  openedAt: string;
  closedAt: string | null;
  version: number;
}

const ACCOUNT_SELECT = `a.id,a.account_number,a.member_id,m.member_number,p.display_name AS owner_name,pr.id AS product_id,pr.code AS product_code,pr.name AS product_name,a.currency,c.exponent,a.status,
  a.nickname,a.statement_delivery,b.posted_balance_minor_units,b.available_balance_minor_units,a.opened_at,a.closed_at,a.version`;
const ACCOUNT_FROM = `FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
  JOIN products pr ON pr.dataset_id=a.dataset_id AND pr.id=${accountProductSql('(SELECT as_of FROM datasets WHERE id=a.dataset_id)')} JOIN currencies c ON c.code=a.currency JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id`;

function accountFrom(instant?: string): string { return instant===undefined ? ACCOUNT_FROM : ACCOUNT_FROM.replaceAll('(SELECT as_of FROM datasets WHERE id=a.dataset_id)',`'${new Date(instant).toISOString()}'`); }

function accountRow(row: Row): AccountRow {
  return {
    memberRoles: (optionalStr(row, 'scoped_roles') ?? '').split(',').filter(Boolean),
    id: str(row, 'id'), accountNumber: str(row, 'account_number'), memberId: str(row, 'member_id'), memberNumber: str(row, 'member_number'), ownerName: str(row, 'owner_name'),
    productId: str(row, 'product_id'), productCode: str(row, 'product_code'), productName: str(row, 'product_name'), currency: str(row, 'currency'), exponent: int(row, 'exponent'),
    status: str(row, 'status'), nickname: str(row, 'nickname'), statementDelivery: str(row, 'statement_delivery'), postedMinorUnits: int(row, 'posted_balance_minor_units'),
    availableMinorUnits: int(row, 'available_balance_minor_units'), openedAt: str(row, 'opened_at'), closedAt: optionalStr(row, 'closed_at'), version: int(row, 'version'),
  };
}

const ACCOUNT_SORTS: Readonly<Record<string, string>> = {
  accountNumber: 'a.account_number', memberNumber: 'm.member_number', owner: 'p.display_name COLLATE NOCASE', product: 'pr.code', status: 'a.status',
  nickname: 'a.nickname COLLATE NOCASE', posted: 'b.posted_balance_minor_units', available: 'b.available_balance_minor_units', opened: 'a.opened_at',
};

export const ACCOUNT_RELATIONSHIP_ROLES = ['owner','joint-owner','signer','guardian','beneficial-owner','beneficiary'] as const;
export type AccountRelationshipRole = typeof ACCOUNT_RELATIONSHIP_ROLES[number];
export interface AccountSearch extends PageQuery {
  ownershipRole?: AccountRelationshipRole;
  /** Restricts results to these account identities. */
  ids?: readonly string[];
  memberId?: string;
  query?: string;
  status?: string;
  currency?: string;
  sort?: string;
  direction?: SortDirection;
}

export function searchAccounts(database: SqlDatabase, datasetId: string, search: AccountSearch, instant?: string): PageResult<AccountRow> {
  if (search.status !== undefined && !['', 'open', 'restricted', 'dormant', 'closed', 'matured'].includes(search.status)) throw new RangeError('Unsupported account status.');
  if (search.sort !== undefined && !Object.hasOwn(ACCOUNT_SORTS, search.sort)) throw new RangeError('Unsupported account sort.');
  if (search.direction !== undefined && !['asc', 'desc'].includes(search.direction)) throw new RangeError('Unsupported sort direction.');
  const clauses = ['a.dataset_id=?'];
  const parameters: SQLInputValue[] = [datasetId];
  if (search.ownershipRole !== undefined && !ACCOUNT_RELATIONSHIP_ROLES.includes(search.ownershipRole)) throw new RangeError('Unsupported ownership role.');
  if (search.ownershipRole !== undefined && search.memberId === undefined) throw new RangeError('An ownership role requires a member scope.');
  const observedAt = new Date(instant ?? datasetClock(database, datasetId).asOf).toISOString();
  const relationship = `FROM account_parties ap JOIN members scoped ON scoped.dataset_id=ap.dataset_id AND scoped.party_id=ap.party_id WHERE ap.dataset_id=a.dataset_id AND ap.account_id=a.id AND scoped.id=? AND ap.starts_at<=? AND (ap.ends_at IS NULL OR ap.ends_at>?)${search.ownershipRole === undefined ? '' : ' AND ap.role=?'}`;
  const relationshipParameters = search.memberId === undefined ? [] : [search.memberId,observedAt,observedAt,...(search.ownershipRole === undefined ? [] : [search.ownershipRole])];
  if (search.memberId !== undefined) { clauses.push(`EXISTS (SELECT 1 ${relationship})`); parameters.push(...relationshipParameters); }
  const query = search.query?.trim() ?? '';
  if (query.length > 0) {
    const prefix = `${likeFragment(query.toUpperCase())}%`;
    const contains = `%${likeFragment(query)}%`;
    clauses.push("(a.account_number LIKE ? ESCAPE '\\' OR m.member_number LIKE ? ESCAPE '\\' OR a.nickname LIKE ? ESCAPE '\\' OR p.display_name LIKE ? ESCAPE '\\')");
    parameters.push(prefix, prefix, contains, contains);
  }
  if (search.status !== undefined && search.status !== '') { clauses.push('a.status=?'); parameters.push(search.status); }
  if (search.currency !== undefined && search.currency !== '') { clauses.push('a.currency=?'); parameters.push(search.currency); }
  idClause('a.id', search.ids, clauses, parameters);
  const available = instant === undefined ? 'b.available_balance_minor_units' : `b.available_balance_minor_units + COALESCE((SELECT SUM(h.amount_minor_units) FROM holds h WHERE h.dataset_id=a.dataset_id AND h.account_id=a.id AND h.status='active' AND (h.expires_at IS NULL OR h.expires_at>(SELECT as_of FROM datasets WHERE id=a.dataset_id))),0) - COALESCE((SELECT SUM(h.amount_minor_units) FROM holds h WHERE h.dataset_id=a.dataset_id AND h.account_id=a.id AND h.status='active' AND (h.expires_at IS NULL OR h.expires_at>'${new Date(instant).toISOString()}')),0)`;
  const facilityAdjustment = instant===undefined ? '' : ` + (SELECT COALESCE(SUM(MAX(0,${facilityLimitSql(`'${new Date(instant).toISOString()}'`)}-f.used_minor_units)),0) FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id AND f.status='active') - (SELECT COALESCE(SUM(MAX(0,${facilityLimitSql('(SELECT as_of FROM datasets WHERE id=f.dataset_id)')}-f.used_minor_units)),0) FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id AND f.status='active')`;
  const currentAvailable=`${available}${facilityAdjustment}`;
  const sort = search.sort === 'available' ? currentAvailable : ACCOUNT_SORTS[search.sort ?? 'accountNumber'] ?? 'a.account_number';
  const direction = search.direction === 'desc' ? 'DESC' : 'ASC';
  const page = paged(database, ACCOUNT_SELECT.replace('b.available_balance_minor_units', `${currentAvailable} AS available_balance_minor_units`), accountFrom(instant), clauses.join(' AND '), parameters, `${sort} ${direction},a.id ${direction}`, search, accountRow);
  if (search.memberId !== undefined) for (const item of page.items) item.memberRoles = all(database, `SELECT ap.role FROM account_parties ap JOIN members scoped ON scoped.dataset_id=ap.dataset_id AND scoped.party_id=ap.party_id WHERE ap.dataset_id=? AND ap.account_id=? AND scoped.id=? AND ap.starts_at<=? AND (ap.ends_at IS NULL OR ap.ends_at>?) ORDER BY ap.role`, datasetId,item.id,search.memberId,observedAt,observedAt).map(row=>str(row,'role'));
  return page;
}

export interface NoteRow {
  evidenceVersionIds: string[];
  id: string;
  visibility: string;
  text: string;
  createdAt: string;
  actor: ActorRef | null;
}

export interface CaseRow {
  id: string;
  caseNumber: string;
  memberId: string;
  memberNumber: string;
  memberName: string;
  accountId: string | null;
  accountNumber: string | null;
  queueId: string;
  queueCode: string;
  queueName: string;
  assignedActorId: string | null;
  assignedName: string | null;
  state: string;
  priority: string;
  category: string;
  categoryLabel: string;
  summary: string;
  openedAt: string;
  dueAt: string;
  overdue: boolean;
  version: number;
}

export interface MemberDetail {
  member: MemberRow & { taxClassification: string; partyId: string };
  person: { legalGiven: string; legalFamily: string; preferredName: string | null; preferredNameScope: 'servicing' | 'communications' | 'all' | null; birthDate: string; deceasedAt: string | null } | null;
  organization: { legalName: string; registrationNumber: string; organizationType: string } | null;
  email: { id: string; value: string; verifiedAt: string | null } | null;
  phone: { id: string; value: string; verifiedAt: string | null } | null;
  address: { line1: string; line2: string | null; city: string; region: string; postalCode: string; country: string; evidenceStatus: string } | null;
  redirectTo: { memberId: string; memberNumber: string } | null;
  /** Newest first; restricted notes appear only for a reader authorized to see them. */
  notes: NoteRow[];
  /** Restricted notes left out of `notes` because the reader may not see them. */
  restrictedNotesWithheld: number;
  accounts: AccountRow[];
  cases: CaseRow[];
}

/** The operator a detail read is for. Reads that name no reader never include restricted notes. */
export interface NoteReader {
  institutionId: string;
  actorId: string;
  now?: string;
}

/** True when the reader is an active operator holding a restricted-note grant at the dataset's business time. */
export function readsRestrictedNotes(database: SqlDatabase, datasetId: string, reader: NoteReader | undefined): boolean {
  if (reader === undefined) return false;
  if (datasetClock(database, datasetId).institutionId !== reader.institutionId) return false;
  const actor = one(database, 'SELECT status FROM actors WHERE dataset_id=? AND id=?', datasetId, reader.actorId);
  if (actor === undefined || str(actor, 'status') !== 'active') return false;
  const permissions = actorPermissions(database, datasetId, reader.institutionId, reader.actorId, reader.now ?? datasetClock(database, datasetId).asOf);
  return RESTRICTED_NOTE_GRANTS.some((grant) => permissions.has(grant));
}

function noteRows(database: SqlDatabase, datasetId: string, table: 'member_notes' | 'case_notes', column: 'member_id' | 'case_id', ownerId: string, reader: NoteReader | undefined): { notes: NoteRow[]; withheld: number } {
  const restricted = readsRestrictedNotes(database, datasetId, reader);
  const visible = restricted ? '' : " AND n.visibility='general'";
  const notes = all(database, `SELECT n.id,n.visibility,n.text,n.created_at,n.actor_id,a.actor_number,a.display_name FROM ${table} n LEFT JOIN actors a ON a.dataset_id=n.dataset_id AND a.id=n.actor_id
    WHERE n.dataset_id=? AND n.${column}=?${visible} ORDER BY n.created_at DESC,n.rowid DESC LIMIT 200`, datasetId, ownerId).map((row) => ({
    evidenceVersionIds: table === 'case_notes' ? all(database,'SELECT document_version_id FROM case_note_documents WHERE dataset_id=? AND note_id=? ORDER BY document_version_id',datasetId,str(row,'id')).map(evidence=>str(evidence,'document_version_id')) : [],
    id: str(row, 'id'), visibility: str(row, 'visibility'), text: str(row, 'text'), createdAt: str(row, 'created_at'),
    actor: optionalStr(row, 'actor_number') === null ? null : { id: str(row, 'actor_id'), actorNumber: str(row, 'actor_number'), displayName: str(row, 'display_name') },
  }));
  const withheld = restricted ? 0 : int(one(database, `SELECT COUNT(*) AS count FROM ${table} WHERE dataset_id=? AND ${column}=? AND visibility='restricted'`, datasetId, ownerId), 'count');
  return { notes, withheld };
}

function contact(database: SqlDatabase, datasetId: string, partyId: string, kind: 'email' | 'phone'): MemberDetail['email'] {
  const row = one(database, `SELECT id,value,verified_at FROM contact_points WHERE dataset_id=? AND party_id=? AND kind=? AND valid_to IS NULL
    ORDER BY CASE purpose WHEN 'primary' THEN 0 WHEN 'mobile' THEN 0 ELSE 1 END,valid_from DESC,id LIMIT 1`, datasetId, partyId, kind);
  return row === undefined ? null : { id: str(row, 'id'), value: str(row, 'value'), verifiedAt: optionalStr(row, 'verified_at') };
}

export function memberDetail(database: SqlDatabase, datasetId: string, memberId: string, reader?: NoteReader): MemberDetail | undefined {
  const clock=datasetClock(database,datasetId);
  const taxDate=localDate(reader?.now??clock.asOf,clock.timeZone);
  const row = one(database, `SELECT ${MEMBER_SELECT},COALESCE((SELECT t.classification FROM tax_status_history t WHERE t.dataset_id=m.dataset_id AND t.member_id=m.id AND t.valid_from<=? AND (t.valid_to IS NULL OR t.valid_to>?) ORDER BY t.valid_from DESC,t.id DESC LIMIT 1),m.tax_classification) AS tax_classification,m.party_id ${MEMBER_FROM} WHERE m.dataset_id=? AND m.id=?`, taxDate,taxDate,datasetId, memberId);
  if (row === undefined) return undefined;
  const partyId = str(row, 'party_id');
  const person = one(database, 'SELECT legal_given,legal_family,preferred_name,preferred_name_scope,birth_date,deceased_at FROM people WHERE dataset_id=? AND party_id=?', datasetId, partyId);
  const organization = one(database, 'SELECT legal_name,registration_number,organization_type FROM organizations WHERE dataset_id=? AND party_id=?', datasetId, partyId);
  const address = one(database, `SELECT a.line1,a.line2,a.city,a.region,a.postal_code,a.country,pa.evidence_status FROM party_addresses pa JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
    WHERE pa.dataset_id=? AND pa.party_id=? AND pa.purpose='mailing' AND pa.valid_to IS NULL ORDER BY pa.valid_from DESC,pa.id LIMIT 1`, datasetId, partyId);
  const redirect = one(database, 'SELECT r.target_member_id,m.member_number FROM member_redirects r JOIN members m ON m.dataset_id=r.dataset_id AND m.id=r.target_member_id WHERE r.dataset_id=? AND r.source_member_id=?', datasetId, memberId);
  const { notes, withheld } = noteRows(database, datasetId, 'member_notes', 'member_id', memberId, reader);
  return {
    member: { ...memberRow(row), taxClassification: str(row, 'tax_classification'), partyId },
    person: person === undefined ? null : { legalGiven: str(person, 'legal_given'), legalFamily: str(person, 'legal_family'), preferredName: optionalStr(person, 'preferred_name'),
      preferredNameScope: optionalStr(person, 'preferred_name_scope') as 'servicing' | 'communications' | 'all' | null, birthDate: str(person, 'birth_date'), deceasedAt: optionalStr(person, 'deceased_at') },
    organization: organization === undefined ? null : { legalName: str(organization, 'legal_name'), registrationNumber: str(organization, 'registration_number'), organizationType: str(organization, 'organization_type') },
    email: contact(database, datasetId, partyId, 'email'),
    phone: contact(database, datasetId, partyId, 'phone'),
    address: address === undefined ? null : { line1: str(address, 'line1'), line2: optionalStr(address, 'line2'), city: str(address, 'city'), region: str(address, 'region'), postalCode: str(address, 'postal_code'), country: str(address, 'country'), evidenceStatus: str(address, 'evidence_status') },
    redirectTo: redirect === undefined ? null : { memberId: str(redirect, 'target_member_id'), memberNumber: str(redirect, 'member_number') },
    notes,
    restrictedNotesWithheld: withheld,
    accounts: searchAccounts(database, datasetId, { memberId, limit: 200, offset: 0 }, reader?.now).items,
    cases: searchCases(database, datasetId, { memberId, limit: 100, offset: 0 }, reader?.now).items,
  };
}

export interface AccountDetail {
  account: AccountRow;
  memberStatus: string;
  parties: { partyId: string; displayName: string; role: string; startsAt: string; endsAt: string | null }[];
  holds: { id: string; amountMinorUnits: number; status: string; reason: string; releaseAuthority: string; placedAt: string }[];
  restrictions: { id: string; kind: string; status: string; authority: string; placedAt: string }[];
  facilities: { id: string; kind: string; limitMinorUnits: number; usedMinorUnits: number; status: string }[];
  maturityTerms: { id: string; maturityDate: string; cutoffAt: string; projectedProceedsMinorUnits: number; currency: string; productTermId: string }[];
  maturityInstructions: { id: string; state: string; version: number; cutoffAt: string }[];
  cards: { id: string; lastFour: string; status: string }[];
  eligibility: { debit: Eligibility; credit: Eligibility; closure: Eligibility };
  observedAt: string;
}

export function accountDetail(database: SqlDatabase, datasetId: string, accountId: string, instant?: string): AccountDetail | undefined {
  const row = one(database, `SELECT ${ACCOUNT_SELECT},m.status AS member_status ${accountFrom(instant)} WHERE a.dataset_id=? AND a.id=?`, datasetId, accountId);
  if (row === undefined) return undefined;
  const now = new Date(instant ?? datasetClock(database, datasetId).asOf).toISOString();
  const facts = accountFacts(database, datasetId, accountId, now);
  if (facts === undefined) return undefined;
  return {
    account: { ...accountRow(row), availableMinorUnits: facts.availableMinorUnits }, memberStatus: str(row, 'member_status'),
    parties: all(database, 'SELECT ap.party_id,p.display_name,ap.role,ap.starts_at,ap.ends_at FROM account_parties ap JOIN parties p ON p.dataset_id=ap.dataset_id AND p.id=ap.party_id WHERE ap.dataset_id=? AND ap.account_id=? ORDER BY ap.role,p.display_name', datasetId, accountId)
      .map((party) => ({ partyId: str(party, 'party_id'), displayName: str(party, 'display_name'), role: str(party, 'role'), startsAt: str(party, 'starts_at'), endsAt: optionalStr(party, 'ends_at') })),
    holds: all(database, 'SELECT id,amount_minor_units,status,reason,release_authority,placed_at FROM holds WHERE dataset_id=? AND account_id=? ORDER BY placed_at DESC,id', datasetId, accountId)
      .map((hold) => ({ id: str(hold, 'id'), amountMinorUnits: int(hold, 'amount_minor_units'), status: str(hold, 'status'), reason: str(hold, 'reason'), releaseAuthority: str(hold, 'release_authority'), placedAt: str(hold, 'placed_at') })),
    restrictions: all(database, 'SELECT id,kind,status,authority,placed_at FROM restrictions WHERE dataset_id=? AND account_id=? ORDER BY placed_at DESC,id', datasetId, accountId)
      .map((restriction) => ({ id: str(restriction, 'id'), kind: str(restriction, 'kind'), status: str(restriction, 'status'), authority: str(restriction, 'authority'), placedAt: str(restriction, 'placed_at') })),
    facilities: all(database, `SELECT f.id,f.kind,${facilityLimitSql(`'${new Date(now).toISOString()}'`)} AS limit_minor_units,f.used_minor_units,f.status FROM facilities f WHERE f.dataset_id=? AND f.account_id=? ORDER BY f.id`, datasetId, accountId)
      .map((facility) => ({ id: str(facility, 'id'), kind: str(facility, 'kind'), limitMinorUnits: int(facility, 'limit_minor_units'), usedMinorUnits: int(facility, 'used_minor_units'), status: str(facility, 'status') })),
    maturityTerms: all(database,'SELECT id,maturity_date,cutoff_at,projected_proceeds_minor_units,currency,product_term_id FROM deposit_maturity_terms WHERE dataset_id=? AND account_id=? ORDER BY maturity_date,id',datasetId,accountId)
      .map(term=>({id:str(term,'id'),maturityDate:str(term,'maturity_date'),cutoffAt:str(term,'cutoff_at'),projectedProceedsMinorUnits:int(term,'projected_proceeds_minor_units'),currency:str(term,'currency'),productTermId:str(term,'product_term_id')})),
    maturityInstructions: all(database,'SELECT id,state,version,cutoff_at FROM maturity_instructions WHERE dataset_id=? AND account_id=? ORDER BY cutoff_at,id',datasetId,accountId)
      .map(instruction=>({id:str(instruction,'id'),state:str(instruction,'state'),version:int(instruction,'version'),cutoffAt:str(instruction,'cutoff_at')})),
    cards: all(database, 'SELECT id,last_four,status FROM cards WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, accountId)
      .map((card) => ({ id: str(card, 'id'), lastFour: str(card, 'last_four'), status: str(card, 'status') })),
    eligibility: { debit: debitEligibility(facts), credit: creditEligibility(facts), closure: closureEligibility(facts) },
    observedAt: now,
  };
}

export interface TransactionRow {
  journalId: string;
  reference: string;
  postedAt: string;
  effectiveDate: string;
  description: string;
  status: string;
  lineNumber: number;
  amountMinorUnits: number;
  runningBalanceMinorUnits: number;
  counterparty: string | null;
  operationKind: string | null;
  receiptNumber: string | null;
}

export interface TransactionSearch extends PageQuery {
  /** Inclusive local start date. */
  startDate?: string;
  /** Exclusive local end date. */
  endDate?: string;
  direction?: 'credit' | 'debit';
  minMinorUnits?: number;
  maxMinorUnits?: number;
  text?: string;
  order?: 'newest' | 'oldest';
  /** Journal status; omitted lists both posted and reversed entries. */
  status?: 'posted' | 'reversed';
  /** Exact journal reference, compared without regard to letter case. `text` matches fragments instead. */
  reference?: string;
}

const TRANSACTION_STATUSES: ReadonlySet<string> = new Set(['posted', 'reversed']);

/** Account ledger entries with signed amounts and a posted running balance in ledger order. */
export function accountTransactions(database: SqlDatabase, datasetId: string, accountId: string, search: TransactionSearch): PageResult<TransactionRow> {
  validatePage(search);
  if (search.direction !== undefined && !['credit', 'debit'].includes(search.direction)) throw new RangeError('Transaction direction must be credit or debit.');
  if (search.order !== undefined && !['newest', 'oldest'].includes(search.order)) throw new RangeError('Transaction order must be newest or oldest.');
  for (const amount of [search.minMinorUnits, search.maxMinorUnits]) if (amount !== undefined && (!Number.isSafeInteger(amount) || amount < 0)) throw new RangeError('Amount filters must be nonnegative exact minor units.');
  if (search.minMinorUnits !== undefined && search.maxMinorUnits !== undefined && search.minMinorUnits > search.maxMinorUnits) throw new RangeError('Amount filter bounds are reversed.');
  if (search.startDate !== undefined && search.endDate !== undefined && search.startDate > search.endDate) throw new RangeError('Date filter bounds are reversed.');
  for (const date of [search.startDate, search.endDate]) if (date !== undefined && !isIsoDate(date)) throw new RangeError('Transaction dates must be YYYY-MM-DD.');
  const clauses = ['1=1'];
  const parameters: SQLInputValue[] = [datasetId, accountId];
  if (search.startDate !== undefined) { clauses.push('effective_date>=?'); parameters.push(search.startDate); }
  if (search.endDate !== undefined) { clauses.push('effective_date<?'); parameters.push(search.endDate); }
  if (search.direction === 'credit') clauses.push('amount>0');
  if (search.direction === 'debit') clauses.push('amount<0');
  if (search.minMinorUnits !== undefined) { clauses.push('ABS(amount)>=?'); parameters.push(search.minMinorUnits); }
  if (search.maxMinorUnits !== undefined) { clauses.push('ABS(amount)<=?'); parameters.push(search.maxMinorUnits); }
  const text = search.text?.trim() ?? '';
  if (text.length > 0) { clauses.push("(reference LIKE ? ESCAPE '\\' OR description LIKE ? ESCAPE '\\')"); parameters.push(`%${likeFragment(text)}%`, `%${likeFragment(text)}%`); }  if (search.status !== undefined) {
    if (!TRANSACTION_STATUSES.has(search.status)) throw new RangeError('Transaction status must be posted or reversed.');
    clauses.push('o.status=?');
    parameters.push(search.status);
  }
  const reference = search.reference?.trim() ?? '';
  if (reference.length > 0) { clauses.push('UPPER(reference)=?'); parameters.push(reference.toUpperCase()); }
  const base = `WITH entries AS (
      SELECT j.id AS journal_id,j.reference,j.posted_at,COALESCE((SELECT dc.new_effective_date FROM effective_date_corrections dc WHERE dc.dataset_id=j.dataset_id AND dc.journal_id=j.id ORDER BY dc.corrected_at DESC,dc.id DESC LIMIT 1),j.effective_date) AS effective_date,COALESCE((SELECT ta.new_description FROM transaction_amendments ta WHERE ta.dataset_id=j.dataset_id AND ta.journal_id=j.id ORDER BY ta.amended_at DESC,ta.id DESC LIMIT 1),j.description) AS description,j.status,jl.line_number,j.operation_id,la.id AS ledger_id,
        CASE la.normal_side WHEN 'credit' THEN jl.credit_minor_units-jl.debit_minor_units ELSE jl.debit_minor_units-jl.credit_minor_units END AS amount
      FROM ledger_accounts la JOIN journal_lines jl ON jl.dataset_id=la.dataset_id AND jl.ledger_account_id=la.id JOIN journals j ON j.dataset_id=jl.dataset_id AND j.id=jl.journal_id
      WHERE la.dataset_id=? AND la.customer_account_id=?
    ), ordered AS (
      SELECT *,SUM(CASE WHEN status='posted' THEN amount ELSE 0 END) OVER (ORDER BY effective_date,posted_at,reference,line_number ROWS UNBOUNDED PRECEDING) AS running FROM entries
    )`;
  const where = clauses.join(' AND ');
  const total = int(one(database, `${base} SELECT COUNT(*) AS count FROM ordered o WHERE ${where}`, ...parameters), 'count');
  const order = search.order === 'oldest' ? 'effective_date ASC,posted_at ASC,reference ASC,line_number ASC' : 'effective_date DESC,posted_at DESC,reference DESC,line_number DESC';
  const items = all(database, `${base} SELECT o.*,op.operation_kind,r.receipt_number,
      (SELECT group_concat(COALESCE(a2.account_number,g2.code),', ') FROM journal_lines l2 JOIN ledger_accounts g2 ON g2.dataset_id=l2.dataset_id AND g2.id=l2.ledger_account_id
        LEFT JOIN accounts a2 ON a2.dataset_id=g2.dataset_id AND a2.id=g2.customer_account_id WHERE l2.dataset_id=? AND l2.journal_id=o.journal_id AND l2.ledger_account_id<>o.ledger_id) AS counterparty
    FROM ordered o LEFT JOIN operations op ON op.dataset_id=? AND op.id=o.operation_id LEFT JOIN operation_receipts r ON r.dataset_id=op.dataset_id AND r.operation_id=op.id
    WHERE ${where} ORDER BY ${order} LIMIT ? OFFSET ?`, datasetId, accountId, datasetId, datasetId, ...parameters.slice(2), search.limit, search.offset).map((row) => ({
    journalId: str(row, 'journal_id'), reference: str(row, 'reference'), postedAt: str(row, 'posted_at'), effectiveDate: str(row, 'effective_date'), description: str(row, 'description'),
    status: str(row, 'status'), lineNumber: int(row, 'line_number'), amountMinorUnits: int(row, 'amount'), runningBalanceMinorUnits: int(row, 'running'),
    counterparty: optionalStr(row, 'counterparty'), operationKind: optionalStr(row, 'operation_kind'), receiptNumber: optionalStr(row, 'receipt_number'),
  }));
  return { items, total, offset: search.offset, limit: search.limit };
}

/** Months with ledger activity for an account, newest first. */
export function statementPeriods(database: SqlDatabase, datasetId: string, accountId: string): string[] {
  return all(database, `SELECT DISTINCT substr(j.effective_date,1,7) AS period FROM ledger_accounts la JOIN journal_lines jl ON jl.dataset_id=la.dataset_id AND jl.ledger_account_id=la.id
    JOIN journals j ON j.dataset_id=jl.dataset_id AND j.id=jl.journal_id WHERE la.dataset_id=? AND la.customer_account_id=? ORDER BY period DESC`, datasetId, accountId).map((row) => str(row, 'period'));
}

export interface StatementData {
  institutionName: string;
  account: AccountRow;
  period: string;
  periodStart: string;
  periodEndExclusive: string;
  openingMinorUnits: number;
  closingMinorUnits: number;
  creditsMinorUnits: number;
  debitsMinorUnits: number;
  entries: { reference: string; date: string; description: string; amountMinorUnits: number }[];
}

function nextMonth(period: string): string {
  const year = Number(period.slice(0, 4));
  const month = Number(period.slice(5, 7));
  return month === 12 ? `${year + 1}-01-01` : `${year}-${String(month + 1).padStart(2, '0')}-01`;
}

/** Posted activity for one calendar month; rejects more than 10,000 lines instead of returning a partial statement. */
export function statementData(database: SqlDatabase, datasetId: string, accountId: string, period: string, instant?: string): StatementData | undefined {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/u.test(period)) return undefined;
  const account = one(database, `SELECT ${ACCOUNT_SELECT} ${accountFrom(instant)} WHERE a.dataset_id=? AND a.id=?`, datasetId, accountId);
  if (account === undefined) return undefined;
  const periodStart = `${period}-01`;
  const periodEndExclusive = nextMonth(period);
  const amount = `CASE la.normal_side WHEN 'credit' THEN jl.credit_minor_units-jl.debit_minor_units ELSE jl.debit_minor_units-jl.credit_minor_units END`;
  const joins = `FROM ledger_accounts la JOIN journal_lines jl ON jl.dataset_id=la.dataset_id AND jl.ledger_account_id=la.id JOIN journals j ON j.dataset_id=jl.dataset_id AND j.id=jl.journal_id
    WHERE la.dataset_id=? AND la.customer_account_id=? AND j.status='posted'`;
  const opening = optionalInt(one(database, `SELECT SUM(${amount}) AS total ${joins} AND j.effective_date<?`, datasetId, accountId, periodStart), 'total') ?? 0;
  const entries = all(database, `SELECT j.reference,j.effective_date,COALESCE((SELECT ta.new_description FROM transaction_amendments ta WHERE ta.dataset_id=j.dataset_id AND ta.journal_id=j.id ORDER BY ta.amended_at DESC,ta.id DESC LIMIT 1),j.description) AS description,${amount} AS amount ${joins} AND j.effective_date>=? AND j.effective_date<? ORDER BY j.effective_date,j.posted_at,j.reference,jl.line_number LIMIT 10001`,
    datasetId, accountId, periodStart, periodEndExclusive).map((row) => ({ reference: str(row, 'reference'), date: str(row, 'effective_date'), description: str(row, 'description'), amountMinorUnits: int(row, 'amount') }));
  if (entries.length > 10_000) throw new RangeError('Statement exceeds the supported limit of 10,000 journal lines. No partial statement was generated.');
  const credits = entries.filter((entry) => entry.amountMinorUnits > 0).reduce((total, entry) => total + entry.amountMinorUnits, 0);
  const debits = entries.filter((entry) => entry.amountMinorUnits < 0).reduce((total, entry) => total - entry.amountMinorUnits, 0);
  if (![opening,credits,debits,opening + credits - debits].every(Number.isSafeInteger)) throw new RangeError('Statement totals exceed exact integer monetary bounds.');
  return {
    institutionName: datasetClock(database, datasetId).institutionName, account: accountRow(account), period, periodStart, periodEndExclusive,
    openingMinorUnits: opening, closingMinorUnits: opening + credits - debits, creditsMinorUnits: credits, debitsMinorUnits: debits, entries,
  };
}

/** Renders a generated PDF statement for a period. It is a derived view, not an issued document version. */
export async function renderGeneratedStatement(statement: StatementData, generatedAt: string): Promise<DocumentArtifact> {
  return renderStatementPdf({
    institutionName: statement.institutionName, ownerName: statement.account.ownerName, memberNumber: statement.account.memberNumber, accountNumber: statement.account.accountNumber,
    currency: statement.account.currency, currencyExponent: statement.account.exponent, periodStart: statement.periodStart, periodEndExclusive: statement.periodEndExclusive,
    asOf: generatedAt, openingBalanceMinor: statement.openingMinorUnits,
    entries: statement.entries.map((entry) => ({ reference: entry.reference, date: entry.date, description: entry.description, amountMinor: entry.amountMinorUnits })),
  });
}

/** Exports posted and reversed ledger lines of an account as CSV, with spreadsheet formula protection. */
export function transactionsCsv(account: AccountRow, rows: readonly TransactionRow[]): DocumentArtifact {
  return renderCsv({
    displayName: `${account.accountNumber}-transactions.csv`,
    columns: ['member_number', 'account_number', 'currency', 'effective_date', 'reference', 'description', 'status', 'signed_minor_units', 'running_balance_minor_units', 'counterparty', 'receipt_number'],
    rows: rows.map((row) => [account.memberNumber, account.accountNumber, account.currency, row.effectiveDate, row.reference, row.description, row.status, row.amountMinorUnits, row.runningBalanceMinorUnits, row.counterparty ?? '', row.receiptNumber ?? '']),
  });
}

export interface DocumentRow {
  versionId: string;
  documentId: string;
  documentType: string;
  displayName: string;
  version: number;
  mediaType: string;
  digest: string;
  byteLength: number;
  issuedAt: string;
  periodStart: string | null;
  periodEnd: string | null;
  pageCount: number | null;
  status: string;
  accountId: string | null;
  ownerPartyId: string;
}

const DOCUMENT_SELECT = `SELECT v.id AS version_id,d.id AS document_id,d.document_type,d.display_name,v.version,v.media_type,v.digest,b.byte_length,v.issued_at,v.period_start,v.period_end,v.page_count,v.status,d.account_id,d.owner_party_id
  FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest`;

function documentRow(row: Row): DocumentRow {
  return {
    versionId: str(row, 'version_id'), documentId: str(row, 'document_id'), documentType: str(row, 'document_type'), displayName: str(row, 'display_name'), version: int(row, 'version'),
    mediaType: str(row, 'media_type'), digest: str(row, 'digest'), byteLength: int(row, 'byte_length'), issuedAt: str(row, 'issued_at'), periodStart: optionalStr(row, 'period_start'),
    periodEnd: optionalStr(row, 'period_end'), pageCount: optionalInt(row, 'page_count'), status: str(row, 'status'), accountId: optionalStr(row, 'account_id'), ownerPartyId: str(row, 'owner_party_id'),
  };
}

export interface DocumentListRow extends DocumentRow {
  memberId: string;
  memberNumber: string;
  ownerName: string;
  accountNumber: string | null;
}

export interface DocumentSearch extends PageQuery {
  /** Member or account number prefix, owner name or file name fragment. */
  query?: string;
  documentType?: string;
  memberId?: string;
  accountId?: string;
  sort?: string;
  direction?: SortDirection;
}

const DOCUMENT_SORTS: Readonly<Record<string, string>> = { issued: 'v.issued_at', type: 'd.document_type', member: 'm.member_number', account: 'a.account_number', name: 'd.display_name COLLATE NOCASE' };

/** Stored document versions with the member who owns them, newest first by default. */
export function searchDocuments(database: SqlDatabase, datasetId: string, search: DocumentSearch, reader?: NoteReader): PageResult<DocumentListRow> {
  const clauses = ['d.dataset_id=?', documentReadFilter(database,datasetId,reader)];
  const parameters: SQLInputValue[] = [datasetId];
  const query = search.query?.trim() ?? '';
  if (query.length > 0) {
    const prefix = `${likeFragment(query.toUpperCase())}%`;
    const contains = `%${likeFragment(query)}%`;
    clauses.push("(m.member_number LIKE ? ESCAPE '\\' OR a.account_number LIKE ? ESCAPE '\\' OR p.display_name LIKE ? ESCAPE '\\' OR d.display_name LIKE ? ESCAPE '\\')");
    parameters.push(prefix, prefix, contains, contains);
  }
  if (search.documentType !== undefined && search.documentType !== '') { clauses.push('d.document_type=?'); parameters.push(search.documentType); }
  if (search.memberId !== undefined) { clauses.push('m.id=?'); parameters.push(search.memberId); }
  if (search.accountId !== undefined) { clauses.push('d.account_id=?'); parameters.push(search.accountId); }
  const sort = DOCUMENT_SORTS[search.sort ?? 'issued'] ?? 'v.issued_at';
  const direction = search.sort === undefined ? 'DESC' : search.direction === 'desc' ? 'DESC' : 'ASC';
  return paged(database,
    `v.id AS version_id,d.id AS document_id,d.document_type,d.display_name,v.version,v.media_type,v.digest,b.byte_length,v.issued_at,v.period_start,v.period_end,v.page_count,v.status,
      d.account_id,d.owner_party_id,m.id AS member_id,m.member_number,p.display_name AS owner_name,a.account_number`,
    `FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      JOIN members m ON m.dataset_id=d.dataset_id AND m.id=(SELECT m2.id FROM members m2 WHERE m2.dataset_id=d.dataset_id AND m2.party_id=d.owner_party_id ORDER BY m2.status='merged',m2.member_number LIMIT 1)
      JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id LEFT JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id`,
    clauses.join(' AND '), parameters, `${sort} ${direction},v.id ${direction}`, search,
    (row) => ({ ...documentRow(row), memberId: str(row, 'member_id'), memberNumber: str(row, 'member_number'), ownerName: str(row, 'owner_name'), accountNumber: optionalStr(row, 'account_number') }));
}

/** Document types stored in a dataset, for filter choices. */
export function documentTypes(database: SqlDatabase, datasetId: string): string[] {
  return all(database, 'SELECT DISTINCT document_type FROM documents WHERE dataset_id=? ORDER BY document_type', datasetId).map((row) => str(row, 'document_type'));
}

export function accountDocuments(database: SqlDatabase, datasetId: string, accountId: string, reader?: NoteReader): DocumentRow[] {
  return all(database, `${DOCUMENT_SELECT} WHERE d.dataset_id=? AND d.account_id=? AND ${documentReadFilter(database,datasetId,reader)} ORDER BY COALESCE(v.period_start,'') DESC,v.issued_at DESC,v.id LIMIT 500`, datasetId, accountId).map(documentRow);
}

/** Stored immutable document bytes and their metadata, or undefined for an unknown version. */
export function documentContent(database: SqlDatabase, datasetId: string, versionId: string, reader?: NoteReader): (DocumentRow & { bytes: Uint8Array }) | undefined {
  const row = one(database, `${DOCUMENT_SELECT} WHERE v.dataset_id=? AND v.id=? AND ${documentReadFilter(database,datasetId,reader)}`, datasetId, versionId);
  if (row === undefined) return undefined;
  const blob = one(database, 'SELECT bytes FROM document_blobs WHERE dataset_id=? AND digest=?', datasetId, str(row, 'digest'));
  const bytes = blob?.bytes;
  if (!(bytes instanceof Uint8Array)) throw new Error('Stored document bytes are missing.');
  if(bytes.byteLength!==int(row,'byte_length') || sha256(bytes)!==str(row,'digest')) throw new Error('Stored document bytes failed their integrity check.');
  return { ...documentRow(row), bytes: Uint8Array.from(bytes) };
}

export interface ActivityRow {
  sequence: number;
  occurredAt: string;
  kind: string;
  resourceKind: string;
  resourceId: string;
  summary: string;
  actor: ActorRef | null;
  operationId: string | null;
  operationStatus: string | null;
  receiptNumber: string | null;
}

export interface ActivitySearch extends PageQuery {
  memberId?: string;
  accountId?: string;
  caseId?: string;
  kind?: string;
  actorId?: string;
  query?: string;
}

/** Committed business events, newest first, optionally scoped to a member, account or case and their child records. */
export function listActivity(database: SqlDatabase, datasetId: string, search: ActivitySearch): PageResult<ActivityRow> {
  const clauses = ['e.dataset_id=?'];
  const parameters: SQLInputValue[] = [datasetId];
  if (search.memberId !== undefined) { clauses.push(activityScopePredicate('member')); parameters.push(search.memberId); }
  if (search.accountId !== undefined) { clauses.push(activityScopePredicate('account')); parameters.push(search.accountId); }
  if (search.caseId !== undefined) {
    clauses.push(activityScopePredicate('case'));
    parameters.push(search.caseId);
  }
  if (search.kind !== undefined && search.kind !== '') { clauses.push('e.kind=?'); parameters.push(search.kind); }
  if (search.actorId !== undefined && search.actorId !== '') { clauses.push('e.actor_id=?'); parameters.push(search.actorId); }
  const query = search.query?.trim() ?? '';
  if (query.length > 0) { clauses.push("(e.summary LIKE ? ESCAPE '\\' OR r.receipt_number LIKE ? ESCAPE '\\')"); parameters.push(`%${likeFragment(query)}%`, `${likeFragment(query.toUpperCase())}%`); }
  return paged(database, 'e.sequence,e.occurred_at,e.kind,e.resource_kind,e.resource_id,e.summary,e.actor_id,a.actor_number,a.display_name,o.id AS operation_id,o.status AS operation_status,r.receipt_number',
    `FROM business_events e LEFT JOIN actors a ON a.dataset_id=e.dataset_id AND a.id=e.actor_id LEFT JOIN operations o ON o.dataset_id=e.dataset_id AND o.id=e.operation_id
      LEFT JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id`,
    clauses.join(' AND '), parameters, 'e.sequence DESC', search, (row) => ({
      sequence: int(row, 'sequence'), occurredAt: str(row, 'occurred_at'), kind: str(row, 'kind'), resourceKind: str(row, 'resource_kind'), resourceId: str(row, 'resource_id'),
      summary: str(row, 'summary'), actor: optionalStr(row, 'actor_number') === null ? null : { id: str(row, 'actor_id'), actorNumber: str(row, 'actor_number'), displayName: str(row, 'display_name') },
      operationId: optionalStr(row, 'operation_id'), operationStatus: optionalStr(row, 'operation_status'), receiptNumber: optionalStr(row, 'receipt_number'),
    }));
}

export function receiptByNumber(database: SqlDatabase, datasetId: string, receiptNumber: string): Receipt | undefined {
  return loadReceipt(database, datasetId, { receiptNumber });
}

/**
 * Receipt of the operation committed under an idempotency key, or undefined when none committed.
 * Keys are unique per dataset, matching `executeCommand`, so this settles an attempt whose response was lost.
 */
export function receiptByIdempotencyKey(database: SqlDatabase, datasetId: string, idempotencyKey: string): Receipt | undefined {
  const operation = one(database, 'SELECT id FROM operations WHERE dataset_id=? AND idempotency_key=?', datasetId, idempotencyKey);
  return operation === undefined ? undefined : loadReceipt(database, datasetId, { operationId: str(operation, 'id') });
}

const CASE_SELECT = `c.id,c.case_number,c.member_id,m.member_number,p.display_name AS member_name,c.account_id,a.account_number,c.queue_id,q.code AS queue_code,q.name AS queue_name,
  c.assigned_actor_id,ac.display_name AS assigned_name,c.state,c.priority,c.category,c.summary,c.opened_at,c.due_at,c.version`;
const CASE_FROM = `FROM cases c JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
  LEFT JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id
  LEFT JOIN actors ac ON ac.dataset_id=c.dataset_id AND ac.id=c.assigned_actor_id`;

function caseRow(row: Row, now: string): CaseRow {
  const state = str(row, 'state');
  const category = str(row, 'category');
  return {
    id: str(row, 'id'), caseNumber: str(row, 'case_number'), memberId: str(row, 'member_id'), memberNumber: str(row, 'member_number'), memberName: str(row, 'member_name'),
    accountId: optionalStr(row, 'account_id'), accountNumber: optionalStr(row, 'account_number'), queueId: str(row, 'queue_id'), queueCode: str(row, 'queue_code'), queueName: str(row, 'queue_name'),
    assignedActorId: optionalStr(row, 'assigned_actor_id'), assignedName: optionalStr(row, 'assigned_name'), state, priority: str(row, 'priority'), category,
    categoryLabel: CASE_CATEGORIES[category] ?? category, summary: str(row, 'summary'), openedAt: str(row, 'opened_at'), dueAt: str(row, 'due_at'),
    overdue: !['resolved', 'closed'].includes(state) && str(row, 'due_at') < now, version: int(row, 'version'),
  };
}

const CASE_SORTS: Readonly<Record<string, string>> = {
  caseNumber: 'c.case_number', due: 'c.due_at', opened: 'c.opened_at', state: 'c.state', priority: "CASE c.priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END",
  member: 'm.member_number', queue: 'q.code', assignee: 'ac.display_name COLLATE NOCASE',
};

export interface CaseSearch extends PageQuery {
  /** Restricts results to these case identities. */
  ids?: readonly string[];
  memberId?: string;
  accountId?: string;
  states?: readonly string[];
  queueId?: string;
  /** Cases in any of these queues. */
  queueIds?: readonly string[];
  assignedActorId?: string | null;
  priority?: string;
  overdue?: boolean;
  query?: string;
  sort?: string;
  direction?: SortDirection;
}

/** Case selection criteria without paging or ordering. */
export type CaseFilter = Omit<CaseSearch, keyof PageQuery | 'sort' | 'direction'>;

export function searchCases(database: SqlDatabase, datasetId: string, search: CaseSearch, instant?: string): PageResult<CaseRow> {
  if (search.sort !== undefined && !Object.hasOwn(CASE_SORTS, search.sort)) throw new RangeError('Unsupported case sort.');
  if (search.direction !== undefined && !['asc', 'desc'].includes(search.direction)) throw new RangeError('Unsupported sort direction.');
  const now = new Date(instant ?? datasetClock(database, datasetId).asOf).toISOString();
  const { clauses, parameters } = caseCriteria(datasetId, search, now);
  const sort = CASE_SORTS[search.sort ?? 'due'] ?? 'c.due_at';
  const direction = search.direction === 'desc' ? 'DESC' : 'ASC';
  return paged(database, CASE_SELECT, CASE_FROM, clauses.join(' AND '), parameters, `${sort} ${direction},c.id ${direction}`, search, (row) => caseRow(row, now));
}

export type CaseGroupBy = 'state' | 'queue' | 'priority' | 'assignee';

export interface CaseGroup {
  key: string;
  label: string;
  count: number;
  /** Criteria that select exactly this group's cases when combined with the grouped search. */
  filter: CaseFilter;
}

const CASE_STATE_LABELS: Readonly<Record<CaseState, string>> = {
  open: 'Open', 'pending-customer': 'Pending customer', 'pending-internal': 'Pending internal', resolved: 'Resolved', closed: 'Closed', reopened: 'Reopened',
};
const PRIORITY_LABELS: Readonly<Record<string, string>> = { urgent: 'Urgent', high: 'High', normal: 'Normal', low: 'Low' };

/** Counts of matching cases per group, in a stable business order. The counts add up to the search total. */
export function caseGroupCounts(database: SqlDatabase, datasetId: string, search: CaseFilter, groupBy: CaseGroupBy, instant?: string): CaseGroup[] {
  const now = new Date(instant ?? datasetClock(database, datasetId).asOf).toISOString();
  const { clauses, parameters } = caseCriteria(datasetId, search, now);
  const where = clauses.join(' AND ');
  const counted = (key: string, extra = ''): Row[] => all(database, `SELECT ${key} AS key${extra},COUNT(*) AS count ${CASE_FROM} WHERE ${where} GROUP BY ${key}`, ...parameters);
  switch (groupBy) {
    case 'state': {
      const counts = new Map(counted('c.state').map((row) => [str(row, 'key'), int(row, 'count')]));
      return Object.entries(CASE_STATE_LABELS).flatMap(([state, label]) => { const count = counts.get(state); return count === undefined ? [] : [{ key: state, label, count, filter: { states: [state] } }]; });
    }
    case 'priority': {
      const counts = new Map(counted('c.priority').map((row) => [str(row, 'key'), int(row, 'count')]));
      return Object.entries(PRIORITY_LABELS).flatMap(([priority, label]) => { const count = counts.get(priority); return count === undefined ? [] : [{ key: priority, label, count, filter: { priority } }]; });
    }
    case 'queue':
      return counted('c.queue_id', ',q.code,q.name').sort((a, b) => str(a, 'code').localeCompare(str(b, 'code')))
        .map((row) => ({ key: str(row, 'key'), label: `${str(row, 'code')} · ${str(row, 'name')}`, count: int(row, 'count'), filter: { queueIds: [str(row, 'key')] } }));
    case 'assignee':
      return counted('c.assigned_actor_id', ',ac.display_name').sort((a, b) => (optionalStr(a, 'display_name') ?? '').localeCompare(optionalStr(b, 'display_name') ?? ''))
        .map((row) => {
          const actorId = optionalStr(row, 'key');
          return { key: actorId ?? 'unassigned', label: optionalStr(row, 'display_name') ?? 'Unassigned', count: int(row, 'count'), filter: { assignedActorId: actorId } };
        });
  }
}

function caseCriteria(datasetId: string, search: CaseFilter, now: string): { clauses: string[]; parameters: SQLInputValue[] } {
  const clauses = ['c.dataset_id=?'];
  const parameters: SQLInputValue[] = [datasetId];
  if (search.memberId !== undefined) { clauses.push('c.member_id=?'); parameters.push(search.memberId); }
  if (search.accountId !== undefined) { clauses.push('c.account_id=?'); parameters.push(search.accountId); }
  idClause('c.id', search.ids, clauses, parameters);
  if (search.states !== undefined && search.states.length > 0) { clauses.push(`c.state IN (${search.states.map(() => '?').join(',')})`); parameters.push(...search.states); }
  if (search.queueId !== undefined && search.queueId !== '') { clauses.push('c.queue_id=?'); parameters.push(search.queueId); }
  if (search.queueIds !== undefined && search.queueIds.length > 0) { clauses.push(`c.queue_id IN (${search.queueIds.map(() => '?').join(',')})`); parameters.push(...search.queueIds); }
  if (search.assignedActorId === null) clauses.push('c.assigned_actor_id IS NULL');
  else if (search.assignedActorId !== undefined && search.assignedActorId !== '') { clauses.push('c.assigned_actor_id=?'); parameters.push(search.assignedActorId); }
  if (search.priority !== undefined && search.priority !== '') { clauses.push('c.priority=?'); parameters.push(search.priority); }
  if (search.overdue === true) { clauses.push("c.state NOT IN ('resolved','closed') AND c.due_at<?"); parameters.push(now); }
  const query = search.query?.trim() ?? '';
  if (query.length > 0) {
    clauses.push("(c.case_number LIKE ? ESCAPE '\\' OR m.member_number LIKE ? ESCAPE '\\' OR c.summary LIKE ? ESCAPE '\\' OR p.display_name LIKE ? ESCAPE '\\')");
    parameters.push(`${likeFragment(query.toUpperCase())}%`, `${likeFragment(query.toUpperCase())}%`, `%${likeFragment(query)}%`, `%${likeFragment(query)}%`);
  }
  return { clauses, parameters };
}

export interface CaseDetail {
  case: CaseRow;
  memberStatus: string;
  events: { sequence: number; state: string; occurredAt: string; actor: ActorRef | null; detail: string }[];
  /** Newest first; restricted notes appear only for a reader authorized to see them. */
  notes: NoteRow[];
  restrictedNotesWithheld: number;
  dependencies: { id: string; kind: string; referenceId: string; state: string; dueAt: string | null }[];
  documents: (DocumentRow & { purpose: string; visibility: string })[];
  sla: { state: string; startsAt: string; endsAt: string | null; reason: string | null }[];
  allowedTransitions: CaseState[];
}

export function caseDetail(database: SqlDatabase, datasetId: string, caseId: string, reader?: NoteReader): CaseDetail | undefined {
  const now = new Date(reader?.now ?? datasetClock(database, datasetId).asOf).toISOString();
  const row = one(database, `SELECT ${CASE_SELECT},m.status AS member_status ${CASE_FROM} WHERE c.dataset_id=? AND c.id=?`, datasetId, caseId);
  if (row === undefined) return undefined;
  const record = caseRow(row, now);
  const { notes, withheld } = noteRows(database, datasetId, 'case_notes', 'case_id', caseId, reader);
  return {
    case: record, memberStatus: str(row, 'member_status'),
    events: all(database, 'SELECT e.sequence,e.state,e.occurred_at,e.detail,e.actor_id,a.actor_number,a.display_name FROM case_events e LEFT JOIN actors a ON a.dataset_id=e.dataset_id AND a.id=e.actor_id WHERE e.dataset_id=? AND e.case_id=? ORDER BY e.sequence', datasetId, caseId)
      .map((event) => ({ sequence: int(event, 'sequence'), state: str(event, 'state'), occurredAt: str(event, 'occurred_at'), detail: str(event, 'detail'),
        actor: optionalStr(event, 'actor_number') === null ? null : { id: str(event, 'actor_id'), actorNumber: str(event, 'actor_number'), displayName: str(event, 'display_name') } })),
    notes,
    restrictedNotesWithheld: withheld,
    dependencies: all(database, 'SELECT id,kind,reference_id,state,due_at FROM case_dependencies WHERE dataset_id=? AND case_id=? ORDER BY id', datasetId, caseId)
      .map((dependency) => ({ id: str(dependency, 'id'), kind: str(dependency, 'kind'), referenceId: str(dependency, 'reference_id'), state: str(dependency, 'state'), dueAt: optionalStr(dependency, 'due_at') })),
    documents: all(database, `${DOCUMENT_SELECT.replace('SELECT ', 'SELECT cd.purpose,cd.visibility,')} JOIN case_documents cd ON cd.dataset_id=v.dataset_id AND cd.document_version_id=v.id WHERE cd.dataset_id=? AND cd.case_id=?${readsRestrictedNotes(database, datasetId, reader) ? '' : " AND cd.visibility='general'"} ORDER BY v.issued_at,v.id`, datasetId, caseId)
      .map((document) => ({ ...documentRow(document), purpose: str(document, 'purpose'), visibility: str(document, 'visibility') })),
    sla: all(database, 'SELECT state,starts_at,ends_at,reason FROM sla_intervals WHERE dataset_id=? AND case_id=? ORDER BY starts_at,rowid', datasetId, caseId)
      .map((interval) => ({ state: str(interval, 'state'), startsAt: str(interval, 'starts_at'), endsAt: optionalStr(interval, 'ends_at'), reason: optionalStr(interval, 'reason') })),
    allowedTransitions: [...CASE_TRANSITIONS[record.state as CaseState]],
  };
}

export interface ReferenceData {
  queues: { id: string; code: string; name: string; visibility: string }[];
  caseWorkers: ActorRef[];
  products: { id: string; code: string; name: string; currency: string }[];
  caseCategories: { code: string; label: string }[];
  currencies: { code: string; exponent: number; name: string }[];
}

export function referenceData(database: SqlDatabase, datasetId: string, institutionId: string, instant?: string): ReferenceData {
  const now = new Date(instant ?? datasetClock(database, datasetId).asOf).toISOString();
  const caseWorkers = all(database, "SELECT id FROM actors WHERE dataset_id=? AND status='active' ORDER BY display_name", datasetId)
    .map((row) => str(row, 'id'))
    .filter((actorId) => { const permissions = actorPermissions(database, datasetId, institutionId, actorId, now); return permissions.has('case.manage') || permissions.has('supervise'); })
    .flatMap((actorId) => { const actor = actorRef(database, datasetId, actorId); return actor === undefined ? [] : [actor]; });
  return {
    queues: all(database, 'SELECT id,code,name,visibility FROM queues WHERE dataset_id=? ORDER BY code', datasetId).map((row) => ({ id: str(row, 'id'), code: str(row, 'code'), name: str(row, 'name'), visibility: str(row, 'visibility') })),
    caseWorkers,
    products: all(database, "SELECT id,code,name,currency FROM products WHERE dataset_id=? AND family='deposit' AND status='active' AND code NOT LIKE '%-TERM' ORDER BY currency,code", datasetId)
      .map((row) => ({ id: str(row, 'id'), code: str(row, 'code'), name: str(row, 'name'), currency: str(row, 'currency') })),
    caseCategories: Object.entries(CASE_CATEGORIES).map(([code, label]) => ({ code, label })),
    currencies: all(database, 'SELECT code,exponent,name FROM currencies ORDER BY code').map((row) => ({ code: str(row, 'code'), exponent: int(row, 'exponent'), name: str(row, 'name') })),
  };
}

export interface RecordStamp {
  version: number;
  /** Changes when any displayed fact of the record changes, including child rows and balances. */
  stamp: string;
}

export interface StampRequest {
  members?: readonly string[];
  accounts?: readonly string[];
  cases?: readonly string[];
}

export type StampResponse = Record<'members' | 'accounts' | 'cases', Record<string, RecordStamp | null>>;

/** Current version and change stamp of each requested record, for record-scoped stale detection. */
export function recordStamps(database: SqlDatabase, datasetId: string, request: StampRequest): StampResponse {
  const total = (request.members?.length ?? 0) + (request.accounts?.length ?? 0) + (request.cases?.length ?? 0);
  if (total > 300) throw new RangeError('At most 300 records can be checked at once.');
  const result: StampResponse = { members: {}, accounts: {}, cases: {} };
  for (const id of request.members ?? []) {
    const row = one(database, `SELECT m.version,(SELECT COUNT(*) FROM member_notes n WHERE n.dataset_id=m.dataset_id AND n.member_id=m.id) AS notes,
      (SELECT COUNT(*) FROM accounts a WHERE a.dataset_id=m.dataset_id AND a.member_id=m.id) AS accounts,
      (SELECT COUNT(*)||':'||COALESCE(SUM(c.version),0) FROM cases c WHERE c.dataset_id=m.dataset_id AND c.member_id=m.id) AS cases FROM members m WHERE m.dataset_id=? AND m.id=?`, datasetId, id);
    result.members[id] = row === undefined ? null : { version: int(row, 'version'), stamp: `${int(row, 'version')}:${int(row, 'notes')}:${int(row, 'accounts')}:${str(row, 'cases')}` };
  }
  for (const id of request.accounts ?? []) {
    const row = one(database, `SELECT a.version,a.status,b.posted_balance_minor_units,b.available_balance_minor_units,
      (SELECT COUNT(*) FROM journal_lines jl JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id WHERE la.dataset_id=a.dataset_id AND la.customer_account_id=a.id) AS lines
      FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.id=?`, datasetId, id);
    result.accounts[id] = row === undefined ? null : { version: int(row, 'version'), stamp: `${int(row, 'version')}:${str(row, 'status')}:${int(row, 'posted_balance_minor_units')}:${int(row, 'available_balance_minor_units')}:${int(row, 'lines')}` };
  }
  for (const id of request.cases ?? []) {
    const row = one(database, `SELECT c.version,(SELECT COUNT(*) FROM case_events e WHERE e.dataset_id=c.dataset_id AND e.case_id=c.id) AS events,
      (SELECT COUNT(*) FROM case_notes n WHERE n.dataset_id=c.dataset_id AND n.case_id=c.id) AS notes FROM cases c WHERE c.dataset_id=? AND c.id=?`, datasetId, id);
    result.cases[id] = row === undefined ? null : { version: int(row, 'version'), stamp: `${int(row, 'version')}:${int(row, 'events')}:${int(row, 'notes')}` };
  }
  return result;
}
