import { createHash, randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';

import {
  all,
  actorPermissions,
  canonicalJson,
  cleanText,
  int,
  isIsoDate,
  localDate,
  loadReceipt,
  nextNumber,
  one,
  optionalInt,
  optionalStr,
  reject,
  run,
  str,
  textProblem,
  zonedInstant,
  type Row,
} from './core.js';
import type { ApplyEnvironment, Environment, Preparation, Prepared } from './commands.js';
import { commandIntentDigest } from './command-intent.js';
import { canReadDocument } from './document-access.js';
import { approvalPrepared, requireApproval, rowFingerprint } from './finance-support.js';
import { MAX_DOCUMENT_BYTES, validateDocumentMedia } from './media-validation.js';
import { CAPABILITY_GRANTS } from './rules.js';
import { isMaintenanceRequestedCommand } from './servicing-types.js';
import type {
  AddressReconcileCommand,
  AddressDestinationUpdateCommand,
  CaseCloseCommand,
  CaseEscalateCommand,
  CaseInformationRequestCommand,
  CaseReopenCommand,
  CaseSubjectCorrectCommand,
  CommunicationPreferenceUpdateCommand,
  CommunicationDeliveryUpdateCommand,
  CommunicationSendCommand,
  ConsentDeliveryRecordCommand,
  ConsentWithdrawCommand,
  CustomerExportCreateCommand,
  DocumentAnnotationUpdateCommand,
  DocumentBundleRedactCommand,
  DocumentIndexCommand,
  DocumentMetadataUpdateCommand,
  DocumentSignatureCollectCommand,
  IdentityVerifyCommand,
  IdentityEvidenceRegisterCommand,
  LegalNameUpdateCommand,
  MaintenanceDraftAmendCommand,
  MaintenanceDraftSaveCommand,
  MaintenanceRequestSubmitCommand,
  MaintenanceRequestReviewCommand,
  MaintenanceRequestProcessCommand,
  MaintenanceRequestWithdrawCommand,
  MaintenanceRequestedCommand,
  PreferredNameUpdateCommand,
  RetentionHoldApplyCommand,
  ServicingCommand,
} from './servicing-types.js';
import type { AddressInput, Rejection, ResourceKind } from './types.js';

const ISO_INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/u;
const RESOURCE = (kind: string): ResourceKind => kind as ResourceKind;
const SIGNATURE_CHANNELS = new Set(['authorized-local-signature', 'in-person-signature', 'secure-message-signature']);
const TRUSTED_SIGNATURE_SOURCE = 'trusted-local-signature-response';
const DOCUMENT_SOURCES = new Set(['approved-local-source', 'approved-local-upload', 'approved-local-scan', TRUSTED_SIGNATURE_SOURCE]);
const ACCESS_SENSITIVE_DOCUMENT_TYPES = new Set(['customer-record-export', 'signature-evidence', 'identity-document', 'passport', 'drivers-license', 'national-id', 'state-id', 'redacted-evidence']);
const LEGAL_NAME_AUTHORITY_EVIDENCE_KINDS = new Set(['court-order', 'marriage-certificate', 'divorce-decree', 'passport', 'drivers-license', 'national-id', 'state-id']);
const EXPORT_DOCUMENT_TYPES = Object.freeze({
  statements: ['account-statement'],
  disclosures: ['delivery-disclosure'],
  'servicing-notices': ['servicing-notice'],
  'servicing-evidence': ['redacted-evidence'],
  'signed-evidence': ['signature-evidence'],
} satisfies Readonly<Record<string, readonly string[]>>);

function review(consequences: string[]): Prepared['review'] {
  return { amount: null, exponent: null, description: null, accounts: [], consequences };
}

function problem(value: string, label: string, maximum: number): string | null {
  return textProblem(value, label, maximum);
}

function validateInstant(value: string, label: string): string | null {
  return ISO_INSTANT.test(value) && !Number.isNaN(Date.parse(value)) ? null : `${label} must be an ISO UTC instant.`;
}

function normalizeInstant(value: string): string {
  return new Date(value).toISOString();
}

function validBytes(value: Uint8Array, label = 'Document'): string | null {
  return value instanceof Uint8Array && value.byteLength > 0 && value.byteLength <= MAX_DOCUMENT_BYTES ? null : `${label} bytes must contain 1 to ${MAX_DOCUMENT_BYTES} bytes.`;
}

function digest(bytes: Uint8Array): string {
  return createHash('sha256').update(bytes).digest('hex');
}

function verifyStoredBlob(env: Environment, contentDigest: string, mediaType: string, byteLength: number): Preparation | null {
  const row = one(env.database, 'SELECT media_type,byte_length,bytes FROM document_blobs WHERE dataset_id=? AND digest=?', env.datasetId, contentDigest);
  if (row === undefined) return null;
  const stored = row.bytes;
  if (!(stored instanceof Uint8Array) || stored.byteLength !== int(row, 'byte_length') || digest(stored) !== contentDigest) throw new Error(`Stored document blob ${contentDigest} failed its integrity check.`);
  if (str(row, 'media_type') !== mediaType || int(row, 'byte_length') !== byteLength) return reject('validation', 'The content digest is already stored with different media metadata.');
  return null;
}

function staleVersion(label: string, expected: number, current: number): Preparation {
  return reject('stale_version', `This ${label} changed after you opened it (version ${expected} is now ${current}).`, { currentVersion: current });
}

function nextUpdatedAt(current: string, now: string): string {
  if (now > current) return now;
  const parsed = Date.parse(current);
  if (!Number.isFinite(parsed)) throw new Error('Stored update time is invalid.');
  return new Date(parsed + 1).toISOString();
}

function normalizedExtractedText(value: string): string {
  return value.normalize('NFC').replaceAll(/\s+/gu, ' ').trim();
}

/** Extracts visible PDF text through bounded Poppler execution and fails closed for unsupported or malformed content. */
function extractPdfText(env: Environment, version: Row): string | null {
  if (str(version, 'media_type') !== 'application/pdf') return null;
  const contentDigest = str(version, 'digest');
  const blob = one(env.database, 'SELECT byte_length,bytes FROM document_blobs WHERE dataset_id=? AND digest=?', env.datasetId, contentDigest);
  const bytes = blob?.bytes;
  if (!(bytes instanceof Uint8Array) || bytes.byteLength !== int(blob, 'byte_length') || digest(bytes) !== contentDigest) throw new Error(`Document version ${str(version, 'id')} failed its integrity check.`);
  const extracted = spawnSync('pdftotext', ['-', '-'], { input: Buffer.from(bytes), encoding: 'utf8', timeout: 5_000, maxBuffer: 4 * 1024 * 1024 });
  if (extracted.error !== undefined || extracted.status !== 0 || extracted.signal !== null) return null;
  const text = extracted.stdout.normalize('NFC').replaceAll('\r\n', '\n').replaceAll('\r', '\n').trim();
  return text.length === 0 ? null : text;
}

function documentVersionIsVisible(env: Environment, versionId: string): boolean {
  return canReadDocument(env.database, env.datasetId, versionId, { institutionId: env.institutionId, actorId: env.actorId, now: env.now });
}

function memberProtectedValues(env: Environment, memberId: string): string[] {
  const member = memberRow(env, memberId); if (member === undefined) return [];
  const partyId = str(member, 'party_id');
  const values = [str(member, 'member_number')];
  for (const row of all(env.database, 'SELECT legal_given,legal_family,birth_date FROM people WHERE dataset_id=? AND party_id=?', env.datasetId, partyId)) {
    values.push(str(row, 'legal_given'), str(row, 'legal_family'), str(row, 'birth_date'));
  }
  for (const row of all(env.database, 'SELECT value FROM contact_points WHERE dataset_id=? AND party_id=? AND valid_to IS NULL', env.datasetId, partyId)) values.push(str(row, 'value'));
  for (const row of all(env.database, `SELECT a.line1,a.line2,a.city,a.region,a.postal_code FROM party_addresses pa JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
    WHERE pa.dataset_id=? AND pa.party_id=? AND pa.valid_to IS NULL`, env.datasetId, partyId)) {
    values.push(str(row, 'line1'), optionalStr(row, 'line2') ?? '', str(row, 'city'), str(row, 'region'), str(row, 'postal_code'));
  }
  for (const row of all(env.database, 'SELECT account_number FROM accounts WHERE dataset_id=? AND member_id=?', env.datasetId, memberId)) values.push(str(row, 'account_number'));
  return [...new Set(values.map(normalizedExtractedText).filter(value => value.length >= 3))];
}

function excerptHasProtectedValue(excerpt: string, protectedValues: readonly string[], denyPatterns: readonly RegExp[]): boolean {
  const folded = excerpt.toLocaleLowerCase('en-US');
  return protectedValues.some(value => folded.includes(value.toLocaleLowerCase('en-US'))) || denyPatterns.some(pattern => pattern.test(excerpt));
}

interface SignatureResponseEvidence {
  documentVersionId: string;
  documentDigest: string;
  signerPartyIds: string[];
  channel: string;
  response: 'signed' | 'declined' | 'expired';
}

function parseSignatureResponseEvidence(text: string): SignatureResponseEvidence | null {
  const values = new Map<string, string[]>();
  for (const rawLine of text.split('\n')) {
    const line = rawLine.trim();
    if (line.length === 0) continue;
    const match = /^(Document version|Document SHA-256|Signer party|Channel|Response): ([^\r\n]+)$/u.exec(line);
    if (match === null) return null;
    const key = match[1]; const value = match[2];
    if (key === undefined || value === undefined || value.trim() !== value) return null;
    const existing = values.get(key) ?? []; existing.push(value); values.set(key, existing);
  }
  const oneValue = (key: string): string | null => {
    const found = values.get(key); return found?.length === 1 ? found[0] ?? null : null;
  };
  const documentVersionId = oneValue('Document version'); const documentDigest = oneValue('Document SHA-256');
  const signerPartyIds = values.get('Signer party') ?? []; const channel = oneValue('Channel'); const response = oneValue('Response');
  if (documentVersionId === null || documentDigest === null || signerPartyIds.length === 0 || channel === null || !['signed', 'declined', 'expired'].includes(response ?? '')) return null;
  if (values.size !== 5 || new Set(signerPartyIds).size !== signerPartyIds.length) return null;
  return { documentVersionId, documentDigest, signerPartyIds, channel, response: response as SignatureResponseEvidence['response'] };
}

function trustedSignatureEvidenceProvenance(env: Environment, versionId: string): boolean {
  const row = one(env.database, `SELECT o.actor_id,o.occurred_at FROM business_events e
    JOIN operations o ON o.dataset_id=e.dataset_id AND o.id=e.operation_id
    JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id
    WHERE e.dataset_id=? AND e.resource_kind='document-version' AND e.resource_id=? AND o.operation_kind='document.index'
      AND json_extract(r.result_json,'$.source')=? ORDER BY o.occurred_at DESC,o.id LIMIT 1`, env.datasetId, versionId, TRUSTED_SIGNATURE_SOURCE);
  if (row === undefined) return false;
  return actorPermissions(env.database, env.datasetId, env.institutionId, str(row, 'actor_id'), str(row, 'occurred_at')).has('signature.response.record');
}

function resourceEvent(apply: ApplyEnvironment, kind: string, id: string, summary: string): void {
  apply.event({ kind: RESOURCE(kind), id }, summary);
}

function prepared(
  businessReference: string,
  result: Record<string, unknown>,
  consequences: string[],
  apply: (environment: ApplyEnvironment) => void,
): Prepared {
  return { kind: 'prepared', businessReference, result, review: review(consequences), apply };
}

function memberRow(env: Environment, memberId: string): Row | undefined {
  return one(env.database, `SELECT m.id,m.member_number,m.party_id,m.status,m.version,p.display_name,p.kind
    FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
    WHERE m.dataset_id=? AND m.id=?`, env.datasetId, memberId);
}

function accountRow(env: Environment, accountId: string): Row | undefined {
  return one(env.database, `SELECT a.id,a.account_number,a.member_id,a.currency,a.status,a.version,m.party_id,m.member_number
    FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
    WHERE a.dataset_id=? AND a.id=?`, env.datasetId, accountId);
}

function evidenceRow(env: Environment, evidenceId: string): Row | undefined {
  return one(env.database, `SELECT e.id,e.party_id,e.status,e.issued_at,e.expires_at,e.kind,e.reference
    FROM identity_evidence e WHERE e.dataset_id=? AND e.id=?`, env.datasetId, evidenceId);
}

function evidenceDateProblem(env: Environment, evidence: Row): string | null {
  const today = localDate(env.now, env.timeZone);
  const issuedAt = str(evidence, 'issued_at');
  const expiresAt = optionalStr(evidence, 'expires_at');
  if (!isIsoDate(issuedAt) || issuedAt > today) return 'Evidence issue date is invalid or in the future.';
  if (expiresAt !== null && (!isIsoDate(expiresAt) || expiresAt <= issuedAt || expiresAt < today)) return 'Evidence expiry is invalid or has passed.';
  return null;
}

function documentVersion(env: Environment, versionId: string): Row | undefined {
  if (!documentVersionIsVisible(env, versionId)) return undefined;
  return one(env.database, `SELECT v.id,v.document_id,v.version,v.digest,v.media_type,v.issued_at,v.period_start,v.period_end,v.page_count,v.status,
      d.owner_party_id,d.account_id,d.document_type,d.display_name,d.retention_class
    FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
    WHERE v.dataset_id=? AND v.id=?`, env.datasetId, versionId);
}

function documentVersionBytesAreValid(env: Environment, version: Row): boolean {
  const contentDigest = str(version, 'digest');
  const blob = one(env.database, 'SELECT media_type,byte_length,bytes FROM document_blobs WHERE dataset_id=? AND digest=?', env.datasetId, contentDigest);
  const bytes = blob?.bytes;
  return bytes instanceof Uint8Array && str(blob, 'media_type') === str(version, 'media_type') && int(blob, 'byte_length') === bytes.byteLength
    && digest(bytes) === contentDigest && validateDocumentMedia(bytes, str(version, 'media_type')).valid;
}

export type ConsentState = 'granted' | 'withdrawn' | 'expired' | 'pending';

/** Resolves account-specific consent before the party-wide fallback for the same purpose and channel. */
export function effectiveConsentState(
  env: Pick<Environment, 'database' | 'datasetId' | 'now'>,
  partyId: string,
  accountId: string | null,
  purpose: string,
  channel: string,
): ConsentState | null {
  const consent = one(env.database, `SELECT state FROM consents WHERE dataset_id=? AND party_id=? AND purpose=? AND channel=?
    AND effective_at<=? AND (account_id IS ? OR account_id IS NULL)
    ORDER BY CASE WHEN account_id IS ? THEN 0 ELSE 1 END,effective_at DESC,
      CASE state WHEN 'withdrawn' THEN 0 ELSE 1 END,id DESC LIMIT 1`,
  env.datasetId, partyId, purpose, channel, env.now, accountId, accountId);
  if (consent === undefined) return null;
  const state = str(consent, 'state');
  if (state === 'granted' || state === 'withdrawn' || state === 'expired' || state === 'pending') return state;
  throw new Error(`Stored consent state ${state} is invalid.`);
}

function memberParty(env: Environment, memberId: string): string | undefined {
  return optionalStr(memberRow(env, memberId), 'party_id') ?? undefined;
}

function addressProblems(address: AddressInput): string | null {
  const fields: [string, string, number][] = [
    ['line1', address.line1, 80], ['city', address.city, 60], ['region', address.region, 40], ['postalCode', address.postalCode, 12], ['country', address.country, 2],
  ];
  for (const [field, value, max] of fields) {
    const issue = problem(value, `Address ${field}`, max);
    if (issue !== null) return issue;
  }
  if (!/^[A-Z]{2}$/u.test(cleanText(address.country))) return 'Address country must be a two-letter ISO code.';
  return null;
}

function normalizedAddress(address: AddressInput): AddressInput {
  return { line1: cleanText(address.line1), line2: address.line2 === null ? null : cleanText(address.line2) || null,
    city: cleanText(address.city), region: cleanText(address.region), postalCode: cleanText(address.postalCode).toUpperCase(), country: cleanText(address.country).toUpperCase() };
}

function prepareIdentityEvidenceRegister(env: Environment, command: IdentityEvidenceRegisterCommand): Preparation {
  const member = memberRow(env, command.memberId); if (member === undefined) return reject('not_found', 'The member does not exist.');
  const version = documentVersion(env, command.documentVersionId); if (version === undefined) return reject('not_found', 'The identity document version does not exist.');
  if (str(version, 'owner_party_id') !== str(member, 'party_id')) return reject('ownership_mismatch', 'The identity document is outside the member scope.');
  const versionType = str(version, 'document_type');
  if (!['identity-document', 'passport', 'drivers-license', 'national-id', 'state-id'].includes(versionType)
    || !['current', 'signed'].includes(str(version, 'status')) || versionType !== 'identity-document' && versionType !== command.evidenceKind) {
    return reject('ineligible', 'Identity evidence requires a current approved identity-document version.');
  }
  const today = localDate(env.now, env.timeZone);
  if (!isIsoDate(command.issuedAt) || !isIsoDate(command.expiresAt) || command.issuedAt > today || command.expiresAt <= command.issuedAt) return reject('validation', 'Evidence issue and expiry dates must be ordered ISO dates, and issue date cannot be future.');
  if (command.expiresAt < today) return reject('ineligible', 'Expired identity evidence cannot be registered for verification.');
  const reference = cleanText(command.reference); const referenceIssue = problem(reference, 'Evidence reference', 120); if (referenceIssue !== null) return reject('validation', referenceIssue, { field: 'reference' });
  const immutableReference = canonicalJson({ reference, documentVersionId: command.documentVersionId, digest: str(version, 'digest') });
  const duplicate = one(env.database, 'SELECT id FROM identity_evidence WHERE dataset_id=? AND party_id=? AND reference=?', env.datasetId, str(member, 'party_id'), immutableReference);
  if (duplicate !== undefined) return { kind: 'unchanged', message: `Identity evidence is already registered as ${str(duplicate, 'id')}.` };
  const evidenceId = command.evidenceId ?? `identity-evidence-${randomUUID()}`;
  if (one(env.database, 'SELECT id FROM identity_evidence WHERE dataset_id=? AND id=?', env.datasetId, evidenceId) !== undefined) return reject('ineligible', 'An identity evidence record with this identity already exists.');
  return prepared(evidenceId, { evidenceId, memberId: command.memberId, documentVersionId: command.documentVersionId, digest: str(version, 'digest'), status: 'unverified' },
    ['Registers one immutable member-bound identity document for a separate verification decision.'], (apply) => {
      run(apply.database, `INSERT INTO identity_evidence (dataset_id,id,party_id,kind,status,issued_at,expires_at,reference) VALUES (?,?,?,?,?,?,?,?)`,
        apply.datasetId, evidenceId, str(member, 'party_id'), command.evidenceKind, 'unverified', command.issuedAt, command.expiresAt, immutableReference);
      resourceEvent(apply, 'identity-evidence', evidenceId, `Identity evidence registered from immutable document ${command.documentVersionId}.`);
    });
}

function prepareIdentityVerify(env: Environment, command: IdentityVerifyCommand): Preparation {
  const member = memberRow(env, command.memberId);
  const evidence = evidenceRow(env, command.evidenceId);
  if (member === undefined) return reject('not_found', 'The member does not exist.');
  if (evidence === undefined) return reject('not_found', 'The identity evidence does not exist.');
  if (str(member, 'party_id') !== str(evidence, 'party_id')) return reject('ownership_mismatch', 'Identity evidence belongs to another member.');
  if (evidence.status !== 'unverified') return reject('ineligible', 'Only unverified identity evidence can be verified.');
  const dateProblem = evidenceDateProblem(env, evidence); if (dateProblem !== null) return reject('ineligible', dateProblem);
  const reference = str(evidence, 'reference');
  let binding: unknown; try { binding = JSON.parse(reference); } catch { return reject('ineligible', 'Identity evidence is not bound to an immutable document version.'); }
  if (binding === null || typeof binding !== 'object' || Array.isArray(binding)) return reject('ineligible', 'Registered identity document binding is malformed.');
  const documentVersionId = (binding as Record<string, unknown>).documentVersionId; const expectedDigest = (binding as Record<string, unknown>).digest;
  if (typeof documentVersionId !== 'string' || typeof expectedDigest !== 'string') return reject('ineligible', 'Registered identity document binding is incomplete.');
  const version = documentVersion(env, documentVersionId);
  if (version === undefined || str(version, 'owner_party_id') !== str(member, 'party_id') || str(version, 'digest') !== expectedDigest
    || !['current', 'signed'].includes(str(version, 'status')) || !['identity-document', 'passport', 'drivers-license', 'national-id', 'state-id'].includes(str(version, 'document_type'))) {
    return reject('ineligible', 'Registered identity evidence no longer matches its immutable member-bound document.');
  }
  if (!documentVersionBytesAreValid(env, version)) {
    return reject('ineligible', 'Registered identity evidence bytes are missing, changed, or unreadable.');
  }
  const method = cleanText(command.method);
  if (method.length === 0) return reject('validation', 'Verification method is required.', { field: 'method' });
  return prepared(command.evidenceId, { memberId: command.memberId, evidenceId: command.evidenceId, status: 'verified', method }, ['Marks the supplied evidence verified.'], (apply) => {
    run(apply.database, 'UPDATE identity_evidence SET status=? WHERE dataset_id=? AND id=?', 'verified', apply.datasetId, command.evidenceId);
    resourceEvent(apply, 'identity-evidence', command.evidenceId, `Identity evidence ${command.evidenceId} verified for member ${str(member, 'member_number')}.`);
  });
}

function prepareLegalNameUpdate(env: Environment, command: LegalNameUpdateCommand): Preparation {
  const member = memberRow(env, command.memberId);
  const evidence = evidenceRow(env, command.evidenceId);
  if (member === undefined) return reject('not_found', 'The member does not exist.');
  if (command.expectedVersion !== int(member, 'version')) return reject('stale_version', `This member changed after you opened it (version ${command.expectedVersion} is now ${int(member, 'version')}).`, { currentVersion: int(member, 'version') });
  if (evidence === undefined) return reject('not_found', 'The authority evidence does not exist.');
  if (str(member, 'party_id') !== str(evidence, 'party_id') || evidence.status !== 'verified') return reject('ineligible', 'A verified authority document for this member is required.');
  const dateProblem = evidenceDateProblem(env, evidence); if (dateProblem !== null) return reject('ineligible', dateProblem);
  if (!LEGAL_NAME_AUTHORITY_EVIDENCE_KINDS.has(str(evidence, 'kind'))) return reject('ineligible', 'The verified evidence is not legal-name authority.');
  const given = cleanText(command.legalGiven); const family = cleanText(command.legalFamily);
  const givenProblem = problem(given, 'Legal given name', 60); const familyProblem = problem(family, 'Legal family name', 60);
  if (givenProblem !== null) return reject('validation', givenProblem, { field: 'legalGiven' });
  if (familyProblem !== null) return reject('validation', familyProblem, { field: 'legalFamily' });
  const current = one(env.database, 'SELECT legal_given,legal_family FROM people WHERE dataset_id=? AND party_id=?', env.datasetId, str(member, 'party_id'));
  if (current !== undefined && str(current, 'legal_given') === given && str(current, 'legal_family') === family) return { kind: 'unchanged', message: 'The legal name already matches.' };
  const approval = requireApproval(env, command, command.approvalId); if (approval !== null) return approval;
  const history = one(env.database, `SELECT id FROM name_history WHERE dataset_id=? AND party_id=? AND kind='legal' AND valid_to IS NULL ORDER BY valid_from DESC LIMIT 1`, env.datasetId, str(member, 'party_id'));
  const historyId = `name-history-${randomUUID()}`;
  return approvalPrepared(prepared(str(member, 'member_number'), { memberId: command.memberId, displayName: `${given} ${family}`, historyId }, ['Changes the legal name and closes the prior legal-name interval.'], (apply) => {
    const partyId = str(member, 'party_id');
    run(apply.database, 'UPDATE people SET legal_given=?,legal_family=? WHERE dataset_id=? AND party_id=?', given, family, apply.datasetId, partyId);
    run(apply.database, 'UPDATE parties SET display_name=? WHERE dataset_id=? AND id=?', `${given} ${family}`, apply.datasetId, partyId);
    run(apply.database, 'UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.memberId);
    if (history !== undefined) run(apply.database, 'UPDATE name_history SET valid_to=? WHERE dataset_id=? AND id=? AND valid_to IS NULL', apply.now, apply.datasetId, str(history, 'id'));
    run(apply.database, `INSERT INTO name_history (dataset_id,id,party_id,kind,given_name,family_name,valid_from,valid_to,evidence_id)
      VALUES (?,?,?,?,?,?,?,NULL,?)`, apply.datasetId, historyId, partyId, 'legal', given, family, apply.now, command.evidenceId);
    resourceEvent(apply, 'name-history', historyId, `Legal name amended to ${given} ${family}.`);
    resourceEvent(apply, 'member', command.memberId, `Member ${str(member, 'member_number')} legal name amended.`);
  }), command.approvalId);
}

function preparePreferredNameUpdate(env: Environment, command: PreferredNameUpdateCommand): Preparation {
  const member = memberRow(env, command.memberId);
  if (member === undefined) return reject('not_found', 'The member does not exist.');
  if (command.expectedVersion !== int(member, 'version')) return reject('stale_version', `This member changed after you opened it (version ${command.expectedVersion} is now ${int(member, 'version')}).`, { currentVersion: int(member, 'version') });
  if (!['servicing', 'all', 'communications'].includes(cleanText(command.communicationScope))) return reject('validation', 'Communication scope must be servicing, communications or all.', { field: 'communicationScope' });
  const preferred = command.preferredName === null ? null : cleanText(command.preferredName);
  if (preferred !== null) {
    const issue = problem(preferred, 'Preferred name', 60);
    if (issue !== null) return reject('validation', issue, { field: 'preferredName' });
  }
  const scope = preferred === null ? null : cleanText(command.communicationScope) as 'servicing' | 'communications' | 'all';
  const row = one(env.database, 'SELECT preferred_name,preferred_name_scope FROM people WHERE dataset_id=? AND party_id=?', env.datasetId, str(member, 'party_id'));
  if ((optionalStr(row, 'preferred_name') ?? null) === preferred && (optionalStr(row, 'preferred_name_scope') ?? null) === scope) return { kind: 'unchanged', message: 'The preferred name and communication scope already match.' };
  return prepared(str(member, 'member_number'), { memberId: command.memberId, preferredName: preferred, communicationScope: command.communicationScope }, ['Records a preferred name independently of the legal name.'], (apply) => {
    run(apply.database, 'UPDATE people SET preferred_name=?,preferred_name_scope=? WHERE dataset_id=? AND party_id=?', preferred, scope, apply.datasetId, str(member, 'party_id'));
    run(apply.database, 'UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.memberId);
    resourceEvent(apply, 'member', command.memberId, `Preferred name updated for member ${str(member, 'member_number')}.`);
  });
}

function prepareDocumentIndex(env: Environment, command: DocumentIndexCommand): Preparation {
  const member = memberRow(env, command.memberId);
  if (member === undefined) return reject('not_found', 'The member does not exist.');
  if (str(member, 'party_id') !== command.ownerPartyId) return reject('ownership_mismatch', 'Owner party is not the member party.');
  if (command.accountId !== null) {
    const account = accountRow(env, command.accountId);
    if (account === undefined) return reject('not_found', 'The account does not exist.');
    if (str(account, 'member_id') !== command.memberId) return reject('ownership_mismatch', 'Account is not owned by the member.');
  }
  const bytesIssue = validBytes(command.bytes, 'Source document'); if (bytesIssue !== null) return reject('validation', bytesIssue, { field: 'bytes' });
  const typeIssue = problem(command.documentType, 'Document type', 80); if (typeIssue !== null) return reject('validation', typeIssue, { field: 'documentType' });
  const nameIssue = problem(command.displayName, 'Display name', 200); if (nameIssue !== null) return reject('validation', nameIssue, { field: 'displayName' });
  const retentionIssue = problem(command.retentionClass, 'Retention class', 80); if (retentionIssue !== null) return reject('validation', retentionIssue, { field: 'retentionClass' });
  const source = command.source === undefined ? '' : cleanText(command.source);
  if (!DOCUMENT_SOURCES.has(source)) return reject('validation', 'Document source is not an approved local input.', { field: 'source' });
  if (cleanText(command.documentType) === 'signature-evidence' && source !== TRUSTED_SIGNATURE_SOURCE) return reject('not_authorized', 'Signature response evidence must originate from the trusted local signature callback.', { field: 'source' });
  if (source === TRUSTED_SIGNATURE_SOURCE) {
    const permissions = actorPermissions(env.database, env.datasetId, env.institutionId, env.actorId, env.now);
    if (cleanText(command.documentType) !== 'signature-evidence' || env.principalKind !== 'system' || !permissions.has('signature.response.record')) {
      return reject('not_authorized', 'Only the authorized local signature callback can index signature response evidence.', { field: 'source' });
    }
  }
  if (command.pageCount !== undefined && command.pageCount !== null && command.pageCount < 1) return reject('validation', 'Page count must be a positive integer.', { field: 'pageCount' });
  const calculatedDigest = digest(command.bytes);
  if (command.sourceDigest !== undefined && command.sourceDigest !== calculatedDigest) return reject('validation', 'Source digest does not match the supplied bytes.', { field: 'sourceDigest' });
  const documentId = command.documentId ?? `document-${randomUUID()}`;
  const versionId = `${documentId}-v1`;
  const mediaType = cleanText(command.mediaType ?? 'application/pdf').toLowerCase();
  const mediaValidation = validateDocumentMedia(command.bytes, mediaType);
  if (!mediaValidation.valid) return reject('validation', mediaValidation.message, { field: 'mediaType' });
  if (mediaValidation.pageCount !== undefined && command.pageCount !== undefined && command.pageCount !== null && command.pageCount !== mediaValidation.pageCount) {
    return reject('validation', 'Page count does not match the decoded document.', { field: 'pageCount' });
  }
  const pageCount = mediaValidation.pageCount ?? command.pageCount ?? null;
  const blobIssue = verifyStoredBlob(env, calculatedDigest, mediaType, command.bytes.byteLength); if (blobIssue !== null) return blobIssue;
  const alreadyIndexed = one(env.database, `SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
    WHERE v.dataset_id=? AND v.digest=? AND d.owner_party_id=?`, env.datasetId, calculatedDigest, command.ownerPartyId);
  if (alreadyIndexed !== undefined) return { kind: 'unchanged', message: `Exact document bytes are already indexed as ${str(alreadyIndexed, 'id')}.` };
  if (one(env.database, 'SELECT id FROM documents WHERE dataset_id=? AND id=?', env.datasetId, documentId) !== undefined) return reject('ineligible', 'A document with this identity is already indexed.');
  return prepared(documentId, { documentId, versionId, ownerPartyId: command.ownerPartyId, digest: calculatedDigest, mediaType, source }, ['Stores immutable bytes by SHA-256 and indexes one owner-bound version.'], (apply) => {
    run(apply.database, 'INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,?,?,?)', apply.datasetId, calculatedDigest, mediaType, command.bytes.byteLength, command.bytes);
    run(apply.database, `INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
      VALUES (?,?,?,?,?,?,?,?)`, apply.datasetId, documentId, command.ownerPartyId, command.accountId, cleanText(command.documentType), cleanText(command.displayName), cleanText(command.retentionClass), apply.now);
    run(apply.database, `INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,?,?,?,?,NULL,NULL,?,'current')`, apply.datasetId, versionId, documentId, 1, calculatedDigest, mediaType, apply.now, pageCount);
    resourceEvent(apply, 'document', documentId, `Document ${documentId} indexed for member ${command.memberId}.`);
    resourceEvent(apply, 'document-version', versionId, `Document version ${versionId} stored with digest ${calculatedDigest}.`);
  });
}

function prepareDocumentRedact(env: Environment, command: DocumentBundleRedactCommand): Preparation {
  if (command.sourceVersionIds.length === 0 || command.sourceVersionIds.length > 20) return reject('validation', 'Redaction requires 1 to 20 source versions.', { field: 'sourceVersionIds' });
  if (new Set(command.sourceVersionIds).size !== command.sourceVersionIds.length) return reject('validation', 'Source document versions must be unique.', { field: 'sourceVersionIds' });
  const partyId = memberParty(env, command.memberId); if (partyId === undefined) return reject('not_found', 'The member does not exist.');
  const sources = new Map<string, Row>(); const extracted = new Map<string, string>();
  for (const versionId of command.sourceVersionIds) {
    const source = documentVersion(env, versionId);
    if (source === undefined) return reject('not_found', `Source document version ${versionId} does not exist.`);
    if (str(source, 'owner_party_id') !== partyId) return reject('ownership_mismatch', 'Every source version must belong to the member.');
    const text = extractPdfText(env, source); if (text === null) return reject('ineligible', `Source document version ${versionId} cannot be safely text-extracted for redaction.`);
    sources.set(versionId, source); extracted.set(versionId, normalizedExtractedText(text));
  }
  const policy = one(env.database, 'SELECT id,name,version,rules_json FROM policy_versions WHERE dataset_id=? AND id=? AND effective_at<=?', env.datasetId, command.redactionPolicyVersionId, env.now);
  if (policy === undefined) return reject('not_found', 'The redaction policy version does not exist.');
  let redaction: Record<string, unknown>;
  try {
    const rules: unknown = JSON.parse(str(policy, 'rules_json')); const value = rules !== null && typeof rules === 'object' ? (rules as Record<string, unknown>).redaction : undefined;
    if (value === null || typeof value !== 'object' || Array.isArray(value) || (value as Record<string, unknown>).enabled !== true) return reject('ineligible', 'The selected policy does not authorize redaction.');
    redaction = value as Record<string, unknown>;
  } catch { return reject('ineligible', 'The selected redaction policy is malformed.'); }
  const configuredMaxExcerpts = redaction.maxExcerpts; const configuredMaxChars = redaction.maxExcerptChars;
  if (typeof configuredMaxExcerpts !== 'number' || !Number.isSafeInteger(configuredMaxExcerpts) || configuredMaxExcerpts < 1 || configuredMaxExcerpts > 100
    || typeof configuredMaxChars !== 'number' || !Number.isSafeInteger(configuredMaxChars) || configuredMaxChars < 20 || configuredMaxChars > 1000
    || !Array.isArray(redaction.denyPatterns) || !redaction.denyPatterns.every((value): value is string => typeof value === 'string')) {
    return reject('ineligible', 'The selected redaction policy is missing valid bounded excerpt and deny-pattern rules.');
  }
  const maxExcerpts = configuredMaxExcerpts; const maxExcerptChars = configuredMaxChars;
  if (command.approvedExcerpts.length === 0 || command.approvedExcerpts.length > maxExcerpts) return reject('validation', `Approved excerpts must contain 1 to ${maxExcerpts} entries.`, { field: 'approvedExcerpts' });
  const configuredPatterns = redaction.denyPatterns;
  let denyPatterns: RegExp[];
  try {
    denyPatterns = [/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/u, /\b\d{3}-\d{2}-\d{4}\b/u, /\b(?:secret|password|token|protected[- ]identifier)\b/iu,
      ...configuredPatterns.map(pattern => new RegExp(pattern, 'iu'))];
  } catch { return reject('ineligible', 'The selected redaction policy contains an invalid deny pattern.'); }
  const protectedValues = memberProtectedValues(env, command.memberId); const approvedLines: string[] = []; const coveredSources = new Set<string>(); const excerptKeys = new Set<string>();
  for (const excerpt of command.approvedExcerpts) {
    if (!sources.has(excerpt.sourceVersionId)) return reject('validation', `Approved excerpt source ${excerpt.sourceVersionId} is outside the source inventory.`, { field: 'approvedExcerpts' });
    const text = normalizedExtractedText(excerpt.text); const issue = problem(text, 'Approved excerpt', maxExcerptChars); if (issue !== null) return reject('validation', issue, { field: 'approvedExcerpts' });
    const sourceText = extracted.get(excerpt.sourceVersionId); if (sourceText === undefined || !sourceText.includes(text)) return reject('ineligible', `Approved excerpt is not exact visible text from source ${excerpt.sourceVersionId}.`);
    if (excerptHasProtectedValue(text, protectedValues, denyPatterns)) return reject('ineligible', 'An approved excerpt still contains a protected value under the selected policy.');
    const key = `${excerpt.sourceVersionId}\u0000${text}`; if (excerptKeys.has(key)) return reject('validation', 'Approved excerpts must be unique.', { field: 'approvedExcerpts' });
    excerptKeys.add(key); coveredSources.add(excerpt.sourceVersionId); approvedLines.push(`[${excerpt.sourceVersionId}] ${text}`);
  }
  if (command.sourceVersionIds.some(versionId => !coveredSources.has(versionId))) return reject('validation', 'Every source version must retain at least one approved excerpt.', { field: 'approvedExcerpts' });
  const recipientPurpose = cleanText(command.recipientPurpose);
  const purposeIssue = problem(recipientPurpose, 'Recipient purpose', 120); if (purposeIssue !== null) return reject('validation', purposeIssue, { field: 'recipientPurpose' });
  const displayName = cleanText(command.displayName ?? 'approved-redacted-evidence.txt'); const displayNameIssue = problem(displayName, 'Display name', 200); if (displayNameIssue !== null) return reject('validation', displayNameIssue, { field: 'displayName' });
  const outputBytes = Buffer.from([
    env.institutionName,
    'Scoped redacted document bundle',
    `Recipient purpose: ${recipientPurpose}`,
    `Source versions: ${command.sourceVersionIds.join(', ')}`,
    `Redaction policy: ${str(policy, 'name')} ${str(policy, 'version')} (${command.redactionPolicyVersionId})`,
    '',
    ...approvedLines,
  ].join('\n'), 'utf8');
  const redactedDigest = digest(outputBytes);
  if ([...sources.values()].some(source => str(source, 'digest') === redactedDigest)) return reject('ineligible', 'A redacted derivative must have a distinct digest.');
  if (excerptHasProtectedValue(outputBytes.toString('utf8'), protectedValues, denyPatterns)) return reject('ineligible', 'The generated derivative failed its protected-value verification.');
  const blobIssue = verifyStoredBlob(env, redactedDigest, 'text/plain', outputBytes.byteLength); if (blobIssue !== null) return blobIssue;
  const documentId = `document-redacted-${randomUUID()}`; const versionId = `${documentId}-v1`; const derivationId = `document-derivation-${randomUUID()}`;
  return prepared(documentId, { sourceVersionIds: command.sourceVersionIds, derivativeVersionId: versionId, digest: redactedDigest, mediaType: 'text/plain', approvedExcerptCount: approvedLines.length, protectedIdentifierPresent: false }, ['Creates a safe text derivative from exact source excerpts with explicit lineage and policy.'], (apply) => {
    const source = sources.get(command.sourceVersionIds[0] ?? ''); if (source === undefined) throw new Error('Missing redaction source.');
    run(apply.database, 'INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,?,?,?)', apply.datasetId, redactedDigest, 'text/plain', outputBytes.byteLength, outputBytes);
    run(apply.database, `INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
      VALUES (?,?,?,?,?,?,?,?)`, apply.datasetId, documentId, partyId, optionalStr(source, 'account_id'), 'redacted-evidence', displayName, 'servicing-7y', apply.now);
    run(apply.database, `INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,?,?,?,?,NULL,NULL,NULL,'redacted')`, apply.datasetId, versionId, documentId, 1, redactedDigest, 'text/plain', apply.now);
    for (const sourceVersionId of command.sourceVersionIds) run(apply.database, `INSERT INTO document_derivations (dataset_id,id,source_version_id,derivative_version_id,purpose,policy_version_id)
      VALUES (?,?,?,?,?,?)`, apply.datasetId, sourceVersionId === command.sourceVersionIds[0] ? derivationId : `document-derivation-${randomUUID()}`, sourceVersionId, versionId, 'redaction', command.redactionPolicyVersionId);
    resourceEvent(apply, 'document-version', versionId, `Redacted derivative ${versionId} created from ${command.sourceVersionIds.join(', ')}.`);
    resourceEvent(apply, 'document-derivation', derivationId, `Redaction lineage recorded under policy ${command.redactionPolicyVersionId}.`);
  });
}

function prepareSignatureCollect(env: Environment, command: DocumentSignatureCollectCommand): Preparation {
  const version = documentVersion(env, command.documentVersionId); if (version === undefined) return reject('not_found', 'The document version does not exist.');
  if (command.signerPartyIds.length === 0) return reject('validation', 'At least one signer is required.', { field: 'signerPartyIds' });
  if (new Set(command.signerPartyIds).size !== command.signerPartyIds.length) return reject('validation', 'Signer identities must be unique.', { field: 'signerPartyIds' });
  const channel = cleanText(command.channel); const channelIssue = problem(channel, 'Signature channel', 80); if (channelIssue !== null) return reject('validation', channelIssue, { field: 'channel' });
  if (!SIGNATURE_CHANNELS.has(channel)) return reject('validation', 'Signature channel is not approved for local collection.', { field: 'channel' });
  const evidenceReference = command.evidenceReference === undefined ? null : cleanText(command.evidenceReference);
  if (command.action === 'request' && evidenceReference !== null) return reject('validation', 'A signature request cannot claim response evidence.', { field: 'evidenceReference' });
  let responseEvidence: SignatureResponseEvidence | null = null;
  if (command.action !== 'request') {
    const permissions = actorPermissions(env.database, env.datasetId, env.institutionId, env.actorId, env.now);
    if (env.principalKind !== 'system' || !permissions.has('signature.response.record')) return reject('not_authorized', 'Only the authorized local signature callback can record a terminal response.');
    if (evidenceReference === null) return reject('validation', 'Signature response evidence is required.', { field: 'evidenceReference' });
    const evidenceIssue = problem(evidenceReference, 'Signature evidence reference', 200);
    if (evidenceIssue !== null) return reject('validation', evidenceIssue, { field: 'evidenceReference' });
    const evidence = documentVersion(env, evidenceReference);
    if (evidence === undefined) return reject('not_found', 'The signature evidence document version does not exist.');
    if (str(evidence, 'owner_party_id') !== str(version, 'owner_party_id')) return reject('ownership_mismatch', 'Signature evidence is outside the signed document owner scope.');
    if (str(evidence, 'document_type') !== 'signature-evidence' || str(evidence, 'status') === 'superseded') return reject('ineligible', 'A current signature-evidence document version is required.');
    if (!trustedSignatureEvidenceProvenance(env, evidenceReference)) return reject('not_authorized', 'Signature evidence lacks trusted callback provenance.');
    const responseEvidenceText = extractPdfText(env, evidence); if (responseEvidenceText === null) return reject('ineligible', 'Signature response evidence cannot be safely verified.');
    responseEvidence = parseSignatureResponseEvidence(responseEvidenceText);
    const expectedResponse = command.action === 'sign' ? 'signed' : command.action === 'decline' ? 'declined' : 'expired';
    if (responseEvidence === null || responseEvidence.documentVersionId !== command.documentVersionId || responseEvidence.documentDigest !== str(version, 'digest') || responseEvidence.channel !== channel || responseEvidence.response !== expectedResponse) {
      return reject('ineligible', 'Signature response evidence does not bind the exact document, digest, channel and response.');
    }
  }
  const existing: Row[] = [];
  for (const signer of command.signerPartyIds) {
    if (one(env.database, 'SELECT id FROM parties WHERE dataset_id=? AND id=?', env.datasetId, signer) === undefined) return reject('not_found', `Signer party ${signer} does not exist.`);
    const accountId = optionalStr(version, 'account_id');
    if (signer !== str(version, 'owner_party_id') && (accountId === null || one(env.database, `SELECT party_id FROM account_parties WHERE dataset_id=? AND account_id=? AND party_id=? AND role IN ('owner','joint-owner','signer') AND ends_at IS NULL`, env.datasetId, accountId, signer) === undefined)) {
      return reject('ownership_mismatch', 'Every signer must be an active owner or signer in the document account scope.');
    }
    const matches = all(env.database, 'SELECT id,status,requested_at FROM signatures WHERE dataset_id=? AND document_version_id=? AND signer_party_id=? ORDER BY requested_at,id', env.datasetId, command.documentVersionId, signer);
    if (command.action === 'request') {
      if (matches.length > 0) return reject('ineligible', 'A signature lifecycle already exists for one of the signers.');
    } else {
      const pending = matches.filter(row => str(row, 'status') === 'requested');
      if (pending.length !== 1) return reject('ineligible', 'Each signer must have exactly one pending signature request.');
      const pendingRow = pending[0] as Row;
      const request = one(env.database, `SELECT 1 AS matched FROM business_events e JOIN operations o ON o.dataset_id=e.dataset_id AND o.id=e.operation_id
        JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id
        WHERE e.dataset_id=? AND e.resource_kind='signature' AND e.resource_id=? AND o.operation_kind='document.signature.collect'
          AND json_extract(r.result_json,'$.state')='requested' AND json_extract(r.result_json,'$.documentVersionId')=?
          AND json_extract(r.result_json,'$.channel')=? AND EXISTS (SELECT 1 FROM json_each(r.result_json,'$.signerPartyIds') WHERE value=?) LIMIT 1`,
      env.datasetId, str(pendingRow, 'id'), command.documentVersionId, channel, signer);
      if (request === undefined) return reject('ineligible', 'The pending signature request has no exact approved-channel provenance.');
      existing.push(pendingRow);
    }
  }
  if (responseEvidence !== null && canonicalJson([...responseEvidence.signerPartyIds].sort()) !== canonicalJson([...command.signerPartyIds].sort())) return reject('ineligible', 'Signature response evidence does not bind the exact signer set.');
  const ids = command.action === 'request' ? command.signerPartyIds.map(() => `signature-${randomUUID()}`) : existing.map(row => str(row, 'id'));
  const state = command.action === 'request' ? 'requested' : command.action === 'sign' ? 'signed' : command.action === 'decline' ? 'declined' : 'expired';
  return prepared(command.documentVersionId, { signatureIds: ids, documentVersionId: command.documentVersionId, signerPartyIds: command.signerPartyIds, channel, state, evidenceReference }, [command.action === 'request' ? 'Creates pending signature requests without claiming a human response.' : `Records the verified ${state} response against the exact immutable document version and evidence.`], (apply) => {
    for (const [index, signer] of command.signerPartyIds.entries()) {
      const id = ids[index]; if (id === undefined) continue;
      if (command.action === 'request') {
        run(apply.database, `INSERT INTO signatures (dataset_id,id,document_version_id,signer_party_id,status,requested_at,signed_at,evidence_reference)
          VALUES (?,?,?,?,?,?,NULL,NULL)`, apply.datasetId, id, command.documentVersionId, signer, 'requested', apply.now);
      } else {
        run(apply.database, `UPDATE signatures SET status=?,signed_at=?,evidence_reference=? WHERE dataset_id=? AND id=? AND status='requested'`, state, state === 'signed' ? apply.now : null, evidenceReference, apply.datasetId, id);
      }
      resourceEvent(apply, 'signature', id, command.action === 'request'
        ? `Signature requested from ${signer} on ${command.documentVersionId} via ${channel}.`
        : `Signature response ${state} recorded for ${signer} on ${command.documentVersionId} via ${channel}; evidence ${evidenceReference}.`);
    }
    if (state === 'signed') run(apply.database, "UPDATE document_versions SET status='signed' WHERE dataset_id=? AND id=? AND status='current'", apply.datasetId, command.documentVersionId);
  });
}

function prepareConsentRecord(env: Environment, command: ConsentDeliveryRecordCommand): Preparation {
  const party = one(env.database, 'SELECT id FROM parties WHERE dataset_id=? AND id=?', env.datasetId, command.partyId); if (party === undefined) return reject('not_found', 'The party does not exist.');
  const accountId = command.accountId ?? null;
  if (accountId !== null) {
    const account = accountRow(env, accountId); if (account === undefined) return reject('not_found', 'The account does not exist.');
    if (str(account, 'party_id') !== command.partyId) return reject('ownership_mismatch', 'Account is not owned by the consenting party.');
  }
  const disclosure = documentVersion(env, command.disclosureVersionId); if (disclosure === undefined) return reject('not_found', 'The disclosure version does not exist.');
  if (str(disclosure, 'owner_party_id') !== command.partyId) return reject('ownership_mismatch', 'Disclosure is not addressed to the consenting party.');
  if ((optionalStr(disclosure, 'account_id') ?? null) !== accountId) return reject('ownership_mismatch', 'Disclosure account scope does not match the consent account scope.');
  const purpose = cleanText(command.purpose); const channel = cleanText(command.channel); const evidence = cleanText(command.evidence);
  if (problem(purpose, 'Consent purpose', 100) !== null || problem(channel, 'Consent channel', 80) !== null) return reject('validation', 'Consent purpose and channel are required.');
  const evidenceIssue = problem(evidence, 'Consent evidence', 500); if (evidenceIssue !== null) return reject('validation', evidenceIssue, { field: 'evidence' });
  const latest = one(env.database, `SELECT state FROM consents WHERE dataset_id=? AND party_id=? AND account_id IS ? AND purpose=? AND channel=? AND effective_at<=?
    ORDER BY effective_at DESC,CASE state WHEN 'withdrawn' THEN 0 ELSE 1 END,id DESC LIMIT 1`, env.datasetId, command.partyId, accountId, purpose, channel, env.now);
  if (latest !== undefined && str(latest, 'state') === 'granted') return { kind: 'unchanged', message: 'An active consent already exists for this account scope, purpose and channel.' };
  const id = `consent-${randomUUID()}`;
  return prepared(id, { consentId: id, partyId: command.partyId, accountId, purpose, channel, disclosureVersionId: command.disclosureVersionId, evidence }, ['Records legal delivery consent separately from communication preferences.'], (apply) => {
    run(apply.database, `INSERT INTO consents (dataset_id,id,party_id,account_id,purpose,channel,disclosure_version_id,state,effective_at) VALUES (?,?,?,?,?,?,?,?,?)`, apply.datasetId, id, command.partyId, accountId, purpose, channel, command.disclosureVersionId, 'granted', apply.now);
    resourceEvent(apply, 'consent', id, `Consent granted for ${purpose}/${channel} in ${accountId ?? 'party-wide'} scope; acknowledgement ${evidence}.`);
  });
}

function prepareConsentWithdraw(env: Environment, command: ConsentWithdrawCommand): Preparation {
  const consent = one(env.database, 'SELECT id,party_id,account_id,purpose,channel,state,effective_at,disclosure_version_id FROM consents WHERE dataset_id=? AND id=?', env.datasetId, command.consentId);
  if (consent === undefined) return reject('not_found', 'The consent does not exist.');
  if (str(consent, 'state') !== 'granted') return reject('ineligible', 'Only granted consent can be withdrawn.');
  const accountId = optionalStr(consent, 'account_id');
  const latest = one(env.database, `SELECT id,state FROM consents WHERE dataset_id=? AND party_id=? AND account_id IS ? AND purpose=? AND channel=? AND effective_at<=?
    ORDER BY effective_at DESC,CASE state WHEN 'withdrawn' THEN 0 ELSE 1 END,id DESC LIMIT 1`, env.datasetId, str(consent, 'party_id'), accountId, str(consent, 'purpose'), str(consent, 'channel'), env.now);
  if (latest === undefined || str(latest, 'id') !== command.consentId || str(latest, 'state') !== 'granted') return reject('ineligible', 'The selected consent is no longer the active grant.');
  const consentChannel = str(consent, 'channel');
  if (command.affectedChannels.length !== 1 || command.affectedChannels[0] !== consentChannel) return reject('validation', 'Affected channels must contain exactly the stored consent channel.', { field: 'affectedChannels' });
  const suppliedEffectiveAt = command.effectiveAt ?? env.now; const issue = validateInstant(suppliedEffectiveAt, 'Effective time'); if (issue !== null) return reject('validation', issue, { field: 'effectiveAt' });
  const effectiveAt = normalizeInstant(suppliedEffectiveAt);
  if (effectiveAt < str(consent, 'effective_at')) return reject('validation', 'Withdrawal cannot precede the original consent.');
  if (effectiveAt > env.now) return reject('validation', 'Scheduled consent withdrawal is not supported; the effective time cannot be in the future.', { field: 'effectiveAt' });
  const withdrawalId = `consent-withdrawal-${randomUUID()}`;
  return prepared(command.consentId, { consentId: command.consentId, withdrawalId, accountId, state: 'withdrawn', effectiveAt, requiredServicingPreserved: true }, ['Adds a scoped withdrawal while preserving the original grant timestamp and disclosure evidence.'], (apply) => {
    run(apply.database, `INSERT INTO consents (dataset_id,id,party_id,account_id,purpose,channel,disclosure_version_id,state,effective_at) VALUES (?,?,?,?,?,?,?,?,?)`,
      apply.datasetId, withdrawalId, str(consent, 'party_id'), accountId, str(consent, 'purpose'), consentChannel, str(consent, 'disclosure_version_id'), 'withdrawn', effectiveAt);
    resourceEvent(apply, 'consent', withdrawalId, `Consent ${command.consentId} withdrawn for ${str(consent, 'purpose')}/${consentChannel} in ${accountId ?? 'party-wide'} scope; original evidence preserved.`);
  });
}

function exportCategory(documentType: string, categories: readonly string[]): string | null {
  return categories.find(category => EXPORT_DOCUMENT_TYPES[category as keyof typeof EXPORT_DOCUMENT_TYPES].includes(documentType)) ?? null;
}

function exportDateMatches(version: Row, from: string | null, through: string | null): boolean {
  const periodStart = optionalStr(version, 'period_start'); const periodEnd = optionalStr(version, 'period_end');
  if (periodStart !== null || periodEnd !== null) {
    return (from === null || periodEnd === null || periodEnd > from) && (through === null || periodStart === null || periodStart <= through);
  }
  const issuedDate = str(version, 'issued_at').slice(0, 10);
  return (from === null || issuedDate >= from) && (through === null || issuedDate <= through);
}

function exportSource(env: Environment, version: Row, category: string): Record<string, unknown> {
  const contentDigest = str(version, 'digest');
  const blob = one(env.database, 'SELECT media_type,byte_length,bytes FROM document_blobs WHERE dataset_id=? AND digest=?', env.datasetId, contentDigest);
  if (blob === undefined || !(blob.bytes instanceof Uint8Array)) throw new Error(`Export source ${str(version, 'id')} has no immutable bytes.`);
  const bytes = blob.bytes;
  if (bytes.byteLength !== int(blob, 'byte_length') || digest(bytes) !== contentDigest || str(blob, 'media_type') !== str(version, 'media_type')) {
    throw new Error(`Export source ${str(version, 'id')} failed its integrity check.`);
  }
  return {
    category,
    documentId: str(version, 'document_id'),
    versionId: str(version, 'id'),
    version: int(version, 'version'),
    documentType: str(version, 'document_type'),
    displayName: str(version, 'display_name'),
    accountId: optionalStr(version, 'account_id'),
    issuedAt: str(version, 'issued_at'),
    periodStart: optionalStr(version, 'period_start'),
    periodEnd: optionalStr(version, 'period_end'),
    mediaType: str(version, 'media_type'),
    digest: contentDigest,
    byteLength: bytes.byteLength,
    contentBase64: Buffer.from(bytes).toString('base64'),
  };
}

function prepareCustomerExport(env: Environment, command: CustomerExportCreateCommand): Preparation {
  const member = memberRow(env, command.memberId); if (member === undefined) return reject('not_found', 'The member does not exist.');
  const categories = command.categories.map(cleanText);
  if (categories.length === 0) return reject('validation', 'At least one export category is required.', { field: 'categories' });
  if (categories.some(category => !(category in EXPORT_DOCUMENT_TYPES))) return reject('validation', `Export categories must be ${Object.keys(EXPORT_DOCUMENT_TYPES).join(', ')}.`, { field: 'categories' });
  if (new Set(categories).size !== categories.length) return reject('validation', 'Export categories must be unique.', { field: 'categories' });
  const destination = cleanText(command.destination);
  if (!['local-vault', 'approved-local-output', 'approved-local-destination'].includes(destination)) return reject('validation', 'Destination is not an approved local destination.', { field: 'destination' });
  for (const date of [command.from, command.through]) if (date !== null && !isIsoDate(date)) return reject('validation', 'Export dates must be YYYY-MM-DD.');
  if (command.from !== null && command.through !== null && command.from > command.through) return reject('validation', 'Export date range is empty.');
  if (command.documentVersionIds.length === 0 || command.documentVersionIds.length > 100) return reject('validation', 'Export inventory must contain 1 to 100 exact document versions.', { field: 'documentVersionIds' });
  if (new Set(command.documentVersionIds).size !== command.documentVersionIds.length) return reject('validation', 'Export document versions must be unique.', { field: 'documentVersionIds' });
  const partyId = str(member, 'party_id'); const versions: Row[] = []; const foundCategories = new Set<string>();
  for (const id of command.documentVersionIds) {
    const version = documentVersion(env, id); if (version === undefined) return reject('not_found', `Document version ${id} does not exist.`);
    if (str(version, 'owner_party_id') !== partyId) return reject('ownership_mismatch', 'Export document is outside the member scope.');
    const category = exportCategory(str(version, 'document_type'), categories);
    if (category === null) return reject('validation', `Document version ${id} is outside the requested categories.`, { field: 'documentVersionIds' });
    if (!exportDateMatches(version, command.from, command.through)) return reject('validation', `Document version ${id} is outside the requested date scope.`, { field: 'documentVersionIds' });
    if (category === 'servicing-evidence' && one(env.database, `SELECT id FROM document_derivations WHERE dataset_id=? AND derivative_version_id=? AND purpose='redaction'`, env.datasetId, id) === undefined) {
      return reject('ineligible', `Servicing evidence ${id} has no approved redaction lineage.`);
    }
    versions.push(version); foundCategories.add(category);
  }
  const allowedTypes = [...new Set(categories.flatMap(category => EXPORT_DOCUMENT_TYPES[category as keyof typeof EXPORT_DOCUMENT_TYPES]))];
  const placeholders = allowedTypes.map(() => '?').join(',');
  const completeRows = all(env.database, `SELECT v.id,v.document_id,v.version,v.digest,v.media_type,v.issued_at,v.period_start,v.period_end,v.page_count,v.status,
      d.owner_party_id,d.account_id,d.document_type,d.display_name,d.retention_class FROM document_versions v
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE v.dataset_id=? AND d.owner_party_id=? AND d.document_type IN (${placeholders})
      AND (((v.period_start IS NOT NULL OR v.period_end IS NOT NULL) AND (? IS NULL OR v.period_end IS NULL OR v.period_end>?) AND (? IS NULL OR v.period_start IS NULL OR v.period_start<=?))
        OR (v.period_start IS NULL AND v.period_end IS NULL AND (? IS NULL OR substr(v.issued_at,1,10)>=?) AND (? IS NULL OR substr(v.issued_at,1,10)<=?)))
      AND (d.document_type<>'redacted-evidence' OR EXISTS (SELECT 1 FROM document_derivations dd WHERE dd.dataset_id=v.dataset_id AND dd.derivative_version_id=v.id AND dd.purpose='redaction'))
      ORDER BY v.id LIMIT 101`, env.datasetId, partyId, ...allowedTypes, command.from, command.from, command.through, command.through, command.from, command.from, command.through, command.through);
  if (completeRows.length > 100) return reject('limit_exceeded', 'The exact export scope exceeds 100 document versions; narrow the categories or date range.');
  const completeInventory = completeRows.map(version => str(version, 'id'));
  if (canonicalJson([...command.documentVersionIds].sort()) !== canonicalJson(completeInventory.sort())) return reject('stale_version', 'The exact export inventory is incomplete or changed after preflight. Rebuild and reapprove it.');
  const missingCategory = categories.find(category => !foundCategories.has(category));
  if (missingCategory !== undefined) return reject('validation', `The exact export inventory contains no document for category ${missingCategory}.`, { field: 'documentVersionIds' });
  const approval = requireApproval(env, command, command.approvalId); if (approval !== null) return approval;
  const sourceEntries = versions.map(version => exportSource(env, version, exportCategory(str(version, 'document_type'), categories) ?? ''));
  const artifactBytes = Buffer.from(canonicalJson({
    schema: 'customer-record-export.v1', institutionId: env.institutionId, generatedAt: env.now,
    member: { id: command.memberId, memberNumber: str(member, 'member_number') },
    scope: { categories, from: command.from, through: command.through, destination }, documents: sourceEntries,
  }), 'utf8');
  const bytesIssue = validBytes(artifactBytes, 'Export artifact'); if (bytesIssue !== null) return reject('limit_exceeded', bytesIssue);
  const artifactDigest = digest(artifactBytes); const blobIssue = verifyStoredBlob(env, artifactDigest, 'application/json', artifactBytes.byteLength); if (blobIssue !== null) return blobIssue;
  const documentId = `document-export-${randomUUID()}`; const versionId = `${documentId}-v1`;
  const purpose = `member=${command.memberId};categories=${categories.join(',')};from=${command.from ?? ''};through=${command.through ?? ''};destination=${destination};artifact=${versionId}`;
  const eventIds = versions.map(() => `document-access-${randomUUID()}`);
  return approvalPrepared(prepared(str(member, 'member_number'), {
    memberId: command.memberId, versionIds: command.documentVersionIds, categories, from: command.from, through: command.through, destination,
    artifactDocumentId: documentId, artifactVersionId: versionId, artifactDigest, artifactByteLength: artifactBytes.byteLength,
  }, ['Creates one immutable, complete JSON artifact from the approved inventory and logs access to every included version.'], (apply) => {
    run(apply.database, 'INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,?,?,?)', apply.datasetId, artifactDigest, 'application/json', artifactBytes.byteLength, artifactBytes);
    run(apply.database, `INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
      VALUES (?,?,?,?,?,?,?,?)`, apply.datasetId, documentId, partyId, null, 'customer-record-export', `customer-record-export-${apply.now.slice(0, 10)}.json`, 'customer-export-30d', apply.now);
    run(apply.database, `INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,?,?,?,?,NULL,NULL,NULL,'current')`, apply.datasetId, versionId, documentId, 1, artifactDigest, 'application/json', apply.now);
    resourceEvent(apply, 'document', documentId, `Customer record export created for member ${command.memberId}.`);
    resourceEvent(apply, 'document-version', versionId, `Immutable customer export ${versionId} stored with digest ${artifactDigest}.`);
    for (const [index, version] of versions.entries()) {
      const id = eventIds[index]; if (id === undefined) continue;
      run(apply.database, `INSERT INTO document_access_events (dataset_id,id,document_version_id,actor_id,action,occurred_at,purpose) VALUES (?,?,?,?,?,?,?)`, apply.datasetId, id, str(version, 'id'), apply.actorId, 'export', apply.now, purpose);
      resourceEvent(apply, 'document-access', id, `Included ${str(version, 'id')} in export ${versionId} for ${destination}.`);
    }
  }), command.approvalId);
}

function prepareRetentionHold(env: Environment, command: RetentionHoldApplyCommand): Preparation {
  const hasDocument = command.documentId !== undefined; const hasCase = command.caseId !== undefined;
  if (hasDocument === hasCase) return reject('validation', 'Specify exactly one document or case scope.');
  if (problem(command.reason, 'Hold reason', 500) !== null) return reject('validation', problem(command.reason, 'Hold reason', 500) ?? '', { field: 'reason' });
  if (!isIsoDate(command.reviewAt) && validateInstant(command.reviewAt, 'Review time') !== null) return reject('validation', 'Review date must be a date or ISO UTC instant.', { field: 'reviewAt' });
  const reviewAt = isIsoDate(command.reviewAt) ? command.reviewAt : normalizeInstant(command.reviewAt);
  if (isIsoDate(reviewAt) ? reviewAt <= localDate(env.now, env.timeZone) : reviewAt <= env.now) return reject('validation', 'Review date must be after the business time.', { field: 'reviewAt' });
  const targetId = command.documentId ?? command.caseId;
  if (targetId === undefined) return reject('validation', 'Specify a retention target.');
  const target = hasDocument ? one(env.database, 'SELECT id FROM documents WHERE dataset_id=? AND id=?', env.datasetId, targetId) : one(env.database, 'SELECT id FROM cases WHERE dataset_id=? AND id=?', env.datasetId, targetId);
  if (target === undefined) return reject('not_found', 'The retention target does not exist.');
  const where = hasDocument ? 'document_id=?' : 'case_id=?';
  if (one(env.database, `SELECT id FROM retention_holds WHERE dataset_id=? AND ${where} AND state='active'`, env.datasetId, targetId) !== undefined) return reject('ineligible', 'An active retention hold already protects this scope.');
  const approval = requireApproval(env, command, command.approvalId); if (approval !== null) return approval;
  const id = `retention-hold-${randomUUID()}`;
  return approvalPrepared(prepared(id, { holdId: id, documentId: command.documentId ?? null, caseId: command.caseId ?? null, reviewAt }, ['Protects the exact document or case until its review date.'], (apply) => {
    run(apply.database, `INSERT INTO retention_holds (dataset_id,id,document_id,case_id,reason,state,placed_at,review_at,released_at) VALUES (?,?,?,?,?,?,?,?,NULL)`, apply.datasetId, id, command.documentId ?? null, command.caseId ?? null, cleanText(command.reason), 'active', apply.now, reviewAt);
    resourceEvent(apply, 'retention-hold', id, `Retention hold ${id} applied until ${reviewAt}.`);
  }), command.approvalId);
}

function destinationForParty(env: Environment, partyId: string, channel: string, explicit?: string): string | null {
  if (explicit !== undefined) return cleanText(explicit) || null;
  const row = one(env.database, 'SELECT value FROM contact_points WHERE dataset_id=? AND party_id=? AND kind=? AND valid_to IS NULL ORDER BY valid_from DESC,id LIMIT 1', env.datasetId, partyId, channel === 'email' ? 'email' : channel);
  return optionalStr(row, 'value');
}

function prepareInformationRequest(env: Environment, command: CaseInformationRequestCommand): Preparation {
  const caseRow = one(env.database, 'SELECT id,case_number,member_id,account_id,state,version FROM cases WHERE dataset_id=? AND id=?', env.datasetId, command.caseId);
  if (caseRow === undefined) return reject('not_found', 'The case does not exist.');
  if (command.expectedVersion !== int(caseRow, 'version')) return staleVersion('case', command.expectedVersion, int(caseRow, 'version'));
  if (!['open', 'reopened', 'pending-internal'].includes(str(caseRow, 'state'))) return reject('ineligible', 'Information can only be requested from an active case.');
  const fields = command.fields.map(cleanText);
  if (fields.length === 0 || fields.length > 20 || fields.some(field => field.length === 0 || field.length > 100 || !/^[A-Za-z0-9][A-Za-z0-9 ._/-]*$/u.test(field)) || new Set(fields).size !== fields.length) return reject('validation', 'Provide 1 to 20 unique requested field names without control or delimiter characters.', { field: 'fields' });
  if (one(env.database, 'SELECT id FROM parties WHERE dataset_id=? AND id=?', env.datasetId, command.recipientPartyId) === undefined) return reject('not_found', 'The recipient party does not exist.');
  if (memberParty(env, str(caseRow, 'member_id')) !== command.recipientPartyId) return reject('ownership_mismatch', 'Recipient is not the case member.');
  if (validateInstant(command.dueAt, 'Information due time') !== null) return reject('validation', 'Information due time must be a future ISO UTC instant.', { field: 'dueAt' });
  const dueAt = normalizeInstant(command.dueAt); if (dueAt <= env.now) return reject('validation', 'Information due time must be a future ISO UTC instant.', { field: 'dueAt' });
  const channel = cleanText(command.channel); if (channel !== 'email') return reject('validation', 'Only email information requests are enabled in the local queue.', { field: 'channel' });
  const destination = destinationForParty(env, command.recipientPartyId, channel, command.destination); if (destination === null) return reject('not_found', 'No destination is registered for the requested channel.');
  if (one(env.database, `SELECT id FROM contact_points WHERE dataset_id=? AND party_id=? AND kind='email' AND valid_to IS NULL AND value=?`, env.datasetId, command.recipientPartyId, destination) === undefined) return reject('ownership_mismatch', 'Destination is not a current contact for the case member.');
  const noticeVersionId = command.documentVersionId ?? optionalStr(one(env.database, `SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE v.dataset_id=? AND d.owner_party_id=? AND d.document_type='servicing-notice' ORDER BY v.issued_at DESC LIMIT 1`, env.datasetId, command.recipientPartyId), 'id');
  if (noticeVersionId === null) return reject('not_found', 'No approved servicing notice document is available.');
  const notice = documentVersion(env, noticeVersionId); if (notice === undefined) return reject('not_found', 'The notice document version does not exist.');
  if (str(notice, 'owner_party_id') !== command.recipientPartyId) return reject('ownership_mismatch', 'The notice document belongs to another party.');
  if (str(notice, 'document_type') !== 'servicing-notice' || str(notice, 'status') === 'superseded') return reject('ineligible', 'The information request requires a current approved servicing notice.');
  const existing = one(env.database, `SELECT id FROM case_dependencies WHERE dataset_id=? AND case_id=? AND kind='requested-document' AND state='open'`, env.datasetId, command.caseId);
  if (existing !== undefined) return reject('ineligible', 'An information request is already pending for this case.');
  const jobId = `communication-job-${randomUUID()}`; const eventId = `communication-event-${randomUUID()}`; const dependencyId = `case-dependency-${randomUUID()}`; const version = int(caseRow, 'version') + 1;
  return prepared(str(caseRow, 'case_number'), { caseId: command.caseId, caseVersion: version, jobId, dependencyId, deliveryState: 'queued', dueAt }, ['Queues one local notice and creates one open requested-document dependency.'], (apply) => {
    run(apply.database, 'UPDATE cases SET version=? WHERE dataset_id=? AND id=?', version, apply.datasetId, command.caseId);
    run(apply.database, `INSERT INTO communication_jobs (dataset_id,id,party_id,document_version_id,purpose,channel,destination,state,created_at) VALUES (?,?,?,?,?,?,?,?,?)`, apply.datasetId, jobId, command.recipientPartyId, noticeVersionId, 'missing-information', channel, destination, 'queued', apply.now);
    run(apply.database, `INSERT INTO communication_events (dataset_id,id,job_id,sequence,state,occurred_at,detail) VALUES (?,?,?,?,?,?,?)`, apply.datasetId, eventId, jobId, 1, 'queued', apply.now, 'Queued locally; not delivered.');
    run(apply.database, `INSERT INTO case_dependencies (dataset_id,id,case_id,kind,reference_id,state,due_at) VALUES (?,?,?,?,?,?,?)`, apply.datasetId, dependencyId, command.caseId, 'requested-document', fields.join(','), 'open', dueAt);
    resourceEvent(apply, 'communication-job', jobId, `Information request queued for ${command.recipientPartyId}.`);
    resourceEvent(apply, 'case-dependency', dependencyId, `Requested ${fields.join(', ')} by ${dueAt}.`);
  });
}

function prepareCaseEscalate(env: Environment, command: CaseEscalateCommand): Preparation {
  const row = one(env.database, 'SELECT id,case_number,state,priority,due_at,version FROM cases WHERE dataset_id=? AND id=?', env.datasetId, command.caseId);
  if (row === undefined) return reject('not_found', 'The case does not exist.');
  if (command.expectedVersion !== int(row, 'version')) return staleVersion('case', command.expectedVersion, int(row, 'version'));
  if (!['open', 'pending-customer', 'pending-internal', 'reopened'].includes(str(row, 'state'))) return reject('ineligible', 'Only an active case can be escalated.');
  const ruleIssue = problem(command.escalationRule, 'Escalation rule', 200); if (ruleIssue !== null) return reject('validation', ruleIssue, { field: 'escalationRule' });
  if (str(row, 'due_at') > env.now) return reject('ineligible', 'The escalation deadline has not been reached.');
  const priority = str(row, 'priority'); const next = priority === 'low' ? 'normal' : priority === 'normal' ? 'high' : priority === 'high' ? 'urgent' : priority;
  if (next === priority) return { kind: 'unchanged', message: 'The case is already at its maximum priority.' };
  const eventId = `case-event-${randomUUID()}`; const version = int(row, 'version') + 1;
  return prepared(str(row, 'case_number'), { caseId: command.caseId, priority: next, basisDueAt: str(row, 'due_at') }, ['Raises priority only after comparing the stored due date with the business clock.'], (apply) => {
    run(apply.database, 'UPDATE cases SET priority=?,version=? WHERE dataset_id=? AND id=?', next, version, apply.datasetId, command.caseId);
    run(apply.database, `INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?,?,?,?,?)`, apply.datasetId, eventId, command.caseId, nextCommunicationSequenceForCase(apply, command.caseId), str(row, 'state'), apply.now, apply.actorId, `Escalated because due_at ${str(row, 'due_at')} is before ${apply.now}. Rule: ${command.escalationRule}.`);
    resourceEvent(apply, 'case', command.caseId, `Case priority raised to ${next}.`);
  });
}

function nextCommunicationSequenceForCase(apply: ApplyEnvironment, caseId: string): number {
  return (optionalInt(one(apply.database, 'SELECT MAX(sequence) AS maximum FROM case_events WHERE dataset_id=? AND case_id=?', apply.datasetId, caseId), 'maximum') ?? 0) + 1;
}

function prepareAddressReconcile(env: Environment, command: AddressReconcileCommand): Preparation {
  const member = memberRow(env, command.memberId); if (member === undefined) return reject('not_found', 'The member does not exist.');
  if (command.expectedMemberVersion !== int(member, 'version')) return staleVersion('member', command.expectedMemberVersion, int(member, 'version'));
  const address = one(env.database, `SELECT a.id,a.line1,a.line2,a.city,a.region,a.postal_code,a.country,pa.id AS party_address_id,pa.party_id,pa.purpose,pa.valid_to,pa.evidence_status
    FROM addresses a JOIN party_addresses pa ON pa.dataset_id=a.dataset_id AND pa.address_id=a.id WHERE a.dataset_id=? AND a.id=?`, env.datasetId, command.conflictingAddressId);
  if (address === undefined) return reject('not_found', 'The conflicting address does not exist.');
  if (str(address, 'party_id') !== str(member, 'party_id')) return reject('ownership_mismatch', 'Address is not attached to the member.');
  if (str(address, 'evidence_status') !== 'conflicting' || optionalStr(address, 'valid_to') !== null) return reject('ineligible', 'Only a current address with conflicting evidence can be reconciled.');
  const evidence = documentVersion(env, command.winningEvidenceVersionId); if (evidence === undefined) return reject('not_found', 'Winning evidence version does not exist.');
  if (str(evidence, 'owner_party_id') !== str(member, 'party_id') || str(evidence, 'digest') !== command.winningEvidenceDigest) return reject('ownership_mismatch', 'Winning evidence is not an exact member-bound digest.');
  if (str(evidence, 'document_type') !== 'address-evidence' || str(evidence, 'status') !== 'current') return reject('ineligible', 'Winning evidence must be a current approved address-evidence document version.');
  if (!documentVersionBytesAreValid(env, evidence)) return reject('ineligible', 'Winning address evidence bytes are missing, changed, or unreadable.');
  if (command.precedence !== 'verified-evidence') return reject('ineligible', 'Only verified evidence can resolve this address conflict.');
  const resolved = command.address;
  const issue = addressProblems(resolved); if (issue !== null) return reject('validation', issue);
  const normalized = normalizedAddress(resolved);
  const approval = requireApproval(env, command, command.approvalId); if (approval !== null) return approval;
  const memberVersion = int(member, 'version') + 1; const addressId = `address-${randomUUID()}`; const partyAddressId = `party-address-${randomUUID()}`;
  return approvalPrepared(prepared(command.memberId, { memberId: command.memberId, memberVersion, addressId, supersededAddressId: command.conflictingAddressId, line1: normalized.line1, winningEvidenceVersionId: command.winningEvidenceVersionId, winningEvidenceDigest: command.winningEvidenceDigest, sourceDisposition: 'verified-over-conflicting' }, ['Closes the conflicting address association and appends one verified canonical address.'], (apply) => {
    run(apply.database, 'UPDATE party_addresses SET valid_to=? WHERE dataset_id=? AND id=? AND valid_to IS NULL', apply.now, apply.datasetId, str(address, 'party_address_id'));
    run(apply.database, `INSERT INTO addresses (dataset_id,id,line1,line2,city,region,postal_code,country) VALUES (?,?,?,?,?,?,?,?)`,
      apply.datasetId, addressId, normalized.line1, normalized.line2, normalized.city, normalized.region, normalized.postalCode, normalized.country);
    run(apply.database, `INSERT INTO party_addresses (dataset_id,id,party_id,address_id,purpose,valid_from,valid_to,evidence_status,evidence_version_id) VALUES (?,?,?,?,?,?,NULL,'verified',?)`,
      apply.datasetId, partyAddressId, str(member, 'party_id'), addressId, str(address, 'purpose'), apply.now, command.winningEvidenceVersionId);
    run(apply.database, 'UPDATE members SET version=? WHERE dataset_id=? AND id=?', memberVersion, apply.datasetId, command.memberId);
    resourceEvent(apply, 'party-address', str(address, 'party_address_id'), `Conflicting address association closed using verified evidence ${command.winningEvidenceVersionId}.`);
    resourceEvent(apply, 'address', addressId, `Verified canonical address appended from evidence ${command.winningEvidenceVersionId}.`);
    resourceEvent(apply, 'party-address', partyAddressId, 'Verified canonical member address association created.');
  }), command.approvalId);
}

const ADDRESS_DESTINATION_TARGET_COLUMN = Object.freeze({
  'member-mailing': 'member_id',
  'account-statement': 'account_id',
  'card-shipping': 'card_id',
  'loan-notice': 'loan_id',
} satisfies Record<AddressDestinationUpdateCommand['context'], string>);

function addressDestinationTarget(env: Environment, command: AddressDestinationUpdateCommand): Row | undefined {
  switch (command.context) {
    case 'member-mailing':
      return one(env.database, 'SELECT m.id AS target_id,m.party_id,NULL AS account_id,m.status FROM members m WHERE m.dataset_id=? AND m.id=?', env.datasetId, command.targetId);
    case 'account-statement':
      return one(env.database, `SELECT a.id AS target_id,m.party_id,a.id AS account_id,a.status,a.statement_delivery FROM accounts a
        JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id WHERE a.dataset_id=? AND a.id=?`, env.datasetId, command.targetId);
    case 'card-shipping':
      return one(env.database, `SELECT c.id AS target_id,m.party_id,a.id AS account_id,a.status,c.status AS target_status FROM cards c
        JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
        WHERE c.dataset_id=? AND c.id=?`, env.datasetId, command.targetId);
    case 'loan-notice':
      return one(env.database, `SELECT l.id AS target_id,m.party_id,a.id AS account_id,a.status,l.state AS target_status FROM loans l
        JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
        WHERE l.dataset_id=? AND l.id=?`, env.datasetId, command.targetId);
  }
}

function addressDestinationConsentProblem(env: Environment, command: AddressDestinationUpdateCommand, partyId: string, accountId: string | null, effectiveAt: string): Rejection | null {
  if (command.consentId === null) return null;
  const purpose = { 'member-mailing': 'servicing-notices', 'account-statement': 'account-statements', 'card-shipping': 'card-shipping', 'loan-notice': 'loan-notices' }[command.context];
  const consent = one(env.database, `SELECT c.id,c.party_id,c.account_id,c.purpose,c.channel,c.state,c.effective_at,d.owner_party_id,d.account_id AS disclosure_account_id,v.status AS disclosure_status
    FROM consents c JOIN document_versions v ON v.dataset_id=c.dataset_id AND v.id=c.disclosure_version_id
    JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE c.dataset_id=? AND c.id=?`, env.datasetId, command.consentId);
  if (consent === undefined) return reject('not_found', 'The destination consent does not exist.', { field: 'consentId' });
  if (str(consent, 'party_id') !== partyId || optionalStr(consent, 'account_id') !== accountId || str(consent, 'owner_party_id') !== partyId || optionalStr(consent, 'disclosure_account_id') !== accountId) {
    return reject('ownership_mismatch', 'The destination consent or disclosure names another member scope.', { field: 'consentId' });
  }
  if (str(consent, 'purpose') !== purpose || str(consent, 'channel') !== 'mail' || str(consent, 'state') !== 'granted' || str(consent, 'effective_at') > effectiveAt || !['current', 'signed'].includes(str(consent, 'disclosure_status'))) {
    return reject('ineligible', 'The supplied postal consent is not effective for this destination context.', { field: 'consentId' });
  }
  const latest = one(env.database, `SELECT id FROM consents WHERE dataset_id=? AND party_id=? AND account_id IS ? AND purpose=? AND channel='mail' AND effective_at<=?
    ORDER BY effective_at DESC,id DESC LIMIT 1`, env.datasetId, partyId, accountId, purpose, effectiveAt);
  return latest === undefined || str(latest, 'id') !== command.consentId
    ? reject('ineligible', 'The supplied postal consent is not the latest effective decision for this context.', { field: 'consentId' }) : null;
}

function prepareAddressDestinationUpdate(env: Environment, command: AddressDestinationUpdateCommand): Preparation {
  const member = memberRow(env, command.memberId);
  if (member === undefined) return reject('not_found', 'The member does not exist.');
  if (str(member, 'status') !== 'active') return reject('ineligible', 'Address destinations can only be updated for an active member.');
  if (!isIsoDate(command.effectiveDate) || command.effectiveDate < localDate(env.now, env.timeZone)) return reject('validation', 'Destination effective date must be today or later.', { field: 'effectiveDate' });
  const effectiveAt = zonedInstant(command.effectiveDate, '00:00', env.timeZone);
  const target = addressDestinationTarget(env, command);
  if (target === undefined) return reject('not_found', 'The destination target does not exist.');
  if (str(target, 'party_id') !== str(member, 'party_id') || command.context === 'member-mailing' && command.targetId !== command.memberId) {
    return reject('ownership_mismatch', 'The destination target belongs to another member.');
  }
  if (command.context !== 'member-mailing' && str(target, 'status') === 'closed') return reject('ineligible', 'The destination target account is closed.');
  if (command.context === 'loan-notice' && !['active', 'delinquent'].includes(str(target, 'target_status'))) return reject('ineligible', 'Loan-notice destinations require an active or delinquent loan.');
  const addressEvidenceAt = effectiveAt < env.now ? env.now : effectiveAt;
  const partyAddress = one(env.database, `SELECT pa.id,pa.address_id,pa.party_id,pa.evidence_status,pa.evidence_version_id,pa.valid_from,pa.valid_to
    FROM party_addresses pa WHERE pa.dataset_id=? AND pa.party_id=? AND pa.address_id=? AND pa.valid_from<=? AND (pa.valid_to IS NULL OR pa.valid_to>?)
    ORDER BY pa.valid_from DESC,pa.id DESC LIMIT 1`, env.datasetId, str(member, 'party_id'), command.addressId, addressEvidenceAt, addressEvidenceAt);
  if (partyAddress === undefined || str(partyAddress, 'evidence_status') !== 'verified' || optionalStr(partyAddress, 'evidence_version_id') !== command.evidenceVersionId) {
    return reject('ineligible', 'The selected destination is not the exact verified address evidence effective for this member.');
  }
  const evidence = documentVersion(env, command.evidenceVersionId);
  if (evidence === undefined) return reject('not_found', 'The address evidence version does not exist.');
  if (str(evidence, 'owner_party_id') !== str(member, 'party_id')) return reject('ownership_mismatch', 'The address evidence belongs to another member.');
  if (str(evidence, 'document_type') !== 'address-evidence' || !['current', 'signed'].includes(str(evidence, 'status')) || !documentVersionBytesAreValid(env, evidence)) {
    return reject('ineligible', 'The destination requires current readable address evidence.');
  }
  const accountId = optionalStr(target, 'account_id');
  const consentProblem = addressDestinationConsentProblem(env, command, str(member, 'party_id'), accountId, effectiveAt);
  if (consentProblem !== null) return consentProblem;
  const targetColumn = ADDRESS_DESTINATION_TARGET_COLUMN[command.context];
  const current = one(env.database, `SELECT id,party_address_id,evidence_version_id,consent_id,effective_at,ends_at FROM address_destinations
    WHERE dataset_id=? AND context_kind=? AND ${targetColumn}=? AND effective_at<=? AND (ends_at IS NULL OR ends_at>?) ORDER BY effective_at DESC,id DESC LIMIT 1`,
  env.datasetId, command.context, command.targetId, effectiveAt, effectiveAt);
  if ((current === undefined ? null : str(current, 'id')) !== command.expectedCurrentDestinationId) {
    return reject('stale_version', 'The scoped address destination changed after review.');
  }
  if (current !== undefined && str(current, 'party_address_id') === str(partyAddress, 'id') && str(current, 'evidence_version_id') === command.evidenceVersionId && optionalStr(current, 'consent_id') === command.consentId) {
    return { kind: 'unchanged', message: 'The scoped address destination already matches the verified route.' };
  }
  if (current !== undefined && str(current, 'effective_at') === effectiveAt) return reject('ineligible', 'A different address destination is already recorded for this context and effective date.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const successor = one(env.database, `SELECT effective_at FROM address_destinations WHERE dataset_id=? AND context_kind=? AND ${targetColumn}=? AND effective_at>? ORDER BY effective_at,id LIMIT 1`,
    env.datasetId, command.context, command.targetId, effectiveAt);
  const destinationId = `address-destination-${randomUUID()}`;
  const scopeColumns = {
    memberId: command.context === 'member-mailing' ? command.targetId : null,
    accountId: command.context === 'account-statement' ? command.targetId : null,
    cardId: command.context === 'card-shipping' ? command.targetId : null,
    loanId: command.context === 'loan-notice' ? command.targetId : null,
  };
  return approvalPrepared(prepared(destinationId, { destinationId, context: command.context, targetId: command.targetId, addressId: command.addressId, evidenceVersionId: command.evidenceVersionId, consentId: command.consentId, effectiveAt },
    [`Sets only the ${command.context} destination for ${command.targetId}; other address contexts and legal consent remain unchanged.`], (apply) => {
      if (current !== undefined && optionalStr(current, 'ends_at') !== effectiveAt) run(apply.database, 'UPDATE address_destinations SET ends_at=? WHERE dataset_id=? AND id=?', effectiveAt, apply.datasetId, str(current, 'id'));
      run(apply.database, `INSERT INTO address_destinations (dataset_id,id,context_kind,member_id,account_id,card_id,loan_id,party_address_id,evidence_version_id,consent_id,effective_at,ends_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`, apply.datasetId, destinationId, command.context, scopeColumns.memberId, scopeColumns.accountId, scopeColumns.cardId, scopeColumns.loanId,
      str(partyAddress, 'id'), command.evidenceVersionId, command.consentId, effectiveAt, optionalStr(successor, 'effective_at'));
      resourceEvent(apply, 'address-destination', destinationId, `${command.context} destination ${command.targetId} set to verified address ${command.addressId} effective ${command.effectiveDate}.`);
    }), command.approvalId);
}

function evidenceOwnedByMember(env: Environment, versionId: string, memberId: string): boolean {
  const partyId = memberParty(env, memberId); const version = documentVersion(env, versionId);
  return partyId !== undefined && version !== undefined && str(version, 'owner_party_id') === partyId;
}

function currentEvidenceProblem(env: Environment, versionId: string, memberId: string): Preparation | null {
  const version = documentVersion(env, versionId);
  if (version === undefined || !evidenceOwnedByMember(env, versionId, memberId)) {
    return reject('ownership_mismatch', 'Evidence is outside the case member scope or is not visible to this operator.');
  }
  if (!['current', 'signed'].includes(str(version, 'status'))) {
    return reject('ineligible', 'Case evidence must be a current immutable document version.');
  }
  if (!documentVersionBytesAreValid(env, version)) {
    return reject('ineligible', 'Case evidence bytes are missing, changed, or unreadable.');
  }
  return null;
}

function prepareCaseClose(env: Environment, command: CaseCloseCommand): Preparation {
  const row = one(env.database, 'SELECT id,case_number,member_id,state,version FROM cases WHERE dataset_id=? AND id=?', env.datasetId, command.caseId); if (row === undefined) return reject('not_found', 'The case does not exist.');
  if (command.expectedVersion !== int(row, 'version')) return staleVersion('case', command.expectedVersion, int(row, 'version'));
  if (str(row, 'state') !== 'resolved') return reject('ineligible', 'Only a resolved case can be closed.');
  const openDependency = one(env.database, `SELECT id FROM case_dependencies WHERE dataset_id=? AND case_id=? AND state='open'`, env.datasetId, command.caseId); if (openDependency !== undefined) return reject('ineligible', 'Open dependencies must be satisfied before closure.');
  const evidenceProblem = currentEvidenceProblem(env, command.effectEvidenceVersionId, str(row, 'member_id')); if (evidenceProblem !== null) return evidenceProblem;
  const resolutionIssue = problem(command.resolutionCode, 'Resolution code', 100); if (resolutionIssue !== null) return reject('validation', resolutionIssue, { field: 'resolutionCode' });
  const eventId = `case-event-${randomUUID()}`; const version = int(row, 'version') + 1;
  return prepared(str(row, 'case_number'), { caseId: command.caseId, state: 'closed', resolutionCode: command.resolutionCode }, ['Closes a resolved case only after all dependencies are satisfied and records closure history.'], (apply) => {
    run(apply.database, 'UPDATE cases SET state=?,version=? WHERE dataset_id=? AND id=?', 'closed', version, apply.datasetId, command.caseId);
    run(apply.database, 'INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?,?,?,?,?)', apply.datasetId, eventId, command.caseId, nextCommunicationSequenceForCase(apply, command.caseId), 'closed', apply.now, apply.actorId, `Closed with resolution evidence ${command.effectEvidenceVersionId} (${command.resolutionCode}).`);
    resourceEvent(apply, 'case', command.caseId, 'Case closed after dependency review.');
  });
}

function addDays(instant: string, days: number): string {
  const date = new Date(instant); date.setUTCDate(date.getUTCDate() + days); return date.toISOString();
}

function prepareCaseReopen(env: Environment, command: CaseReopenCommand): Preparation {
  const row = one(env.database, 'SELECT id,case_number,member_id,state,version FROM cases WHERE dataset_id=? AND id=?', env.datasetId, command.caseId); if (row === undefined) return reject('not_found', 'The case does not exist.');
  if (command.expectedVersion !== int(row, 'version')) return staleVersion('case', command.expectedVersion, int(row, 'version'));
  if (!['resolved', 'closed'].includes(str(row, 'state'))) return reject('ineligible', 'Only resolved or closed cases can be reopened.');
  const evidenceProblem = currentEvidenceProblem(env, command.evidenceVersionId, str(row, 'member_id')); if (evidenceProblem !== null) return evidenceProblem;
  const basisIssue = problem(command.reopeningBasis, 'Reopening basis', 500); if (basisIssue !== null) return reject('validation', basisIssue, { field: 'reopeningBasis' });
  const dependencyId = `case-dependency-${randomUUID()}`; const eventId = `case-event-${randomUUID()}`; const version = int(row, 'version') + 1;
  const suppliedDueAt = command.dueAt ?? addDays(env.now, 7);
  if (validateInstant(suppliedDueAt, 'Due time') !== null) return reject('validation', 'Reopened case due time must be a future ISO UTC instant.', { field: 'dueAt' });
  const dueAt = normalizeInstant(suppliedDueAt); if (dueAt <= env.now) return reject('validation', 'Reopened case due time must be a future ISO UTC instant.', { field: 'dueAt' });
  return prepared(str(row, 'case_number'), { caseId: command.caseId, state: 'reopened', evidenceVersionId: command.evidenceVersionId }, ['Reopens the case while preserving prior resolution events and adding an evidence dependency.'], (apply) => {
    run(apply.database, 'UPDATE cases SET state=?,version=? WHERE dataset_id=? AND id=?', 'reopened', version, apply.datasetId, command.caseId);
    run(apply.database, 'INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?,?,?,?,?)', apply.datasetId, eventId, command.caseId, nextCommunicationSequenceForCase(apply, command.caseId), 'reopened', apply.now, apply.actorId, `Reopened for new evidence ${command.evidenceVersionId}; prior resolution preserved (${command.reopeningBasis}).`);
    run(apply.database, 'INSERT INTO case_dependencies (dataset_id,id,case_id,kind,reference_id,state,due_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, dependencyId, command.caseId, 'new-evidence', command.evidenceVersionId, 'open', dueAt);
    resourceEvent(apply, 'case', command.caseId, 'Case reopened with new evidence.');
    resourceEvent(apply, 'case-dependency', dependencyId, `New evidence due by ${dueAt}.`);
  });
}

function prepareCaseSubjectCorrect(env: Environment, command: CaseSubjectCorrectCommand): Preparation {
  const row = one(env.database, 'SELECT id,case_number,member_id,account_id,state,version FROM cases WHERE dataset_id=? AND id=?', env.datasetId, command.caseId); if (row === undefined) return reject('not_found', 'The case does not exist.');
  if (command.expectedVersion !== int(row, 'version')) return staleVersion('case', command.expectedVersion, int(row, 'version'));
  const targetMember = memberRow(env, command.correctMemberId); if (targetMember === undefined) return reject('not_found', 'Correct member does not exist.');
  if (str(targetMember, 'status') === 'merged') return reject('ineligible', 'A merged member cannot become the corrected case subject.');
  if (command.correctAccountId !== null) { const account = accountRow(env, command.correctAccountId); if (account === undefined) return reject('not_found', 'Correct account does not exist.'); if (str(account, 'member_id') !== command.correctMemberId) return reject('ownership_mismatch', 'Correct account is not owned by the correct member.'); }
  if (!evidenceOwnedByMember(env, command.evidenceVersionId, str(row, 'member_id')) && !evidenceOwnedByMember(env, command.evidenceVersionId, command.correctMemberId)) return reject('ownership_mismatch', 'Correction evidence is outside both subject scopes.');
  const sourceEvidenceProblem = currentEvidenceProblem(env, command.evidenceVersionId,
    evidenceOwnedByMember(env, command.evidenceVersionId, str(row, 'member_id')) ? str(row, 'member_id') : command.correctMemberId);
  if (sourceEvidenceProblem !== null) return sourceEvidenceProblem;
  if (str(row, 'member_id') === command.correctMemberId && (optionalStr(row, 'account_id') ?? null) === command.correctAccountId) return { kind: 'unchanged', message: 'The case already has the correct subject.' };
  const approval = requireApproval(env, command, command.approvalId); if (approval !== null) return approval;
  const eventId = `case-event-${randomUUID()}`; const version = int(row, 'version') + 1;
  const caseDocumentCount = int(one(env.database, 'SELECT COUNT(*) AS count FROM case_documents WHERE dataset_id=? AND case_id=?', env.datasetId, command.caseId), 'count');
  const caseNoteCount = int(one(env.database, 'SELECT COUNT(*) AS count FROM case_notes WHERE dataset_id=? AND case_id=?', env.datasetId, command.caseId), 'count');
  const restrictedQueue = one(env.database, "SELECT id FROM queues WHERE dataset_id=? AND visibility='restricted' ORDER BY id LIMIT 1", env.datasetId);
  if (restrictedQueue === undefined) return reject('ineligible', 'No restricted queue is available for post-correction access review.');
  return approvalPrepared(prepared(str(row, 'case_number'), { caseId: command.caseId, memberId: command.correctMemberId, accountId: command.correctAccountId,
    accessReassessment: { restrictedQueueId: str(restrictedQueue, 'id'), caseDocumentsRestricted: caseDocumentCount, caseNotesProtectedByQueue: caseNoteCount, evidenceOwnershipChanged: false } },
  ['Corrects the case subject, preserves document and note history, and moves the case and its evidence links behind restricted access for renewed review.'], (apply) => {
    run(apply.database, 'UPDATE cases SET member_id=?,account_id=?,queue_id=?,version=? WHERE dataset_id=? AND id=?', command.correctMemberId, command.correctAccountId, str(restrictedQueue, 'id'), version, apply.datasetId, command.caseId);
    run(apply.database, "UPDATE case_documents SET visibility='restricted' WHERE dataset_id=? AND case_id=?", apply.datasetId, command.caseId);
    run(apply.database, 'INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?,?,?,?,?)', apply.datasetId, eventId, command.caseId, nextCommunicationSequenceForCase(apply, command.caseId), str(row, 'state'), apply.now, apply.actorId, `Corrected subject from ${str(row, 'member_id')}/${optionalStr(row, 'account_id') ?? ''} to ${command.correctMemberId}/${command.correctAccountId ?? ''}; prior exposure retained.`);
    resourceEvent(apply, 'case', command.caseId, `Case subject corrected; moved to restricted queue with ${caseDocumentCount} evidence link(s) and ${caseNoteCount} preserved note(s) pending renewed access review.`);
  }), command.approvalId);
}

const MAX_MAINTENANCE_COMMAND_BYTES = 16 * 1024;

function requestedCommandCopy(command: MaintenanceRequestedCommand): MaintenanceRequestedCommand {
  return JSON.parse(canonicalJson(command)) as MaintenanceRequestedCommand;
}

function requestedCommandProblem(command: MaintenanceRequestedCommand, memberId: string, accountId: string | null): string | null {
  if (Buffer.byteLength(canonicalJson(command), 'utf8') > MAX_MAINTENANCE_COMMAND_BYTES) return `Requested command cannot exceed ${MAX_MAINTENANCE_COMMAND_BYTES} bytes.`;
  switch (command.kind) {
    case 'contact.update':
      if (command.memberId !== memberId) return 'Requested contact update is outside the maintenance request member scope.';
      if (command.email === undefined && command.phone === undefined && command.address === undefined) return 'Requested contact update must select at least one contact field.';
      return null;
    case 'member.note.add': return command.memberId === memberId ? null : 'Requested note is outside the maintenance request member scope.';
    case 'account.nickname.update':
    case 'account.statement_delivery.update':
    case 'account.close': return accountId !== null && command.accountId === accountId ? null : 'Requested account command is outside the maintenance request account scope.';
  }
}

function draftRequestedCommand(draft: unknown): MaintenanceRequestedCommand | null {
  if (draft === null || typeof draft !== 'object' || Array.isArray(draft)) return null;
  const command = (draft as Record<string, unknown>).requestedCommand;
  return isMaintenanceRequestedCommand(command) ? command : null;
}

function draftObject(command: MaintenanceDraftSaveCommand): Record<string, unknown> {
  return { requestedCommand: requestedCommandCopy(command.requestedCommand), note: cleanText(command.note ?? ''), evidenceDocumentVersionIds: command.evidenceDocumentVersionIds ?? [], missingFields: command.missingFields.map(cleanText) };
}

function prepareDraftSave(env: Environment, command: MaintenanceDraftSaveCommand): Preparation {
  const member = memberRow(env, command.memberId); if (member === undefined) return reject('not_found', 'The member does not exist.');
  if (command.accountId !== null) { const account = accountRow(env, command.accountId); if (account === undefined) return reject('not_found', 'The account does not exist.'); if (str(account, 'member_id') !== command.memberId) return reject('ownership_mismatch', 'Account is not owned by the member.'); }
  for (const [field, value, max] of [['category', command.category, 80], ['subject', command.subject, 200]] as const) { const issue = problem(value, field, max); if (issue !== null) return reject('validation', issue, { field }); }
  const commandIssue = requestedCommandProblem(command.requestedCommand, command.memberId, command.accountId); if (commandIssue !== null) return reject('validation', commandIssue, { field: 'requestedCommand' });
  if (command.note !== undefined) { const noteIssue = problem(command.note, 'Note', 2000); if (noteIssue !== null) return reject('validation', noteIssue, { field: 'note' }); }
  const missingFields = command.missingFields.map(cleanText);
  if (missingFields.length > 20 || missingFields.some(field => field.length === 0 || field.length > 100) || new Set(missingFields).size !== missingFields.length) return reject('validation', 'Provide at most 20 unique missing fields of at most 100 characters.', { field: 'missingFields' });
  const requestId = command.requestId ?? `maintenance-request-${randomUUID()}`; if (one(env.database, 'SELECT id FROM maintenance_requests WHERE dataset_id=? AND id=?', env.datasetId, requestId) !== undefined) return reject('ineligible', 'A maintenance request with this identity already exists.');
  const requestNumber = command.requestNumber ?? nextNumber(env.database, 'maintenance_requests', 'request_number', env.datasetId, 'MR', 8);
  if (command.requestNumber !== undefined) { const requestNumberIssue = problem(requestNumber, 'Request number', 80); if (requestNumberIssue !== null) return reject('validation', requestNumberIssue, { field: 'requestNumber' }); }
  if (one(env.database, 'SELECT id FROM maintenance_requests WHERE dataset_id=? AND request_number=?', env.datasetId, requestNumber) !== undefined) return reject('ineligible', 'A maintenance request with this number already exists.');
  const draft = { ...draftObject(command), missingFields }; const attachments = [...(command.evidenceDocumentVersionIds ?? [])];
  if (attachments.length > 50) return reject('limit_exceeded', 'A maintenance request supports at most 50 evidence attachments.', { field: 'evidenceDocumentVersionIds' });
  if (new Set(attachments).size !== attachments.length) return reject('validation', 'Evidence attachments must be unique.', { field: 'evidenceDocumentVersionIds' });
  for (const versionId of attachments) {
    const version = documentVersion(env, versionId); if (version === undefined) return reject('not_found', `Evidence version ${versionId} does not exist.`);
    if (str(version, 'owner_party_id') !== str(member, 'party_id')) return reject('ownership_mismatch', `Evidence version ${versionId} is outside the member scope.`);
  }
  return prepared(requestNumber, { requestId, requestNumber, state: 'draft', missingFields }, ['Stores an incomplete request with a durable number without applying business changes.'], (apply) => {
    run(apply.database, `INSERT INTO maintenance_requests (dataset_id,id,request_number,member_id,account_id,category,reason,subject,draft_json,state,created_at,updated_at,applied_receipt_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NULL)`, apply.datasetId, requestId, requestNumber, command.memberId, command.accountId, cleanText(command.category), null, cleanText(command.subject), canonicalJson(draft), 'draft', apply.now, apply.now);
    for (const versionId of attachments) run(apply.database, 'INSERT INTO request_attachments (dataset_id,request_id,document_version_id,purpose) VALUES (?,?,?,?)', apply.datasetId, requestId, versionId, 'evidence');
    resourceEvent(apply, 'maintenance-request', requestId, `Maintenance draft ${requestNumber} saved.`);
  });
}

function prepareDraftAmend(env: Environment, command: MaintenanceDraftAmendCommand): Preparation {
  const row = one(env.database, `SELECT id,request_number,member_id,account_id,reason,subject,draft_json,state,updated_at FROM maintenance_requests WHERE dataset_id=? AND id=?`, env.datasetId, command.requestId); if (row === undefined) return reject('not_found', 'The maintenance request does not exist.');
  if (str(row, 'state') !== 'draft') return reject('ineligible', 'Only draft requests can be amended.');
  if (str(row, 'updated_at') !== command.expectedUpdatedAt) return reject('stale_version', 'This draft changed after you opened it. Reopen it before amending again.');
  let current: Record<string, unknown>;
  try { const parsed: unknown = JSON.parse(str(row, 'draft_json')); current = parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed) ? { ...(parsed as Record<string, unknown>) } : {}; } catch { return reject('validation', 'The saved draft is not valid JSON.'); }
  const patch = command.patch;
  if (Object.keys(patch).length === 0) return reject('validation', 'At least one draft field must be selected for amendment.', { field: 'patch' });
  if (patch.subject !== undefined) { const issue = problem(patch.subject, 'Subject', 200); if (issue !== null) return reject('validation', issue, { field: 'subject' }); }
  if (patch.reason !== undefined && patch.reason !== null) { const issue = problem(patch.reason, 'Reason', 500); if (issue !== null) return reject('validation', issue, { field: 'reason' }); }
  if (patch.note !== undefined) { const issue = problem(patch.note, 'Note', 2000); if (issue !== null) return reject('validation', issue, { field: 'note' }); }
  if (patch.requestedCommand !== undefined) {
    const issue = requestedCommandProblem(patch.requestedCommand, str(row, 'member_id'), optionalStr(row, 'account_id'));
    if (issue !== null) return reject('validation', issue, { field: 'requestedCommand' });
  }
  const patchedMissing = patch.missingFields?.map(cleanText);
  if (patchedMissing !== undefined && (patchedMissing.length > 20 || patchedMissing.some(field => field.length === 0 || field.length > 100) || new Set(patchedMissing).size !== patchedMissing.length)) return reject('validation', 'Provide at most 20 unique missing fields of at most 100 characters.', { field: 'missingFields' });
  if (patch.subject !== undefined) current.subject = cleanText(patch.subject);
  if (patch.requestedCommand !== undefined) current.requestedCommand = requestedCommandCopy(patch.requestedCommand);
  if (patch.note !== undefined) current.note = cleanText(patch.note);
  if (patchedMissing !== undefined) current.missingFields = patchedMissing;
  delete current.review;
  const attachmentRows = all(env.database, 'SELECT document_version_id,purpose FROM request_attachments WHERE dataset_id=? AND request_id=? ORDER BY document_version_id LIMIT 51', env.datasetId, command.requestId);
  if (attachmentRows.length > 50) return reject('limit_exceeded', 'The saved request exceeds the 50-attachment processing limit.');
  const priorAttachmentIds = attachmentRows.map(item => str(item, 'document_version_id'));
  let attachmentIds = patch.evidenceDocumentVersionIds === undefined ? priorAttachmentIds : [...patch.evidenceDocumentVersionIds];
  if (patch.evidenceVersionId !== undefined) attachmentIds.push(patch.evidenceVersionId);
  attachmentIds = [...new Set(attachmentIds)];
  if (attachmentIds.length > 50) return reject('limit_exceeded', 'A maintenance request supports at most 50 evidence attachments.', { field: 'evidenceDocumentVersionIds' });
  if (patch.evidenceDocumentVersionIds !== undefined && new Set(patch.evidenceDocumentVersionIds).size !== patch.evidenceDocumentVersionIds.length) return reject('validation', 'Evidence attachments must be unique.', { field: 'evidenceDocumentVersionIds' });
  const partyId = memberParty(env, str(row, 'member_id')); if (partyId === undefined) throw new Error('Maintenance request member is missing.');
  for (const id of attachmentIds) {
    const version = documentVersion(env, id); if (version === undefined) return reject('not_found', `Evidence version ${id} does not exist.`);
    if (str(version, 'owner_party_id') !== partyId) return reject('ownership_mismatch', `Evidence version ${id} is outside the request member scope.`);
  }
  if (patch.evidenceDocumentVersionIds !== undefined || patch.evidenceVersionId !== undefined) current.evidenceDocumentVersionIds = attachmentIds;
  const subject = patch.subject === undefined ? str(row, 'subject') : cleanText(patch.subject); const reason = patch.reason === undefined ? optionalStr(row, 'reason') : patch.reason === null ? null : cleanText(patch.reason);
  const updatedAt = nextUpdatedAt(str(row, 'updated_at'), env.now); const attachmentsChanged = patch.evidenceDocumentVersionIds !== undefined || patch.evidenceVersionId !== undefined;
  const purposes = new Map(attachmentRows.map(item => [str(item, 'document_version_id'), str(item, 'purpose')]));
  return prepared(str(row, 'request_number'), { requestId: command.requestId, state: 'draft', updatedAt, missingFields: current.missingFields ?? [], attachmentVersionIds: attachmentIds }, ['Amends selected draft fields and preserves every omitted field and attachment.'], (apply) => {
    run(apply.database, 'UPDATE maintenance_requests SET reason=?,subject=?,draft_json=?,updated_at=? WHERE dataset_id=? AND id=?', reason, subject, canonicalJson(current), updatedAt, apply.datasetId, command.requestId);
    if (attachmentsChanged) {
      run(apply.database, 'DELETE FROM request_attachments WHERE dataset_id=? AND request_id=?', apply.datasetId, command.requestId);
      for (const id of attachmentIds) run(apply.database, 'INSERT INTO request_attachments (dataset_id,request_id,document_version_id,purpose) VALUES (?,?,?,?)', apply.datasetId, command.requestId, id, purposes.get(id) ?? 'evidence');
    }
    resourceEvent(apply, 'maintenance-request', command.requestId, `Maintenance draft ${str(row, 'request_number')} amended.`);
  });
}

function prepareRequestSubmit(env: Environment, command: MaintenanceRequestSubmitCommand): Preparation {
  const row = one(env.database, 'SELECT id,request_number,member_id,account_id,reason,draft_json,state,updated_at FROM maintenance_requests WHERE dataset_id=? AND id=?', env.datasetId, command.requestId); if (row === undefined) return reject('not_found', 'The maintenance request does not exist.');
  if (str(row, 'state') !== 'draft') return reject('ineligible', 'Only draft requests can be submitted.');
  if (str(row, 'updated_at') !== command.expectedUpdatedAt) return reject('stale_version', 'This request changed after you opened it. Reopen it before submitting.');
  let draft: unknown; try { draft = JSON.parse(str(row, 'draft_json')); } catch { return reject('validation', 'The request draft is not valid JSON.'); }
  const requestedCommand = draftRequestedCommand(draft);
  if (requestedCommand === null) return reject('ineligible', 'The request draft does not contain an exact supported maintenance command.');
  const commandIssue = requestedCommandProblem(requestedCommand, str(row, 'member_id'), optionalStr(row, 'account_id'));
  if (commandIssue !== null) return reject('ineligible', commandIssue);
  const missing = draft !== null && typeof draft === 'object' && !Array.isArray(draft) && Array.isArray((draft as { missingFields?: unknown }).missingFields) ? (draft as { missingFields: unknown[] }).missingFields : [];
  if (optionalStr(row, 'reason') === null || optionalStr(row, 'reason')?.trim() === '' || missing.length > 0) return reject('ineligible', 'Complete the request reason and every missing field before submitting.');
  const updatedAt = nextUpdatedAt(str(row, 'updated_at'), env.now);
  return prepared(str(row, 'request_number'), { requestId: command.requestId, state: 'submitted', updatedAt, businessChangeApplied: false }, ['Submits only the request state; no account or member business fields are changed.'], (apply) => {
    run(apply.database, 'UPDATE maintenance_requests SET state=?,updated_at=? WHERE dataset_id=? AND id=?', 'submitted', updatedAt, apply.datasetId, command.requestId);
    resourceEvent(apply, 'maintenance-request', command.requestId, `Maintenance request ${str(row, 'request_number')} submitted.`);
  });
}

function prepareRequestReview(env: Environment, command: MaintenanceRequestReviewCommand): Preparation {
  const row = one(env.database, 'SELECT id,request_number,member_id,account_id,draft_json,state,updated_at FROM maintenance_requests WHERE dataset_id=? AND id=?', env.datasetId, command.requestId);
  if (row === undefined) return reject('not_found', 'The maintenance request does not exist.');
  if (str(row, 'state') !== 'submitted') return reject('ineligible', 'Only a submitted maintenance request can be reviewed.');
  if (str(row, 'updated_at') !== command.expectedUpdatedAt) return reject('stale_version', 'The maintenance request changed after the checker opened it.');
  const maker = one(env.database, `SELECT actor_id FROM business_events WHERE dataset_id=? AND resource_kind='maintenance-request' AND resource_id=?
    ORDER BY sequence LIMIT 1`, env.datasetId, command.requestId);
  if (maker === undefined) return reject('ineligible', 'Maintenance request has no attributable maker event.');
  if (str(maker, 'actor_id') === env.actorId) return reject('not_authorized', 'The request maker cannot perform its checker review.');
  const reason = cleanText(command.reason); const reasonIssue = problem(reason, 'Review reason', 500); if (reasonIssue !== null) return reject('validation', reasonIssue, { field: 'reason' });
  const missingFields = [...(command.missingFields ?? [])].map(cleanText);
  if (command.decision === 'return-for-information') {
    if (missingFields.length === 0 || missingFields.length > 20 || missingFields.some(field => field.length === 0 || field.length > 100) || new Set(missingFields).size !== missingFields.length) {
      return reject('validation', 'Return-for-information requires 1 to 20 unique missing fields.', { field: 'missingFields' });
    }
  } else if (command.missingFields !== undefined) return reject('validation', 'Missing fields apply only to return-for-information.', { field: 'missingFields' });
  let draft: Record<string, unknown>;
  try { const value: unknown = JSON.parse(str(row, 'draft_json')); draft = value !== null && typeof value === 'object' && !Array.isArray(value) ? { ...(value as Record<string, unknown>) } : {}; }
  catch { return reject('validation', 'The request draft is not valid JSON.'); }
  const requestedCommand = draftRequestedCommand(draft);
  if (requestedCommand === null) return reject('ineligible', 'The request draft does not contain an exact supported maintenance command.');
  const commandIssue = requestedCommandProblem(requestedCommand, str(row, 'member_id'), optionalStr(row, 'account_id'));
  if (commandIssue !== null) return reject('ineligible', commandIssue);
  const state = command.decision === 'approve' ? 'approved' : command.decision === 'reject' ? 'rejected' : 'draft';
  draft.review = { decision: command.decision, reason, checkerActorId: env.actorId, reviewedAt: env.now,
    requestedCommandDigest: commandIntentDigest(requestedCommand) };
  if (command.decision === 'return-for-information') draft.missingFields = missingFields;
  const updatedAt = nextUpdatedAt(str(row, 'updated_at'), env.now);
  return prepared(str(row, 'request_number'), { requestId: command.requestId, state, decision: command.decision, updatedAt, businessChangeApplied: false },
    ['Records an attributable checker disposition; approval remains distinct from applying any business change.'], (apply) => {
      const review = resultRecord(draft.review);
      if (review === null) throw new Error('Prepared maintenance review is invalid.');
      review.approvalEventSequence = (optionalInt(one(apply.database, 'SELECT MAX(sequence) AS maximum FROM business_events WHERE dataset_id=?', apply.datasetId), 'maximum') ?? 0) + 1;
      run(apply.database, 'UPDATE maintenance_requests SET state=?,draft_json=?,updated_at=? WHERE dataset_id=? AND id=?', state, canonicalJson(draft), updatedAt, apply.datasetId, command.requestId);
      resourceEvent(apply, 'maintenance-request', command.requestId, `Checker ${command.decision}: ${reason}`);
  });
}

function resultRecord(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null;
}

function contactPostcondition(env: Environment, command: Extract<MaintenanceRequestedCommand, { kind: 'contact.update' }>, result: Record<string, unknown>): boolean {
  if (result.memberId !== command.memberId || result.version !== command.expectedVersion + 1) return false;
  const member = memberRow(env, command.memberId); if (member === undefined || int(member, 'version') < command.expectedVersion + 1) return false;
  const partyId = str(member, 'party_id');
  const currentContactValue = (kind: 'email' | 'phone'): string | null => optionalStr(one(env.database, `SELECT value FROM contact_points WHERE dataset_id=? AND party_id=? AND kind=? AND valid_to IS NULL
    ORDER BY valid_from DESC,id LIMIT 1`, env.datasetId, partyId, kind), 'value');
  if (command.email !== undefined) {
    const expected = command.email === null || cleanText(command.email) === '' ? null : cleanText(command.email);
    if (currentContactValue('email') !== expected) return false;
  }
  if (command.phone !== undefined) {
    const expected = command.phone === null || cleanText(command.phone) === '' ? null : cleanText(command.phone);
    if (currentContactValue('phone') !== expected) return false;
  }
  if (command.address !== undefined) {
    const expected = normalizedAddress(command.address);
    const current = one(env.database, `SELECT a.line1,a.line2,a.city,a.region,a.postal_code,a.country FROM party_addresses pa
      JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
      WHERE pa.dataset_id=? AND pa.party_id=? AND pa.purpose='mailing' AND pa.valid_to IS NULL ORDER BY pa.valid_from DESC,pa.id LIMIT 1`, env.datasetId, partyId);
    if (current === undefined || str(current, 'line1') !== expected.line1 || optionalStr(current, 'line2') !== expected.line2
      || str(current, 'city') !== expected.city || str(current, 'region') !== expected.region || str(current, 'postal_code') !== expected.postalCode
      || str(current, 'country') !== expected.country) return false;
  }
  return true;
}

function maintenancePostcondition(env: Environment, command: MaintenanceRequestedCommand, resultValue: unknown, effectActorId: string): boolean {
  const result = resultRecord(resultValue); if (result === null) return false;
  switch (command.kind) {
    case 'contact.update': return contactPostcondition(env, command, result);
    case 'member.note.add': {
      if (result.memberId !== command.memberId || typeof result.noteId !== 'string') return false;
      const note = one(env.database, 'SELECT member_id,actor_id,visibility,text FROM member_notes WHERE dataset_id=? AND id=?', env.datasetId, result.noteId);
      return note !== undefined && str(note, 'member_id') === command.memberId && str(note, 'actor_id') === effectActorId
        && str(note, 'visibility') === command.visibility && str(note, 'text') === cleanText(command.text);
    }
    case 'account.nickname.update': {
      if (result.accountId !== command.accountId || result.nickname !== cleanText(command.nickname) || result.version !== command.expectedVersion + 1) return false;
      const account = accountRow(env, command.accountId);
      return account !== undefined && int(account, 'version') >= command.expectedVersion + 1
        && str(one(env.database, 'SELECT nickname FROM accounts WHERE dataset_id=? AND id=?', env.datasetId, command.accountId), 'nickname') === cleanText(command.nickname);
    }
    case 'account.statement_delivery.update': {
      if (result.accountId !== command.accountId || result.statement_delivery !== command.statementDelivery || result.version !== command.expectedVersion + 1) return false;
      const account = accountRow(env, command.accountId);
      return account !== undefined && int(account, 'version') >= command.expectedVersion + 1
        && str(one(env.database, 'SELECT statement_delivery FROM accounts WHERE dataset_id=? AND id=?', env.datasetId, command.accountId), 'statement_delivery') === command.statementDelivery;
    }
    case 'account.close': {
      const account = one(env.database, 'SELECT status,closed_at,version FROM accounts WHERE dataset_id=? AND id=?', env.datasetId, command.accountId);
      return result.accountId === command.accountId && result.status === 'closed' && account !== undefined && str(account, 'status') === 'closed'
        && optionalStr(account, 'closed_at') !== null && int(account, 'version') >= command.expectedVersion + 1;
    }
  }
}

function prepareRequestProcess(env: Environment, command: MaintenanceRequestProcessCommand): Preparation {
  const row = one(env.database, 'SELECT id,request_number,member_id,account_id,draft_json,state,updated_at FROM maintenance_requests WHERE dataset_id=? AND id=?', env.datasetId, command.requestId);
  if (row === undefined) return reject('not_found', 'The maintenance request does not exist.');
  if (str(row, 'state') !== 'approved') return reject('ineligible', 'Only an approved maintenance request can be processed.');
  if (str(row, 'updated_at') !== command.expectedUpdatedAt) return reject('stale_version', 'The approved request changed after it was opened for processing.');
  const reason = cleanText(command.reason); const reasonIssue = problem(reason, 'Processing reason', 500); if (reasonIssue !== null) return reject('validation', reasonIssue, { field: 'reason' });
  if (command.disposition === 'reject' && command.appliedReceiptId !== undefined) return reject('validation', 'A rejected request cannot reference an applied receipt.', { field: 'appliedReceiptId' });
  let draft: unknown; try { draft = JSON.parse(str(row, 'draft_json')); } catch { return reject('validation', 'The request draft is not valid JSON.'); }
  const requestedCommand = draftRequestedCommand(draft);
  if (requestedCommand === null) return reject('ineligible', 'The approved request does not contain an exact supported maintenance command.');
  const commandIssue = requestedCommandProblem(requestedCommand, str(row, 'member_id'), optionalStr(row, 'account_id'));
  if (commandIssue !== null) return reject('ineligible', commandIssue);
  const reviewValue = draft !== null && typeof draft === 'object' && !Array.isArray(draft) ? (draft as Record<string, unknown>).review : undefined;
  const approval = resultRecord(reviewValue);
  const requestedCommandDigest = commandIntentDigest(requestedCommand);
  if (approval === null || approval.decision !== 'approve' || typeof approval.reviewedAt !== 'string' || validateInstant(approval.reviewedAt, 'Approval time') !== null
    || typeof approval.checkerActorId !== 'string' || typeof approval.approvalEventSequence !== 'number' || !Number.isSafeInteger(approval.approvalEventSequence)
    || approval.approvalEventSequence < 1 || approval.requestedCommandDigest !== requestedCommandDigest) return reject('ineligible', 'The approved request is not bound to its exact current command terms.');
  const approvalEvent = one(env.database, `SELECT e.operation_id FROM business_events e JOIN operations o ON o.dataset_id=e.dataset_id AND o.id=e.operation_id
    WHERE e.dataset_id=? AND e.sequence=? AND e.resource_kind='maintenance-request' AND e.resource_id=? AND e.actor_id=?
      AND e.kind='maintenance.request.review' AND o.operation_kind='maintenance.request.review' AND o.status='committed'`,
  env.datasetId, approval.approvalEventSequence, command.requestId, approval.checkerActorId);
  if (approvalEvent === undefined) return reject('ineligible', 'The approved request has no matching durable checker event.');
  let appliedReceiptId: string | null = null;
  if (command.disposition === 'apply') {
    if (command.appliedReceiptId === undefined) return reject('validation', 'Applied processing requires the exact receipt for the previously committed business change.', { field: 'appliedReceiptId' });
    const receiptRow = one(env.database, `SELECT r.id,o.id AS operation_id,o.operation_kind,o.command_digest,o.occurred_at,o.status FROM operation_receipts r JOIN operations o
      ON o.dataset_id=r.dataset_id AND o.id=r.operation_id WHERE r.dataset_id=? AND r.id=?`, env.datasetId, command.appliedReceiptId);
    if (receiptRow === undefined || str(receiptRow, 'operation_kind') !== requestedCommand.kind || str(receiptRow, 'command_digest') !== requestedCommandDigest
      || str(receiptRow, 'status') !== 'committed') return reject('ownership_mismatch', 'Applied receipt does not match the exact approved command.');
    const durableReceipt = loadReceipt(env.database, env.datasetId, { operationId: str(receiptRow, 'operation_id') });
    if (durableReceipt === undefined || str(receiptRow, 'occurred_at') < approval.reviewedAt || durableReceipt.committedAt < approval.reviewedAt) {
      return reject('ineligible', 'Applied receipt must be committed after the exact request was approved.');
    }
    const effectPermissions = actorPermissions(env.database, env.datasetId, env.institutionId, durableReceipt.actor.id, str(receiptRow, 'occurred_at'));
    if (!CAPABILITY_GRANTS[requestedCommand.kind].some(grant => effectPermissions.has(grant))) return reject('not_authorized', 'Applied receipt actor was not authorized for the approved command.');
    if (one(env.database, 'SELECT id FROM maintenance_requests WHERE dataset_id=? AND applied_receipt_id=? AND id<>?', env.datasetId, command.appliedReceiptId, command.requestId) !== undefined) {
      return reject('ineligible', 'The applied receipt is already linked to another maintenance request.');
    }
    const accountId = optionalStr(row, 'account_id');
    const target = one(env.database, `SELECT sequence FROM business_events WHERE dataset_id=? AND operation_id=? AND sequence>? AND
      ((resource_kind='member' AND resource_id=?) OR (? IS NOT NULL AND resource_kind='account' AND resource_id=?)) ORDER BY sequence LIMIT 1`,
    env.datasetId, str(receiptRow, 'operation_id'), approval.approvalEventSequence, str(row, 'member_id'), accountId, accountId);
    if (target === undefined) return reject('ineligible', 'Applied receipt must have a scope-matched effect committed after the checker approval.');
    if (!maintenancePostcondition(env, requestedCommand, durableReceipt.result, durableReceipt.actor.id)) return reject('ineligible', 'Applied receipt does not establish the approved current postcondition.');
    appliedReceiptId = command.appliedReceiptId;
  }
  const state = command.disposition === 'apply' ? 'applied' : 'rejected'; const updatedAt = nextUpdatedAt(str(row, 'updated_at'), env.now);
  return prepared(str(row, 'request_number'), { requestId: command.requestId, state, appliedReceiptId, updatedAt, businessChangeApplied: appliedReceiptId !== null },
    ['Records the terminal request disposition and links only a separately committed, scope-matched business receipt.'], (apply) => {
      run(apply.database, 'UPDATE maintenance_requests SET state=?,updated_at=?,applied_receipt_id=? WHERE dataset_id=? AND id=?', state, updatedAt, appliedReceiptId, apply.datasetId, command.requestId);
      resourceEvent(apply, 'maintenance-request', command.requestId, appliedReceiptId === null ? `Processing rejected: ${reason}` : `Applied business receipt ${appliedReceiptId}: ${reason}`);
    });
}

function prepareRequestWithdraw(env: Environment, command: MaintenanceRequestWithdrawCommand): Preparation {
  const row = one(env.database, 'SELECT id,request_number,state,updated_at,applied_receipt_id FROM maintenance_requests WHERE dataset_id=? AND id=?', env.datasetId, command.requestId); if (row === undefined) return reject('not_found', 'The maintenance request does not exist.');
  if (str(row, 'updated_at') !== command.expectedUpdatedAt) return reject('stale_version', 'This request changed after you opened it. Reopen it before withdrawing.');
  if (optionalStr(row, 'applied_receipt_id') !== null) return reject('ineligible', 'An applied request cannot be withdrawn.');
  if (!['draft', 'submitted', 'approved'].includes(str(row, 'state'))) return reject('ineligible', 'This request is already terminal.');
  const reason = cleanText(command.reason); const issue = problem(reason, 'Withdrawal reason', 500); if (issue !== null) return reject('validation', issue, { field: 'reason' });
  const updatedAt = nextUpdatedAt(str(row, 'updated_at'), env.now);
  return prepared(str(row, 'request_number'), { requestId: command.requestId, state: 'withdrawn', updatedAt, appliedEffects: [] }, ['Withdraws an unprocessed request and reports that no business effects were applied.'], (apply) => {
    run(apply.database, 'UPDATE maintenance_requests SET state=?,reason=?,updated_at=? WHERE dataset_id=? AND id=?', 'withdrawn', reason, updatedAt, apply.datasetId, command.requestId);
    resourceEvent(apply, 'maintenance-request', command.requestId, `Maintenance request ${str(row, 'request_number')} withdrawn.`);
  });
}

function normalizedRegion(command: DocumentAnnotationUpdateCommand): string | null {
  const { x, y, width, height } = command.regionMicros;
  if (![x, y, width, height].every(value => Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000) || width <= 0 || height <= 0 || x + width > 1_000_000 || y + height > 1_000_000) return null;
  return JSON.stringify({ x: x / 1_000_000, y: y / 1_000_000, width: width / 1_000_000, height: height / 1_000_000 });
}

function prepareAnnotationUpdate(env: Environment, command: DocumentAnnotationUpdateCommand): Preparation {
  const version = documentVersion(env, command.documentVersionId); if (version === undefined) return reject('not_found', 'The document version does not exist.');
  const pageCount = optionalInt(version, 'page_count') ?? 1; if (!Number.isSafeInteger(command.pageNumber) || command.pageNumber < 1 || command.pageNumber > pageCount) return reject('validation', 'Annotation page is outside the document version.');
  const region = normalizedRegion(command); if (region === null) return reject('validation', 'Annotation region must be normalized within the page.');
  if (command.action !== 'remove' && (command.text === undefined || problem(command.text, 'Annotation text', 2000) !== null)) return reject('validation', 'Annotation text is required.', { field: 'text' });
  if (command.action === 'remove' && command.text !== undefined) return reject('validation', 'Removing an annotation does not replace its historical text.', { field: 'text' });
  const existing = command.annotationId === undefined ? undefined : one(env.database, 'SELECT id,document_version_id,actor_id,page_number,region_json,text,status,created_at FROM document_annotations WHERE dataset_id=? AND id=?', env.datasetId, command.annotationId);
  if (command.action === 'create' && existing !== undefined) return reject('ineligible', 'Annotation already exists.');
  if (command.action !== 'create' && (existing === undefined || str(existing, 'document_version_id') !== command.documentVersionId)) return reject('not_found', 'The annotation does not exist on this document version.');
  if (command.action === 'create' && command.expectedAnnotationFingerprint !== undefined) return reject('validation', 'A new annotation cannot include an existing annotation fingerprint.', { field: 'expectedAnnotationFingerprint' });
  if (command.action !== 'create') {
    if (existing === undefined) return reject('not_found', 'The annotation does not exist.');
    if (str(existing, 'status') === 'removed') return reject('ineligible', 'A removed annotation is terminal and cannot be amended or removed again.');
    if (command.expectedAnnotationFingerprint === undefined) return reject('validation', 'The reviewed annotation fingerprint is required.', { field: 'expectedAnnotationFingerprint' });
    const fingerprint = rowFingerprint(existing, ['id', 'document_version_id', 'actor_id', 'page_number', 'region_json', 'text', 'status', 'created_at']);
    if (fingerprint !== command.expectedAnnotationFingerprint) return reject('stale_version', 'The annotation changed after review. Reopen it before updating.');
    if (command.action === 'remove' && (int(existing, 'page_number') !== command.pageNumber || str(existing, 'region_json') !== region)) return reject('validation', 'Removal must retain the annotation page and region reviewed in the fingerprint.');
  }
  const id = command.annotationId ?? `document-annotation-${randomUUID()}`; const status = command.action === 'remove' ? 'removed' : command.action === 'amend' ? 'amended' : 'active';
  return prepared(id, { annotationId: id, versionId: command.documentVersionId, page: command.pageNumber, action: command.action }, ['Anchors one annotation to an immutable document version and exact normalized region.'], (apply) => {
    if (command.action === 'create') run(apply.database, `INSERT INTO document_annotations (dataset_id,id,document_version_id,actor_id,page_number,region_json,text,status,created_at) VALUES (?,?,?,?,?,?,?,?,?)`, apply.datasetId, id, command.documentVersionId, apply.actorId, command.pageNumber, region, cleanText(command.text ?? ''), status, apply.now);
    else if (command.action === 'remove') run(apply.database, "UPDATE document_annotations SET status='removed' WHERE dataset_id=? AND id=?", apply.datasetId, id);
    else run(apply.database, `UPDATE document_annotations SET page_number=?,region_json=?,text=?,status=? WHERE dataset_id=? AND id=?`, command.pageNumber, region, cleanText(command.text ?? ''), status, apply.datasetId, id);
    resourceEvent(apply, 'document-annotation', id, `Document annotation ${command.action}d on ${command.documentVersionId}.`);
  });
}

function prepareMetadataUpdate(env: Environment, command: DocumentMetadataUpdateCommand): Preparation {
  const document = one(env.database, 'SELECT id,owner_party_id,account_id,document_type,display_name,retention_class FROM documents WHERE dataset_id=? AND id=?', env.datasetId, command.documentId); if (document === undefined) return reject('not_found', 'The document does not exist.');
  const expected = command.expectedMetadata;
  if (str(document, 'owner_party_id') !== expected.ownerPartyId || (optionalStr(document, 'account_id') ?? null) !== expected.accountId
    || str(document, 'document_type') !== expected.documentType || str(document, 'display_name') !== expected.displayName || str(document, 'retention_class') !== expected.retentionClass) {
    return reject('stale_version', 'The document metadata changed after you opened it. Reopen it before saving.');
  }
  const documentType = cleanText(command.documentType); const displayName = cleanText(command.displayName); const retentionClass = cleanText(command.retentionClass);
  for (const [field, value, maximum] of [['documentType', documentType, 80], ['displayName', displayName, 200], ['retentionClass', retentionClass, 80]] as const) {
    const issue = problem(value, field, maximum); if (issue !== null) return reject('validation', issue, { field });
  }
  if (one(env.database, 'SELECT id FROM parties WHERE dataset_id=? AND id=?', env.datasetId, command.ownerPartyId) === undefined) return reject('not_found', 'New owner party does not exist.');
  if (command.accountId !== null) { const account = accountRow(env, command.accountId); if (account === undefined) return reject('not_found', 'New account does not exist.'); if (str(account, 'party_id') !== command.ownerPartyId) return reject('ownership_mismatch', 'New account does not belong to new owner.'); }
  const latestVersion = one(env.database, 'SELECT id FROM document_versions WHERE dataset_id=? AND document_id=? ORDER BY version DESC LIMIT 1', env.datasetId, command.documentId); if (latestVersion === undefined) return reject('ineligible', 'Document has no immutable version.');
  if (!documentVersionIsVisible(env, str(latestVersion, 'id'))) return reject('not_found', 'The document does not exist.');
  if (str(document, 'owner_party_id') === command.ownerPartyId && (optionalStr(document, 'account_id') ?? null) === command.accountId
    && str(document, 'document_type') === documentType && str(document, 'display_name') === displayName && str(document, 'retention_class') === retentionClass) return { kind: 'unchanged', message: 'The document metadata already matches.' };
  const associationChanged = str(document, 'owner_party_id') !== command.ownerPartyId || (optionalStr(document, 'account_id') ?? null) !== command.accountId;
  const sensitiveTypeChanged = str(document, 'document_type') !== documentType
    && (ACCESS_SENSITIVE_DOCUMENT_TYPES.has(str(document, 'document_type')) || ACCESS_SENSITIVE_DOCUMENT_TYPES.has(documentType));
  const requiresApproval = associationChanged || sensitiveTypeChanged;
  if (!requiresApproval && command.approvalId !== undefined) return reject('validation', 'Independent approval is only accepted for an access-sensitive metadata change.', { field: 'approvalId' });
  if (associationChanged) {
    if (command.approvalId === undefined) return reject('not_authorized', 'Owner or account reassociation requires independent approval.', { field: 'approvalId' });
    const dependent = one(env.database, `SELECT
      EXISTS (SELECT 1 FROM retention_holds h WHERE h.dataset_id=? AND h.document_id=? AND h.state='active') AS active_hold,
      EXISTS (SELECT 1 FROM document_versions v JOIN case_documents cd ON cd.dataset_id=v.dataset_id AND cd.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS case_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN case_note_documents nd ON nd.dataset_id=v.dataset_id AND nd.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS case_note_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN request_attachments ra ON ra.dataset_id=v.dataset_id AND ra.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS request_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN signatures s ON s.dataset_id=v.dataset_id AND s.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS signature_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN consents c ON c.dataset_id=v.dataset_id AND c.disclosure_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS consent_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN communication_jobs j ON j.dataset_id=v.dataset_id AND j.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS communication_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN identity_evidence e ON e.dataset_id=v.dataset_id
        AND CASE WHEN json_valid(e.reference) THEN json_extract(e.reference,'$.documentVersionId') ELSE NULL END=v.id WHERE v.dataset_id=? AND v.document_id=?) AS identity_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN document_derivations dd ON dd.dataset_id=v.dataset_id
        AND (dd.source_version_id=v.id OR dd.derivative_version_id=v.id) WHERE v.dataset_id=? AND v.document_id=?) AS derivation_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN document_annotations a ON a.dataset_id=v.dataset_id AND a.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS annotation_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN document_access_events ae ON ae.dataset_id=v.dataset_id AND ae.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS access_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN batches b ON b.dataset_id=v.dataset_id AND b.input_document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS batch_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN dispute_evidence de ON de.dataset_id=v.dataset_id AND de.document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS dispute_link,
      EXISTS (SELECT 1 FROM document_versions v JOIN loan_closures lc ON lc.dataset_id=v.dataset_id AND lc.closure_document_version_id=v.id WHERE v.dataset_id=? AND v.document_id=?) AS loan_closure_link`,
    env.datasetId, command.documentId, env.datasetId, command.documentId, env.datasetId, command.documentId, env.datasetId, command.documentId,
    env.datasetId, command.documentId, env.datasetId, command.documentId, env.datasetId, command.documentId, env.datasetId, command.documentId,
    env.datasetId, command.documentId, env.datasetId, command.documentId, env.datasetId, command.documentId, env.datasetId, command.documentId,
    env.datasetId, command.documentId, env.datasetId, command.documentId);
    const dependencyColumns = ['active_hold', 'case_link', 'case_note_link', 'request_link', 'signature_link', 'consent_link', 'communication_link',
      'identity_link', 'derivation_link', 'annotation_link', 'access_link', 'batch_link', 'dispute_link', 'loan_closure_link'];
    if (dependent === undefined || dependencyColumns.some(column => int(dependent, column) !== 0)) {
      return reject('ineligible', 'Owner reassociation is blocked while any retained business, evidence, access, or document-lineage dependency remains.');
    }
    const ownerMembers = int(one(env.database, "SELECT COUNT(*) AS count FROM members WHERE dataset_id=? AND party_id=? AND status<>'merged'", env.datasetId, command.ownerPartyId), 'count');
    if (ownerMembers !== 1) return reject('ineligible', 'The new owner party does not resolve to exactly one active member.');
  }
  if (requiresApproval) {
    if (command.approvalId === undefined) return reject('not_authorized', 'This access-sensitive metadata change requires independent approval.', { field: 'approvalId' });
    const approval = requireApproval(env, command, command.approvalId); if (approval !== null) return approval;
  }
  const change = prepared(command.documentId, { documentId: command.documentId, ownerPartyId: command.ownerPartyId, accountId: command.accountId, documentType, associationChanged,
    accessPolicyChanged: sensitiveTypeChanged, accessReassessment: associationChanged ? { dependencyLinks: 0 } : null },
  [associationChanged ? 'Reassociates an unencumbered document under independent approval after checking every access-bearing dependency.' : sensitiveTypeChanged ? 'Changes an access-sensitive document type under independent approval.' : 'Corrects index metadata without changing document bytes or access associations.'], (apply) => {
    run(apply.database, 'UPDATE documents SET owner_party_id=?,account_id=?,document_type=?,display_name=?,retention_class=? WHERE dataset_id=? AND id=?', command.ownerPartyId, command.accountId, documentType, displayName, retentionClass, apply.datasetId, command.documentId);
    resourceEvent(apply, 'document', command.documentId, associationChanged ? 'Document metadata reassociated after approved dependency checks.' : 'Document index metadata corrected.');
  });
  return requiresApproval && command.approvalId !== undefined ? approvalPrepared(change, command.approvalId) : change;
}

function preparePreferenceUpdate(env: Environment, command: CommunicationPreferenceUpdateCommand): Preparation {
  if (one(env.database, 'SELECT id FROM parties WHERE dataset_id=? AND id=?', env.datasetId, command.partyId) === undefined) return reject('not_found', 'The party does not exist.');
  const purpose = cleanText(command.purpose); const channel = cleanText(command.channel);
  if (problem(purpose, 'Purpose', 100) !== null || problem(channel, 'Channel', 80) !== null) return reject('validation', 'Purpose and channel are required.');
  const existing = one(env.database, 'SELECT id,state FROM communication_preferences WHERE dataset_id=? AND party_id=? AND purpose=? AND channel=?', env.datasetId, command.partyId, purpose, channel);
  if (existing !== undefined && str(existing, 'state') === command.state) return { kind: 'unchanged', message: 'The communication preference already matches.' };
  const id = existing === undefined ? `communication-preference-${randomUUID()}` : str(existing, 'id');
  return prepared(id, { partyId: command.partyId, purpose, channel, state: command.state, legalConsentChanged: false }, ['Changes exactly one purpose/channel preference and leaves legal consent unchanged.'], (apply) => {
    if (existing === undefined) run(apply.database, 'INSERT INTO communication_preferences (dataset_id,id,party_id,purpose,channel,state,updated_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, id, command.partyId, purpose, channel, command.state, apply.now);
    else run(apply.database, 'UPDATE communication_preferences SET state=?,updated_at=? WHERE dataset_id=? AND id=?', command.state, apply.now, apply.datasetId, id);
    resourceEvent(apply, 'communication-preference', id, `Communication preference ${command.purpose}/${command.channel} set to ${command.state}.`);
  });
}

function addressDestinationForDelivery(env: Environment, destinationId: string): Row | undefined {
  return one(env.database, `SELECT d.id,d.context_kind,d.member_id,d.account_id,d.card_id,d.loan_id,d.party_address_id,d.evidence_version_id,d.consent_id,d.effective_at,d.ends_at,
    pa.party_id,pa.address_id,pa.evidence_status,pa.evidence_version_id AS address_evidence_version_id,pa.valid_from AS address_valid_from,pa.valid_to AS address_valid_to,
    a.line1,a.line2,a.city,a.region,a.postal_code,a.country,ev.status AS address_evidence_status,
    c.party_id AS consent_party_id,c.account_id AS consent_account_id,c.purpose AS consent_purpose,c.channel AS consent_channel,c.state AS consent_state,c.effective_at AS consent_effective_at,
    card.account_id AS card_account_id,loan.account_id AS loan_account_id
    FROM address_destinations d JOIN party_addresses pa ON pa.dataset_id=d.dataset_id AND pa.id=d.party_address_id
    JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
    JOIN document_versions ev ON ev.dataset_id=d.dataset_id AND ev.id=d.evidence_version_id
    LEFT JOIN consents c ON c.dataset_id=d.dataset_id AND c.id=d.consent_id
    LEFT JOIN cards card ON card.dataset_id=d.dataset_id AND card.id=d.card_id
    LEFT JOIN loans loan ON loan.dataset_id=d.dataset_id AND loan.id=d.loan_id
    WHERE d.dataset_id=? AND d.id=?`, env.datasetId, destinationId);
}

function addressDestinationDeliveryProblem(env: Environment, destination: Row): string | null {
  const endsAt = optionalStr(destination, 'ends_at');
  const addressValidTo = optionalStr(destination, 'address_valid_to');
  if (str(destination, 'effective_at') > env.now || endsAt !== null && endsAt <= env.now) return 'The postal address instruction is not effective.';
  if (str(destination, 'evidence_status') !== 'verified' || addressValidTo !== null && addressValidTo <= env.now
    || str(destination, 'address_valid_from') > env.now || str(destination, 'address_evidence_version_id') !== str(destination, 'evidence_version_id')
    || !['current', 'signed'].includes(str(destination, 'address_evidence_status'))) return 'The postal route is no longer backed by current verified address evidence.';
  const context = str(destination, 'context_kind') as AddressDestinationUpdateCommand['context'];
  const targetColumn = ADDRESS_DESTINATION_TARGET_COLUMN[context];
  const targetId = optionalStr(destination, targetColumn);
  if (targetId === null) return 'The postal address instruction has an invalid context target.';
  const latest = one(env.database, `SELECT id FROM address_destinations WHERE dataset_id=? AND context_kind=? AND ${targetColumn}=? AND effective_at<=? AND (ends_at IS NULL OR ends_at>?) ORDER BY effective_at DESC,id DESC LIMIT 1`,
    env.datasetId, context, targetId, env.now, env.now);
  if (latest === undefined || str(latest, 'id') !== str(destination, 'id')) return 'A newer postal address instruction is effective.';
  const consentId = optionalStr(destination, 'consent_id');
  if (consentId === null) return null;
  const consentEffectiveAt = optionalStr(destination, 'consent_effective_at');
  const accountId = optionalStr(destination, 'account_id') ?? optionalStr(destination, 'card_account_id') ?? optionalStr(destination, 'loan_account_id');
  const purpose = { 'member-mailing': 'servicing-notices', 'account-statement': 'account-statements', 'card-shipping': 'card-shipping', 'loan-notice': 'loan-notices' }[context];
  if (optionalStr(destination, 'consent_party_id') !== str(destination, 'party_id') || optionalStr(destination, 'consent_account_id') !== accountId
    || optionalStr(destination, 'consent_purpose') !== purpose || optionalStr(destination, 'consent_channel') !== 'mail'
    || optionalStr(destination, 'consent_state') !== 'granted' || consentEffectiveAt === null || consentEffectiveAt > env.now) {
    return 'The postal consent is no longer granted for this destination context.';
  }
  const latestConsent = one(env.database, `SELECT id FROM consents WHERE dataset_id=? AND party_id=? AND account_id IS ? AND purpose=? AND channel='mail' AND effective_at<=? ORDER BY effective_at DESC,id DESC LIMIT 1`,
    env.datasetId, str(destination, 'party_id'), accountId, purpose, env.now);
  return latestConsent === undefined || str(latestConsent, 'id') !== consentId ? 'A later postal consent decision prevents delivery.' : null;
}

function postalDestination(destination: Row): string {
  return [str(destination, 'line1'), optionalStr(destination, 'line2'), `${str(destination, 'city')}, ${str(destination, 'region')} ${str(destination, 'postal_code')}`, str(destination, 'country')]
    .filter((part): part is string => part !== null).join(', ');
}

function prepareCommunicationSend(env: Environment, command: CommunicationSendCommand): Preparation {
  if (one(env.database, 'SELECT id FROM parties WHERE dataset_id=? AND id=?', env.datasetId, command.partyId) === undefined) return reject('not_found', 'The recipient party does not exist.');
  const version = documentVersion(env, command.documentVersionId); if (version === undefined) return reject('not_found', 'The notice document version does not exist.');
  if (str(version, 'owner_party_id') !== command.partyId) return reject('ownership_mismatch', 'Notice is not owned by the recipient party.');
  if (str(version, 'status') === 'superseded') return reject('ineligible', 'A superseded document version cannot be queued as an approved notice.');
  const purpose = cleanText(command.purpose);
  const channel = cleanText(command.channel);
  let destination: string;
  let addressDestinationId: string | null = null;
  if (channel === 'email') {
    if (command.addressDestinationId !== undefined || command.destination === undefined) return reject('validation', 'Email delivery requires only an explicit destination email.', { field: 'destination' });
    destination = cleanText(command.destination);
    if (!/^\S+@\S+\.\S+$/u.test(destination)) return reject('validation', 'Destination email is invalid.', { field: 'destination' });
    const contact = one(env.database, `SELECT id FROM contact_points WHERE dataset_id=? AND party_id=? AND kind='email' AND valid_to IS NULL AND value=?`, env.datasetId, command.partyId, destination);
    if (contact === undefined) return reject('ownership_mismatch', 'Destination is not a current member contact.');
  } else if (channel === 'mail') {
    if (command.destination !== undefined || command.addressDestinationId === undefined) return reject('validation', 'Postal delivery requires one stored address destination and does not accept caller-supplied address text.', { field: 'addressDestinationId' });
    const instruction = addressDestinationForDelivery(env, command.addressDestinationId);
    if (instruction === undefined) return reject('not_found', 'The postal address instruction does not exist.', { field: 'addressDestinationId' });
    if (str(instruction, 'party_id') !== command.partyId) return reject('ownership_mismatch', 'The postal address instruction belongs to another party.', { field: 'addressDestinationId' });
    const instructionProblem = addressDestinationDeliveryProblem(env, instruction);
    if (instructionProblem !== null) return reject('ineligible', instructionProblem, { field: 'addressDestinationId' });
    const documentAccountId = optionalStr(version, 'account_id');
    const context = str(instruction, 'context_kind');
    const targetAccountId = optionalStr(instruction, 'account_id') ?? optionalStr(instruction, 'card_account_id') ?? optionalStr(instruction, 'loan_account_id');
    const contextMatches = purpose === 'account-statements' ? context === 'account-statement' && targetAccountId === documentAccountId
      : purpose === 'loan-notice' ? context === 'loan-notice' && targetAccountId === documentAccountId
      : purpose === 'card-replacement' ? context === 'card-shipping' && targetAccountId === documentAccountId
      : ['servicing', 'required-servicing'].includes(purpose) && context === 'member-mailing';
    if (!contextMatches) return reject('ownership_mismatch', 'The postal instruction does not match the notice purpose and account scope.', { field: 'addressDestinationId' });
    destination = postalDestination(instruction);
    addressDestinationId = command.addressDestinationId;
  } else return reject('validation', 'Only email and stored-address postal delivery are enabled in the local queue.', { field: 'channel' });
  if (!['servicing', 'required-servicing', 'card-replacement', 'account-statements', 'loan-notice'].includes(purpose)) {
    const pref = one(env.database, `SELECT state FROM communication_preferences WHERE dataset_id=? AND party_id=? AND purpose=? AND channel=?`, env.datasetId, command.partyId, purpose, channel);
    if (pref?.state !== 'enabled') return reject('ineligible', 'The purpose/channel preference is not enabled.');
  }
  if (purpose === 'account-statements' && channel === 'email') {
    if (effectiveConsentState(env, command.partyId, optionalStr(version, 'account_id'), 'account-statements', 'electronic') !== 'granted') {
      return reject('ineligible', 'Electronic statement consent is not granted for the notice account scope.');
    }
  }
  const jobId = command.jobId ?? `communication-job-${randomUUID()}`; if (one(env.database, 'SELECT id FROM communication_jobs WHERE dataset_id=? AND id=?', env.datasetId, jobId) !== undefined) return reject('ineligible', 'A communication job with this identity already exists.');
  const eventId = `communication-event-${randomUUID()}`;
  return prepared(jobId, { jobId, versionId: command.documentVersionId, recipient: destination, state: 'queued', delivered: false }, ['Queues one approved notice locally and never claims external delivery.'], (apply) => {
    run(apply.database, `INSERT INTO communication_jobs (dataset_id,id,party_id,document_version_id,address_destination_id,purpose,channel,destination,state,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)`, apply.datasetId, jobId, command.partyId, command.documentVersionId, addressDestinationId, purpose, channel, destination, 'queued', apply.now);
    run(apply.database, `INSERT INTO communication_events (dataset_id,id,job_id,sequence,state,occurred_at,detail) VALUES (?,?,?,?,?,?,?)`, apply.datasetId, eventId, jobId, 1, 'queued', apply.now, 'Accepted into local queue; delivery not asserted.');
    resourceEvent(apply, 'communication-job', jobId, `Queued ${purpose} notice for ${destination}.`);
    resourceEvent(apply, 'communication-event', eventId, 'Local queue accepted; delivery not asserted.');
  });
}

function deliveryIneligibility(env: Environment, job: Row): string | null {
  const destination = str(job, 'destination'); const channel = str(job, 'channel'); const partyId = str(job, 'party_id'); const purpose = str(job, 'purpose');
  const addressDestinationId = optionalStr(job, 'address_destination_id');
  if (addressDestinationId !== null) {
    const instruction = addressDestinationForDelivery(env, addressDestinationId);
    if (instruction === undefined || str(instruction, 'party_id') !== partyId || postalDestination(instruction) !== destination) return 'The queued postal address instruction no longer matches the recipient.';
    return addressDestinationDeliveryProblem(env, instruction);
  }
  const contactKind = channel === 'electronic' ? 'email' : channel;
  if (one(env.database, 'SELECT id FROM contact_points WHERE dataset_id=? AND party_id=? AND kind=? AND value=? AND valid_to IS NULL', env.datasetId, partyId, contactKind, destination) === undefined) {
    return 'The queued destination is no longer a current recipient contact.';
  }
  if (purpose === 'account-statements') {
    return effectiveConsentState(env, partyId, optionalStr(job, 'account_id'), 'account-statements', 'electronic') !== 'granted'
      ? 'Electronic statement consent is no longer granted for the notice account scope.' : null;
  }
  if (['servicing', 'required-servicing', 'card-replacement', 'missing-information'].includes(purpose)) return null;
  const preference = one(env.database, 'SELECT state FROM communication_preferences WHERE dataset_id=? AND party_id=? AND purpose=? AND channel=?', env.datasetId, partyId, purpose, channel);
  return preference === undefined || str(preference, 'state') !== 'enabled' ? 'The purpose and channel preference is no longer enabled.' : null;
}

function prepareCommunicationDeliveryUpdate(env: Environment, command: CommunicationDeliveryUpdateCommand): Preparation {
  const permissions = actorPermissions(env.database, env.datasetId, env.institutionId, env.actorId, env.now);
  if (env.principalKind !== 'system' || !permissions.has('communication.delivery.record')) return reject('not_authorized', 'Only the authorized local delivery callback can update delivery state.');
  const job = one(env.database, `SELECT j.id,j.party_id,j.document_version_id,j.address_destination_id,j.purpose,j.channel,j.destination,j.state,d.account_id
    FROM communication_jobs j JOIN document_versions v ON v.dataset_id=j.dataset_id AND v.id=j.document_version_id
    JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE j.dataset_id=? AND j.id=?`, env.datasetId, command.jobId);
  if (job === undefined) return reject('not_found', 'The communication job does not exist.');
  const current = str(job, 'state');
  if (current !== command.expectedState) return reject('stale_version', `Communication job changed after review (${command.expectedState} is now ${current}).`);
  if (command.action === 'accept' && current !== 'queued') return reject('invalid_transition', 'Only a queued communication can be accepted.');
  const detail = cleanText(command.detail); const detailIssue = problem(detail, 'Delivery detail', 500); if (detailIssue !== null) return reject('validation', detailIssue, { field: 'detail' });
  const consentProblem = command.action === 'deliver' ? deliveryIneligibility(env, job) : null;
  const state = consentProblem !== null ? 'cancelled' : command.action === 'accept' ? 'accepted' : command.action === 'deliver' ? 'delivered' : command.action === 'bounce' ? 'bounced' : 'cancelled';
  const eventId = `communication-event-${randomUUID()}`;
  return prepared(command.jobId, { jobId: command.jobId, requestedAction: command.action, state, delivered: state === 'delivered', consentRevalidated: command.action === 'deliver', cancellationReason: consentProblem },
    [consentProblem === null ? `Records the local ${state} callback without claiming a different delivery state.` : `Cancels delivery because current consent or destination validation failed: ${consentProblem}`], (apply) => {
      const sequence = (optionalInt(one(apply.database, 'SELECT MAX(sequence) AS maximum FROM communication_events WHERE dataset_id=? AND job_id=?', apply.datasetId, command.jobId), 'maximum') ?? 0) + 1;
      run(apply.database, 'UPDATE communication_jobs SET state=? WHERE dataset_id=? AND id=?', state, apply.datasetId, command.jobId);
      run(apply.database, 'INSERT INTO communication_events (dataset_id,id,job_id,sequence,state,occurred_at,detail) VALUES (?,?,?,?,?,?,?)',
        apply.datasetId, eventId, command.jobId, sequence, state, apply.now, consentProblem ?? detail);
      resourceEvent(apply, 'communication-job', command.jobId, `Local delivery state changed from ${current} to ${state}.`);
      resourceEvent(apply, 'communication-event', eventId, consentProblem ?? detail);
    });
}

/** Prepares servicing commands for the parent command pipeline. */
export function prepareServicing(env: Environment, command: ServicingCommand): Preparation {
  switch (command.kind) {
    case 'member.identity_evidence.register': return prepareIdentityEvidenceRegister(env, command);
    case 'member.identity.verify': return prepareIdentityVerify(env, command);
    case 'member.legal_name.update': return prepareLegalNameUpdate(env, command);
    case 'member.preferred_name.update': return preparePreferredNameUpdate(env, command);
    case 'document.index': return prepareDocumentIndex(env, command);
    case 'document.bundle.redact': return prepareDocumentRedact(env, command);
    case 'document.signature.collect': return prepareSignatureCollect(env, command);
    case 'consent.delivery.record': return prepareConsentRecord(env, command);
    case 'consent.withdraw': return prepareConsentWithdraw(env, command);
    case 'document.customer_export.create': return prepareCustomerExport(env, command);
    case 'document.retention_hold.apply': return prepareRetentionHold(env, command);
    case 'case.information.request': return prepareInformationRequest(env, command);
    case 'case.escalate': return prepareCaseEscalate(env, command);
    case 'maintenance.address.reconcile': return prepareAddressReconcile(env, command);
    case 'maintenance.address.destination.update': return prepareAddressDestinationUpdate(env, command);
    case 'case.close': return prepareCaseClose(env, command);
    case 'case.reopen': return prepareCaseReopen(env, command);
    case 'case.subject.correct': return prepareCaseSubjectCorrect(env, command);
    case 'maintenance.draft.save': return prepareDraftSave(env, command);
    case 'maintenance.draft.amend': return prepareDraftAmend(env, command);
    case 'maintenance.request.submit': return prepareRequestSubmit(env, command);
    case 'maintenance.request.review': return prepareRequestReview(env, command);
    case 'maintenance.request.process': return prepareRequestProcess(env, command);
    case 'maintenance.request.withdraw': return prepareRequestWithdraw(env, command);
    case 'document.annotation.update': return prepareAnnotationUpdate(env, command);
    case 'document.metadata.update': return prepareMetadataUpdate(env, command);
    case 'communication.preference.update': return preparePreferenceUpdate(env, command);
    case 'communication.send': return prepareCommunicationSend(env, command);
    case 'communication.delivery.update': return prepareCommunicationDeliveryUpdate(env, command);
  }
}
