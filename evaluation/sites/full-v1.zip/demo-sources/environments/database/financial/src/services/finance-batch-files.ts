/** Parses the bounded RFC-4180 subset emitted and accepted by financial batch services. */
export function parseFinanceCsv(bytes: Uint8Array): string[][] | null {
  if (bytes.byteLength === 0 || bytes.byteLength > 8_000_000) return null;
  let input: string;
  try { input = new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch { return null; }
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < input.length; index += 1) {
    const character = input[index];
    if (character === undefined) return null;
    if (quoted) {
      if (character === '"' && input[index + 1] === '"') { field += '"'; index += 1; }
      else if (character === '"') quoted = false;
      else field += character;
    } else if (character === '"' && field.length === 0) quoted = true;
    else if (character === ',') { row.push(field); field = ''; }
    else if (character === '\r' && input[index + 1] === '\n') { row.push(field); rows.push(row); row = []; field = ''; index += 1; }
    else if (character === '"' || character === '\r' || character === '\n' || character === '\0') return null;
    else field += character;
    if (field.length > 10_000 || rows.length > 10_000) return null;
  }
  if (quoted || row.length > 0 || field.length > 0 || rows.length === 0) return null;
  return rows;
}
