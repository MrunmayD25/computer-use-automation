import type { FinanceCommand } from './finance-types.js';
import type { ServicingCommand } from './servicing-types.js';
import type { Money } from './types.js';

export type ApprovalCommand =
  | { kind: 'approval.request'; target: FinanceCommand | ServicingCommand; checkerActorId: string; policyVersionId: string; expiresAt: string; amountLimit: Money | null }
  | { kind: 'approval.decide'; approvalId: string; expectedFingerprint: string; decision: 'approve' | 'deny'; reason: string };

export const APPROVAL_GRANTS = {
  'approval.request': ['maintain', 'payment.prepare', 'payment.approve', 'supervise', 'case.manage'],
  'approval.decide': ['payment.approve', 'supervise', 'financial.correction.approve', 'transfer.internal.reverse', 'interest.adjust', 'transaction.effective-date.correct'],
} as const;
