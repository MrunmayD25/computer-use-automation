import { authorizeQuery, datasetClock, one, reject, str } from './core.js';
import {
  accountDetail, accountTransactions, caseDetail, institutionSummary, listActivity, memberDetail, operatorProfile,
  receiptByIdempotencyKey, receiptByNumber, searchAccounts, searchCases, searchMembers, statementData,
  type AccountDetail, type AccountSearch, type ActivitySearch, type CaseSearch, type MemberSearch, type TransactionSearch,
} from './queries.js';
import type { FinancialStore } from './store.js';
import type { Rejection, ServiceContext } from './types.js';

export type CoreQuery =
  | { kind: 'institution.context.verify' }
  | { kind: 'member.search'; search: MemberSearch }
  | { kind: 'member.inspect'; memberId: string }
  | { kind: 'account.list'; search: AccountSearch }
  | { kind: 'account.inquire'; memberId: string; accountId: string; balanceType: 'posted' | 'available' | 'both' }
  | { kind: 'transaction.search'; accountId: string; search: TransactionSearch }
  | { kind: 'statement.inspect'; accountId: string; period: string }
  | { kind: 'activity.inspect'; search: ActivitySearch }
  | { kind: 'receipt.inspect'; receiptNumber: string }
  | { kind: 'operation.inspect'; idempotencyKey: string }
  | { kind: 'case.search'; search: CaseSearch }
  | { kind: 'case.inspect'; caseId: string };

export interface AccountInquiry extends AccountDetail { requestedMemberId: string; requestedBalance: {type:'posted'|'available'|'both';currency:string;postedMinorUnits?:number;availableMinorUnits?:number} }

type CoreQueryValue = AccountInquiry | ReturnType<typeof accountDetail | typeof accountTransactions | typeof caseDetail | typeof listActivity | typeof memberDetail | typeof receiptByIdempotencyKey | typeof searchAccounts | typeof searchCases | typeof searchMembers | typeof statementData>
  | { institution: ReturnType<typeof institutionSummary>; operator: ReturnType<typeof operatorProfile> };
export type CoreQueryOutcome = { kind: 'queried'; value: CoreQueryValue; truncated: boolean } | Rejection;

const fields = {
  'institution.context.verify': [], 'member.search': ['search'], 'member.inspect': ['memberId'],
  'account.list': ['search'], 'account.inquire': ['memberId','accountId','balanceType'], 'transaction.search': ['accountId', 'search'],
  'statement.inspect': ['accountId', 'period'], 'activity.inspect': ['search'], 'receipt.inspect': ['receiptNumber'],
  'operation.inspect': ['idempotencyKey'], 'case.search': ['search'], 'case.inspect': ['caseId'],
} as const;

const searchFields: Readonly<Record<string, readonly string[]>> = {
  'member.search': ['limit', 'offset', 'ids', 'query', 'field', 'match', 'status', 'sort', 'direction'],
  'account.list': ['limit', 'offset', 'ids', 'memberId', 'ownershipRole', 'query', 'status', 'currency', 'sort', 'direction'],
  'transaction.search': ['limit', 'offset', 'startDate', 'endDate', 'direction', 'minMinorUnits', 'maxMinorUnits', 'text', 'order', 'status', 'reference'],
  'activity.inspect': ['limit', 'offset', 'memberId', 'accountId', 'caseId', 'kind', 'actorId', 'query'],
  'case.search': ['limit', 'offset', 'ids', 'memberId', 'accountId', 'states', 'queueId', 'queueIds', 'assignedActorId', 'priority', 'overdue', 'query', 'sort', 'direction'],
};

function searchProblem(kind: string, search: object): Rejection | null {
  const allowed = searchFields[kind];
  if (allowed === undefined) return reject('validation', 'This query has no search options.');
  for (const [field, value] of Object.entries(search)) {
    if (!allowed.includes(field)) return reject('validation', `Unknown search option ${field}.`);
    if (value === undefined) continue;
    const valid = ['limit', 'offset', 'minMinorUnits', 'maxMinorUnits'].includes(field) ? Number.isSafeInteger(value) && Number(value) >= 0
      : ['ids', 'states', 'queueIds'].includes(field) ? Array.isArray(value) && value.length <= 500 && value.every(item => typeof item === 'string')
      : field === 'overdue' ? typeof value === 'boolean'
      : field === 'assignedActorId' && value === null ? true : typeof value === 'string';
    if (!valid) return reject('validation', `Invalid search option ${field}.`);
  }
  return null;
}

/** Executes an ordinary application inquiry inside one authorized database snapshot. */
export function queryCore(store: FinancialStore, context: ServiceContext, query: CoreQuery): CoreQueryOutcome {
  if (!isQueryKind(query)) return reject('validation', 'Unknown core query.');
  const allowed: readonly string[] = fields[query.kind];
  if (Object.keys(query).some(key => key !== 'kind' && !allowed.includes(key)) || allowed.some(key => !Object.hasOwn(query, key))) return reject('validation', 'Invalid query fields.');
  for (const field of allowed) {
    const value: unknown = Reflect.get(query, field);
    if (field === 'search' ? value === null || typeof value !== 'object' || Array.isArray(value) : typeof value !== 'string') return reject('validation', `Invalid ${field}.`, { field });
    if (field === 'search' && typeof value === 'object' && value !== null) {
      const invalid = searchProblem(query.kind, value);
      if (invalid !== null) return invalid;
    }
  }
  return store.read(database => {
    const denied = authorizeQuery(database, context);
    if (denied !== null) return denied;
    const datasetId = context.binding.datasetId;
    const now = new Date(context.now ?? datasetClock(database, datasetId).asOf).toISOString();
    const reader = { institutionId: context.binding.institutionId, actorId: context.actorId, now };
    try {
      let value: CoreQueryValue;
      switch (query.kind) {
        case 'institution.context.verify': {
          const actor = one(database, 'SELECT actor_number FROM actors WHERE dataset_id=? AND id=?', datasetId, context.actorId);
          value = { institution: institutionSummary(database, datasetId), operator: operatorProfile(database, datasetId, context.binding.institutionId, str(actor, 'actor_number'), now) };
          break;
        }
        case 'member.search': value = searchMembers(database, datasetId, query.search); break;
        case 'member.inspect': value = memberDetail(database, datasetId, query.memberId, reader); break;
        case 'account.list': value = searchAccounts(database, datasetId, query.search, now); break;
        case 'account.inquire': {
          if (!['posted','available','both'].includes(query.balanceType)) return reject('validation','Unsupported balance type.');
          const linked = searchAccounts(database,datasetId,{memberId:query.memberId,ids:[query.accountId],limit:1,offset:0},now).items[0];
          if (linked === undefined) return reject('not_found','The account is absent from the requested member scope.');
          const detail = accountDetail(database,datasetId,query.accountId,now);
          if (detail === undefined) return reject('not_found','The account no longer exists.');
          value = {...detail,account:{...detail.account,memberRoles:linked.memberRoles},requestedMemberId:query.memberId,requestedBalance:{type:query.balanceType,currency:detail.account.currency,...(query.balanceType==='available'?{}:{postedMinorUnits:detail.account.postedMinorUnits}),...(query.balanceType==='posted'?{}:{availableMinorUnits:detail.account.availableMinorUnits})}};
          break;
        }
        case 'transaction.search': value = accountTransactions(database, datasetId, query.accountId, query.search); break;
        case 'statement.inspect': value = statementData(database, datasetId, query.accountId, query.period, now); break;
        case 'activity.inspect': value = listActivity(database, datasetId, query.search); break;
        case 'receipt.inspect': value = receiptByNumber(database, datasetId, query.receiptNumber); break;
        case 'operation.inspect': value = receiptByIdempotencyKey(database, datasetId, query.idempotencyKey); break;
        case 'case.search': value = searchCases(database, datasetId, query.search, now); break;
        case 'case.inspect': value = caseDetail(database, datasetId, query.caseId, reader); break;
      }
      return value === undefined ? reject('not_found', 'The requested record is absent from this institution and dataset.') : { kind: 'queried', value, truncated: 'items' in value && 'total' in value && 'offset' in value ? value.offset + value.items.length < value.total : false };
    } catch (error) {
      if (error instanceof RangeError) return reject('validation', error.message);
      throw error;
    }
  });
}

function isQueryKind(value: unknown): value is CoreQuery {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const kind: unknown = Reflect.get(value, 'kind');
  return typeof kind === 'string' && Object.hasOwn(fields, kind);
}
