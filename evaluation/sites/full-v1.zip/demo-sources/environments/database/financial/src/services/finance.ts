import type { Environment, Preparation } from './commands.js';
import { reject } from './core.js';
import { prepareFinanceLending } from './finance-lending.js';
import { prepareFinanceMember } from './finance-members.js';
import { prepareFinancePayments } from './finance-payments.js';
import { prepareFinanceReconciliation } from './finance-reconciliation.js';
import type { FinanceCommand } from './finance-types.js';

/** Prepares one full-v1 financial command against current state without performing side effects. */
export function prepareFinance(env: Environment, command: FinanceCommand): Preparation {
  const preparation = prepareFinanceMember(env, command)
    ?? prepareFinancePayments(env, command)
    ?? prepareFinanceLending(env, command)
    ?? prepareFinanceReconciliation(env, command);
  return preparation ?? reject('validation', `Financial command ${command.kind} has no preparation handler.`);
}
