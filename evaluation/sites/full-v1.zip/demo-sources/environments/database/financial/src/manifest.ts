import type { InstitutionSeed, SeedManifest } from './model.js';

export const DEFAULT_SEED_MANIFEST: SeedManifest = Object.freeze({
  name: 'financial-demo-v1',
  generatorVersion: '2',
  schemaVersion: 2,
  seed: 20_260_911,
  asOf: '2026-09-14T15:00:00.000Z',
  scale: 'standard',
  institutions: Object.freeze([
    Object.freeze({ id: 'northstar', legalName: 'Northstar Mutual Financial Cooperative', displayName: 'Northstar', timeZone: 'America/Chicago', defaultCurrency: 'USD' as const }),
    Object.freeze({ id: 'riverton', legalName: 'Riverton Community Financial', displayName: 'Riverton', timeZone: 'America/New_York', defaultCurrency: 'USD' as const }),
    Object.freeze({ id: 'harbor', legalName: 'Harbor Cooperative Bank', displayName: 'Harbor', timeZone: 'America/Los_Angeles', defaultCurrency: 'USD' as const }),
  ]),
});


function record(value: unknown, label: string, keys: readonly string[]): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) throw new Error(`${label} must be an object.`);
  const result = value as Record<string, unknown>;
  const unexpected = Object.keys(result).filter(key => !keys.includes(key));
  if (unexpected.length > 0) throw new Error(`${label} contains unexpected fields: ${unexpected.join(', ')}.`);
  return result;
}

function requiredText(value: unknown, label: string, maximum = 120): string {
  if (typeof value !== 'string' || value.trim().length === 0 || value.length > maximum || Array.from(value).some(character => character.charCodeAt(0) < 32)) throw new Error(`${label} must be nonempty text up to ${maximum} characters.`);
  return value;
}

function institutionSeed(value: unknown): InstitutionSeed {
  const input = record(value,'Institution',['id','legalName','displayName','timeZone','defaultCurrency']);
  const id = requiredText(input.id,'Institution ID',64);
  if (!/^[a-z][a-z0-9-]*$/.test(id)) throw new Error('Institution ID must use lowercase letters, digits and hyphens.');
  const timeZone = requiredText(input.timeZone,'Institution time zone');
  try { new Intl.DateTimeFormat('en-US',{timeZone}).format(0); }
  catch { throw new Error(`Institution time zone ${timeZone} is invalid.`); }
  const currency = input.defaultCurrency;
  if (currency !== 'USD' && currency !== 'EUR' && currency !== 'JPY' && currency !== 'KWD') throw new Error('Institution currency is unsupported.');
  return {id,legalName:requiredText(input.legalName,'Institution legal name'),displayName:requiredText(input.displayName,'Institution display name'),timeZone,defaultCurrency:currency};
}

export function validateSeedManifest(value: unknown): SeedManifest {
  const input = record(value,'Seed manifest',['name','generatorVersion','schemaVersion','seed','asOf','scale','institutions']);
  const name = requiredText(input.name,'Seed world name');
  if (input.generatorVersion !== '2' || input.schemaVersion !== 2) throw new Error('Seed manifest version is unsupported.');
  const seed = input.seed;
  if (typeof seed !== 'number' || !Number.isSafeInteger(seed) || seed < 0 || seed > 0x7fff_ffff) throw new Error('Seed must be an integer from 0 through 2147483647.');
  if (input.asOf !== '2026-09-14T15:00:00.000Z') throw new Error('Seed as-of instant must be 2026-09-14T15:00:00.000Z.');
  const scale = input.scale;
  if (scale !== 'small' && scale !== 'standard' && scale !== 'capacity') throw new Error('Seed scale is unsupported.');
  if (!Array.isArray(input.institutions) || input.institutions.length !== 3) throw new Error('Seed manifest must define exactly three institutions.');
  const institutions = Array.from(input.institutions, institutionSeed);
  if (new Set(institutions.map(institution => institution.id)).size !== institutions.length) throw new Error('Institution IDs must be distinct.');
  return {name,generatorVersion:'2',schemaVersion:2,seed,asOf:input.asOf,scale,institutions};
}
