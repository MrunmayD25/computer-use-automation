import { constants } from 'node:buffer';
import { randomUUID } from 'node:crypto';
import { chmodSync, closeSync, mkdirSync, openSync, readFileSync, realpathSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { isDeepStrictEqual } from 'node:util';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { backup, DatabaseSync, type SQLOutputValue } from 'node:sqlite';
import { attachSnapshot, captureSnapshot, closeSnapshot, digest, freeze, inheritSnapshot, PRIVATE_PREFIX, quote, replaySnapshot, schemaDigest, tableShapes, valueOf } from './run-storage.js';
import type { CapturedRow, CapturedTransaction, CapturedValue, CreateRunOptions, RowChange, RunDescriptor, RunEvidence, RunLimits, RunSnapshot, RunSqlDatabase, VerificationRun, WriteContext } from './run-types.js';

import { closeRunEvidence, fileDigest, loadRunEvidence, registerEvidence } from './evidence.js';
export { loadRunEvidence } from './evidence.js';
export type * from './run-types.js';
const DEFAULT_LIMITS: RunLimits = { maxRows: 1_000_000, maxChanges: 100_000, maxBlobBytes: 1_073_741_824, maxSnapshotBytes: 268_435_456, busyTimeoutMs: 5_000 };
type Authorizer = (action: number, first: string | null, second: string | null, databaseName: string | null, triggerName: string | null) => number;
type AuthorizingDatabase = DatabaseSync & { setAuthorizer(authorizer: Authorizer | null): void };
const SQLITE = {
  ok: 0,
  deny: 1,
  createIndex: 1,
  createTable: 2,
  createTemporaryIndex: 3,
  createTemporaryTable: 4,
  createTemporaryTrigger: 5,
  createTemporaryView: 6,
  createTrigger: 7,
  createView: 8,
  delete: 9,
  dropIndex: 10,
  dropTable: 11,
  dropTemporaryIndex: 12,
  dropTemporaryTable: 13,
  dropTemporaryTrigger: 14,
  dropTemporaryView: 15,
  dropTrigger: 16,
  dropView: 17,
  insert: 18,
  pragma: 19,
  transaction: 22,
  update: 23,
  attach: 24,
  detach: 25,
  alterTable: 26,
  reindex: 27,
  analyze: 28,
  createVirtualTable: 29,
  dropVirtualTable: 30,
} as const;
const SCHEMA_ACTIONS = new Set<number>([
  SQLITE.createIndex,
  SQLITE.createTable,
  SQLITE.createTemporaryIndex,
  SQLITE.createTemporaryTable,
  SQLITE.createTemporaryTrigger,
  SQLITE.createTemporaryView,
  SQLITE.createTrigger,
  SQLITE.createView,
  SQLITE.dropIndex,
  SQLITE.dropTable,
  SQLITE.dropTemporaryIndex,
  SQLITE.dropTemporaryTable,
  SQLITE.dropTemporaryTrigger,
  SQLITE.dropTemporaryView,
  SQLITE.dropTrigger,
  SQLITE.dropView,
  SQLITE.alterTable,
  SQLITE.reindex,
  SQLITE.analyze,
  SQLITE.createVirtualTable,
  SQLITE.dropVirtualTable,
]);
const DATA_CHANGE_ACTIONS = new Set<number>([SQLITE.delete, SQLITE.insert, SQLITE.update]);
const READ_ONLY_PRAGMAS = new Set(['foreign_key_check', 'foreign_key_list', 'index_info', 'index_list', 'table_info', 'table_xinfo', 'user_version']);
type CallbackMode = 'prepare' | 'read' | 'write';
const STATEMENT_METHODS = new Set<PropertyKey>(['all', 'columns', 'get', 'iterate', 'run', 'setAllowBareNamedParameters', 'setAllowUnknownNamedParameters', 'setReadBigInts', 'setReturnArrays']);
const STATEMENT_PROPERTIES = new Set<PropertyKey>(['expandedSQL', 'sourceSQL']);
function connect(path: string, limits: RunLimits): DatabaseSync {
  const database = new DatabaseSync(path);
  database.exec(`PRAGMA foreign_keys=ON; PRAGMA recursive_triggers=ON; PRAGMA busy_timeout=${limits.busyTimeoutMs}`);
  return database;
}
function persist(path: string, bytes: string | Uint8Array): void {
  mkdirSync(dirname(path), { recursive: true });
  const temporary = `${path}.${randomUUID()}.tmp`;
  const file = openSync(temporary, 'wx', 0o600);
  try {
    try { writeFileSync(file, bytes); }
    finally { closeSync(file); }
    renameSync(temporary, path);
  } catch (error) {
    rmSync(temporary, { force: true });
    throw error;
  }
}
function parsedRecord(value: unknown, label: string): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error(`Invalid ${label}.`);
  return value as Record<string, unknown>;
}
function authorizing(database: DatabaseSync): AuthorizingDatabase {
  const candidate = database as Partial<AuthorizingDatabase>;
  if (typeof candidate.setAuthorizer !== 'function') throw new Error('Verification writes require Node SQLite authorizer support.');
  return database as AuthorizingDatabase;
}
function installCallbackAuthorizer(database: DatabaseSync, mode: CallbackMode, captureTriggers: ReadonlySet<string> = new Set()): () => void {
  const controlled = authorizing(database);
  controlled.setAuthorizer((action, first, second, _databaseName, triggerName) => {
    if (action === SQLITE.attach || action === SQLITE.detach || action === SQLITE.transaction) return SQLITE.deny;
    if (action === SQLITE.pragma) {
      const readOnly = first !== null && READ_ONLY_PRAGMAS.has(first.toLowerCase()) && (second === null || first.toLowerCase() !== 'user_version');
      const deferredForeignKeys = first?.toLowerCase() === 'defer_foreign_keys' && ['1', 'on', 'true'].includes(second?.toLowerCase() ?? '');
      return readOnly || deferredForeignKeys ? SQLITE.ok : SQLITE.deny;
    }
    if (mode !== 'prepare' && SCHEMA_ACTIONS.has(action)) return SQLITE.deny;
    if (mode === 'read' && DATA_CHANGE_ACTIONS.has(action)) return SQLITE.deny;
    if (DATA_CHANGE_ACTIONS.has(action) && first?.startsWith(PRIVATE_PREFIX)) {
      const captureInsert = action === SQLITE.insert
        && first === '__verification_changes'
        && triggerName !== null
        && captureTriggers.has(triggerName);
      return captureInsert ? SQLITE.ok : SQLITE.deny;
    }
    return SQLITE.ok;
  });
  return () => controlled.setAuthorizer(null);
}
function guardIterator<T extends object>(iterator: T, assertActive: () => void): T {
  const guarded = new Proxy(Object.create(null) as object, {
    get(_target, property) {
      assertActive();
      if (property === Symbol.iterator) return () => guarded;
      if (!['next', 'return', 'throw'].includes(String(property))) throw new Error('Iterator property is outside the run SQL interface.');
      const value = Reflect.get(iterator, property, iterator) as unknown;
      if (typeof value !== 'function') return value;
      return (...args: unknown[]): unknown => {
        assertActive();
        return Reflect.apply(value, iterator, args) as unknown;
      };
    },
    set: () => false,
    defineProperty: () => false,
    deleteProperty: () => false,
    getPrototypeOf: () => null,
  });
  return guarded as T;
}
function guardStatement<T extends object>(statement: T, assertActive: () => void): T {
  return new Proxy(Object.create(null) as object, {
    get(_target, property) {
      assertActive();
      if (STATEMENT_PROPERTIES.has(property)) return Reflect.get(statement, property, statement) as unknown;
      if (!STATEMENT_METHODS.has(property)) throw new Error('Statement property is outside the run SQL interface.');
      const value = Reflect.get(statement, property, statement) as unknown;
      if (typeof value !== 'function') throw new Error('Run SQL statement method is unavailable.');
      return (...args: unknown[]) => {
        assertActive();
        const result = Reflect.apply(value, statement, args) as unknown;
        return property === 'iterate' && result !== null && typeof result === 'object'
          ? guardIterator(result, assertActive)
          : result;
      };
    },
    set: () => false,
    defineProperty: () => false,
    deleteProperty: () => false,
    getPrototypeOf: () => null,
  }) as T;
}
function guardDatabase(database: DatabaseSync): { database: RunSqlDatabase; deactivate(): void } {
  let active = true;
  const assertActive = (): void => {
    if (!active) throw new Error('Run callback database access ended with its transaction.');
  };
  const guarded = Object.assign(Object.create(null), {
    exec(sql: string): void {
      assertActive();
      database.exec(sql);
    },
    prepare(sql: string) {
      assertActive();
      return guardStatement(database.prepare(sql), assertActive);
    },
  }) as RunSqlDatabase;
  Object.freeze(guarded);
  return { database: guarded, deactivate: () => { active = false; } };
}
function parseRow(value: SQLOutputValue | undefined): CapturedRow | null {
  if (value === null) return null;
  if (typeof value !== 'string') throw new Error('Invalid captured row.');
  return parsedRecord(JSON.parse(value) as unknown, 'captured row') as CapturedRow;
}
function assertNoPrivateSchemaObjects(database: DatabaseSync): void {
  const object = database.prepare('SELECT type,name FROM sqlite_schema').all()
    .find((row) => String(row.name).startsWith(PRIVATE_PREFIX));
  if (object !== undefined) throw new Error(`Database contains reserved private verifier ${String(object.type)} ${String(object.name)}.`);
}
function installCapture(database: DatabaseSync, limits: RunLimits): Set<string> {
  const captureTriggers = new Set<string>();
  database.exec(`CREATE TABLE __verification_transactions (id TEXT PRIMARY KEY, context TEXT NOT NULL) STRICT;
    CREATE TABLE __verification_changes (sequence INTEGER PRIMARY KEY AUTOINCREMENT, transaction_id TEXT NOT NULL REFERENCES __verification_transactions(id), table_name TEXT NOT NULL, operation TEXT NOT NULL, row_key TEXT NOT NULL, before_json TEXT, after_json TEXT) STRICT;
    CREATE TRIGGER __verification_changes_no_update BEFORE UPDATE ON __verification_changes BEGIN SELECT RAISE(ABORT,'Capture is immutable'); END;
    CREATE TRIGGER __verification_changes_no_delete BEFORE DELETE ON __verification_changes BEGIN SELECT RAISE(ABORT,'Capture is immutable'); END;
    CREATE TRIGGER __verification_transactions_no_update BEFORE UPDATE ON __verification_transactions BEGIN SELECT RAISE(ABORT,'Capture is immutable'); END;
    CREATE TRIGGER __verification_transactions_no_delete BEFORE DELETE ON __verification_transactions BEGIN SELECT RAISE(ABORT,'Capture is immutable'); END;
    CREATE TRIGGER __verification_transactions_limit BEFORE INSERT ON __verification_transactions BEGIN SELECT CASE WHEN (SELECT COUNT(*) FROM __verification_transactions)>=${limits.maxChanges} THEN RAISE(ABORT,'Capture transaction limit exceeded') END; END;
    CREATE TRIGGER __verification_transactions_context BEFORE INSERT ON __verification_transactions BEGIN SELECT CASE WHEN NEW.id<>__verification_context() THEN RAISE(ABORT,'Invalid capture context') END; END;
    CREATE TRIGGER __verification_changes_context BEFORE INSERT ON __verification_changes BEGIN SELECT CASE WHEN NEW.transaction_id<>__verification_context() THEN RAISE(ABORT,'Invalid capture context') END; END;`);
  const image = (prefix: string, columns: readonly string[]): string => `__verification_row(${columns.flatMap((column) => [`'${column.replaceAll("'", "''")}'`, `${prefix}.${quote(column)}`]).join(',')})`;
  for (const [index, shape] of tableShapes(database).entries()) {
    for (const operation of ['insert', 'update', 'delete'] as const) {
      const triggerName = `${PRIVATE_PREFIX}${index}_${operation}`;
      const old = operation === 'insert' ? 'NULL' : image('OLD', shape.columns);
      const fresh = operation === 'delete' ? 'NULL' : image('NEW', shape.columns);
      const key = image(operation === 'insert' ? 'NEW' : 'OLD', shape.primaryKey);
      database.exec(`CREATE TRIGGER ${quote(triggerName)} AFTER ${operation.toUpperCase()} ON ${quote(shape.name)} BEGIN
        SELECT CASE WHEN (SELECT COUNT(*) FROM __verification_changes)>=${limits.maxChanges} THEN RAISE(ABORT,'Capture change limit exceeded') END;
        INSERT INTO __verification_changes(transaction_id,table_name,operation,row_key,before_json,after_json)
        VALUES (__verification_context(),'${shape.name.replaceAll("'", "''")}','${operation}',${key},${old},${fresh}); END;`);
      captureTriggers.add(triggerName);
    }
  }
  return captureTriggers;
}
function transactions(database: DatabaseSync): CapturedTransaction[] {
  return database.prepare('SELECT id,context FROM __verification_transactions ORDER BY rowid').all().map((transaction) => {
    const id = String(transaction.id);
    const context = parsedRecord(JSON.parse(String(transaction.context)) as unknown, 'write context') as unknown as WriteContext;
    const changes: RowChange[] = database.prepare('SELECT * FROM __verification_changes WHERE transaction_id=? ORDER BY sequence').all(id).map((row) => {
      const operation = row.operation;
      if (operation !== 'insert' && operation !== 'update' && operation !== 'delete') throw new Error('Invalid captured operation.');
      const key = parseRow(row.row_key);
      if (key === null) throw new Error('Missing captured primary key.');
      return { sequence: Number(row.sequence), transactionId: id, table: String(row.table_name), operation, key, before: parseRow(row.before_json), after: parseRow(row.after_json) };
    });
    return { id, context, changes };
  });
}
class Run implements VerificationRun {
  private state: 'prepared' | 'running' | 'sealed' | 'disposed' | 'closed' = 'prepared';
  private baseline: RunSnapshot | undefined;
  private evidence: RunEvidence | undefined;
  private baselineArtifact: RunEvidence['baseline'] | undefined;
  private captureSchema = '';
  private captureTriggers: ReadonlySet<string> = new Set();
  private active = false;
  private ownedDatabase: DatabaseSync | undefined;
  constructor(private info: RunDescriptor, private readonly limits: RunLimits) {}
  descriptor(): RunDescriptor { return this.info; }
  private check(state: 'prepared' | 'running'): void {
    if (this.active) throw new Error('A run transaction is already active.');
    if (this.state !== state) throw new Error(`Run must be ${state}; begin precedes writes and sealed runs cannot mutate.`);
  }
  prepare<T>(callback: (database: RunSqlDatabase) => T): T {
    this.check('prepared');
    return this.transact(undefined, callback);
  }
  private transact<T>(context: WriteContext | undefined, callback: (database: RunSqlDatabase) => T): T {
    const closeAfter = context === undefined;
    const database = closeAfter ? connect(this.info.databasePath, this.limits) : this.ownedDatabase;
    if (database === undefined) throw new Error('Running verification database is unavailable.');
    this.active = true;
    const id = randomUUID();
    let rowBytes = 0;
    database.function('__verification_context', () => id);
    database.function('__verification_row', { varargs: true, useBigIntArguments: true }, (...args: SQLOutputValue[]) => {
      const row: Record<string, CapturedValue> = {};
      for (let index = 0; index < args.length; index += 2) {
        const name = args[index]; const value = args[index + 1];
        if (typeof name !== 'string' || value === undefined) throw new Error('Invalid capture column arguments.');
        row[name] = valueOf(value, this.limits);
      }
      const encoded = JSON.stringify(row); rowBytes += Buffer.byteLength(encoded);
      if (rowBytes > this.limits.maxSnapshotBytes) throw new Error('Transaction capture byte limit exceeded.');
      return encoded;
    });
    database.exec('BEGIN IMMEDIATE');
    let removeAuthorizer: (() => void) | undefined;
    let deactivate: (() => void) | undefined;
    try {
      if (context !== undefined) database.prepare('INSERT INTO __verification_transactions VALUES (?,?)').run(id, JSON.stringify(context));
      removeAuthorizer = installCallbackAuthorizer(database, context === undefined ? 'prepare' : 'write', this.captureTriggers);
      const guarded = guardDatabase(database);
      deactivate = () => guarded.deactivate();
      const result = callback(guarded.database);
      deactivate();
      deactivate = undefined;
      removeAuthorizer();
      removeAuthorizer = undefined;
      if (result !== null && typeof result === 'object' && 'then' in result) throw new Error('Run transaction callbacks must be synchronous.');
      if (!database.isOpen || !database.isTransaction) throw new Error('Run callbacks must not close or end their transaction.');
      captureSnapshot(database, 'transaction-check', this.limits);
      database.exec('COMMIT');
      return result;
    } catch (error) {
      deactivate?.();
      removeAuthorizer?.();
      if (database.isOpen && database.isTransaction) database.exec('ROLLBACK');
      throw error;
    } finally { this.active = false; if (closeAfter && database.isOpen) database.close(); }
  }
  begin(): RunSnapshot {
    this.check('prepared');
    const database = connect(this.info.databasePath, this.limits);
    const baselinePath = join(dirname(this.info.evidencePath), 'baseline.sqlite');
    const temporary = `${baselinePath}.${randomUUID()}.tmp`;
    let baseline: RunSnapshot | undefined;
    let published = false;
    try {
      database.exec('PRAGMA locking_mode=EXCLUSIVE; BEGIN EXCLUSIVE');
      assertNoPrivateSchemaObjects(database);
      baseline = captureSnapshot(database, 'before', this.limits);
      database.exec('COMMIT');
      mkdirSync(dirname(baselinePath), { recursive: true });
      database.prepare('VACUUM INTO ?').run(temporary);
      chmodSync(temporary, 0o600);
      renameSync(temporary, baselinePath);
      published = true;
      const artifact = freeze({ file: 'baseline.sqlite' as const, ...fileDigest(baselinePath) });
      attachSnapshot(baseline, baselinePath, this.limits);
      database.exec('BEGIN EXCLUSIVE');
      const captureTriggers = installCapture(database, this.limits);
      const captureSchema = schemaDigest(database, true);
      const info = freeze({ ...this.info, schemaDigest: baseline.schemaDigest });
      persist(join(dirname(this.info.evidencePath), 'descriptor.json'), `${JSON.stringify(info)}\n`);
      database.exec('COMMIT');
      this.info = info;
      this.baseline = baseline;
      this.baselineArtifact = artifact;
      this.captureTriggers = captureTriggers;
      this.captureSchema = captureSchema;
      this.ownedDatabase = database;
      this.state = 'running';
      return baseline;
    } catch (error) {
      if (database.isTransaction) database.exec('ROLLBACK');
      if (baseline !== undefined) closeSnapshot(baseline);
      rmSync(temporary, { force: true });
      if (published) rmSync(baselinePath, { force: true });
      throw error;
    } finally { if (this.ownedDatabase !== database) database.close(); }
  }
  write<T>(context: WriteContext, callback: (database: RunSqlDatabase) => T): T {
    this.check('running');
    if (!['automation', 'human', 'peer', 'system'].includes(context.kind) || context.reference.trim().length === 0) throw new Error('A write requires trusted principal context and reference.');
    return this.transact(freeze({ ...context }), callback);
  }
  read<T>(callback: (database: RunSqlDatabase) => T): T {
    this.check('running');
    const database = this.ownedDatabase;
    if (database === undefined) throw new Error('Running verification database is unavailable.');
    this.active = true;
    database.exec('BEGIN');
    let removeAuthorizer: (() => void) | undefined;
    let deactivate: (() => void) | undefined;
    try {
      removeAuthorizer = installCallbackAuthorizer(database, 'read');
      const guarded = guardDatabase(database);
      deactivate = () => guarded.deactivate();
      const result = callback(guarded.database);
      deactivate();
      deactivate = undefined;
      removeAuthorizer();
      removeAuthorizer = undefined;
      if (result !== null && typeof result === 'object' && 'then' in result) throw new Error('Run transaction callbacks must be synchronous.');
      if (!database.isOpen || !database.isTransaction) throw new Error('Run callbacks must not close or end their transaction.');
      database.exec('COMMIT');
      return result;
    } catch (error) {
      deactivate?.();
      removeAuthorizer?.();
      if (database.isOpen && database.isTransaction) database.exec('ROLLBACK');
      throw error;
    } finally { this.active = false; }
  }
  snapshot(label: string): RunSnapshot {
    this.check('running');
    const database = this.ownedDatabase;
    const before = this.baseline;
    if (database === undefined || before === undefined) throw new Error('Running verification database is unavailable.');
    return replaySnapshot(before, transactions(database), label);
  }
  finish(): RunEvidence {
    if (this.evidence !== undefined) return this.evidence;
    this.check('running');
    const before = this.baseline;
    if (before === undefined) throw new Error('Missing run baseline.');
    const database = this.ownedDatabase;
    if (database === undefined) throw new Error('Running verification database is unavailable.');
    try {
      database.exec('BEGIN IMMEDIATE');
      const after = captureSnapshot(database, 'after', this.limits);
      const captured = transactions(database);
      const reconstructed = replaySnapshot(before, captured, 'after');
      const diagnostics = Object.keys(after.tables).filter((name) => !isDeepStrictEqual(after.tables[name], reconstructed.tables[name])).map((name) => `Capture does not reconstruct table ${name}.`);
      inheritSnapshot(after, reconstructed);
      if (schemaDigest(database, true) !== this.captureSchema || after.schemaDigest !== before.schemaDigest) diagnostics.push('Database or capture schema changed during the run.');
      const baseline = this.baselineArtifact;
      if (baseline === undefined) throw new Error('Missing immutable baseline artifact.');
      const body = { version: 2 as const, descriptor: this.info, baseline, limits: this.limits, before, after, transactions: captured, captureComplete: diagnostics.length === 0, diagnostics };
      const evidence = freeze({ ...body, digest: digest(body) });
      const encoded = `${JSON.stringify(evidence)}\n`;
      if (Buffer.byteLength(encoded, 'utf8') > constants.MAX_STRING_LENGTH) throw new Error('Uncompressed evidence byte limit exceeded.');
      persist(this.info.evidencePath, encoded);
      database.exec('COMMIT');
      this.evidence = registerEvidence(evidence, diagnostics);
      this.state = 'sealed';
      database.close();
      this.ownedDatabase = undefined;
      return evidence;
    } catch (error) {
      if (database.isTransaction) database.exec('ROLLBACK');
      throw error;
    }
  }
  dispose(options: { reportPath: string }): void {
    if (this.active || this.state === 'running' || this.state === 'prepared') throw new Error('Finish the run and persist its report before disposal.');
    const reportLocation = relative(dirname(this.info.databasePath), realpathSync(options.reportPath));
    if (!reportLocation.startsWith('..') && !isAbsolute(reportLocation)) throw new Error('The retained report must be outside the disposable run directory.');
    const report = parsedRecord(JSON.parse(readFileSync(options.reportPath, 'utf8')) as unknown, 'run report');
    if (report.runId !== this.info.runId || report.contractDigest !== this.info.contractDigest) throw new Error('Report runId or contractDigest does not match this run.');
    const evidence = loadRunEvidence(this.info.evidencePath);
    try {
      if (digest(evidence.descriptor) !== digest(this.info) || evidence.digest !== this.evidence?.digest) throw new Error('Retained evidence descriptor does not match this run.');
    } finally { closeRunEvidence(evidence); }
    rmSync(dirname(this.info.databasePath), { recursive: true, force: true });
    closeRunEvidence(this.evidence);
    this.state = 'disposed';
  }
  close(): void {
    if (this.active) throw new Error('Cannot close an active run transaction.');
    if (this.ownedDatabase?.isOpen) this.ownedDatabase.close();
    this.ownedDatabase = undefined;
    if (this.baseline !== undefined) closeSnapshot(this.baseline);
    if (this.evidence !== undefined) closeRunEvidence(this.evidence);
    this.state = 'closed';
  }
}
export async function createRun(options: CreateRunOptions): Promise<VerificationRun> {
  if (options.contractDigest.trim().length === 0 || options.bindings.length === 0) throw new Error('A run requires contract digest and source dataset bindings.');
  const limits = { ...DEFAULT_LIMITS, ...options.limits };
  for (const [name, value] of Object.entries(limits)) if (!Number.isSafeInteger(value) || value <= 0) throw new Error(`Invalid positive run limit ${name}.`);
  const runId = randomUUID();
  mkdirSync(resolve(options.root), { recursive: true });
  const root = realpathSync(options.root);
  const directory = join(root, 'runs', runId);
  const databasePath = join(directory, 'financial.sqlite');
  const evidencePath = join(root, 'evidence', runId, 'evidence.json');
  mkdirSync(directory, { recursive: true });
  const source = new DatabaseSync(resolve(options.sourcePath), { readOnly: true });
  try {
    source.exec('BEGIN');
    source.prepare('SELECT name FROM sqlite_schema LIMIT 1').get();
    await backup(source, databasePath);
    source.exec('COMMIT');
  }
  catch (error) { rmSync(directory, { recursive: true, force: true }); throw error; }
  finally { source.close(); }
  const database = connect(databasePath, limits);
  try {
    assertNoPrivateSchemaObjects(database);
    for (const binding of options.bindings) if (database.prepare('SELECT id FROM datasets WHERE id=? AND institution_id=?').get(binding.datasetId, binding.institutionId) === undefined) throw new Error('Invalid institution/dataset binding.');
    const descriptor = freeze({ runId, contractDigest: options.contractDigest, databasePath, evidencePath, bindings: options.bindings.map((binding) => ({ ...binding })), schemaDigest: schemaDigest(database) });
    return new Run(descriptor, limits);
  } catch (error) { rmSync(directory, { recursive: true, force: true }); throw error; }
  finally { database.close(); }
}
