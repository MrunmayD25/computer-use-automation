import { createHash } from 'node:crypto';
import type { CoreSeedReferences, SeedContext } from './contract.js';
import { zonedInstant } from '../services/core.js';

const currencies = ['USD', 'EUR', 'JPY', 'KWD'] as const;
const givenNames = ['Alex', 'Alex', 'Mara', 'Andre', 'Lin', 'Evelyn', 'Jonah', 'Zoë', 'José', 'Amina', 'Mei', 'Darius', 'Sofía', 'Theo', 'Fatima', 'Noah'];
const familyNames = ['Morgan', 'Morgan', 'Vance', 'Vance', 'Morales', 'Kowalski', 'Patel', "O'Connor", 'García', 'Hassan', 'Chen', 'Cole', 'Rivera', 'Nguyen', 'Bennett', 'Fischer'];
const cities = ['Chicago', 'Evanston', 'Milwaukee', 'Madison', 'Minneapolis', 'St. Louis'];

function at<T>(values: readonly T[], index: number): T {
  const value = values[index];
  if (value === undefined) throw new Error(`Missing seed value at index ${index}.`);
  return value;
}

function isoMonth(asOf: string, monthsBack: number, day: number): string {
  const value = new Date(asOf);
  value.setUTCMonth(value.getUTCMonth() - monthsBack, day);
  value.setUTCHours(15, 0, 0, 0);
  return value.toISOString();
}

function insertTwoLineJournal(
  context: SeedContext,
  ordinal: string,
  debitLedgerAccountId: string,
  creditLedgerAccountId: string,
  amountMinorUnits: number,
  currency: string,
  occurredAt: string,
  description: string,
  operationId: string | null = null,
): string {
  const { database, binding } = context;
  const journalId = context.id('journal', ordinal);
  if (operationId === null) {
    operationId = context.id('posting-operation', ordinal);
    const fingerprint = createHash('sha256').update(JSON.stringify({ debitLedgerAccountId, creditLedgerAccountId, amountMinorUnits, currency, occurredAt, description })).digest('hex');
    database.prepare('INSERT INTO operations (dataset_id,id,actor_id,operation_kind,business_reference,idempotency_key,command_digest,status,occurred_at) VALUES (?,?,?,?,?,?,?,?,?)').run(
      binding.datasetId, operationId, context.id('actor', 2), 'journal-posting', `JR-${ordinal}`, `posting-${ordinal}`, fingerprint, 'committed', occurredAt,
    );
    database.prepare('INSERT INTO operation_receipts (dataset_id,id,operation_id,receipt_number,result_digest,committed_at) VALUES (?,?,?,?,?,?)').run(
      binding.datasetId, context.id('posting-receipt', ordinal), operationId, `RC-${ordinal}`, fingerprint, occurredAt,
    );
  }
  database.prepare('INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,?,?,?,?,?,?,NULL)').run(
    binding.datasetId, journalId, `JR-${ordinal}`, operationId, 'posted', occurredAt, occurredAt.slice(0, 10), description,
  );
  const line = database.prepare('INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,?,?)');
  line.run(binding.datasetId, journalId, 1, debitLedgerAccountId, currency, amountMinorUnits, 0, description);
  line.run(binding.datasetId, journalId, 2, creditLedgerAccountId, currency, 0, amountMinorUnits, description);
  return journalId;
}

function seedReferenceData(context: SeedContext): Pick<CoreSeedReferences, 'actorIds' | 'branchIds' | 'queueIds' | 'productIds' | 'glAccountIdsByCurrency'> {
  const { database, binding, institution } = context;
  const policyId = context.id('policy', 1);
  database.prepare('INSERT INTO policy_versions (dataset_id,id,name,version,effective_at,rules_json) VALUES (?,?,?,?,?,?)').run(
    binding.datasetId, policyId, `${institution.displayName} servicing policy`, '2026.3', '2026-01-01T00:00:00.000Z',
    JSON.stringify({
      transferLimitMinorUnits: 2_500_000,
      cardLimitMaximumMinorUnitsByCurrency: { USD: 2_500_000, EUR: 2_500_000, GBP: 2_500_000 },
      refundMakerCheckerThresholdMinorUnits: 50_000,
      accountAuthority: { minimumActiveNaturalPersonAuthorities: 1 },
      rounding: 'half-even',
      loanPayoff: { yearBasis: 365, rounding: 'half-even', quoteValidityDays: 7 },
      fees: ['USD', 'EUR', 'GBP'].flatMap(currency => [
        { code: 'monthly-service', currency, maximumMinorUnits: 2_500 },
        { code: 'document-copy', currency, maximumMinorUnits: 1_000 },
      ]),
      redaction: { enabled: true, maxExcerpts: 32, maxExcerptChars: 300 },
    }),
  );
  const holidayDates = new Set(['2026-01-01', '2026-07-03', '2026-09-07', '2026-11-26', '2026-12-25']);
  const calendarInsert = database.prepare('INSERT INTO calendar_days (dataset_id,local_date,calendar_version,is_business_day,payment_cutoff_at,label) VALUES (?,?,?,?,?,?)');
  for (let day = 0; day < 1827; day += 1) {
    const date = new Date('2024-01-01T00:00:00.000Z');
    date.setUTCDate(date.getUTCDate() + day);
    const localDate = date.toISOString().slice(0, 10);
    const weekend = date.getUTCDay() === 0 || date.getUTCDay() === 6;
    const holiday = holidayDates.has(localDate);
    calendarInsert.run(binding.datasetId, localDate, 'US-FI-2026.1', weekend || holiday ? 0 : 1, zonedInstant(localDate, '16:00', institution.timeZone), holiday ? 'Institution holiday' : null);
  }

  const branchIds = Array.from({ length: 3 }, (_, index) => context.id('branch', index + 1));
  const branchInsert = database.prepare('INSERT INTO branches (dataset_id,id,branch_number,name,time_zone) VALUES (?,?,?,?,?)');
  branchIds.forEach((id, index) => branchInsert.run(binding.datasetId, id, context.businessNumber('BR', index + 1, 3), at(['Central', 'Lakeside', 'North Market'], index), institution.timeZone));
  const queueCodes = ['GENERAL', 'PAYMENTS', 'DISPUTES', 'RESTRICTED'];
  const queueIds = queueCodes.map((_, index) => context.id('queue', index + 1));
  const queueInsert = database.prepare('INSERT INTO queues (dataset_id,id,code,name,visibility) VALUES (?,?,?,?,?)');
  queueIds.forEach((id, index) => queueInsert.run(binding.datasetId, id, at(queueCodes, index), `${at(queueCodes, index)} servicing`, index === 3 ? 'restricted' : index === 1 ? 'supervisor' : 'general'));

  const actorIds = Array.from({ length: 8 }, (_, index) => context.id('actor', index + 1));
  const actorInsert = database.prepare('INSERT INTO actors (dataset_id,id,actor_number,display_name,status) VALUES (?,?,?,?,?)');
  actorIds.forEach((id, index) => actorInsert.run(binding.datasetId, id, context.businessNumber('OP', index + 1, 4), at(['Jordan Lee', 'Casey Patel', 'Morgan Ellis', 'Taylor Brooks', 'Riley Chen', 'Avery Davis', 'Cameron Díaz', 'Samir Khan'], index), index === 7 ? 'disabled' : 'active'));
  const roleCodes = ['viewer', 'servicer', 'payments-maker', 'payments-checker', 'supervisor'];
  const roleIds = roleCodes.map((_, index) => context.id('role', index + 1));
  const roleInsert = database.prepare('INSERT INTO roles (dataset_id,id,code,name) VALUES (?,?,?,?)');
  const actorRoleInsert = database.prepare('INSERT INTO actor_roles (dataset_id,actor_id,role_id,starts_at,ends_at) VALUES (?,?,?,?,NULL)');
  const permissionInsert = database.prepare('INSERT INTO role_permissions (dataset_id,role_id,permission,scope_json) VALUES (?,?,?,?)');
  roleIds.forEach((id, index) => {
    roleInsert.run(binding.datasetId, id, at(roleCodes, index), at(roleCodes, index));
    permissionInsert.run(binding.datasetId, id, index === 0 ? 'read' : index === 1 ? 'maintain' : index === 2 ? 'payment.prepare' : index === 3 ? 'payment.approve' : 'supervise', JSON.stringify({ institutionId: institution.id }));
  });
  const institutionScope = JSON.stringify({ institutionId: institution.id });
  for (const permission of ['member.note.add', 'document.annotate', 'case.manage']) permissionInsert.run(binding.datasetId, at(roleIds, 1), permission, institutionScope);
  for (const permission of ['transfer.internal', 'transfer.internal.reverse', 'interest.accrual', 'interest.adjust', 'transaction.effective-date.correct']) permissionInsert.run(binding.datasetId, at(roleIds, 2), permission, institutionScope);
  permissionInsert.run(binding.datasetId, at(roleIds, 3), 'financial.correction.approve', institutionScope);
  for (const permission of ['signature.response.record','communication.delivery.record']) permissionInsert.run(binding.datasetId, at(roleIds, 4), permission, institutionScope);
  actorIds.forEach((actorId, index) => actorRoleInsert.run(binding.datasetId, actorId, at(roleIds, index % roleIds.length), '2024-01-01T00:00:00.000Z'));

  const productIds: string[] = [];
  const productInsert = database.prepare('INSERT INTO products (dataset_id,id,code,name,family,currency,status) VALUES (?,?,?,?,?,?,?)');
  const termInsert = database.prepare('INSERT INTO product_terms (dataset_id,id,product_id,version,effective_at,annual_rate_bps,rules_json) VALUES (?,?,?,?,?,?,?)');
  for (const currency of currencies) {
    for (const [type, rate] of [['checking', 10], ['savings', 240], ['term', 385], ['loan', 725], ['card', 1_899]] as const) {
      const productId = context.id('product', `${currency}-${type}`);
      const family = type === 'loan' ? 'loan' : type === 'card' ? 'card' : 'deposit';
      productIds.push(productId);
      productInsert.run(binding.datasetId, productId, `${currency}-${type}`.toUpperCase(), `${currency} ${type}`, family, currency, 'active');
      termInsert.run(binding.datasetId, context.id('product-term', `${currency}-${type}`), productId, '2026.1', '2026-01-01T00:00:00.000Z', rate, JSON.stringify({
        minimumOpeningMinorUnits: type === 'checking' ? 0 : 1000,
        maturityMonths: type === 'term' ? 12 : null,
        ...(type === 'loan' ? { loanApplication: { requiredEvidenceKinds: ['income-verification', 'credit-decision'] } } : {}),
      }));
    }
  }

  const glAccountIdsByCurrency: Record<string, { cash: string; opening: string; feeIncome: string; settlement: string }> = {};
  const ledgerInsert = database.prepare('INSERT INTO ledger_accounts (dataset_id,id,code,kind,currency,normal_side,customer_account_id) VALUES (?,?,?,?,?,?,NULL)');
  for (const currency of currencies) {
    const ids = {
      cash: context.id('gl', `${currency}-cash`),
      opening: context.id('gl', `${currency}-opening`),
      feeIncome: context.id('gl', `${currency}-fees`),
      settlement: context.id('gl', `${currency}-settlement`),
    };
    glAccountIdsByCurrency[currency] = ids;
    ledgerInsert.run(binding.datasetId, ids.cash, `${currency}-CASH`, 'cash', currency, 'debit');
    ledgerInsert.run(binding.datasetId, ids.opening, `${currency}-OPENING`, 'opening-equity', currency, 'credit');
    ledgerInsert.run(binding.datasetId, ids.feeIncome, `${currency}-FEE-INCOME`, 'fee-income', currency, 'credit');
    ledgerInsert.run(binding.datasetId, ids.settlement, `${currency}-SETTLEMENT`, 'settlement', currency, 'debit');
  }
  return { actorIds, branchIds, queueIds, productIds, glAccountIdsByCurrency };
}

export function seedCore(context: SeedContext): CoreSeedReferences {
  const reference = seedReferenceData(context);
  const { database, binding, profile } = context;
  const partyIds: string[] = [];
  const memberIds: string[] = [];
  const partyInsert = database.prepare('INSERT INTO parties (dataset_id,id,kind,display_name,created_at) VALUES (?,?,?,?,?)');
  const peopleInsert = database.prepare('INSERT INTO people (dataset_id,party_id,legal_given,legal_family,preferred_name,preferred_name_scope,birth_date,deceased_at) VALUES (?,?,?,?,?,?,?,?)');
  const organizationInsert = database.prepare('INSERT INTO organizations (dataset_id,party_id,legal_name,registration_number,organization_type) VALUES (?,?,?,?,?)');
  const memberInsert = database.prepare('INSERT INTO members (dataset_id,id,party_id,member_number,status,joined_at,tax_classification,version) VALUES (?,?,?,?,?,?,?,?)');
  const contactInsert = database.prepare('INSERT INTO contact_points (dataset_id,id,party_id,kind,purpose,value,valid_from,valid_to,verified_at) VALUES (?,?,?,?,?,?,?,?,?)');
  const addressInsert = database.prepare('INSERT INTO addresses (dataset_id,id,line1,line2,city,region,postal_code,country) VALUES (?,?,?,?,?,?,?,?)');
  const partyAddressInsert = database.prepare('INSERT INTO party_addresses (dataset_id,id,party_id,address_id,purpose,valid_from,valid_to,evidence_status) VALUES (?,?,?,?,?,?,?,?)');
  const evidenceInsert = database.prepare('INSERT INTO identity_evidence (dataset_id,id,party_id,kind,status,issued_at,expires_at,reference) VALUES (?,?,?,?,?,?,?,?)');
  for (let index = 0; index < profile.membersPerInstitution; index += 1) {
    const ordinal = index + 1;
    const given = at(givenNames, index % givenNames.length);
    const family = at(familyNames, index % familyNames.length);
    const partyId = context.id('party-person', ordinal);
    const memberId = context.id('member', ordinal);
    const status = index === profile.membersPerInstitution - 1 ? 'merged' : index % 41 === 0 && index > 0 ? 'deceased' : index % 37 === 0 && index > 0 ? 'inactive' : 'active';
    const evidenceStatus = index % 17 === 0 ? 'contradictory' : index % 13 === 0 ? 'expired' : index % 11 === 0 ? 'unverified' : 'verified';
    partyIds.push(partyId);
    memberIds.push(memberId);
    partyInsert.run(binding.datasetId, partyId, 'person', `${given} ${family}`, isoMonth(context.asOf, 60 + (index % 24), 1));
    const preferredName = index % 19 === 0 ? `Preferred ${given}` : null;
    peopleInsert.run(binding.datasetId, partyId, given, family, preferredName, preferredName === null ? null : 'all', `19${String(55 + (index % 40)).padStart(2, '0')}-${String(1 + (index % 12)).padStart(2, '0')}-${String(1 + (index % 27)).padStart(2, '0')}`, status === 'deceased' ? isoMonth(context.asOf, 8, 10) : null);
    memberInsert.run(binding.datasetId, memberId, partyId, context.businessNumber('NM', ordinal, 6), status, isoMonth(context.asOf, 48 + (index % 48), 2), index % 23 === 0 ? 'backup-withholding' : 'individual', 1 + (index % 4));
    contactInsert.run(binding.datasetId, context.id('email', ordinal), partyId, 'email', 'primary', `${given.toLocaleLowerCase('en-US').replaceAll(/[^a-z]/g, '')}.${family.toLocaleLowerCase('en-US').replaceAll(/[^a-z]/g, '')}${ordinal}@example.test`, isoMonth(context.asOf, 24, 1), null, evidenceStatus === 'verified' ? isoMonth(context.asOf, 12, 2) : null);
    contactInsert.run(binding.datasetId, context.id('phone', ordinal), partyId, 'phone', 'mobile', `312-555-${String(1000 + ordinal).padStart(4, '0')}`, isoMonth(context.asOf, 24, 1), null, isoMonth(context.asOf, 12, 2));
    const addressId = context.id('address', ordinal);
    addressInsert.run(binding.datasetId, addressId, `${100 + ordinal * 7} ${index % 2 === 0 ? 'Maple' : 'Oak'} Avenue`, index % 29 === 0 ? `Unit ${ordinal}` : null, at(cities, index % cities.length), index % 5 === 0 ? 'WI' : 'IL', String(60000 + (ordinal % 999)).padStart(5, '0'), 'US');
    partyAddressInsert.run(binding.datasetId, context.id('party-address', ordinal), partyId, addressId, 'mailing', isoMonth(context.asOf, 24, 1), null, evidenceStatus === 'contradictory' ? 'conflicting' : evidenceStatus);
    const evidenceId = context.id('evidence', ordinal);
    evidenceInsert.run(binding.datasetId, evidenceId, partyId, index % 3 === 0 ? 'passport' : 'drivers-license', evidenceStatus, isoMonth(context.asOf, 36, 1).slice(0, 10), evidenceStatus === 'expired' ? isoMonth(context.asOf, 2, 1).slice(0, 10) : isoMonth(context.asOf, -24, 1).slice(0, 10), `EV-${String(ordinal).padStart(7, '0')}`);
    database.prepare('INSERT INTO name_history (dataset_id,id,party_id,kind,given_name,family_name,valid_from,valid_to,evidence_id) VALUES (?,?,?,?,?,?,?,?,?)').run(binding.datasetId, context.id('name-history', ordinal), partyId, 'legal', given, family, isoMonth(context.asOf, 60, 1), null, evidenceId);
    database.prepare('INSERT INTO tax_status_history (dataset_id,id,member_id,classification,valid_from,valid_to,evidence_id) VALUES (?,?,?,?,?,?,?)').run(binding.datasetId, context.id('tax-history', ordinal), memberId, index % 23 === 0 ? 'backup-withholding' : 'individual', isoMonth(context.asOf, 36, 1), null, evidenceId);
  }
  for (let index = 0; index < profile.organizationsPerInstitution; index += 1) {
    const ordinal = profile.membersPerInstitution + index + 1;
    const partyId = context.id('party-organization', index + 1);
    const memberId = context.id('member', ordinal);
    partyIds.push(partyId);
    memberIds.push(memberId);
    const name = `${['Lakeview Foods', 'Prairie Works', 'North Market Cooperative', 'Juniper Studio', 'Harbor Medical', 'Common Ground Trust'][index % 6]} ${index + 1}`;
    partyInsert.run(binding.datasetId, partyId, 'organization', name, isoMonth(context.asOf, 72, 1));
    organizationInsert.run(binding.datasetId, partyId, name, `REG-${String(index + 1).padStart(8, '0')}`, index % 3 === 0 ? 'nonprofit' : 'corporation');
    memberInsert.run(binding.datasetId, memberId, partyId, context.businessNumber('NM', ordinal, 6), 'active', isoMonth(context.asOf, 48, 2), index % 3 === 0 ? 'tax-exempt' : 'organization', 1);
  }
  const relationshipInsert = database.prepare('INSERT INTO party_relationships (dataset_id,id,from_party_id,to_party_id,role,starts_at,ends_at) VALUES (?,?,?,?,?,?,NULL)');
  for (let index = 0; index + 1 < Math.min(24, partyIds.length); index += 2) {
    relationshipInsert.run(binding.datasetId, context.id('relationship', index + 1), at(partyIds, index), at(partyIds, index + 1), index % 4 === 0 ? 'guardian' : 'household', isoMonth(context.asOf, 48, 1));
  }
  const ownershipInsert = database.prepare('INSERT INTO organization_ownership (dataset_id,id,organization_party_id,owner_party_id,ownership_bps,is_control_person,starts_at,ends_at,evidence_id) VALUES (?,?,?,?,?,?,?,NULL,?)');
  for (let organizationIndex = 0; organizationIndex < profile.organizationsPerInstitution; organizationIndex += 1) {
    const organizationPartyId = context.id('party-organization', organizationIndex + 1);
    for (let ownerOffset = 0; ownerOffset < 2; ownerOffset += 1) {
      const ownerIndex = (organizationIndex * 2 + ownerOffset) % profile.membersPerInstitution;
      const ownerPartyId = at(partyIds, ownerIndex);
      relationshipInsert.run(binding.datasetId, context.id('relationship', `organization-${organizationIndex + 1}-${ownerOffset + 1}`), organizationPartyId, ownerPartyId, 'beneficial-owner', isoMonth(context.asOf, 48, 1));
      ownershipInsert.run(binding.datasetId, context.id('organization-ownership', `${organizationIndex + 1}-${ownerOffset + 1}`), organizationPartyId, ownerPartyId, ownerOffset === 0 ? 6_000 : 4_000, ownerOffset === 0 ? 1 : 0, isoMonth(context.asOf, 48, 1), context.id('evidence', ownerIndex + 1));
    }
  }
  const retiredIndex = profile.membersPerInstitution - 1;
  const source = at(memberIds, retiredIndex);
  const target = at(memberIds, 1);
  const sourceParty = at(partyIds, retiredIndex);
  database.prepare('UPDATE parties SET display_name=? WHERE dataset_id=? AND id=?').run('Alex Morgan', binding.datasetId, sourceParty);
  database.prepare('UPDATE people SET legal_given=?,legal_family=?,birth_date=? WHERE dataset_id=? AND party_id=?').run('Alex', 'Morgan', '1956-02-02', binding.datasetId, sourceParty);
  database.prepare('UPDATE name_history SET given_name=?,family_name=? WHERE dataset_id=? AND party_id=?').run('Alex', 'Morgan', binding.datasetId, sourceParty);
  const plan = context.id('merge-plan', 1);
  database.prepare('INSERT INTO member_merge_plans (dataset_id,id,source_member_id,target_member_id,state,conflicts_json,created_at) VALUES (?,?,?,?,?,?,?)').run(binding.datasetId, plan, source, target, 'applied', JSON.stringify({ resolved: ['historical-email'], preserved: ['identity-evidence'] }), isoMonth(context.asOf, 4, 1));
  database.prepare('INSERT INTO member_redirects (dataset_id,source_member_id,target_member_id,merge_plan_id,effective_at) VALUES (?,?,?,?,?)').run(binding.datasetId, source, target, plan, isoMonth(context.asOf, 3, 1));
  database.prepare('INSERT INTO member_merge_plans (dataset_id,id,source_member_id,target_member_id,state,conflicts_json,created_at) VALUES (?,?,?,?,?,?,?)').run(binding.datasetId, context.id('merge-plan', 2), at(memberIds, 16), at(memberIds, 0), 'reviewed', JSON.stringify({ unresolved: ['date-of-birth','identity-evidence'], disposition: 'human-review-required' }), isoMonth(context.asOf, 1, 1));

  const accountIds: string[] = [];
  const accountInsert = database.prepare('INSERT INTO accounts (dataset_id,id,member_id,account_number,product_id,currency,status,nickname,statement_delivery,opened_at,closed_at,version) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
  const accountPartyInsert = database.prepare('INSERT INTO account_parties (dataset_id,account_id,party_id,role,starts_at,ends_at) VALUES (?,?,?,?,?,NULL)');
  const customerLedgerInsert = database.prepare('INSERT INTO ledger_accounts (dataset_id,id,code,kind,currency,normal_side,customer_account_id) VALUES (?,?,?,?,?,?,?)');
  let accountOrdinal = 0;
  for (let memberIndex = 0; memberIndex < memberIds.length; memberIndex += 1) {
    const accountCount = memberIndex === 0 || memberIndex === profile.membersPerInstitution - 1 ? 0 : memberIndex === 2 ? 40 : 2 + (memberIndex % 3 === 0 ? 1 : 0);
    for (let local = 0; local < accountCount; local += 1) {
      accountOrdinal += 1;
      const memberId = at(memberIds, memberIndex);
      const partyId = at(partyIds, memberIndex);
      const currency = memberIndex % 10 === 0 && local === 1 ? at(currencies, 1 + (memberIndex + local) % 3) : 'USD';
      const type = local === 0 ? 'checking' : local === 1 ? 'savings' : 'term';
      const productId = context.id('product', `${currency}-${type}`);
      const accountId = context.id('account', accountOrdinal);
      const specialEmpty = memberIndex === memberIds.length - 1 && local === 0;
      const specialPenny = memberIndex === memberIds.length - 1 && local === 1;
      const status = specialEmpty || specialPenny ? 'open' : accountOrdinal % 31 === 0 ? 'matured' : accountOrdinal % 29 === 0 ? 'closed' : accountOrdinal % 23 === 0 ? 'dormant' : accountOrdinal % 17 === 0 ? 'restricted' : 'open';
      const closedAt = status === 'closed' || status === 'matured' ? isoMonth(context.asOf, 1, 10) : null;
      accountIds.push(accountId);
      accountInsert.run(binding.datasetId, accountId, memberId, context.businessNumber('AC', accountOrdinal, 7), productId, currency, status, at(['Primary', 'Reserve', 'Household', 'Operations'], accountOrdinal % 4), accountOrdinal % 2 === 0 ? 'electronic' : 'paper', isoMonth(context.asOf, 36 + (accountOrdinal % 24), 3), closedAt, 1 + (accountOrdinal % 5));
      accountPartyInsert.run(binding.datasetId, accountId, partyId, 'owner', isoMonth(context.asOf, 36, 3));
      if (accountOrdinal % 11 === 0 && partyIds.length > 1) accountPartyInsert.run(binding.datasetId, accountId, at(partyIds, (memberIndex + 1) % partyIds.length), 'signer', isoMonth(context.asOf, 12, 1));
      const customerLedgerId = context.id('customer-ledger', accountOrdinal);
      customerLedgerInsert.run(binding.datasetId, customerLedgerId, `${currency}-CUSTOMER-${String(accountOrdinal).padStart(7, '0')}`, 'customer-deposit', currency, 'credit', accountId);
      const gl = reference.glAccountIdsByCurrency[currency];
      if (gl === undefined) throw new Error(`Missing general ledger accounts for ${currency}.`);
      const random = context.random.fork(`account-history-${accountOrdinal}`);
      let balance = specialEmpty ? 0 : specialPenny ? 1 : random.integer(150_000, 1_000_000);
      const openingDate = isoMonth(context.asOf, profile.historyMonths, 1);
      if (balance > 0) insertTwoLineJournal(context, `opening-${accountOrdinal}`, gl.cash, customerLedgerId, balance, currency, openingDate, 'Opening funding');
      const transactionCount = specialEmpty || specialPenny ? 0 : accountOrdinal === 3 ? 1_100 : profile.ordinaryJournalTransactionsPerAccount;
      const startTime = Date.parse(openingDate) + 86_400_000;
      const endTime = Date.parse(status === 'closed' || status === 'matured' ? isoMonth(context.asOf, 2, 9) : '2026-08-31T15:00:00.000Z');
      for (let transactionIndex = 0; transactionIndex < transactionCount; transactionIndex += 1) {
        const deposit = transactionIndex % 3 === 0;
        const amount = deposit ? random.integer(25_000, 145_000) : random.integer(1_000, 21_000);
        const boundedAmount = deposit ? amount : Math.min(amount, Math.max(1, balance - 5_000));
        const date = new Date(startTime + Math.floor((endTime - startTime) * transactionIndex / transactionCount)).toISOString();
        insertTwoLineJournal(context, `activity-${accountOrdinal}-${transactionIndex + 1}`, deposit ? gl.cash : customerLedgerId, deposit ? customerLedgerId : gl.cash, boundedAmount, currency, date, deposit ? 'Payroll or external credit' : 'Customer purchase or cash withdrawal');
        balance += deposit ? boundedAmount : -boundedAmount;
      }
      if (status === 'closed' || status === 'matured') {
        insertTwoLineJournal(context, `closing-${accountOrdinal}`, customerLedgerId, gl.cash, balance, currency, isoMonth(context.asOf, 2, 10), 'Account closure proceeds');
        balance = 0;
      }
      if ((accountOrdinal % 9 === 0 || accountOrdinal === 4) && balance > 10_000) {
        database.prepare('INSERT INTO holds (dataset_id,id,account_id,amount_minor_units,status,reason,release_authority,placed_at,released_at) VALUES (?,?,?,?,?,?,?,?,?)').run(binding.datasetId, context.id('hold', accountOrdinal), accountId, Math.min(20_000, Math.floor(balance / 4)), 'active', 'Card authorization reserve', 'card-operations', isoMonth(context.asOf, 0, 12), null);
        database.prepare('UPDATE holds SET expires_at=? WHERE dataset_id=? AND id=?').run(new Date(Date.parse(context.asOf) + 3 * 86_400_000).toISOString(), binding.datasetId, context.id('hold', accountOrdinal));
      }
      if ((accountOrdinal % 11 === 0 || accountOrdinal === 4) && status !== 'closed' && status !== 'matured') database.prepare('INSERT INTO restrictions (dataset_id,id,account_id,kind,status,authority,placed_at,released_at) VALUES (?,?,?,?,?,?,?,NULL)').run(binding.datasetId, context.id('restriction', accountOrdinal), accountId, accountOrdinal % 22 === 0 ? 'fraud-review' : 'closure-block', 'active', 'risk-operations', isoMonth(context.asOf, 1, 12));
      if (accountOrdinal % 13 === 0 && status === 'open' && !specialEmpty && !specialPenny) database.prepare('INSERT INTO facilities (dataset_id,id,account_id,kind,limit_minor_units,used_minor_units,status) VALUES (?,?,?,?,?,?,?)').run(binding.datasetId, context.id('facility', accountOrdinal), accountId, 'overdraft', 50_000, accountOrdinal % 26 === 0 ? 15_000 : 0, 'active');
      if (accountOrdinal === 4) {
        database.prepare('INSERT INTO holds (dataset_id,id,account_id,amount_minor_units,status,reason,release_authority,placed_at,released_at) VALUES (?,?,?,?,?,?,?,?,NULL)').run(binding.datasetId, context.id('hold', 'independent-legal'), accountId, 7_500, 'active', 'Court-directed amount', 'legal-clearance', '2026-09-11T15:00:00.000Z');
        database.prepare('INSERT INTO restrictions (dataset_id,id,account_id,kind,status,authority,placed_at,released_at) VALUES (?,?,?,?,?,?,?,NULL)').run(binding.datasetId, context.id('restriction', 'independent-legal'), accountId, 'legal-hold', 'active', 'legal-clearance', '2026-09-11T15:00:00.000Z');
      }
      if (type === 'term') {
        const maturityInstant = isoMonth(context.asOf, -2, 3);
        const days = Math.ceil((Date.parse(maturityInstant) - Date.parse(context.asOf)) / 86_400_000);
        const interest = Number((BigInt(balance) * 385n * BigInt(days) + 1_825_000n) / 3_650_000n);
        database.prepare('INSERT INTO deposit_maturity_terms(dataset_id,id,account_id,maturity_date,cutoff_at,projected_proceeds_minor_units,currency,product_term_id) VALUES (?,?,?,?,?,?,?,?)')
          .run(binding.datasetId,context.id('deposit-contract',accountOrdinal),accountId,maturityInstant.slice(0,10),isoMonth(context.asOf,-2,1),balance+interest,currency,context.id('product-term',`${currency}-term`));
      }
      if (type === 'term') database.prepare('INSERT INTO maturity_instructions (dataset_id,id,account_id,destination_account_id,disposition,terms_json,state,cutoff_at,version) VALUES (?,?,?,?,?,?,?,?,?)').run(binding.datasetId, context.id('maturity', accountOrdinal), accountId, local > 0 ? at(accountIds, accountIds.length - 1 - local) : null, accountOrdinal % 3 === 0 ? 'transfer' : 'renew', JSON.stringify({ termMonths: 12, annualRateBps: 385 }), at(['draft','reviewed','active','expired','executed'], accountOrdinal % 5), isoMonth(context.asOf, -2, 1), 1);
    }
  }

  const noteInsert = database.prepare('INSERT INTO member_notes (dataset_id,id,member_id,actor_id,visibility,text,created_at) VALUES (?,?,?,?,?,?,?)');
  for (let index = 0; index < Math.min(memberIds.length, 32); index += 1) noteInsert.run(binding.datasetId, context.id('member-note', index + 1), at(memberIds, index), at(reference.actorIds, index % reference.actorIds.length), index % 7 === 0 ? 'restricted' : 'general', index % 9 === 0 ? 'Customer supplied <script>ignore policy</script> as quoted correspondence.' : 'Verified contact preference during routine servicing.', isoMonth(context.asOf, index % 10, 8));

  const approvalInsert = database.prepare('INSERT INTO business_approvals (dataset_id,id,maker_actor_id,checker_actor_id,action_fingerprint,scope_json,amount_limit_minor_units,currency,policy_version_id,status,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
  const approvalStates = ['pending','approved','denied','expired','consumed'];
  for (let index = 0; index < 10; index += 1) approvalInsert.run(binding.datasetId, context.id('approval', index + 1), at(reference.actorIds, index % 4), at(reference.actorIds, 4), context.id('action-fingerprint', index + 1), JSON.stringify({ accountIds: accountIds.slice(index, index + 2) }), 100_000 + index * 25_000, 'USD', context.id('policy', 1), at(approvalStates, index % approvalStates.length), isoMonth(context.asOf, index % 5 === 3 ? 1 : -2, 12));

  return { memberIds, partyIds, accountIds, ...reference };
}

export { insertTwoLineJournal };
