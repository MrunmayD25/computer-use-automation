import { createHash } from 'node:crypto';

export interface SeedRandom {
  next(): number;
  integer(minimum: number, maximum: number): number;
  pick<T>(values: readonly T[]): T;
  fork(label: string): SeedRandom;
}

function stateFor(seed: number, label: string): number {
  const digest = createHash('sha256').update(`${seed}:${label}`).digest();
  return digest.readUInt32LE(0);
}

export function createSeedRandom(seed: number, label = 'root'): SeedRandom {
  let state = stateFor(seed, label);
  const next = (): number => {
    state = (Math.imul(state, 1_664_525) + 1_013_904_223) >>> 0;
    return state / 0x1_0000_0000;
  };
  return {
    next,
    integer(minimum: number, maximum: number): number {
      if (!Number.isSafeInteger(minimum) || !Number.isSafeInteger(maximum) || maximum < minimum) {
        throw new Error('Random integer bounds are invalid.');
      }
      return minimum + Math.floor(next() * (maximum - minimum + 1));
    },
    pick<T>(values: readonly T[]): T {
      if (values.length === 0) throw new Error('Cannot pick from an empty collection.');
      return values[Math.floor(next() * values.length)] as T;
    },
    fork(childLabel: string): SeedRandom {
      return createSeedRandom(seed, `${label}/${childLabel}`);
    },
  };
}
