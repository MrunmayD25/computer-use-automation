import { all, canonicalJson, int, sha256, str, type Row } from './core.js';
import type { SqlDatabase } from './store.js';
import type { ActorRef, SavedSearchDefinition, SavedSearchEntity, SavedSearchFilterValue, SavedSearchVisibility } from './types.js';

type FilterKind = 'text' | 'list' | 'boolean';

export interface SavedSearchEntitySpec {
  /** Filter names and value kinds, in canonical storage order. */
  filters: Readonly<Record<string, FilterKind>>;
  /** Sortable stored fields mapped to the sort key of the entity's list query. */
  sorts: Readonly<Record<string, string>>;
  /** Stored field names a search may show, which applications use as column identities. */
  columns: readonly string[];
}

/** The field vocabulary of each searchable entity. Saved definitions may reference nothing else. */
export const SAVED_SEARCH_ENTITIES: Readonly<Record<SavedSearchEntity, SavedSearchEntitySpec>> = {
  members: {
    filters: { query: 'text', status: 'text' },
    sorts: { member_number: 'memberNumber', display_name: 'name', status: 'status', joined_at: 'joined' },
    columns: ['member_number', 'display_name', 'kind', 'status', 'email', 'phone', 'open_accounts', 'joined_at', 'version'],
  },
  accounts: {
    filters: { query: 'text', status: 'text', currency: 'text' },
    sorts: {
      account_number: 'accountNumber', member_number: 'memberNumber', owner_name: 'owner', product_code: 'product', status: 'status', nickname: 'nickname',
      posted_minor_units: 'posted', available_minor_units: 'available', opened_at: 'opened',
    },
    columns: ['account_number', 'member_number', 'owner_name', 'product_code', 'product_name', 'currency', 'status', 'nickname', 'statement_delivery',
      'posted_minor_units', 'available_minor_units', 'opened_at', 'closed_at', 'version'],
  },
  cases: {
    filters: { query: 'text', states: 'list', queueIds: 'list', priority: 'text', assignedActorId: 'text', overdue: 'boolean' },
    sorts: { case_number: 'caseNumber', due_at: 'due', opened_at: 'opened', state: 'state', priority: 'priority', member_number: 'member', queue_code: 'queue', assigned_name: 'assignee' },
    columns: ['case_number', 'member_number', 'member_name', 'account_number', 'queue_code', 'assigned_name', 'state', 'priority', 'category', 'summary',
      'opened_at', 'due_at', 'overdue', 'version'],
  },
};

const DEFINITION_KEYS: ReadonlySet<string> = new Set(['entity', 'filters', 'sort', 'columns', 'maxResults']);
const MAX_FILTER_TEXT = 200;
const MAX_LIST_ITEMS = 20;
export const MAX_SAVED_SEARCH_RESULTS = 10_000;

export type SavedSearchParse = { ok: true; definition: SavedSearchDefinition } | { ok: false; field: string; message: string };

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/**
 * Validates a saved search definition and returns its canonical form. Empty filters are dropped,
 * text is trimmed and list values are deduplicated, so equal meanings store equal JSON.
 */
export function parseSavedSearchDefinition(value: unknown): SavedSearchParse {
  const fail = (field: string, message: string): SavedSearchParse => ({ ok: false, field, message });
  if (!isRecord(value)) return fail('definition', 'A saved search definition must be an object.');
  const unknownKey = Object.keys(value).find((key) => !DEFINITION_KEYS.has(key));
  if (unknownKey !== undefined) return fail('definition', `Saved searches have no ${unknownKey} setting.`);
  const entity = value.entity;
  if (entity !== 'members' && entity !== 'accounts' && entity !== 'cases') return fail('definition.entity', 'A saved search lists members, accounts or cases.');
  const spec = SAVED_SEARCH_ENTITIES[entity];

  if (!isRecord(value.filters)) return fail('definition.filters', 'Filters must be an object.');
  const rawFilters = value.filters;
  const unknownFilter = Object.keys(rawFilters).find((key) => !(key in spec.filters));
  if (unknownFilter !== undefined) return fail(`definition.filters.${unknownFilter}`, `${entity} searches have no ${unknownFilter} filter.`);
  const filters: Record<string, SavedSearchFilterValue> = {};
  for (const [key, kind] of Object.entries(spec.filters)) {
    const raw = rawFilters[key];
    if (raw === undefined || raw === null) continue;
    const field = `definition.filters.${key}`;
    if (kind === 'text') {
      if (typeof raw !== 'string' || raw.length > MAX_FILTER_TEXT) return fail(field, `The ${key} filter must be text of at most ${MAX_FILTER_TEXT} characters.`);
      const text = raw.normalize('NFC').trim();
      if (text !== '') filters[key] = text;
    } else if (kind === 'list') {
      if (!Array.isArray(raw) || raw.length > MAX_LIST_ITEMS || raw.some((item) => typeof item !== 'string' || item.length === 0 || item.length > MAX_FILTER_TEXT)) {
        return fail(field, `The ${key} filter must list at most ${MAX_LIST_ITEMS} values.`);
      }
      const values = [...new Set(raw as string[])];
      if (values.length > 0) filters[key] = values;
    } else {
      if (typeof raw !== 'boolean') return fail(field, `The ${key} filter must be true or false.`);
      if (raw) filters[key] = true;
    }
  }

  const sortFields = Object.keys(spec.sorts);
  const sortProblem = `Sort by at most one of ${sortFields.join(', ')}, ascending or descending.`;
  if (!Array.isArray(value.sort) || value.sort.length > 1) return fail('definition.sort', sortProblem);
  const sort: { field: string; direction: 'asc' | 'desc' }[] = [];
  for (const item of value.sort as unknown[]) {
    if (!isRecord(item) || Object.keys(item).length !== 2 || typeof item.field !== 'string' || !sortFields.includes(item.field) || (item.direction !== 'asc' && item.direction !== 'desc')) {
      return fail('definition.sort', sortProblem);
    }
    sort.push({ field: item.field, direction: item.direction });
  }

  if (!Array.isArray(value.columns) || value.columns.length === 0) return fail('definition.columns', 'Choose at least one column.');
  const columns = value.columns as unknown[];
  const unknownColumn = columns.find((column) => typeof column !== 'string' || !spec.columns.includes(column));
  if (unknownColumn !== undefined) return fail('definition.columns', `${entity} searches have no ${typeof unknownColumn === 'string' ? unknownColumn : JSON.stringify(unknownColumn)} column.`);
  if (new Set(columns).size !== columns.length) return fail('definition.columns', 'Each column may appear once.');

  const maxResults = value.maxResults;
  if (maxResults !== undefined && (typeof maxResults !== 'number' || !Number.isSafeInteger(maxResults) || maxResults < 1 || maxResults > MAX_SAVED_SEARCH_RESULTS)) {
    return fail('definition.maxResults', `The result limit must be a whole number from 1 through ${MAX_SAVED_SEARCH_RESULTS}.`);
  }
  return { ok: true, definition: { entity, filters, sort, columns: columns as string[], ...(maxResults === undefined ? {} : { maxResults }) } };
}

/** Opaque content revision a caller reviewed. Any change to name, visibility or definition changes it. */
export function savedSearchRevision(row: { name: string; visibility: string; definitionJson: string }): string {
  return sha256(canonicalJson([row.name, row.visibility, row.definitionJson])).slice(0, 24);
}

export interface SavedSearchRow {
  id: string;
  name: string;
  visibility: SavedSearchVisibility;
  owner: ActorRef;
  /** True when the requesting operator owns the search and may change it. */
  mine: boolean;
  createdAt: string;
  revision: string;
  definition: SavedSearchDefinition | null;
  /** Why a stored definition cannot be opened, or null when it is valid. */
  problem: string | null;
}

const SAVED_SEARCH_SELECT = `SELECT s.id,s.actor_id,s.name,s.visibility,s.definition_json,s.created_at,a.actor_number,a.display_name
  FROM saved_searches s JOIN actors a ON a.dataset_id=s.dataset_id AND a.id=s.actor_id`;

function savedSearchRow(row: Row, actorId: string): SavedSearchRow {
  const definitionJson = str(row, 'definition_json');
  let parsed: SavedSearchParse;
  try { parsed = parseSavedSearchDefinition(JSON.parse(definitionJson)); } catch { parsed = { ok: false, field: 'definition', message: 'The stored definition is not valid JSON.' }; }
  const name = str(row, 'name');
  const visibility = str(row, 'visibility') as SavedSearchVisibility;
  return {
    id: str(row, 'id'), name, visibility, owner: { id: str(row, 'actor_id'), actorNumber: str(row, 'actor_number'), displayName: str(row, 'display_name') },
    mine: str(row, 'actor_id') === actorId, createdAt: str(row, 'created_at'), revision: savedSearchRevision({ name, visibility, definitionJson }),
    definition: parsed.ok ? parsed.definition : null, problem: parsed.ok ? null : parsed.message,
  };
}

/** The operator's own searches followed by searches other operators shared, optionally for one entity. */
export function listSavedSearches(database: SqlDatabase, datasetId: string, actorId: string, entity?: SavedSearchEntity): SavedSearchRow[] {
  const rows = all(database, `${SAVED_SEARCH_SELECT} WHERE s.dataset_id=? AND (s.actor_id=? OR s.visibility='shared')
    ORDER BY CASE WHEN s.actor_id=? THEN 0 ELSE 1 END,s.name COLLATE NOCASE,s.id LIMIT 500`, datasetId, actorId, actorId).map((row) => savedSearchRow(row, actorId));
  return entity === undefined ? rows : rows.filter((row) => row.definition?.entity === entity || (row.definition === null && storedEntity(database, datasetId, row.id) === entity));
}

function storedEntity(database: SqlDatabase, datasetId: string, searchId: string): string | null {
  const [row] = all(database, "SELECT json_extract(definition_json,'$.entity') AS entity FROM saved_searches WHERE dataset_id=? AND id=? AND json_valid(definition_json)", datasetId, searchId);
  const entity = row?.entity;
  return typeof entity === 'string' ? entity : null;
}

/** One saved search the operator may see: their own, or another operator's shared search. */
export function savedSearchForActor(database: SqlDatabase, datasetId: string, actorId: string, searchId: string): SavedSearchRow | undefined {
  const [row] = all(database, `${SAVED_SEARCH_SELECT} WHERE s.dataset_id=? AND s.id=? AND (s.actor_id=? OR s.visibility='shared')`, datasetId, searchId, actorId);
  return row === undefined ? undefined : savedSearchRow(row, actorId);
}

export function countSavedSearches(database: SqlDatabase, datasetId: string, actorId: string): number {
  return int(all(database, 'SELECT COUNT(*) AS count FROM saved_searches WHERE dataset_id=? AND actor_id=?', datasetId, actorId)[0], 'count');
}
