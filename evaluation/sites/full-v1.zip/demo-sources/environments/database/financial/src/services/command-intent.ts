import { createHash } from 'node:crypto';

import { canonicalJson } from './core.js';

/**
 * Returns the stable identity of a command's business intent.
 *
 * Expected values are review-time bindings. They protect the current write but
 * are deliberately excluded so a retry can refresh a stale version or
 * fingerprint without becoming a different idempotent intent. Payload,
 * approval, and evidence fields remain part of the intent.
 */
export function commandIntentDigest(command: object): string {
  const intent = Object.fromEntries(Object.entries(command as Record<string, unknown>).filter(([key]) => !key.startsWith('expected')));
  return createHash('sha256').update(canonicalJson(intent)).digest('hex');
}
