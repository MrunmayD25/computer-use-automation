import type { DatabaseSync } from 'node:sqlite';

import type { DatasetBinding, InstitutionSeed, SeedScale } from '../model.js';
import type { SeedRandom } from './random.js';

export interface ScaleProfile {
  membersPerInstitution: number;
  organizationsPerInstitution: number;
  historyMonths: number;
  ordinaryJournalTransactionsPerAccount: number;
}

export interface SeedContext {
  database: DatabaseSync;
  binding: DatasetBinding;
  institution: InstitutionSeed;
  scale: SeedScale;
  profile: ScaleProfile;
  seed: number;
  asOf: string;
  random: SeedRandom;
  id(kind: string, ordinal: number | string): string;
  businessNumber(prefix: string, ordinal: number, width?: number): string;
}

export interface CoreSeedReferences {
  memberIds: readonly string[];
  partyIds: readonly string[];
  accountIds: readonly string[];
  actorIds: readonly string[];
  branchIds: readonly string[];
  queueIds: readonly string[];
  productIds: readonly string[];
  glAccountIdsByCurrency: Readonly<Record<string, { cash: string; opening: string; feeIncome: string; settlement: string }>>;
}

export interface ExtendedSeedReferences {
  paymentIds: readonly string[];
  cardIds: readonly string[];
  loanIds: readonly string[];
  documentVersionIds: readonly string[];
  caseIds: readonly string[];
  batchIds: readonly string[];
}

export interface GeneratedDocument {
  bytes: Uint8Array;
  mediaType: 'application/pdf' | 'text/csv' | 'text/html' | 'text/plain';
  displayName: string;
}
