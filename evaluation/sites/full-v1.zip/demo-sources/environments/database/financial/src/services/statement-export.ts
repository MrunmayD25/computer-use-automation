import { createHash } from 'node:crypto';

import { renderCsv, type DocumentArtifact } from '../documents.js';
import { authorizeQuery, datasetClock, reject } from './core.js';
import { renderGeneratedStatement, searchAccounts, statementData, type StatementData } from './queries.js';
import type { FinancialStore } from './store.js';
import type { Rejection, ServiceContext } from './types.js';

export interface StatementExportRequest {
  memberId: string;
  accountId: string;
  period: string;
  formats: readonly ('html' | 'csv' | 'pdf')[];
  destinationId: string;
}
export interface StatementExport {
  kind: 'artifacts';
  source: 'ledger-snapshot';
  destinationId: string;
  observedAt: string;
  statement: StatementData;
  artifacts: DocumentArtifact[];
}
const escape = (value: string): string => value.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');

function validRequest(value: unknown): value is StatementExportRequest {
  if(value===null || typeof value!=='object' || Array.isArray(value)) return false;
  const keys=['memberId','accountId','period','formats','destinationId'];
  if(Object.keys(value).some(key=>!keys.includes(key)) || keys.some(key=>key!=='formats' && typeof Reflect.get(value,key)!=='string')) return false;
  const formats:unknown=Reflect.get(value,'formats');
  const period:unknown=Reflect.get(value,'period');
  return Array.isArray(formats) && formats.length>=1 && formats.length<=3 && new Set(formats).size===formats.length
    && formats.every((format:unknown)=>typeof format==='string' && ['html','csv','pdf'].includes(format))
    && typeof period==='string' && /^\d{4}-(0[1-9]|1[0-2])$/u.test(period);
}

/**
 * Produces a coherent derived statement bundle without changing business data.
 *
 * approvedDestinations comes from trusted backend configuration. The adapter owns saving returned
 * bytes to that approved local handle; this result does not assert that any file was saved. Issued
 * historical versions are retrieved separately, never silently replaced with this ledger projection.
 */
export async function exportStatement(store: FinancialStore, context: ServiceContext, request: StatementExportRequest, approvedDestinations: readonly string[]): Promise<StatementExport | Rejection> {
  if(!validRequest(request)) return reject('validation','Invalid statement export fields or formats.');
  if (!approvedDestinations.includes(request.destinationId)) return reject('not_authorized','The local export destination is not approved.');
  const snapshot = store.read(database=>{
    const denied=authorizeQuery(database,context);
    if(denied!==null) return denied;
    const observedAt=new Date(context.now ?? datasetClock(database,context.binding.datasetId).asOf).toISOString();
    const account=searchAccounts(database,context.binding.datasetId,{memberId:request.memberId,ids:[request.accountId],offset:0,limit:1},observedAt).items[0];
    if(account===undefined) return reject('not_found','The requested account is absent from the member scope.');
    let statement: StatementData | undefined;
    try { statement=statementData(database,context.binding.datasetId,request.accountId,request.period,observedAt); }
    catch (error) {
      if (error instanceof RangeError) return reject('validation',error.message);
      throw error;
    }
    if(statement===undefined) return reject('not_found','The requested statement scope does not exist.');
    return {kind:'snapshot' as const,observedAt,statement};
  });
  if(snapshot.kind==='rejected') return snapshot;
  const {statement,observedAt}=snapshot;
  const account=statement.account;
  const artifacts: DocumentArtifact[]=[];
  for(const format of request.formats) {
    if(format==='pdf') artifacts.push(await renderGeneratedStatement(statement,observedAt));
    else if(format==='csv') {
      let running=statement.openingMinorUnits;
      artifacts.push(renderCsv({displayName:`${account.accountNumber}-${statement.period}.csv`,columns:['member_number','account_number','currency','effective_date','reference','description','signed_minor_units','running_balance_minor_units'],rows:statement.entries.map(entry=>{
        running+=entry.amountMinorUnits;
        return [account.memberNumber,account.accountNumber,account.currency,entry.date,entry.reference,entry.description,entry.amountMinorUnits,running];
      })}));
    } else {
      const rows=statement.entries.map(entry=>`<tr><td>${escape(entry.date)}</td><td>${escape(entry.reference)}</td><td>${escape(entry.description)}</td><td>${entry.amountMinorUnits}</td></tr>`).join('');
      const bytes=Buffer.from(`<!doctype html><html lang="en"><meta charset="utf-8"><title>${escape(account.accountNumber)} statement</title><body><h1>${escape(statement.institutionName)}</h1><h2>Derived statement · ${escape(statement.period)}</h2><p>Member ${escape(account.memberNumber)} · ${escape(account.ownerName)} · Account ${escape(account.accountNumber)}</p><p>Observed ${escape(observedAt)}. All amounts are exact ${escape(account.currency)} minor units (exponent ${account.exponent}).</p><p>Opening ${statement.openingMinorUnits}; closing ${statement.closingMinorUnits}</p><table><thead><tr><th>Date</th><th>Reference</th><th>Description</th><th>Signed minor units</th></tr></thead><tbody>${rows}</tbody></table></body></html>`);
      artifacts.push({displayName:`${account.accountNumber}-${statement.period}.html`,mediaType:'text/html',bytes,digest:createHash('sha256').update(bytes).digest('hex'),pageCount:0});
    }
  }
  return {kind:'artifacts',source:'ledger-snapshot',destinationId:request.destinationId,observedAt,statement,artifacts};
}
