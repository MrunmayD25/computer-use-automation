import { createHash } from 'node:crypto';
import type { SQLOutputValue } from 'node:sqlite';

import { insertTwoLineJournal } from './core.js';
import type { CoreSeedReferences, SeedContext } from './contract.js';

export interface HistoricalTransferReferences {
  transferJournalIds: string[];
  correctionJournalIds: string[];
  interestJournalIds: string[];
}

type Row = Record<string, SQLOutputValue>;

function text(row: Row, column: string): string {
  const value = row[column];
  if (typeof value !== 'string') throw new Error(`Expected historical journal ${column}.`);
  return value;
}

function integer(row: Row, column: string): number {
  const value = row[column];
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error(`Invalid historical journal ${column}.`);
  return value;
}

function halfEven(numerator: bigint, denominator: bigint): number {
  const quotient = numerator / denominator;
  const remainder = numerator % denominator;
  const rounded = quotient + (remainder * 2n > denominator || remainder * 2n === denominator && quotient % 2n !== 0n ? 1n : 0n);
  const result = Number(rounded);
  if (!Number.isSafeInteger(result)) throw new Error('Interest calculation exceeds safe integer range.');
  return result;
}

export function seedHistoricalTransfers(context: SeedContext, refs: CoreSeedReferences): HistoricalTransferReferences {
  const db = context.database;
  const dataset = context.binding.datasetId;
  const actorId = refs.actorIds[2];
  if (actorId === undefined) throw new Error('Historical financial operations require an actor.');
  const result: HistoricalTransferReferences = { transferJournalIds: [], correctionJournalIds: [], interestJournalIds: [] };
  const operationInsert = db.prepare(`INSERT INTO operations (dataset_id,id,actor_id,operation_kind,business_reference,idempotency_key,command_digest,status,occurred_at)
    VALUES (?,?,?,?,?,?,?,'committed',?)`);
  const receiptInsert = db.prepare(`INSERT INTO operation_receipts (dataset_id,id,operation_id,receipt_number,result_digest,committed_at) VALUES (?,?,?,?,?,?)`);
  let operationOrdinal = 0;
  const post = (kind: string, key: string, debit: string, credit: string, amount: number, currency: string, occurredAt: string, description: string,
    input: Record<string, string | number>): string => {
    const operationId = context.id('operation', `historical-${key}`);
    operationOrdinal += 1;
    const command = { kind, ...input, amountMinorUnits: amount, currency };
    const commandDigest = createHash('sha256').update(JSON.stringify(command)).digest('hex');
    if (kind === 'transfer.internal.reverse' || kind === 'interest.adjust') {
      const checker = refs.actorIds[3];
      if (checker === undefined || checker === actorId) throw new Error('Financial corrections require an independent checker.');
      db.prepare(`INSERT INTO business_approvals (dataset_id,id,maker_actor_id,checker_actor_id,action_fingerprint,scope_json,amount_limit_minor_units,currency,policy_version_id,status,expires_at)
        VALUES (?,?,?,?,?,?,?,?,?,'consumed',?)`).run(dataset, context.id('approval', `historical-${key}`), actorId, checker, commandDigest,
        JSON.stringify(command), amount, currency, typeof input.policyVersionId === 'string' ? input.policyVersionId : context.id('policy', 1), '2026-09-30T23:59:59.000Z');
    }
    operationInsert.run(dataset, operationId, actorId, kind, context.businessNumber('HT', operationOrdinal, 7), `historical-${key}`,
      commandDigest, occurredAt);
    const journalId = insertTwoLineJournal(context, `historical-${key}`, debit, credit, amount, currency, occurredAt, description, operationId);
    const receiptId = context.id('receipt', `historical-${key}`);
    receiptInsert.run(dataset, receiptId, operationId, context.businessNumber('HR', operationOrdinal, 7),
      createHash('sha256').update(JSON.stringify({ journalId, command })).digest('hex'), occurredAt);
    db.prepare(`INSERT INTO business_events (dataset_id,id,actor_id,operation_id,sequence,occurred_at,kind,resource_kind,resource_id,summary) VALUES (?,?,?,?,?,?,?,?,?,?)`)
      .run(dataset, context.id('business-event', `historical-${key}`), actorId, operationId, 500000 + operationOrdinal, occurredAt, kind, 'journal', journalId, description);
    return journalId;
  };
  const correction = (originalId: string, correctionId: string, amount: number, key: string, kind: 'reversal' | 'adjustment', originalAmount: number): void => {
    db.prepare(`INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,?)`)
      .run(dataset, context.id('correction-link', `historical-${key}`), originalId, correctionId, amount, kind);
    if (kind === 'reversal' && amount === originalAmount) db.prepare('UPDATE journals SET reversal_of_id=? WHERE dataset_id=? AND id=?').run(originalId, dataset, correctionId);
    result.correctionJournalIds.push(correctionId);
  };
  const pairs = db.prepare(`SELECT a.id AS source_id,b.id AS destination_id,a.member_id,a.currency,la.id AS source_ledger,lb.id AS destination_ledger
    FROM accounts a JOIN accounts b ON b.dataset_id=a.dataset_id AND b.member_id=a.member_id AND b.currency=a.currency AND a.account_number<b.account_number
    JOIN ledger_accounts la ON la.dataset_id=a.dataset_id AND la.customer_account_id=a.id AND la.kind='customer-deposit'
    JOIN ledger_accounts lb ON lb.dataset_id=b.dataset_id AND lb.customer_account_id=b.id AND lb.kind='customer-deposit'
    JOIN account_balances ba ON ba.dataset_id=a.dataset_id AND ba.account_id=a.id
    JOIN account_balances bb ON bb.dataset_id=b.dataset_id AND bb.account_id=b.id
    WHERE a.dataset_id=? AND a.status='open' AND b.status='open' AND ba.posted_balance_minor_units>50000 AND bb.posted_balance_minor_units>50000
    ORDER BY a.member_id,a.account_number,b.account_number`).all(dataset);
  if (pairs.length < 3) throw new Error('History seed requires at least three eligible same-owner account pairs.');
  const count = context.scale === 'small' ? 24 : context.scale === 'standard' ? 240 : 480;
  const used = new Set<string>();
  const balancedPairs: Row[] = [];
  for (const pair of pairs) {
    const member = text(pair, 'member_id');
    if (!used.has(member)) {
      used.add(member);
      balancedPairs.push(pair);
    }
  }
  for (let index = 0; index < count; index += 1) {
    const pair = balancedPairs[index % balancedPairs.length];
    if (pair === undefined) throw new Error('Missing historical transfer pair.');
    const source = text(pair, 'source_ledger');
    const destination = text(pair, 'destination_ledger');
    const currency = text(pair, 'currency');
    const amount = context.random.fork(`historical-transfer-${index}`).integer(500, 5000);
    const description = index % 2 === 0 ? 'Scheduled savings transfer' : 'Household reserve transfer';
    const command = { sourceAccountId: text(pair, 'source_id'), destinationAccountId: text(pair, 'destination_id') };
    const original = post('transfer.internal', `transfer-${index}`, source, destination, amount, currency, '2026-08-05T12:00:00.000Z', description, command);
    result.transferJournalIds.push(original);
    if (index % 4 === 0) continue;
    const amounts = index % 4 === 1 ? [Math.floor(amount / 2)] : index % 4 === 2 ? [amount] : [Math.floor(amount / 3), amount - Math.floor(amount / 3)];
    for (const [part, returned] of amounts.entries()) {
      const key = `transfer-return-${index}-${part}`;
      const returnedJournal = post('transfer.internal.reverse', key, destination, source, returned, currency,
        `2026-08-${part === 0 ? '08' : '09'}T12:00:00.000Z`, `Correction of ${description.toLowerCase()}`,
        { originalJournalId: original, sourceAccountId: command.destinationAccountId, destinationAccountId: command.sourceAccountId });
      correction(original, returnedJournal, returned, key, 'reversal', amount);
    }
  }
  const policyId = context.id('policy', 'deposit-interest-calculation');
  db.prepare('INSERT INTO policy_versions (dataset_id,id,name,version,effective_at,rules_json) VALUES (?,?,?,?,?,?)').run(dataset, policyId,
    'Deposit interest calculation and correction', '2026.1', '2026-01-01T00:00:00.000Z', JSON.stringify({
      calculation: 'sum-positive-daily-closing-balances-times-annual-rate', rateUnit: 'basis-points', annualRateBps: 365,
      dayCount: 'actual-365', rounding: 'half-even-on-period-total', periodStartInclusive: '2026-07-01', periodEndExclusive: '2026-08-01',
      correctionPeriodStatus: 'open', correctionDeadline: '2026-09-30', authority: 'independent-checker',
    }));
  const interestAccounts = balancedPairs.slice(0, context.scale === 'small' ? 9 : 30);
  const expenseLedgers = new Map<string, string>();
  for (const [index, account] of interestAccounts.entries()) {
    const currency = text(account, 'currency');
    let expense = expenseLedgers.get(currency);
    if (expense === undefined) {
      expense = context.id('ledger-account', `interest-expense-${currency}`);
      db.prepare('INSERT INTO ledger_accounts (dataset_id,id,code,kind,currency,normal_side,customer_account_id) VALUES (?,?,?,?,?,?,NULL)')
        .run(dataset, expense, `${currency}-DEPOSIT-INTEREST-EXPENSE`, 'interest-expense', currency, 'debit');
      expenseLedgers.set(currency, expense);
    }
    const accountId = text(account, 'source_id');
    const ledgerId = text(account, 'source_ledger');
    const history = db.prepare(`SELECT j.posted_at,l.credit_minor_units-l.debit_minor_units AS amount FROM journal_lines l
      JOIN journals j ON j.dataset_id=l.dataset_id AND j.id=l.journal_id
      WHERE l.dataset_id=? AND l.ledger_account_id=? AND j.posted_at<'2026-08-01' ORDER BY j.posted_at,j.id`).all(dataset, ledgerId);
    let balanceDays = 0;
    for (let day = 1; day <= 31; day += 1) {
      const date = `2026-07-${day.toString().padStart(2, '0')}`;
      const closing = history.filter(row => text(row, 'posted_at').slice(0, 10) <= date).reduce((sum, row) => sum + integer(row, 'amount'), 0);
      balanceDays += Math.max(0, closing);
    }
    if (!Number.isSafeInteger(balanceDays)) throw new Error('Interest basis exceeds safe integer range.');
    const calculated = halfEven(BigInt(balanceDays) * 365n, 365n * 10000n);
    const delta = index % 3 === 0 ? 25 : index % 3 === 1 ? -25 : 0;
    const booked = calculated - delta;
    if (booked <= 0) throw new Error('Interest history needs a positive original accrual.');
    const original = post('interest.accrual', `interest-original-${index}`, expense, ledgerId, booked, currency,
      '2026-08-01T12:00:00.000Z', 'July deposit interest accrual', { accountId, policyVersionId: policyId, periodStart: '2026-07-01', periodEnd: '2026-08-01' });
    db.prepare('UPDATE journals SET effective_date=? WHERE dataset_id=? AND id=?').run('2026-07-31', dataset, original);
    result.interestJournalIds.push(original);
    let adjusted: string | null = null;
    if (delta !== 0 && index !== 0) {
      adjusted = post('interest.adjust', `interest-adjustment-${index}`, delta > 0 ? expense : ledgerId, delta > 0 ? ledgerId : expense,
        Math.abs(delta), currency, '2026-08-10T12:00:00.000Z', delta > 0 ? 'July interest underpayment correction' : 'July interest overpayment correction',
        { accountId, originalJournalId: original, policyVersionId: policyId, periodStart: '2026-07-01', periodEnd: '2026-08-01', approvedDeltaMinorUnits: delta });
      db.prepare('UPDATE journals SET effective_date=? WHERE dataset_id=? AND id=?').run('2026-07-31', dataset, adjusted);
      correction(original, adjusted, Math.abs(delta), `interest-${index}`, 'adjustment', booked);
      result.interestJournalIds.push(adjusted);
    }
    db.prepare(`INSERT INTO interest_calculations (dataset_id,id,account_id,policy_version_id,period_start,period_end,balance_days_minor_units,annual_rate_bps,year_basis,
      calculated_interest_minor_units,booked_interest_minor_units,delta_minor_units,original_journal_id,adjustment_journal_id,state) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(dataset, context.id('interest-calculation', index), accountId, policyId, '2026-07-01', '2026-08-01', balanceDays, 365, 365, calculated, booked, delta,
        original, adjusted, delta === 0 ? 'no-change' : adjusted === null ? 'pending' : 'posted');
  }
  return result;
}
