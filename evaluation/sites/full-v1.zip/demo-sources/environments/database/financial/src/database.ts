import { accountProductSql } from './product-sql.js';
import { createHash, randomUUID } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { DatabaseSync, type StatementSync } from 'node:sqlite';

import type {
  AccountListItem,
  ActorListItem,
  BatchListItem,
  CardListItem,
  CaseListItem,
  DatasetBinding,
  DatasetId,
  DatasetSummary,
  DocumentListItem,
  FinancialDatabase,
  FinancialDataset,
  InstitutionId,
  LoanListItem,
  MemberListItem,
  Page,
  PageRequest,
  PaymentListItem,
  SeedManifest,
  SeedWorldResult,
} from './model.js';
import { createSchema, DATASET_TABLES_IN_INSERT_ORDER, SCHEMA_VERSION } from './schema.js';
import type { ScaleProfile, SeedContext } from './seed/contract.js';
import { seedCore } from './seed/core.js';
import { validateSeedManifest } from './manifest.js';
import { seedDocumentsAndServicing } from './seed/documents-servicing.js';
import { seedFinancialDomains } from './seed/financial.js';
import { createSeedRandom } from './seed/random.js';
import { seedReconciliation } from './seed/reconciliation.js';
import { seedHistoricalTransfers } from './seed/transfers.js';
import { seedPaymentAccounting } from './seed/payment-accounting.js';
import { createRecordReader } from './records.js';

type SqlValue = string | number | bigint | Uint8Array | null;
type SqlRow = Record<string, SqlValue>;

const scaleProfiles: Record<SeedManifest['scale'], ScaleProfile> = {
  small: { membersPerInstitution: 48, organizationsPerInstitution: 6, historyMonths: 18, ordinaryJournalTransactionsPerAccount: 12 },
  standard: { membersPerInstitution: 750, organizationsPerInstitution: 36, historyMonths: 24, ordinaryJournalTransactionsPerAccount: 12 },
  capacity: { membersPerInstitution: 1_500, organizationsPerInstitution: 72, historyMonths: 36, ordinaryJournalTransactionsPerAccount: 18 },
};

function rows(statement: StatementSync, ...parameters: SqlValue[]): SqlRow[] {
  return statement.all(...parameters);
}

function row(statement: StatementSync, ...parameters: SqlValue[]): SqlRow | undefined {
  return statement.get(...parameters);
}

function text(value: SqlValue | undefined, name: string): string {
  if (typeof value !== 'string') throw new Error(`Database column ${name} is invalid.`);
  return value;
}

function integer(value: SqlValue | undefined, name: string): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error(`Database column ${name} is invalid.`);
  return value;
}

function asInstitutionId(value: string): InstitutionId {
  return value as InstitutionId;
}

function asDatasetId(value: string): DatasetId {
  return value as DatasetId;
}

function stableDigest(value: unknown): string {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

function stableId(...parts: readonly (string | number)[]): string {
  return createHash('sha256').update(parts.join(':')).digest('hex').slice(0, 24);
}

function validatePage(request: PageRequest): void {
  if (!Number.isSafeInteger(request.limit) || request.limit < 1 || request.limit > 100) throw new Error('Page limit must be an integer from 1 through 100.');
  if (request.cursor !== undefined && request.cursor.length === 0) throw new Error('Page cursor cannot be empty.');
}

function page<T>(statement: StatementSync, request: PageRequest, scope: string, parameters: readonly SqlValue[], map: (value: SqlRow) => T): Page<T> {
  validatePage(request);
  let after = '';
  if (request.cursor !== undefined) {
    try {
      if (request.cursor.length > 4096) throw new Error('Oversized cursor.');
      const cursor: unknown = JSON.parse(Buffer.from(request.cursor, 'base64url').toString('utf8'));
      if (!Array.isArray(cursor) || cursor.length !== 3 || cursor[0] !== parameters[0] || cursor[1] !== scope || typeof cursor[2] !== 'string') throw new Error('Wrong cursor scope.');
      after = cursor[2];
    } catch (error) { throw new Error('Invalid page cursor.', { cause: error }); }
  }
  const values = rows(statement, ...parameters, after, request.limit + 1);
  const hasNext = values.length > request.limit;
  const selected = hasNext ? values.slice(0, request.limit) : values;
  return { items: selected.map(map), nextCursor: hasNext ? Buffer.from(JSON.stringify([parameters[0], scope, text(selected.at(-1)?.id, 'id')])).toString('base64url') : null };
}

function bindingsForWorld(database: DatabaseSync, name: string): DatasetBinding[] {
  return rows(database.prepare('SELECT institution_id,dataset_id FROM world_datasets WHERE world_name=? ORDER BY ordinal'), name).map((value) => ({
    institutionId: asInstitutionId(text(value.institution_id, 'institution_id')),
    datasetId: asDatasetId(text(value.dataset_id, 'dataset_id')),
  }));
}

function validateBinding(database: DatabaseSync, binding: DatasetBinding): void {
  const found = row(database.prepare('SELECT id FROM datasets WHERE id=? AND institution_id=?'), binding.datasetId, binding.institutionId);
  if (found === undefined) throw new Error('Dataset binding does not match the institution.');
}

async function seedDataset(database: DatabaseSync, manifest: SeedManifest, institutionIndex: number, binding: DatasetBinding): Promise<void> {
  const institution = manifest.institutions[institutionIndex];
  if (institution === undefined) throw new Error('Seed manifest institution is missing.');
  const profile = scaleProfiles[manifest.scale];
  const context: SeedContext = {
    database,
    binding,
    institution,
    scale: manifest.scale,
    profile,
    seed: manifest.seed,
    asOf: manifest.asOf,
    random: createSeedRandom(manifest.seed, institution.id),
    id(kind: string, ordinal: number | string): string {
      return `${institution.id}-${kind}-${String(ordinal)}`;
    },
    businessNumber(prefix: string, ordinal: number, width = 6): string {
      return `${prefix}${String(ordinal).padStart(width, '0')}`;
    },
  };
  const core = seedCore(context);
  const financial = seedFinancialDomains(context, core);
  seedPaymentAccounting(context, core);
  seedHistoricalTransfers(context, core);
  const documents = await seedDocumentsAndServicing(context, core);
  const batchIds = seedReconciliation(context, core, { paymentIds: financial.paymentIds, documentVersionIds: documents.documentVersionIds });
  if (financial.loanIds.length === 0 || documents.caseIds.length === 0 || batchIds.length === 0) throw new Error('Seed generator did not create every required domain.');
}

class BoundDataset implements FinancialDataset {
  readonly records;
  readonly members;
  readonly accounts;
  readonly payments;
  readonly cards;
  readonly loans;
  readonly documents;
  readonly servicing;
  readonly reconciliation;
  readonly policy;
  readonly accounting;

  private readonly binding: DatasetBinding;

  constructor(private readonly database: DatabaseSync, binding: DatasetBinding, private readonly checkAccess: () => void) {
    validateBinding(database, binding);
    this.binding = Object.freeze({ ...binding });
    const datasetId = binding.datasetId;
    this.records = createRecordReader(database, datasetId, checkAccess);
    this.members = {
      list: (request: PageRequest): Page<MemberListItem> => page(this.prepare(`SELECT m.id,m.member_number,p.display_name,p.kind,m.status FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE m.dataset_id=? AND m.id>? ORDER BY m.id LIMIT ?`), request, 'members', [datasetId], (value) => ({ id: text(value.id,'id'), memberNumber: text(value.member_number,'member_number'), displayName: text(value.display_name,'display_name'), kind: text(value.kind,'kind') as MemberListItem['kind'], status: text(value.status,'status') as MemberListItem['status'] })),
    };
    this.accounts = {
      list: (request: PageRequest): Page<AccountListItem> => page(this.prepare(`SELECT a.id,a.account_number,a.member_id,p.code AS product_code,a.currency,a.status,b.posted_balance_minor_units,b.available_balance_minor_units FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.id=${accountProductSql('(SELECT as_of FROM datasets WHERE id=a.dataset_id)')} JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.id>? ORDER BY a.id LIMIT ?`), request, 'accounts', [datasetId], (value) => ({ id:text(value.id,'id'), accountNumber:text(value.account_number,'account_number'), memberId:text(value.member_id,'member_id'), productCode:text(value.product_code,'product_code'), currency:text(value.currency,'currency'), status:text(value.status,'status') as AccountListItem['status'], postedBalanceMinorUnits:integer(value.posted_balance_minor_units,'posted_balance_minor_units'), availableBalanceMinorUnits:integer(value.available_balance_minor_units,'available_balance_minor_units') })),
    };
    this.payments = {
      list: (request: PageRequest): Page<PaymentListItem> => page(this.prepare('SELECT id,reference,source_account_id,amount_minor_units,currency,state FROM payments WHERE dataset_id=? AND id>? ORDER BY id LIMIT ?'), request, 'payments', [datasetId], (value) => ({ id:text(value.id,'id'), reference:text(value.reference,'reference'), sourceAccountId:text(value.source_account_id,'source_account_id'), amountMinorUnits:integer(value.amount_minor_units,'amount_minor_units'), currency:text(value.currency,'currency'), state:text(value.state,'state') })),
    };
    this.cards = {
      list: (request: PageRequest): Page<CardListItem> => page(this.prepare('SELECT id,account_id,last_four,status FROM cards WHERE dataset_id=? AND id>? ORDER BY id LIMIT ?'), request, 'cards', [datasetId], (value) => ({ id:text(value.id,'id'), accountId:text(value.account_id,'account_id'), lastFour:text(value.last_four,'last_four'), status:text(value.status,'status') })),
    };
    this.loans = {
      list: (request: PageRequest): Page<LoanListItem> => page(this.prepare('SELECT id,account_id,state,principal_minor_units,currency FROM loans WHERE dataset_id=? AND id>? ORDER BY id LIMIT ?'), request, 'loans', [datasetId], (value) => ({ id:text(value.id,'id'), accountId:text(value.account_id,'account_id'), state:text(value.state,'state'), principalMinorUnits:integer(value.principal_minor_units,'principal_minor_units'), currency:text(value.currency,'currency') })),
    };
    this.documents = {
      list: (request: PageRequest): Page<DocumentListItem> => page(this.prepare(`SELECT v.id,d.id AS document_id,d.owner_party_id,d.display_name,d.document_type,v.media_type,v.digest,b.byte_length FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest WHERE v.dataset_id=? AND v.id>? ORDER BY v.id LIMIT ?`), request, 'documents', [datasetId], (value) => ({ id:text(value.document_id,'document_id'), versionId:text(value.id,'id'), ownerPartyId:text(value.owner_party_id,'owner_party_id'), displayName:text(value.display_name,'display_name'), documentType:text(value.document_type,'document_type'), mediaType:text(value.media_type,'media_type'), digest:text(value.digest,'digest'), byteLength:integer(value.byte_length,'byte_length') })),
      bytes: (versionId: string): Uint8Array => {
        const value = row(this.prepare('SELECT b.bytes FROM document_versions v JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest WHERE v.dataset_id=? AND v.id=?'), datasetId, versionId);
        const bytes = value?.bytes;
        if (!(bytes instanceof Uint8Array)) throw new Error('Unknown document version.');
        return Uint8Array.from(bytes);
      },
    };
    this.servicing = {
      listCases: (request: PageRequest): Page<CaseListItem> => page(this.prepare('SELECT id,case_number,member_id,state,priority FROM cases WHERE dataset_id=? AND id>? ORDER BY id LIMIT ?'), request, 'servicing', [datasetId], (value) => ({ id:text(value.id,'id'), caseNumber:text(value.case_number,'case_number'), memberId:text(value.member_id,'member_id'), state:text(value.state,'state'), priority:text(value.priority,'priority') })),
    };
    this.reconciliation = {
      listBatches: (request: PageRequest): Page<BatchListItem> => page(this.prepare('SELECT b.id,b.batch_number,b.kind,b.state,COUNT(i.id) AS item_count FROM batches b LEFT JOIN batch_items i ON i.dataset_id=b.dataset_id AND i.batch_id=b.id WHERE b.dataset_id=? AND b.id>? GROUP BY b.dataset_id,b.id ORDER BY b.id LIMIT ?'), request, 'reconciliation', [datasetId], (value) => ({ id:text(value.id,'id'), batchNumber:text(value.batch_number,'batch_number'), kind:text(value.kind,'kind'), state:text(value.state,'state'), itemCount:integer(value.item_count,'item_count') })),
    };
    this.policy = {
      listActors: (request: PageRequest): Page<ActorListItem> => page(this.prepare('SELECT id,actor_number,display_name,status FROM actors WHERE dataset_id=? AND id>? ORDER BY id LIMIT ?'), request, 'policy', [datasetId], (value) => ({ id:text(value.id,'id'), actorNumber:text(value.actor_number,'actor_number'), displayName:text(value.display_name,'display_name'), status:text(value.status,'status') })),
    };
    this.accounting = {
      journalLines: (request: PageRequest) => {
        const result = this.records.list('journal_lines', request);
        return { items: result.items.map(value => ({
          journalId: text(value.journal_id, 'journal_id'), lineNumber: integer(value.line_number, 'line_number'),
          ledgerAccountId: text(value.ledger_account_id, 'ledger_account_id'),
          debitMinorUnits: integer(value.debit_minor_units, 'debit_minor_units'),
          creditMinorUnits: integer(value.credit_minor_units, 'credit_minor_units'), currency: text(value.currency, 'currency'),
        })), nextCursor: result.nextCursor };
      },
    };
  }

  private prepare(sql: string): StatementSync {
    this.checkAccess();
    return this.database.prepare(sql);
  }

  summary(): DatasetSummary {
    const count = (table: string, predicate = ''): number => integer(row(this.prepare(`SELECT COUNT(*) AS count FROM ${table} WHERE dataset_id=?${predicate}`), this.binding.datasetId)?.count, `${table}.count`);
    return {
      members: count('members'), organizations: count('parties', " AND kind='organization'"), accounts: count('accounts'),
      journalLines: count('journal_lines'), payments: count('payments'), cards: count('cards'), loans: count('loans'),
      documents: count('document_versions'), cases: count('cases'), batches: count('batches'),
    };
  }
}

class FinancialDatabaseImpl implements FinancialDatabase {
  private seeding = false;

  private assertAvailable(): void {
    if (this.seeding) throw new Error('Seed operation is in progress on this database handle.');
  }

  constructor(private readonly database: DatabaseSync) {}

  async seedWorld(input: SeedManifest): Promise<SeedWorldResult> {
    this.assertAvailable();
    const manifest = validateSeedManifest(input);
    const digest = stableDigest(manifest);
    const existing = row(this.database.prepare('SELECT manifest_digest FROM worlds WHERE name=?'), manifest.name);
    if (existing !== undefined) {
      if (text(existing.manifest_digest, 'manifest_digest') !== digest) throw new Error(`Named world ${manifest.name} exists with a different manifest.`);
      return { kind: 'existing', bindings: bindingsForWorld(this.database, manifest.name) };
    }
    this.seeding = true;
    let transactionStarted = false;
    try {
      this.database.exec('BEGIN IMMEDIATE');
      transactionStarted = true;
      this.database.prepare('INSERT INTO worlds (name,seed,scale,as_of,generator_version,schema_version,manifest_digest,created_at) VALUES (?,?,?,?,?,?,?,?)').run(manifest.name, manifest.seed, manifest.scale, manifest.asOf, manifest.generatorVersion, manifest.schemaVersion, digest, manifest.asOf);
      for (const [index, institution] of manifest.institutions.entries()) {
        const institutionId = asInstitutionId(institution.id);
        const institutionRow = row(this.database.prepare('SELECT legal_name,display_name,country,time_zone,default_currency FROM institutions WHERE id=?'), institutionId);
        if (institutionRow === undefined) this.database.prepare('INSERT INTO institutions (id,legal_name,display_name,country,time_zone,default_currency) VALUES (?,?,?,?,?,?)').run(institutionId, institution.legalName, institution.displayName, 'US', institution.timeZone, institution.defaultCurrency);
        else if (stableDigest(institutionRow) !== stableDigest({ legal_name: institution.legalName, display_name: institution.displayName, country: 'US', time_zone: institution.timeZone, default_currency: institution.defaultCurrency })) throw new Error(`Institution ${institution.id} conflicts with the seed manifest.`);
        const datasetId = asDatasetId(`dataset-${stableId(manifest.name, institution.id, manifest.seed, manifest.scale)}`);
        const binding = { institutionId, datasetId };
        this.database.prepare('INSERT INTO datasets (id,institution_id,name,seed,scale,as_of,generator_version,schema_version,revision) VALUES (?,?,?,?,?,?,?,?,0)').run(datasetId, institutionId, `${manifest.name}:${institution.id}`, manifest.seed, manifest.scale, manifest.asOf, manifest.generatorVersion, manifest.schemaVersion);
        this.database.prepare('INSERT INTO world_datasets (world_name,institution_id,dataset_id,ordinal) VALUES (?,?,?,?)').run(manifest.name, institutionId, datasetId, index + 1);
        await seedDataset(this.database, manifest, index, binding);
      }
      const foreignKeys = rows(this.database.prepare('PRAGMA foreign_key_check'));
      if (foreignKeys.length > 0) throw new Error(`Seed violates ${foreignKeys.length} foreign keys.`);
      const unbalanced = rows(this.database.prepare('SELECT journal_id,currency FROM journal_lines GROUP BY dataset_id,journal_id,currency HAVING SUM(debit_minor_units)<>SUM(credit_minor_units)'));
      if (unbalanced.length > 0) throw new Error(`Seed contains ${unbalanced.length} unbalanced journals.`);
      this.database.exec('COMMIT');
      return { kind: 'created', bindings: bindingsForWorld(this.database, manifest.name) };
    } catch (error) {
      if (transactionStarted) this.database.exec('ROLLBACK');
      throw error;
    } finally {
      this.seeding = false;
    }
  }

  getNamedWorld(name: string): readonly DatasetBinding[] {
    this.assertAvailable();
    return bindingsForWorld(this.database, name);
  }

  cloneDataset(binding: DatasetBinding, name?: string): DatasetBinding {
    this.assertAvailable();
    const datasetId = asDatasetId(`dataset-clone-${randomUUID()}`);
    if (name !== undefined && (name.trim().length === 0 || name.length > 120)) throw new Error('Clone name must contain 1 to 120 characters.');
    this.database.exec('BEGIN IMMEDIATE');
    try {
      validateBinding(this.database, binding);
      const source = row(this.database.prepare('SELECT institution_id,seed,scale,as_of,generator_version,schema_version,revision,name FROM datasets WHERE id=?'), binding.datasetId);
      if (source === undefined) throw new Error('Source dataset is missing.');
      const cloneName = name ?? `${text(source.name, 'name')}:clone:${datasetId.slice(-8)}`;
      this.database.exec('PRAGMA defer_foreign_keys=ON');
      this.database.prepare('INSERT INTO datasets (id,institution_id,name,seed,scale,as_of,generator_version,schema_version,revision) VALUES (?,?,?,?,?,?,?,?,?)').run(datasetId, binding.institutionId, cloneName, integer(source.seed,'seed'), text(source.scale,'scale'), text(source.as_of,'as_of'), text(source.generator_version,'generator_version'), integer(source.schema_version,'schema_version'), integer(source.revision,'revision'));
      for (const table of DATASET_TABLES_IN_INSERT_ORDER) {
        const columns = rows(this.database.prepare(`PRAGMA table_info(${table})`)).map((value) => text(value.name, 'name'));
        if (!columns.includes('dataset_id')) throw new Error(`Clone table ${table} is not dataset scoped.`);
        const selection = columns.map((column) => column === 'dataset_id' ? '?' : column).join(',');
        this.database.prepare(`INSERT INTO ${table} (${columns.join(',')}) SELECT ${selection} FROM ${table} WHERE dataset_id=?`).run(datasetId, binding.datasetId);
      }
      this.database.exec('COMMIT');
    } catch (error) {
      this.database.exec('ROLLBACK');
      throw error;
    }
    return { institutionId: binding.institutionId, datasetId };
  }

  dataset(binding: DatasetBinding): FinancialDataset {
    this.assertAvailable();
    return new BoundDataset(this.database, binding, () => this.assertAvailable());
  }

  close(): void { this.assertAvailable(); this.database.close(); }
  [Symbol.dispose](): void { this.close(); }
}

export function openDatabase(path: string, busyTimeoutMs: number): FinancialDatabase {
  mkdirSync(dirname(path), { recursive: true });
  const database = new DatabaseSync(path);
  try {
    database.exec('PRAGMA foreign_keys=ON');
    database.exec('PRAGMA journal_mode=WAL');
    database.exec(`PRAGMA busy_timeout=${busyTimeoutMs}`);
    const version = integer(row(database.prepare('PRAGMA user_version'))?.user_version, 'user_version');
    if (version === 0) {
      database.exec('BEGIN IMMEDIATE');
      try {
        const lockedVersion = integer(row(database.prepare('PRAGMA user_version'))?.user_version, 'user_version');
        if (lockedVersion === 0) createSchema(database);
        else if (lockedVersion !== SCHEMA_VERSION) throw new Error(`Unsupported financial database schema version ${lockedVersion}.`);
        database.exec('COMMIT');
      } catch (error) {
        database.exec('ROLLBACK');
        throw error;
      }
    } else if (version !== SCHEMA_VERSION) throw new Error(`Unsupported financial database schema version ${version}.`);
    return new FinancialDatabaseImpl(database);
  } catch (error) {
    database.close();
    throw error;
  }
}
