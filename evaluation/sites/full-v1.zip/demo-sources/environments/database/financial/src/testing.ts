import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';

import type { DatasetBinding } from './model.js';

export function openTrustedReadOnly(path: string): DatabaseSync {
  const database = new DatabaseSync(path, { readOnly: true });
  database.exec('PRAGMA foreign_keys=ON');
  return database;
}

export function withTrustedFixtureTransaction<T>(
  options: { path: string; binding: DatasetBinding },
  callback: (database: DatabaseSync) => T,
): T {
  const database = new DatabaseSync(options.path);
  database.exec('PRAGMA foreign_keys=ON');
  const binding = database.prepare('SELECT id FROM datasets WHERE id=? AND institution_id=?').get(options.binding.datasetId, options.binding.institutionId);
  if (binding === undefined) {
    database.close();
    throw new Error('Trusted fixture dataset binding is invalid.');
  }
  database.exec('BEGIN IMMEDIATE');
  try {
    const result = callback(database);
    database.prepare('UPDATE datasets SET revision=revision+1 WHERE id=?').run(options.binding.datasetId);
    database.exec('COMMIT');
    return result;
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  } finally {
    database.close();
  }
}

/** Keys disposable application seed caches to the schema, seed code and document assets actually loaded. */
export function financialSeedCacheKey(): string {
  const extension=import.meta.url.endsWith('.ts') ? '.ts' : '.js';
  const files=['schema','facility-sql','product-sql','manifest','documents'].map(name=>new URL(`./${name}${extension}`,import.meta.url));
  for(const name of readdirSync(new URL('./seed/',import.meta.url)).sort()) if(name.endsWith(extension) && !name.endsWith('.d.ts')) files.push(new URL(`./seed/${name}`,import.meta.url));
  files.push(new URL('../src/assets/NotoSans-Regular.ttf',import.meta.url));
  const hash=createHash('sha256');
  for(const file of files) { hash.update(file.pathname.split('/').at(-1)??''); hash.update(readFileSync(file)); }
  return hash.digest('hex').slice(0,20);
}
