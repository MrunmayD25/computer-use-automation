import { accountFacts, all, canonicalJson, int, isIsoDate, localDate, nextNumber, one, optionalStr, reject, run, str, type Row } from './core.js';
import { debitEligibility } from './rules.js';
import type { Preparation } from './commands.js';
import type { FinanceCommand } from './finance-types.js';
import {
  approvalPrepared, enforceSafeLedgerPosting, generalLedger, insertJournal, ledgerForAccount, loadAccount, loadMember, newId, noFinanceReview, paymentEvent, prepared,
  normalizeInstant, requireAccountVersion, requireApproval, requireCredit, requireDate, requireDebit, requireFingerprint, requireInstant, requireMemberVersion, requireMoney, requireText, rowFingerprint,
  type FinanceEnvironment,
} from './finance-support.js';
import type { Rejection } from './types.js';

type FinanceOf<K extends FinanceCommand['kind']> = Extract<FinanceCommand, { kind: K }>;
function validation(problems: readonly (Rejection | null)[]): Rejection | null { return problems.find((problem) => problem !== null) ?? null; }
function isRejection(value: Row | Rejection): value is Rejection { return value.kind === 'rejected'; }

function beneficiaryRow(env: FinanceEnvironment, beneficiaryId: string): Row | undefined {
  return one(env.database, 'SELECT id,owner_party_id,display_name,status FROM beneficiaries WHERE dataset_id=? AND id=?', env.datasetId, beneficiaryId);
}

function routeRow(env: FinanceEnvironment, routeId: string): Row | undefined {
  return one(env.database, `SELECT r.id,r.beneficiary_id,r.version,r.routing_kind,r.masked_destination,r.simulated_token,r.status,r.verified_at,r.expires_at,
    b.owner_party_id,b.status AS beneficiary_status FROM beneficiary_routes r JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id
    WHERE r.dataset_id=? AND r.id=?`, env.datasetId, routeId);
}

const ROUTE_COLUMNS = ['id','beneficiary_id','version','routing_kind','masked_destination','simulated_token','status','verified_at','expires_at','owner_party_id','beneficiary_status'] as const;

function prepareBeneficiaryCreate(env: FinanceEnvironment, command: FinanceOf<'beneficiary.create'>): Preparation {
  const member = loadMember(env, command.memberId);
  if (member === undefined) return reject('not_found', 'The beneficiary owner member does not exist.');
  const invalid = validation([requireMemberVersion(member, command.expectedMemberVersion), requireText(command.displayName, 'displayName', 'Beneficiary name', 120), requireText(command.routingKind, 'routingKind', 'Routing kind', 30), requireText(command.maskedDestination, 'maskedDestination', 'Masked destination', 80), requireText(command.simulatedToken, 'simulatedToken', 'Simulated route token', 200)]);
  if (invalid !== null) return invalid;
  if (str(member, 'status') !== 'active') return reject('ineligible', 'Only an active member may own a new beneficiary.');
  if (command.allowedRails.length === 0 || command.allowedRails.length > 10 || !command.allowedRails.includes(command.routingKind) || new Set(command.allowedRails).size !== command.allowedRails.length) return reject('validation', 'Allowed rails must be a unique bounded list containing the selected routing kind.', { field: 'allowedRails' });
  const duplicate = one(env.database, `SELECT b.id FROM beneficiaries b JOIN beneficiary_routes r ON r.dataset_id=b.dataset_id AND r.beneficiary_id=b.id
    WHERE b.dataset_id=? AND b.owner_party_id=? AND lower(b.display_name)=lower(?) AND r.simulated_token=? AND r.status<>'superseded'`, env.datasetId, str(member, 'party_id'), command.displayName.trim(), command.simulatedToken.trim());
  if (duplicate !== undefined) return reject('duplicate_identity', `Beneficiary ${str(duplicate, 'id')} already has this exact route.`);
  const beneficiaryId = newId('beneficiary');
  const routeId = newId('beneficiary-route');
  return prepared({ businessReference: beneficiaryId, result: { beneficiaryId, routeId, routeStatus: 'unverified' }, review: noFinanceReview(['Creates an inactive route pending independent verification; it cannot receive a payment yet.']), apply(apply) {
    run(apply.database, "INSERT INTO beneficiaries (dataset_id,id,owner_party_id,display_name,status) VALUES (?,?,?,?,'active')", apply.datasetId, beneficiaryId, str(member, 'party_id'), command.displayName.trim());
    run(apply.database, `INSERT INTO beneficiary_routes (dataset_id,id,beneficiary_id,version,routing_kind,masked_destination,simulated_token,status,verified_at,expires_at)
      VALUES (?,?,?,1,?,?,?,'unverified',NULL,NULL)`, apply.datasetId, routeId, beneficiaryId, command.routingKind.trim(), command.maskedDestination.trim(), command.simulatedToken.trim());
    apply.event({ kind: 'beneficiary', id: beneficiaryId }, `Beneficiary ${beneficiaryId} created with unverified ${command.routingKind} route ${routeId}.`);
  } });
}

function prepareBeneficiaryVerify(env: FinanceEnvironment, command: FinanceOf<'beneficiary.verify'>): Preparation {
  const beneficiary = beneficiaryRow(env, command.beneficiaryId);
  const route = routeRow(env, command.routeId);
  if (beneficiary === undefined || route === undefined || str(route, 'beneficiary_id') !== command.beneficiaryId) return reject('not_found', 'The beneficiary route does not exist.');
  const stale = requireFingerprint(route, ROUTE_COLUMNS, command.expectedFingerprint, 'beneficiary route');
  if (stale !== null) return stale;
  if (str(beneficiary, 'status') !== 'active') return reject('ineligible', 'The beneficiary is disabled.');
  if (str(route, 'status') === 'verified' && (optionalStr(route, 'expires_at') ?? '9999') > env.now) return { kind: 'unchanged', message: 'The exact route version is already verified.' };
  if (str(route, 'status') !== 'unverified') return reject('ineligible', `Route status is ${str(route, 'status')}; it cannot be verified.`);
  const evidence = one(env.database, 'SELECT party_id,status,expires_at FROM identity_evidence WHERE dataset_id=? AND id=?', env.datasetId, command.evidenceId);
  if (evidence === undefined || str(evidence, 'party_id') !== str(beneficiary, 'owner_party_id') || str(evidence, 'status') !== 'verified' || (optionalStr(evidence, 'expires_at') ?? '9999') <= env.now) return reject('ineligible', 'Current verified evidence for the beneficiary owner is required.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: command.beneficiaryId, result: { beneficiaryId: command.beneficiaryId, routeId: command.routeId, verified: true }, review: noFinanceReview([`Verifies only route version ${int(route, 'version')} and binds evidence ${command.evidenceId}.`]), apply(apply) {
    run(apply.database, "UPDATE beneficiary_routes SET status='verified',verified_at=?,expires_at=? WHERE dataset_id=? AND id=?", apply.now, new Date(Date.parse(apply.now) + 365 * 86_400_000).toISOString(), apply.datasetId, command.routeId);
    apply.event({ kind: 'beneficiary', id: command.beneficiaryId }, `Beneficiary route ${command.routeId} version ${int(route, 'version')} independently verified using ${command.evidenceId}.`);
  } }), command.approvalId);
}

function prepareRoutingUpdate(env: FinanceEnvironment, command: FinanceOf<'beneficiary.routing.update'>): Preparation {
  const beneficiary = beneficiaryRow(env, command.beneficiaryId);
  if (beneficiary === undefined) return reject('not_found', 'The beneficiary does not exist.');
  const routes = all(env.database, `SELECT id,beneficiary_id,version,routing_kind,masked_destination,simulated_token,status,verified_at,expires_at,? AS owner_party_id,? AS beneficiary_status
    FROM beneficiary_routes WHERE dataset_id=? AND beneficiary_id=? AND status<>'superseded' ORDER BY version DESC`, str(beneficiary, 'owner_party_id'), str(beneficiary, 'status'), env.datasetId, command.beneficiaryId);
  const current = routes[0];
  if (current === undefined) return reject('not_found', 'The beneficiary has no current route.');
  const stale = requireFingerprint(current, ROUTE_COLUMNS, command.expectedRouteFingerprint, 'beneficiary route');
  if (stale !== null) return stale;
  const invalid = validation([requireDate(command.effectiveDate, 'effectiveDate'), requireText(command.routingKind, 'routingKind', 'Routing kind', 30), requireText(command.maskedDestination, 'maskedDestination', 'Masked destination', 80), requireText(command.simulatedToken, 'simulatedToken', 'Simulated route token', 200)]);
  if (invalid !== null) return invalid;
  if (command.effectiveDate !== localDate(env.now, env.timeZone)) return reject('ineligible', 'Routing changes must be executed on their approved effective date.', { field: 'effectiveDate' });
  const payments = all(env.database, "SELECT id,state FROM payments WHERE dataset_id=? AND beneficiary_route_id=? AND state IN ('pending-approval','released','cancellation-requested')", env.datasetId, str(current, 'id'));
  if (payments.length > 0) return reject('open_dependencies', `${payments.length} payment(s) prohibit changing this route immediately.`);
  if (str(current, 'routing_kind') === command.routingKind.trim() && str(current, 'masked_destination') === command.maskedDestination.trim() && str(current, 'simulated_token') === command.simulatedToken.trim()) return { kind: 'unchanged', message: 'The beneficiary route already has these details.' };
  const tokenClash = one(env.database, "SELECT id FROM beneficiary_routes WHERE dataset_id=? AND simulated_token=? AND status<>'superseded'", env.datasetId, command.simulatedToken.trim());
  if (tokenClash !== undefined) return reject('duplicate_identity', 'This simulated route token is already in use.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const routeId = newId('beneficiary-route');
  const nextVersion = int(current, 'version') + 1;
  const schedules = all(env.database, "SELECT id FROM payment_schedules WHERE dataset_id=? AND beneficiary_route_id=? AND state='active'", env.datasetId, str(current, 'id')).map((row) => str(row, 'id'));
  return approvalPrepared(prepared({ businessReference: command.beneficiaryId, result: { beneficiaryId: command.beneficiaryId, routeId, version: nextVersion, status: 'unverified', pausedSchedules: schedules }, review: noFinanceReview([`Creates route version ${nextVersion} as unverified and pauses ${schedules.length} dependent schedule(s) for review.`]), apply(apply) {
    run(apply.database, "UPDATE beneficiary_routes SET status='superseded' WHERE dataset_id=? AND id=?", apply.datasetId, str(current, 'id'));
    run(apply.database, `INSERT INTO beneficiary_routes (dataset_id,id,beneficiary_id,version,routing_kind,masked_destination,simulated_token,status,verified_at,expires_at)
      VALUES (?,?,?,?,?,?,?,'unverified',NULL,NULL)`, apply.datasetId, routeId, command.beneficiaryId, nextVersion, command.routingKind.trim(), command.maskedDestination.trim(), command.simulatedToken.trim());
    for (const scheduleId of schedules) run(apply.database, "UPDATE payment_schedules SET state='paused' WHERE dataset_id=? AND id=?", apply.datasetId, scheduleId);
    apply.event({ kind: 'beneficiary', id: command.beneficiaryId }, `Routing version ${nextVersion} created unverified; ${schedules.length} schedule(s) paused for review.`);
  } }), command.approvalId);
}

function prepareBeneficiaryRetire(env: FinanceEnvironment, command: FinanceOf<'beneficiary.retire'>): Preparation {
  const beneficiary = beneficiaryRow(env, command.beneficiaryId);
  if (beneficiary === undefined) return reject('not_found', 'The beneficiary does not exist.');
  const stale = requireFingerprint(beneficiary, ['id','owner_party_id','display_name','status'], command.expectedFingerprint, 'beneficiary');
  if (stale !== null) return stale;
  if (str(beneficiary, 'status') === 'disabled') return { kind: 'unchanged', message: 'The beneficiary is already retired.' };
  const dependent = all(env.database, `SELECT p.id,p.state FROM payments p JOIN beneficiary_routes r ON r.dataset_id=p.dataset_id AND r.id=p.beneficiary_route_id
    WHERE p.dataset_id=? AND r.beneficiary_id=? AND p.state IN ('draft','pending-approval','released','cancellation-requested')`, env.datasetId, command.beneficiaryId);
  const schedules = all(env.database, `SELECT s.id FROM payment_schedules s JOIN beneficiary_routes r ON r.dataset_id=s.dataset_id AND r.id=s.beneficiary_route_id
    WHERE s.dataset_id=? AND r.beneficiary_id=? AND s.state IN ('active','paused')`, env.datasetId, command.beneficiaryId);
  if (schedules.length > 0 || dependent.some((row) => str(row, 'state') !== 'draft')) return reject('open_dependencies', 'Active schedules or progressed payments require their own cancellation or end authority.');
  if (dependent.length > 0 && command.dependentDisposition === 'reject-if-active') return reject('open_dependencies', `${dependent.length} draft payment(s) still depend on this beneficiary.`);
  return prepared({ businessReference: command.beneficiaryId, result: { beneficiaryId: command.beneficiaryId, retired: true, cancelledDrafts: dependent.length }, review: noFinanceReview([`Retires this beneficiary and ${dependent.length === 0 ? 'has no dependencies' : `cancels ${dependent.length} draft instruction(s)`}; released payments and schedules are never changed here.`]), apply(apply) {
    for (const payment of dependent) {
      run(apply.database, "UPDATE payments SET state='cancelled',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, str(payment, 'id'));
      paymentEvent(apply, str(payment, 'id'), 'cancelled', `Draft cancelled when beneficiary retired: ${command.reason.trim()}`);
    }
    run(apply.database, "UPDATE beneficiaries SET status='disabled' WHERE dataset_id=? AND id=?", apply.datasetId, command.beneficiaryId);
    apply.event({ kind: 'beneficiary', id: command.beneficiaryId }, `Beneficiary ${command.beneficiaryId} retired; ${dependent.length} draft payment(s) cancelled.`);
  } });
}

function validRouteForPayment(env: FinanceEnvironment, routeId: string, expectedFingerprint: string, rail: string): Row | Rejection {
  const route = routeRow(env, routeId);
  if (route === undefined) return reject('not_found', 'The beneficiary route does not exist.');
  const stale = requireFingerprint(route, ROUTE_COLUMNS, expectedFingerprint, 'beneficiary route');
  if (stale !== null) return stale;
  if (str(route, 'beneficiary_status') !== 'active' || str(route, 'status') !== 'verified' || (optionalStr(route, 'expires_at') ?? '') <= env.now) return reject('ineligible', 'The beneficiary route is not currently verified and active.');
  if (str(route, 'routing_kind') !== rail) return reject('ineligible', 'The selected rail differs from the verified route.');
  return route;
}

function ownerParty(env: FinanceEnvironment, accountId: string): string | undefined {
  return optionalStr(one(env.database, `SELECT m.party_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
    WHERE a.dataset_id=? AND a.id=?`, env.datasetId, accountId), 'party_id') ?? undefined;
}

function requirePaymentWindow(env: FinanceEnvironment, requestedDate: string, calendarVersion: string, cutoffAt: string): Rejection | null {
  const invalid = validation([
    requireDate(requestedDate, 'requestedDate'),
    requireText(calendarVersion, 'calendarVersion', 'Calendar version', 120),
    requireInstant(cutoffAt, 'cutoffAt'),
  ]);
  if (invalid !== null) return invalid;
  const normalizedCutoff = normalizeInstant(cutoffAt);
  if (normalizedCutoff === null) return reject('validation', 'Use a valid ISO-8601 cutoff instant with an explicit offset.', { field: 'cutoffAt' });
  const calendar = one(env.database, 'SELECT calendar_version,is_business_day,payment_cutoff_at FROM calendar_days WHERE dataset_id=? AND local_date=?', env.datasetId, requestedDate);
  if (calendar === undefined) return reject('ineligible', 'The requested payment date is outside the configured business calendar.');
  if (str(calendar, 'calendar_version') !== calendarVersion || str(calendar, 'payment_cutoff_at') !== normalizedCutoff) {
    return reject('stale_version', 'The payment calendar or cutoff changed after review.');
  }
  if (int(calendar, 'is_business_day') !== 1) return reject('ineligible', 'The requested payment date is not a business day.');
  const today = localDate(env.now, env.timeZone);
  if (requestedDate < today) return reject('ineligible', 'The requested payment date has passed; select and authorize a current business date explicitly.');
  if (requestedDate === today && normalizedCutoff <= env.now) {
    return reject('ineligible', 'The requested payment date cutoff has passed; select and authorize a later business date explicitly.');
  }
  return null;
}

function preparePaymentCreate(env: FinanceEnvironment, command: FinanceOf<'payment.create'>): Preparation {
  const account = loadAccount(env, command.sourceAccountId);
  if (account === undefined) return reject('not_found', 'The source account does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedSourceVersion), requireMoney(env, command.amount, 'amount'), requireText(command.reference, 'reference', 'Payment reference', 80)]);
  if (invalid !== null) return invalid;
  const window = requirePaymentWindow(env, command.requestedDate, command.calendarVersion, command.cutoffAt);
  if (window !== null) return window;
  const route = validRouteForPayment(env, command.beneficiaryRouteId, command.expectedRouteFingerprint, command.rail);
  if (isRejection(route)) return route;
  if (ownerParty(env, command.sourceAccountId) !== str(route, 'owner_party_id')) return reject('ownership_mismatch', 'The source account and beneficiary belong to different members.');
  const funds = requireDebit(env, command.sourceAccountId, command.amount);
  if (funds !== null) return funds;
  const today = localDate(env.now, env.timeZone);
  const latest = new Date(`${today}T00:00:00Z`); latest.setUTCFullYear(latest.getUTCFullYear() + 1);
  if (command.requestedDate < today || command.requestedDate > latest.toISOString().slice(0, 10)) return reject('ineligible', 'The requested date is outside the supported one-year payment window.');
  if (one(env.database, 'SELECT 1 AS found FROM payments WHERE dataset_id=? AND reference=?', env.datasetId, command.reference.trim()) !== undefined) return reject('duplicate_identity', 'A payment already uses this reference.');
  const paymentId = newId('payment');
  return prepared({ businessReference: command.reference.trim(), result: { paymentId, reference: command.reference.trim(), state: command.targetState }, review: { amount: command.amount, exponent: null, description: command.reference.trim(), accounts: [], consequences: [command.targetState === 'draft' ? 'Saves a draft without reserving funds.' : 'Creates a pending-approval instruction and reserves the exact amount; it is not released or settled.'] }, apply(apply) {
    run(apply.database, `INSERT INTO payments (dataset_id,id,reference,source_account_id,beneficiary_route_id,amount_minor_units,currency,requested_date,state,version)
      VALUES (?,?,?,?,?,?,?,?,?,1)`, apply.datasetId, paymentId, command.reference.trim(), command.sourceAccountId, command.beneficiaryRouteId, command.amount.minorUnits, command.amount.currency, command.requestedDate, command.targetState);
    paymentEvent(apply, paymentId, 'draft', 'Payment instruction prepared.');
    if (command.targetState === 'pending-approval') {
      paymentEvent(apply, paymentId, 'pending-approval', 'Submitted for independent approval.');
      run(apply.database, "INSERT INTO reservations (dataset_id,id,account_id,payment_id,amount_minor_units,status,created_at,ended_at) VALUES (?,?,?,?,?,'active',?,NULL)", apply.datasetId, newId('reservation'), command.sourceAccountId, paymentId, command.amount.minorUnits, apply.now);
      run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.sourceAccountId);
    }
    apply.event({ kind: 'payment', id: paymentId }, `Payment ${command.reference.trim()} created in ${command.targetState} state for ${command.amount.minorUnits} ${command.amount.currency} minor units.`);
  } });
}

function paymentRow(env: FinanceEnvironment, paymentId: string): Row | undefined {
  return one(env.database, `SELECT p.id,p.reference,p.source_account_id,p.beneficiary_route_id,p.amount_minor_units,p.currency,p.requested_date,p.state,p.version,
    r.status AS route_status,r.expires_at AS route_expires_at,b.status AS beneficiary_status FROM payments p
    JOIN beneficiary_routes r ON r.dataset_id=p.dataset_id AND r.id=p.beneficiary_route_id JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id
    WHERE p.dataset_id=? AND p.id=?`, env.datasetId, paymentId);
}

function preparePaymentSubmit(env: FinanceEnvironment, command: FinanceOf<'payment.submit'>): Preparation {
  const payment = paymentRow(env, command.paymentId);
  if (payment === undefined) return reject('not_found', 'The payment does not exist.');
  if (int(payment, 'version') !== command.expectedVersion) return reject('stale_version', `The payment changed after review (version ${command.expectedVersion} is now ${int(payment, 'version')}).`, { currentVersion: int(payment, 'version') });
  if (str(payment, 'state') === 'pending-approval') return { kind: 'unchanged', message: 'The payment is already pending approval.' };
  if (str(payment, 'state') !== 'draft') return reject('ineligible', 'Only a draft payment may be submitted.');
  if (str(payment, 'route_status') !== 'verified' || (optionalStr(payment, 'route_expires_at') ?? '') <= env.now || str(payment, 'beneficiary_status') !== 'active') return reject('ineligible', 'The draft beneficiary route is no longer verified and active.');
  const amount = { minorUnits: int(payment, 'amount_minor_units'), currency: str(payment, 'currency') };
  const funds = requireDebit(env, str(payment, 'source_account_id'), amount);
  if (funds !== null) return funds;
  return prepared({ businessReference: str(payment, 'reference'), result: { paymentId: command.paymentId, state: 'pending-approval', amount }, review: { amount, exponent: null, description: str(payment, 'reference'), accounts: [], consequences: ['Submits the exact draft for independent approval and reserves its funds.'] }, apply(apply) {
    run(apply.database, "UPDATE payments SET state='pending-approval',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, command.paymentId);
    run(apply.database, "INSERT INTO reservations (dataset_id,id,account_id,payment_id,amount_minor_units,status,created_at,ended_at) VALUES (?,?,?,?,?,'active',?,NULL)", apply.datasetId, newId('reservation'), str(payment, 'source_account_id'), command.paymentId, amount.minorUnits, apply.now);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(payment, 'source_account_id'));
    paymentEvent(apply, command.paymentId, 'pending-approval', 'Draft submitted for independent approval.');
    apply.event({ kind: 'payment', id: command.paymentId }, `Payment ${str(payment, 'reference')} submitted for approval; funds reserved once.`);
  } });
}

function preparePaymentRelease(env: FinanceEnvironment, command: FinanceOf<'payment.approve_release'>): Preparation {
  const payment = paymentRow(env, command.paymentId);
  if (payment === undefined) return reject('not_found', 'The payment does not exist.');
  if (int(payment, 'version') !== command.expectedVersion) return reject('stale_version', `The payment changed after review (version ${command.expectedVersion} is now ${int(payment, 'version')}).`, { currentVersion: int(payment, 'version') });
  if (str(payment, 'state') === 'released') return { kind: 'unchanged', message: 'The payment is already released.' };
  if (str(payment, 'state') !== 'pending-approval') return reject('ineligible', `Payment state is ${str(payment, 'state')}; only pending approval may be released.`);
  if (str(payment, 'requested_date') !== command.requestedDate) return reject('stale_version', 'The payment date changed after review.');
  const window = requirePaymentWindow(env, command.requestedDate, command.calendarVersion, command.cutoffAt);
  if (window !== null) return window;
  if (str(payment, 'route_status') !== 'verified' || (optionalStr(payment, 'route_expires_at') ?? '') <= env.now || str(payment, 'beneficiary_status') !== 'active') return reject('ineligible', 'The payment destination is no longer verified and active.');
  const reservation = one(env.database, "SELECT amount_minor_units,status FROM reservations WHERE dataset_id=? AND payment_id=?", env.datasetId, command.paymentId);
  if (reservation === undefined || str(reservation, 'status') !== 'active' || int(reservation, 'amount_minor_units') !== int(payment, 'amount_minor_units')) return reject('ineligible', 'The payment reservation is missing or does not match the reviewed amount.');
  const currentAccount = accountFacts(env.database, env.datasetId, str(payment, 'source_account_id'), env.now);
  if (currentAccount === undefined || currentAccount.currency !== str(payment, 'currency')) return reject('ineligible', 'The payment source account is no longer available in the reviewed currency.');
  const eligible = debitEligibility(currentAccount);
  if (!eligible.eligible) return reject('ineligible', eligible.reasons.join(' '));
  if (currentAccount.availableMinorUnits + int(reservation, 'amount_minor_units') < int(payment, 'amount_minor_units')) return reject('insufficient_funds', 'Current funds no longer back the reserved payment amount.');
  const maker = one(env.database, "SELECT actor_id FROM payment_events WHERE dataset_id=? AND payment_id=? AND state='pending-approval' ORDER BY sequence DESC LIMIT 1", env.datasetId, command.paymentId);
  const approvalRow = one(env.database, 'SELECT maker_actor_id FROM business_approvals WHERE dataset_id=? AND id=?', env.datasetId, command.approvalId);
  if (maker === undefined || approvalRow === undefined || optionalStr(maker, 'actor_id') !== str(approvalRow, 'maker_actor_id')) return reject('not_authorized', 'Approval maker does not match the operator who submitted this payment.');
  const amount = { minorUnits: int(payment, 'amount_minor_units'), currency: str(payment, 'currency') };
  const approval = requireApproval(env, command, command.approvalId, amount);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: str(payment, 'reference'), result: { paymentId: command.paymentId, state: 'released' }, review: { amount, exponent: null, description: str(payment, 'reference'), accounts: [], consequences: ['Releases the exact reviewed instruction once; settlement remains a separate state.'] }, apply(apply) {
    run(apply.database, "UPDATE payments SET state='released',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, command.paymentId);
    paymentEvent(apply, command.paymentId, 'released', `Released under approval ${command.approvalId}.`);
    apply.event({ kind: 'payment', id: command.paymentId }, `Payment ${str(payment, 'reference')} released under independent approval; it is not yet settled.`);
  } }), command.approvalId);
}

function preparePaymentSettle(env: FinanceEnvironment, command: FinanceOf<'payment.settle'>): Preparation {
  const payment = paymentRow(env, command.paymentId);
  if (payment === undefined) return reject('not_found', 'The payment does not exist.');
  if (int(payment, 'version') !== command.expectedVersion) return reject('stale_version', `The payment changed after review (version ${command.expectedVersion} is now ${int(payment, 'version')}).`, { currentVersion: int(payment, 'version') });
  const invalid = requireText(command.settlementReference, 'settlementReference', 'Settlement reference', 120);
  if (invalid !== null) return invalid;
  if (str(payment, 'state') === 'settled') return { kind: 'unchanged', message: 'The payment is already settled.' };
  if (str(payment, 'state') !== 'released' || str(payment, 'requested_date') > localDate(env.now, env.timeZone)) return reject('ineligible', 'Only a released payment due on or before today may settle.');
  if (one(env.database, 'SELECT 1 AS found FROM operations WHERE dataset_id=? AND operation_kind=? AND business_reference=?', env.datasetId, command.kind, command.settlementReference.trim()) !== undefined) return reject('duplicate_identity', 'The settlement reference is already in use.');
  const customer = ledgerForAccount(env, str(payment, 'source_account_id'));
  const settlement = generalLedger(env, str(payment, 'currency'), 'settlement');
  if (customer === undefined || settlement === undefined) return reject('ineligible', 'Payment settlement ledgers are unavailable.');
  const amount = { minorUnits: int(payment, 'amount_minor_units'), currency: str(payment, 'currency') };
  return prepared({ businessReference: command.settlementReference.trim(), result: { paymentId: command.paymentId, state: 'settled', settlementReference: command.settlementReference.trim(), amount }, review: { amount, exponent: null, description: command.settlementReference.trim(), accounts: [], consequences: ['Posts one settlement journal, closes the reservation and marks the released payment settled.'] }, apply(apply) {
    const journalId = insertJournal(apply, { debitLedgerId: str(customer, 'id'), creditLedgerId: str(settlement, 'id'), amount: amount.minorUnits, currency: amount.currency, description: `Payment settlement ${command.settlementReference.trim()}`, prefix: 'PS' });
    run(apply.database, "INSERT INTO payment_postings (dataset_id,id,payment_id,kind,journal_id) VALUES (?,?,?,'settlement',?)", apply.datasetId, newId('payment-posting'), command.paymentId, journalId);
    run(apply.database, "UPDATE reservations SET status='consumed',ended_at=? WHERE dataset_id=? AND payment_id=? AND status='active'", apply.now, apply.datasetId, command.paymentId);
    run(apply.database, "UPDATE payments SET state='settled',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, command.paymentId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(payment, 'source_account_id'));
    paymentEvent(apply, command.paymentId, 'settled', `Settlement ${command.settlementReference.trim()} posted.`);
    apply.event({ kind: 'payment', id: command.paymentId }, `Payment ${str(payment, 'reference')} settled under ${command.settlementReference.trim()}.`);
  } });
}

function occurrenceDates(start: string, end: string, frequency: FinanceOf<'payment.schedule.create'>['frequency'], interval: number): string[] {
  const dates: string[] = [];
  const cursor = new Date(`${start}T00:00:00.000Z`);
  const finish = new Date(`${end}T00:00:00.000Z`);
  const monthlyAnchor = cursor.getUTCDate();
  while (cursor <= finish && dates.length <= 366) {
    dates.push(cursor.toISOString().slice(0, 10));
    if (frequency === 'daily') cursor.setUTCDate(cursor.getUTCDate() + interval);
    else if (frequency === 'weekly') cursor.setUTCDate(cursor.getUTCDate() + interval * 7);
    else {
      const nextMonth = new Date(Date.UTC(cursor.getUTCFullYear(), cursor.getUTCMonth() + interval, 1));
      const lastDay = new Date(Date.UTC(nextMonth.getUTCFullYear(), nextMonth.getUTCMonth() + 1, 0)).getUTCDate();
      cursor.setTime(Date.UTC(nextMonth.getUTCFullYear(), nextMonth.getUTCMonth(), Math.min(monthlyAnchor, lastDay)));
    }
  }
  return dates;
}

function prepareScheduleCreate(env: FinanceEnvironment, command: FinanceOf<'payment.schedule.create'>): Preparation {
  const account = loadAccount(env, command.sourceAccountId);
  if (account === undefined) return reject('not_found', 'The source account does not exist.');
  const invalid = validation([requireAccountVersion(account, command.expectedSourceVersion), requireMoney(env, command.amount, 'amount'), requireDate(command.startDate, 'startDate'), requireDate(command.endDate, 'endDate')]);
  if (invalid !== null) return invalid;
  const reviewedRoute = routeRow(env, command.beneficiaryRouteId);
  if (reviewedRoute === undefined) return reject('not_found', 'The beneficiary route does not exist.');
  const route = validRouteForPayment(env, command.beneficiaryRouteId, command.expectedRouteFingerprint, str(reviewedRoute, 'routing_kind'));
  if (isRejection(route)) return route;
  if (ownerParty(env, command.sourceAccountId) !== str(route, 'owner_party_id')) return reject('ownership_mismatch', 'The account and beneficiary belong to different members.');
  if (str(account, 'currency') !== command.amount.currency) return reject('currency_mismatch', 'The scheduled amount currency differs from the source account.');
  if (!Number.isSafeInteger(command.interval) || command.interval < 1 || command.interval > 12 || command.startDate < localDate(env.now, env.timeZone) || command.endDate < command.startDate) return reject('validation', 'Schedule dates or interval are invalid.');
  const dates = occurrenceDates(command.startDate, command.endDate, command.frequency, command.interval);
  if (dates.length === 0 || dates.length > 366) return reject('limit_exceeded', 'A recurring schedule must contain 1 to 366 bounded occurrences.');
  const approval = requireApproval(env, command, command.approvalId, command.amount);
  if (approval !== null) return approval;
  const scheduleId = newId('payment-schedule');
  return approvalPrepared(prepared({ businessReference: scheduleId, result: { scheduleId, occurrenceCount: dates.length, firstDate: dates[0], lastDate: dates.at(-1) }, review: { amount: command.amount, exponent: null, description: `${command.frequency} every ${command.interval}`, accounts: [], consequences: [`Creates a finite ${dates.length}-occurrence schedule; no occurrence is released or settled.`] }, apply(apply) {
    run(apply.database, `INSERT INTO payment_schedules (dataset_id,id,source_account_id,beneficiary_route_id,rule_json,time_zone,calendar_version,start_date,end_date,state)
      VALUES (?,?,?,?,?,?,?,?,?,'active')`, apply.datasetId, scheduleId, command.sourceAccountId, command.beneficiaryRouteId, JSON.stringify({ amountMinorUnits: command.amount.minorUnits, currency: command.amount.currency, frequency: command.frequency, interval: command.interval, shift: 'none', monthEndPolicy: 'clamp-to-last-day' }), apply.timeZone, 'US-FI-2026.1', command.startDate, command.endDate);
    dates.forEach((date) => run(apply.database, "INSERT INTO schedule_occurrences (dataset_id,id,schedule_id,local_date,payment_id,state) VALUES (?,?,?,?,NULL,'planned')", apply.datasetId, newId('schedule-occurrence'), scheduleId, date));
    apply.event({ kind: 'payment-schedule', id: scheduleId }, `Finite schedule ${scheduleId} created with ${dates.length} planned occurrence(s), none released.`);
  } }), command.approvalId);
}

function prepareScheduleMaterialize(env: FinanceEnvironment, command: FinanceOf<'payment.schedule.materialize'>): Preparation {
  const occurrence = one(env.database, `SELECT o.id,o.schedule_id,o.local_date,o.payment_id,o.state,s.source_account_id,s.beneficiary_route_id,s.rule_json,s.state AS schedule_state,
    p.state AS payment_state,p.version AS payment_version,p.amount_minor_units AS payment_amount_minor_units,p.currency AS payment_currency,p.requested_date AS payment_requested_date
    FROM schedule_occurrences o JOIN payment_schedules s ON s.dataset_id=o.dataset_id AND s.id=o.schedule_id
    LEFT JOIN payments p ON p.dataset_id=o.dataset_id AND p.id=o.payment_id WHERE o.dataset_id=? AND o.id=?`, env.datasetId, command.occurrenceId);
  if (occurrence === undefined) return reject('not_found', 'The schedule occurrence does not exist.');
  const columns = ['id','schedule_id','local_date','payment_id','state','source_account_id','beneficiary_route_id','rule_json','schedule_state','payment_state','payment_version','payment_amount_minor_units','payment_currency','payment_requested_date'] as const;
  const stale = requireFingerprint(occurrence, columns, command.expectedFingerprint, 'schedule occurrence');
  if (stale !== null) return stale;
  if (optionalStr(occurrence, 'payment_id') !== null) return { kind: 'unchanged', message: 'The occurrence is already materialized.' };
  if (str(occurrence, 'state') !== 'planned' || str(occurrence, 'schedule_state') !== 'active' || str(occurrence, 'local_date') > localDate(env.now, env.timeZone)) return reject('ineligible', 'Only a due planned occurrence on an active schedule may materialize.');
  let rule: unknown;
  try { rule = JSON.parse(str(occurrence, 'rule_json')) as unknown; } catch { return reject('ineligible', 'The stored schedule rule is invalid.'); }
  if (rule === null || typeof rule !== 'object' || Array.isArray(rule)) return reject('ineligible', 'The stored schedule rule is invalid.');
  const amount = { minorUnits: Number(Reflect.get(rule, 'amountMinorUnits')), currency: String(Reflect.get(rule, 'currency')) };
  const invalid = requireMoney(env, amount, 'amount');
  if (invalid !== null) return reject('ineligible', 'The stored schedule amount is invalid.');
  const route = routeRow(env, str(occurrence, 'beneficiary_route_id'));
  if (route === undefined || str(route, 'status') !== 'verified' || (optionalStr(route, 'expires_at') ?? '') <= env.now || str(route, 'beneficiary_status') !== 'active') return reject('ineligible', 'The scheduled beneficiary route is no longer verified and active.');
  const funds = requireDebit(env, str(occurrence, 'source_account_id'), amount);
  if (funds !== null) return funds;
  const paymentId = newId('payment');
  const reference = nextNumber(env.database, 'payments', 'reference', env.datasetId, 'SO', 9);
  return prepared({ businessReference: reference, result: { occurrenceId: command.occurrenceId, paymentId, state: 'pending-approval', amount }, review: { amount, exponent: null, description: `Scheduled occurrence ${command.occurrenceId}`, accounts: [], consequences: ['Materializes one due occurrence as a pending-approval payment and reserves funds exactly once.'] }, apply(apply) {
    run(apply.database, `INSERT INTO payments (dataset_id,id,reference,source_account_id,beneficiary_route_id,amount_minor_units,currency,requested_date,state,version)
      VALUES (?,?,?,?,?,?,?,?,'pending-approval',1)`, apply.datasetId, paymentId, reference, str(occurrence, 'source_account_id'), str(occurrence, 'beneficiary_route_id'), amount.minorUnits, amount.currency, str(occurrence, 'local_date'));
    run(apply.database, "INSERT INTO reservations (dataset_id,id,account_id,payment_id,amount_minor_units,status,created_at,ended_at) VALUES (?,?,?,?,?,'active',?,NULL)", apply.datasetId, newId('reservation'), str(occurrence, 'source_account_id'), paymentId, amount.minorUnits, apply.now);
    run(apply.database, "UPDATE schedule_occurrences SET payment_id=?,state='materialized' WHERE dataset_id=? AND id=?", paymentId, apply.datasetId, command.occurrenceId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(occurrence, 'source_account_id'));
    paymentEvent(apply, paymentId, 'pending-approval', `Materialized from schedule occurrence ${command.occurrenceId}.`);
    apply.event({ kind: 'payment', id: paymentId }, `Due schedule occurrence ${command.occurrenceId} materialized once as payment ${reference}.`);
  } });
}

function prepareOccurrenceAmend(env: FinanceEnvironment, command: FinanceOf<'payment.occurrence.amend'>): Preparation {
  const occurrence = one(env.database, `SELECT o.id,o.schedule_id,o.local_date,o.payment_id,o.state,s.source_account_id,s.beneficiary_route_id,s.rule_json,s.state AS schedule_state,
    p.state AS payment_state,p.version AS payment_version,p.amount_minor_units AS payment_amount_minor_units,p.currency AS payment_currency,p.requested_date AS payment_requested_date
    FROM schedule_occurrences o JOIN payment_schedules s ON s.dataset_id=o.dataset_id AND s.id=o.schedule_id
    LEFT JOIN payments p ON p.dataset_id=o.dataset_id AND p.id=o.payment_id WHERE o.dataset_id=? AND o.id=?`, env.datasetId, command.occurrenceId);
  if (occurrence === undefined) return reject('not_found', 'The scheduled occurrence does not exist.');
  const stale = requireFingerprint(occurrence, ['id','schedule_id','local_date','payment_id','state','source_account_id','beneficiary_route_id','rule_json','schedule_state','payment_state','payment_version','payment_amount_minor_units','payment_currency','payment_requested_date'], command.expectedFingerprint, 'scheduled occurrence');
  if (stale !== null) return stale;
  const invalid = validation([requireMoney(env, command.newAmount, 'newAmount'), requireDate(command.newDate, 'newDate')]);
  if (invalid !== null) return invalid;
  if (str(occurrence, 'state') !== 'planned' || str(occurrence, 'schedule_state') !== 'active') return reject('ineligible', 'Only a planned occurrence on an active schedule may be amended.');
  if (one(env.database, 'SELECT 1 AS found FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? AND local_date=? AND id<>?', env.datasetId, str(occurrence, 'schedule_id'), command.newDate, command.occurrenceId) !== undefined) return reject('duplicate_identity', 'Another occurrence already uses the requested date.');
  const linkedPaymentId = optionalStr(occurrence, 'payment_id');
  if (linkedPaymentId !== null && optionalStr(occurrence, 'payment_state') !== 'draft') return reject('ineligible', 'The linked occurrence instruction is no longer an amendable draft.');
  const account = loadAccount(env, str(occurrence, 'source_account_id'));
  if (account === undefined || str(account, 'currency') !== command.newAmount.currency) return reject('currency_mismatch', 'The amended amount currency differs from the source account.');
  const paymentId = linkedPaymentId ?? newId('payment');
  const reference = linkedPaymentId === null ? nextNumber(env.database, 'payments', 'reference', env.datasetId, 'SO', 9) : null;
  return prepared({ businessReference: command.occurrenceId, result: { occurrenceId: command.occurrenceId, paymentId, newDate: command.newDate, newAmount: command.newAmount, reusedDraft: linkedPaymentId !== null }, review: { amount: command.newAmount, exponent: null, description: `Occurrence exception ${command.occurrenceId}`, accounts: [], consequences: ['Changes only one planned occurrence and records its amount in a linked draft payment.'] }, apply(apply) {
    if (linkedPaymentId === null) {
      run(apply.database, `INSERT INTO payments (dataset_id,id,reference,source_account_id,beneficiary_route_id,amount_minor_units,currency,requested_date,state,version)
        VALUES (?,?,?,?,?,?,?,?,'draft',1)`, apply.datasetId, paymentId, reference, str(occurrence, 'source_account_id'), str(occurrence, 'beneficiary_route_id'), command.newAmount.minorUnits, command.newAmount.currency, command.newDate);
      paymentEvent(apply, paymentId, 'draft', `Draft exception for schedule occurrence ${command.occurrenceId}.`);
    } else {
      run(apply.database, 'UPDATE payments SET amount_minor_units=?,currency=?,requested_date=?,version=version+1 WHERE dataset_id=? AND id=?', command.newAmount.minorUnits, command.newAmount.currency, command.newDate, apply.datasetId, paymentId);
      paymentEvent(apply, paymentId, 'draft', `Draft exception amended for schedule occurrence ${command.occurrenceId}.`);
    }
    if (str(occurrence, 'local_date') !== command.newDate || linkedPaymentId === null) {
      run(apply.database, 'UPDATE schedule_occurrences SET local_date=?,payment_id=? WHERE dataset_id=? AND id=?', command.newDate, paymentId, apply.datasetId, command.occurrenceId);
    }
    apply.event({ kind: 'payment', id: paymentId }, `Occurrence ${command.occurrenceId} alone amended to ${command.newDate} and ${command.newAmount.minorUnits} ${command.newAmount.currency} minor units.`);
  } });
}

function preparePaymentCancel(env: FinanceEnvironment, command: FinanceOf<'payment.cancel'>): Preparation {
  const payment = paymentRow(env, command.paymentId);
  if (payment === undefined) return reject('not_found', 'The payment does not exist.');
  if (int(payment, 'version') !== command.expectedVersion) return reject('stale_version', `The payment changed after review (version ${command.expectedVersion} is now ${int(payment, 'version')}).`, { currentVersion: int(payment, 'version') });
  const invalid = requireText(command.reason, 'reason', 'Cancellation reason');
  if (invalid !== null) return invalid;
  const state = str(payment, 'state');
  if (state === 'cancelled') return { kind: 'unchanged', message: 'The payment is already cancelled.' };
  if (!['draft','pending-approval','released'].includes(state)) return reject('ineligible', `Payment state ${state} is not cancellable; return handling may be required.`);
  const immediate = state !== 'released';
  const requestId = newId('payment-cancel');
  return prepared({ businessReference: str(payment, 'reference'), result: { paymentId: command.paymentId, state: immediate ? 'cancelled' : 'cancellation-requested', cancellationAcknowledged: immediate }, review: noFinanceReview([immediate ? 'Cancels the instruction and releases its reservation once.' : 'Records a cancellation request only; the released payment is not represented as cancelled.']), apply(apply) {
    run(apply.database, 'UPDATE payments SET state=?,version=version+1 WHERE dataset_id=? AND id=?', immediate ? 'cancelled' : 'cancellation-requested', apply.datasetId, command.paymentId);
    run(apply.database, 'INSERT INTO payment_cancel_requests (dataset_id,id,payment_id,actor_id,state,reason,requested_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, requestId, command.paymentId, apply.actorId, immediate ? 'accepted' : 'requested', command.reason.trim(), apply.now);
    paymentEvent(apply, command.paymentId, immediate ? 'cancelled' : 'cancellation-requested', command.reason.trim());
    if (immediate) run(apply.database, "UPDATE reservations SET status='released',ended_at=? WHERE dataset_id=? AND payment_id=? AND status='active'", apply.now, apply.datasetId, command.paymentId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(payment, 'source_account_id'));
    apply.event({ kind: 'payment', id: command.paymentId }, `Payment ${str(payment, 'reference')} moved to ${immediate ? 'cancelled' : 'cancellation-requested'}: ${command.reason.trim()}`);
  } });
}

function prepareReturnResolve(env: FinanceEnvironment, command: FinanceOf<'payment.return.resolve'>): Preparation {
  const returned = one(env.database, `SELECT r.id,r.payment_id,r.return_code,r.amount_minor_units,r.occurred_at,r.settlement_reference,
    p.source_account_id,p.amount_minor_units AS payment_amount_minor_units,p.currency,p.reference,p.state,p.version AS payment_version,a.version AS account_version
    FROM payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id
    JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE r.dataset_id=? AND r.id=?`, env.datasetId, command.returnId);
  if (returned === undefined || str(returned, 'payment_id') !== command.paymentId) return reject('not_found', 'The named return does not match this payment.');
  const stale = requireFingerprint(returned, ['id','payment_id','return_code','amount_minor_units','occurred_at','settlement_reference','source_account_id','payment_amount_minor_units','currency','reference','state','payment_version','account_version'], command.expectedFingerprint, 'payment return');
  if (stale !== null) return stale;
  const duplicateReturnEvidence = all(env.database, `SELECT id FROM payment_returns
    WHERE dataset_id=? AND payment_id=? AND settlement_reference=? ORDER BY id`, env.datasetId, command.paymentId, str(returned, 'settlement_reference'));
  if (duplicateReturnEvidence.length !== 1) return reject('ineligible', 'The payment has ambiguous duplicate return evidence.');
  if (str(returned, 'state') !== 'returned') return reject('ineligible', 'The payment is not in returned state.');
  if (one(env.database, "SELECT 1 AS found FROM payment_events WHERE dataset_id=? AND payment_id=? AND state='return-resolved'", env.datasetId, command.paymentId) !== undefined) return { kind: 'unchanged', message: 'The return was already resolved.' };
  const amount = { minorUnits: int(returned, 'amount_minor_units'), currency: str(returned, 'currency') };
  if (amount.minorUnits !== int(returned, 'payment_amount_minor_units')) return reject('ineligible', 'The return amount does not match the original payment.');
  const postingRows = all(env.database, `SELECT pp.kind,pp.journal_id,j.status,COUNT(jl.line_number) AS line_count,
      SUM(jl.debit_minor_units) AS debits,SUM(jl.credit_minor_units) AS credits,
      SUM(CASE WHEN la.customer_account_id=p.source_account_id THEN jl.debit_minor_units ELSE 0 END) AS customer_debit,
      SUM(CASE WHEN la.customer_account_id=p.source_account_id THEN jl.credit_minor_units ELSE 0 END) AS customer_credit,
      SUM(CASE WHEN la.kind='settlement' THEN jl.debit_minor_units ELSE 0 END) AS settlement_debit,
      SUM(CASE WHEN la.kind='settlement' THEN jl.credit_minor_units ELSE 0 END) AS settlement_credit,
      SUM(CASE WHEN jl.currency<>p.currency THEN 1 ELSE 0 END) AS wrong_currency
    FROM payment_postings pp JOIN payments p ON p.dataset_id=pp.dataset_id AND p.id=pp.payment_id
    JOIN journals j ON j.dataset_id=pp.dataset_id AND j.id=pp.journal_id
    JOIN journal_lines jl ON jl.dataset_id=j.dataset_id AND jl.journal_id=j.id
    JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id
    WHERE pp.dataset_id=? AND pp.payment_id=? GROUP BY pp.kind,pp.journal_id,j.status`, env.datasetId, command.paymentId);
  const validPosting = (posting: Row | undefined, kind: 'settlement' | 'return'): boolean => posting !== undefined
    && str(posting, 'status') === 'posted' && int(posting, 'line_count') === 2 && int(posting, 'wrong_currency') === 0
    && int(posting, 'debits') === amount.minorUnits && int(posting, 'credits') === amount.minorUnits
    && (kind === 'settlement'
      ? int(posting, 'customer_debit') === amount.minorUnits && int(posting, 'customer_credit') === 0 && int(posting, 'settlement_debit') === 0 && int(posting, 'settlement_credit') === amount.minorUnits
      : int(posting, 'customer_debit') === 0 && int(posting, 'customer_credit') === amount.minorUnits && int(posting, 'settlement_debit') === amount.minorUnits && int(posting, 'settlement_credit') === 0);
  const settlementPostings = postingRows.filter((row) => str(row, 'kind') === 'settlement');
  if (settlementPostings.length !== 1 || !validPosting(settlementPostings[0], 'settlement')) return reject('ineligible', 'The original payment lacks one exact settlement posting.');
  const returnPostings = postingRows.filter((row) => str(row, 'kind') === 'return');
  if (returnPostings.length > 1) return reject('ineligible', 'The payment has ambiguous duplicate return postings.');
  const existingPosting = returnPostings[0];
  if (existingPosting !== undefined && !validPosting(existingPosting, 'return')) return reject('ineligible', 'The existing return posting does not match the original payment.');
  let customer: Row | undefined;
  let settlement: Row | undefined;
  if (command.disposition === 'credit-source' && existingPosting === undefined) {
    const credit = requireCredit(env, str(returned, 'source_account_id'), amount.currency);
    if (credit !== null) return credit;
    customer = ledgerForAccount(env, str(returned, 'source_account_id'));
    settlement = generalLedger(env, amount.currency, 'settlement');
    if (customer === undefined || settlement === undefined) return reject('ineligible', 'Return ledgers are unavailable.');
  }
  const approval = requireApproval(env, command, command.approvalId, amount);
  if (approval !== null) return approval;
  const investigation = command.disposition === 'investigate' ? (() => {
    const account = loadAccount(env, str(returned, 'source_account_id'));
    const queue = one(env.database, "SELECT id FROM queues WHERE dataset_id=? AND visibility='restricted' ORDER BY id LIMIT 1", env.datasetId);
    if (account === undefined || queue === undefined) return null;
    return {
      account,
      queueId: str(queue, 'id'),
      caseId: newId('case'),
      caseNumber: nextNumber(env.database, 'cases', 'case_number', env.datasetId, 'RT', 7),
      dueAt: new Date(Date.parse(env.now) + 14 * 86_400_000).toISOString(),
    };
  })() : null;
  if (command.disposition === 'investigate' && investigation === null) return reject('ineligible', 'A restricted return-investigation case cannot be opened for this payment.');
  return approvalPrepared(prepared({ businessReference: str(returned, 'settlement_reference'), result: { returnId: command.returnId, disposition: command.disposition, existingReturnPosting: existingPosting === undefined ? null : str(existingPosting, 'journal_id'), caseId: investigation?.caseId ?? null, caseNumber: investigation?.caseNumber ?? null }, review: { amount, exponent: null, description: str(returned, 'return_code'), accounts: [], consequences: [command.disposition === 'credit-source' ? 'Confirms or posts the exact return credit once.' : 'Opens an investigation without automatically resending or changing beneficiary details.'] }, apply(apply) {
    let journalId = existingPosting === undefined ? null : str(existingPosting, 'journal_id');
    if (command.disposition === 'credit-source' && journalId === null) {
      if (customer === undefined || settlement === undefined) throw new Error('Return ledgers disappeared inside the transaction.');
      enforceSafeLedgerPosting(apply, [
        { ledgerAccountId: str(settlement, 'id'), currency: amount.currency, debitMinorUnits: amount.minorUnits, creditMinorUnits: 0 },
        { ledgerAccountId: str(customer, 'id'), currency: amount.currency, debitMinorUnits: 0, creditMinorUnits: amount.minorUnits },
      ]);
      journalId = insertJournal(apply, { debitLedgerId: str(settlement, 'id'), creditLedgerId: str(customer, 'id'), amount: amount.minorUnits, currency: amount.currency, description: `Resolved return ${command.returnId}`, prefix: 'PR' });
      run(apply.database, "INSERT INTO payment_postings (dataset_id,id,payment_id,kind,journal_id) VALUES (?,?,?,'return',?)", apply.datasetId, newId('payment-posting'), command.paymentId, journalId);
      run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(returned, 'source_account_id'));
    }
    if (investigation !== null) {
      run(apply.database, `INSERT INTO cases (dataset_id,id,case_number,member_id,account_id,queue_id,assigned_actor_id,state,priority,category,summary,opened_at,due_at,version)
        VALUES (?,?,?,?,?,?,NULL,'open','normal','payment-return',?,?,?,1)`, apply.datasetId, investigation.caseId, investigation.caseNumber, str(investigation.account, 'member_id'), str(investigation.account, 'id'), investigation.queueId, `Investigate returned payment ${str(returned, 'reference')}`, apply.now, investigation.dueAt);
      run(apply.database, "INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,1,'open',?,?,?)", apply.datasetId, newId('case-event'), investigation.caseId, apply.now, apply.actorId, `Return investigation opened from return ${command.returnId} for payment ${command.paymentId}; no resend authorized.`);
      run(apply.database, "INSERT INTO case_dependencies (dataset_id,id,case_id,kind,reference_id,state,due_at) VALUES (?,?,?,'payment-return',?,'open',?)", apply.datasetId, newId('case-dependency'), investigation.caseId, command.returnId, investigation.dueAt);
      apply.event({ kind: 'case', id: investigation.caseId }, `Return investigation case ${investigation.caseNumber} opened for return ${command.returnId}.`);
    }
    paymentEvent(apply, command.paymentId, 'return-resolved', `${command.disposition}; return ${command.returnId}; posting ${journalId ?? 'none'}.`);
    apply.event({ kind: 'payment', id: command.paymentId }, `Return ${command.returnId} resolved as ${command.disposition}; beneficiary route unchanged and no automatic resend.`);
  } }), command.approvalId);
}

function prepareScheduleEnd(env: FinanceEnvironment, command: FinanceOf<'payment.schedule.end'>): Preparation {
  const scheduleRow = one(env.database, 'SELECT id,source_account_id,beneficiary_route_id,rule_json,time_zone,calendar_version,start_date,end_date,state FROM payment_schedules WHERE dataset_id=? AND id=?', env.datasetId, command.scheduleId);
  if (scheduleRow === undefined) return reject('not_found', 'The recurring schedule does not exist.');
  const occurrences = all(env.database, 'SELECT id,local_date,payment_id,state FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? ORDER BY local_date,id', env.datasetId, command.scheduleId);
  const schedule = { ...scheduleRow, occurrence_inventory: canonicalJson(occurrences) };
  const stale = requireFingerprint(schedule, ['id','source_account_id','beneficiary_route_id','rule_json','time_zone','calendar_version','start_date','end_date','state','occurrence_inventory'], command.expectedFingerprint, 'payment schedule');
  if (stale !== null) return stale;
  if (!isIsoDate(command.endFromDate)) return reject('validation', 'End date must be a valid YYYY-MM-DD date.', { field: 'endFromDate' });
  if (str(schedule, 'state') === 'ended') return { kind: 'unchanged', message: 'The recurring schedule is already ended.' };
  const future = occurrences.filter((row) => str(row, 'local_date') >= command.endFromDate);
  const cancellable = future.filter((row) => str(row, 'state') === 'planned');
  const irreversible = future.filter((row) => ['released','settled'].includes(str(row, 'state')));
  const unresolved = future.filter((row) => !['planned','released','settled'].includes(str(row, 'state')));
  if (unresolved.length > 0) return reject('open_dependencies', `${unresolved.length} future occurrence(s) must be resolved before ending this schedule.`);
  if (cancellable.length === 0 && irreversible.length === 0) return reject('ineligible', 'The schedule has no future occurrences from this date.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: command.scheduleId, result: { scheduleId: command.scheduleId, cancelledPlanned: cancellable.length, irreversible: irreversible.map((row) => str(row, 'id')) }, review: noFinanceReview([`Ends the series from ${command.endFromDate}; cancels ${cancellable.length} planned occurrence(s), while ${irreversible.length} released or settled occurrence(s) remain disclosed and unchanged.`]), apply(apply) {
    run(apply.database, "UPDATE payment_schedules SET state='ended',end_date=? WHERE dataset_id=? AND id=?", command.endFromDate, apply.datasetId, command.scheduleId);
    for (const occurrence of cancellable) run(apply.database, "UPDATE schedule_occurrences SET state='cancelled' WHERE dataset_id=? AND id=?", apply.datasetId, str(occurrence, 'id'));
    apply.event({ kind: 'payment-schedule', id: command.scheduleId }, `Schedule ${command.scheduleId} ended from ${command.endFromDate}; ${cancellable.length} planned occurrence(s) cancelled, ${irreversible.length} irreversible disclosed.`);
  } }), command.approvalId);
}

export function prepareFinancePayments(env: FinanceEnvironment, command: FinanceCommand): Preparation | null {
  switch (command.kind) {
    case 'beneficiary.create': return prepareBeneficiaryCreate(env, command);
    case 'beneficiary.verify': return prepareBeneficiaryVerify(env, command);
    case 'beneficiary.routing.update': return prepareRoutingUpdate(env, command);
    case 'beneficiary.retire': return prepareBeneficiaryRetire(env, command);
    case 'payment.create': return preparePaymentCreate(env, command);
    case 'payment.submit': return preparePaymentSubmit(env, command);
    case 'payment.approve_release': return preparePaymentRelease(env, command);
    case 'payment.settle': return preparePaymentSettle(env, command);
    case 'payment.schedule.create': return prepareScheduleCreate(env, command);
    case 'payment.schedule.materialize': return prepareScheduleMaterialize(env, command);
    case 'payment.occurrence.amend': return prepareOccurrenceAmend(env, command);
    case 'payment.cancel': return preparePaymentCancel(env, command);
    case 'payment.return.resolve': return prepareReturnResolve(env, command);
    case 'payment.schedule.end': return prepareScheduleEnd(env, command);
    default: return null;
  }
}

export function beneficiaryFingerprint(row: Row): string { return rowFingerprint(row, ['id','owner_party_id','display_name','status']); }
export function beneficiaryRouteFingerprint(row: Row): string { return rowFingerprint(row, ROUTE_COLUMNS); }
