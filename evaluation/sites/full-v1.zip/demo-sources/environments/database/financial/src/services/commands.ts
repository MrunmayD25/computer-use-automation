import { accountProductSql } from '../product-sql.js';
import { prepareApproval, validateApprovalCommand } from './approvals.js';
import { APPROVAL_GRANTS, type ApprovalCommand } from './approval-types.js';
import { prepareFinance } from './finance.js';
import { effectiveConsentState, prepareServicing } from './servicing.js';
import { FINANCE_GRANTS, validateFinanceCommand, type FinanceCommand } from './finance-types.js';
import { SERVICING_GRANTS, isServicingCommand, type ServicingCommand } from './servicing-types.js';
import { validateCoreCommand } from './validation.js';
import { randomUUID } from 'node:crypto';

import {
  accountFacts, actorPermissions, all, authorize, authorizeQuery, canonicalJson, cleanText, datasetClock, int, isIsoDate, loadReceipt, localDate, nextNumber,
  one, optionalInt, optionalStr, OutcomeAbort, recordEvent, recordOperation, reject, requireSafeLedgerPosting, run, sha256, str, textProblem, zonedInstant,
  type Row,
} from './core.js';
import {
  CAPABILITY_GRANTS, CASE_CATEGORIES, caseTransitionAllowed, closureEligibility, creditEligibility, debitEligibility, LIMITS, ORGANIZATION_TAX_CLASSIFICATIONS,
  QUEUE_WIDENING_GRANTS, RESTRICTED_NOTE_GRANTS, routeWidensExposure, SHARED_SEARCH_GRANTS,
} from './rules.js';
import { countSavedSearches, parseSavedSearchDefinition, savedSearchRevision } from './saved-searches.js';
import { commandIntentDigest } from './command-intent.js';
import type { FinancialStore, SqlDatabase } from './store.js';
import type {
  AddressInput, CaseState, CommandKind, CommandOutcome, Money, OperationReview, Rejection, ResourceKind, ReviewedAccount, ReviewOutcome,
  SavedSearchDefinition, ServiceCommand, ServiceContext, Unchanged,
} from './types.js';

export interface Environment {
  database: SqlDatabase;
  datasetId: string;
  institutionId: string;
  institutionName: string;
  actorId: string;
  principalKind: NonNullable<ServiceContext['principalKind']>;
  now: string;
  timeZone: string;
}

export interface ApplyEnvironment extends Environment {
  operationId: string;
  event(resource: { kind: ResourceKind; id: string }, summary: string): void;
}

/** A validated command whose effects are ready to apply inside the current transaction. */
export interface Prepared {
  kind: 'prepared';
  businessReference: string;
  result: Record<string, unknown>;
  review: Omit<OperationReview, 'commandKind' | 'institutionId' | 'institutionName'>;
  apply(environment: ApplyEnvironment): void;
}

export type Preparation = Prepared | Rejection | Unchanged;

const IDEMPOTENCY_KEY = /^[A-Za-z0-9._:-]{8,128}$/u;
export const ATOMIC_BATCH_IDEMPOTENCY_PREFIX = 'internal:atomic-batch:';
export const ATOMIC_BATCH_CHILD_IDEMPOTENCY_PREFIX = `${ATOMIC_BATCH_IDEMPOTENCY_PREFIX}child:`;
const EMAIL = /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/u;
const PHONE = /^\+?[0-9][0-9 ().-]{6,19}$/u;
const HARD_AMOUNT_CEILING = 1_000_000_000_000;
const POSTAL_CODE = new RegExp(`^[A-Za-z0-9 -]{3,${LIMITS.postalCodeLength}}$`, 'u');

export function commandEnvironment(database: SqlDatabase, context: ServiceContext): Environment {
  const clock = datasetClock(database, context.binding.datasetId);
  if (clock.institutionId !== context.binding.institutionId) throw new OutcomeAbort(reject('not_authorized', 'The dataset does not belong to the requested institution.'));
  if (context.now !== undefined && (!/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/u.test(context.now) || !Number.isFinite(Date.parse(context.now)))) throw new OutcomeAbort(reject('validation', 'Business time must be a valid instant with an explicit offset.'));
  return {
    database, datasetId: context.binding.datasetId, institutionId: context.binding.institutionId, institutionName: clock.institutionName,
    actorId: context.actorId, principalKind: context.principalKind ?? 'human', now: new Date(context.now ?? clock.asOf).toISOString(), timeZone: clock.timeZone,
  };
}

export function validateCommandIdempotencyKey(idempotencyKey: unknown, allowAtomicBatchChild = false): Rejection | null {
  if (typeof idempotencyKey !== 'string' || !IDEMPOTENCY_KEY.test(idempotencyKey)) {
    return reject('validation', 'The idempotency key must contain 8 to 128 letters, digits, or . _ : - characters.', { field: 'idempotencyKey' });
  }
  if (allowAtomicBatchChild) {
    if (!idempotencyKey.startsWith(ATOMIC_BATCH_CHILD_IDEMPOTENCY_PREFIX)) throw new Error('An atomic child requires its reserved idempotency namespace.');
  } else if (idempotencyKey.startsWith(ATOMIC_BATCH_IDEMPOTENCY_PREFIX)) {
    return reject('validation', 'The idempotency key uses a reserved internal namespace.', { field: 'idempotencyKey' });
  }
  return null;
}

/** Rechecks a command's runtime shape and current actor authority without preparing or applying it. */
export function authorizeCommandTransaction(environment: Environment, command: ServiceCommand): void {
  const invalid = validateServiceCommand(command);
  if (invalid !== null) throw new OutcomeAbort(invalid);
  const denied = authorize(
    environment.database,
    environment.datasetId,
    environment.institutionId,
    environment.actorId,
    environment.now,
    CAPABILITY_GRANTS[command.kind],
  );
  if (denied !== null) throw new OutcomeAbort(denied);
}

/**
 * Removes review-time bindings from idempotency identity. The implementation lives in a
 * dependency-free utility so approval-bound maintenance evidence uses the same digest.
 */
export { commandIntentDigest } from './command-intent.js';

/** Runs one command inside a transaction already owned by the caller. Business outcomes abort that transaction. */
export function executeCommandTransaction(
  database: SqlDatabase,
  context: ServiceContext,
  command: ServiceCommand,
  idempotencyKey: string,
  allowAtomicBatchChild = false,
): Extract<CommandOutcome, { kind: 'committed' }> {
  const invalidKey = validateCommandIdempotencyKey(idempotencyKey, allowAtomicBatchChild);
  if (invalidKey !== null) throw new OutcomeAbort(invalidKey);
  const commandDigest = commandIntentDigest(command);
  const env = commandEnvironment(database, context);
  authorizeCommandTransaction(env, command);
  const existing = one(database, 'SELECT id,command_digest,actor_id FROM operations WHERE dataset_id=? AND idempotency_key=?', env.datasetId, idempotencyKey);
  if (existing !== undefined) {
    if (str(existing, 'actor_id') !== env.actorId) throw new OutcomeAbort(reject('idempotency_conflict', 'This submission key belongs to another operator.'));
    if (str(existing, 'command_digest') !== commandDigest) throw new OutcomeAbort(reject('idempotency_conflict', 'This submission key was already used for a different request.'));
    const receipt = loadReceipt(database, env.datasetId, { operationId: str(existing, 'id') });
    if (receipt === undefined) throw new Error('Committed operation has no receipt.');
    throw new OutcomeAbort({ kind: 'duplicate', receipt });
  }
  const prepared = prepare(env, command);
  if (prepared.kind !== 'prepared') throw new OutcomeAbort(prepared);
  const operationId = `op-${randomUUID()}`;
  recordOperation(database, {
    datasetId: env.datasetId, actorId: env.actorId, kind: command.kind, businessReference: prepared.businessReference, idempotencyKey,
    commandDigest, resultDigest: sha256(canonicalJson(prepared.result)), result: prepared.result, now: env.now, operationId,
  });
  prepared.apply({
    ...env, operationId,
    event: (resource, summary) => {
      const later=one(database,'SELECT occurred_at FROM business_events WHERE dataset_id=? AND resource_kind=? AND resource_id=? AND occurred_at>? ORDER BY occurred_at DESC LIMIT 1',env.datasetId,resource.kind,resource.id,env.now);
      if(later!==undefined) throw new OutcomeAbort(reject('stale_version','The business clock precedes a committed change to this record. Refresh its state and observation time.'));
      recordEvent(database, { datasetId: env.datasetId, actorId: env.actorId, operationId, now: env.now, kind: command.kind, resource, summary, eventId: `event-${randomUUID()}` });
    },
  });
  const receipt = loadReceipt(database, env.datasetId, { operationId });
  if (receipt === undefined) throw new Error('Committed operation has no receipt.');
  return { kind: 'committed', receipt };
}

/**
 * Validates and commits one business command atomically.
 *
 * The idempotency key scopes one attempt. Repeating it with the same command returns the original receipt;
 * repeating it with a different command is rejected. Rejections roll back and leave no rows or capture.
 */
export function executeCommand(store: FinancialStore, context: ServiceContext, command: ServiceCommand, idempotencyKey: string): CommandOutcome {
  const invalid = validateServiceCommand(command);
  if (invalid !== null) return invalid;
  const invalidKey = validateCommandIdempotencyKey(idempotencyKey);
  if (invalidKey !== null) return invalidKey;
  try {
    return store.write(
      { kind: context.principalKind ?? 'human', actorId: context.actorId, reference: context.reference },
      (database) => executeCommandTransaction(database, context, command, idempotencyKey),
    );
  } catch (error) {
    if (error instanceof OutcomeAbort) return error.outcome;
    throw error;
  }
}

/** Validates a command against current data and returns its reviewed terms without any effect. */
export function reviewCommand(store: FinancialStore, context: ServiceContext, command: ServiceCommand): ReviewOutcome {
  const invalid = validateServiceCommand(command);
  if (invalid !== null) return invalid;
  try { return store.read((database) => {
    const env = commandEnvironment(database, context);
    const denied = authorizeQuery(database, context);
    if (denied !== null) return denied;
    const prepared = prepare(env, command);
    if (prepared.kind !== 'prepared') return prepared;
    return { kind: 'reviewable', review: { commandKind: command.kind, institutionId: env.institutionId, institutionName: env.institutionName, ...prepared.review } };
  }); } catch (error) {
    if (error instanceof OutcomeAbort && error.outcome.kind === 'rejected') return error.outcome;
    throw error;
  }
}

/** Runtime command schema; TypeScript declarations alone cannot validate requests. */
export function validateServiceCommand(command: unknown): Rejection | null {
  if (command === null || typeof command !== 'object' || Array.isArray(command)) return reject('validation', 'A command must be an object.');
  const kind: unknown = Reflect.get(command, 'kind');
  if (typeof kind !== 'string') return reject('validation', 'A command kind is required.');
  if (Object.hasOwn(APPROVAL_GRANTS, kind)) return validateApprovalCommand(command);
  if (Object.hasOwn(FINANCE_GRANTS, kind)) return validateFinanceCommand(command);
  if (Object.hasOwn(SERVICING_GRANTS, kind)) return isServicingCommand(command) ? null : reject('validation', `Invalid fields for ${kind}.`);
  return validateCoreCommand(command);
}

function prepare(env: Environment, command: ServiceCommand): Preparation {
  if (Object.hasOwn(APPROVAL_GRANTS, command.kind)) return prepareApproval(env, command as ApprovalCommand);
  if (Object.hasOwn(FINANCE_GRANTS, command.kind)) return prepareFinance(env, command as FinanceCommand);
  if (Object.hasOwn(SERVICING_GRANTS, command.kind)) return prepareServicing(env, command as ServicingCommand);
  switch (command.kind) {
    case 'member.create': return prepareMemberCreate(env, command);
    case 'member.organization.create': return prepareOrganizationCreate(env, command);
    case 'contact.update': return prepareContactUpdate(env, command);
    case 'member.note.add': return prepareMemberNote(env, command);
    case 'account.open': return prepareAccountOpen(env, command);
    case 'account.nickname.update': return prepareAccountField(env, command.accountId, command.expectedVersion, 'nickname', command.nickname);
    case 'account.statement_delivery.update': return prepareAccountField(env, command.accountId, command.expectedVersion, 'statement_delivery', command.statementDelivery);
    case 'account.close': return prepareAccountClose(env, command);
    case 'cash.deposit': return prepareCash(env, command, 'credit');
    case 'cash.withdraw': return prepareCash(env, command, 'debit');
    case 'transfer.internal': return prepareTransfer(env, command);
    case 'case.open': return prepareCaseOpen(env, command);
    case 'case.assign': return prepareCaseAssign(env, command);
    case 'case.transition': return prepareCaseTransition(env, command);
    case 'case.note.add': return prepareCaseNote(env, command);
    case 'edit.cancel': return prepareDraftDiscard(env,command);
    case 'search.saved.create': return prepareSavedSearchCreate(env, command);
    case 'search.saved.update': return prepareSavedSearchUpdate(env, command);
    case 'search.saved.delete': return prepareSavedSearchDelete(env, command);
    default: return reject('validation', 'Unknown command kind.');
  }
}

const noReview = (consequences: string[]): Prepared['review'] => ({ amount: null, exponent: null, description: null, accounts: [], consequences });

function firstProblem(problems: readonly [string, string | null][]): Rejection | null {
  const found = problems.find(([, problem]) => problem !== null);
  return found === undefined ? null : reject('validation', found[1] ?? '', { field: found[0] });
}

function optionalTextProblem(value: string | null, label: string, maximum: number): string | null {
  return value === null ? null : textProblem(value, label, maximum);
}

function addressProblem(address: AddressInput | null, prefix = 'address'): [string, string | null][] {
  if (address === null) return [];
  return [
    [`${prefix}.line1`, textProblem(address.line1, 'Address line 1', LIMITS.addressLineLength)],
    [`${prefix}.line2`, optionalTextProblem(address.line2 === null || cleanText(address.line2) === '' ? null : address.line2, 'Address line 2', LIMITS.addressLineLength)],
    [`${prefix}.city`, textProblem(address.city, 'City', LIMITS.cityLength)],
    [`${prefix}.region`, textProblem(address.region, 'Region', LIMITS.regionLength)],
    [`${prefix}.postalCode`, POSTAL_CODE.test(cleanText(address.postalCode)) ? null : `Postal code must be 3 to ${LIMITS.postalCodeLength} letters, digits, spaces or hyphens.`],
    [`${prefix}.country`, /^[A-Z]{2}$/u.test(cleanText(address.country)) ? null : 'Country must be a two-letter ISO code.'],
  ];
}

function normalizedAddress(address: AddressInput): AddressInput {
  const line2 = address.line2 === null ? null : cleanText(address.line2);
  return { line1: cleanText(address.line1), line2: line2 === '' ? null : line2, city: cleanText(address.city), region: cleanText(address.region), postalCode: cleanText(address.postalCode).toUpperCase(), country: cleanText(address.country) };
}

function staleVersion(label: string, expected: number, current: number): Rejection {
  return reject('stale_version', `This ${label} changed after you opened it (version ${expected} is now ${current}). Review the current values before saving again.`, { currentVersion: current });
}

function member(env: Environment, memberId: string): Row | undefined {
  return one(env.database, `SELECT m.id,m.member_number,m.party_id,m.status,m.version,p.display_name,p.kind FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
    WHERE m.dataset_id=? AND m.id=?`, env.datasetId, memberId);
}

/** Optional text with surrounding blanks removed; blank means absent. */
function optionalClean(value: string | null): string | null {
  return value === null || cleanText(value) === '' ? null : cleanText(value);
}

interface NewContact {
  email: string | null;
  phone: string | null;
  address: AddressInput | null;
}

function newContactProblems(contact: NewContact): [string, string | null][] {
  return [
    ['email', contact.email === null || (EMAIL.test(contact.email) && contact.email.length <= LIMITS.emailLength) ? null : 'Email address is not valid.'],
    ['phone', contact.phone === null || PHONE.test(contact.phone) ? null : 'Phone number must contain 7 to 20 digits and separators.'],
    ...addressProblem(contact.address),
  ];
}

function insertNewContact(env: Environment, partyId: string, contact: NewContact): void {
  if (contact.email !== null) insertContact(env, partyId, 'email', 'primary', contact.email);
  if (contact.phone !== null) insertContact(env, partyId, 'phone', 'mobile', contact.phone);
  if (contact.address !== null) insertAddress(env, partyId, normalizedAddress(contact.address));
}

function prepareMemberCreate(env: Environment, command: Extract<ServiceCommand, { kind: 'member.create' }>): Preparation {
  const contact: NewContact = { email: optionalClean(command.email), phone: optionalClean(command.phone), address: command.address };
  const preferred = optionalClean(command.preferredName);
  const today = localDate(env.now, env.timeZone);
  const invalid = firstProblem([
    ['legalGiven', textProblem(command.legalGiven, 'Legal given name', LIMITS.nameLength)],
    ['legalFamily', textProblem(command.legalFamily, 'Legal family name', LIMITS.nameLength)],
    ['preferredName', optionalTextProblem(preferred, 'Preferred name', LIMITS.nameLength)],
    ['birthDate', !isIsoDate(command.birthDate) ? 'Birth date must be a valid YYYY-MM-DD date.' : command.birthDate > today ? 'Birth date cannot be in the future.' : command.birthDate < '1900-01-01' ? 'Birth date must be on or after 1900-01-01.' : null],
    ...newContactProblems(contact),
  ]);
  if (invalid !== null) return invalid;
  const given = cleanText(command.legalGiven);
  const family = cleanText(command.legalFamily);
  const fold = (value: string): string => value.toLocaleLowerCase('en-US');
  const duplicate = all(env.database, `SELECT m.member_number,pe.legal_given,pe.legal_family FROM people pe JOIN members m ON m.dataset_id=pe.dataset_id AND m.party_id=pe.party_id
      WHERE pe.dataset_id=? AND pe.birth_date=? AND m.status<>'merged'`, env.datasetId, command.birthDate)
    .find((row) => fold(str(row, 'legal_given')) === fold(given) && fold(str(row, 'legal_family')) === fold(family));
  if (duplicate !== undefined) return reject('duplicate_identity', `Member ${str(duplicate, 'member_number')} already has this legal name and birth date.`, { field: 'legalFamily' });
  const partyId = `party-${randomUUID()}`;
  const memberId = `member-${randomUUID()}`;
  const memberNumber = nextNumber(env.database, 'members', 'member_number', env.datasetId, 'NM', 6);
  return {
    kind: 'prepared', businessReference: memberNumber, result: { memberId, memberNumber, partyId },
    review: noReview([`Creates member ${memberNumber} for ${given} ${family}.`]),
    apply(apply) {
      const { database, datasetId, now } = apply;
      run(database, 'INSERT INTO parties (dataset_id,id,kind,display_name,created_at) VALUES (?,?,?,?,?)', datasetId, partyId, 'person', `${given} ${family}`, now);
      run(database, 'INSERT INTO people (dataset_id,party_id,legal_given,legal_family,preferred_name,preferred_name_scope,birth_date,deceased_at) VALUES (?,?,?,?,?,?,?,NULL)', datasetId, partyId, given, family, preferred, preferred === null ? null : 'all', command.birthDate);
      insertMemberIdentity(apply, { partyId, memberId, memberNumber, given, family, taxClassification: 'individual' });
      insertNewContact(apply, partyId, contact);
      apply.event({ kind: 'member', id: memberId }, `Member ${memberNumber} created for ${given} ${family}.`);
    },
  };
}

/** The member row and the opening entries of its legal-name and tax-classification histories. */
function insertMemberIdentity(env: Environment, identity: { partyId: string; memberId: string; memberNumber: string; given: string | null; family: string; taxClassification: string }): void {
  const { database, datasetId, now } = env;
  run(database, 'INSERT INTO members (dataset_id,id,party_id,member_number,status,joined_at,tax_classification,version) VALUES (?,?,?,?,?,?,?,1)', datasetId, identity.memberId, identity.partyId, identity.memberNumber, 'active', now, identity.taxClassification);
  run(database, 'INSERT INTO name_history (dataset_id,id,party_id,kind,given_name,family_name,valid_from,valid_to,evidence_id) VALUES (?,?,?,?,?,?,?,NULL,NULL)', datasetId, `name-history-${randomUUID()}`, identity.partyId, 'legal', identity.given, identity.family, now);
  run(database, 'INSERT INTO tax_status_history (dataset_id,id,member_id,classification,valid_from,valid_to,evidence_id) VALUES (?,?,?,?,?,NULL,NULL)', datasetId, `tax-history-${randomUUID()}`, identity.memberId, identity.taxClassification, now);
}

const REGISTRATION_NUMBER = /^[A-Z0-9][A-Z0-9-]{2,29}$/u;

/** Creates a member for an organization party. A registration number identifies at most one organization per institution. */
function prepareOrganizationCreate(env: Environment, command: Extract<ServiceCommand, { kind: 'member.organization.create' }>): Preparation {
  const contact: NewContact = { email: optionalClean(command.email), phone: optionalClean(command.phone), address: command.address };
  const registrationNumber = cleanText(command.registrationNumber).toUpperCase();
  const types = Object.keys(ORGANIZATION_TAX_CLASSIFICATIONS);
  const invalid = firstProblem([
    ['legalName', textProblem(command.legalName, 'Legal name', LIMITS.organizationNameLength)],
    ['registrationNumber', REGISTRATION_NUMBER.test(registrationNumber) ? null : 'Registration number must be 3 to 30 letters, digits or hyphens.'],
    ['organizationType', types.includes(command.organizationType) ? null : `Organization type must be ${types.join(' or ')}.`],
    ...newContactProblems(contact),
  ]);
  if (invalid !== null) return invalid;
  const duplicate = one(env.database, `SELECT m.member_number FROM organizations o LEFT JOIN members m ON m.dataset_id=o.dataset_id AND m.party_id=o.party_id
    WHERE o.dataset_id=? AND upper(o.registration_number)=?`, env.datasetId, registrationNumber);
  if (duplicate !== undefined) {
    const holder = optionalStr(duplicate, 'member_number');
    return reject('duplicate_identity', `Registration number ${registrationNumber} is already on file${holder === null ? '' : ` for member ${holder}`}.`, { field: 'registrationNumber' });
  }
  const legalName = cleanText(command.legalName);
  const partyId = `party-${randomUUID()}`;
  const memberId = `member-${randomUUID()}`;
  const memberNumber = nextNumber(env.database, 'members', 'member_number', env.datasetId, 'NM', 6);
  const taxClassification = ORGANIZATION_TAX_CLASSIFICATIONS[command.organizationType];
  return {
    kind: 'prepared', businessReference: memberNumber, result: { memberId, memberNumber, partyId },
    review: noReview([`Creates member ${memberNumber} for the ${command.organizationType} ${legalName}, registration ${registrationNumber}.`]),
    apply(apply) {
      const { database, datasetId, now } = apply;
      run(database, 'INSERT INTO parties (dataset_id,id,kind,display_name,created_at) VALUES (?,?,?,?,?)', datasetId, partyId, 'organization', legalName, now);
      run(database, 'INSERT INTO organizations (dataset_id,party_id,legal_name,registration_number,organization_type) VALUES (?,?,?,?,?)', datasetId, partyId, legalName, registrationNumber, command.organizationType);
      insertMemberIdentity(apply, { partyId, memberId, memberNumber, given: null, family: legalName, taxClassification });
      insertNewContact(apply, partyId, contact);
      apply.event({ kind: 'member', id: memberId }, `Member ${memberNumber} created for ${legalName}.`);
    },
  };
}

function insertContact(env: Environment, partyId: string, kind: 'email' | 'phone', purpose: string, value: string): void {
  run(env.database, 'INSERT INTO contact_points (dataset_id,id,party_id,kind,purpose,value,valid_from,valid_to,verified_at) VALUES (?,?,?,?,?,?,?,NULL,NULL)',
    env.datasetId, `contact-${randomUUID()}`, partyId, kind, purpose, value, env.now);
}

function insertAddress(env: Environment, partyId: string, address: AddressInput): void {
  const addressId = `address-${randomUUID()}`;
  run(env.database, 'INSERT INTO addresses (dataset_id,id,line1,line2,city,region,postal_code,country) VALUES (?,?,?,?,?,?,?,?)', env.datasetId, addressId, address.line1, address.line2, address.city, address.region, address.postalCode, address.country);
  run(env.database, 'INSERT INTO party_addresses (dataset_id,id,party_id,address_id,purpose,valid_from,valid_to,evidence_status) VALUES (?,?,?,?,?,?,NULL,?)', env.datasetId, `party-address-${randomUUID()}`, partyId, addressId, 'mailing', env.now, 'unverified');
}

function currentContact(env: Environment, partyId: string, kind: 'email' | 'phone'): Row | undefined {
  return one(env.database, `SELECT id,purpose,value FROM contact_points WHERE dataset_id=? AND party_id=? AND kind=? AND valid_to IS NULL
    ORDER BY CASE purpose WHEN 'primary' THEN 0 WHEN 'mobile' THEN 0 ELSE 1 END,valid_from DESC,id LIMIT 1`, env.datasetId, partyId, kind);
}

function prepareContactUpdate(env: Environment, command: Extract<ServiceCommand, { kind: 'contact.update' }>): Preparation {
  const record = member(env, command.memberId);
  if (record === undefined) return reject('not_found', 'The member does not exist at this institution.');
  const status = str(record, 'status');
  if (status === 'merged' || status === 'deceased') return reject('ineligible', `Member status is ${status}; contact maintenance is unavailable.`);
  if (int(record, 'version') !== command.expectedVersion) return staleVersion('member', command.expectedVersion, int(record, 'version'));
  const email = command.email === undefined ? undefined : command.email === null || cleanText(command.email) === '' ? null : cleanText(command.email);
  const phone = command.phone === undefined ? undefined : command.phone === null || cleanText(command.phone) === '' ? null : cleanText(command.phone);
  const invalid = firstProblem([
    ['email', email === undefined || email === null || (EMAIL.test(email) && email.length <= LIMITS.emailLength) ? null : 'Email address is not valid.'],
    ['phone', phone === undefined || phone === null || PHONE.test(phone) ? null : 'Phone number must contain 7 to 20 digits and separators.'],
    ...addressProblem(command.address ?? null),
  ]);
  if (invalid !== null) return invalid;
  const partyId = str(record, 'party_id');
  const changes: { field: string; apply(env: Environment): void }[] = [];
  for (const [kind, value, purpose] of [['email', email, 'primary'], ['phone', phone, 'mobile']] as const) {
    if (value === undefined) continue;
    const current = currentContact(env, partyId, kind);
    if ((current === undefined && value === null) || (current !== undefined && str(current, 'value') === value)) continue;
    changes.push({ field: kind, apply(apply) {
      if (current !== undefined) run(apply.database, 'UPDATE contact_points SET valid_to=? WHERE dataset_id=? AND id=?', apply.now, apply.datasetId, str(current, 'id'));
      if (value !== null) insertContact(apply, partyId, kind, current === undefined ? purpose : str(current, 'purpose'), value);
    } });
  }
  if (command.address !== undefined) {
    const address = normalizedAddress(command.address);
    const current = one(env.database, `SELECT pa.id,a.line1,a.line2,a.city,a.region,a.postal_code,a.country FROM party_addresses pa JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
      WHERE pa.dataset_id=? AND pa.party_id=? AND pa.purpose='mailing' AND pa.valid_to IS NULL ORDER BY pa.valid_from DESC,pa.id LIMIT 1`, env.datasetId, partyId);
    const same = current !== undefined && str(current, 'line1') === address.line1 && optionalStr(current, 'line2') === address.line2 && str(current, 'city') === address.city
      && str(current, 'region') === address.region && str(current, 'postal_code') === address.postalCode && str(current, 'country') === address.country;
    if (!same) changes.push({ field: 'address', apply(apply) {
      if (current !== undefined) run(apply.database, 'UPDATE party_addresses SET valid_to=? WHERE dataset_id=? AND id=?', apply.now, apply.datasetId, str(current, 'id'));
      insertAddress(apply, partyId, address);
    } });
  }
  if (changes.length === 0) return { kind: 'unchanged', message: 'The contact details already match the stored values.' };
  const memberNumber = str(record, 'member_number');
  const fields = changes.map((change) => change.field);
  return {
    kind: 'prepared', businessReference: memberNumber, result: { memberId: command.memberId, fields, version: command.expectedVersion + 1 },
    review: noReview([`Updates ${fields.join(', ')} for member ${memberNumber}.`]),
    apply(apply) {
      for (const change of changes) change.apply(apply);
      bumpVersion(apply, 'members', command.memberId, command.expectedVersion);
      apply.event({ kind: 'member', id: command.memberId }, `Contact updated for ${memberNumber}: ${fields.join(', ')}.`);
    },
  };
}

function bumpVersion(env: Environment, table: 'members' | 'accounts' | 'cases', id: string, expected: number, assignments = '', ...values: (string | number | null)[]): void {
  const result = env.database.prepare(`UPDATE ${table} SET ${assignments}${assignments === '' ? '' : ','}version=version+1 WHERE dataset_id=? AND id=? AND version=?`).run(...values, env.datasetId, id, expected);
  if (result.changes !== 1) throw new Error(`Concurrent ${table} version change detected inside the transaction.`);
}

function restrictedNoteRefusal(env: Environment, visibility: string): Rejection | null {
  if (visibility !== 'restricted') return null;
  const permissions = actorPermissions(env.database, env.datasetId, env.institutionId, env.actorId, env.now);
  return RESTRICTED_NOTE_GRANTS.some((grant) => permissions.has(grant)) ? null
    : reject('not_authorized', `Restricted notes require the ${RESTRICTED_NOTE_GRANTS.join(' or ')} permission.`, { field: 'visibility' });
}

function prepareMemberNote(env: Environment, command: Extract<ServiceCommand, { kind: 'member.note.add' }>): Preparation {
  const record = member(env, command.memberId);
  if (record === undefined) return reject('not_found', 'The member does not exist at this institution.');
  const invalid = firstProblem([
    ['visibility', (['general', 'restricted'] as readonly string[]).includes(command.visibility) ? null : 'Visibility must be general or restricted.'],
    ['text', textProblem(command.text, 'Note text', LIMITS.noteLength, true)],
  ]);
  if (invalid !== null) return invalid;
  const restricted = restrictedNoteRefusal(env, command.visibility);
  if (restricted !== null) return restricted;
  const noteId = `member-note-${randomUUID()}`;
  const memberNumber = str(record, 'member_number');
  const text = cleanText(command.text);
  return {
    kind: 'prepared', businessReference: memberNumber, result: { noteId, memberId: command.memberId },
    review: noReview([`Adds a ${command.visibility} note to member ${memberNumber}.`]),
    apply(apply) {
      run(apply.database, 'INSERT INTO member_notes (dataset_id,id,member_id,actor_id,visibility,text,created_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, noteId, command.memberId, apply.actorId, command.visibility, text, apply.now);
      apply.event({ kind: 'member-note', id: noteId }, `${command.visibility === 'restricted' ? 'Restricted' : 'General'} note added to ${memberNumber}.`);
      apply.event({ kind: 'member', id: command.memberId }, `Note ${noteId} recorded.`);
    },
  };
}

function prepareAccountOpen(env: Environment, command: Extract<ServiceCommand, { kind: 'account.open' }>): Preparation {
  const record = member(env, command.memberId);
  if (record === undefined) return reject('not_found', 'The member does not exist at this institution.');
  if (str(record, 'status') !== 'active') return reject('ineligible', `Member status is ${str(record, 'status')}; accounts can only be opened for active members.`);
  const product = one(env.database, 'SELECT id,code,name,family,currency,status FROM products WHERE dataset_id=? AND id=?', env.datasetId, command.productId);
  const invalid = firstProblem([
    ['productId', product === undefined ? 'Select a product offered by this institution.'
      : str(product, 'family') !== 'deposit' || str(product, 'status') !== 'active' ? 'Only active deposit products can be opened here.'
        : str(product, 'code').endsWith('-TERM') ? 'Term deposits need a funded maturity instruction, which this operation does not create.' : null],
    ['nickname', textProblem(command.nickname, 'Nickname', LIMITS.nicknameLength)],
    ['statementDelivery', (['paper', 'electronic'] as readonly string[]).includes(command.statementDelivery) ? null : 'Statement delivery must be paper or electronic.'],
  ]);
  if (invalid !== null || product === undefined) return invalid ?? reject('validation', 'Select a product.', { field: 'productId' });
  if (command.statementDelivery === 'electronic' && effectiveConsentState(env, str(record, 'party_id'), null, 'account-statements', 'electronic') !== 'granted') {
    return reject('ineligible', 'Opening an electronic-delivery account requires effective party-wide statement consent.', { field: 'statementDelivery' });
  }
  const open = int(one(env.database, "SELECT COUNT(*) AS count FROM accounts WHERE dataset_id=? AND member_id=? AND status NOT IN ('closed','matured')", env.datasetId, command.memberId), 'count');
  if (open >= LIMITS.maxOpenAccountsPerMember) return reject('account_limit_reached', `Member already has ${open} open accounts; the limit is ${LIMITS.maxOpenAccountsPerMember}.`);
  const accountId = `account-${randomUUID()}`;
  const ledgerId = `ledger-${randomUUID()}`;
  const accountNumber = nextNumber(env.database, 'accounts', 'account_number', env.datasetId, 'AC', 7);
  const currency = str(product, 'currency');
  const ledgerCode = nextNumber(env.database, 'ledger_accounts', 'code', env.datasetId, `${currency}-CUSTOMER-`, 7);
  const nickname = cleanText(command.nickname);
  const memberNumber = str(record, 'member_number');
  return {
    kind: 'prepared', businessReference: accountNumber, result: { accountId, accountNumber, memberId: command.memberId },
    review: noReview([`Opens ${str(product, 'name')} account ${accountNumber} for member ${memberNumber} with a zero balance.`]),
    apply(apply) {
      run(apply.database, 'INSERT INTO accounts (dataset_id,id,member_id,account_number,product_id,currency,status,nickname,statement_delivery,opened_at,closed_at,version) VALUES (?,?,?,?,?,?,?,?,?,?,NULL,1)',
        apply.datasetId, accountId, command.memberId, accountNumber, command.productId, currency, 'open', nickname, command.statementDelivery, apply.now);
      run(apply.database, 'INSERT INTO account_parties (dataset_id,account_id,party_id,role,starts_at,ends_at) VALUES (?,?,?,?,?,NULL)', apply.datasetId, accountId, str(record, 'party_id'), 'owner', apply.now);
      run(apply.database, 'INSERT INTO ledger_accounts (dataset_id,id,code,kind,currency,normal_side,customer_account_id) VALUES (?,?,?,?,?,?,?)',
        apply.datasetId, ledgerId, ledgerCode, 'customer-deposit', currency, 'credit', accountId);
      apply.event({ kind: 'account', id: accountId }, `Account ${accountNumber} (${str(product, 'name')}) opened.`);
      apply.event({ kind: 'member', id: command.memberId }, `Account ${accountNumber} opened for ${memberNumber}.`);
    },
  };
}

function accountView(env: Environment, accountId: string): Row | undefined {
  const row=one(env.database, `SELECT a.id,a.account_number,a.member_id,a.currency,a.status,a.nickname,a.statement_delivery,a.version,m.member_number,p.display_name AS owner_name,
      pr.name AS product_name,c.exponent,b.posted_balance_minor_units,b.available_balance_minor_units
    FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
    JOIN products pr ON pr.dataset_id=a.dataset_id AND pr.id=${accountProductSql(`'${env.now}'`)} JOIN currencies c ON c.code=a.currency
    JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.id=?`, env.datasetId, accountId);
  const facts=accountFacts(env.database,env.datasetId,accountId,env.now);
  return row===undefined || facts===undefined ? undefined : {...row,available_balance_minor_units:facts.availableMinorUnits};
}

function reviewedAccount(view: Row, postedDelta: number, availableDelta: number): ReviewedAccount {
  const posted = int(view, 'posted_balance_minor_units');
  const available = int(view, 'available_balance_minor_units');
  const postedAfter = posted + postedDelta;
  const availableAfter = available + availableDelta;
  if (!Number.isSafeInteger(postedAfter) || !Number.isSafeInteger(availableAfter)) {
    throw new OutcomeAbort(reject('limit_exceeded', 'The resulting account balance exceeds the exact minor-unit capacity. No funds moved.', { field: 'amount' }));
  }
  return {
    id: str(view, 'id'), accountNumber: str(view, 'account_number'), memberId: str(view, 'member_id'), memberNumber: str(view, 'member_number'),
    ownerName: str(view, 'owner_name'), productName: str(view, 'product_name'), currency: str(view, 'currency'), exponent: int(view, 'exponent'),
    status: str(view, 'status'), version: int(view, 'version'), postedBeforeMinorUnits: posted, postedAfterMinorUnits: postedAfter,
    availableBeforeMinorUnits: available, availableAfterMinorUnits: availableAfter,
  };
}

function prepareAccountField(env: Environment, accountId: string, expectedVersion: number, column: 'nickname' | 'statement_delivery', rawValue: string): Preparation {
  const view = accountView(env, accountId);
  if (view === undefined) return reject('not_found', 'The account does not exist at this institution.');
  if (str(view, 'status') === 'closed') return reject('ineligible', 'Closed accounts cannot be maintained.');
  if (int(view, 'version') !== expectedVersion) return staleVersion('account', expectedVersion, int(view, 'version'));
  const value = column === 'nickname' ? cleanText(rawValue) : rawValue;
  const invalid = column === 'nickname'
    ? firstProblem([['nickname', textProblem(rawValue, 'Nickname', LIMITS.nicknameLength)]])
    : firstProblem([['statementDelivery', value === 'paper' || value === 'electronic' ? null : 'Statement delivery must be paper or electronic.']]);
  if (invalid !== null) return invalid;
  const label = column === 'nickname' ? 'nickname' : 'statement delivery';
  if (str(view, column) === value) return { kind: 'unchanged', message: `The account ${label} is already ${value}.` };
  if (column === 'statement_delivery' && value === 'electronic') {
    const owner = member(env, str(view, 'member_id'));
    if (owner === undefined || effectiveConsentState(env, str(owner, 'party_id'), accountId, 'account-statements', 'electronic') !== 'granted') {
      return reject('ineligible', 'Electronic statement delivery requires effective consent for this account.', { field: 'statementDelivery' });
    }
  }
  const accountNumber = str(view, 'account_number');
  return {
    kind: 'prepared', businessReference: accountNumber, result: { accountId, [column]: value, version: expectedVersion + 1 },
    review: { amount: null, exponent: int(view, 'exponent'), description: null, accounts: [reviewedAccount(view, 0, 0)], consequences: [`Changes the ${label} of ${accountNumber} from ${str(view, column)} to ${value}.`] },
    apply(apply) {
      bumpVersion(apply, 'accounts', accountId, expectedVersion, `${column}=?`, value);
      apply.event({ kind: 'account', id: accountId }, `Account ${accountNumber} ${label} changed from "${str(view, column)}" to "${value}".`);
    },
  };
}

function prepareAccountClose(env: Environment, command: Extract<ServiceCommand, { kind: 'account.close' }>): Preparation {
  const view = accountView(env, command.accountId);
  if (view === undefined) return reject('not_found', 'The account does not exist at this institution.');
  if (int(view, 'version') !== command.expectedVersion) return staleVersion('account', command.expectedVersion, int(view, 'version'));
  const facts = accountFacts(env.database, env.datasetId, command.accountId, env.now);
  if (facts === undefined) return reject('not_found', 'The account does not exist at this institution.');
  const eligibility = closureEligibility(facts);
  if (!eligibility.eligible) return reject('closure_blocked', eligibility.reasons.join(' '));
  const invalid = firstProblem([['reason', textProblem(command.reason, 'Closure reason', LIMITS.reasonLength)]]);
  if (invalid !== null) return invalid;
  const accountNumber = str(view, 'account_number');
  const reason = cleanText(command.reason);
  return {
    kind: 'prepared', businessReference: accountNumber, result: { accountId: command.accountId, status: 'closed' },
    review: { amount: null, exponent: int(view, 'exponent'), description: reason, accounts: [reviewedAccount(view, 0, 0)], consequences: [`Account ${accountNumber} becomes closed.`, 'No funds move; the posted balance is already zero.'] },
    apply(apply) {
      bumpVersion(apply, 'accounts', command.accountId, command.expectedVersion, "status='closed',closed_at=?", apply.now);
      apply.event({ kind: 'account', id: command.accountId }, `Account ${accountNumber} closed. Reason: ${reason}`);
    },
  };
}

function moneyProblem(env: Environment, amount: Money, currency: string): Rejection | null {
  if (!Number.isSafeInteger(amount.minorUnits) || amount.minorUnits <= 0) return reject('validation', 'Amount must be a positive exact amount in minor units.', { field: 'amount' });
  if (amount.currency !== currency) return reject('currency_mismatch', `The account holds ${currency}; the requested amount is in ${amount.currency}. No currency conversion is performed.`, { field: 'amount' });
  const policy = one(env.database, 'SELECT rules_json FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC LIMIT 1', env.datasetId, env.now);
  let limit = HARD_AMOUNT_CEILING;
  if (policy !== undefined) {
    const rules: unknown = JSON.parse(str(policy, 'rules_json'));
    const configured = rules !== null && typeof rules === 'object' && 'transferLimitMinorUnits' in rules ? rules.transferLimitMinorUnits : undefined;
    if (typeof configured === 'number' && Number.isSafeInteger(configured)) limit = configured;
  }
  if (amount.minorUnits > limit) return reject('limit_exceeded', `Amount exceeds the policy limit of ${limit} minor units per operation.`, { field: 'amount' });
  return null;
}

function customerLedger(env: Environment, accountId: string): string {
  return str(one(env.database, 'SELECT id FROM ledger_accounts WHERE dataset_id=? AND customer_account_id=?', env.datasetId, accountId), 'id');
}

function insertJournal(env: ApplyEnvironment, input: { id: string; reference: string; description: string; lines: { ledgerId: string; debit: number; credit: number }[]; currency: string }): void {
  const invalid = requireSafeLedgerPosting(env.database, env.datasetId, input.lines.map(line => ({ ledgerAccountId: line.ledgerId, currency: input.currency, debitMinorUnits: line.debit, creditMinorUnits: line.credit })));
  if (invalid !== null) throw new OutcomeAbort(invalid);
  run(env.database, 'INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,?,?,?,?,?,?,NULL)',
    env.datasetId, input.id, input.reference, env.operationId, 'posted', env.now, localDate(env.now, env.timeZone), input.description);
  for (const [index, line] of input.lines.entries()) {
    run(env.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,?,?)',
      env.datasetId, input.id, index + 1, line.ledgerId, input.currency, line.debit, line.credit, input.description);
  }
}

function prepareCash(env: Environment, command: Extract<ServiceCommand, { kind: 'cash.deposit' | 'cash.withdraw' }>, direction: 'credit' | 'debit'): Preparation {
  const view = accountView(env, command.accountId);
  if (view === undefined) return reject('not_found', 'The account does not exist at this institution.');
  if (int(view, 'version') !== command.expectedVersion) return staleVersion('account', command.expectedVersion, int(view, 'version'));
  const facts = accountFacts(env.database, env.datasetId, command.accountId, env.now);
  if (facts === undefined) return reject('not_found', 'The account does not exist at this institution.');
  const eligibility = direction === 'credit' ? creditEligibility(facts) : debitEligibility(facts);
  if (!eligibility.eligible) return reject('ineligible', eligibility.reasons.join(' '));
  const invalidAmount = moneyProblem(env, command.amount, facts.currency);
  if (invalidAmount !== null) return invalidAmount;
  const invalid = firstProblem([['description', textProblem(command.description, 'Description', LIMITS.descriptionLength)]]);
  if (invalid !== null) return invalid;
  const amount = command.amount.minorUnits;
  if (direction === 'debit' && facts.availableMinorUnits < amount) return reject('insufficient_funds', 'The withdrawal exceeds the available balance.', { field: 'amount' });
  const cash = one(env.database, "SELECT id FROM ledger_accounts WHERE dataset_id=? AND kind='cash' AND currency=? AND customer_account_id IS NULL ORDER BY code LIMIT 1", env.datasetId, facts.currency);
  if (cash === undefined) return reject('ineligible', `This institution has no ${facts.currency} cash ledger.`);
  const customer = customerLedger(env, command.accountId);
  const cashLedger = str(cash, 'id');
  const lines = direction === 'credit'
    ? [{ ledgerId: cashLedger, debit: amount, credit: 0 }, { ledgerId: customer, debit: 0, credit: amount }]
    : [{ ledgerId: customer, debit: amount, credit: 0 }, { ledgerId: cashLedger, debit: 0, credit: amount }];
  const unsafe = requireSafeLedgerPosting(env.database, env.datasetId, lines.map(line => ({ ledgerAccountId: line.ledgerId, currency: facts.currency, debitMinorUnits: line.debit, creditMinorUnits: line.credit })));
  if (unsafe !== null) return unsafe;
  const journalId = `journal-${randomUUID()}`;
  const reference = nextNumber(env.database, 'journals', 'reference', env.datasetId, 'TX', 10);
  const description = cleanText(command.description);
  const accountNumber = str(view, 'account_number');
  const delta = direction === 'credit' ? amount : -amount;
  const verb = direction === 'credit' ? 'Cash deposit' : 'Cash withdrawal';
  return {
    kind: 'prepared', businessReference: reference, result: { journalId, reference, accountId: command.accountId, amount: command.amount },
    review: { amount: command.amount, exponent: int(view, 'exponent'), description, accounts: [reviewedAccount(view, delta, delta)],
      consequences: [`${verb} posts one balanced journal between the ${facts.currency} cash ledger and ${accountNumber}.`] },
    apply(apply) {
      insertJournal(apply, { id: journalId, reference, description, currency: facts.currency, lines });
      run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
      apply.event({ kind: 'journal', id: journalId }, `${verb} ${reference} of ${amount} ${facts.currency} minor units on ${accountNumber}.`);
      apply.event({ kind: 'account', id: command.accountId }, `${verb} ${reference} posted.`);
    },
  };
}

function prepareTransfer(env: Environment, command: Extract<ServiceCommand, { kind: 'transfer.internal' }>): Preparation {
  if (command.sourceAccountId === command.destinationAccountId) return reject('same_account', 'Source and destination must be different accounts.', { field: 'destinationAccountId' });
  const source = accountView(env, command.sourceAccountId);
  const destination = accountView(env, command.destinationAccountId);
  if (source === undefined) return reject('not_found', 'The source account does not exist at this institution.', { field: 'sourceAccountId' });
  if (destination === undefined) return reject('not_found', 'The destination account does not exist at this institution.', { field: 'destinationAccountId' });
  if (int(source, 'version') !== command.expectedSourceVersion) return staleVersion('source account', command.expectedSourceVersion, int(source, 'version'));
  if (int(destination, 'version') !== command.expectedDestinationVersion) return staleVersion('destination account', command.expectedDestinationVersion, int(destination, 'version'));
  if (str(source, 'member_id') !== str(destination, 'member_id')) return reject('ownership_mismatch', 'Internal transfers move funds only between accounts owned by the same member.', { field: 'destinationAccountId' });
  if (str(source, 'currency') !== str(destination, 'currency')) return reject('currency_mismatch', 'Both accounts must hold the same currency; no conversion is performed.', { field: 'destinationAccountId' });
  const sourceFacts = accountFacts(env.database, env.datasetId, command.sourceAccountId, env.now);
  const destinationFacts = accountFacts(env.database, env.datasetId, command.destinationAccountId, env.now);
  if (sourceFacts === undefined || destinationFacts === undefined) return reject('not_found', 'An account does not exist at this institution.');
  const debit = debitEligibility(sourceFacts);
  if (!debit.eligible) return reject('ineligible', `Source: ${debit.reasons.join(' ')}`, { field: 'sourceAccountId' });
  const credit = creditEligibility(destinationFacts);
  if (!credit.eligible) return reject('ineligible', `Destination: ${credit.reasons.join(' ')}`, { field: 'destinationAccountId' });
  const invalidAmount = moneyProblem(env, command.amount, sourceFacts.currency);
  if (invalidAmount !== null) return invalidAmount;
  const invalid = firstProblem([['description', textProblem(command.description, 'Description', LIMITS.descriptionLength)]]);
  if (invalid !== null) return invalid;
  const amount = command.amount.minorUnits;
  if (sourceFacts.availableMinorUnits < amount) return reject('insufficient_funds', 'The transfer exceeds the source account available balance.', { field: 'amount' });
  const journalId = `journal-${randomUUID()}`;
  const reference = nextNumber(env.database, 'journals', 'reference', env.datasetId, 'TX', 10);
  const description = cleanText(command.description);
  const from = str(source, 'account_number');
  const to = str(destination, 'account_number');
  return {
    kind: 'prepared', businessReference: reference, result: { journalId, reference, sourceAccountId: command.sourceAccountId, destinationAccountId: command.destinationAccountId, amount: command.amount },
    review: { amount: command.amount, exponent: int(source, 'exponent'), description, accounts: [reviewedAccount(source, -amount, -amount), reviewedAccount(destination, amount, amount)],
      consequences: [`Moves funds from ${from} to ${to} in one balanced journal.`] },
    apply(apply) {
      insertJournal(apply, { id: journalId, reference, description, currency: sourceFacts.currency, lines: [
        { ledgerId: customerLedger(apply, command.sourceAccountId), debit: amount, credit: 0 },
        { ledgerId: customerLedger(apply, command.destinationAccountId), debit: 0, credit: amount },
      ] });
      run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id IN (?,?)', apply.datasetId, command.sourceAccountId, command.destinationAccountId);
      apply.event({ kind: 'journal', id: journalId }, `Internal transfer ${reference} of ${amount} ${sourceFacts.currency} minor units from ${from} to ${to}.`);
      apply.event({ kind: 'account', id: command.sourceAccountId }, `Transfer ${reference} debited ${from}.`);
      apply.event({ kind: 'account', id: command.destinationAccountId }, `Transfer ${reference} credited ${to}.`);
    },
  };
}

function caseAssigneeProblem(env: Environment, actorId: string | null): string | null {
  if (actorId === null) return null;
  const actor = one(env.database, 'SELECT status FROM actors WHERE dataset_id=? AND id=?', env.datasetId, actorId);
  if (actor === undefined) return 'The assignee is not an operator at this institution.';
  if (str(actor, 'status') !== 'active') return 'The assignee is disabled.';
  const permissions = actorPermissions(env.database, env.datasetId, env.institutionId, actorId, env.now);
  return permissions.has('case.manage') || permissions.has('supervise') ? null : 'The assignee is not authorized to work servicing cases.';
}

const CASE_STATES = new Set<CaseState>(['open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened']);

function caseRow(env: Environment, caseId: string): Row | undefined {
  return one(env.database, 'SELECT id,case_number,member_id,account_id,queue_id,assigned_actor_id,state,category,version FROM cases WHERE dataset_id=? AND id=?', env.datasetId, caseId);
}

function appendCaseEvent(env: ApplyEnvironment, caseId: string, state: string, detail: string): void {
  const sequence = (optionalInt(one(env.database, 'SELECT MAX(sequence) AS maximum FROM case_events WHERE dataset_id=? AND case_id=?', env.datasetId, caseId), 'maximum') ?? 0) + 1;
  run(env.database, 'INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?,?,?,?,?)', env.datasetId, `case-event-${randomUUID()}`, caseId, sequence, state, env.now, env.actorId, detail);
}

function prepareCaseOpen(env: Environment, command: Extract<ServiceCommand, { kind: 'case.open' }>): Preparation {
  const record = member(env, command.memberId);
  if (record === undefined) return reject('not_found', 'The member does not exist at this institution.');
  if (str(record, 'status') === 'merged') return reject('ineligible', 'Merged members cannot receive new cases; use the surviving member.');
  const account = command.accountId === null ? undefined : one(env.database, 'SELECT id,account_number,member_id FROM accounts WHERE dataset_id=? AND id=?', env.datasetId, command.accountId);
  const queue = one(env.database, 'SELECT id,code FROM queues WHERE dataset_id=? AND id=?', env.datasetId, command.queueId);
  const today = localDate(env.now, env.timeZone);
  const invalid = firstProblem([
    ['accountId', command.accountId !== null && (account === undefined || str(account, 'member_id') !== command.memberId) ? 'The linked account must belong to the case member.' : null],
    ['queueId', queue === undefined ? 'Select a servicing queue.' : null],
    ['assignedActorId', caseAssigneeProblem(env, command.assignedActorId)],
    ['category', command.category in CASE_CATEGORIES ? null : 'Select a case category.'],
    ['priority', ['low', 'normal', 'high', 'urgent'].includes(command.priority) ? null : 'Select a priority.'],
    ['summary', textProblem(command.summary, 'Summary', LIMITS.summaryLength)],
    ['dueDate', !isIsoDate(command.dueDate) ? 'Due date must be a valid YYYY-MM-DD date.' : command.dueDate < today ? `Due date cannot be before the business date ${today}.` : null],
  ]);
  if (invalid !== null || queue === undefined) return invalid ?? reject('validation', 'Select a servicing queue.', { field: 'queueId' });
  const duplicate = one(env.database, "SELECT case_number FROM cases WHERE dataset_id=? AND member_id=? AND category=? AND account_id IS ? AND state NOT IN ('resolved','closed')",
    env.datasetId, command.memberId, command.category, command.accountId);
  if (duplicate !== undefined) return reject('duplicate_open_case', `Case ${str(duplicate, 'case_number')} is already open for this member, category and account.`);
  const caseId = `case-${randomUUID()}`;
  const caseNumber = nextNumber(env.database, 'cases', 'case_number', env.datasetId, 'CS', 6);
  const summary = cleanText(command.summary);
  const dueAt = zonedInstant(command.dueDate, '17:00', env.timeZone);
  return {
    kind: 'prepared', businessReference: caseNumber, result: { caseId, caseNumber },
    review: noReview([`Opens case ${caseNumber} for member ${str(record, 'member_number')} in queue ${str(queue, 'code')}.`]),
    apply(apply) {
      run(apply.database, 'INSERT INTO cases (dataset_id,id,case_number,member_id,account_id,queue_id,assigned_actor_id,state,priority,category,summary,opened_at,due_at,version) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,1)',
        apply.datasetId, caseId, caseNumber, command.memberId, command.accountId, command.queueId, command.assignedActorId, 'open', command.priority, command.category, summary, apply.now, dueAt);
      appendCaseEvent(apply, caseId, 'open', `Case opened: ${summary}`);
      run(apply.database, 'INSERT INTO sla_intervals (dataset_id,id,case_id,state,starts_at,ends_at,reason) VALUES (?,?,?,?,?,NULL,NULL)', apply.datasetId, `sla-interval-${randomUUID()}`, caseId, 'running', apply.now);
      apply.event({ kind: 'case', id: caseId }, `Case ${caseNumber} opened: ${summary}`);
      apply.event({ kind: 'member', id: command.memberId }, `Case ${caseNumber} opened for ${str(record, 'member_number')}.`);
    },
  };
}

function actorName(env: Environment, actorId: string | null): string {
  if (actorId === null) return 'unassigned';
  return optionalStr(one(env.database, 'SELECT display_name FROM actors WHERE dataset_id=? AND id=?', env.datasetId, actorId), 'display_name') ?? actorId;
}

function prepareCaseAssign(env: Environment, command: Extract<ServiceCommand, { kind: 'case.assign' }>): Preparation {
  const record = caseRow(env, command.caseId);
  if (record === undefined) return reject('not_found', 'The case does not exist at this institution.');
  if (int(record, 'version') !== command.expectedVersion) return staleVersion('case', command.expectedVersion, int(record, 'version'));
  if (str(record, 'state') === 'closed') return reject('ineligible', 'Closed cases must be reopened before reassignment.');
  const queue = one(env.database, 'SELECT id,code,visibility FROM queues WHERE dataset_id=? AND id=?', env.datasetId, command.queueId);
  const invalid = firstProblem([
    ['queueId', queue === undefined ? 'Select a servicing queue.' : null],
    ['assignedActorId', caseAssigneeProblem(env, command.assignedActorId)],
    ['reason', textProblem(command.reason, 'Assignment reason', LIMITS.reasonLength)],
  ]);
  if (invalid !== null || queue === undefined) return invalid ?? reject('validation', 'Select a servicing queue.', { field: 'queueId' });
  const current = one(env.database, 'SELECT code,visibility FROM queues WHERE dataset_id=? AND id=?', env.datasetId, str(record, 'queue_id'));
  if (current !== undefined && routeWidensExposure(str(current, 'visibility'), str(queue, 'visibility'))) {
    const permissions = actorPermissions(env.database, env.datasetId, env.institutionId, env.actorId, env.now);
    if (!QUEUE_WIDENING_GRANTS.some((grant) => permissions.has(grant))) {
      return reject('not_authorized', `Moving a case from ${str(current, 'code')} (${str(current, 'visibility')}) to ${str(queue, 'code')} (${str(queue, 'visibility')}) widens who works it and requires the ${QUEUE_WIDENING_GRANTS.join(' or ')} permission.`, { field: 'queueId' });
    }
  }
  if (str(record, 'queue_id') === command.queueId && optionalStr(record, 'assigned_actor_id') === command.assignedActorId) return { kind: 'unchanged', message: 'The case already has this queue and assignee.' };
  const caseNumber = str(record, 'case_number');
  const detail = `Assigned to ${actorName(env, command.assignedActorId)} in queue ${str(queue, 'code')}: ${cleanText(command.reason)}`;
  return {
    kind: 'prepared', businessReference: caseNumber, result: { caseId: command.caseId, queueId: command.queueId, assignedActorId: command.assignedActorId },
    review: noReview([detail]),
    apply(apply) {
      bumpVersion(apply, 'cases', command.caseId, command.expectedVersion, 'queue_id=?,assigned_actor_id=?', command.queueId, command.assignedActorId);
      appendCaseEvent(apply, command.caseId, str(record, 'state'), detail);
      apply.event({ kind: 'case', id: command.caseId }, `Case ${caseNumber} ${detail.charAt(0).toLowerCase()}${detail.slice(1)}`);
    },
  };
}

function prepareCaseTransition(env: Environment, command: Extract<ServiceCommand, { kind: 'case.transition' }>): Preparation {
  const record = caseRow(env, command.caseId);
  if (record === undefined) return reject('not_found', 'The case does not exist at this institution.');
  if (int(record, 'version') !== command.expectedVersion) return staleVersion('case', command.expectedVersion, int(record, 'version'));
  const from = str(record, 'state') as CaseState;
  if (!CASE_STATES.has(command.toState)) return reject('validation', 'Select a case status.', { field: 'toState' });
  if (from === command.toState) return { kind: 'unchanged', message: `The case is already ${from}.` };
  if (!caseTransitionAllowed(from, command.toState)) return reject('invalid_transition', `A ${from} case cannot move to ${command.toState}.`, { field: 'toState' });
  const invalid = firstProblem([['reason', textProblem(command.reason, 'Reason', LIMITS.reasonLength, true)]]);
  if (invalid !== null) return invalid;
  if (command.toState === 'closed') {
    const open = int(one(env.database, "SELECT COUNT(*) AS count FROM case_dependencies WHERE dataset_id=? AND case_id=? AND state='open'", env.datasetId, command.caseId), 'count');
    if (open > 0) return reject('open_dependencies', `${open} case dependenc${open === 1 ? 'y is' : 'ies are'} still open; satisfy or waive them before closing.`);
  }
  const caseNumber = str(record, 'case_number');
  const reason = cleanText(command.reason);
  return {
    kind: 'prepared', businessReference: caseNumber, result: { caseId: command.caseId, from, to: command.toState },
    review: noReview([`Moves case ${caseNumber} from ${from} to ${command.toState}.`]),
    apply(apply) {
      bumpVersion(apply, 'cases', command.caseId, command.expectedVersion, 'state=?', command.toState);
      appendCaseEvent(apply, command.caseId, command.toState, `${from} → ${command.toState}: ${reason}`);
      const ending = command.toState === 'resolved' || command.toState === 'closed';
      run(apply.database, `UPDATE sla_intervals SET ends_at=?${ending ? ",state='completed'" : ''} WHERE dataset_id=? AND case_id=? AND ends_at IS NULL`, apply.now, apply.datasetId, command.caseId);
      if (!ending) {
        run(apply.database, 'INSERT INTO sla_intervals (dataset_id,id,case_id,state,starts_at,ends_at,reason) VALUES (?,?,?,?,?,NULL,?)', apply.datasetId, `sla-interval-${randomUUID()}`, command.caseId,
          command.toState === 'pending-customer' ? 'paused' : 'running', apply.now, command.toState === 'pending-customer' ? 'Awaiting customer response.' : null);
      }
      apply.event({ kind: 'case', id: command.caseId }, `Case ${caseNumber} moved from ${from} to ${command.toState}: ${reason}`);
    },
  };
}

function prepareCaseNote(env: Environment, command: Extract<ServiceCommand, { kind: 'case.note.add' }>): Preparation {
  const record = caseRow(env, command.caseId);
  if (record === undefined) return reject('not_found', 'The case does not exist at this institution.');
  const invalid = firstProblem([
    ['visibility', (['general', 'restricted'] as readonly string[]).includes(command.visibility) ? null : 'Visibility must be general or restricted.'],
    ['text', textProblem(command.text, 'Note text', LIMITS.noteLength, true)],
  ]);
  if (invalid !== null) return invalid;
  const restricted = restrictedNoteRefusal(env, command.visibility);
  if (restricted !== null) return restricted;
  const evidenceVersionIds = command.evidenceVersionIds ?? [];
  for (const versionId of evidenceVersionIds) {
    const evidence = one(env.database, `SELECT d.owner_party_id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id WHERE v.dataset_id=? AND v.id=? AND m.id=?`,env.datasetId,versionId,str(record,'member_id'));
    if (evidence === undefined) return reject('ownership_mismatch','Case note evidence must belong to the case member.');
    const restrictedLink = one(env.database, "SELECT case_id FROM case_documents WHERE dataset_id=? AND document_version_id=? AND visibility='restricted'",env.datasetId,versionId);
    if (restrictedLink !== undefined && command.visibility !== 'restricted') return reject('not_authorized','Restricted evidence requires a restricted note.');
  }
  const noteId = `case-note-${randomUUID()}`;
  const caseNumber = str(record, 'case_number');
  const text = cleanText(command.text);
  return {
    kind: 'prepared', businessReference: caseNumber, result: { noteId, caseId: command.caseId },
    review: noReview([`Appends a ${command.visibility} note to case ${caseNumber}.`]),
    apply(apply) {
      run(apply.database, 'INSERT INTO case_notes (dataset_id,id,case_id,actor_id,visibility,text,created_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, noteId, command.caseId, apply.actorId, command.visibility, text, apply.now);
      for (const versionId of evidenceVersionIds) run(apply.database,'INSERT INTO case_note_documents(dataset_id,note_id,document_version_id) VALUES (?,?,?)',apply.datasetId,noteId,versionId);
      apply.event({ kind: 'case-note', id: noteId }, `${command.visibility === 'restricted' ? 'Restricted' : 'General'} note added to case ${caseNumber}.`);
      apply.event({ kind: 'case', id: command.caseId }, `Note ${noteId} appended.`);
    },
  };
}

const PRIORITIES: readonly string[] = ['low', 'normal', 'high', 'urgent'];
const SEARCH_VISIBILITIES: readonly string[] = ['private', 'shared'];

function sharesSearches(env: Environment): boolean {
  const permissions = actorPermissions(env.database, env.datasetId, env.institutionId, env.actorId, env.now);
  return SHARED_SEARCH_GRANTS.some((grant) => permissions.has(grant));
}

/** Filters that name records must name records of this institution, so a saved meaning cannot silently match nothing. */
function definitionReferenceProblem(env: Environment, definition: SavedSearchDefinition): Rejection | null {
  const value = (key: string): string | boolean | string[] | undefined => definition.filters[key];
  const fail = (key: string, message: string): Rejection => reject('validation', message, { field: `definition.filters.${key}` });
  if (definition.entity === 'cases') {
    const states = value('states');
    const badState = Array.isArray(states) ? states.find((state) => !CASE_STATES.has(state as CaseState)) : undefined;
    if (badState !== undefined) return fail('states', `Case status ${badState} does not exist.`);
    const queues = value('queueIds');
    for (const queueId of Array.isArray(queues) ? queues : []) {
      if (one(env.database, 'SELECT 1 AS found FROM queues WHERE dataset_id=? AND id=?', env.datasetId, queueId) === undefined) return fail('queueIds', `Queue ${queueId} is not a servicing queue at ${env.institutionName}.`);
    }
    const priority = value('priority');
    if (typeof priority === 'string' && !PRIORITIES.includes(priority)) return fail('priority', `Priority ${priority} does not exist.`);
    const assignee = value('assignedActorId');
    if (typeof assignee === 'string' && assignee !== 'unassigned' && one(env.database, 'SELECT 1 AS found FROM actors WHERE dataset_id=? AND id=?', env.datasetId, assignee) === undefined) {
      return fail('assignedActorId', 'The assignee filter names an operator who does not exist here.');
    }
  }
  if (definition.entity === 'accounts') {
    const currency = value('currency');
    if (typeof currency === 'string' && one(env.database, 'SELECT 1 AS found FROM currencies WHERE code=?', currency) === undefined) return fail('currency', `Currency ${currency} is not supported.`);
  }
  return null;
}

function storedSearchEntity(definitionJson: string): string | null {
  try {
    const parsed: unknown = JSON.parse(definitionJson);
    return parsed !== null && typeof parsed === 'object' && 'entity' in parsed && typeof parsed.entity === 'string' ? parsed.entity : null;
  } catch {
    return null;
  }
}

function duplicateSearchName(env: Environment, name: string, entity: string, excludeId: string | null): Rejection | null {
  const fold = name.toLocaleLowerCase('en-US');
  const clash = all(env.database, 'SELECT id,name,definition_json FROM saved_searches WHERE dataset_id=? AND actor_id=?', env.datasetId, env.actorId)
    .find((row) => str(row, 'id') !== excludeId && str(row, 'name').toLocaleLowerCase('en-US') === fold && storedSearchEntity(str(row, 'definition_json')) === entity);
  return clash === undefined ? null : reject('validation', `You already have a ${entity} search named "${str(clash, 'name')}".`, { field: 'name' });
}

function validSavedDefinition(env: Environment, definition: unknown): { ok: true; definition: SavedSearchDefinition } | { ok: false; rejection: Rejection } {
  const parsed = parseSavedSearchDefinition(definition);
  if (!parsed.ok) return { ok: false, rejection: reject('validation', parsed.message, { field: parsed.field }) };
  const referenced = definitionReferenceProblem(env, parsed.definition);
  return referenced === null ? parsed : { ok: false, rejection: referenced };
}

function prepareSavedSearchCreate(env: Environment, command: Extract<ServiceCommand, { kind: 'search.saved.create' }>): Preparation {
  const invalid = firstProblem([
    ['name', textProblem(command.name, 'Name', LIMITS.savedSearchNameLength)],
    ['visibility', SEARCH_VISIBILITIES.includes(command.visibility) ? null : 'Visibility must be private or shared.'],
  ]);
  if (invalid !== null) return invalid;
  const valid = validSavedDefinition(env, command.definition);
  if (!valid.ok) return valid.rejection;
  if (command.visibility === 'shared' && !sharesSearches(env)) return reject('not_authorized', 'Sharing a saved search requires the case.manage or supervise permission.', { field: 'visibility' });
  const name = cleanText(command.name);
  const duplicate = duplicateSearchName(env, name, valid.definition.entity, null);
  if (duplicate !== null) return duplicate;
  const owned = countSavedSearches(env.database, env.datasetId, env.actorId);
  if (owned >= LIMITS.savedSearchesPerActor) return reject('limit_exceeded', `You already have ${owned} saved searches; the limit is ${LIMITS.savedSearchesPerActor}.`);
  const searchId = `saved-search-${randomUUID()}`;
  const definitionJson = JSON.stringify(valid.definition);
  return {
    kind: 'prepared', businessReference: searchId, result: { searchId, name, visibility: command.visibility, definitionJson },
    review: noReview([`Saves the ${command.visibility} ${valid.definition.entity} search "${name}".`]),
    apply(apply) {
      run(apply.database, 'INSERT INTO saved_searches (dataset_id,id,actor_id,name,visibility,definition_json,created_at) VALUES (?,?,?,?,?,?,?)',
        apply.datasetId, searchId, apply.actorId, name, command.visibility, definitionJson, apply.now);
      apply.event({ kind: 'saved-search', id: searchId }, `Saved search "${name}" created (${command.visibility}, ${valid.definition.entity}).`);
    },
  };
}

/** Loads a search the operator may change: others' private searches are invisible and others' shared searches are read-only. */
function searchForChange(env: Environment, searchId: string, expectedRevision: string): { ok: true; row: Row } | { ok: false; rejection: Rejection } {
  const row = one(env.database, `SELECT s.id,s.actor_id,s.name,s.visibility,s.definition_json,a.actor_number FROM saved_searches s JOIN actors a ON a.dataset_id=s.dataset_id AND a.id=s.actor_id
    WHERE s.dataset_id=? AND s.id=?`, env.datasetId, searchId);
  if (row === undefined || (str(row, 'actor_id') !== env.actorId && str(row, 'visibility') !== 'shared')) {
    return { ok: false, rejection: reject('not_found', 'The saved search does not exist or is private to another operator.') };
  }
  if (str(row, 'actor_id') !== env.actorId) return { ok: false, rejection: reject('not_authorized', `Only its owner ${str(row, 'actor_number')} can change this saved search.`) };
  if (savedSearchRevision({ name: str(row, 'name'), visibility: str(row, 'visibility'), definitionJson: str(row, 'definition_json') }) !== expectedRevision) {
    return { ok: false, rejection: reject('stale_version', 'This saved search changed after you opened it. Reopen it to see the current version before saving again.') };
  }
  return { ok: true, row };
}

function prepareSavedSearchUpdate(env: Environment, command: Extract<ServiceCommand, { kind: 'search.saved.update' }>): Preparation {
  const loaded = searchForChange(env, command.searchId, command.expectedRevision);
  if (!loaded.ok) return loaded.rejection;
  const { row } = loaded;
  if (command.name === undefined && command.visibility === undefined && command.definition === undefined) return reject('validation', 'Change the name, visibility or definition.');
  const invalid = firstProblem([
    ['name', command.name === undefined ? null : textProblem(command.name, 'Name', LIMITS.savedSearchNameLength)],
    ['visibility', command.visibility === undefined || SEARCH_VISIBILITIES.includes(command.visibility) ? null : 'Visibility must be private or shared.'],
  ]);
  if (invalid !== null) return invalid;
  const currentEntity = storedSearchEntity(str(row, 'definition_json'));
  let definitionJson = str(row, 'definition_json');
  if (command.definition !== undefined) {
    const valid = validSavedDefinition(env, command.definition);
    if (!valid.ok) return valid.rejection;
    if (valid.definition.entity !== currentEntity) return reject('validation', 'A saved search cannot change which records it lists; save a new search instead.', { field: 'definition.entity' });
    definitionJson = JSON.stringify(valid.definition);
  }
  const name = command.name === undefined ? str(row, 'name') : cleanText(command.name);
  const visibility = command.visibility ?? str(row, 'visibility');
  const fields = [
    name !== str(row, 'name') ? 'name' : null,
    visibility !== str(row, 'visibility') ? 'visibility' : null,
    definitionJson !== str(row, 'definition_json') ? 'definition' : null,
  ].filter((field): field is string => field !== null);
  if (fields.length === 0) return { kind: 'unchanged', message: 'The saved search already has these values.' };
  if (visibility === 'shared' && str(row, 'visibility') !== 'shared' && !sharesSearches(env)) {
    return reject('not_authorized', 'Sharing a saved search requires the case.manage or supervise permission.', { field: 'visibility' });
  }
  if (fields.includes('name')) {
    const duplicate = duplicateSearchName(env, name, currentEntity ?? '', command.searchId);
    if (duplicate !== null) return duplicate;
  }
  return {
    kind: 'prepared', businessReference: command.searchId, result: { searchId: command.searchId, name, visibility, definitionJson },
    review: noReview([`Updates the ${fields.join(', ')} of saved search "${name}".`]),
    apply(apply) {
      const result = apply.database.prepare('UPDATE saved_searches SET name=?,visibility=?,definition_json=? WHERE dataset_id=? AND id=?').run(name, visibility, definitionJson, apply.datasetId, command.searchId);
      if (result.changes !== 1) throw new Error('Saved search disappeared inside the transaction.');
      apply.event({ kind: 'saved-search', id: command.searchId }, `Saved search "${name}" updated: ${fields.join(', ')}.`);
    },
  };
}

function prepareSavedSearchDelete(env: Environment, command: Extract<ServiceCommand, { kind: 'search.saved.delete' }>): Preparation {
  const loaded = searchForChange(env, command.searchId, command.expectedRevision);
  if (!loaded.ok) return loaded.rejection;
  const name = str(loaded.row, 'name');
  return {
    kind: 'prepared', businessReference: command.searchId, result: { searchId: command.searchId, deleted: true },
    review: noReview([`Deletes saved search "${name}".`]),
    apply(apply) {
      run(apply.database, 'DELETE FROM saved_searches WHERE dataset_id=? AND id=?', apply.datasetId, command.searchId);
      apply.event({ kind: 'saved-search', id: command.searchId }, `Saved search "${name}" deleted.`);
    },
  };
}

export type { CommandKind };

function prepareDraftDiscard(env: Environment, command: Extract<ServiceCommand,{kind:'edit.cancel'}>): Preparation {
  const request=one(env.database,'SELECT request_number,state,updated_at,applied_receipt_id FROM maintenance_requests WHERE dataset_id=? AND id=?',env.datasetId,command.requestId);
  if(request===undefined) return reject('not_found','The saved draft does not exist.');
  if(str(request,'state')==='withdrawn') return {kind:'unchanged',message:'The draft was already discarded.'};
  if(str(request,'state')!=='draft' || optionalStr(request,'applied_receipt_id')!==null) return reject('ineligible','Only an unapplied draft can be discarded.');
  if(str(request,'updated_at')!==command.expectedUpdatedAt) return reject('stale_version','The draft changed after it was reviewed.');
  const updatedAt=new Date(Math.max(Date.parse(env.now),Date.parse(command.expectedUpdatedAt)+1)).toISOString();
  return {kind:'prepared',businessReference:str(request,'request_number'),result:{requestId:command.requestId,state:'withdrawn',appliedEffects:[],evidenceRetained:true},review:noReview(['Discards the pending draft while retaining its evidence and preserving all business records.']),apply(apply){
    run(apply.database,"UPDATE maintenance_requests SET state='withdrawn',updated_at=? WHERE dataset_id=? AND id=?",updatedAt,apply.datasetId,command.requestId);
    apply.event({kind:'maintenance-request',id:command.requestId},'Draft discarded without applying pending business changes.');
  }};
}
