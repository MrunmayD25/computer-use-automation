import type { DATASET_TABLES_IN_INSERT_ORDER } from './schema.js';

export type FinancialRecordTable = Exclude<(typeof DATASET_TABLES_IN_INSERT_ORDER)[number], 'document_blobs'>;
export type FinancialRecord = Readonly<Record<string, string | number | bigint | null>>;
export interface FinancialRecordReader {
  list(table: FinancialRecordTable, request: PageRequest): Page<FinancialRecord>;
}

declare const institutionIdBrand: unique symbol;
declare const datasetIdBrand: unique symbol;

export type InstitutionId = string & { readonly [institutionIdBrand]: true };
export type DatasetId = string & { readonly [datasetIdBrand]: true };
export type SeedScale = 'small' | 'standard' | 'capacity';

export interface DatasetBinding {
  institutionId: InstitutionId;
  datasetId: DatasetId;
}

export interface InstitutionSeed {
  id: string;
  legalName: string;
  displayName: string;
  timeZone: string;
  defaultCurrency: 'USD' | 'EUR' | 'JPY' | 'KWD';
}

export interface SeedManifest {
  name: string;
  generatorVersion: '2';
  schemaVersion: 2;
  seed: number;
  asOf: '2026-09-14T15:00:00.000Z';
  scale: SeedScale;
  institutions: readonly InstitutionSeed[];
}

export interface SeedWorldResult {
  kind: 'created' | 'existing';
  bindings: readonly DatasetBinding[];
}

export interface DatasetSummary {
  members: number;
  organizations: number;
  accounts: number;
  journalLines: number;
  payments: number;
  cards: number;
  loans: number;
  documents: number;
  cases: number;
  batches: number;
}

export interface PageRequest {
  limit: number;
  cursor?: string;
}

export interface Page<T> {
  items: readonly T[];
  nextCursor: string | null;
}

export interface MemberListItem {
  id: string;
  memberNumber: string;
  displayName: string;
  kind: 'person' | 'organization';
  status: 'active' | 'inactive' | 'deceased' | 'merged';
}

export interface AccountListItem {
  id: string;
  accountNumber: string;
  memberId: string;
  productCode: string;
  currency: string;
  status: 'open' | 'restricted' | 'dormant' | 'closed' | 'matured';
  postedBalanceMinorUnits: number;
  availableBalanceMinorUnits: number;
}

export interface PaymentListItem {
  id: string;
  reference: string;
  sourceAccountId: string;
  amountMinorUnits: number;
  currency: string;
  state: string;
}

export interface CardListItem {
  id: string;
  accountId: string;
  lastFour: string;
  status: string;
}

export interface LoanListItem {
  id: string;
  accountId: string;
  state: string;
  principalMinorUnits: number;
  currency: string;
}

export interface DocumentListItem {
  id: string;
  versionId: string;
  ownerPartyId: string;
  displayName: string;
  documentType: string;
  mediaType: string;
  digest: string;
  byteLength: number;
}

export interface CaseListItem {
  id: string;
  caseNumber: string;
  memberId: string;
  state: string;
  priority: string;
}

export interface BatchListItem {
  id: string;
  batchNumber: string;
  kind: string;
  state: string;
  itemCount: number;
}

export interface ActorListItem {
  id: string;
  actorNumber: string;
  displayName: string;
  status: string;
}

export interface AccountingQueries {
  journalLines(request: PageRequest): Page<{ journalId: string; lineNumber: number; ledgerAccountId: string; debitMinorUnits: number; creditMinorUnits: number; currency: string }>;
}

export interface FinancialDataset {
  records: FinancialRecordReader;
  summary(): DatasetSummary;
  members: { list(request: PageRequest): Page<MemberListItem> };
  accounts: { list(request: PageRequest): Page<AccountListItem> };
  payments: { list(request: PageRequest): Page<PaymentListItem> };
  cards: { list(request: PageRequest): Page<CardListItem> };
  loans: { list(request: PageRequest): Page<LoanListItem> };
  documents: {
    list(request: PageRequest): Page<DocumentListItem>;
    bytes(versionId: string): Uint8Array;
  };
  servicing: { listCases(request: PageRequest): Page<CaseListItem> };
  reconciliation: { listBatches(request: PageRequest): Page<BatchListItem> };
  policy: { listActors(request: PageRequest): Page<ActorListItem> };
  accounting: AccountingQueries;
}

export interface FinancialDatabase {
  seedWorld(manifest: SeedManifest): Promise<SeedWorldResult>;
  getNamedWorld(name: string): readonly DatasetBinding[];
  cloneDataset(binding: DatasetBinding, name?: string): DatasetBinding;
  dataset(binding: DatasetBinding): FinancialDataset;
  close(): void;
  [Symbol.dispose](): void;
}
