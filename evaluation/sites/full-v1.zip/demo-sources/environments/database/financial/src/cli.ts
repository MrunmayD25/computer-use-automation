#!/usr/bin/env node
import { resolve } from 'node:path';
import { DatabaseSync } from 'node:sqlite';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase, validateSeedManifest } from './public.js';
import type { SeedScale } from './model.js';
import { SCHEMA_VERSION } from './schema.js';
import { verifyFinancialDatabase } from './verification/independent-audit.js';

interface Arguments {
  command: 'seed' | 'verify';
  path: string;
  name: string;
  seed: number;
  scale: SeedScale;
  verbose: boolean;
}

function usage(): never {
  throw new Error('Usage: financial-seed <seed|verify> --path <sqlite-file> [--name <world>] [--seed <integer>] [--scale <small|standard|capacity>] [--verbose]');
}

function parseArguments(values: readonly string[]): Arguments {
  const command = values[0];
  if (command !== 'seed' && command !== 'verify') usage();
  let path = '';
  let name = DEFAULT_SEED_MANIFEST.name;
  let seed = DEFAULT_SEED_MANIFEST.seed;
  let scale: SeedScale = DEFAULT_SEED_MANIFEST.scale;
  let verbose = false;
  for (let index = 1; index < values.length; index += 1) {
    const value = values[index];
    if (value === '--verbose') {
      verbose = true;
      continue;
    }
    const next = values[index + 1];
    if (next === undefined) usage();
    if (value === '--path') path = resolve(next);
    else if (value === '--name') name = next;
    else if (value === '--seed') seed = Number(next);
    else if (value === '--scale' && ['small','standard','capacity'].includes(next)) scale = next as SeedScale;
    else usage();
    index += 1;
  }
  if (path.length === 0) usage();
  return { command, path, name, seed, scale, verbose };
}

async function main(): Promise<void> {
  const input = parseArguments(process.argv.slice(2));
  if (input.command === 'verify') {
    using database = new DatabaseSync(input.path, { readOnly: true });
    database.exec('PRAGMA query_only=ON; BEGIN');
    if (database.prepare('PRAGMA user_version').get()?.user_version !== SCHEMA_VERSION) throw new Error('Unsupported financial database schema version.');
    const bindings = database.prepare('SELECT institution_id AS institutionId,dataset_id AS datasetId FROM world_datasets WHERE world_name=? ORDER BY ordinal').all(input.name);
    if (bindings.length === 0) throw new Error(`World ${input.name} was not found.`);
    const failures = await verifyFinancialDatabase(database);
    if (failures.length > 0) throw new Error(`Database verification failed: ${JSON.stringify(failures.map(failure => ({ name: failure.name, count: failure.witnesses.length, witnesses: failure.witnesses.slice(0, 5) })))}`);
    process.stdout.write(`${JSON.stringify({ kind: 'verified', bindings, failures: 0 }, null, 2)}\n`);
    if (input.verbose) process.stderr.write(`Verified ${bindings.length} institution datasets.\n`);
    return;
  }
  using database = openFinancialDatabase({ path: input.path });
  const manifest = validateSeedManifest({ ...DEFAULT_SEED_MANIFEST, name: input.name, seed: input.seed, scale: input.scale });
  const result = await database.seedWorld(manifest);
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  if (input.verbose) process.stderr.write(`Seeded ${result.bindings.length} institution datasets.\n`);
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`${process.argv.includes('--verbose') && error instanceof Error ? error.stack ?? message : message}\n`);
  process.exitCode = 1;
});
