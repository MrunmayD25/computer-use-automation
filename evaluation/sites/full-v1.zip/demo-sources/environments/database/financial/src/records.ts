import type {DatabaseSync,SQLInputValue} from 'node:sqlite';
import {DATASET_TABLES_IN_INSERT_ORDER} from './schema.js';
import type {DatasetId,FinancialRecordReader,FinancialRecordTable,FinancialRecord,PageRequest} from './model.js';

const tables=new Set<string>(DATASET_TABLES_IN_INSERT_ORDER.filter(table=>table!=='document_blobs'));
const quote=(identifier:string):string=>`"${identifier.replaceAll('"','""')}"`;

function decodeCursor(cursor:string,datasetId:string,table:string,keyCount:number): SQLInputValue[] {
  try {
    if(cursor.length>4096) throw new Error('Oversized cursor.');
    const value:unknown=JSON.parse(Buffer.from(cursor,'base64url').toString('utf8'));
    if(!Array.isArray(value) || value.length!==3 || value[0]!==datasetId || value[1]!==table || !Array.isArray(value[2]) || value[2].length!==keyCount) throw new Error('Wrong cursor scope.');
    const keys:unknown[]=value[2];
    return keys.map(key=>{
      if(typeof key==='string' || typeof key==='number' && Number.isSafeInteger(key)) return key;
      throw new Error('Invalid cursor key.');
    });
  } catch(error) {throw new Error('Invalid record cursor.',{cause:error});}
}

export function createRecordReader(database:DatabaseSync,datasetId:DatasetId,checkAccess:()=>void):FinancialRecordReader {
  const primaryKeys=new Map<FinancialRecordTable,string[]>();
  return {
    list(table:FinancialRecordTable,request:PageRequest) {
      checkAccess();
      if(!tables.has(table)) throw new Error('Unsupported financial record table.');
      if(!Number.isSafeInteger(request.limit) || request.limit<1 || request.limit>100) throw new Error('Record page limit must be an integer from 1 through 100.');
      let keys=primaryKeys.get(table);
      if(!keys) {
        keys=database.prepare(`PRAGMA table_info(${quote(table)})`).all()
          .filter(row=>typeof row.pk==='number' && row.pk>0 && row.name!=='dataset_id')
          .sort((a,b)=>Number(a.pk)-Number(b.pk)).map(row=>String(row.name));
        if(keys.length===0) throw new Error(`No stable record key for ${table}.`);
        primaryKeys.set(table,keys);
      }
      const parameters:SQLInputValue[]=[datasetId];
      let after='';
      if(request.cursor!==undefined) {
        parameters.push(...decodeCursor(request.cursor,datasetId,table,keys.length));
        after=` AND (${keys.map(quote).join(',')})>(${keys.map(()=>'?').join(',')})`;
      }
      const result=database.prepare(`SELECT * FROM ${quote(table)} WHERE dataset_id=?${after} ORDER BY ${keys.map(quote).join(',')} LIMIT ?`).all(...parameters,request.limit+1);
      const hasMore=result.length>request.limit;
      const selected=hasMore ? result.slice(0,request.limit) : result;
      const items:FinancialRecord[]=selected.map(row=>Object.fromEntries(Object.entries(row).map(([key,value])=>{
        if(value instanceof Uint8Array) throw new Error('Binary content must be read through documents.bytes.');
        return [key,value];
      })));
      const last=items.at(-1);
      const nextCursor=hasMore && last ? Buffer.from(JSON.stringify([datasetId,table,keys.map(key=>last[key])])).toString('base64url') : null;
      return {items,nextCursor};
    },
  };
}
