import type { FinancialDatabase } from './model.js';
import { openDatabase } from './database.js';

export * from './model.js';

export { DEFAULT_SEED_MANIFEST, validateSeedManifest } from './manifest.js';

export interface OpenFinancialDatabaseOptions {
  path: string;
  busyTimeoutMs?: number;
}

export function openFinancialDatabase(options: OpenFinancialDatabaseOptions): FinancialDatabase {
  if (options.path.length === 0) throw new Error('Database path cannot be empty.');
  const timeout = options.busyTimeoutMs ?? 5_000;
  if (!Number.isSafeInteger(timeout) || timeout < 0 || timeout > 60_000) throw new Error('Busy timeout must be an integer from 0 through 60000 milliseconds.');
  return openDatabase(options.path, timeout);
}
