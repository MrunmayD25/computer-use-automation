import { randomUUID } from 'node:crypto';

import {
  ATOMIC_BATCH_CHILD_IDEMPOTENCY_PREFIX,
  ATOMIC_BATCH_IDEMPOTENCY_PREFIX,
  authorizeCommandTransaction,
  commandEnvironment,
  commandIntentDigest,
  executeCommandTransaction,
  validateCommandIdempotencyKey,
} from './commands.js';
import { canonicalJson, loadReceipt, one, OutcomeAbort, recordOperation, reject, sha256, str } from './core.js';
import type { FinancialStore } from './store.js';
import type { CommandOutcome, Receipt, Rejection, ServiceCommand, ServiceContext, Unchanged } from './types.js';

export const MAX_ATOMIC_BATCH_COMMANDS = 100;
const PARENT_KEY_PREFIX = `${ATOMIC_BATCH_IDEMPOTENCY_PREFIX}parent:`;

export interface AtomicBatchItemOutcome {
  /** Zero-based position in the submitted command array. */
  itemIndex: number;
  outcome: Extract<CommandOutcome, { kind: 'committed' | 'duplicate' }> | Unchanged;
}

export type AtomicBatchOutcome =
  | { kind: 'committed'; receipt: Receipt; items: AtomicBatchItemOutcome[] }
  | { kind: 'duplicate'; receipt: Receipt }
  | (Rejection & { itemIndex?: number });

class AtomicBatchAbort extends Error {
  constructor(readonly itemIndex: number, readonly rejection: Rejection) {
    super(rejection.kind);
  }
}

function parentIdempotencyKey(idempotencyKey: string): string {
  return `${PARENT_KEY_PREFIX}${sha256(idempotencyKey)}`;
}

function childIdempotencyKey(idempotencyKey: string, itemIndex: number): string {
  return `${ATOMIC_BATCH_CHILD_IDEMPOTENCY_PREFIX}${sha256(idempotencyKey)}:${itemIndex}`;
}

function itemSummary(item: AtomicBatchItemOutcome): Record<string, unknown> {
  if (item.outcome.kind === 'unchanged') return { itemIndex: item.itemIndex, kind: item.outcome.kind, message: item.outcome.message };
  return {
    itemIndex: item.itemIndex,
    kind: item.outcome.kind,
    operationId: item.outcome.receipt.operationId,
    receiptNumber: item.outcome.receipt.receiptNumber,
  };
}

/**
 * Commits an ordered command list in one database transaction.
 *
 * Every child observes prior child effects. A rejected child rolls back every child operation,
 * receipt, event, journal and business effect. The batch key owns the complete ordered payload.
 */
export function executeAtomicCommandBatch(
  store: FinancialStore,
  context: ServiceContext,
  commands: readonly ServiceCommand[],
  idempotencyKey: string,
): AtomicBatchOutcome {
  const submittedCommands: unknown = commands;
  if (!Array.isArray(submittedCommands)) return reject('validation', 'Atomic batch commands must be an array.', { field: 'commands' });
  if (commands.length === 0 || commands.length > MAX_ATOMIC_BATCH_COMMANDS) {
    return reject('validation', `An atomic batch must contain 1 to ${MAX_ATOMIC_BATCH_COMMANDS} commands.`, { field: 'commands' });
  }
  const invalidKey = validateCommandIdempotencyKey(idempotencyKey);
  if (invalidKey !== null) return invalidKey;
  // Bind the parent to child business intent while allowing a retry to refresh stale bindings.
  // Child transactions use the same digest, so parent and child idempotency cannot disagree.
  const batchDigest = sha256(canonicalJson(commands.map(commandIntentDigest)));

  try {
    return store.write({ kind: context.principalKind ?? 'human', actorId: context.actorId, reference: context.reference }, (database) => {
      const env = commandEnvironment(database, context);
      const parentKey = parentIdempotencyKey(idempotencyKey);
      const existing = one(database, 'SELECT id,command_digest,actor_id FROM operations WHERE dataset_id=? AND idempotency_key=?', env.datasetId, parentKey);
      if (existing !== undefined) {
        if (str(existing, 'actor_id') !== env.actorId) throw new OutcomeAbort(reject('idempotency_conflict', 'This atomic batch key belongs to another operator.'));
        if (str(existing, 'command_digest') !== batchDigest) throw new OutcomeAbort(reject('idempotency_conflict', 'This atomic batch key was already used for a different ordered command list.'));
        for (const command of commands) authorizeCommandTransaction(env, command);
        const receipt = loadReceipt(database, env.datasetId, { operationId: str(existing, 'id') });
        if (receipt === undefined) throw new Error('Committed atomic batch has no parent receipt.');
        return { kind: 'duplicate' as const, receipt };
      }

      const items: AtomicBatchItemOutcome[] = [];
      for (const [itemIndex, command] of commands.entries()) {
        try {
          const outcome = executeCommandTransaction(database, context, command, childIdempotencyKey(idempotencyKey, itemIndex), true);
          items.push({ itemIndex, outcome });
        } catch (error) {
          if (!(error instanceof OutcomeAbort)) throw error;
          if (error.outcome.kind === 'rejected') throw new AtomicBatchAbort(itemIndex, error.outcome);
          items.push({ itemIndex, outcome: error.outcome });
        }
      }

      const result: Record<string, unknown> = {
        batchDigest,
        commandCount: commands.length,
        items: items.map(itemSummary),
      };
      const operationId = `op-${randomUUID()}`;
      recordOperation(database, {
        datasetId: env.datasetId,
        actorId: env.actorId,
        kind: 'command.batch.atomic',
        businessReference: `BAT-${batchDigest.slice(0, 12).toUpperCase()}`,
        idempotencyKey: parentKey,
        commandDigest: batchDigest,
        resultDigest: sha256(canonicalJson(result)),
        result,
        now: env.now,
        operationId,
      });
      const receipt = loadReceipt(database, env.datasetId, { operationId });
      if (receipt === undefined) throw new Error('Committed atomic batch has no parent receipt.');
      return { kind: 'committed' as const, receipt, items };
    });
  } catch (error) {
    if (error instanceof AtomicBatchAbort) return { ...error.rejection, itemIndex: error.itemIndex };
    if (error instanceof OutcomeAbort && error.outcome.kind === 'rejected') return error.outcome;
    throw error;
  }
}
