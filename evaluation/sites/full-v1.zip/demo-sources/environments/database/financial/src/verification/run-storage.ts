import { createHash } from 'node:crypto';
import { DatabaseSync, type SQLOutputValue } from 'node:sqlite';
import { isDeepStrictEqual } from 'node:util';
import type { CapturedRow, CapturedTransaction, CapturedValue, RunLimits, RunSnapshot, RunTableSnapshot, SnapshotOrdering, SnapshotPrimaryKeyType } from './run-types.js';

export const PRIVATE_PREFIX = '__verification_';
export function quote(name: string): string { return `"${name.replaceAll('"', '""')}"`; }
export function digest(value: unknown): string { return createHash('sha256').update(JSON.stringify(value)).digest('hex'); }
export function freeze<T>(value: T): T {
  if (value !== null && typeof value === 'object') {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
export function valueOf(value: SQLOutputValue, limits: RunLimits): CapturedValue {
  if (value instanceof Uint8Array) {
    if (value.byteLength > limits.maxBlobBytes) throw new Error('BLOB byte limit exceeded.');
    return { kind: 'blob', digest: createHash('sha256').update(value).digest('hex'), byteLength: value.byteLength };
  }
  if (typeof value === 'bigint') {
    return value >= BigInt(Number.MIN_SAFE_INTEGER) && value <= BigInt(Number.MAX_SAFE_INTEGER)
      ? Number(value) : { kind: 'integer', decimal: value.toString() };
  }
  if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('Non-finite SQL numbers cannot be captured.');
  return value;
}
export interface TableShape {
  name: string;
  columns: readonly string[];
  primaryKey: readonly string[];
  ordering: SnapshotOrdering;
  primaryKeyTypes: readonly SnapshotPrimaryKeyType[];
}
function primaryKeyTypes(info: readonly Record<string, SQLOutputValue>[], primaryKey: readonly string[]): SnapshotPrimaryKeyType[] | undefined {
  const types: SnapshotPrimaryKeyType[] = [];
  for (const name of primaryKey) {
    const column = info.find((entry) => String(entry.name) === name);
    const type = column === undefined ? undefined : String(column.type).toUpperCase();
    if (type !== 'TEXT' && type !== 'INTEGER' && type !== 'REAL') return undefined;
    types.push(type);
  }
  return types;
}
function hasBinaryPrimaryKeyCollation(database: DatabaseSync, name: string, primaryKey: readonly string[], types: readonly SnapshotPrimaryKeyType[]): boolean {
  if (primaryKey.length === 1 && types[0] === 'INTEGER') return true;
  const index = database.prepare(`PRAGMA index_list(${quote(name)})`).all().find((entry) => String(entry.origin) === 'pk');
  if (index === undefined) return false;
  const columns = database.prepare(`PRAGMA index_xinfo(${quote(String(index.name))})`).all()
    .filter((entry) => Number(entry.key) === 1)
    .sort((left, right) => Number(left.seqno) - Number(right.seqno));
  return columns.length === primaryKey.length && columns.every((column, index) => column.name === primaryKey[index] && column.coll === 'BINARY');
}
export function tableShapes(database: DatabaseSync): TableShape[] {
  const names = database.prepare("SELECT name FROM sqlite_schema WHERE type='table' AND substr(name,1,7)<>'sqlite_' ORDER BY name").all();
  const strict = new Set(database.prepare('PRAGMA table_list').all().filter((row) => row.schema === 'main' && Number(row.strict) === 1).map((row) => String(row.name)));
  const encoding = String(database.prepare('PRAGMA encoding').get()?.encoding).toUpperCase();
  return names.filter((row) => !String(row.name).startsWith(PRIVATE_PREFIX)).map((row) => {
    const name = String(row.name);
    const info = database.prepare(`PRAGMA table_info(${quote(name)})`).all();
    const columns = info.map((column) => String(column.name)).sort();
    const primaryKey = info.filter((column) => Number(column.pk) > 0).sort((a, b) => Number(a.pk) - Number(b.pk)).map((column) => String(column.name));
    if (primaryKey.length === 0) throw new Error(`Captured table ${name} must have a primary key.`);
    const types = primaryKeyTypes(info, primaryKey);
    const native = types !== undefined && strict.has(name) && (!types.includes('TEXT') || encoding === 'UTF-8') && hasBinaryPrimaryKeyCollation(database, name, primaryKey, types);
    return { name, columns, primaryKey, ordering: native ? 'sqlite-pk-v1' : 'canonical-json-v1', primaryKeyTypes: native ? types : [] };
  });
}
export function schemaDigest(database: DatabaseSync, includeCapture = false): string {
  const rows = database.prepare("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE substr(name,1,7)<>'sqlite_' ORDER BY type,name").all();
  return digest(rows.filter((row) => includeCapture || !String(row.name).startsWith(PRIVATE_PREFIX)));
}
export function rowKey(row: CapturedRow, columns: readonly string[]): string {
  return JSON.stringify(columns.map((column) => row[column]));
}
export interface SnapshotLifetime { closed: boolean; database?: DatabaseSync }
type Overlay = ReadonlyMap<string, ReadonlyMap<string, CapturedRow | null>>;
interface SnapshotSource {
  database: DatabaseSync;
  path?: string;
  limits: RunLimits;
  overlay: Overlay;
  history: readonly CapturedTransaction[];
  lifetime: SnapshotLifetime;
}
const sources = new WeakMap<RunSnapshot, SnapshotSource>();
function sourceOf(snapshot: RunSnapshot): SnapshotSource {
  const source = sources.get(snapshot);
  if (source === undefined) throw new Error('Snapshot is not an authentic registered SQL snapshot.');
  if (source.lifetime.closed) throw new Error('Snapshot evidence reader is closed.');
  return source;
}
export function snapshotLifetime(snapshot: RunSnapshot): SnapshotLifetime { return sourceOf(snapshot).lifetime; }
export function snapshotHistory(snapshot: RunSnapshot): readonly CapturedTransaction[] { return sourceOf(snapshot).history; }
export function closeSnapshot(snapshot: RunSnapshot): void {
  const source = sources.get(snapshot);
  if (source === undefined) return;
  source.lifetime.closed = true;
  if (source.lifetime.database?.isOpen) source.lifetime.database.close();
}
export function attachSnapshot(snapshot: RunSnapshot, path: string, limits: RunLimits, lifetime: SnapshotLifetime = { closed: false }): void {
  const database = lifetime.database ?? new DatabaseSync(path, { readOnly: true });
  if (lifetime.database === undefined) {
    try {
      database.exec('PRAGMA query_only=ON; PRAGMA cache_size=-8192; BEGIN');
      database.prepare('SELECT name FROM sqlite_schema LIMIT 1').get();
      lifetime.database = database;
    } catch (error) { database.close(); throw error; }
  }
  sources.set(snapshot, { database, path, limits, overlay: new Map(), history: [], lifetime });
}
export function inheritSnapshot(snapshot: RunSnapshot, from: RunSnapshot): void { sources.set(snapshot, sourceOf(from)); }
const keyFunctions = new WeakSet<DatabaseSync>();
function installKeyFunction(database: DatabaseSync, limits: RunLimits): void {
  if (keyFunctions.has(database)) return;
  database.function('__verification_sort_key', { varargs: true, useBigIntArguments: true }, (...values) => Buffer.from(JSON.stringify(values.map((value) => valueOf(value, limits))), 'utf8'));
  keyFunctions.add(database);
}
function sqlFilter(equals: Readonly<Record<string, CapturedValue>>): { sql: string; values: (string | number | bigint | null)[] } {
  const terms: string[] = [];
  const values: (string | number | bigint | null)[] = [];
  for (const [name, value] of Object.entries(equals)) {
    if (value !== null && typeof value === 'object' && value.kind === 'blob') continue;
    if (typeof value === 'string' && value.includes('�')) continue;
    terms.push(`${quote(name)} IS ?`);
    values.push(value !== null && typeof value === 'object' ? BigInt(value.decimal) : value);
  }
  return { sql: terms.length ? ` WHERE ${terms.join(' AND ')}` : '', values };
}
function compareInteger(left: CapturedValue, right: CapturedValue): number {
  const value = (input: CapturedValue): bigint => {
    if (typeof input === 'number' && Number.isSafeInteger(input)) return BigInt(input);
    if (input !== null && typeof input === 'object' && input.kind === 'integer') return BigInt(input.decimal);
    throw new Error('Native INTEGER primary key has an invalid captured value.');
  };
  const first = value(left); const second = value(right);
  return first < second ? -1 : first > second ? 1 : 0;
}
function comparePrimaryKeyValue(type: SnapshotPrimaryKeyType, left: CapturedValue, right: CapturedValue): number {
  if (left === null || right === null) return left === right ? 0 : left === null ? -1 : 1;
  if (type === 'INTEGER') return compareInteger(left, right);
  if (type === 'REAL') {
    if (typeof left !== 'number' || typeof right !== 'number') throw new Error('Native REAL primary key has an invalid captured value.');
    return left < right ? -1 : left > right ? 1 : 0;
  }
  if (typeof left !== 'string' || typeof right !== 'string') throw new Error('Native TEXT primary key has an invalid captured value.');
  return Buffer.compare(Buffer.from(left, 'utf8'), Buffer.from(right, 'utf8'));
}
function compareRows(shape: TableShape, left: CapturedRow, right: CapturedRow): number {
  if (shape.ordering === 'canonical-json-v1') return Buffer.compare(Buffer.from(rowKey(left, shape.primaryKey)), Buffer.from(rowKey(right, shape.primaryKey)));
  for (const [index, column] of shape.primaryKey.entries()) {
    const first = left[column]; const second = right[column]; const type = shape.primaryKeyTypes[index];
    if (first === undefined || second === undefined || type === undefined) throw new Error('Native primary key column is missing.');
    const difference = comparePrimaryKeyValue(type, first, second);
    if (difference !== 0) return difference;
  }
  return 0;
}
function orderBy(shape: TableShape): string {
  return shape.ordering === 'sqlite-pk-v1'
    ? shape.primaryKey.map((column) => `${quote(column)} COLLATE BINARY`).join(',')
    : `__verification_sort_key(${shape.primaryKey.map(quote).join(',')}) COLLATE BINARY`;
}
function* sqlRows(database: DatabaseSync, shape: TableShape, limits: RunLimits, equals: Readonly<Record<string, CapturedValue>> = {}): Generator<CapturedRow> {
  const filter = sqlFilter(equals);
  const statement = database.prepare(`SELECT ${shape.columns.map(quote).join(',')} FROM ${quote(shape.name)}${filter.sql} ORDER BY ${orderBy(shape)}`);
  statement.setReadBigInts(true);
  let previous: string | undefined;
  let previousRow: CapturedRow | undefined;
  for (const raw of statement.iterate(...filter.values)) {
    const row: Record<string, CapturedValue> = {};
    for (const column of shape.columns) {
      const value = raw[column];
      if (value === undefined) throw new Error(`Missing SQL column ${column}.`);
      row[column] = valueOf(value, limits);
    }
    const key = rowKey(row, shape.primaryKey);
    if (shape.ordering === 'sqlite-pk-v1') {
      if (previousRow !== undefined && compareRows(shape, previousRow, row) >= 0) throw new Error(`Native primary key order is not unique after normalization in ${shape.name}.`);
      previousRow = row;
    } else if (key === previous) throw new Error(`Duplicate snapshot primary key in ${shape.name}.`);
    previous = key;
    if (Object.entries(equals).every(([column, value]) => isDeepStrictEqual(row[column], value))) yield row;
  }
}
/** Reads normalized rows from an authenticated snapshot, with exact filters applied after historical updates. */
export function* selectSnapshotRows(snapshot: RunSnapshot, table: string, equals: Readonly<Record<string, CapturedValue>> = {}): Generator<CapturedRow> {
  const source = sourceOf(snapshot);
  const metadata = snapshot.tables[table];
  if (metadata === undefined) throw new Error(`Unknown captured table ${table}.`);
  for (const column of Object.keys(equals)) if (!metadata.columns.includes(column)) throw new Error(`Unknown ${table}.${column}.`);
  const database = source.database;
  installKeyFunction(database, source.limits);
  const overlay = source.overlay.get(table);
  const shape: TableShape = { name: table, ...metadata };
  const additions = [...(overlay?.entries() ?? [])].filter((entry): entry is [string, CapturedRow] => entry[1] !== null
    && Object.entries(equals).every(([column, value]) => isDeepStrictEqual(entry[1]?.[column], value)))
    .sort(([, left], [, right]) => compareRows(shape, left, right));
  let index = 0;
  let next = additions[index];
  for (const row of sqlRows(database, shape, source.limits, equals)) {
    sourceOf(snapshot);
    const key = rowKey(row, metadata.primaryKey);
    while (next !== undefined && compareRows(shape, next[1], row) < 0) {
      sourceOf(snapshot);
      yield next[1]; next = additions[++index];
    }
    if (!overlay?.has(key)) {
      sourceOf(snapshot);
      yield row;
    }
  }
  while (next !== undefined) {
    sourceOf(snapshot);
    yield next[1]; next = additions[++index];
  }
}
interface SnapshotBudget { rows: number; blobBytes: number; bytes: number }
function addBudget(budget: SnapshotBudget, table: RunTableSnapshot, limits: RunLimits): void {
  budget.rows += table.rowCount; budget.blobBytes += table.blobBytes; budget.bytes += table.byteLength;
  if (budget.rows > limits.maxRows) throw new Error('Snapshot row limit exceeded.');
  if (budget.blobBytes > limits.maxBlobBytes) throw new Error('Snapshot BLOB byte limit exceeded.');
  if (budget.bytes > limits.maxSnapshotBytes) throw new Error('Snapshot byte limit exceeded.');
}
function summarize(shape: TableShape, rows: Iterable<CapturedRow>, limits: RunLimits, budget: SnapshotBudget): RunTableSnapshot {
  const hash = createHash('sha256').update('verification-table-v2\n').update(JSON.stringify({ columns: shape.columns, primaryKey: shape.primaryKey, ordering: shape.ordering, primaryKeyTypes: shape.primaryKeyTypes })).update('\n');
  let rowCount = 0; let blobBytes = 0; let byteLength = 0;
  for (const row of rows) {
    const encoded = JSON.stringify(row);
    const size = Buffer.byteLength(encoded);
    let blobs = 0;
    for (const value of Object.values(row)) if (value !== null && typeof value === 'object' && value.kind === 'blob') blobs += value.byteLength;
    rowCount += 1; blobBytes += blobs; byteLength += size;
    addBudget(budget, { columns: [], primaryKey: [], ordering: 'canonical-json-v1', primaryKeyTypes: [], rowCount: 1, blobBytes: blobs, byteLength: size, digest: '' }, limits);
    hash.update(encoded).update('\n');
  }
  return { columns: shape.columns, primaryKey: shape.primaryKey, ordering: shape.ordering, primaryKeyTypes: shape.primaryKeyTypes, rowCount, blobBytes, byteLength, digest: hash.digest('hex') };
}
function snapshotSequence(database: DatabaseSync): number {
  const captureExists = database.prepare("SELECT name FROM sqlite_schema WHERE name='__verification_changes'").get();
  return captureExists === undefined ? 0 : Number(database.prepare('SELECT COALESCE(MAX(sequence),0) AS n FROM __verification_changes').get()?.n);
}
export function captureSnapshot(database: DatabaseSync, label: string, limits: RunLimits): RunSnapshot {
  installKeyFunction(database, limits);
  const tables: Record<string, RunTableSnapshot> = {};
  const budget: SnapshotBudget = { rows: 0, blobBytes: 0, bytes: 0 };
  for (const shape of tableShapes(database)) tables[shape.name] = summarize(shape, sqlRows(database, shape, limits), limits, budget);
  const body = { label, schemaDigest: schemaDigest(database), sequence: snapshotSequence(database), tables };
  const snapshot = freeze({ ...body, digest: digest(body) });
  sources.set(snapshot, { database, limits, overlay: new Map(), history: [], lifetime: { closed: false } });
  return snapshot;
}
export function matchesSnapshot(database: DatabaseSync, label: string, limits: RunLimits, expected: RunSnapshot): boolean {
  return isDeepStrictEqual(captureSnapshot(database, label, limits), expected);
}
/** Replays complete ordered row images over a SQL baseline, keeping only touched keys in memory. */
export function replaySnapshot(before: RunSnapshot, transactions: readonly CapturedTransaction[], label = 'replayed'): RunSnapshot {
  const source = sourceOf(before);
  const ownedTransactions = freeze(structuredClone(transactions));
  const history = freeze([...source.history, ...ownedTransactions]);
  const overlay = new Map<string, Map<string, CapturedRow | null>>();
  for (const [table, rows] of source.overlay) overlay.set(table, new Map(rows));
  const changed = new Set<string>();
  let sequence = before.sequence;
  for (const transaction of ownedTransactions) for (const change of transaction.changes) {
    const table = before.tables[change.table];
    if (table === undefined) throw new Error('Capture refers to a table absent from the baseline.');
    if (change.sequence <= sequence || change.transactionId !== transaction.id) throw new Error('Invalid change sequence or transaction binding.');
    const rows = overlay.get(change.table) ?? new Map<string, CapturedRow | null>();
    overlay.set(change.table, rows);
    const key = rowKey(change.key, table.primaryKey);
    if (!isDeepStrictEqual(Object.keys(change.key).sort(), [...table.primaryKey].sort())) throw new Error('Capture primary key columns do not match the table.');
    const read = (keyRow: CapturedRow): CapturedRow | null => {
      const id = rowKey(keyRow, table.primaryKey);
      if (rows.has(id)) return rows.get(id) ?? null;
      const filter: Record<string, CapturedValue> = {};
      for (const column of table.primaryKey) {
        const value = keyRow[column];
        if (value === undefined) throw new Error('Missing capture primary key column.');
        filter[column] = value;
      }
      const found = [...selectSnapshotRows(before, change.table, filter)];
      if (found.length > 1) throw new Error('Duplicate snapshot primary key.');
      return found[0] ?? null;
    };
    if (!isDeepStrictEqual(read(change.key), change.before)) throw new Error(`Capture before-image mismatch at sequence ${change.sequence}.`);
    if (change.before !== null && key !== rowKey(change.before, table.primaryKey)) throw new Error('Capture key differs from its before-image.');
    if (change.operation === 'insert' && (change.before !== null || change.after === null)) throw new Error('Invalid insert image.');
    if (change.operation === 'insert' && change.after !== null && key !== rowKey(change.after, table.primaryKey)) throw new Error('Capture insert key differs from its after-image.');
    if (change.operation === 'delete' && (change.before === null || change.after !== null)) throw new Error('Invalid delete image.');
    if (change.operation === 'update' && (change.before === null || change.after === null)) throw new Error('Invalid update images.');
    rows.set(key, null);
    if (change.after !== null) {
      if (Object.keys(change.after).sort().join('\0') !== [...table.columns].sort().join('\0')) throw new Error('Capture row columns do not match the table.');
      const nextKey = rowKey(change.after, table.primaryKey);
      if (nextKey !== key && read(change.after) !== null) throw new Error('Capture inserts an already existing primary key.');
      rows.set(nextKey, change.after);
    }
    changed.add(change.table); sequence = change.sequence;
  }
  const tables: Record<string, RunTableSnapshot> = { ...before.tables };
  const draft: RunSnapshot = { ...before, label, sequence, tables };
  sources.set(draft, { ...source, overlay, history });
  const budget: SnapshotBudget = { rows: 0, blobBytes: 0, bytes: 0 };
  for (const [name, table] of Object.entries(tables)) {
    if (changed.has(name)) tables[name] = summarize({ name, ...table }, selectSnapshotRows(draft, name), source.limits, budget);
    else addBudget(budget, table, source.limits);
  }
  const body = { label, schemaDigest: before.schemaDigest, sequence, tables };
  const snapshot = freeze({ ...body, digest: digest(body) });
  sources.set(snapshot, { ...source, overlay, history });
  return snapshot;
}
