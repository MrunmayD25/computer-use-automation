/** Effective facility limit: the latest approved revision supersedes the origination limit, including at expiry. */
export function facilityLimitSql(clock: string): string {
  return `COALESCE((SELECT CASE WHEN term.expires_at IS NULL OR term.expires_at>${clock} THEN term.limit_minor_units ELSE 0 END FROM facility_limit_terms term WHERE term.dataset_id=f.dataset_id AND term.facility_id=f.id AND term.effective_at<=${clock} ORDER BY term.effective_at DESC,term.id DESC LIMIT 1),f.limit_minor_units)`;
}
