import { createHash } from 'node:crypto';
import type { SQLInputValue } from 'node:sqlite';

import { formatMinorUnits, renderCsv, renderDocument, renderScanPdf, renderScanPng, renderStatementPdf, type DocumentArtifact, type FinancialDocumentInput } from '../documents.js';
import { canonicalJson } from '../services/core.js';
import type { CoreSeedReferences, SeedContext } from './contract.js';

type Row = Record<string, SQLInputValue>;

function string(row: Row, field: string): string {
  const value = row[field];
  if (typeof value !== 'string') throw new Error(`Missing document seed text ${field}.`);
  return value;
}

function number(row: Row, field: string): number {
  const value = row[field];
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error(`Invalid document seed integer ${field}.`);
  return value;
}

function daysBefore(asOf: string, days: number): string {
  return new Date(new Date(asOf).getTime() - days * 86_400_000).toISOString();
}

export async function seedDocumentsAndServicing(context: SeedContext, refs: CoreSeedReferences): Promise<{ documentVersionIds: string[]; caseIds: string[] }> {
  const db = context.database;
  const dataset = context.binding.datasetId;
  const documentVersionIds: string[] = [];
  const caseIds: string[] = [];
  const actors = refs.actorIds;
  const actor = actors[1];
  const checker = actors[4];
  if (actor === undefined || checker === undefined || refs.queueIds.length === 0) throw new Error('Servicing requires makers, checkers and queues.');
  const insert = (table: string, values: Row): void => {
    const data = { dataset_id: dataset, ...values };
    const columns = Object.keys(data);
    db.prepare(`INSERT INTO ${table} (${columns.join(',')}) VALUES (${columns.map(() => '?').join(',')})`).run(...Object.values(data));
  };
  const store = (artifact: DocumentArtifact, ownerPartyId: string, accountId: string | null, kind: string, ordinal: string,
    issuedAt: string, options: { version?: number; documentId?: string; status?: string; periodStart?: string; periodEnd?: string } = {}): string => {
    const documentId = options.documentId ?? context.id('document', ordinal);
    const version = options.version ?? 1;
    const versionId = context.id('document-version', `${ordinal}-${version}`);
    db.prepare('INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,?,?,?)')
      .run(dataset, artifact.digest, artifact.mediaType, artifact.bytes.length, artifact.bytes);
    if (options.documentId === undefined) insert('documents', { id: documentId, owner_party_id: ownerPartyId, account_id: accountId,
      document_type: kind, display_name: artifact.displayName, retention_class: kind === 'account-statement' ? 'financial-seven-years' : 'servicing-evidence', created_at: issuedAt });
    insert('document_versions', { id: versionId, document_id: documentId, version, digest: artifact.digest,
      media_type: artifact.mediaType, issued_at: issuedAt, period_start: options.periodStart ?? null,
      period_end: options.periodEnd ?? null, page_count: artifact.pageCount, status: options.status ?? 'current' });
    documentVersionIds.push(versionId);
    return versionId;
  };
  const members = db.prepare(`SELECT m.id,m.party_id,m.member_number,p.display_name FROM members m
    JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE m.dataset_id=? ORDER BY m.member_number`).all(dataset);
  const templateOwner = members[0];
  if (templateOwner === undefined) throw new Error('Closure templates require a document owner.');
  for (const [index, documentType] of ['loan-closure-confirmation', 'simulated-lien-release'].entries()) {
    const template = await renderDocument({
      title: `${documentType} approved template`, institutionName: context.institution.displayName,
      ownerName: 'Institution operations', memberNumber: 'TEMPLATE', asOf: context.asOf,
      documentType: `${documentType}-template`, version: 1, displayName: `${documentType}-template.pdf`,
      sections: [{ heading: 'Required fields', lines: ['Loan reference', 'Account reference', 'Owner party', 'Closure receipt', 'Closed at', 'Issued and delivery status'] }],
    });
    store(template, string(templateOwner, 'party_id'), null, `${documentType}-template`, `loan-closure-template-${index}`, context.asOf);
  }
  const documentMembers = members.slice(0, context.scale === 'small' ? 48 : context.scale === 'standard' ? 180 : 300);
  const communicationStates = ['draft', 'queued', 'accepted', 'delivered', 'bounced', 'cancelled'] as const;
  const consentStates = ['granted', 'withdrawn', 'expired', 'pending'] as const;
  const signatureStates = ['signed', 'signed', 'expired', 'requested'] as const;
  const requestStates = ['draft', 'submitted', 'approved', 'applied', 'rejected', 'withdrawn', 'cancelled'] as const;
  const caseStates = ['open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened'] as const;
  const accountQuery = db.prepare('SELECT id,account_number FROM accounts WHERE dataset_id=? AND member_id=? ORDER BY account_number LIMIT 1');
  for (const [index, member] of documentMembers.entries()) {
    const memberId = string(member, 'id');
    const partyId = string(member, 'party_id');
    const name = string(member, 'display_name');
    const memberNumber = string(member, 'member_number');
    const account = accountQuery.get(dataset, memberId);
    const accountId = account === undefined ? null : string(account, 'id');
    const issuedAt = daysBefore(context.asOf, 45 + index % 30);
    const base: FinancialDocumentInput = { title: 'Electronic delivery disclosure', institutionName: context.institution.displayName,
      ownerName: name, memberNumber, asOf: issuedAt, documentType: 'delivery-disclosure', version: 1,
      displayName: 'disclosure.pdf', sections: [{ heading: 'Scope and choice', lines: [
        'This disclosure covers electronic account statements only.',
        'Marketing preferences are separate from statement delivery consent.',
        'Paper servicing notices remain available under institutional policy.',
        `Disclosure reference: ${context.businessNumber('ED', index + 1)}`,
        'All records, signatures, and delivery channels are synthetic local simulations.',
      ] }] };
    const disclosure = await renderDocument(base);
    const disclosureId = store(disclosure, partyId, accountId, 'delivery-disclosure', `disclosure-${index}`, issuedAt,
      index % 8 === 0 ? { status: 'superseded' } : {});
    if (index % 8 === 0) {
      const updated = await renderDocument({ ...base, version: 2, asOf: daysBefore(context.asOf, 20),
        sections: [...base.sections, { heading: 'Revised contact method', lines: ['Contact the local servicing desk for format changes.'] }] });
      store(updated, partyId, accountId, 'delivery-disclosure', `disclosure-${index}`, daysBefore(context.asOf, 20),
        { documentId: context.id('document', `disclosure-${index}`), version: 2 });
    }
    const consentState = consentStates[index % consentStates.length] ?? 'pending';
    insert('consents', { id: context.id('consent', index), party_id: partyId, account_id: accountId, purpose: 'account-statements', channel: 'electronic',
      disclosure_version_id: disclosureId, state: consentState, effective_at: daysBefore(context.asOf, 18) });
    for (const [purpose, state] of [['marketing', index % 2 === 0 ? 'disabled' : 'enabled'], ['servicing', 'enabled']] as const) {
      insert('communication_preferences', { id: context.id('communication-preference', `${index}-${purpose}`), party_id: partyId,
        purpose, channel: 'email', state, updated_at: daysBefore(context.asOf, 17) });
    }
    insert('communication_preferences', { id: context.id('communication-preference', `${index}-account-statements`), party_id: partyId,
      purpose: 'account-statements', channel: 'electronic', state: 'enabled', updated_at: daysBefore(context.asOf, 23) });
    const signatureState = index % 8 === 7 ? 'declined' : signatureStates[index % signatureStates.length] ?? 'requested';
    let signatureEvidenceId: string | null = null;
    if (signatureState === 'signed') {
      const signedAt = daysBefore(context.asOf, 21);
      const evidence = await renderDocument({ ...base, title: 'Local signature evidence', documentType: 'signature-evidence',
        displayName: 'signature-evidence.pdf', asOf: signedAt, sections: [{ heading: 'Synthetic acknowledgement record', lines: [
          `Signer: ${name}`, `Signer party reference: ${partyId}`, `Recorded at: ${signedAt}`,
          `Signed document version: ${disclosureId}`, `Signed content SHA-256: ${disclosure.digest}`,
          'Acknowledgement: electronic account-statement disclosure accepted through the local simulation.',
          'This record binds the named signer to this exact content version. It does not represent a real legal signature.',
        ] }] });
      signatureEvidenceId = store(evidence, partyId, accountId, 'signature-evidence', `signature-evidence-${index}`, signedAt, { status: 'signed' });
    }
    insert('signatures', { id: context.id('signature', index), document_version_id: disclosureId, signer_party_id: partyId,
      status: signatureState, requested_at: daysBefore(context.asOf, 22), signed_at: signatureState === 'signed' ? daysBefore(context.asOf, 21) : null,
      evidence_reference: signatureEvidenceId });
    const noticeInput: FinancialDocumentInput = { ...base, title: 'Servicing information request', documentType: 'servicing-notice', displayName: 'notice.pdf',
      asOf: daysBefore(context.asOf, 12), sections: [{ heading: 'Requested information', lines: [
        `Reference: ${context.businessNumber('SR', index + 1)}`, 'Provide current address evidence through the local servicing desk.',
        'No change to the account has been applied by this request.', `Due date: ${daysBefore(context.asOf, -8).slice(0, 10)}`,
      ] }] };
    const noticeId = store(await renderDocument(noticeInput), partyId, accountId, 'servicing-notice', `notice-${index}`, noticeInput.asOf);
    const jobId = context.id('communication-job', index);
    const jobState = communicationStates[index % communicationStates.length] ?? 'draft';
    const contact = db.prepare("SELECT value FROM contact_points WHERE dataset_id=? AND party_id=? AND kind='email' ORDER BY id LIMIT 1").get(dataset, partyId);
    insert('communication_jobs', { id: jobId, party_id: partyId, document_version_id: noticeId, purpose: 'servicing', channel: 'email',
      destination: contact === undefined ? `member-${index}@example.test` : string(contact, 'value'), state: jobState, created_at: daysBefore(context.asOf, 11) });
    const states = jobState === 'draft' ? ['draft'] : jobState === 'queued' ? ['draft', 'queued'] :
      jobState === 'cancelled' ? ['draft', 'queued', 'cancelled'] : jobState === 'accepted' ? ['draft', 'queued', 'accepted'] : ['draft', 'queued', 'accepted', jobState];
    states.forEach((state, sequence) => insert('communication_events', { id: context.id('communication-event', `${index}-${sequence}`), job_id: jobId,
      sequence: sequence + 1, state, occurred_at: daysBefore(context.asOf, 11 - sequence), detail: state === 'bounced' ? 'Synthetic mailbox unavailable.' : `Local delivery state ${state}.` }));
    if (index % 12 === 1) {
      const pendingStatementId = context.id('communication-job', `statement-${index}`);
      insert('communication_jobs', { id: pendingStatementId, party_id: partyId, document_version_id: disclosureId,
        purpose: 'account-statements', channel: 'electronic', destination: contact === undefined ? `member-${index}@example.test` : string(contact, 'value'),
        state: 'queued', created_at: daysBefore(context.asOf, 20) });
      for (const [sequence, state] of ['draft', 'queued'].entries()) insert('communication_events', {
        id: context.id('communication-event', `statement-${index}-${sequence}`), job_id: pendingStatementId, sequence: sequence + 1,
        state, occurred_at: daysBefore(context.asOf, 20 - sequence), detail: 'Optional electronic statement job admitted before consent withdrawal.' });
    }
    let evidenceId = noticeId;
    if (index < 8) {
      const address = db.prepare(`SELECT a.line1,a.city,a.region,a.postal_code,pa.evidence_status FROM party_addresses pa
        JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
        WHERE pa.dataset_id=? AND pa.party_id=? ORDER BY pa.id LIMIT 1`).get(dataset, partyId);
      const addressLines = address === undefined ? ['No verified address is currently recorded.'] :
        [string(address, 'line1'), `${string(address, 'city')}, ${string(address, 'region')} ${string(address, 'postal_code')}`,
          `Source status: ${string(address, 'evidence_status')}`];
      const scanInput: FinancialDocumentInput = { ...base, title: 'Address evidence scan', documentType: 'address-evidence',
        sections: [{ heading: 'Evidence review', lines: [`Subject: ${memberNumber}`, `Evidence reference: ${context.businessNumber('EV', index + 1)}`,
          index % 2 === 0 ? 'Review status: verified' : 'Review status: requires clarification', ...addressLines, 'Synthetic scanned correspondence. Original content remains unchanged.'] }] };
      evidenceId = store(await renderScanPdf({ ...scanInput, rotation: index % 2 === 0 ? 0 : 90, ...(index === 7 ? { embeddedTranscript: 'Unverified OCR transcription. Address: 99 Pine Avenue. This transcript conflicts with the scanned original.' } : {}) }), partyId, accountId, 'address-evidence', `scan-${index}`, issuedAt);
      if (index === 0) store(await renderScanPng(scanInput), partyId, accountId, 'address-evidence-image', 'scan-image', issuedAt);
      insert('document_annotations', { id: context.id('document-annotation', index), document_version_id: noticeId, actor_id: actor,
        page_number: 1, region_json: JSON.stringify({ x: 0.07, y: 0.20, width: 0.75, height: 0.08 }), text: 'Verify the requested owner and current evidence before applying changes.',
        status: index % 3 === 0 ? 'amended' : index % 3 === 1 ? 'active' : 'removed', created_at: daysBefore(context.asOf, 9) });
    }
    const requestState = requestStates[index % requestStates.length] ?? 'draft';
    const requestId = context.id('maintenance-request', index);
    let receiptId: string | null = null;
    const noteText = `Address evidence review recorded for ${memberNumber}; no contact fields changed.`;
    const requestedCommand = { kind: 'member.note.add', memberId, visibility: 'general', text: noteText };
    const requestedCommandDigest = createHash('sha256').update(canonicalJson(requestedCommand)).digest('hex');
    let appliedOperationId: string | null = null;
    let appliedNoteId: string | null = null;
    if (requestState === 'applied') {
      const operationId = context.id('operation', `servicing-${index}`);
      appliedOperationId = operationId;
      receiptId = context.id('receipt', `servicing-${index}`);
      const noteId = context.id('member-note', `servicing-${index}`);
      appliedNoteId = noteId;
      const result = { noteId, memberId };
      insert('operations', { id: operationId, actor_id: actor, operation_kind: 'member.note.add', business_reference: context.businessNumber('SN', index + 1),
        idempotency_key: `servicing-note-${index}`, command_digest: requestedCommandDigest, status: 'committed', occurred_at: daysBefore(context.asOf, 7) });
      insert('operation_receipts', { id: receiptId, operation_id: operationId, receipt_number: context.businessNumber('SR', index + 1),
        result_digest: createHash('sha256').update(canonicalJson(result)).digest('hex'), committed_at: daysBefore(context.asOf, 7), result_json: canonicalJson(result) });
      insert('member_notes', { id: noteId, member_id: memberId, actor_id: actor,
        visibility: 'general', text: noteText, created_at: daysBefore(context.asOf, 7) });
    }
    const review = requestState === 'approved' || requestState === 'applied'
      ? { decision: 'approve', reason: 'Synthetic independent review approved exact command terms.', checkerActorId: checker,
          reviewedAt: daysBefore(context.asOf, 8), requestedCommandDigest }
      : requestState === 'rejected'
        ? { decision: 'reject', reason: 'Synthetic independent review rejected the request.', checkerActorId: checker,
            reviewedAt: daysBefore(context.asOf, 8), requestedCommandDigest }
        : undefined;
    insert('maintenance_requests', { id: requestId, request_number: context.businessNumber('MR', index + 1), member_id: memberId,
      account_id: accountId, category: requestState === 'applied' ? 'servicing-note' : 'contact-review',
      reason: requestState === 'draft' && index % 2 === 0 ? null : 'customer-request', subject: `Review contact evidence for ${memberNumber}`,
      draft_json: canonicalJson({ requestedCommand, note: requestState === 'applied' ? noteText : '', evidenceDocumentVersionIds: [noticeId],
        missingFields: requestState === 'draft' && index % 2 === 0 ? ['reason', 'evidence'] : [], ...(review === undefined ? {} : { review }) }),
      state: requestState, created_at: daysBefore(context.asOf, 10), updated_at: daysBefore(context.asOf, 7), applied_receipt_id: receiptId });
    const eventSequence = 600_000 + index * 10;
    insert('business_events', { id: context.id('business-event', `maintenance-maker-${index}`), actor_id: actor, operation_id: null,
      sequence: eventSequence, occurred_at: daysBefore(context.asOf, 10), kind: 'maintenance.draft.save', resource_kind: 'maintenance-request',
      resource_id: requestId, summary: `Maintenance draft ${context.businessNumber('MR', index + 1)} saved.` });
    if (['submitted', 'approved', 'applied', 'rejected'].includes(requestState)) insert('business_events', {
      id: context.id('business-event', `maintenance-submit-${index}`), actor_id: actor, operation_id: null, sequence: eventSequence + 1,
      occurred_at: daysBefore(context.asOf, 9), kind: 'maintenance.request.submit', resource_kind: 'maintenance-request', resource_id: requestId,
      summary: `Maintenance request ${context.businessNumber('MR', index + 1)} submitted.` });
    if (review !== undefined) insert('business_events', { id: context.id('business-event', `maintenance-review-${index}`), actor_id: checker,
      operation_id: null, sequence: eventSequence + 2, occurred_at: review.reviewedAt, kind: 'maintenance.request.review', resource_kind: 'maintenance-request',
      resource_id: requestId, summary: `Checker ${review.decision}: ${review.reason}` });
    if (appliedOperationId !== null && appliedNoteId !== null) {
      insert('business_events', { id: context.id('business-event', `servicing-note-${index}`), actor_id: actor, operation_id: appliedOperationId,
        sequence: eventSequence + 3, occurred_at: daysBefore(context.asOf, 7), kind: 'member.note.add', resource_kind: 'member-note', resource_id: appliedNoteId,
        summary: `General note added to ${memberNumber}.` });
      insert('business_events', { id: context.id('business-event', `servicing-member-${index}`), actor_id: actor, operation_id: appliedOperationId,
        sequence: eventSequence + 4, occurred_at: daysBefore(context.asOf, 7), kind: 'member.note.add', resource_kind: 'member', resource_id: memberId,
        summary: `Note ${appliedNoteId} recorded.` });
      insert('business_events', { id: context.id('business-event', `maintenance-process-${index}`), actor_id: checker, operation_id: null,
        sequence: eventSequence + 5, occurred_at: daysBefore(context.asOf, 7), kind: 'maintenance.request.process', resource_kind: 'maintenance-request',
        resource_id: requestId, summary: `Applied business receipt ${receiptId ?? ''}.` });
    }
    const caseId = context.id('case', index);
    caseIds.push(caseId);
    const caseState = caseStates[index % caseStates.length] ?? 'open';
    const queue = refs.queueIds[index % refs.queueIds.length];
    if (queue === undefined) throw new Error('Missing servicing queue.');
    insert('cases', { id: caseId, case_number: context.businessNumber('CS', index + 1), member_id: memberId, account_id: accountId,
      queue_id: queue, assigned_actor_id: actor, state: caseState, priority: index % 7 === 0 ? 'high' : 'normal',
      category: 'contact-evidence', summary: `Resolve address evidence for ${memberNumber}`, opened_at: daysBefore(context.asOf, 14),
      due_at: daysBefore(context.asOf, index % 3 === 0 ? 2 : -7), version: caseState === 'reopened' ? 3 : 1 });
    const history = caseState === 'reopened' ? ['open', 'resolved', 'closed', 'reopened'] : caseState === 'closed' ? ['open', 'resolved', 'closed'] : caseState === 'open' ? ['open'] : ['open', caseState];
    history.forEach((state, sequence) => insert('case_events', { id: context.id('case-event', `${index}-${sequence}`), case_id: caseId,
      sequence: sequence + 1, state, occurred_at: daysBefore(context.asOf, 14 - sequence * 2), actor_id: actor,
      detail: state === 'pending-customer' ? 'Waiting for requested evidence; SLA pause begins under servicing calendar v1.' : state === 'reopened' ? 'New address evidence received after prior resolution.' : `Case ${state}; prior history preserved.` }));
    insert('case_notes', { id: context.id('case-note', index), case_id: caseId, actor_id: actor, visibility: index % 3 === 0 ? 'restricted' : 'general',
      text: `Evidence is scoped to ${memberNumber}. Review notice ${noticeId} and request ${requestId}.`, created_at: daysBefore(context.asOf, 7) });
    insert('request_attachments', { request_id: requestId, document_version_id: evidenceId, purpose: 'contact-evidence' });
    insert('case_documents', { case_id: caseId, document_version_id: evidenceId, purpose: 'address-review', visibility: 'restricted' });
    if (evidenceId !== noticeId) insert('case_documents', { case_id: caseId, document_version_id: noticeId,
      purpose: 'customer-information-request', visibility: 'general' });
    insert('case_documents', { case_id: caseId, document_version_id: disclosureId, purpose: 'consent-scope', visibility: 'general' });
    insert('document_access_events', { id: context.id('document-access', index), document_version_id: evidenceId,
      actor_id: actor, action: 'view', occurred_at: daysBefore(context.asOf, 7), purpose: 'servicing-evidence-review' });
    const ended = caseState === 'resolved' || caseState === 'closed';
    insert('sla_intervals', { id: context.id('sla-interval', `${index}-0`), case_id: caseId, state: ended ? 'completed' : 'running',
      starts_at: daysBefore(context.asOf, 14), ends_at: ended || caseState === 'pending-customer' ? daysBefore(context.asOf, 12) : null,
      reason: ended ? 'Resolution recorded with evidence.' : null });
    if (caseState === 'pending-customer') insert('sla_intervals', { id: context.id('sla-interval', `${index}-1`), case_id: caseId,
      state: 'paused', starts_at: daysBefore(context.asOf, 12), ends_at: null, reason: 'Awaiting customer evidence under calendar policy.' });
    if (index % 4 === 0) insert('retention_holds', { id: context.id('retention-hold', index), document_id: context.id('document', `notice-${index}`),
      case_id: caseId, reason: 'Preserve evidence during servicing review.', state: index % 12 === 0 ? 'active' : index % 12 === 4 ? 'released' : 'expired',
      placed_at: daysBefore(context.asOf, 10), review_at: daysBefore(context.asOf, index % 12 === 8 ? 1 : -30),
      released_at: index % 12 === 4 ? daysBefore(context.asOf, 2) : null });
    if (index < 8) {
      const redacted = await renderDocument({ ...base, title: 'Scoped servicing evidence', documentType: 'redacted-evidence',
        displayName: 'evidence-redacted.pdf', asOf: daysBefore(context.asOf, 6), sections: [{ heading: 'Approved disclosure',
          lines: [`Member reference: ${memberNumber}`, 'Evidence received for address review.',
            'Street address and contact details omitted under scoped-disclosure policy.', `Source version: ${evidenceId}`] }] });
      const redactedId = store(redacted, partyId, accountId, 'redacted-evidence', `redacted-${index}`, daysBefore(context.asOf, 6), { status: 'redacted' });
      insert('document_derivations', { id: context.id('document-derivation', index), source_version_id: evidenceId,
        derivative_version_id: redactedId, purpose: 'redaction', policy_version_id: null });
      insert('case_documents', { case_id: caseId, document_version_id: redactedId, purpose: 'approved-disclosure', visibility: 'general' });
    }
    insert('case_dependencies', { id: context.id('case-dependency', index), case_id: caseId, kind: 'document-version', reference_id: evidenceId,
      state: caseState === 'resolved' || caseState === 'closed' ? 'satisfied' : 'open', due_at: daysBefore(context.asOf, -7) });
  }
  for (const [index, selectedActor] of actors.entries()) {
    for (const visibility of ['private', 'shared'] as const) insert('saved_searches', { id: context.id('saved-search', `${index}-${visibility}`), actor_id: selectedActor,
      name: `${visibility === 'private' ? 'My' : 'Team'} pending servicing cases`, visibility,
      definition_json: JSON.stringify({ entity: 'cases', filters: { states: ['pending-customer', 'pending-internal'] }, sort: [{ field: 'due_at', direction: 'asc' }],
        columns: ['case_number', 'member_number', 'state', 'due_at'], maxResults: 200 }), created_at: daysBefore(context.asOf, 30) });
  }
  const statementAccounts = db.prepare(`SELECT a.id,a.account_number,a.currency,m.member_number,p.display_name,m.party_id,c.exponent
    FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
    JOIN currencies c ON c.code=a.currency WHERE a.dataset_id=? ORDER BY a.account_number LIMIT ?`).all(dataset, context.scale === 'small' ? 12 : 48);
  for (const [accountIndex, account] of statementAccounts.entries()) {
    const accountId = string(account, 'id');
    const entries = db.prepare(`SELECT j.reference,j.posted_at,j.description,
      CASE l.normal_side WHEN 'credit' THEN jl.credit_minor_units-jl.debit_minor_units ELSE jl.debit_minor_units-jl.credit_minor_units END AS amount
      FROM ledger_accounts l JOIN journal_lines jl ON jl.dataset_id=l.dataset_id AND jl.ledger_account_id=l.id
      JOIN journals j ON j.dataset_id=jl.dataset_id AND j.id=jl.journal_id
      WHERE l.dataset_id=? AND l.customer_account_id=? ORDER BY j.posted_at,j.reference,jl.line_number`).all(dataset, accountId);
    const periods = [...new Set(entries.map(entry => string(entry, 'posted_at').slice(0, 7)))].filter(period => period < context.asOf.slice(0, 7));
    const chosen = accountIndex < 2 ? periods.slice(-18) : periods.slice(-2);
    for (const period of chosen) {
      const periodStart = `${period}-01`;
      const periodEnd = new Date(Date.UTC(Number(period.slice(0, 4)), Number(period.slice(5, 7)), 1)).toISOString().slice(0, 10);
      const opening = entries.filter(entry => string(entry, 'posted_at').slice(0, 10) < periodStart).reduce((sum, entry) => sum + number(entry, 'amount'), 0);
      const periodEntries = entries.filter(entry => {
        const date = string(entry, 'posted_at').slice(0, 10);
        return date >= periodStart && date < periodEnd;
      }).map(entry => ({ reference: string(entry, 'reference'), date: string(entry, 'posted_at').slice(0, 10), description: string(entry, 'description'), amountMinor: number(entry, 'amount') }));
      const statement = await renderStatementPdf({ institutionName: context.institution.displayName, ownerName: string(account, 'display_name'),
        memberNumber: string(account, 'member_number'), accountNumber: string(account, 'account_number'), currency: string(account, 'currency'), currencyExponent: number(account, 'exponent'),
        asOf: `${periodEnd}T12:00:00.000Z`, periodStart, periodEndExclusive: periodEnd, openingBalanceMinor: opening, entries: periodEntries });
      store(statement, string(account, 'party_id'), accountId, 'account-statement', `statement-${accountIndex}-${period}`, `${periodEnd}T12:00:00.000Z`, { periodStart, periodEnd });
      if (accountIndex === 0 && period === chosen.at(-1)) store(renderCsv({ displayName: 'statement.csv', columns: ['date', 'reference', 'description', 'amount_minor_units', 'currency'],
        rows: periodEntries.map(entry => [entry.date, entry.reference, entry.description, entry.amountMinor, string(account, 'currency')]) }),
      string(account, 'party_id'), accountId, 'statement-csv', `statement-csv-${accountIndex}-${period}`, `${periodEnd}T12:00:00.000Z`, { periodStart, periodEnd });
    }
  }
  const disputes = db.prepare(`SELECT d.id,d.case_number,d.journal_id,d.state,d.claimed_amount_minor_units,d.currency,d.deadline,
    a.id AS account_id,a.account_number,m.member_number,m.party_id,p.display_name,cu.exponent
    FROM disputes d JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id
    JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
    JOIN currencies cu ON cu.code=d.currency WHERE d.dataset_id=? ORDER BY d.id LIMIT 24`).all(dataset);
  for (const [index, dispute] of disputes.entries()) {
    const receivedAt = daysBefore(context.asOf, 3);
    const evidence = await renderDocument({ title: 'Transaction dispute evidence', institutionName: context.institution.displayName,
      ownerName: string(dispute, 'display_name'), memberNumber: string(dispute, 'member_number'), accountNumber: string(dispute, 'account_number'),
      asOf: receivedAt, documentType: 'dispute-evidence', version: 1, displayName: 'dispute-evidence.pdf', sections: [{ heading: 'Customer allegation and supporting records',
        lines: [`Dispute reference: ${string(dispute, 'case_number')}`, `Transaction reference: ${string(dispute, 'journal_id')}`,
          `Claimed amount: ${formatMinorUnits(number(dispute, 'claimed_amount_minor_units'), string(dispute, 'currency'), number(dispute, 'exponent'))}`,
          `Submission deadline: ${string(dispute, 'deadline')}`, 'The customer disputes the identified transaction. This allegation is not a final decision.',
          'Receipt and servicing correspondence are held for local review. No evidence is sent externally.'] }] });
    const versionId = store(evidence, string(dispute, 'party_id'), string(dispute, 'account_id'), 'dispute-evidence', `dispute-evidence-${index}`, receivedAt);
    insert('dispute_evidence', { id: context.id('dispute-evidence', `document-${index}`), dispute_id: string(dispute, 'id'), document_version_id: versionId,
      evidence_kind: 'customer-statement', digest: evidence.digest, status: index % 3 === 0 ? 'received' : index % 3 === 1 ? 'accepted' : 'rejected', received_at: receivedAt });
    if (index % 2 === 0) insert('dispute_evidence', { id: context.id('dispute-evidence', `duplicate-document-${index}`), dispute_id: string(dispute, 'id'),
      document_version_id: versionId, evidence_kind: 'customer-statement', digest: evidence.digest, status: 'duplicate', received_at: daysBefore(context.asOf, 2) });
  }
  const loanEvidence = db.prepare(`SELECT l.id,l.state,l.currency,cu.exponent,a.id AS account_id,a.account_number,m.member_number,m.party_id,p.display_name,
    q.id AS quote_id,q.as_of,q.expires_at,q.total_minor_units,q.lines_json,
    c.id AS closure_id,c.receipt_id,c.closed_at
    FROM loans l JOIN currencies cu ON cu.code=l.currency JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id
    JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
    LEFT JOIN payoff_quotes q ON q.dataset_id=l.dataset_id AND q.loan_id=l.id
    LEFT JOIN loan_closures c ON c.dataset_id=l.dataset_id AND c.loan_id=l.id
    WHERE l.dataset_id=? ORDER BY l.id,q.as_of`).all(dataset);
  let closedLoanOrdinal = 0;
  const closureDocuments = new Set<string>();
  for (const [index, loan] of loanEvidence.entries()) {
    const quoteId = loan.quote_id;
    if (typeof quoteId === 'string') {
      const values: unknown = JSON.parse(string(loan, 'lines_json'));
      if (values === null || typeof values !== 'object' || Array.isArray(values)) throw new Error('Invalid payoff quote components.');
      const quoteLines = Object.entries(values).map(([name, amount]: [string, unknown]) => {
        if (typeof amount !== 'number') throw new Error('Invalid payoff component amount.');
        return `${name}: ${formatMinorUnits(amount, string(loan, 'currency'), number(loan, 'exponent'))}`;
      });
      const quote = await renderDocument({ title: 'Dated loan payoff quote', institutionName: context.institution.displayName,
        ownerName: string(loan, 'display_name'), memberNumber: string(loan, 'member_number'), accountNumber: string(loan, 'account_number'),
        asOf: string(loan, 'as_of'), documentType: 'loan-payoff-quote', version: 1, displayName: 'payoff-quote.pdf',
        sections: [{ heading: 'Quoted obligations', lines: [`Loan reference: ${string(loan, 'id')}`, `Quote reference: ${quoteId}`,
          `Quote expires: ${string(loan, 'expires_at')}`, `Amount due: ${formatMinorUnits(number(loan, 'total_minor_units'), string(loan, 'currency'), number(loan, 'exponent'))}`,
          ...quoteLines, 'This dated quote is not evidence of payment or loan closure.'] }] });
      store(quote, string(loan, 'party_id'), string(loan, 'account_id'), 'loan-payoff-quote', `loan-quote-${index}`, string(loan, 'as_of'));
    }
    if (loan.state === 'closed' && typeof loan.closure_id === 'string' && !closureDocuments.has(loan.closure_id)) {
      const residual = db.prepare('SELECT COALESCE(SUM(balance_minor_units),0) AS total FROM loan_components WHERE dataset_id=? AND loan_id=?').get(dataset, string(loan, 'id'));
      const obligations = db.prepare("SELECT COUNT(*) AS total FROM loan_obligations WHERE dataset_id=? AND loan_id=? AND state='open'").get(dataset, string(loan, 'id'));
      if (residual === undefined || obligations === undefined || number(residual, 'total') !== 0 || number(obligations, 'total') !== 0) {
        throw new Error('Loan closure document cannot be issued with residual debt or open obligations.');
      }
      closureDocuments.add(loan.closure_id);
      closedLoanOrdinal += 1;
      if (closedLoanOrdinal % 2 === 0) continue;
      const closure = await renderDocument({ title: 'Loan closure confirmation', institutionName: context.institution.displayName,
        ownerName: string(loan, 'display_name'), memberNumber: string(loan, 'member_number'), accountNumber: string(loan, 'account_number'),
        asOf: string(loan, 'closed_at'), documentType: 'loan-closure-confirmation', version: 1, displayName: 'closure-confirmation.pdf',
        sections: [{ heading: 'Verified local closure', lines: [`Loan reference: ${string(loan, 'id')}`, `Closure receipt: ${string(loan, 'receipt_id')}`,
          `Closed at: ${string(loan, 'closed_at')}`, 'Outstanding principal, interest, and fee obligations are satisfied.',
          'Template: closure-confirmation-v1. This confirmation does not grant collateral release authority.',
          'Issuance is complete. No delivery is asserted by this document.'] }] });
      const versionId = store(closure, string(loan, 'party_id'), string(loan, 'account_id'), 'loan-closure-confirmation', `loan-closure-${index}`, string(loan, 'closed_at'));
      db.prepare('UPDATE loan_closures SET closure_document_version_id=? WHERE dataset_id=? AND id=?').run(versionId, dataset, loan.closure_id);
    }
  }
  return { documentVersionIds, caseIds };
}
