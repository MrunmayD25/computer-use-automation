import type { DatabaseSync } from 'node:sqlite';
import type { DatasetBinding } from '../model.js';

/**
 * SQL access to an evaluator-owned database clone.
 *
 * Callbacks can prepare statements and execute SQL inside the run's transaction. They cannot
 * attach another database, change the schema after capture begins, or control the connection.
 */
export type RunSqlDatabase = Pick<DatabaseSync, 'exec' | 'prepare'>;

export type CapturedValue = string | number | null
  | Readonly<{ kind: 'integer'; decimal: string }>
  | Readonly<{ kind: 'blob'; digest: string; byteLength: number }>;
export type CapturedRow = Readonly<Record<string, CapturedValue>>;
export type SnapshotOrdering = 'canonical-json-v1' | 'sqlite-pk-v1';
export type SnapshotPrimaryKeyType = 'TEXT' | 'INTEGER' | 'REAL';
export interface RunTableSnapshot {
  readonly columns: readonly string[];
  readonly primaryKey: readonly string[];
  readonly ordering: SnapshotOrdering;
  readonly primaryKeyTypes: readonly SnapshotPrimaryKeyType[];
  readonly rowCount: number;
  readonly blobBytes: number;
  readonly byteLength: number;
  readonly digest: string;
}
export interface RunSnapshot {
  readonly label: string;
  readonly schemaDigest: string;
  readonly sequence: number;
  readonly tables: Readonly<Record<string, RunTableSnapshot>>;
  readonly digest: string;
}
export interface WriteContext {
  readonly kind: 'automation' | 'human' | 'peer' | 'system';
  readonly actorId?: string;
  readonly reference: string;
}
export interface RowChange {
  readonly sequence: number;
  readonly transactionId: string;
  readonly table: string;
  readonly operation: 'insert' | 'update' | 'delete';
  readonly key: CapturedRow;
  readonly before: CapturedRow | null;
  readonly after: CapturedRow | null;
}
export interface CapturedTransaction {
  readonly id: string;
  readonly context: WriteContext;
  readonly changes: readonly RowChange[];
}
export interface RunDescriptor {
  readonly runId: string;
  readonly contractDigest: string;
  readonly databasePath: string;
  readonly evidencePath: string;
  readonly bindings: readonly DatasetBinding[];
  readonly schemaDigest: string;
}
export interface RunEvidence {
  readonly version: 2;
  readonly baseline: Readonly<{ file: 'baseline.sqlite'; byteLength: number; digest: string }>;
  readonly limits: RunLimits;
  readonly descriptor: RunDescriptor;
  readonly before: RunSnapshot;
  readonly after: RunSnapshot;
  readonly transactions: readonly CapturedTransaction[];
  readonly captureComplete: boolean;
  readonly diagnostics: readonly string[];
  readonly digest: string;
}
export interface RunLimits {
  readonly maxRows: number;
  readonly maxChanges: number;
  readonly maxBlobBytes: number;
  readonly maxSnapshotBytes: number;
  readonly busyTimeoutMs: number;
}
export interface CreateRunOptions {
  readonly root: string;
  readonly sourcePath: string;
  readonly bindings: readonly DatasetBinding[];
  readonly contractDigest: string;
  readonly limits?: Partial<RunLimits>;
}
/**
 * An isolated capture lifecycle owned by the evaluator.
 *
 * The evaluator owns the source and run directory. Callback isolation does not authenticate or
 * defend against a privileged process that independently rewrites those filesystem artifacts.
 */
export interface VerificationRun {
  descriptor(): RunDescriptor;
  prepare<T>(callback: (database: RunSqlDatabase) => T): T;
  begin(): RunSnapshot;
  write<T>(context: WriteContext, callback: (database: RunSqlDatabase) => T): T;
  read<T>(callback: (database: RunSqlDatabase) => T): T;
  snapshot(label: string): RunSnapshot;
  finish(): RunEvidence;
  dispose(options: { reportPath: string }): void;
  close(): void;
}
