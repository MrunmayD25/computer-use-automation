import { existsSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';

import { SCHEMA_VERSION } from '../schema.js';
import type { RunSqlDatabase, VerificationRun, WriteContext } from '../verification/run-types.js';

/** The SQL surface services use. It matches the guarded handle a verification run provides. */
export type SqlDatabase = RunSqlDatabase;

/** Trusted identity of the principal on whose behalf a transaction commits. */
export interface WritePrincipal extends WriteContext {
  readonly actorId: string;
}

/**
 * Transactional access to the shared financial database.
 *
 * `read` runs one consistent snapshot. `write` commits one atomic transaction and rolls back when the
 * callback throws. Callbacks are synchronous; asynchronous work such as PDF rendering happens outside.
 */
export interface FinancialStore {
  read<T>(callback: (database: SqlDatabase) => T): T;
  write<T>(principal: WritePrincipal, callback: (database: SqlDatabase) => T): T;
  /** Releases resources this store owns. A run-backed store never disposes of the evaluator's run. */
  close(): void;
}

export interface OpenFinancialStoreOptions {
  path: string;
  busyTimeoutMs?: number;
}

/** Opens an existing seeded database in ordinary shared mode. It never creates a schema or seeds data. */
export function openFinancialStore(options: OpenFinancialStoreOptions): FinancialStore {
  if (!existsSync(options.path)) throw new Error(`Financial database ${options.path} does not exist. Seed it with the financial package before starting an application.`);
  const timeout = options.busyTimeoutMs ?? 5_000;
  if (!Number.isSafeInteger(timeout) || timeout < 0 || timeout > 60_000) throw new Error('Busy timeout must be an integer from 0 through 60000 milliseconds.');
  const database = new DatabaseSync(options.path);
  try {
    database.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=${timeout}`);
    const version = database.prepare('PRAGMA user_version').get()?.user_version;
    if (version !== SCHEMA_VERSION) throw new Error(`Unsupported financial database schema version ${String(version)}.`);
  } catch (error) {
    database.close();
    throw error;
  }
  let active = false;
  const transact = <T>(begin: string, callback: (handle: SqlDatabase) => T): T => {
    if (!database.isOpen) throw new Error('The financial store is closed.');
    if (active) throw new Error('A financial store transaction is already active.');
    active = true;
    try {
      database.exec(begin);
      const result = callback(database);
      if (result !== null && typeof result === 'object' && 'then' in result) throw new Error('Store callbacks must be synchronous.');
      database.exec('COMMIT');
      return result;
    } catch (error) {
      if (database.isTransaction) database.exec('ROLLBACK');
      throw error;
    } finally {
      active = false;
    }
  };
  return {
    read: (callback) => transact('BEGIN', callback),
    write: (principal, callback) => {
      assertPrincipal(principal);
      return transact('BEGIN IMMEDIATE', callback);
    },
    close: () => { if (database.isOpen) database.close(); },
  };
}

/**
 * Routes every read and write through an evaluator-owned verification run.
 *
 * The run owns its connection, capture, snapshots and disposal. Closing this store only detaches it.
 */
export function verificationRunStore(run: Pick<VerificationRun, 'read' | 'write'>): FinancialStore {
  let open = true;
  const assertOpen = (): void => { if (!open) throw new Error('The verification run store is detached.'); };
  return {
    read: (callback) => { assertOpen(); return run.read(callback); },
    write: (principal, callback) => {
      assertOpen();
      assertPrincipal(principal);
      return run.write({ kind: principal.kind, actorId: principal.actorId, reference: principal.reference }, callback);
    },
    close: () => { open = false; },
  };
}

function assertPrincipal(principal: WritePrincipal): void {
  if (!['automation', 'human', 'peer', 'system'].includes(principal.kind) || principal.actorId.length === 0 || principal.reference.trim().length === 0) {
    throw new Error('A write requires a trusted principal kind, actor and reference.');
  }
}
