import { createHash } from 'node:crypto';

import { facilityLimitSql } from '../facility-sql.js';
import { all, canonicalJson, int, loadReceipt, localDate, nextNumber, one, optionalStr, reject, run, str, zonedInstant, type Row } from './core.js';
import type { Preparation } from './commands.js';
import type { FinanceCommand } from './finance-types.js';
import { documentContent } from './queries.js';
import {
  approvalPrepared, cardEvent, enforceSafeLedgerPosting, generalLedger, insertJournal, ledgerForAccount, loadAccount, loadMember, newId, noFinanceReview, prepared,
  isEvidenceValidAt, normalizeInstant, requireAccountVersion, requireApproval, requireCredit, requireDate, requireFingerprint, requireInstant, requireMemberVersion, requireMoney, requireText, rowFingerprint,
  type FinanceEnvironment,
} from './finance-support.js';
import type { Rejection } from './types.js';

type FinanceOf<K extends FinanceCommand['kind']> = Extract<FinanceCommand, { kind: K }>;
function validation(problems: readonly (Rejection | null)[]): Rejection | null { return problems.find((problem) => problem !== null) ?? null; }

function cardRow(env: FinanceEnvironment, cardId: string): Row | undefined {
  const card = one(env.database, `SELECT c.id,c.account_id,c.last_four,c.expiry_month,c.expiry_year,c.status,a.member_id,a.currency,a.status AS account_status
    FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? AND c.id=?`, env.datasetId, cardId);
  if (card === undefined) return undefined;
  const limits = all(env.database, 'SELECT id,kind,amount_minor_units,currency,effective_at,expires_at FROM card_limits WHERE dataset_id=? AND card_id=? ORDER BY effective_at,id', env.datasetId, cardId);
  const locks = all(env.database, 'SELECT id,kind,authority,state,placed_at,released_at FROM card_locks WHERE dataset_id=? AND card_id=? ORDER BY placed_at,id', env.datasetId, cardId);
  const replacementOrders = all(env.database, 'SELECT id,address_id,state,requested_at FROM card_replacement_orders WHERE dataset_id=? AND card_id=? ORDER BY requested_at,id', env.datasetId, cardId);
  return { ...card, limits: canonicalJson(limits), locks: canonicalJson(locks), replacement_orders: canonicalJson(replacementOrders) };
}
const CARD_COLUMNS = ['id','account_id','last_four','expiry_month','expiry_year','status','member_id','currency','account_status','limits','locks','replacement_orders'] as const;

function prepareCardReplace(env: FinanceEnvironment, command: FinanceOf<'card.replace'>): Preparation {
  const card = cardRow(env, command.cardId);
  if (card === undefined) return reject('not_found', 'The card does not exist.');
  const stale = requireFingerprint(card, CARD_COLUMNS, command.expectedFingerprint, 'card');
  if (stale !== null) return stale;
  const invalid = requireText(command.reason, 'reason', 'Replacement reason');
  if (invalid !== null) return invalid;
  const openOrders = all(env.database, "SELECT id,address_id,state FROM card_replacement_orders WHERE dataset_id=? AND card_id=? AND state NOT IN ('cancelled','delivered') ORDER BY requested_at,id", env.datasetId, command.cardId);
  if (openOrders.length > 1) return reject('open_dependencies', 'Several replacement orders are active; resolve them before reissuing.');
  const pendingOrder = openOrders[0];
  const initialReplacement = ['active','temporarily-locked'].includes(str(card, 'status')) && pendingOrder === undefined;
  const addressReissue = str(card, 'status') === 'replaced' && pendingOrder !== undefined;
  if (str(card, 'account_status') !== 'open' || !initialReplacement && !addressReissue) return reject('ineligible', 'The card or replacement order is not eligible for replacement.');
  const identity = one(env.database, `SELECT e.id,e.party_id,e.status,e.issued_at,e.expires_at,m.party_id AS member_party_id FROM identity_evidence e
    JOIN members m ON m.dataset_id=e.dataset_id AND m.party_id=e.party_id WHERE e.dataset_id=? AND e.id=? AND m.id=?`, env.datasetId, command.identityEvidenceId, str(card, 'member_id'));
  if (identity === undefined || str(identity, 'party_id') !== str(identity, 'member_party_id') || str(identity, 'status') !== 'verified'
    || !isEvidenceValidAt(str(identity, 'issued_at'), optionalStr(identity, 'expires_at'), env.now, env.timeZone)) {
    return reject('ineligible', 'Card replacement requires current verified identity evidence for the card member.', { field: 'identityEvidenceId' });
  }
  const shippingDestination = one(env.database, `SELECT d.id,d.evidence_version_id AS destination_evidence_version_id,pa.address_id,pa.evidence_status,pa.evidence_version_id,pa.valid_from,pa.valid_to,m.party_id
    FROM address_destinations d JOIN party_addresses pa ON pa.dataset_id=d.dataset_id AND pa.id=d.party_address_id
    JOIN members m ON m.dataset_id=pa.dataset_id AND m.party_id=pa.party_id
    WHERE d.dataset_id=? AND d.id=? AND d.context_kind='card-shipping' AND d.card_id=? AND m.id=?
      AND d.effective_at<=? AND (d.ends_at IS NULL OR d.ends_at>?) AND pa.valid_from<=? AND (pa.valid_to IS NULL OR pa.valid_to>?)`,
  env.datasetId, command.deliveryDestinationId, command.cardId, str(card, 'member_id'), env.now, env.now, env.now, env.now);
  const effectiveShippingDestination = one(env.database, `SELECT id FROM address_destinations
    WHERE dataset_id=? AND context_kind='card-shipping' AND card_id=? AND effective_at<=? AND (ends_at IS NULL OR ends_at>?)
    ORDER BY effective_at DESC,id DESC LIMIT 1`, env.datasetId, command.cardId, env.now, env.now);
  if (shippingDestination === undefined || effectiveShippingDestination === undefined || str(effectiveShippingDestination, 'id') !== command.deliveryDestinationId) {
    return reject('ineligible', 'The approved card-shipping instruction is not the current effective destination.', { field: 'deliveryDestinationId' });
  }
  if (str(shippingDestination, 'address_id') !== command.deliveryAddressId) {
    return reject('ownership_mismatch', 'The replacement address differs from the effective card-shipping instruction.', { field: 'deliveryAddressId' });
  }
  if (str(shippingDestination, 'evidence_status') !== 'verified'
    || optionalStr(shippingDestination, 'evidence_version_id') !== str(shippingDestination, 'destination_evidence_version_id')) {
    return reject('ineligible', 'The card-shipping instruction is no longer backed by verified address evidence.', { field: 'deliveryAddressId' });
  }
  let addressEvidence;
  try {
    addressEvidence = documentContent(env.database, env.datasetId, str(shippingDestination, 'destination_evidence_version_id'), { institutionId: env.institutionId, actorId: env.actorId, now: env.now });
  } catch {
    return reject('ineligible', 'The card-shipping evidence bytes are missing or fail their integrity check.', { field: 'deliveryDestinationId' });
  }
  if (addressEvidence === undefined || addressEvidence.ownerPartyId !== str(shippingDestination, 'party_id') || !['current','signed'].includes(addressEvidence.status)) {
    return reject('ineligible', 'The card-shipping instruction is no longer backed by current owner-scoped evidence.', { field: 'deliveryDestinationId' });
  }
  if (addressReissue && str(pendingOrder, 'address_id') === command.deliveryAddressId) return { kind: 'unchanged', message: 'The pending replacement order already uses this verified address.' };
  const orderId = newId('card-replacement');
  return prepared({ businessReference: command.cardId, result: { cardId: command.cardId, replacementOrderId: orderId, state: 'pending', reissued: addressReissue, cancelledOrderId: addressReissue ? str(pendingOrder, 'id') : null }, review: noFinanceReview([addressReissue ? `Cancels the pending order and reissues it to verified address ${command.deliveryAddressId}; the disposed card remains replaced.` : `Permanently disposes card ending ${str(card, 'last_four')} and creates a linked pending order to the verified address.`]), apply(apply) {
    if (addressReissue) run(apply.database, "UPDATE card_replacement_orders SET state='cancelled' WHERE dataset_id=? AND id=?", apply.datasetId, str(pendingOrder, 'id'));
    else {
      run(apply.database, "UPDATE cards SET status='replaced' WHERE dataset_id=? AND id=?", apply.datasetId, command.cardId);
      run(apply.database, "INSERT INTO card_locks (dataset_id,id,card_id,kind,authority,state,placed_at,released_at) VALUES (?,?,?,'permanent','replacement','active',?,NULL)", apply.datasetId, newId('card-lock'), command.cardId, apply.now);
    }
    run(apply.database, "INSERT INTO card_replacement_orders (dataset_id,id,card_id,address_id,state,requested_at) VALUES (?,?,?,?,'pending',?)", apply.datasetId, orderId, command.cardId, command.deliveryAddressId, apply.now);
    cardEvent(apply, command.cardId, 'replaced', addressReissue ? `Replacement order ${str(pendingOrder, 'id')} cancelled and reissued: ${command.reason.trim()}` : command.reason.trim());
    apply.event({ kind: 'card', id: command.cardId }, addressReissue
      ? `Pending replacement order ${str(pendingOrder, 'id')} cancelled and reissued as ${orderId} to verified address ${command.deliveryAddressId}.`
      : `Card ending ${str(card, 'last_four')} replaced and order ${orderId} linked to verified address ${command.deliveryAddressId}.`);
  } });
}

function prepareCardLock(env: FinanceEnvironment, command: FinanceOf<'card.lock.update'>): Preparation {
  const card = cardRow(env, command.cardId);
  if (card === undefined) return reject('not_found', 'The card does not exist.');
  const stale = requireFingerprint(card, CARD_COLUMNS, command.expectedFingerprint, 'card');
  if (stale !== null) return stale;
  const permanent = one(env.database, "SELECT id FROM card_locks WHERE dataset_id=? AND card_id=? AND kind IN ('permanent','fraud') AND state='active'", env.datasetId, command.cardId);
  const temporary = one(env.database, "SELECT id,authority FROM card_locks WHERE dataset_id=? AND card_id=? AND kind='temporary' AND state='active' ORDER BY placed_at DESC LIMIT 1", env.datasetId, command.cardId);
  if (!['active','temporarily-locked'].includes(str(card, 'status'))) return reject('ineligible', 'Only an active card may use the temporary lock control.');
  if (permanent !== undefined) return reject('ineligible', 'A temporary lock control cannot override a permanent or fraud restriction.');
  if ((str(card, 'status') === 'temporarily-locked') !== (temporary !== undefined)) return reject('ineligible', 'The card temporary-lock status is inconsistent with its active lock evidence.');
  if ((command.requestedState === 'locked') === (temporary !== undefined)) return { kind: 'unchanged', message: `The temporary card lock is already ${command.requestedState === 'locked' ? 'active' : 'released'}.` };
  const invalid = requireText(command.authority, 'authority', 'Lock authority', 120);
  if (invalid !== null) return invalid;
  return prepared({ businessReference: command.cardId, result: { cardId: command.cardId, state: command.requestedState }, review: noFinanceReview([`Changes only the convenience temporary lock; fraud and permanent controls remain independent.`]), apply(apply) {
    if (command.requestedState === 'locked') {
      run(apply.database, "INSERT INTO card_locks (dataset_id,id,card_id,kind,authority,state,placed_at,released_at) VALUES (?,?,?,'temporary',?,'active',?,NULL)", apply.datasetId, newId('card-lock'), command.cardId, command.authority.trim(), apply.now);
      run(apply.database, "UPDATE cards SET status='temporarily-locked' WHERE dataset_id=? AND id=?", apply.datasetId, command.cardId);
    } else {
      run(apply.database, "UPDATE card_locks SET state='released',released_at=? WHERE dataset_id=? AND id=?", apply.now, apply.datasetId, str(temporary, 'id'));
      run(apply.database, "UPDATE cards SET status='active' WHERE dataset_id=? AND id=?", apply.datasetId, command.cardId);
    }
    cardEvent(apply, command.cardId, command.requestedState === 'locked' ? 'temporarily-locked' : 'active', command.authority.trim());
    apply.event({ kind: 'card', id: command.cardId }, `Temporary lock for card ending ${str(card, 'last_four')} ${command.requestedState === 'locked' ? 'applied' : 'released'}; permanent controls unchanged.`);
  } });
}

function prepareCardLimit(env: FinanceEnvironment, command: FinanceOf<'card.limit.update'>): Preparation {
  const card = cardRow(env, command.cardId);
  if (card === undefined) return reject('not_found', 'The card does not exist.');
  const stale = requireFingerprint(card, CARD_COLUMNS, command.expectedFingerprint, 'card');
  if (stale !== null) return stale;
  const invalid = validation([requireMoney(env, command.amount, 'amount', true), requireInstant(command.effectiveAt, 'effectiveAt'), command.expiresAt === null ? null : requireInstant(command.expiresAt, 'expiresAt')]);
  if (invalid !== null) return invalid;
  const effectiveAt = normalizeInstant(command.effectiveAt);
  const expiresAt = command.expiresAt === null ? null : normalizeInstant(command.expiresAt);
  if (effectiveAt === null || command.expiresAt !== null && expiresAt === null) return reject('validation', 'Card limit instants must use valid ISO-8601 values with explicit offsets.');
  if (!['active','temporarily-locked'].includes(str(card, 'status')) || command.amount.currency !== str(card, 'currency')) return reject('ineligible', 'The card is unavailable or the currency differs from its account.');
  if (expiresAt !== null && expiresAt <= effectiveAt) return reject('validation', 'Limit expiry must follow its effective instant.');
  const facility = one(env.database, `SELECT ${facilityLimitSql('?')} AS limit_minor_units FROM facilities f
    WHERE f.dataset_id=? AND f.account_id=? AND f.status='active' ORDER BY limit_minor_units DESC LIMIT 1`, effectiveAt, effectiveAt, env.datasetId, str(card, 'account_id'));
  let ceiling: number | null = facility === undefined ? null : int(facility, 'limit_minor_units');
  if (ceiling === null) {
    const policies = all(env.database, 'SELECT rules_json FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id DESC', env.datasetId, effectiveAt);
    for (const policy of policies) {
      let rules: unknown;
      try { rules = JSON.parse(str(policy, 'rules_json')) as unknown; }
      catch { continue; }
      const ceilings = rules !== null && typeof rules === 'object' && 'cardLimitMaximumMinorUnitsByCurrency' in rules ? rules.cardLimitMaximumMinorUnitsByCurrency : null;
      const candidate = ceilings !== null && typeof ceilings === 'object' && command.amount.currency in ceilings
        ? (ceilings as Record<string, unknown>)[command.amount.currency] : null;
      if (Number.isSafeInteger(candidate) && Number(candidate) >= 0) {
        ceiling = Number(candidate);
        break;
      }
    }
  }
  if (ceiling === null) return reject('ineligible', 'No effective parent facility or explicit card-limit policy ceiling is available.');
  if (command.amount.minorUnits > ceiling) return reject('limit_exceeded', 'The card limit exceeds its parent facility or policy ceiling.');
  const current = one(env.database, 'SELECT id,amount_minor_units,currency,effective_at,expires_at FROM card_limits WHERE dataset_id=? AND card_id=? AND kind=? ORDER BY effective_at DESC,id DESC LIMIT 1', env.datasetId, command.cardId, command.limitKind);
  if (current !== undefined && int(current, 'amount_minor_units') === command.amount.minorUnits && str(current, 'currency') === command.amount.currency
    && str(current, 'effective_at') === effectiveAt && optionalStr(current, 'expires_at') === expiresAt) return { kind: 'unchanged', message: 'This scoped card limit already matches.' };
  if (current !== undefined && str(current, 'effective_at') >= effectiveAt) return reject('ineligible', 'A card limit at or after the requested effective instant already exists.');
  const approval = requireApproval(env, command, command.approvalId, command.amount);
  if (approval !== null) return approval;
  const limitId = newId('card-limit');
  return approvalPrepared(prepared({ businessReference: command.cardId, result: { cardId: command.cardId, limitId, kind: command.limitKind, amount: command.amount, effectiveAt, expiresAt }, review: { amount: command.amount, exponent: null, description: command.limitKind, accounts: [], consequences: ['Creates one scoped card limit and does not alter the account facility or other cards.'] }, apply(apply) {
    run(apply.database, `UPDATE card_limits SET expires_at=? WHERE dataset_id=? AND card_id=? AND kind=? AND effective_at<?
      AND (expires_at IS NULL OR expires_at>?)`, effectiveAt, apply.datasetId, command.cardId, command.limitKind, effectiveAt, effectiveAt);
    run(apply.database, 'INSERT INTO card_limits (dataset_id,id,card_id,kind,amount_minor_units,currency,effective_at,expires_at) VALUES (?,?,?,?,?,?,?,?)', apply.datasetId, limitId, command.cardId, command.limitKind, command.amount.minorUnits, command.amount.currency, effectiveAt, expiresAt);
    apply.event({ kind: 'card', id: command.cardId }, `${command.limitKind} limit for card ending ${str(card, 'last_four')} set to ${command.amount.minorUnits} ${command.amount.currency} minor units.`);
  } }), command.approvalId);
}

function disputeRow(env: FinanceEnvironment, disputeId: string): Row | undefined {
  return one(env.database, `SELECT d.id,d.case_number,d.account_id,d.journal_id,d.claimed_amount_minor_units,d.currency,d.state,d.deadline,
    COALESCE((SELECT SUM(CASE kind WHEN 'provisional' THEN amount_minor_units WHEN 'final' THEN amount_minor_units ELSE -amount_minor_units END) FROM dispute_credits c WHERE c.dataset_id=d.dataset_id AND c.dispute_id=d.id),0) AS net_credit
    FROM disputes d WHERE d.dataset_id=? AND d.id=?`, env.datasetId, disputeId);
}
const DISPUTE_COLUMNS = ['id','case_number','account_id','journal_id','claimed_amount_minor_units','currency','state','deadline','net_credit'] as const;

function memberPartyForAccount(env: FinanceEnvironment, accountId: string): string | undefined {
  return optionalStr(one(env.database, 'SELECT m.party_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id WHERE a.dataset_id=? AND a.id=?', env.datasetId, accountId), 'party_id') ?? undefined;
}

function prepareDisputeOpen(env: FinanceEnvironment, command: FinanceOf<'dispute.open'>): Preparation {
  const transaction = one(env.database, `SELECT t.id,t.card_id,t.journal_id,t.amount_minor_units,t.currency,t.state,c.account_id,a.member_id
    FROM card_transactions t JOIN cards c ON c.dataset_id=t.dataset_id AND c.id=t.card_id JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
    WHERE t.dataset_id=? AND t.id=?`, env.datasetId, command.cardTransactionId);
  if (transaction === undefined) return reject('not_found', 'The card transaction does not exist.');
  const stale = requireFingerprint(transaction, ['id','card_id','journal_id','amount_minor_units','currency','state','account_id','member_id'], command.expectedFingerprint, 'card transaction');
  if (stale !== null) return stale;
  const invalid = validation([requireMoney(env, command.assertedAmount, 'assertedAmount'), requireText(command.reason, 'reason', 'Dispute reason')]);
  if (invalid !== null) return invalid;
  if (command.evidenceIds.length === 0 || command.evidenceIds.length > 25 || new Set(command.evidenceIds).size !== command.evidenceIds.length) {
    return reject('validation', 'Submit 1 to 25 distinct evidence document versions.', { field: 'evidenceIds' });
  }
  if (str(transaction, 'state') !== 'posted' || optionalStr(transaction, 'journal_id') === null || command.assertedAmount.currency !== str(transaction, 'currency') || command.assertedAmount.minorUnits > int(transaction, 'amount_minor_units')) return reject('ineligible', 'Only a posted transaction amount may be disputed.');
  if (one(env.database, "SELECT 1 AS found FROM disputes WHERE dataset_id=? AND journal_id=? AND state NOT IN ('denied','closed')", env.datasetId, str(transaction, 'journal_id')) !== undefined) return reject('duplicate_open_case', 'An active dispute already covers this transaction.');
  const ownerParty = memberPartyForAccount(env, str(transaction, 'account_id'));
  if (ownerParty === undefined) return reject('ineligible', 'The card account has no member owner.');
  for (const versionId of command.evidenceIds) {
    let document;
    try {
      document = documentContent(env.database, env.datasetId, versionId, { institutionId: env.institutionId, actorId: env.actorId, now: env.now });
    } catch {
      return reject('ineligible', `Evidence ${versionId} bytes are missing or fail their integrity check.`, { field: 'evidenceIds' });
    }
    if (document === undefined || document.ownerPartyId !== ownerParty || document.accountId !== str(transaction, 'account_id')) {
      return reject('ownership_mismatch', `Evidence ${versionId} is absent or outside the card account owner scope.`);
    }
    if (!['current','signed'].includes(document.status)) return reject('ineligible', `Evidence ${versionId} is not current.`, { field: 'evidenceIds' });
  }
  const disputeId = newId('dispute');
  const caseId = newId('case');
  const caseNumber = nextNumber(env.database, 'disputes', 'case_number', env.datasetId, 'DP', 7);
  const serviceCaseNumber = nextNumber(env.database, 'cases', 'case_number', env.datasetId, 'DS', 7);
  const queue = one(env.database, "SELECT id FROM queues WHERE dataset_id=? AND visibility='restricted' ORDER BY id LIMIT 1", env.datasetId);
  if (queue === undefined) return reject('ineligible', 'No restricted dispute queue is configured.');
  return prepared({ businessReference: caseNumber, result: { disputeId, caseId, caseNumber, serviceCaseNumber, state: 'submitted', evidenceCount: command.evidenceIds.length }, review: { amount: command.assertedAmount, exponent: null, description: command.reason.trim(), accounts: [], consequences: ['Records an allegation and opens one linked servicing case; it makes no final fraud finding.'] }, apply(apply) {
    run(apply.database, "INSERT INTO disputes (dataset_id,id,case_number,account_id,journal_id,claimed_amount_minor_units,currency,state,deadline) VALUES (?,?,?,?,?,?,?,'submitted',?)", apply.datasetId, disputeId, caseNumber, str(transaction, 'account_id'), str(transaction, 'journal_id'), command.assertedAmount.minorUnits, command.assertedAmount.currency, new Date(Date.parse(apply.now) + 45 * 86_400_000).toISOString());
    run(apply.database, `INSERT INTO cases (dataset_id,id,case_number,member_id,account_id,queue_id,assigned_actor_id,state,priority,category,summary,opened_at,due_at,version)
      VALUES (?,?,?,?,?,?,NULL,'open','normal','card-dispute',?,?,?,1)`, apply.datasetId, caseId, serviceCaseNumber, str(transaction, 'member_id'), str(transaction, 'account_id'), str(queue, 'id'), `Dispute ${caseNumber}: ${command.reason.trim()}`, apply.now, new Date(Date.parse(apply.now) + 45 * 86_400_000).toISOString());
    run(apply.database, "INSERT INTO case_dependencies (dataset_id,id,case_id,kind,reference_id,state,due_at) VALUES (?,?,?,'dispute',?,'open',?)", apply.datasetId, newId('case-dependency'), caseId, disputeId, new Date(Date.parse(apply.now) + 45 * 86_400_000).toISOString());
    run(apply.database, "INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,1,'open',?,?,?)", apply.datasetId, newId('case-event'), caseId, apply.now, apply.actorId, `Card dispute case opened from dispute ${caseNumber} for transaction ${command.cardTransactionId}.`);
    for (const versionId of command.evidenceIds) run(apply.database, "INSERT INTO dispute_evidence (dataset_id,id,dispute_id,document_version_id,evidence_kind,digest,status,received_at) SELECT ?,?,?,?,'customer-supplied',digest,'accepted',? FROM document_versions WHERE dataset_id=? AND id=?", apply.datasetId, newId('dispute-evidence'), disputeId, versionId, apply.now, apply.datasetId, versionId);
    apply.event({ kind: 'case', id: caseId }, `Card dispute servicing case ${serviceCaseNumber} opened for dispute ${caseNumber}.`);
    apply.event({ kind: 'dispute', id: disputeId }, `Dispute ${caseNumber} opened for transaction ${command.cardTransactionId}; allegation recorded without a final finding.`);
  } });
}

function prepareProvisionalCredit(env: FinanceEnvironment, command: FinanceOf<'dispute.provisional_credit.issue'>): Preparation {
  const dispute = disputeRow(env, command.disputeId);
  if (dispute === undefined) return reject('not_found', 'The dispute does not exist.');
  const stale = requireFingerprint(dispute, DISPUTE_COLUMNS, command.expectedFingerprint, 'dispute');
  if (stale !== null) return stale;
  const invalid = requireMoney(env, command.amount, 'amount');
  if (invalid !== null) return invalid;
  if (!['submitted','investigating'].includes(str(dispute, 'state')) || command.amount.currency !== str(dispute, 'currency') || command.amount.minorUnits > int(dispute, 'claimed_amount_minor_units')) return reject('ineligible', 'The dispute or requested provisional amount is ineligible.');
  if (int(dispute, 'net_credit') !== 0) return reject('ineligible', 'A dispute credit was already issued.');
  const credit = requireCredit(env, str(dispute, 'account_id'), command.amount.currency);
  if (credit !== null) return credit;
  const approval = requireApproval(env, command, command.approvalId, command.amount);
  if (approval !== null) return approval;
  const customer = ledgerForAccount(env, str(dispute, 'account_id'));
  const settlement = generalLedger(env, command.amount.currency, 'settlement');
  if (customer === undefined || settlement === undefined) return reject('ineligible', 'Dispute credit ledgers are not configured.');
  return approvalPrepared(prepared({ businessReference: str(dispute, 'case_number'), result: { disputeId: command.disputeId, amount: command.amount, state: 'provisional-credit' }, review: { amount: command.amount, exponent: null, description: 'Conditional provisional dispute credit', accounts: [], consequences: ['Posts a conditional credit linked to the dispute; it is not represented as a final decision.'] }, apply(apply) {
    const journal = insertJournal(apply, { debitLedgerId: str(settlement, 'id'), creditLedgerId: str(customer, 'id'), amount: command.amount.minorUnits, currency: command.amount.currency, description: `Provisional credit for dispute ${str(dispute, 'case_number')}`, prefix: 'DC' });
    run(apply.database, "INSERT INTO dispute_credits (dataset_id,id,dispute_id,journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,'provisional')", apply.datasetId, newId('dispute-credit'), command.disputeId, journal, command.amount.minorUnits);
    run(apply.database, "UPDATE disputes SET state='provisional-credit' WHERE dataset_id=? AND id=?", apply.datasetId, command.disputeId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(dispute, 'account_id'));
    apply.event({ kind: 'dispute', id: command.disputeId }, `Conditional provisional credit of ${command.amount.minorUnits} ${command.amount.currency} minor units posted for dispute ${str(dispute, 'case_number')}.`);
  } }), command.approvalId);
}

function prepareDisputeEvidence(env: FinanceEnvironment, command: FinanceOf<'dispute.evidence.submit'>): Preparation {
  const dispute = disputeRow(env, command.disputeId);
  if (dispute === undefined) return reject('not_found', 'The dispute does not exist.');
  const stale = requireFingerprint(dispute, DISPUTE_COLUMNS, command.expectedFingerprint, 'dispute');
  if (stale !== null) return stale;
  const deadline = normalizeInstant(command.deadline);
  if (deadline === null) return reject('validation', 'Use a valid ISO-8601 deadline with an explicit offset.', { field: 'deadline' });
  if (!['submitted','investigating','provisional-credit'].includes(str(dispute, 'state')) || deadline !== str(dispute, 'deadline') || env.now > deadline) return reject('ineligible', 'The evidence deadline or dispute state prevents submission.');
  if (command.documentVersionIds.length === 0 || command.documentVersionIds.length > 25 || new Set(command.documentVersionIds).size !== command.documentVersionIds.length) return reject('validation', 'Submit 1 to 25 distinct document versions.', { field: 'documentVersionIds' });
  const owner = memberPartyForAccount(env, str(dispute, 'account_id'));
  if (owner === undefined) return reject('ineligible', 'The dispute account has no member owner.');
  const routeProblem = validation([
    requireText(command.recipient, 'recipient', 'Submission recipient', 200),
    requireText(command.channel, 'channel', 'Submission channel', 100),
  ]);
  if (routeProblem !== null) return routeProblem;
  const packageItems: { documentVersionId: string; digest: string }[] = [];
  for (const versionId of command.documentVersionIds) {
    let document;
    try {
      document = documentContent(env.database, env.datasetId, versionId, { institutionId: env.institutionId, actorId: env.actorId, now: env.now });
    } catch {
      return reject('ineligible', `Document ${versionId} bytes are missing or fail their integrity check.`, { field: 'documentVersionIds' });
    }
    if (document === undefined || document.ownerPartyId !== owner || document.accountId !== str(dispute, 'account_id')) {
      return reject('ownership_mismatch', `Document ${versionId} is absent or outside the dispute owner and account scope.`);
    }
    if (document.status !== 'redacted') return reject('ineligible', `Document ${versionId} is not an approved redacted derivative.`, { field: 'documentVersionIds' });
    const lineage = all(env.database, `SELECT source.status,source_document.owner_party_id,source_document.account_id
      FROM document_derivations derivation JOIN document_versions source ON source.dataset_id=derivation.dataset_id AND source.id=derivation.source_version_id
      JOIN documents source_document ON source_document.dataset_id=source.dataset_id AND source_document.id=source.document_id
      WHERE derivation.dataset_id=? AND derivation.derivative_version_id=? AND derivation.purpose='redaction'`, env.datasetId, versionId);
    if (lineage.length === 0 || lineage.some(source => str(source, 'owner_party_id') !== owner || optionalStr(source, 'account_id') !== str(dispute, 'account_id')
      || !['current','signed'].includes(str(source, 'status')))) {
      return reject('ineligible', `Document ${versionId} lacks current owner-scoped redaction lineage.`, { field: 'documentVersionIds' });
    }
    if (one(env.database, "SELECT 1 AS found FROM dispute_evidence WHERE dataset_id=? AND dispute_id=? AND document_version_id=? AND status='accepted'", env.datasetId, command.disputeId, versionId) !== undefined) return reject('duplicate_identity', `Document ${versionId} is already accepted for this dispute.`);
    packageItems.push({ documentVersionId: versionId, digest: document.digest });
  }
  const packageDigest = createHash('sha256').update(canonicalJson(packageItems)).digest('hex');
  const submissionId = newId('dispute-evidence-submission');
  const recipient = command.recipient.trim();
  const channel = command.channel.trim();
  const result = {
    disputeId: command.disputeId, submissionId, documentVersionIds: command.documentVersionIds, packageDigest, recipient, channel,
    state: 'accepted', acknowledgedAt: env.now, delivered: false,
  };
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({ businessReference: str(dispute, 'case_number'), result, review: noFinanceReview(['Records one exact approved redacted package and local submission acknowledgement for the named recipient and channel; provider delivery remains unasserted.']), apply(apply) {
    run(apply.database, `INSERT INTO dispute_evidence_submissions
      (dataset_id,id,dispute_id,recipient,channel,package_digest,state,acknowledged_at,delivered) VALUES (?,?,?,?,?,?,'accepted',?,0)`,
    apply.datasetId, submissionId, command.disputeId, recipient, channel, packageDigest, apply.now);
    for (const [index, item] of packageItems.entries()) run(apply.database, `INSERT INTO dispute_evidence
      (dataset_id,id,dispute_id,submission_id,package_ordinal,document_version_id,evidence_kind,digest,status,received_at)
      VALUES (?,?,?,?,?,?,'supporting-package',?,'accepted',?)`, apply.datasetId, newId('dispute-evidence'), command.disputeId,
    submissionId, index + 1, item.documentVersionId, item.digest, apply.now);
    if (str(dispute, 'state') === 'submitted') run(apply.database, "UPDATE disputes SET state='investigating' WHERE dataset_id=? AND id=?", apply.datasetId, command.disputeId);
    apply.event({ kind: 'dispute', id: command.disputeId }, `Exact redacted package ${packageDigest} with ${packageItems.length} version(s) accepted locally for ${recipient} through ${channel}; delivery not asserted.`);
  } }), command.approvalId);
}

function prepareDisputeSettle(env: FinanceEnvironment, command: FinanceOf<'dispute.settle'>): Preparation {
  const dispute = disputeRow(env, command.disputeId);
  if (dispute === undefined) return reject('not_found', 'The dispute does not exist.');
  const stale = requireFingerprint(dispute, DISPUTE_COLUMNS, command.expectedFingerprint, 'dispute');
  if (stale !== null) return stale;
  const invalid = requireMoney(env, command.finalAmount, 'finalAmount', true);
  if (invalid !== null) return invalid;
  if (!['submitted','investigating','provisional-credit'].includes(str(dispute, 'state')) || command.finalAmount.currency !== str(dispute, 'currency') || command.finalAmount.minorUnits > int(dispute, 'claimed_amount_minor_units')) return reject('ineligible', 'The decision allocation is inconsistent with the open dispute.');
  if (command.decision === 'denied' && command.finalAmount.minorUnits !== 0) return reject('validation', 'A denied dispute must have a zero final credit.', { field: 'finalAmount' });
  const linkedCases = all(env.database, `SELECT c.id,c.state,c.version,c.member_id,c.account_id,a.member_id AS dispute_member_id
    FROM case_dependencies d JOIN cases c ON c.dataset_id=d.dataset_id AND c.id=d.case_id
    JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=?
    WHERE d.dataset_id=? AND d.kind='dispute' AND d.reference_id=? AND d.state='open' ORDER BY c.id`, str(dispute, 'account_id'), env.datasetId, command.disputeId);
  if (linkedCases.length !== 1 || !['open','pending-customer','pending-internal','reopened'].includes(str(linkedCases[0], 'state'))) {
    return reject('ineligible', 'The dispute must have exactly one active linked servicing case before final settlement.');
  }
  const linkedCase = linkedCases[0];
  if (optionalStr(linkedCase, 'account_id') !== str(dispute, 'account_id') || str(linkedCase, 'member_id') !== str(linkedCase, 'dispute_member_id')) {
    return reject('ownership_mismatch', 'The linked servicing case belongs to another member or account.');
  }
  const approval = requireApproval(env, command, command.approvalId, { minorUnits: Math.max(1, command.finalAmount.minorUnits), currency: command.finalAmount.currency });
  if (approval !== null) return approval;
  const currentCredit = int(dispute, 'net_credit');
  const delta = command.finalAmount.minorUnits - currentCredit;
  const customer = ledgerForAccount(env, str(dispute, 'account_id'));
  const settlement = generalLedger(env, command.finalAmount.currency, 'settlement');
  if (customer === undefined || settlement === undefined) return reject('ineligible', 'Dispute settlement ledgers are not configured.');
  return approvalPrepared(prepared({ businessReference: str(dispute, 'case_number'), result: { disputeId: command.disputeId, decision: command.decision, finalAmount: command.finalAmount, accountingDeltaMinorUnits: delta, caseId: str(linkedCase, 'id'), caseState: 'resolved' }, review: { amount: { minorUnits: Math.abs(delta), currency: command.finalAmount.currency }, exponent: null, description: command.decision, accounts: [], consequences: ['Accounts for the existing provisional credit exactly once, preserves all evidence, and resolves the linked servicing case.'] }, apply(apply) {
    if (delta !== 0) {
      const journal = insertJournal(apply, { debitLedgerId: delta > 0 ? str(settlement, 'id') : str(customer, 'id'), creditLedgerId: delta > 0 ? str(customer, 'id') : str(settlement, 'id'), amount: Math.abs(delta), currency: command.finalAmount.currency, description: `Final ${command.decision} settlement for dispute ${str(dispute, 'case_number')}`, prefix: 'DS' });
      run(apply.database, 'INSERT INTO dispute_credits (dataset_id,id,dispute_id,journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,?)', apply.datasetId, newId('dispute-credit'), command.disputeId, journal, Math.abs(delta), delta > 0 ? 'final' : 'reversal');
      if (delta < 0) {
        const provisional = one(apply.database, "SELECT journal_id FROM dispute_credits WHERE dataset_id=? AND dispute_id=? AND kind='provisional' ORDER BY id LIMIT 1", apply.datasetId, command.disputeId);
        if (provisional !== undefined) run(apply.database, "INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,'reversal')", apply.datasetId, newId('correction-link'), str(provisional, 'journal_id'), journal, Math.abs(delta));
      }
      apply.event({ kind: 'dispute', id: command.disputeId }, `Dispute ${str(dispute, 'case_number')} final accounting delta ${delta} ${command.finalAmount.currency} minor units.`);
    } else apply.event({ kind: 'dispute', id: command.disputeId }, `Dispute ${str(dispute, 'case_number')} finalized with no additional ledger delta.`);
    run(apply.database, 'UPDATE disputes SET state=? WHERE dataset_id=? AND id=?', command.decision, apply.datasetId, command.disputeId);
    run(apply.database, 'UPDATE case_dependencies SET state=\'satisfied\' WHERE dataset_id=? AND kind=\'dispute\' AND reference_id=? AND state=\'open\'', apply.datasetId, command.disputeId);
    run(apply.database, "UPDATE cases SET state='resolved',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, str(linkedCase, 'id'));
    const sequence = int(one(apply.database, 'SELECT COALESCE(MAX(sequence),0)+1 AS sequence FROM case_events WHERE dataset_id=? AND case_id=?', apply.datasetId, str(linkedCase, 'id')), 'sequence');
    run(apply.database, "INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?, 'resolved',?,?,?)", apply.datasetId, newId('case-event'), str(linkedCase, 'id'), sequence, apply.now, apply.actorId, `Dispute ${str(dispute, 'case_number')} ${command.decision}; final credited amount ${command.finalAmount.minorUnits} ${command.finalAmount.currency} minor units.`);
    apply.event({ kind: 'case', id: str(linkedCase, 'id') }, `Linked servicing case resolved with dispute ${str(dispute, 'case_number')} ${command.decision} and final credited amount ${command.finalAmount.minorUnits} ${command.finalAmount.currency} minor units.`);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(dispute, 'account_id'));
  } }), command.approvalId);
}

function loanRow(env: FinanceEnvironment, loanId: string): Row | undefined {
  const loan = one(env.database, `SELECT l.id,l.account_id,l.application_id,l.principal_minor_units,l.currency,l.annual_rate_bps,l.state,l.opened_at,a.member_id,a.status AS account_status
    FROM loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id WHERE l.dataset_id=? AND l.id=?`, env.datasetId, loanId);
  if (loan === undefined) return undefined;
  const components = all(env.database, 'SELECT id,kind,ledger_account_id,balance_minor_units FROM loan_components WHERE dataset_id=? AND loan_id=? ORDER BY kind,id', env.datasetId, loanId);
  const obligations = all(env.database, 'SELECT id,kind,state,due_at FROM loan_obligations WHERE dataset_id=? AND loan_id=? ORDER BY id', env.datasetId, loanId);
  return { ...loan, components: canonicalJson(components), obligations: canonicalJson(obligations) };
}
const LOAN_COLUMNS = ['id','account_id','application_id','principal_minor_units','currency','annual_rate_bps','state','opened_at','member_id','account_status','components','obligations'] as const;

function prepareLoanApplication(env: FinanceEnvironment, command: FinanceOf<'loan.application.prepare'>): Preparation {
  const member = loadMember(env, command.memberId);
  const product = one(env.database, 'SELECT id,family,currency,status FROM products WHERE dataset_id=? AND id=?', env.datasetId, command.productId);
  if (member === undefined || product === undefined) return reject('not_found', 'The member or loan product does not exist.');
  const invalid = validation([requireMemberVersion(member, command.expectedMemberVersion), requireMoney(env, command.requestedAmount, 'requestedAmount'), requireText(command.purpose, 'purpose', 'Loan purpose', 300)]);
  if (invalid !== null) return invalid;
  if (str(member, 'status') !== 'active' || str(product, 'family') !== 'loan' || str(product, 'status') !== 'active' || str(product, 'currency') !== command.requestedAmount.currency) return reject('ineligible', 'The member or product is not eligible for this application.');
  if (!Number.isSafeInteger(command.termMonths) || command.termMonths < 6 || command.termMonths > 360) return reject('validation', 'Term must be 6 to 360 whole months.', { field: 'termMonths' });
  if (command.evidenceIds.length === 0 || command.evidenceIds.length > 20) return reject('ineligible', 'At least one current verified evidence item is required.');
  if (new Set(command.evidenceIds).size !== command.evidenceIds.length) return reject('validation', 'Loan application evidence IDs must be distinct.', { field: 'evidenceIds' });
  const productTerm = one(env.database, `SELECT id,rules_json FROM product_terms WHERE dataset_id=? AND product_id=? AND effective_at<=?
    ORDER BY effective_at DESC,id DESC LIMIT 1`, env.datasetId, command.productId, env.now);
  if (productTerm === undefined) return reject('ineligible', 'The loan product has no effective application requirements.');
  let productRules: unknown;
  try { productRules = JSON.parse(str(productTerm, 'rules_json')); } catch { return reject('ineligible', 'The loan product application requirements are malformed.'); }
  const applicationRules: unknown = productRules !== null && typeof productRules === 'object' ? Reflect.get(productRules, 'loanApplication') : undefined;
  const required: unknown = applicationRules !== null && typeof applicationRules === 'object' ? Reflect.get(applicationRules, 'requiredEvidenceKinds') : undefined;
  if (!Array.isArray(required) || required.length === 0 || required.length > 20 || required.some((kind) => typeof kind !== 'string' || kind.trim() === '') || new Set(required).size !== required.length) {
    return reject('ineligible', 'The loan product does not define a valid evidence-completeness contract.');
  }
  const evidenceKinds = new Set<string>();
  for (const evidenceId of command.evidenceIds) {
    const evidence = one(env.database, 'SELECT party_id,kind,status,issued_at,expires_at FROM identity_evidence WHERE dataset_id=? AND id=?', env.datasetId, evidenceId);
    if (evidence === undefined || str(evidence, 'party_id') !== str(member, 'party_id') || str(evidence, 'status') !== 'verified'
      || !isEvidenceValidAt(str(evidence, 'issued_at'), optionalStr(evidence, 'expires_at'), env.now, env.timeZone)) {
      return reject('ineligible', `Evidence ${evidenceId} is absent, mismatched or not current.`);
    }
    evidenceKinds.add(str(evidence, 'kind'));
  }
  const applicationId = newId('loan-application');
  const requiredEvidenceKinds = required as string[];
  const missingItems = requiredEvidenceKinds.filter((kind) => !evidenceKinds.has(kind));
  const terms = { termMonths: command.termMonths, purpose: command.purpose.trim(), productTermId: str(productTerm, 'id'), evidenceIds: [...command.evidenceIds], requiredEvidenceKinds, missingItems };
  return prepared({ businessReference: applicationId, result: { applicationId, state: 'draft', missingItems: terms.missingItems }, review: { amount: command.requestedAmount, exponent: null, description: command.purpose.trim(), accounts: [], consequences: ['Prepares a draft with explicit missing items; it makes no approval, pricing or lending decision.'] }, apply(apply) {
    run(apply.database, "INSERT INTO loan_applications (dataset_id,id,member_id,product_id,requested_amount_minor_units,currency,terms_json,state) VALUES (?,?,?,?,?,?,?,'draft')", apply.datasetId, applicationId, command.memberId, command.productId, command.requestedAmount.minorUnits, command.requestedAmount.currency, JSON.stringify(terms));
    apply.event({ kind: 'loan-application', id: applicationId }, missingItems.length === 0
      ? `Loan application ${applicationId} prepared as a complete draft evidence package; no lending decision was made.`
      : `Loan application ${applicationId} prepared as draft; missing evidence: ${missingItems.join(', ')}.`);
  } });
}

function prepareLoanPayment(env: FinanceEnvironment, command: FinanceOf<'loan.payment.allocate'>): Preparation {
  const loan = loanRow(env, command.loanId);
  if (loan === undefined) return reject('not_found', 'The loan does not exist.');
  const stale = requireFingerprint(loan, LOAN_COLUMNS, command.expectedFingerprint, 'loan');
  if (stale !== null) return stale;
  const invalid = validation([requireMoney(env, command.amount, 'amount'), requireText(command.receivedFundsReference, 'receivedFundsReference', 'Received funds reference', 120)]);
  if (invalid !== null) return invalid;
  if (!['active','delinquent'].includes(str(loan, 'state')) || str(loan, 'currency') !== command.amount.currency) return reject('ineligible', 'The loan is not payable in this currency and state.');
  const funds = one(env.database, `SELECT f.id,f.member_id,f.currency,f.amount_minor_units,f.source_journal_id,f.holding_ledger_account_id,f.state,
    COALESCE((SELECT SUM(u.amount_minor_units) FROM received_funds_uses u WHERE u.dataset_id=f.dataset_id AND u.received_funds_id=f.id),0) AS allocated
    FROM received_funds f WHERE f.dataset_id=? AND f.reference=?`, env.datasetId, command.receivedFundsReference.trim());
  if (funds === undefined) return reject('not_found', 'The received funds reference is not confirmed in this institution.');
  if (str(funds, 'state') !== 'confirmed' || str(funds, 'member_id') !== str(loan, 'member_id') || str(funds, 'currency') !== command.amount.currency) return reject('ineligible', 'The received funds are revoked, owned by another member or in another currency.');
  const source = one(env.database, `SELECT j.status,
    COALESCE(SUM(CASE WHEN jl.ledger_account_id=? AND jl.currency=? THEN jl.credit_minor_units ELSE 0 END),0) AS holding_credit,
    COALESCE(SUM(jl.debit_minor_units),0) AS debits,COALESCE(SUM(jl.credit_minor_units),0) AS credits
    FROM journals j JOIN journal_lines jl ON jl.dataset_id=j.dataset_id AND jl.journal_id=j.id
    WHERE j.dataset_id=? AND j.id=? GROUP BY j.status`, str(funds, 'holding_ledger_account_id'), command.amount.currency, env.datasetId, str(funds, 'source_journal_id'));
  if (source === undefined || str(source, 'status') !== 'posted' || int(source, 'holding_credit') !== int(funds, 'amount_minor_units') || int(source, 'debits') !== int(source, 'credits')) return reject('ineligible', 'The received funds lack an exact balanced posting to their holding ledger.');
  const fundsRemaining = int(funds, 'amount_minor_units') - int(funds, 'allocated');
  if (command.amount.minorUnits > fundsRemaining) return reject('limit_exceeded', `Only ${fundsRemaining} confirmed received-funds minor units remain unallocated.`);
  const components = all(env.database, `SELECT id,kind,ledger_account_id,balance_minor_units FROM loan_components WHERE dataset_id=? AND loan_id=?
    ORDER BY CASE kind WHEN 'fee' THEN 0 WHEN 'interest' THEN 1 ELSE 2 END`, env.datasetId, command.loanId);
  const total = components.reduce((sum, component) => sum + int(component, 'balance_minor_units'), 0);
  if (command.amount.minorUnits > total) return reject('limit_exceeded', `Only ${total} minor units remain due.`);
  const overpayment = command.amount.minorUnits === total ? fundsRemaining - command.amount.minorUnits : 0;
  if (overpayment > 0 && command.allocationPolicy !== 'fees-interest-principal-hold-remainder') {
    return reject('open_dependencies', `${overpayment} confirmed minor units exceed the exact payoff; select the hold-remainder disposition before allocation.`);
  }
  const allocations: { componentId: string; ledgerId: string; kind: string; amount: number }[] = [];
  let remaining = command.amount.minorUnits;
  for (const component of components) {
    const amount = Math.min(remaining, int(component, 'balance_minor_units'));
    if (amount > 0) allocations.push({ componentId: str(component, 'id'), ledgerId: str(component, 'ledger_account_id'), kind: str(component, 'kind'), amount });
    remaining -= amount;
  }
  if (remaining !== 0) return reject('ineligible', 'The allocation policy could not account for the entire payment.');
  return prepared({ businessReference: command.receivedFundsReference.trim(), result: { loanId: command.loanId, receivedFundsId: str(funds, 'id'), amount: command.amount, remainingReceivedFundsMinorUnits: fundsRemaining - command.amount.minorUnits, overpaymentDisposition: overpayment > 0 ? 'hold-for-return' : null, overpaymentMinorUnits: overpayment, allocations: allocations.map(({ componentId, kind, amount }) => ({ componentId, kind, amountMinorUnits: amount })) }, review: { amount: command.amount, exponent: null, description: command.receivedFundsReference.trim(), accounts: [], consequences: [overpayment > 0 ? `Allocates the exact payoff and records ${overpayment} remaining confirmed minor units as an open hold-for-return obligation.` : 'Allocations apply confirmed received funds to fees, then interest, then principal and sum exactly to the source usage.'] }, apply(apply) {
    enforceSafeLedgerPosting(apply, [
      { ledgerAccountId: str(funds, 'holding_ledger_account_id'), currency: command.amount.currency, debitMinorUnits: command.amount.minorUnits, creditMinorUnits: 0 },
      ...allocations.map((allocation) => ({ ledgerAccountId: allocation.ledgerId, currency: command.amount.currency, debitMinorUnits: 0, creditMinorUnits: allocation.amount })),
    ]);
    const journalId = newId('journal');
    const reference = nextNumber(apply.database, 'journals', 'reference', apply.datasetId, 'LP', 9);
    run(apply.database, "INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,?,?, 'posted',?,?,?,NULL)", apply.datasetId, journalId, reference, apply.operationId, apply.now, localDate(apply.now, apply.timeZone), `Loan payment ${command.receivedFundsReference.trim()}`);
    run(apply.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,0,?)', apply.datasetId, journalId, 1, str(funds, 'holding_ledger_account_id'), command.amount.currency, command.amount.minorUnits, 'Confirmed received loan payment funds');
    allocations.forEach((allocation, index) => {
      run(apply.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,0,?,?)', apply.datasetId, journalId, index + 2, allocation.ledgerId, command.amount.currency, allocation.amount, `${allocation.kind} allocation`);
      run(apply.database, 'INSERT INTO loan_allocations (dataset_id,id,loan_id,payment_journal_id,component_id,amount_minor_units) VALUES (?,?,?,?,?,?)', apply.datasetId, newId('loan-allocation'), command.loanId, journalId, allocation.componentId, allocation.amount);
      run(apply.database, 'UPDATE loan_components SET balance_minor_units=balance_minor_units-? WHERE dataset_id=? AND id=?', allocation.amount, apply.datasetId, allocation.componentId);
    });
    run(apply.database, 'INSERT INTO received_funds_uses (dataset_id,id,received_funds_id,allocation_journal_id,amount_minor_units) VALUES (?,?,?,?,?)', apply.datasetId, newId('received-funds-use'), str(funds, 'id'), journalId, command.amount.minorUnits);
    if (overpayment > 0) run(apply.database, "INSERT INTO loan_obligations (dataset_id,id,loan_id,kind,state,due_at) VALUES (?,?,?,?, 'open',NULL)", apply.datasetId, newId('loan-obligation'), command.loanId, `received-funds-overpayment:${str(funds, 'id')}:${overpayment}`);
    if (command.amount.minorUnits === total) run(apply.database, "UPDATE loans SET state='paid-off' WHERE dataset_id=? AND id=?", apply.datasetId, command.loanId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(loan, 'account_id'));
    apply.event({ kind: 'loan', id: command.loanId }, `Loan payment ${command.receivedFundsReference.trim()} allocated exactly: ${allocations.map((item) => `${item.kind} ${item.amount}`).join(', ')}.`);
  } });
}

function preparePayoffQuote(env: FinanceEnvironment, command: FinanceOf<'loan.payoff.quote'>): Preparation {
  const loan = loanRow(env, command.loanId);
  if (loan === undefined) return reject('not_found', 'The loan does not exist.');
  const stale = requireFingerprint(loan, LOAN_COLUMNS, command.expectedFingerprint, 'loan');
  if (stale !== null) return stale;
  const invalid = requireDate(command.payoffDate, 'payoffDate');
  if (invalid !== null) return invalid;
  if (!['active','delinquent','paid-off'].includes(str(loan, 'state'))) return reject('ineligible', 'A closed loan cannot receive a new payoff quote.');
  const today = localDate(env.now, env.timeZone);
  const latest = new Date(`${today}T00:00:00Z`); latest.setUTCDate(latest.getUTCDate() + 30);
  if (command.payoffDate < today || command.payoffDate > latest.toISOString().slice(0, 10)) return reject('ineligible', 'Payoff date must be within the supported 30-day quotation window.');
  const unresolvedAdjustments = all(env.database, `SELECT kind FROM loan_obligations WHERE dataset_id=? AND loan_id=? AND state='open'
    AND (lower(kind) LIKE '%adjust%' OR lower(kind) LIKE '%accrual%') ORDER BY kind,id`, env.datasetId, command.loanId);
  if (unresolvedAdjustments.length > 0) return reject('open_dependencies', `Resolve monetary loan obligations before quoting: ${unresolvedAdjustments.map((row) => str(row, 'kind')).join(', ')}.`);
  const policy = one(env.database, 'SELECT id,version,rules_json FROM policy_versions WHERE dataset_id=? AND id=? AND effective_at<=?', env.datasetId, command.policyVersionId, env.now);
  if (policy === undefined) return reject('ineligible', 'The supplied quote policy is not effective.');
  let payoffRules: unknown;
  try { payoffRules = Reflect.get(JSON.parse(str(policy, 'rules_json')) as object, 'loanPayoff'); } catch { return reject('ineligible', 'The supplied policy has invalid payoff rules.'); }
  if (payoffRules === null || typeof payoffRules !== 'object' || Array.isArray(payoffRules)
    || Reflect.get(payoffRules, 'rounding') !== 'half-even' || ![360,365,366].includes(Number(Reflect.get(payoffRules, 'yearBasis')))
    || !Number.isSafeInteger(Reflect.get(payoffRules, 'quoteValidityDays')) || Number(Reflect.get(payoffRules, 'quoteValidityDays')) < 1
    || Number(Reflect.get(payoffRules, 'quoteValidityDays')) > 30) return reject('ineligible', 'The supplied policy does not define supported payoff accrual and validity rules.');
  const components = all(env.database, 'SELECT kind,balance_minor_units FROM loan_components WHERE dataset_id=? AND loan_id=? ORDER BY kind', env.datasetId, command.loanId);
  const days = Math.round((Date.parse(`${command.payoffDate}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 86_400_000);
  const principal = components.filter(component => str(component, 'kind') === 'principal').reduce((sum, component) => sum + int(component, 'balance_minor_units'), 0);
  const numerator = BigInt(principal) * BigInt(int(loan, 'annual_rate_bps')) * BigInt(days);
  const denominator = BigInt(Number(Reflect.get(payoffRules, 'yearBasis'))) * 10_000n;
  const quotient = numerator / denominator;
  const remainder = numerator % denominator;
  const projectedInterest = Number(remainder * 2n > denominator || remainder * 2n === denominator && quotient % 2n !== 0n ? quotient + 1n : quotient);
  const lines = { ...Object.fromEntries(components.map((component) => [str(component, 'kind'), int(component, 'balance_minor_units')])), projectedInterest };
  const total = components.reduce((sum, component) => sum + int(component, 'balance_minor_units'), 0) + projectedInterest;
  const quoteId = newId('payoff-quote');
  const validityEndDate = new Date(`${today}T00:00:00.000Z`);
  validityEndDate.setUTCDate(validityEndDate.getUTCDate() + Number(Reflect.get(payoffRules, 'quoteValidityDays')) - 1);
  const localDayEnd = (date: string): string => {
    const following = new Date(`${date}T00:00:00.000Z`);
    following.setUTCDate(following.getUTCDate() + 1);
    return new Date(Date.parse(zonedInstant(following.toISOString().slice(0, 10), '00:00', env.timeZone)) - 1).toISOString();
  };
  const validityExpiresAt = localDayEnd(validityEndDate.toISOString().slice(0, 10));
  const payoffExpiresAt = localDayEnd(command.payoffDate);
  const expiresAt = validityExpiresAt < payoffExpiresAt ? validityExpiresAt : payoffExpiresAt;
  return prepared({ businessReference: quoteId, result: { quoteId, loanId: command.loanId, payoffDate: command.payoffDate, total: { minorUnits: total, currency: str(loan, 'currency') }, lines, expiresAt, policyVersionId: command.policyVersionId }, review: { amount: { minorUnits: total, currency: str(loan, 'currency') }, exponent: null, description: `Payoff quote for ${command.payoffDate}`, accounts: [], consequences: ['Creates a dated itemized quotation only; it neither receives funds nor closes the loan.'] }, apply(apply) {
    run(apply.database, 'INSERT INTO payoff_quotes (dataset_id,id,loan_id,as_of,expires_at,total_minor_units,lines_json,policy_version_id) VALUES (?,?,?,?,?,?,?,?)', apply.datasetId, quoteId, command.loanId, command.payoffDate, expiresAt, total, JSON.stringify(lines), command.policyVersionId);
    apply.event({ kind: 'loan', id: command.loanId }, `Payoff quote ${quoteId} created for ${command.payoffDate}: ${total} ${str(loan, 'currency')} minor units, not a closure.`);
  } });
}

function prepareMaturity(env: FinanceEnvironment, command: FinanceOf<'account.maturity.instruct'>): Preparation {
  const account = loadAccount(env, command.accountId);
  if (account === undefined) return reject('not_found', 'The account does not exist.');
  const invalid = requireAccountVersion(account, command.expectedVersion);
  if (invalid !== null) return invalid;
  const product = one(env.database, 'SELECT code,family FROM products WHERE dataset_id=? AND id=?', env.datasetId, str(account, 'product_id'));
  if (product === undefined || str(product, 'family') !== 'deposit' || !str(product, 'code').toLowerCase().includes('term') || !['open','matured'].includes(str(account, 'status'))) return reject('ineligible', 'Only an eligible term deposit may receive maturity instructions.');
  const maturityTerm = one(env.database, `SELECT c.id,c.maturity_date,c.cutoff_at,c.projected_proceeds_minor_units,c.currency,c.product_term_id
    FROM deposit_maturity_terms c JOIN product_terms t ON t.dataset_id=c.dataset_id AND t.id=c.product_term_id
    WHERE c.dataset_id=? AND c.account_id=? AND c.currency=? AND t.product_id=? AND date(c.maturity_date)>=date(?)
    ORDER BY c.maturity_date,c.id LIMIT 1`, env.datasetId, command.accountId, str(account, 'currency'), str(account, 'product_id'), env.now);
  if (maturityTerm === undefined) return reject('ineligible', 'No authoritative maturity term is available for this account.');
  const cutoff = str(maturityTerm, 'cutoff_at');
  if (cutoff <= env.now) return reject('ineligible', 'The authoritative maturity instruction cutoff has passed.');
  const current = one(env.database, 'SELECT id,account_id,destination_account_id,disposition,terms_json,state,cutoff_at,version FROM maturity_instructions WHERE dataset_id=? AND account_id=? ORDER BY version DESC LIMIT 1', env.datasetId, command.accountId);
  if (current !== undefined && command.expectedInstructionFingerprint !== rowFingerprint(current, ['id','account_id','destination_account_id','disposition','terms_json','state','cutoff_at','version'])) return reject('stale_version', 'The maturity instruction changed after review.');
  if (current === undefined && command.expectedInstructionFingerprint !== null) return reject('stale_version', 'The reviewed maturity instruction no longer exists.');
  if (command.disposition === 'transfer') {
    if (command.destinationAccountId === null) return reject('validation', 'A transfer disposition requires a destination account.', { field: 'destinationAccountId' });
    const destination = loadAccount(env, command.destinationAccountId);
    if (destination === undefined || str(destination, 'member_id') !== str(account, 'member_id') || str(destination, 'currency') !== str(account, 'currency') || str(destination, 'status') !== 'open') return reject('ownership_mismatch', 'The maturity destination must be an open same-member, same-currency account.');
  } else if (command.destinationAccountId !== null) return reject('validation', 'Only transfer disposition accepts a destination account.', { field: 'destinationAccountId' });
  let terms: Record<string, number> = {};
  if (command.disposition === 'renew') {
    if (command.termMonths === null || command.approvedAnnualRateBps === null || !Number.isSafeInteger(command.termMonths) || command.termMonths < 1 || command.termMonths > 120) return reject('validation', 'Renewal requires bounded approved term and rate.', { field: 'termMonths' });
    const available = one(env.database, 'SELECT annual_rate_bps FROM product_terms WHERE dataset_id=? AND product_id=? AND effective_at<=? ORDER BY effective_at DESC LIMIT 1', env.datasetId, str(account, 'product_id'), env.now);
    if (available === undefined || int(available, 'annual_rate_bps') !== command.approvedAnnualRateBps) return reject('ineligible', 'The requested renewal rate is not the current approved product term.');
    terms = { termMonths: command.termMonths, annualRateBps: command.approvedAnnualRateBps };
  } else if (command.termMonths !== null || command.approvedAnnualRateBps !== null) return reject('validation', 'Only renewal accepts term and rate fields.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const instructionId = current === undefined ? newId('maturity') : str(current, 'id');
  const version = current === undefined ? 1 : int(current, 'version') + 1;
  const maturityDate = str(maturityTerm, 'maturity_date');
  const projectedProceeds = { minorUnits: int(maturityTerm, 'projected_proceeds_minor_units'), currency: str(maturityTerm, 'currency') };
  return approvalPrepared(prepared({ businessReference: instructionId, result: { instructionId, version, disposition: command.disposition, destinationAccountId: command.destinationAccountId, terms, maturityDate, projectedProceeds, execution: 'at-maturity', fundsMoved: false }, review: { amount: projectedProceeds, exponent: null, description: `${command.disposition} at maturity on ${maturityDate}`, accounts: [], consequences: [`Stores an instruction against authoritative term ${str(maturityTerm, 'id')}; projected proceeds are ${projectedProceeds.minorUnits} ${projectedProceeds.currency} minor units and no funds move before maturity.`] }, apply(apply) {
    if (current === undefined) run(apply.database, "INSERT INTO maturity_instructions (dataset_id,id,account_id,destination_account_id,disposition,terms_json,state,cutoff_at,version) VALUES (?,?,?,?,?,?,'active',?,1)", apply.datasetId, instructionId, command.accountId, command.destinationAccountId, command.disposition, JSON.stringify(terms), cutoff);
    else run(apply.database, "UPDATE maturity_instructions SET destination_account_id=?,disposition=?,terms_json=?,state='active',cutoff_at=?,version=version+1 WHERE dataset_id=? AND id=?", command.destinationAccountId, command.disposition, JSON.stringify(terms), cutoff, apply.datasetId, instructionId);
    run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.accountId);
    apply.event({ kind: 'maturity-instruction', id: instructionId }, `Maturity instruction ${instructionId} version ${version} set to ${command.disposition} for ${maturityDate}; projected proceeds ${projectedProceeds.minorUnits} ${projectedProceeds.currency} minor units and no premature funds movement.`);
  } }), command.approvalId);
}

function prepareLoanClose(env: FinanceEnvironment, command: FinanceOf<'loan.close'>): Preparation {
  const loan = loanRow(env, command.loanId);
  if (loan === undefined) return reject('not_found', 'The loan does not exist.');
  const stale = requireFingerprint(loan, LOAN_COLUMNS, command.expectedFingerprint, 'loan');
  if (stale !== null) return stale;
  const accountIdentity = one(env.database, `SELECT a.id,a.member_id,a.product_id,a.currency,p.family,p.currency AS product_currency,
    x.member_id AS application_member_id,x.product_id AS application_product_id,x.currency AS application_currency,x.state AS application_state,
    (SELECT COUNT(*) FROM loan_components c JOIN ledger_accounts l ON l.dataset_id=c.dataset_id AND l.id=c.ledger_account_id
      WHERE c.dataset_id=n.dataset_id AND c.loan_id=n.id AND c.kind='principal' AND l.kind='loan-principal' AND l.customer_account_id=a.id) AS owned_principal_ledgers,
    (SELECT COUNT(*) FROM ledger_accounts l WHERE l.dataset_id=a.dataset_id AND l.customer_account_id=a.id
      AND (l.kind<>'loan-principal' OR NOT EXISTS (SELECT 1 FROM loan_components c WHERE c.dataset_id=l.dataset_id AND c.loan_id=n.id AND c.kind='principal' AND c.ledger_account_id=l.id))) AS incompatible_account_ledgers
    FROM loans n JOIN accounts a ON a.dataset_id=n.dataset_id AND a.id=n.account_id
    JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id
    JOIN loan_applications x ON x.dataset_id=n.dataset_id AND x.id=n.application_id
    WHERE n.dataset_id=? AND n.id=?`, env.datasetId, command.loanId);
  if (accountIdentity === undefined || str(accountIdentity, 'family') !== 'loan'
    || str(accountIdentity, 'product_id') !== str(accountIdentity, 'application_product_id')
    || str(accountIdentity, 'member_id') !== str(accountIdentity, 'application_member_id')
    || str(accountIdentity, 'currency') !== str(loan, 'currency')
    || str(accountIdentity, 'product_currency') !== str(loan, 'currency')
    || str(accountIdentity, 'application_currency') !== str(loan, 'currency')
    || str(accountIdentity, 'application_state') !== 'approved'
    || int(accountIdentity, 'owned_principal_ledgers') !== 1 || int(accountIdentity, 'incompatible_account_ledgers') !== 0) {
    return reject('ineligible', 'Loan closure requires the dedicated loan account, approved application product, and its exact principal ledger identity.');
  }
  if (str(loan, 'state') === 'closed') return { kind: 'unchanged', message: 'The loan is already closed.' };
  if (str(loan, 'state') !== 'paid-off') return reject('closure_blocked', 'The loan must be authoritatively paid off before closure.');
  const balances = all(env.database, 'SELECT balance_minor_units FROM loan_components WHERE dataset_id=? AND loan_id=?', env.datasetId, command.loanId);
  if (balances.some((row) => int(row, 'balance_minor_units') !== 0)) return reject('closure_blocked', 'A loan component still has a residual balance.');
  const obligations = all(env.database, "SELECT kind FROM loan_obligations WHERE dataset_id=? AND loan_id=? AND state='open'", env.datasetId, command.loanId);
  if (obligations.length > 0) return reject('open_dependencies', `Open loan obligations remain: ${obligations.map((row) => str(row, 'kind')).join(', ')}.`);
  const quote = one(env.database, 'SELECT id,total_minor_units,expires_at FROM payoff_quotes WHERE dataset_id=? AND id=? AND loan_id=?', env.datasetId, command.payoffEvidenceId, command.loanId);
  if (quote === undefined || int(quote, 'total_minor_units') !== 0 || str(quote, 'expires_at') < env.now) return reject('ineligible', 'Current dated zero-payoff evidence is required.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const closureId = newId('loan-closure');
  return approvalPrepared(prepared({ businessReference: command.loanId, result: { loanId: command.loanId, closureId, state: 'closed' }, review: noFinanceReview(['Closes the paid-off loan once and preserves all payment allocations; collateral release remains separate.']), apply(apply) {
    const receipt = one(apply.database, 'SELECT id FROM operation_receipts WHERE dataset_id=? AND operation_id=?', apply.datasetId, apply.operationId);
    if (receipt === undefined) throw new Error('Loan closure operation has no receipt.');
    run(apply.database, "UPDATE loans SET state='closed' WHERE dataset_id=? AND id=?", apply.datasetId, command.loanId);
    run(apply.database, "UPDATE accounts SET status='closed',closed_at=?,version=version+1 WHERE dataset_id=? AND id=?", apply.now, apply.datasetId, str(loan, 'account_id'));
    run(apply.database, 'INSERT INTO loan_closures (dataset_id,id,loan_id,receipt_id,closed_at,closure_document_version_id) VALUES (?,?,?,?,?,NULL)', apply.datasetId, closureId, command.loanId, str(receipt, 'id'), apply.now);
    apply.event({ kind: 'loan', id: command.loanId }, `Paid-off loan ${command.loanId} closed under zero-payoff evidence ${command.payoffEvidenceId}; allocations preserved.`);
  } }), command.approvalId);
}

function prepareClosureDocument(env: FinanceEnvironment, command: FinanceOf<'document.loan_closure.issue'>): Preparation {
  const closure = one(env.database, `SELECT c.id,c.loan_id,c.receipt_id,c.closed_at,c.closure_document_version_id,l.account_id,l.state AS loan_state,a.member_id,a.status AS account_status,m.party_id
    FROM loan_closures c JOIN loans l ON l.dataset_id=c.dataset_id AND l.id=c.loan_id JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id
    JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id WHERE c.dataset_id=? AND c.loan_id=?`, env.datasetId, command.loanId);
  if (closure === undefined) return reject('not_found', 'The verified loan closure does not exist.');
  const stale = requireFingerprint(closure, ['id','loan_id','receipt_id','closed_at','closure_document_version_id','account_id','member_id','party_id'], command.expectedClosureFingerprint, 'loan closure');
  if (stale !== null) return stale;
  if (str(closure, 'loan_state') !== 'closed' || str(closure, 'account_status') !== 'closed') return reject('ineligible', 'The loan and its dedicated account must still be closed before issuing closure evidence.');
  const receiptRow = one(env.database, `SELECT r.operation_id,o.occurred_at
    FROM operation_receipts r JOIN operations o ON o.dataset_id=r.dataset_id AND o.id=r.operation_id
    WHERE r.dataset_id=? AND r.id=?`, env.datasetId, str(closure, 'receipt_id'));
  let receiptProvesClosure = false;
  if (receiptRow !== undefined) {
    try {
      const receipt = loadReceipt(env.database, env.datasetId, { operationId: str(receiptRow, 'operation_id') });
      const occurredAt = str(receiptRow, 'occurred_at');
      if (receipt !== undefined && receipt.status === 'committed' && receipt.committedAt === occurredAt && receipt.committedAt <= str(closure, 'closed_at')) {
        if (receipt.operationKind === 'loan.close' && receipt.businessReference === command.loanId) {
          const result = receipt.result;
          receiptProvesClosure = result !== null && result.loanId === command.loanId
            && result.closureId === str(closure, 'id') && result.state === 'closed';
        } else if (receipt.operationKind === 'journal-posting' && receipt.result === null) {
          receiptProvesClosure = one(env.database, `SELECT 1 AS found FROM loan_allocations x JOIN journals j ON j.dataset_id=x.dataset_id AND j.id=x.payment_journal_id
            WHERE x.dataset_id=? AND x.loan_id=? AND j.operation_id=? LIMIT 1`, env.datasetId, command.loanId, receipt.operationId) !== undefined;
        }
      }
    } catch {
      receiptProvesClosure = false;
    }
  }
  if (!receiptProvesClosure) return reject('ineligible', 'The linked receipt does not authoritatively prove this loan closure.');
  if (command.recipientPartyId !== str(closure, 'party_id')) return reject('ownership_mismatch', 'The document recipient is not the closed loan owner.');
  const template = documentContent(env.database, env.datasetId, command.templateVersionId, { institutionId: env.institutionId, actorId: env.actorId, now: env.now });
  if (template === undefined || !['current','signed'].includes(template.status) || template.mediaType !== 'text/plain'
    || template.documentType !== `${command.documentType}-template` || template.ownerPartyId !== command.recipientPartyId
    || template.accountId !== str(closure, 'account_id')) return reject('ineligible', 'The approved immutable template does not match the requested closure document type, owner, and account.');
  const issuedVersionId = optionalStr(closure, 'closure_document_version_id');
  if (issuedVersionId !== null) {
    const issued = one(env.database, `SELECT d.owner_party_id,d.account_id,d.document_type,x.source_version_id FROM document_versions v
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN document_derivations x ON x.dataset_id=v.dataset_id AND x.derivative_version_id=v.id
      WHERE v.dataset_id=? AND v.id=?`, env.datasetId, issuedVersionId);
    if (issued !== undefined && str(issued, 'owner_party_id') === command.recipientPartyId && optionalStr(issued, 'account_id') === str(closure, 'account_id')
      && str(issued, 'document_type') === command.documentType && str(issued, 'source_version_id') === command.templateVersionId) {
      return { kind: 'unchanged', message: 'The same loan closure document was already issued.' };
    }
    return reject('ineligible', 'A different loan closure document was already issued.');
  }
  if (command.documentType === 'simulated-lien-release' && one(env.database, "SELECT id FROM loan_obligations WHERE dataset_id=? AND loan_id=? AND kind='collateral-release-authority' AND state='satisfied'", env.datasetId, command.loanId) === undefined) return reject('open_dependencies', 'A satisfied collateral release authority is required for the simulated lien release.');
  const approval = requireApproval(env, command, command.approvalId);
  if (approval !== null) return approval;
  const documentId = newId('document');
  const versionId = newId('document-version');
  const content = Buffer.concat([Buffer.from(template.bytes), Buffer.from('\n\n'), Buffer.from([
    `Document type: ${command.documentType}`,
    `Loan: ${command.loanId}`,
    `Account: ${str(closure, 'account_id')}`,
    `Owner party: ${command.recipientPartyId}`,
    `Closure receipt: ${str(closure, 'receipt_id')}`,
    `Closed at: ${str(closure, 'closed_at')}`,
    `Template version: ${command.templateVersionId}`,
    `Template digest: ${template.digest}`,
    'Outstanding principal, interest, and fee obligations are satisfied.',
    'Issued: yes',
    'Delivered: no',
  ].join('\n'), 'utf8')]);
  const digest = createHash('sha256').update(content).digest('hex');
  return approvalPrepared(prepared({ businessReference: command.loanId, result: { loanId: command.loanId, documentId, versionId, digest, documentType: command.documentType, issued: true, delivered: false }, review: noFinanceReview(['Issues one immutable closure document linked to the verified closure; issuance is not represented as delivery.']), apply(apply) {
    run(apply.database, "INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'text/plain',?,?)", apply.datasetId, digest, content.byteLength, content);
    run(apply.database, 'INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at) VALUES (?,?,?,?,?,?,?,?)', apply.datasetId, documentId, command.recipientPartyId, str(closure, 'account_id'), command.documentType, `${command.documentType} for ${command.loanId}`, 'loan-lifecycle', apply.now);
    run(apply.database, `INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,1,?,'text/plain',?,NULL,NULL,NULL,'current')`, apply.datasetId, versionId, documentId, digest, apply.now);
    run(apply.database, "INSERT INTO document_derivations (dataset_id,id,source_version_id,derivative_version_id,purpose,policy_version_id) VALUES (?,?,?,?,'format-conversion',NULL)", apply.datasetId, newId('document-derivation'), command.templateVersionId, versionId);
    run(apply.database, 'UPDATE loan_closures SET closure_document_version_id=? WHERE dataset_id=? AND id=?', versionId, apply.datasetId, str(closure, 'id'));
    apply.event({ kind: 'document-version', id: versionId }, `${command.documentType} ${versionId} issued for closed loan ${command.loanId}; no delivery claimed.`);
  } }), command.approvalId);
}

export function prepareFinanceLending(env: FinanceEnvironment, command: FinanceCommand): Preparation | null {
  switch (command.kind) {
    case 'card.replace': return prepareCardReplace(env, command);
    case 'card.lock.update': return prepareCardLock(env, command);
    case 'card.limit.update': return prepareCardLimit(env, command);
    case 'dispute.open': return prepareDisputeOpen(env, command);
    case 'dispute.provisional_credit.issue': return prepareProvisionalCredit(env, command);
    case 'dispute.evidence.submit': return prepareDisputeEvidence(env, command);
    case 'dispute.settle': return prepareDisputeSettle(env, command);
    case 'loan.application.prepare': return prepareLoanApplication(env, command);
    case 'loan.payment.allocate': return prepareLoanPayment(env, command);
    case 'loan.payoff.quote': return preparePayoffQuote(env, command);
    case 'account.maturity.instruct': return prepareMaturity(env, command);
    case 'loan.close': return prepareLoanClose(env, command);
    case 'document.loan_closure.issue': return prepareClosureDocument(env, command);
    default: return null;
  }
}

export function cardFingerprint(row: Row): string { return rowFingerprint(row, CARD_COLUMNS); }
export function disputeFingerprint(row: Row): string { return rowFingerprint(row, DISPUTE_COLUMNS); }
export function loanFingerprint(row: Row): string { return rowFingerprint(row, LOAN_COLUMNS); }
