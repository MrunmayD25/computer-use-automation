import { all, authorizeQuery, int, isIsoDate, one, reject, str, type Row } from './core.js';
import type { FinancialStore } from './store.js';
import type { Rejection, ServiceContext } from './types.js';

/**
 * Bounded scoped listings of finance and servicing records.
 *
 * `readFinanceRecord` inspects one record whose identity is already known; applications still need
 * ordinary discovery — every payment on an account, every card transaction on a card, every open
 * suspense item — before an operator can select one. This query is that missing read: a fixed
 * resource vocabulary, institution-scoped, authorized, paged, with optional member, account, parent,
 * state, identifier-fragment and local-date filters. It exposes stored columns only and never writes.
 */

export type FinanceListValue = string | number | null;

export interface FinanceListRow {
  id: string;
  /** Human-facing business identifier (payment reference, member number, batch number, …). */
  label: string;
  status: string | null;
  fields: Record<string, FinanceListValue>;
}

export interface FinanceListInput {
  resource: string;
  /** Exact record id; used by record-detail reads. */
  id?: string;
  memberId?: string;
  accountId?: string;
  /** Parent record id, interpreted per resource (card, dispute, loan, schedule, batch, journal, …). */
  parentId?: string;
  state?: string;
  query?: string;
  dateFrom?: string;
  dateThrough?: string;
  limit: number;
  offset: number;
}

export type FinanceListKind = keyof typeof RESOURCES;

export type FinanceListResult =
  | { kind: 'listed'; resource: string; items: FinanceListRow[]; total: number; offset: number; limit: number; exhausted: boolean }
  | Rejection;

interface ResourceConfig {
  select: string;
  from: string;
  /** SQL expression of the scoped member id, or null when the resource cannot be member-scoped. */
  member?: string;
  account?: string;
  /** Column/expression compared to `parentId`. */
  parent?: string;
  state?: string;
  /** Columns matched by the `query` fragment. */
  search?: readonly string[];
  /** Local-date column compared to dateFrom/dateThrough. */
  date?: string;
  /** Primary key expression for `id` filters; defaults to `<alias>.id`. */
  pk?: string;
  /** Institution-wide resources may be listed without a record scope. */
  allowUnscoped?: boolean;
  order: string;
}

const MEMBER_OF_PARTY = (table: string, column = 'party_id'): string => `EXISTS (SELECT 1 FROM members mx WHERE mx.dataset_id=${table}.dataset_id AND mx.party_id=${table}.${column} AND mx.id=?)`;

const RESOURCES: Readonly<Record<string, ResourceConfig>> = {
  beneficiary: {
    select: `b.id, b.display_name AS label, b.status, b.display_name, b.status AS state,
      (SELECT mx.member_number FROM members mx WHERE mx.dataset_id=b.dataset_id AND mx.party_id=b.owner_party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS ownerMemberNumber,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=b.dataset_id AND mx.party_id=b.owner_party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId`,
    from: 'beneficiaries b', member: MEMBER_OF_PARTY('b', 'owner_party_id'), state: 'b.status', search: ['b.display_name'], order: 'b.id',
  },
  'beneficiary-route': {
    select: `r.id, b.display_name AS label, r.status, r.beneficiary_id, b.display_name AS beneficiaryName,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=b.dataset_id AND mx.party_id=b.owner_party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId, r.version, r.routing_kind AS routingKind, r.masked_destination AS maskedDestination, r.verified_at AS verifiedAt, r.expires_at AS expiresAt`,
    from: 'beneficiary_routes r JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id',
    member: MEMBER_OF_PARTY('b', 'owner_party_id'), parent: 'r.beneficiary_id', state: 'r.status', search: ['b.display_name', 'r.masked_destination'], order: 'r.id',
  },
  payment: {
    select: `p.id, p.reference AS label, p.state AS status, p.reference, p.source_account_id AS accountId, a.member_id AS memberId, a.account_number AS accountNumber, m.member_number AS memberNumber,
      o.display_name AS ownerName, p.amount_minor_units AS amountMinorUnits, p.currency, p.requested_date AS requestedDate, p.state, p.version,
      b.display_name AS beneficiaryName, r.masked_destination AS maskedDestination`,
    from: `payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      JOIN parties o ON o.dataset_id=m.dataset_id AND o.id=m.party_id JOIN beneficiary_routes r ON r.dataset_id=p.dataset_id AND r.id=p.beneficiary_route_id
      JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id`,
    member: 'a.member_id', account: 'p.source_account_id', state: 'p.state', search: ['p.reference', 'b.display_name'], order: 'p.id',
  },
  'payment-schedule': {
    select: `s.id, a.account_number AS label, s.state AS status, a.member_id AS memberId, a.account_number AS accountNumber, m.member_number AS memberNumber,
      b.display_name AS beneficiaryName, s.rule_json AS rule, s.start_date AS startDate, s.end_date AS endDate, s.state,
      (SELECT COUNT(*) FROM schedule_occurrences o WHERE o.dataset_id=s.dataset_id AND o.schedule_id=s.id) AS occurrences`,
    from: `payment_schedules s JOIN accounts a ON a.dataset_id=s.dataset_id AND a.id=s.source_account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      JOIN beneficiary_routes r ON r.dataset_id=s.dataset_id AND r.id=s.beneficiary_route_id JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id`,
    member: 'a.member_id', account: 's.source_account_id', state: 's.state', search: ['a.account_number', 'b.display_name'], order: 's.id',
  },
  'schedule-occurrence': {
    select: `o.id, o.local_date AS label, o.state AS status, o.schedule_id AS scheduleId,
      (SELECT a.member_id FROM accounts a WHERE a.dataset_id=s.dataset_id AND a.id=s.source_account_id) AS memberId, o.local_date AS localDate, o.payment_id AS paymentId, o.state`,
    from: 'schedule_occurrences o JOIN payment_schedules s ON s.dataset_id=o.dataset_id AND s.id=o.schedule_id',
    parent: 'o.schedule_id', account: 's.source_account_id', state: 'o.state', date: 'o.local_date', order: 'o.local_date,o.id',
  },
  'payment-return': {
    select: `r.id, p.reference AS label, r.settlement_reference AS status, r.payment_id AS paymentId,
      (SELECT a.member_id FROM accounts a WHERE a.dataset_id=p.dataset_id AND a.id=p.source_account_id) AS memberId, p.reference AS paymentReference, r.return_code AS returnCode, r.amount_minor_units AS amountMinorUnits, p.currency, r.occurred_at AS occurredAt, r.settlement_reference AS settlementReference`,
    from: 'payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id',
    account: 'p.source_account_id', parent: 'r.payment_id', state: 'r.return_code', search: ['p.reference', 'r.return_code', 'r.settlement_reference'], order: 'r.id',
  },
  'payment-event': {
    select: 'e.id, e.state AS label, e.state AS status, e.payment_id AS paymentId, e.sequence, e.state, e.occurred_at AS occurredAt, e.detail',
    from: 'payment_events e', parent: 'e.payment_id', state: 'e.state', order: 'e.payment_id,e.sequence',
  },
  'payment-cancel-request': {
    select: 'c.id, c.state AS label, c.state AS status, c.payment_id AS paymentId, c.state, c.reason, c.requested_at AS requestedAt',
    from: 'payment_cancel_requests c', parent: 'c.payment_id', state: 'c.state', order: 'c.id',
  },
  card: {
    select: 'c.id, a.account_number AS label, c.status, a.member_id AS memberId, a.account_number AS accountNumber, m.member_number AS memberNumber, c.last_four AS lastFour, c.expiry_month AS expiryMonth, c.expiry_year AS expiryYear',
    from: 'cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id',
    member: 'a.member_id', account: 'c.account_id', state: 'c.status', search: ['a.account_number', 'c.last_four'], order: 'c.id',
  },
  'card-transaction': {
    select: 't.id, t.merchant AS label, t.state AS status, t.card_id AS cardId, c.last_four AS lastFour, a.member_id AS memberId, a.account_number AS accountNumber, t.journal_id AS journalId, t.merchant, t.merchant_category AS merchantCategory, t.amount_minor_units AS amountMinorUnits, t.currency, t.state, t.occurred_at AS occurredAt',
    from: 'card_transactions t JOIN cards c ON c.dataset_id=t.dataset_id AND c.id=t.card_id JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id',
    member: 'a.member_id', account: 'c.account_id', parent: 't.card_id', state: 't.state', search: ['t.merchant', 'c.last_four'], order: 't.occurred_at,t.id',
  },
  'card-limit': {
    select: 'l.id, l.kind AS label, l.expires_at AS status, l.card_id AS cardId, l.kind, l.amount_minor_units AS amountMinorUnits, l.currency, l.effective_at AS effectiveAt, l.expires_at AS expiresAt',
    from: 'card_limits l', parent: 'l.card_id', order: 'l.effective_at,l.id',
  },
  'card-lock': {
    select: 'l.id, l.kind AS label, l.state AS status, l.card_id AS cardId, l.kind, l.authority, l.state, l.placed_at AS placedAt, l.released_at AS releasedAt',
    from: 'card_locks l', parent: 'l.card_id', state: 'l.state', order: 'l.placed_at,l.id',
  },
  'card-event': {
    select: 'e.id, e.state AS label, e.state AS status, e.card_id AS cardId, e.sequence, e.state, e.occurred_at AS occurredAt, e.reason',
    from: 'card_events e', parent: 'e.card_id', order: 'e.card_id,e.sequence',
  },
  'card-replacement-order': {
    select: 'o.id, o.state AS label, o.state AS status, o.card_id AS cardId, o.address_id AS addressId, o.state, o.requested_at AS requestedAt',
    from: 'card_replacement_orders o', parent: 'o.card_id', state: 'o.state', order: 'o.id',
  },
  dispute: {
    select: 'd.id, d.case_number AS label, d.state AS status, d.case_number AS caseNumber, a.member_id AS memberId, a.account_number AS accountNumber, m.member_number AS memberNumber, d.journal_id AS journalId, d.claimed_amount_minor_units AS claimedAmountMinorUnits, d.currency, d.state, d.deadline',
    from: 'disputes d JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id',
    member: 'a.member_id', account: 'd.account_id', parent: 'd.journal_id', state: 'd.state', search: ['d.case_number', 'a.account_number'], order: 'd.id',
  },
  'dispute-evidence': {
    select: 'e.id, e.evidence_kind AS label, e.status, e.dispute_id AS disputeId, e.submission_id AS submissionId, e.package_ordinal AS packageOrdinal, e.document_version_id AS documentVersionId, e.evidence_kind AS evidenceKind, e.digest, e.received_at AS receivedAt',
    from: 'dispute_evidence e', parent: 'e.dispute_id', state: 'e.status', order: 'e.id',
  },
  'dispute-submission': {
    select: 's.id, s.package_digest AS label, s.state AS status, s.dispute_id AS disputeId, s.recipient, s.channel, s.package_digest AS packageDigest, s.state, s.acknowledged_at AS acknowledgedAt, s.delivered',
    from: 'dispute_evidence_submissions s', parent: 's.dispute_id', state: 's.state', search: ['s.recipient', 's.channel', 's.package_digest'], order: 's.id',
  },
  'dispute-credit': {
    select: 'c.id, c.kind AS label, c.kind AS status, c.dispute_id AS disputeId, c.journal_id AS journalId, c.amount_minor_units AS amountMinorUnits, c.kind',
    from: 'dispute_credits c', parent: 'c.dispute_id', order: 'c.id',
  },
  loan: {
    select: 'l.id, a.account_number AS label, l.state AS status, a.member_id AS memberId, a.account_number AS accountNumber, m.member_number AS memberNumber, l.application_id AS applicationId, l.principal_minor_units AS principalMinorUnits, l.currency, l.annual_rate_bps AS annualRateBps, l.state, l.opened_at AS openedAt',
    from: 'loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id',
    member: 'a.member_id', account: 'l.account_id', state: 'l.state', search: ['a.account_number', 'm.member_number'], order: 'l.id',
  },
  'loan-component': {
    select: 'c.id, c.kind AS label, c.kind AS status, c.loan_id AS loanId, c.kind, c.balance_minor_units AS balanceMinorUnits',
    from: 'loan_components c', parent: 'c.loan_id', order: 'c.kind,c.id',
  },
  'loan-obligation': {
    select: 'o.id, o.kind AS label, o.state AS status, o.loan_id AS loanId, o.kind, o.state, o.due_at AS dueAt',
    from: 'loan_obligations o', parent: 'o.loan_id', state: 'o.state', order: 'o.id',
  },
  'loan-allocation': {
    select: 'l.id, l.payment_journal_id AS label, NULL AS status, l.loan_id AS loanId, l.payment_journal_id AS paymentJournalId, l.component_id AS componentId, l.amount_minor_units AS amountMinorUnits',
    from: 'loan_allocations l', parent: 'l.loan_id', order: 'l.id',
  },
  'loan-application': {
    select: 'a.id, m.member_number AS label, a.state AS status, m.member_number AS memberNumber, a.member_id AS memberId, a.product_id AS productId, a.requested_amount_minor_units AS requestedAmountMinorUnits, a.currency, a.terms_json AS terms, a.state',
    from: 'loan_applications a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id',
    member: 'a.member_id', state: 'a.state', search: ['m.member_number'], order: 'a.id',
  },
  'payoff-quote': {
    select: 'q.id, q.as_of AS label, q.expires_at AS status, q.loan_id AS loanId, q.as_of AS asOf, q.expires_at AS expiresAt, q.total_minor_units AS totalMinorUnits, q.policy_version_id AS policyVersionId',
    from: 'payoff_quotes q', parent: 'q.loan_id', order: 'q.id',
  },
  'loan-closure': {
    select: 'c.id, c.closed_at AS label, NULL AS status, c.loan_id AS loanId, c.receipt_id AS receiptId, c.closed_at AS closedAt, c.closure_document_version_id AS closureDocumentVersionId',
    from: 'loan_closures c', parent: 'c.loan_id', order: 'c.id',
  },
  'interest-calculation': {
    select: 'c.id, c.period_end AS label, c.state AS status, c.account_id AS accountId, a.member_id AS memberId, a.account_number AS accountNumber, c.policy_version_id AS policyVersionId, c.period_start AS periodStart, c.period_end AS periodEnd, c.calculated_interest_minor_units AS calculatedInterestMinorUnits, c.booked_interest_minor_units AS bookedInterestMinorUnits, c.delta_minor_units AS deltaMinorUnits, a.currency, c.state',
    from: 'interest_calculations c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id',
    member: 'a.member_id', account: 'c.account_id', state: 'c.state', order: 'c.period_end,c.id',
  },
  fee: {
    select: `f.id, f.journal_id AS label, f.status, a.member_id AS memberId, a.account_number AS accountNumber, m.member_number AS memberNumber, f.journal_id AS journalId, f.original_amount_minor_units AS originalAmountMinorUnits, f.currency, f.policy_version_id AS policyVersionId, f.status AS state,
      COALESCE((SELECT SUM(r.amount_minor_units) FROM fee_refunds r WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id),0) AS refundedMinorUnits`,
    from: 'fees f JOIN accounts a ON a.dataset_id=f.dataset_id AND a.id=f.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id',
    member: 'a.member_id', account: 'f.account_id', state: 'f.status', search: ['a.account_number', 'f.journal_id'], order: 'f.id',
  },
  'fee-waiver': {
    select: 'w.id, w.fee_code AS label, w.state AS status, w.account_id AS accountId, a.member_id AS memberId, a.account_number AS accountNumber, w.fee_id AS feeId, w.fee_code AS feeCode, w.amount_limit_minor_units AS amountLimitMinorUnits, w.currency, w.valid_from AS validFrom, w.valid_through AS validThrough, w.max_occurrences AS maxOccurrences, w.reason, w.state, w.created_at AS createdAt',
    from: 'fee_waivers w JOIN accounts a ON a.dataset_id=w.dataset_id AND a.id=w.account_id',
    member: 'a.member_id', account: 'w.account_id', state: 'w.state', order: 'w.id',
  },
  'fee-refund': {
    select: 'r.id, r.refunded_at AS label, NULL AS status, r.fee_id AS feeId, r.journal_id AS journalId, r.amount_minor_units AS amountMinorUnits, r.refunded_at AS refundedAt',
    from: 'fee_refunds r', parent: 'r.fee_id', order: 'r.id',
  },
  hold: {
    select: 'h.id, a.account_number AS label, h.status, a.member_id AS memberId, a.account_number AS accountNumber, h.amount_minor_units AS amountMinorUnits, a.currency, h.status AS state, h.reason, h.release_authority AS releaseAuthority, h.placed_at AS placedAt, h.expires_at AS expiresAt, h.released_at AS releasedAt',
    from: 'holds h JOIN accounts a ON a.dataset_id=h.dataset_id AND a.id=h.account_id',
    member: 'a.member_id', account: 'h.account_id', state: 'h.status', search: ['a.account_number', 'h.reason'], order: 'h.id',
  },
  'hold-release': {
    select: 'r.id, r.released_at AS label, NULL AS status, r.hold_id AS holdId, r.amount_minor_units AS amountMinorUnits, r.authority, r.evidence_reference AS evidenceReference, r.released_at AS releasedAt',
    from: 'hold_releases r', parent: 'r.hold_id', order: 'r.id',
  },
  restriction: {
    select: 'r.id, r.kind AS label, r.status, a.member_id AS memberId, a.account_number AS accountNumber, r.account_id AS accountId, r.kind, r.status AS state, r.authority, r.placed_at AS placedAt, r.released_at AS releasedAt',
    from: 'restrictions r JOIN accounts a ON a.dataset_id=r.dataset_id AND a.id=r.account_id',
    member: 'a.member_id', account: 'r.account_id', state: 'r.status', order: 'r.id',
  },
  facility: {
    select: 'f.id, f.kind AS label, f.status, a.member_id AS memberId, a.account_number AS accountNumber, f.account_id AS accountId, f.kind, f.limit_minor_units AS limitMinorUnits, f.used_minor_units AS usedMinorUnits, a.currency, f.status AS state',
    from: 'facilities f JOIN accounts a ON a.dataset_id=f.dataset_id AND a.id=f.account_id',
    member: 'a.member_id', account: 'f.account_id', state: 'f.status', order: 'f.id',
  },
  'maturity-instruction': {
    select: 'i.id, i.disposition AS label, i.state AS status, a.member_id AS memberId, a.account_number AS accountNumber, i.account_id AS accountId, i.destination_account_id AS destinationAccountId, i.disposition, i.state, i.cutoff_at AS cutoffAt, i.version',
    from: 'maturity_instructions i JOIN accounts a ON a.dataset_id=i.dataset_id AND a.id=i.account_id',
    member: 'a.member_id', account: 'i.account_id', state: 'i.state', order: 'i.id',
  },
  'deposit-maturity-term': {
    select: 't.id, t.maturity_date AS label, NULL AS status, a.member_id AS memberId, a.account_number AS accountNumber, t.account_id AS accountId, t.maturity_date AS maturityDate, t.cutoff_at AS cutoffAt, t.projected_proceeds_minor_units AS projectedProceedsMinorUnits, t.currency, t.product_term_id AS productTermId',
    from: 'deposit_maturity_terms t JOIN accounts a ON a.dataset_id=t.dataset_id AND a.id=t.account_id',
    member: 'a.member_id', account: 't.account_id', order: 't.maturity_date,t.id',
  },
  'received-funds': {
    select: 'f.id, f.reference AS label, f.state AS status, f.reference, m.member_number AS memberNumber, f.member_id AS memberId, f.amount_minor_units AS amountMinorUnits, f.currency, f.state, f.received_at AS receivedAt, f.source_journal_id AS sourceJournalId',
    from: 'received_funds f JOIN members m ON m.dataset_id=f.dataset_id AND m.id=f.member_id',
    member: 'f.member_id', state: 'f.state', search: ['f.reference', 'm.member_number'], order: 'f.id',
  },
  'received-funds-use': {
    select: 'u.id, u.allocation_journal_id AS label, NULL AS status, u.received_funds_id AS receivedFundsId, u.allocation_journal_id AS allocationJournalId, u.amount_minor_units AS amountMinorUnits',
    from: 'received_funds_uses u', parent: 'u.received_funds_id', order: 'u.id',
  },
  'settlement-batch': {
    select: 'b.id, b.reference AS label, b.state AS status, b.reference, b.currency, b.declared_total_minor_units AS declaredTotalMinorUnits, b.state, b.cutoff_at AS cutoffAt',
    from: 'settlement_batches b', state: 'b.state', search: ['b.reference'], order: 'b.id',
  },
  'settlement-item': {
    select: 'i.id, i.state AS label, i.state AS status, i.settlement_batch_id AS settlementBatchId, i.payment_id AS paymentId, i.amount_minor_units AS amountMinorUnits, i.state',
    from: 'settlement_items i', parent: 'i.settlement_batch_id', state: 'i.state', order: 'i.id',
  },
  'suspense-item': {
    select: 's.id, j.reference AS label, s.state AS status, s.journal_id AS journalId, j.reference AS journalReference, s.original_amount_minor_units AS originalAmountMinorUnits, s.remaining_amount_minor_units AS remainingAmountMinorUnits, s.currency, s.state, s.evidence_reference AS evidenceReference',
    from: 'suspense_items s JOIN journals j ON j.dataset_id=s.dataset_id AND j.id=s.journal_id',
    state: 's.state', search: ['j.reference', 's.evidence_reference'], order: 's.id',
  },
  batch: {
    select: `b.id, b.batch_number AS label, b.state AS status, b.batch_number AS batchNumber, b.kind, b.state, b.currency, b.created_at AS createdAt, b.input_document_version_id AS inputDocumentVersionId, b.input_digest AS inputDigest,
      (SELECT COUNT(*) FROM batch_items i WHERE i.dataset_id=b.dataset_id AND i.batch_id=b.id) AS items`,
    from: 'batches b', state: 'b.state', search: ['b.batch_number', 'b.kind'], order: 'b.id',
  },
  'batch-item': {
    select: 'i.id, i.source_key AS label, i.state AS status, i.batch_id AS batchId, i.ordinal, i.source_key AS sourceKey, i.item_json AS itemJson, i.state, i.receipt_id AS receiptId, i.amount_minor_units AS amountMinorUnits, i.failure_code AS failureCode',
    from: 'batch_items i', parent: 'i.batch_id', state: 'i.state', order: 'i.ordinal,i.id',
  },
  'reconciliation-run': {
    select: 'r.id, r.reference AS label, r.state AS status, r.reference, r.kind, r.as_of AS asOf, r.state, r.control_total_minor_units AS controlTotalMinorUnits, r.currency',
    from: 'reconciliation_runs r', state: 'r.state', search: ['r.reference', 'r.kind'], order: 'r.id',
  },
  'reconciliation-match': {
    select: 'm.id, m.state AS label, m.state AS status, m.run_id AS runId, m.left_reference AS leftReference, m.right_reference AS rightReference, m.amount_minor_units AS amountMinorUnits, m.currency, m.state',
    from: 'reconciliation_matches m', parent: 'm.run_id', state: 'm.state', order: 'm.id',
  },
  'cash-session': {
    select: `s.id, s.business_date AS label, s.state AS status, s.actor_id AS actorId, a.actor_number AS operatorNumber, s.branch_id AS branchId, s.business_date AS businessDate, s.state, s.opened_at AS openedAt, s.closed_at AS closedAt,
      (SELECT d.currency FROM cash_declarations d WHERE d.dataset_id=s.dataset_id AND d.cash_session_id=s.id LIMIT 1) AS currency,
      (SELECT d.declared_minor_units FROM cash_declarations d WHERE d.dataset_id=s.dataset_id AND d.cash_session_id=s.id LIMIT 1) AS declaredMinorUnits,
      (SELECT d.counted_minor_units FROM cash_declarations d WHERE d.dataset_id=s.dataset_id AND d.cash_session_id=s.id LIMIT 1) AS countedMinorUnits`,
    from: 'cash_sessions s LEFT JOIN actors a ON a.dataset_id=s.dataset_id AND a.id=s.actor_id',
    state: 's.state', date: 's.business_date', search: ['s.business_date', 'a.actor_number'], order: 's.id',
  },
  'cash-declaration': {
    select: 'd.id, d.currency AS label, NULL AS status, d.cash_session_id AS cashSessionId, d.currency, d.declared_minor_units AS declaredMinorUnits, d.counted_minor_units AS countedMinorUnits, d.declared_at AS declaredAt',
    from: 'cash_declarations d', parent: 'd.cash_session_id', order: 'd.id',
  },
  'maintenance-request': {
    select: 'r.id, r.request_number AS label, r.state AS status, r.request_number AS requestNumber, m.member_number AS memberNumber, r.member_id AS memberId, r.account_id AS accountId, r.category, r.subject, r.state, r.created_at AS createdAt, r.updated_at AS updatedAt, r.applied_receipt_id AS appliedReceiptId',
    from: 'maintenance_requests r JOIN members m ON m.dataset_id=r.dataset_id AND m.id=r.member_id',
    member: 'r.member_id', account: 'r.account_id', state: 'r.state', search: ['r.request_number', 'r.subject', 'm.member_number'], order: 'r.id',
  },
  'request-attachment': {
    select: 'CAST(a.rowid AS TEXT) AS id, a.document_version_id AS label, NULL AS status, a.request_id AS requestId, a.document_version_id AS documentVersionId, a.purpose',
    from: 'request_attachments a', parent: 'a.request_id', pk: 'a.rowid', order: 'a.request_id,a.document_version_id',
  },
  'communication-job': {
    select: `j.id, j.purpose AS label, j.state AS status, j.party_id AS partyId, j.document_version_id AS documentVersionId, j.address_destination_id AS addressDestinationId,
      (SELECT mx.member_number FROM members mx WHERE mx.dataset_id=j.dataset_id AND mx.party_id=j.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberNumber,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=j.dataset_id AND mx.party_id=j.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId,
      j.purpose, j.channel, j.destination, j.state, j.created_at AS createdAt`,
    from: 'communication_jobs j', member: MEMBER_OF_PARTY('j'), state: 'j.state', search: ['j.purpose', 'j.destination'], order: 'j.id',
  },
  'communication-event': {
    select: 'e.id, e.state AS label, e.state AS status, e.job_id AS jobId, e.sequence, e.state, e.occurred_at AS occurredAt, e.detail',
    from: 'communication_events e', parent: 'e.job_id', order: 'e.job_id,e.sequence',
  },
  'communication-preference': {
    select: 'p.id, p.purpose AS label, p.state AS status, p.party_id AS partyId, p.purpose, p.channel, p.state, p.updated_at AS updatedAt',
    from: 'communication_preferences p', member: MEMBER_OF_PARTY('p'), state: 'p.state', order: 'p.id',
  },
  consent: {
    select: `c.id, c.purpose AS label, c.state AS status, c.party_id AS partyId, c.account_id AS accountId,
      (SELECT mx.member_number FROM members mx WHERE mx.dataset_id=c.dataset_id AND mx.party_id=c.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberNumber,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=c.dataset_id AND mx.party_id=c.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId,
      c.purpose, c.channel, c.disclosure_version_id AS disclosureVersionId, c.state, c.effective_at AS effectiveAt`,
    from: 'consents c', member: MEMBER_OF_PARTY('c'), account: 'c.account_id', state: 'c.state', search: ['c.purpose', 'c.channel'], order: 'c.id',
  },
  'identity-evidence': {
    select: `e.id, e.reference AS label, e.status, e.party_id AS partyId,
      (SELECT mx.member_number FROM members mx WHERE mx.dataset_id=e.dataset_id AND mx.party_id=e.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberNumber,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=e.dataset_id AND mx.party_id=e.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId,
      e.kind, e.status AS state, e.issued_at AS issuedAt, e.expires_at AS expiresAt, e.reference`,
    from: 'identity_evidence e', member: MEMBER_OF_PARTY('e'), state: 'e.status', search: ['e.reference', 'e.kind'], order: 'e.id',
  },
  'retention-hold': {
    select: 'h.id, h.reason AS label, h.state AS status, h.document_id AS documentId, h.case_id AS caseId, h.reason, h.state, h.placed_at AS placedAt, h.review_at AS reviewAt, h.released_at AS releasedAt',
    from: 'retention_holds h', state: 'h.state', parent: 'h.case_id', search: ['h.reason'], order: 'h.id',
  },
  'merge-plan': {
    select: 'p.id, s.member_number AS label, p.state AS status, p.source_member_id AS sourceMemberId, s.member_number AS sourceMemberNumber, p.target_member_id AS targetMemberId, t.member_number AS targetMemberNumber, p.state, p.conflicts_json AS conflicts, p.created_at AS createdAt',
    from: 'member_merge_plans p JOIN members s ON s.dataset_id=p.dataset_id AND s.id=p.source_member_id JOIN members t ON t.dataset_id=p.dataset_id AND t.id=p.target_member_id',
    member: 'p.source_member_id', state: 'p.state', search: ['s.member_number', 't.member_number'], order: 'p.id', allowUnscoped: true,
  },
  'name-history': {
    select: 'h.id, h.kind AS label, h.valid_to AS status, h.party_id AS partyId, h.kind, h.given_name AS givenName, h.family_name AS familyName, h.valid_from AS validFrom, h.valid_to AS validTo, h.evidence_id AS evidenceId',
    from: 'name_history h', member: MEMBER_OF_PARTY('h'), order: 'h.valid_from,h.id',
  },
  'tax-history': {
    select: 'h.id, h.classification AS label, h.valid_to AS status, h.member_id AS memberId, m.member_number AS memberNumber, h.classification, h.valid_from AS validFrom, h.valid_to AS validTo, h.evidence_id AS evidenceId',
    from: 'tax_status_history h JOIN members m ON m.dataset_id=h.dataset_id AND m.id=h.member_id',
    member: 'h.member_id', order: 'h.valid_from,h.id',
  },
  signature: {
    select: 's.id, s.status AS label, s.status, s.document_version_id AS documentVersionId, s.signer_party_id AS signerPartyId, s.status AS state, s.requested_at AS requestedAt, s.signed_at AS signedAt, s.evidence_reference AS evidenceReference',
    from: 'signatures s', parent: 's.document_version_id', state: 's.status', order: 's.id',
  },
  'document-annotation': {
    select: 'a.id, a.text AS label, a.status, a.document_version_id AS documentVersionId, a.actor_id AS actorId, a.page_number AS pageNumber, a.region_json AS regionJson, a.text, a.status AS state, a.created_at AS createdAt',
    from: 'document_annotations a', parent: 'a.document_version_id', state: 'a.status', order: 'a.id',
  },
  'case-dependency': {
    select: 'd.id, d.kind AS label, d.state AS status, d.case_id AS caseId, d.kind, d.reference_id AS referenceId, d.state, d.due_at AS dueAt',
    from: 'case_dependencies d', parent: 'd.case_id', state: 'd.state', order: 'd.id',
  },
  'case-event': {
    select: 'e.id, e.state AS label, e.state AS status, e.case_id AS caseId, e.sequence, e.state, e.occurred_at AS occurredAt, e.actor_id AS actorId, e.detail',
    from: 'case_events e', parent: 'e.case_id', order: 'e.case_id,e.sequence',
  },
  'organization-ownership': {
    select: `o.id, p.display_name AS label, NULL AS status, o.organization_party_id AS organizationPartyId, o.owner_party_id AS ownerPartyId, p.display_name AS ownerName,
      o.ownership_bps AS ownershipBps, o.is_control_person AS isControlPerson, o.starts_at AS startsAt, o.ends_at AS endsAt, o.evidence_id AS evidenceId`,
    from: 'organization_ownership o JOIN parties p ON p.dataset_id=o.dataset_id AND p.id=o.owner_party_id',
    member: MEMBER_OF_PARTY('o', 'owner_party_id'), parent: 'o.organization_party_id', order: 'o.id',
  },
  reservation: {
    select: 'r.id, r.status AS label, r.status, r.account_id AS accountId, a.account_number AS accountNumber, r.payment_id AS paymentId, r.amount_minor_units AS amountMinorUnits, r.status AS state, r.created_at AS createdAt, r.ended_at AS endedAt',
    from: 'reservations r JOIN accounts a ON a.dataset_id=r.dataset_id AND a.id=r.account_id',
    member: 'a.member_id', account: 'r.account_id', parent: 'r.payment_id', state: 'r.status', order: 'r.id',
  },
  journal: {
    select: 'j.id, j.reference AS label, j.status, j.reference, j.effective_date AS effectiveDate, j.description, j.posted_at AS postedAt',
    from: 'journals j',
    account: `EXISTS (SELECT 1 FROM journal_lines jl JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id WHERE jl.dataset_id=j.dataset_id AND jl.journal_id=j.id AND la.customer_account_id=?)`,
    state: 'j.status', search: ['j.reference', 'j.description'], order: 'j.posted_at DESC,j.id',
  },
  transaction: {
    select: 'j.id, j.reference AS label, j.status, j.reference, j.effective_date AS effectiveDate, j.description, j.posted_at AS postedAt',
    from: 'journals j',
    account: `EXISTS (SELECT 1 FROM journal_lines jl JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id WHERE jl.dataset_id=j.dataset_id AND jl.journal_id=j.id AND la.customer_account_id=?)`,
    state: 'j.status', search: ['j.reference', 'j.description'], order: 'j.posted_at DESC,j.id',
  },
  transfer: {
    select: 'j.id, j.reference AS label, j.status, j.reference, j.effective_date AS effectiveDate, j.description, j.posted_at AS postedAt',
    from: `journals j JOIN operations o ON o.dataset_id=j.dataset_id AND o.id=j.operation_id AND o.operation_kind='transfer.internal'`,
    account: `EXISTS (SELECT 1 FROM journal_lines jl JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id WHERE jl.dataset_id=j.dataset_id AND jl.journal_id=j.id AND la.customer_account_id=?)`,
    state: 'j.status', search: ['j.reference', 'j.description'], order: 'j.posted_at DESC,j.id',
  },
  'transaction-amendment': {
    select: 'a.id, a.amended_at AS label, NULL AS status, a.journal_id AS journalId, a.old_description AS oldDescription, a.new_description AS newDescription, a.amended_at AS amendedAt',
    from: 'transaction_amendments a', parent: 'a.journal_id', order: 'a.id',
  },
  'effective-date-correction': {
    select: 'c.id, c.new_effective_date AS label, NULL AS status, c.journal_id AS journalId, c.receipt_id AS receiptId, c.old_effective_date AS oldEffectiveDate, c.new_effective_date AS newEffectiveDate, c.reason, c.corrected_at AS correctedAt',
    from: 'effective_date_corrections c', parent: 'c.journal_id', order: 'c.id',
  },
  'correction-link': {
    select: 'l.id, l.kind AS label, NULL AS status, l.original_journal_id AS originalJournalId, l.correction_journal_id AS correctionJournalId, l.amount_minor_units AS amountMinorUnits, l.kind',
    from: 'correction_links l', parent: 'l.original_journal_id', order: 'l.id',
  },
  'calendar-day': {
    select: `CAST(c.rowid AS TEXT) AS id, c.local_date AS label, CASE c.is_business_day WHEN 1 THEN 'business' ELSE 'closed' END AS status,
      c.local_date AS localDate, c.calendar_version AS calendarVersion, c.is_business_day AS isBusinessDay, c.payment_cutoff_at AS paymentCutoffAt, c.label AS dayLabel`,
    from: 'calendar_days c', date: 'c.local_date', pk: 'c.rowid', order: 'c.local_date',
  },
  product: {
    select: 'p.id, p.code AS label, p.status, p.code, p.name, p.family, p.currency',
    from: 'products p', state: 'p.status', search: ['p.code', 'p.name', 'p.family'], order: 'p.code,p.id', allowUnscoped: true,
  },
  'product-term': {
    select: 't.id, p.code AS label, NULL AS status, t.product_id AS productId, t.version, t.effective_at AS effectiveAt, t.annual_rate_bps AS annualRateBps, t.rules_json AS rules',
    from: 'product_terms t JOIN products p ON p.dataset_id=t.dataset_id AND p.id=t.product_id', parent: 't.product_id', search: ['p.code', 't.version'], order: 'p.code,t.effective_at,t.id', allowUnscoped: true,
  },
  'account-party': {
    select: `CAST(p.rowid AS TEXT) AS id, p.role AS label, p.ends_at AS status, p.account_id AS accountId, p.party_id AS partyId,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=p.dataset_id AND mx.party_id=p.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId,
      (SELECT mx.member_number FROM members mx WHERE mx.dataset_id=p.dataset_id AND mx.party_id=p.party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberNumber,
      o.display_name AS displayName, p.role, p.starts_at AS startsAt, p.ends_at AS endsAt`,
    from: 'account_parties p JOIN parties o ON o.dataset_id=p.dataset_id AND o.id=p.party_id',
    member: MEMBER_OF_PARTY('p'), account: 'p.account_id', pk: 'p.rowid', order: 'p.account_id,p.role',
  },
  document: {
    select: `d.id, d.display_name AS label, NULL AS status, d.document_type AS documentType, d.display_name AS displayName, d.retention_class AS retentionClass,
      d.owner_party_id AS ownerPartyId, d.account_id AS accountId,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=d.dataset_id AND mx.party_id=d.owner_party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId,
      (SELECT mx.member_number FROM members mx WHERE mx.dataset_id=d.dataset_id AND mx.party_id=d.owner_party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberNumber,
      a.account_number AS accountNumber, d.created_at AS createdAt,
      (SELECT COUNT(*) FROM document_versions v WHERE v.dataset_id=d.dataset_id AND v.document_id=d.id) AS versions`,
    from: 'documents d LEFT JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id',
    member: MEMBER_OF_PARTY('d', 'owner_party_id'), account: 'd.account_id', search: ['d.display_name', 'd.document_type'], order: 'd.id',
  },
  'document-version': {
    select: `v.id, v.id AS label, v.status, v.document_id AS documentId, d.display_name AS displayName, d.document_type AS documentType, v.version, v.digest, v.media_type AS mediaType,
      v.issued_at AS issuedAt, v.period_start AS periodStart, v.period_end AS periodEnd, v.page_count AS pageCount,
      (SELECT mx.id FROM members mx WHERE mx.dataset_id=d.dataset_id AND mx.party_id=d.owner_party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberId,
      (SELECT mx.member_number FROM members mx WHERE mx.dataset_id=d.dataset_id AND mx.party_id=d.owner_party_id AND mx.status<>'merged' ORDER BY mx.id LIMIT 1) AS memberNumber,
      d.account_id AS accountId`,
    from: 'document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id',
    member: MEMBER_OF_PARTY('d', 'owner_party_id'), account: 'd.account_id', parent: 'v.document_id', state: 'v.status', search: ['d.display_name', 'v.id'], order: 'v.document_id,v.version',
  },
};

export const FINANCE_LIST_RESOURCES: readonly string[] = Object.keys(RESOURCES);

export function isFinanceListResource(value: string): boolean {
  return Object.hasOwn(RESOURCES, value);
}

/** Whether a resource has a relationship scope that a transport directory may require. */
export function financeListRequiresScope(value: string): boolean {
  const config = RESOURCES[value];
  return config !== undefined && !config.allowUnscoped && (config.member !== undefined || config.account !== undefined || config.parent !== undefined || config.date !== undefined);
}

const like = (value: string): string => `%${value.replaceAll('\\', '\\\\').replaceAll('%', '\\%').replaceAll('_', '\\_')}%`;

function inputProblem(input: unknown): { value: FinanceListInput } | Rejection {
  if (input === null || typeof input !== 'object' || Array.isArray(input)) return reject('validation', 'A finance list request must be an object.');
  const value = input as Record<string, unknown>;
  const allowed = new Set(['resource', 'id', 'memberId', 'accountId', 'parentId', 'state', 'query', 'dateFrom', 'dateThrough', 'limit', 'offset']);
  const unknown = Object.keys(value).find((key) => !allowed.has(key));
  if (unknown !== undefined) return reject('validation', `Unknown field ${unknown}.`, { field: unknown });
  if (typeof value.resource !== 'string' || !Object.hasOwn(RESOURCES, value.resource)) return reject('validation', 'Unknown record resource.', { field: 'resource' });
  for (const key of ['id', 'memberId', 'accountId', 'parentId', 'state', 'query', 'dateFrom', 'dateThrough']) {
    if (value[key] !== undefined && typeof value[key] !== 'string') return reject('validation', `${key} must be text.`, { field: key });
  }
  if (!Number.isSafeInteger(value.limit) || (value.limit as number) < 1 || (value.limit as number) > 500) return reject('validation', 'The list limit must be between 1 and 500.', { field: 'limit' });
  if (!Number.isSafeInteger(value.offset) || (value.offset as number) < 0 || (value.offset as number) > 1_000_000) return reject('validation', 'The list offset is out of range.', { field: 'offset' });
  for (const key of ['dateFrom', 'dateThrough']) {
    if (value[key] !== undefined && value[key] !== '' && !isIsoDate(value[key] as string)) return reject('validation', `${key} must be YYYY-MM-DD.`, { field: key });
  }
  return { value: value as unknown as FinanceListInput };
}

/** Lists one record resource inside the bound institution, authorized for ordinary service reads. */
export function listFinanceRecords(store: FinancialStore, context: ServiceContext, input: unknown): FinanceListResult {
  const parsed = inputProblem(input);
  if (!('value' in parsed)) return parsed;
  const request = parsed.value;
  const config = RESOURCES[request.resource];
  if (config === undefined) return reject('validation', 'Unknown record resource.', { field: 'resource' });
  if (request.memberId !== undefined && request.memberId !== '' && config.member === undefined) return reject('validation', `The ${request.resource} list cannot be scoped to a member.`, { field: 'memberId' });
  if (request.accountId !== undefined && request.accountId !== '' && config.account === undefined) return reject('validation', `The ${request.resource} list cannot be scoped to an account.`, { field: 'accountId' });
  if (request.parentId !== undefined && request.parentId !== '' && config.parent === undefined) return reject('validation', `The ${request.resource} list has no parent scope.`, { field: 'parentId' });
  if (request.state !== undefined && request.state !== '' && config.state === undefined) return reject('validation', `The ${request.resource} list has no state filter.`, { field: 'state' });
  if (request.query !== undefined && request.query !== '' && (config.search === undefined || config.search.length === 0)) return reject('validation', `The ${request.resource} list has no text search.`, { field: 'query' });
  if ((request.dateFrom !== undefined && request.dateFrom !== '') || (request.dateThrough !== undefined && request.dateThrough !== '')) {
    if (config.date === undefined) return reject('validation', `The ${request.resource} list has no date filter.`, { field: 'dateFrom' });
    if (request.dateFrom !== undefined && request.dateFrom !== '' && request.dateThrough !== undefined && request.dateThrough !== '' && request.dateFrom > request.dateThrough)
      return reject('validation', 'Date filter bounds are reversed.', { field: 'dateFrom' });
    if (request.dateFrom !== undefined && request.dateFrom !== '' && request.dateThrough !== undefined && request.dateThrough !== '') {
      const days = (Date.parse(`${request.dateThrough}T00:00:00Z`) - Date.parse(`${request.dateFrom}T00:00:00Z`)) / 86_400_000;
      if (days > 31) return reject('limit_exceeded', 'Date-scoped lists are limited to 32 days; narrow the date range.', { field: 'dateThrough' });
    }
  }
  return store.read((database) => {
    const denied = authorizeQuery(database, context);
    if (denied !== null) return denied;
    const datasetId = context.binding.datasetId;
    const alias = config.from.slice(config.from.indexOf(' ') + 1).split(' ')[0];
    const clauses = [`${alias}.dataset_id=?`];
    const parameters: (string | number)[] = [datasetId];
    const scope = (expression: string | undefined, value: string | undefined): void => {
      if (expression === undefined || value === undefined || value === '') return;
      if (expression.includes('?')) { clauses.push(expression); parameters.push(value); }
      else { clauses.push(`${expression}=?`); parameters.push(value); }
    };
    scope(config.member, request.memberId);
    scope(config.account, request.accountId);
    scope(config.parent, request.parentId);
    scope(config.pk ?? `${alias}.id`, request.id);
    scope(config.state, request.state);
    const query = request.query?.trim() ?? '';
    if (query !== '' && config.search !== undefined) {
      clauses.push(`(${config.search.map((column) => `${column} LIKE ? ESCAPE '\\'`).join(' OR ')})`);
      parameters.push(...config.search.map(() => like(query)));
    }
    if (config.date !== undefined) {
      if (request.dateFrom !== undefined && request.dateFrom !== '') { clauses.push(`${config.date}>=?`); parameters.push(request.dateFrom); }
      if (request.dateThrough !== undefined && request.dateThrough !== '') { clauses.push(`${config.date}<=?`); parameters.push(request.dateThrough); }
    }
    const where = clauses.join(' AND ');
    const total = int(one(database, `SELECT COUNT(*) AS count FROM ${config.from} WHERE ${where}`, ...parameters), 'count');
    const rows = all(database, `SELECT ${config.select} FROM ${config.from} WHERE ${where} ORDER BY ${config.order} LIMIT ? OFFSET ?`, ...parameters, request.limit, request.offset);
    const items = rows.map((row: Row): FinanceListRow => {
      const fields: Record<string, FinanceListValue> = {};
      for (const [key, value] of Object.entries(row)) {
        if (key === 'id' || key === 'label' || key === 'status') continue;
        fields[key] = typeof value === 'bigint' ? Number(value) : (value as FinanceListValue);
      }
      return { id: str(row, 'id'), label: str(row, 'label'), status: row.status === null ? null : str(row, 'status'), fields };
    });
    return { kind: 'listed' as const, resource: request.resource, items, total, offset: request.offset, limit: request.limit, exhausted: request.offset + items.length >= total };
  });
}
