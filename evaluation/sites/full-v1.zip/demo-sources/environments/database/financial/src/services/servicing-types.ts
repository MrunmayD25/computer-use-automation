import type { AddressInput, CoreCommand } from './types.js';
import { validateCoreCommand } from './validation.js';

/** A command in the servicing and records domain. */
export type ServicingCommand =
  | IdentityEvidenceRegisterCommand
  | IdentityVerifyCommand
  | LegalNameUpdateCommand
  | PreferredNameUpdateCommand
  | DocumentIndexCommand
  | DocumentBundleRedactCommand
  | DocumentSignatureCollectCommand
  | ConsentDeliveryRecordCommand
  | ConsentWithdrawCommand
  | CustomerExportCreateCommand
  | RetentionHoldApplyCommand
  | CaseInformationRequestCommand
  | CaseEscalateCommand
  | AddressReconcileCommand
  | AddressDestinationUpdateCommand
  | CaseCloseCommand
  | CaseReopenCommand
  | CaseSubjectCorrectCommand
  | MaintenanceDraftSaveCommand
  | MaintenanceDraftAmendCommand
  | MaintenanceRequestSubmitCommand
  | MaintenanceRequestReviewCommand
  | MaintenanceRequestProcessCommand
  | MaintenanceRequestWithdrawCommand
  | DocumentAnnotationUpdateCommand
  | DocumentMetadataUpdateCommand
  | CommunicationPreferenceUpdateCommand
  | CommunicationSendCommand
  | CommunicationDeliveryUpdateCommand;

export interface IdentityEvidenceRegisterCommand {
  kind: 'member.identity_evidence.register';
  memberId: string;
  documentVersionId: string;
  evidenceId?: string;
  evidenceKind: 'passport' | 'drivers-license' | 'national-id' | 'state-id';
  issuedAt: string;
  expiresAt: string;
  reference: string;
}

export interface IdentityVerifyCommand {
  kind: 'member.identity.verify';
  memberId: string;
  evidenceId: string;
  method: string;
}

export interface LegalNameUpdateCommand {
  kind: 'member.legal_name.update';
  memberId: string;
  expectedVersion: number;
  legalGiven: string;
  legalFamily: string;
  evidenceId: string;
  approvalId: string;
}

export interface PreferredNameUpdateCommand {
  kind: 'member.preferred_name.update';
  memberId: string;
  expectedVersion: number;
  preferredName: string | null;
  communicationScope: string;
}

export interface DocumentIndexCommand {
  kind: 'document.index';
  memberId: string;
  ownerPartyId: string;
  accountId: string | null;
  documentId?: string;
  documentType: string;
  displayName: string;
  retentionClass: string;
  /** Bytes are supplied by an allow-listed local source and are content addressed before storage. */
  bytes: Uint8Array;
  mediaType?: string;
  pageCount?: number | null;
  source?: string;
  sourceDigest?: string;
}

export interface DocumentBundleRedactCommand {
  kind: 'document.bundle.redact';
  memberId: string;
  sourceVersionIds: readonly string[];
  recipientPurpose: string;
  redactionPolicyVersionId: string;
  /** Exact source excerpts retained in the safe derivative after service-side extraction and policy checks. */
  approvedExcerpts: readonly Readonly<{ sourceVersionId: string; text: string }>[];
  /** The service generates a text-only derivative; no source bytes or caller-rendered layers are copied. */
  displayName?: string;
}

export interface DocumentSignatureCollectCommand {
  kind: 'document.signature.collect';
  action: 'request' | 'sign' | 'decline' | 'expire';
  documentVersionId: string;
  signerPartyIds: readonly string[];
  channel: string;
  /** Immutable evidence version required for every terminal response; omitted while requesting. */
  evidenceReference?: string;
}

export interface ConsentDeliveryRecordCommand {
  kind: 'consent.delivery.record';
  partyId: string;
  accountId: string | null;
  purpose: string;
  channel: string;
  disclosureVersionId: string;
  /** Reference describing the affirmative acknowledgement captured by the approved local surface. */
  evidence: string;
}

export interface ConsentWithdrawCommand {
  kind: 'consent.withdraw';
  consentId: string;
  effectiveAt?: string;
  affectedChannels: readonly string[];
}

export interface CustomerExportCreateCommand {
  kind: 'document.customer_export.create';
  memberId: string;
  categories: readonly string[];
  from: string | null;
  through: string | null;
  destination: string;
  approvalId: string;
  /** Exact preflight inventory bound into the independent approval. */
  documentVersionIds: readonly string[];
}

export interface RetentionHoldApplyCommand {
  kind: 'document.retention_hold.apply';
  documentId?: string;
  caseId?: string;
  reason: string;
  reviewAt: string;
  approvalId: string;
}

export interface CaseInformationRequestCommand {
  kind: 'case.information.request';
  caseId: string;
  expectedVersion: number;
  fields: readonly string[];
  recipientPartyId: string;
  channel: string;
  dueAt: string;
  documentVersionId?: string | null;
  destination?: string;
}

export interface CaseEscalateCommand {
  kind: 'case.escalate';
  caseId: string;
  expectedVersion: number;
  escalationRule: string;
}

export interface AddressReconcileCommand {
  kind: 'maintenance.address.reconcile';
  memberId: string;
  expectedMemberVersion: number;
  conflictingAddressId: string;
  winningEvidenceVersionId: string;
  winningEvidenceDigest: string;
  precedence: string;
  /** Canonical address values extracted and approved from the winning evidence. */
  address: AddressInput;
  approvalId: string;
}

export type AddressDestinationContext = 'member-mailing' | 'account-statement' | 'card-shipping' | 'loan-notice';

export interface AddressDestinationUpdateCommand {
  kind: 'maintenance.address.destination.update';
  memberId: string;
  context: AddressDestinationContext;
  targetId: string;
  addressId: string;
  evidenceVersionId: string;
  effectiveDate: string;
  /** Exact currently effective instruction seen during review, or null when none exists. */
  expectedCurrentDestinationId: string | null;
  /** Exact granted postal consent when policy requires one; null records that none is required. */
  consentId: string | null;
  approvalId: string;
}

export interface CaseCloseCommand {
  kind: 'case.close';
  caseId: string;
  expectedVersion: number;
  resolutionCode: string;
  effectEvidenceVersionId: string;
}

export interface CaseReopenCommand {
  kind: 'case.reopen';
  caseId: string;
  expectedVersion: number;
  evidenceVersionId: string;
  reopeningBasis: string;
  dueAt?: string;
}

export interface CaseSubjectCorrectCommand {
  kind: 'case.subject.correct';
  caseId: string;
  expectedVersion: number;
  correctMemberId: string;
  correctAccountId: string | null;
  evidenceVersionId: string;
  approvalId: string;
}

export interface MaintenanceDraftSaveCommand {
  kind: 'maintenance.draft.save';
  memberId: string;
  accountId: string | null;
  requestId?: string;
  requestNumber?: string;
  category: string;
  subject: string;
  requestedCommand: MaintenanceRequestedCommand;
  note?: string;
  missingFields: readonly string[];
  evidenceDocumentVersionIds?: readonly string[];
}

export interface MaintenanceDraftAmendCommand {
  kind: 'maintenance.draft.amend';
  requestId: string;
  expectedUpdatedAt: string;
  patch: Readonly<{
    subject?: string;
    reason?: string | null;
    note?: string;
    requestedCommand?: MaintenanceRequestedCommand;
    missingFields?: readonly string[];
    evidenceVersionId?: string;
    evidenceDocumentVersionIds?: readonly string[];
  }>;
}

export const MAINTENANCE_REQUESTED_COMMAND_KINDS = Object.freeze([
  'contact.update',
  'member.note.add',
  'account.nickname.update',
  'account.statement_delivery.update',
  'account.close',
] as const);

export type MaintenanceRequestedCommand = Extract<CoreCommand, { kind: typeof MAINTENANCE_REQUESTED_COMMAND_KINDS[number] }>;

export interface MaintenanceRequestSubmitCommand {
  kind: 'maintenance.request.submit';
  requestId: string;
  expectedUpdatedAt: string;
  declaredState: 'submitted';
}

export interface MaintenanceRequestWithdrawCommand {
  kind: 'maintenance.request.withdraw';
  requestId: string;
  expectedUpdatedAt: string;
  reason: string;
}

export interface MaintenanceRequestReviewCommand {
  kind: 'maintenance.request.review';
  requestId: string;
  expectedUpdatedAt: string;
  decision: 'approve' | 'reject' | 'return-for-information';
  reason: string;
  missingFields?: readonly string[];
}

export interface MaintenanceRequestProcessCommand {
  kind: 'maintenance.request.process';
  requestId: string;
  expectedUpdatedAt: string;
  disposition: 'apply' | 'reject';
  reason: string;
  /** Receipt for the already committed exact business change; required for apply. */
  appliedReceiptId?: string;
}

export interface DocumentAnnotationUpdateCommand {
  kind: 'document.annotation.update';
  annotationId?: string;
  documentVersionId: string;
  pageNumber: number;
  regionMicros: Readonly<{ x: number; y: number; width: number; height: number }>;
  action: 'create' | 'amend' | 'remove';
  /** Required for amend/remove and matched against the complete stored annotation state. */
  expectedAnnotationFingerprint?: string;
  text?: string;
}

export interface DocumentMetadataUpdateCommand {
  kind: 'document.metadata.update';
  documentId: string;
  expectedMetadata: Readonly<{
    ownerPartyId: string;
    accountId: string | null;
    documentType: string;
    displayName: string;
    retentionClass: string;
  }>;
  documentType: string;
  displayName: string;
  ownerPartyId: string;
  accountId: string | null;
  retentionClass: string;
  /** Independent approval required only when owner or account association changes. */
  approvalId?: string;
}

export interface CommunicationPreferenceUpdateCommand {
  kind: 'communication.preference.update';
  partyId: string;
  purpose: string;
  channel: string;
  state: 'enabled' | 'disabled';
}

export interface CommunicationSendCommand {
  kind: 'communication.send';
  partyId: string;
  channel: string;
  /** Required for electronic delivery. Postal delivery derives its destination from addressDestinationId. */
  destination?: string;
  addressDestinationId?: string;
  purpose: string;
  documentVersionId: string;
  jobId?: string;
}

export interface CommunicationDeliveryUpdateCommand {
  kind: 'communication.delivery.update';
  jobId: string;
  expectedState: 'queued' | 'accepted';
  action: 'accept' | 'deliver' | 'bounce' | 'cancel';
  detail: string;
}

export type ServicingCommandKind = ServicingCommand['kind'];

/** Permissions checked before preparing each servicing command. */
export const SERVICING_GRANTS: Readonly<Record<ServicingCommandKind, readonly string[]>> = Object.freeze({
  'member.identity_evidence.register': ['maintain'],
  'member.identity.verify': ['maintain'],
  'member.legal_name.update': ['supervise'],
  'member.preferred_name.update': ['maintain'],
  'document.index': ['maintain', 'signature.response.record'],
  'document.bundle.redact': ['maintain', 'case.manage', 'supervise'],
  'document.signature.collect': ['maintain', 'signature.response.record'],
  'consent.delivery.record': ['maintain'],
  'consent.withdraw': ['maintain'],
  'document.customer_export.create': ['supervise'],
  'document.retention_hold.apply': ['supervise'],
  'case.information.request': ['case.manage'],
  'case.escalate': ['case.manage', 'supervise'],
  'maintenance.address.reconcile': ['supervise'],
  'maintenance.address.destination.update': ['supervise'],
  'case.close': ['case.manage'],
  'case.reopen': ['case.manage'],
  'case.subject.correct': ['supervise'],
  'maintenance.draft.save': ['maintain'],
  'maintenance.draft.amend': ['maintain'],
  'maintenance.request.submit': ['maintain'],
  'maintenance.request.review': ['supervise'],
  'maintenance.request.process': ['supervise'],
  'maintenance.request.withdraw': ['maintain'],
  'document.annotation.update': ['document.annotate', 'case.manage'],
  'document.metadata.update': ['maintain', 'supervise'],
  'communication.preference.update': ['maintain'],
  'communication.send': ['maintain', 'case.manage'],
  'communication.delivery.update': ['supervise'],
});

function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function exact(value: Record<string, unknown>, required: readonly string[], optional: readonly string[] = []): boolean {
  const permitted = new Set(['kind', ...required, ...optional]);
  return required.every(key => key in value) && Object.keys(value).every(key => permitted.has(key));
}

const string = (value: unknown): value is string => typeof value === 'string';
const integer = (value: unknown): value is number => typeof value === 'number' && Number.isSafeInteger(value);
const nullableString = (value: unknown): value is string | null => value === null || string(value);
const strings = (value: unknown): value is readonly string[] => Array.isArray(value) && value.every(string);
const bytes = (value: unknown): value is Uint8Array => value instanceof Uint8Array;

/** Rejects missing, mistyped and unexpected command fields at an untrusted boundary. */
export function isServicingCommand(value: unknown): value is ServicingCommand {
  if (!record(value) || !string(value.kind)) return false;
  switch (value.kind) {
    case 'member.identity_evidence.register': return exact(value, ['memberId', 'documentVersionId', 'evidenceKind', 'issuedAt', 'expiresAt', 'reference'], ['evidenceId']) && string(value.memberId) && string(value.documentVersionId) && ['passport', 'drivers-license', 'national-id', 'state-id'].includes(String(value.evidenceKind)) && string(value.issuedAt) && string(value.expiresAt) && string(value.reference) && (value.evidenceId === undefined || string(value.evidenceId));
    case 'member.identity.verify': return exact(value, ['memberId', 'evidenceId', 'method']) && string(value.memberId) && string(value.evidenceId) && string(value.method);
    case 'member.legal_name.update': return exact(value, ['memberId', 'expectedVersion', 'legalGiven', 'legalFamily', 'evidenceId', 'approvalId']) && string(value.memberId) && integer(value.expectedVersion) && string(value.legalGiven) && string(value.legalFamily) && string(value.evidenceId) && string(value.approvalId);
    case 'member.preferred_name.update': return exact(value, ['memberId', 'expectedVersion', 'preferredName', 'communicationScope']) && string(value.memberId) && integer(value.expectedVersion) && nullableString(value.preferredName) && string(value.communicationScope);
    case 'document.index': return exact(value, ['memberId', 'ownerPartyId', 'accountId', 'documentType', 'displayName', 'retentionClass', 'bytes'], ['documentId', 'mediaType', 'pageCount', 'source', 'sourceDigest']) && string(value.memberId) && string(value.ownerPartyId) && nullableString(value.accountId) && string(value.documentType) && string(value.displayName) && string(value.retentionClass) && bytes(value.bytes) && (value.documentId === undefined || string(value.documentId)) && (value.mediaType === undefined || string(value.mediaType)) && (value.pageCount === undefined || value.pageCount === null || integer(value.pageCount)) && (value.source === undefined || string(value.source)) && (value.sourceDigest === undefined || string(value.sourceDigest));
    case 'document.bundle.redact': return exact(value, ['memberId', 'sourceVersionIds', 'recipientPurpose', 'redactionPolicyVersionId', 'approvedExcerpts'], ['displayName']) && string(value.memberId) && strings(value.sourceVersionIds) && string(value.recipientPurpose) && string(value.redactionPolicyVersionId) && redactionExcerpts(value.approvedExcerpts) && (value.displayName === undefined || string(value.displayName));
    case 'document.signature.collect': return exact(value, ['action', 'documentVersionId', 'signerPartyIds', 'channel'], ['evidenceReference']) && ['request', 'sign', 'decline', 'expire'].includes(String(value.action)) && string(value.documentVersionId) && strings(value.signerPartyIds) && string(value.channel) && (value.evidenceReference === undefined || string(value.evidenceReference));
    case 'consent.delivery.record': return exact(value, ['partyId', 'accountId', 'purpose', 'channel', 'disclosureVersionId', 'evidence']) && string(value.partyId) && nullableString(value.accountId) && string(value.purpose) && string(value.channel) && string(value.disclosureVersionId) && string(value.evidence);
    case 'consent.withdraw': return exact(value, ['consentId', 'affectedChannels'], ['effectiveAt']) && string(value.consentId) && strings(value.affectedChannels) && (value.effectiveAt === undefined || string(value.effectiveAt));
    case 'document.customer_export.create': return exact(value, ['memberId', 'categories', 'from', 'through', 'destination', 'approvalId', 'documentVersionIds']) && string(value.memberId) && strings(value.categories) && nullableString(value.from) && nullableString(value.through) && string(value.destination) && string(value.approvalId) && strings(value.documentVersionIds);
    case 'document.retention_hold.apply': return exact(value, ['reason', 'reviewAt', 'approvalId'], ['documentId', 'caseId']) && string(value.reason) && string(value.reviewAt) && string(value.approvalId) && (value.documentId === undefined || string(value.documentId)) && (value.caseId === undefined || string(value.caseId));
    case 'case.information.request': return exact(value, ['caseId', 'expectedVersion', 'fields', 'recipientPartyId', 'channel', 'dueAt'], ['documentVersionId', 'destination']) && string(value.caseId) && integer(value.expectedVersion) && strings(value.fields) && string(value.recipientPartyId) && string(value.channel) && string(value.dueAt) && (value.documentVersionId === undefined || nullableString(value.documentVersionId)) && (value.destination === undefined || string(value.destination));
    case 'case.escalate': return exact(value, ['caseId', 'expectedVersion', 'escalationRule']) && string(value.caseId) && integer(value.expectedVersion) && string(value.escalationRule);
    case 'maintenance.address.reconcile': return exact(value, ['memberId', 'expectedMemberVersion', 'conflictingAddressId', 'winningEvidenceVersionId', 'winningEvidenceDigest', 'precedence', 'address', 'approvalId']) && string(value.memberId) && integer(value.expectedMemberVersion) && string(value.conflictingAddressId) && string(value.winningEvidenceVersionId) && string(value.winningEvidenceDigest) && string(value.precedence) && address(value.address) && string(value.approvalId);
    case 'maintenance.address.destination.update': return exact(value, ['memberId', 'context', 'targetId', 'addressId', 'evidenceVersionId', 'effectiveDate', 'expectedCurrentDestinationId', 'consentId', 'approvalId']) && string(value.memberId) && ['member-mailing', 'account-statement', 'card-shipping', 'loan-notice'].includes(String(value.context)) && string(value.targetId) && string(value.addressId) && string(value.evidenceVersionId) && string(value.effectiveDate) && nullableString(value.expectedCurrentDestinationId) && nullableString(value.consentId) && string(value.approvalId);
    case 'case.close': return exact(value, ['caseId', 'expectedVersion', 'resolutionCode', 'effectEvidenceVersionId']) && string(value.caseId) && integer(value.expectedVersion) && string(value.resolutionCode) && string(value.effectEvidenceVersionId);
    case 'case.reopen': return exact(value, ['caseId', 'expectedVersion', 'evidenceVersionId', 'reopeningBasis'], ['dueAt']) && string(value.caseId) && integer(value.expectedVersion) && string(value.evidenceVersionId) && string(value.reopeningBasis) && (value.dueAt === undefined || string(value.dueAt));
    case 'case.subject.correct': return exact(value, ['caseId', 'expectedVersion', 'correctMemberId', 'correctAccountId', 'evidenceVersionId', 'approvalId']) && string(value.caseId) && integer(value.expectedVersion) && string(value.correctMemberId) && nullableString(value.correctAccountId) && string(value.evidenceVersionId) && string(value.approvalId);
    case 'maintenance.draft.save': return exact(value, ['memberId', 'accountId', 'category', 'subject', 'requestedCommand', 'missingFields'], ['requestId', 'requestNumber', 'note', 'evidenceDocumentVersionIds']) && string(value.memberId) && nullableString(value.accountId) && string(value.category) && string(value.subject) && isMaintenanceRequestedCommand(value.requestedCommand) && strings(value.missingFields) && (value.requestId === undefined || string(value.requestId)) && (value.requestNumber === undefined || string(value.requestNumber)) && (value.note === undefined || string(value.note)) && (value.evidenceDocumentVersionIds === undefined || strings(value.evidenceDocumentVersionIds));
    case 'maintenance.draft.amend': return exact(value, ['requestId', 'expectedUpdatedAt', 'patch']) && string(value.requestId) && string(value.expectedUpdatedAt) && draftPatch(value.patch);
    case 'maintenance.request.submit': return exact(value, ['requestId', 'expectedUpdatedAt', 'declaredState']) && string(value.requestId) && string(value.expectedUpdatedAt) && value.declaredState === 'submitted';
    case 'maintenance.request.review': return exact(value, ['requestId', 'expectedUpdatedAt', 'decision', 'reason'], ['missingFields']) && string(value.requestId) && string(value.expectedUpdatedAt) && ['approve', 'reject', 'return-for-information'].includes(String(value.decision)) && string(value.reason) && (value.missingFields === undefined || strings(value.missingFields));
    case 'maintenance.request.process': return exact(value, ['requestId', 'expectedUpdatedAt', 'disposition', 'reason'], ['appliedReceiptId']) && string(value.requestId) && string(value.expectedUpdatedAt) && ['apply', 'reject'].includes(String(value.disposition)) && string(value.reason) && (value.appliedReceiptId === undefined || string(value.appliedReceiptId));
    case 'maintenance.request.withdraw': return exact(value, ['requestId', 'expectedUpdatedAt', 'reason']) && string(value.requestId) && string(value.expectedUpdatedAt) && string(value.reason);
    case 'document.annotation.update': return exact(value, ['documentVersionId', 'pageNumber', 'regionMicros', 'action'], ['annotationId', 'expectedAnnotationFingerprint', 'text']) && string(value.documentVersionId) && integer(value.pageNumber) && region(value.regionMicros) && ['create', 'amend', 'remove'].includes(String(value.action)) && (value.annotationId === undefined || string(value.annotationId)) && (value.expectedAnnotationFingerprint === undefined || string(value.expectedAnnotationFingerprint)) && (value.text === undefined || string(value.text));
    case 'document.metadata.update': return exact(value, ['documentId', 'expectedMetadata', 'documentType', 'displayName', 'ownerPartyId', 'accountId', 'retentionClass'], ['approvalId']) && string(value.documentId) && documentMetadata(value.expectedMetadata) && string(value.documentType) && string(value.displayName) && string(value.ownerPartyId) && nullableString(value.accountId) && string(value.retentionClass) && (value.approvalId === undefined || string(value.approvalId));
    case 'communication.preference.update': return exact(value, ['partyId', 'purpose', 'channel', 'state']) && string(value.partyId) && string(value.purpose) && string(value.channel) && ['enabled', 'disabled'].includes(String(value.state));
    case 'communication.send': return exact(value, ['partyId', 'channel', 'purpose', 'documentVersionId'], ['destination', 'addressDestinationId', 'jobId']) && string(value.partyId) && string(value.purpose) && string(value.documentVersionId) && (value.jobId === undefined || string(value.jobId))
      && ((value.channel === 'email' && string(value.destination) && value.addressDestinationId === undefined)
        || (value.channel === 'mail' && value.destination === undefined && string(value.addressDestinationId)));
    case 'communication.delivery.update': return exact(value, ['jobId', 'expectedState', 'action', 'detail']) && string(value.jobId) && ['queued', 'accepted'].includes(String(value.expectedState)) && ['accept', 'deliver', 'bounce', 'cancel'].includes(String(value.action)) && string(value.detail);
    default: return false;
  }
}

function documentMetadata(value: unknown): value is DocumentMetadataUpdateCommand['expectedMetadata'] {
  return record(value) && exact(value, ['ownerPartyId', 'accountId', 'documentType', 'displayName', 'retentionClass'])
    && string(value.ownerPartyId) && nullableString(value.accountId) && string(value.documentType) && string(value.displayName) && string(value.retentionClass);
}

function redactionExcerpts(value: unknown): value is DocumentBundleRedactCommand['approvedExcerpts'] {
  return Array.isArray(value) && value.every(item => record(item) && exact(item, ['sourceVersionId', 'text']) && string(item.sourceVersionId) && string(item.text));
}

function address(value: unknown): value is AddressInput {
  return record(value) && exact(value, ['line1', 'line2', 'city', 'region', 'postalCode', 'country']) && string(value.line1) && nullableString(value.line2) && string(value.city) && string(value.region) && string(value.postalCode) && string(value.country);
}

function region(value: unknown): value is DocumentAnnotationUpdateCommand['regionMicros'] {
  return record(value) && exact(value, ['x', 'y', 'width', 'height']) && integer(value.x) && integer(value.y) && integer(value.width) && integer(value.height);
}

function draftPatch(value: unknown): value is MaintenanceDraftAmendCommand['patch'] {
  if (!record(value) || !exact(value, [], ['subject', 'reason', 'note', 'requestedCommand', 'missingFields', 'evidenceVersionId', 'evidenceDocumentVersionIds'])) return false;
  return (value.subject === undefined || string(value.subject)) && (value.reason === undefined || nullableString(value.reason)) && (value.note === undefined || string(value.note))
    && (value.requestedCommand === undefined || isMaintenanceRequestedCommand(value.requestedCommand)) && (value.missingFields === undefined || strings(value.missingFields))
    && (value.evidenceVersionId === undefined || string(value.evidenceVersionId)) && (value.evidenceDocumentVersionIds === undefined || strings(value.evidenceDocumentVersionIds));
}

export function isMaintenanceRequestedCommand(value: unknown): value is MaintenanceRequestedCommand {
  if (!record(value) || !string(value.kind) || !MAINTENANCE_REQUESTED_COMMAND_KINDS.includes(value.kind as MaintenanceRequestedCommand['kind'])) return false;
  return validateCoreCommand(value) === null;
}
