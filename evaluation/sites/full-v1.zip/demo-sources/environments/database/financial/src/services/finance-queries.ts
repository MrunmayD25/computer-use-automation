import { createHash } from 'node:crypto';

import { all, authorizeQuery, canonicalJson, int, isIsoDate, one, optionalStr, reject, str, type Row } from './core.js';
import { parseFinanceCsv } from './finance-batch-files.js';
import { rowFingerprint, suspenseClearanceFacts } from './finance-support.js';
import { financeListRequiresScope, listFinanceRecords, type FinanceListInput, type FinanceListKind, type FinanceListResult } from './finance-lists.js';
import type { FinancialStore, SqlDatabase } from './store.js';
import type { Money, Rejection, ServiceContext } from './types.js';

export type FinanceRecordKind =
  | 'beneficiary' | 'beneficiary-route' | 'payment' | 'payment-schedule' | 'schedule-occurrence' | 'payment-return'
  | 'card' | 'card-transaction' | 'dispute' | 'loan' | 'interest-calculation' | 'fee' | 'hold' | 'restriction' | 'facility'
  | 'maturity-instruction' | 'received-funds' | 'transaction' | 'journal' | 'transfer' | 'settlement-batch' | 'suspense-item' | 'batch' | 'loan-closure';

export interface FinanceRecordSnapshot {
  kind: FinanceRecordKind;
  id: string;
  fingerprint: string;
  record: Record<string, unknown>;
  observedAt: string;
}

/** Resource discovery is implemented by `finance-lists`; these scope names preserve the UI's domain language at the transport edge. */
export interface FinanceListScope {
  memberId?: string;
  accountId?: string;
  caseId?: string;
  batchId?: string;
  scheduleId?: string;
  cardId?: string;
  paymentId?: string;
  beneficiaryId?: string;
  disputeId?: string;
  loanId?: string;
  settlementBatchId?: string;
  businessDate?: string;
}

export type FinanceQuery =
  | { kind: 'finance.record'; resource: FinanceRecordKind; id: string }
  | ({ kind: 'finance.records'; resource: FinanceListKind; scope?: FinanceListScope; limit: number; offset?: number }
    & Partial<Pick<FinanceListInput, 'memberId' | 'accountId' | 'parentId' | 'state' | 'query' | 'dateFrom' | 'dateThrough'>>)
  | { kind: 'reconciliation.transfer'; transferJournalId: string; expectedFingerprint: string }
  | { kind: 'reconciliation.settlement_batch'; settlementBatchId: string; expectedFingerprint: string; settlementFileDigest: string; cutoff: string }
  | { kind: 'batch.preview'; batchId: string; expectedFingerprint: string; inputDigest: string; schemaVersion: string; allowedMemberIds: readonly string[]; allowedAccountIds: readonly string[] }
  | { kind: 'reconciliation.cash_day'; businessDate: string; cashSessionIds: readonly string[]; declaredTotal: Money };

export type FinanceQueryResult =
  | { kind: 'found'; snapshot: FinanceRecordSnapshot }
  | Extract<FinanceListResult, { kind: 'listed' }>
  | { kind: 'reconciled'; data: Record<string, unknown> }
  | { kind: 'previewed'; data: Record<string, unknown> }
  | Rejection;

const FINANCE_RECORD_KINDS: readonly FinanceRecordKind[] = [
  'beneficiary', 'beneficiary-route', 'payment', 'payment-schedule', 'schedule-occurrence', 'payment-return',
  'card', 'card-transaction', 'dispute', 'loan', 'interest-calculation', 'fee', 'hold', 'restriction', 'facility',
  'maturity-instruction', 'received-funds', 'transaction', 'journal', 'transfer', 'settlement-batch', 'suspense-item', 'batch', 'loan-closure',
];

const FINANCE_SCOPE_TARGETS: Readonly<Record<keyof FinanceListScope, keyof FinanceListInput | 'businessDate'>> = {
  memberId: 'memberId', accountId: 'accountId', caseId: 'parentId', batchId: 'parentId', scheduleId: 'parentId', cardId: 'parentId',
  paymentId: 'parentId', beneficiaryId: 'parentId', disputeId: 'parentId', loanId: 'parentId', settlementBatchId: 'parentId', businessDate: 'businessDate',
};

type FinanceListScopeResult = Partial<FinanceListInput> | Rejection;

function mapFinanceListScope(scope: FinanceListScope | undefined): FinanceListScopeResult {
  const mapped: Partial<FinanceListInput> = {};
  for (const [key, value] of Object.entries(scope ?? {}) as [keyof FinanceListScope, string][]) {
    if (value === '') continue;
    const target = FINANCE_SCOPE_TARGETS[key];
    if (target === 'businessDate') {
      if (mapped.dateFrom !== undefined || mapped.dateThrough !== undefined) return reject('validation', 'A business date scope cannot be combined with date bounds.', { field: 'scope.businessDate' });
      mapped.dateFrom = value;
      mapped.dateThrough = value;
      continue;
    }
    if (mapped[target] !== undefined) return reject('validation', 'Only one parent scope may be provided.', { field: `scope.${key}` });
    Object.assign(mapped, { [target]: value });
  }
  return mapped;
}

function isRejection(value: FinanceListScopeResult): value is Rejection {
  return Object.hasOwn(value, 'kind') && (value as { kind: unknown }).kind === 'rejected';
}

const QUERY_REQUIRED: Readonly<Record<FinanceQuery['kind'], readonly string[]>> = {
  'finance.record': ['resource', 'id'],
  'finance.records': ['resource', 'limit'],
  'reconciliation.transfer': ['transferJournalId', 'expectedFingerprint'],
  'reconciliation.settlement_batch': ['settlementBatchId', 'expectedFingerprint', 'settlementFileDigest', 'cutoff'],
  'batch.preview': ['batchId', 'expectedFingerprint', 'inputDigest', 'schemaVersion', 'allowedMemberIds', 'allowedAccountIds'],
  'reconciliation.cash_day': ['businessDate', 'cashSessionIds', 'declaredTotal'],
};

function inputRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function exactMoney(value: unknown): boolean {
  return inputRecord(value)
    && Object.keys(value).sort().join(',') === 'currency,minorUnits'
    && typeof value.currency === 'string'
    && Number.isSafeInteger(value.minorUnits);
}

/** Rejects malformed or over-posted finance inquiry input at the public service boundary. */
export function validateFinanceQuery(value: unknown): Rejection | null {
  if (!inputRecord(value) || typeof value.kind !== 'string' || !Object.hasOwn(QUERY_REQUIRED, value.kind)) return reject('validation', 'Unknown finance query kind.', { field: 'kind' });
  const kind = value.kind as FinanceQuery['kind'];
  const required = QUERY_REQUIRED[kind];
  const allowed = new Set(['kind', ...required,
    ...(kind === 'finance.records' ? ['scope', 'offset', 'memberId', 'accountId', 'parentId', 'state', 'query', 'dateFrom', 'dateThrough'] : [])]);
  const unknown = Object.keys(value).find((field) => !allowed.has(field));
  if (unknown !== undefined) return reject('validation', `Unknown field ${unknown} for ${kind}.`, { field: unknown });
  const missing = required.find((field) => !(field in value));
  if (missing !== undefined) return reject('validation', `Missing required field ${missing}.`, { field: missing });
  for (const [field, candidate] of Object.entries(value)) {
    if (field === 'kind') continue;
    if (field === 'declaredTotal') {
      if (!exactMoney(candidate)) return reject('validation', 'declaredTotal must be an exact Money object.', { field });
    } else if (field === 'allowedMemberIds' || field === 'allowedAccountIds' || field === 'cashSessionIds') {
      if (!Array.isArray(candidate) || candidate.some((item) => typeof item !== 'string')) return reject('validation', `${field} must be an array of strings.`, { field });
    } else if (field === 'resource') {
      if (typeof candidate !== 'string' || kind !== 'finance.records' && !FINANCE_RECORD_KINDS.includes(candidate as FinanceRecordKind)) return reject('validation', 'Unknown finance record kind.', { field });
    } else if (kind === 'finance.records' && field === 'scope') {
      if (!inputRecord(candidate)) return reject('validation', 'scope must be an object.', { field });
      const allowedScope = new Set(['memberId','accountId','caseId','batchId','scheduleId','cardId','paymentId','beneficiaryId','disputeId','loanId','settlementBatchId','businessDate']);
      const unknownScope = Object.keys(candidate).find((key) => !allowedScope.has(key));
      if (unknownScope !== undefined) return reject('validation', `Unknown scope field ${unknownScope}.`, { field: `scope.${unknownScope}` });
      if (Object.values(candidate).some((entry) => typeof entry !== 'string')) return reject('validation', 'scope values must be text.', { field: 'scope' });
    } else if (kind === 'finance.records' && (field === 'limit' || field === 'offset')) {
      if (!Number.isSafeInteger(candidate) || field === 'limit' && (Number(candidate) < 1 || Number(candidate) > 500) || field === 'offset' && (Number(candidate) < 0 || Number(candidate) > 1_000_000)) return reject('validation', `${field} must be a bounded integer.`, { field });
    } else if (kind === 'finance.records' && ['memberId','accountId','parentId','state','query','dateFrom','dateThrough'].includes(field)) {
      if (typeof candidate !== 'string') return reject('validation', `${field} must be text.`, { field });
    } else if (typeof candidate !== 'string') return reject('validation', `${field} must be text.`, { field });
  }
  return null;
}

const READ_GRANTS = ['read','maintain','payment.prepare','payment.approve','supervise','case.manage'] as const;

function authorized<T>(store: FinancialStore, context: ServiceContext, read: (database: SqlDatabase, observedAt: string) => T): T | Rejection {
  return store.read((database) => {
    const denied = authorizeQuery(database, context, READ_GRANTS);
    if (denied !== null) return denied;
    const observedAt = context.now ?? str(one(database, 'SELECT as_of FROM datasets WHERE id=?', context.binding.datasetId), 'as_of');
    return read(database, observedAt);
  });
}

function withChildren(row: Row | undefined, children: Record<string, Row[]>): Row | undefined {
  if (row === undefined) return undefined;
  return { ...row, ...Object.fromEntries(Object.entries(children).map(([key, values]) => [key, canonicalJson(values)])) };
}

function financeRecordLimit(database: SqlDatabase, datasetId: string, kind: FinanceRecordKind, id: string): Rejection | null {
  if (kind === 'transfer') {
    const count = int(one(database, 'SELECT COUNT(*) AS count FROM journal_lines WHERE dataset_id=? AND journal_id=?', datasetId, id), 'count');
    if (count > 100) return reject('limit_exceeded', 'The transfer has more than 100 journal lines and cannot be snapshotted safely.');
  }
  if (kind === 'settlement-batch') {
    const count = int(one(database, 'SELECT COUNT(*) AS count FROM settlement_items WHERE dataset_id=? AND settlement_batch_id=?', datasetId, id), 'count');
    if (count > 500) return reject('limit_exceeded', 'The settlement batch has more than 500 items and cannot be snapshotted safely.');
  }
  return null;
}

function financeRow(database: SqlDatabase, datasetId: string, kind: FinanceRecordKind, id: string): { row: Row; columns: readonly string[]; publicRecord?: Record<string, unknown> } | undefined {
  switch (kind) {
    case 'beneficiary': {
      const row = one(database, 'SELECT id,owner_party_id,display_name,status FROM beneficiaries WHERE dataset_id=? AND id=?', datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','owner_party_id','display_name','status'] };
    }
    case 'beneficiary-route': {
      const row = one(database, `SELECT r.id,r.beneficiary_id,r.version,r.routing_kind,r.masked_destination,r.simulated_token,r.status,r.verified_at,r.expires_at,b.owner_party_id,b.status AS beneficiary_status
        FROM beneficiary_routes r JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id WHERE r.dataset_id=? AND r.id=?`, datasetId, id);
      if (row === undefined) return undefined;
      return { row, columns: ['id','beneficiary_id','version','routing_kind','masked_destination','simulated_token','status','verified_at','expires_at','owner_party_id','beneficiary_status'], publicRecord: Object.fromEntries(Object.entries(row).filter(([key]) => key !== 'simulated_token')) };
    }
    case 'payment': {
      const row = one(database, `SELECT p.id,p.reference,p.source_account_id,p.beneficiary_route_id,p.amount_minor_units,p.currency,p.requested_date,p.state,p.version,
        r.status AS route_status,r.expires_at AS route_expires_at,b.status AS beneficiary_status FROM payments p JOIN beneficiary_routes r ON r.dataset_id=p.dataset_id AND r.id=p.beneficiary_route_id
        JOIN beneficiaries b ON b.dataset_id=r.dataset_id AND b.id=r.beneficiary_id WHERE p.dataset_id=? AND p.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: Object.keys(row) };
    }
    case 'payment-schedule': {
      const row = one(database, 'SELECT id,source_account_id,beneficiary_route_id,rule_json,time_zone,calendar_version,start_date,end_date,state FROM payment_schedules WHERE dataset_id=? AND id=?', datasetId, id);
      if (row === undefined) return undefined;
      const occurrences = all(database, 'SELECT id,local_date,payment_id,state FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? ORDER BY local_date,id', datasetId, id);
      return { row: { ...row, occurrence_inventory: canonicalJson(occurrences) }, columns: ['id','source_account_id','beneficiary_route_id','rule_json','time_zone','calendar_version','start_date','end_date','state','occurrence_inventory'] };
    }
    case 'schedule-occurrence': {
      const row = one(database, `SELECT o.id,o.schedule_id,o.local_date,o.payment_id,o.state,s.source_account_id,s.beneficiary_route_id,s.rule_json,s.state AS schedule_state,
        p.state AS payment_state,p.version AS payment_version,p.amount_minor_units AS payment_amount_minor_units,p.currency AS payment_currency,p.requested_date AS payment_requested_date
        FROM schedule_occurrences o JOIN payment_schedules s ON s.dataset_id=o.dataset_id AND s.id=o.schedule_id
        LEFT JOIN payments p ON p.dataset_id=o.dataset_id AND p.id=o.payment_id WHERE o.dataset_id=? AND o.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','schedule_id','local_date','payment_id','state','source_account_id','beneficiary_route_id','rule_json','schedule_state','payment_state','payment_version','payment_amount_minor_units','payment_currency','payment_requested_date'] };
    }
    case 'payment-return': {
      const row = one(database, `SELECT r.id,r.payment_id,r.return_code,r.amount_minor_units,r.occurred_at,r.settlement_reference,
        p.source_account_id,p.amount_minor_units AS payment_amount_minor_units,p.currency,p.reference,p.state,p.version AS payment_version,a.version AS account_version
        FROM payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id
        JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE r.dataset_id=? AND r.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','payment_id','return_code','amount_minor_units','occurred_at','settlement_reference','source_account_id','payment_amount_minor_units','currency','reference','state','payment_version','account_version'] };
    }
    case 'card': {
      const row = one(database, `SELECT c.id,c.account_id,c.last_four,c.expiry_month,c.expiry_year,c.status,a.member_id,a.currency,a.status AS account_status
        FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? AND c.id=?`, datasetId, id);
      if (row === undefined) return undefined;
      const limits = all(database, 'SELECT id,kind,amount_minor_units,currency,effective_at,expires_at FROM card_limits WHERE dataset_id=? AND card_id=? ORDER BY effective_at,id', datasetId, id);
      const locks = all(database, 'SELECT id,kind,authority,state,placed_at,released_at FROM card_locks WHERE dataset_id=? AND card_id=? ORDER BY placed_at,id', datasetId, id);
      const replacementOrders = all(database, 'SELECT id,address_id,state,requested_at FROM card_replacement_orders WHERE dataset_id=? AND card_id=? ORDER BY requested_at,id', datasetId, id);
      return { row: { ...row, limits: canonicalJson(limits), locks: canonicalJson(locks), replacement_orders: canonicalJson(replacementOrders) }, columns: ['id','account_id','last_four','expiry_month','expiry_year','status','member_id','currency','account_status','limits','locks','replacement_orders'] };
    }
    case 'card-transaction': {
      const row = one(database, `SELECT t.id,t.card_id,t.journal_id,t.amount_minor_units,t.currency,t.state,c.account_id,a.member_id FROM card_transactions t
        JOIN cards c ON c.dataset_id=t.dataset_id AND c.id=t.card_id JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE t.dataset_id=? AND t.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','card_id','journal_id','amount_minor_units','currency','state','account_id','member_id'] };
    }
    case 'dispute': {
      const row = one(database, `SELECT d.id,d.case_number,d.account_id,d.journal_id,d.claimed_amount_minor_units,d.currency,d.state,d.deadline,
        COALESCE((SELECT SUM(CASE kind WHEN 'provisional' THEN amount_minor_units WHEN 'final' THEN amount_minor_units ELSE -amount_minor_units END) FROM dispute_credits c WHERE c.dataset_id=d.dataset_id AND c.dispute_id=d.id),0) AS net_credit
        FROM disputes d WHERE d.dataset_id=? AND d.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','case_number','account_id','journal_id','claimed_amount_minor_units','currency','state','deadline','net_credit'] };
    }
    case 'loan': {
      const base = one(database, `SELECT l.id,l.account_id,l.application_id,l.principal_minor_units,l.currency,l.annual_rate_bps,l.state,l.opened_at,a.member_id,a.status AS account_status
        FROM loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id WHERE l.dataset_id=? AND l.id=?`, datasetId, id);
      const row = withChildren(base, {
        components: all(database, 'SELECT id,kind,ledger_account_id,balance_minor_units FROM loan_components WHERE dataset_id=? AND loan_id=? ORDER BY kind,id', datasetId, id),
        obligations: all(database, 'SELECT id,kind,state,due_at FROM loan_obligations WHERE dataset_id=? AND loan_id=? ORDER BY id', datasetId, id),
      });
      return row === undefined ? undefined : { row, columns: ['id','account_id','application_id','principal_minor_units','currency','annual_rate_bps','state','opened_at','member_id','account_status','components','obligations'] };
    }
    case 'interest-calculation': {
      const row = one(database, `SELECT id,account_id,policy_version_id,period_start,period_end,calculated_interest_minor_units,booked_interest_minor_units,delta_minor_units,original_journal_id,adjustment_journal_id,state
        FROM interest_calculations WHERE dataset_id=? AND id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: Object.keys(row) };
    }
    case 'fee': {
      const row = one(database, `SELECT f.id,f.account_id,f.journal_id,f.original_amount_minor_units,f.currency,f.policy_version_id,f.status,
        COALESCE((SELECT SUM(r.amount_minor_units) FROM fee_refunds r WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id),0) AS refunded FROM fees f WHERE f.dataset_id=? AND f.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','account_id','journal_id','original_amount_minor_units','currency','policy_version_id','status','refunded'] };
    }
    case 'hold': {
      const row = one(database, `SELECT h.id,h.account_id,h.amount_minor_units,h.status,h.reason,h.release_authority,h.placed_at,h.expires_at,h.released_at,
        COALESCE((SELECT SUM(r.amount_minor_units) FROM hold_releases r WHERE r.dataset_id=h.dataset_id AND r.hold_id=h.id),0) AS released_minor_units
        FROM holds h WHERE h.dataset_id=? AND h.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','account_id','amount_minor_units','status','reason','release_authority','placed_at','expires_at','released_at','released_minor_units'] };
    }
    case 'restriction': {
      const row = one(database, 'SELECT id,account_id,kind,status,authority,placed_at,released_at FROM restrictions WHERE dataset_id=? AND id=?', datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','account_id','kind','status','authority','placed_at','released_at'] };
    }
    case 'facility': {
      const base = one(database, 'SELECT id,account_id,kind,limit_minor_units,used_minor_units,status FROM facilities WHERE dataset_id=? AND id=?', datasetId, id);
      const row = withChildren(base, {
        terms: all(database, 'SELECT id,limit_minor_units,effective_at,expires_at,operation_id FROM facility_limit_terms WHERE dataset_id=? AND facility_id=? ORDER BY effective_at,id', datasetId, id),
      });
      return row === undefined ? undefined : { row, columns: ['id','kind','limit_minor_units','used_minor_units','status','terms'] };
    }
    case 'maturity-instruction': {
      const row = one(database, 'SELECT id,account_id,destination_account_id,disposition,terms_json,state,cutoff_at,version FROM maturity_instructions WHERE dataset_id=? AND id=?', datasetId, id);
      return row === undefined ? undefined : { row, columns: Object.keys(row) };
    }
    case 'received-funds': {
      const row = one(database, `SELECT f.id,f.reference,f.member_id,f.currency,f.amount_minor_units,f.source_journal_id,f.state,f.received_at,
        COALESCE((SELECT SUM(u.amount_minor_units) FROM received_funds_uses u WHERE u.dataset_id=f.dataset_id AND u.received_funds_id=f.id),0) AS allocated_minor_units,
        f.amount_minor_units-COALESCE((SELECT SUM(u.amount_minor_units) FROM received_funds_uses u WHERE u.dataset_id=f.dataset_id AND u.received_funds_id=f.id),0) AS remaining_minor_units
        FROM received_funds f WHERE f.dataset_id=? AND f.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','reference','member_id','currency','amount_minor_units','source_journal_id','state','received_at','allocated_minor_units','remaining_minor_units'] };
    }
    case 'transaction': {
      const row = one(database, `SELECT j.id,j.reference,j.status,j.posted_at,j.effective_date,j.description,
        (SELECT new_description FROM transaction_amendments a WHERE a.dataset_id=j.dataset_id AND a.journal_id=j.id ORDER BY amended_at DESC,id DESC LIMIT 1) AS display_description,
        COALESCE((SELECT new_effective_date FROM effective_date_corrections c WHERE c.dataset_id=j.dataset_id AND c.journal_id=j.id ORDER BY corrected_at DESC,id DESC LIMIT 1),j.effective_date) AS display_effective_date
        FROM journals j WHERE j.dataset_id=? AND j.id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','reference','status','posted_at','effective_date','description','display_description','display_effective_date'] };
    }
    case 'journal': {
      const base = one(database, `SELECT j.id,j.reference,j.operation_id,j.status,j.posted_at,j.effective_date,j.description,j.reversal_of_id,o.operation_kind
        FROM journals j LEFT JOIN operations o ON o.dataset_id=j.dataset_id AND o.id=j.operation_id WHERE j.dataset_id=? AND j.id=?`, datasetId, id);
      const row = withChildren(base, {
        lines: all(database, `SELECT l.line_number,l.ledger_account_id,l.currency,l.debit_minor_units,l.credit_minor_units,la.kind,la.customer_account_id
          FROM journal_lines l JOIN ledger_accounts la ON la.dataset_id=l.dataset_id AND la.id=l.ledger_account_id WHERE l.dataset_id=? AND l.journal_id=? ORDER BY l.line_number`, datasetId, id),
        corrections: all(database, `SELECT id,old_effective_date,new_effective_date,policy_version_id,policy_period_start,policy_period_end,reason,corrected_at
          FROM effective_date_corrections WHERE dataset_id=? AND journal_id=? ORDER BY corrected_at,id`, datasetId, id),
      });
      return row === undefined ? undefined : { row, columns: ['id','reference','operation_id','status','posted_at','effective_date','description','reversal_of_id','operation_kind','lines','corrections'] };
    }
    case 'transfer': {
      const base = one(database, `SELECT j.id,j.reference,j.status,j.effective_date,j.operation_id,o.operation_kind,r.receipt_number FROM journals j
        JOIN operations o ON o.dataset_id=j.dataset_id AND o.id=j.operation_id JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id
        WHERE j.dataset_id=? AND j.id=?`, datasetId, id);
      const row = withChildren(base, { lines: all(database, `SELECT l.line_number,l.ledger_account_id,l.currency,l.debit_minor_units,l.credit_minor_units,la.customer_account_id
        FROM journal_lines l JOIN ledger_accounts la ON la.dataset_id=l.dataset_id AND la.id=l.ledger_account_id WHERE l.dataset_id=? AND l.journal_id=? ORDER BY l.line_number LIMIT 100`, datasetId, id) });
      return row === undefined ? undefined : { row, columns: ['id','reference','status','effective_date','operation_id','operation_kind','receipt_number','lines'] };
    }
    case 'settlement-batch': {
      const base = one(database, 'SELECT id,reference,currency,declared_total_minor_units,state,cutoff_at FROM settlement_batches WHERE dataset_id=? AND id=?', datasetId, id);
      const row = withChildren(base, { items: all(database, 'SELECT id,payment_id,amount_minor_units,state FROM settlement_items WHERE dataset_id=? AND settlement_batch_id=? ORDER BY id LIMIT 500', datasetId, id) });
      return row === undefined ? undefined : { row, columns: ['id','reference','currency','declared_total_minor_units','state','cutoff_at','items'] };
    }
    case 'suspense-item': {
      const row = one(database, `SELECT s.id,s.journal_id,s.original_amount_minor_units,s.remaining_amount_minor_units,s.currency,s.state,s.evidence_reference,
        (SELECT id FROM ledger_accounts la WHERE la.dataset_id=s.dataset_id AND la.kind='suspense' AND EXISTS (SELECT 1 FROM journal_lines jl WHERE jl.dataset_id=la.dataset_id AND jl.journal_id=s.journal_id AND jl.ledger_account_id=la.id) LIMIT 1) AS suspense_ledger_id
        FROM suspense_items s WHERE s.dataset_id=? AND s.id=?`, datasetId, id);
      if (row === undefined) return undefined;
      const clearanceInventory = canonicalJson(suspenseClearanceFacts(database, datasetId, id, str(row, 'evidence_reference')));
      return { row: { ...row, clearance_inventory: clearanceInventory }, columns: ['id','journal_id','original_amount_minor_units','remaining_amount_minor_units','currency','state','evidence_reference','suspense_ledger_id','clearance_inventory'] };
    }
    case 'batch': {
      const base = one(database, 'SELECT id,batch_number,kind,input_document_version_id,input_digest,state,approved_total_limit_minor_units,currency,created_at FROM batches WHERE dataset_id=? AND id=?', datasetId, id);
      const row = withChildren(base, { items: all(database, 'SELECT id,ordinal,source_key,item_json,state,receipt_id,amount_minor_units,failure_code FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal,id', datasetId, id) });
      return row === undefined ? undefined : { row, columns: ['id','batch_number','kind','input_document_version_id','input_digest','state','approved_total_limit_minor_units','currency','created_at','items'] };
    }
    case 'loan-closure': {
      const row = one(database, `SELECT c.id,c.loan_id,c.receipt_id,c.closed_at,c.closure_document_version_id,l.account_id,a.member_id,m.party_id FROM loan_closures c
        JOIN loans l ON l.dataset_id=c.dataset_id AND l.id=c.loan_id JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id
        JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id WHERE c.dataset_id=? AND c.loan_id=?`, datasetId, id);
      return row === undefined ? undefined : { row, columns: ['id','loan_id','receipt_id','closed_at','closure_document_version_id','account_id','member_id','party_id'] };
    }
  }
}

/** Reads one finance record through an actor/institution binding and returns an opaque stale-edit fingerprint. */
export function readFinanceRecord(store: FinancialStore, context: ServiceContext, resource: FinanceRecordKind, id: string): FinanceQueryResult {
  return authorized(store, context, (database, observedAt) => {
    const overflow = financeRecordLimit(database, context.binding.datasetId, resource, id);
    if (overflow !== null) return overflow;
    const found = financeRow(database, context.binding.datasetId, resource, id);
    if (found === undefined) return reject('not_found', `The ${resource} record does not exist at this institution.`);
    return { kind: 'found' as const, snapshot: { kind: resource, id, fingerprint: rowFingerprint(found.row, found.columns), record: found.publicRecord ?? found.row, observedAt } };
  });
}

function reconcileTransferRead(database: SqlDatabase, datasetId: string, query: Extract<FinanceQuery, { kind: 'reconciliation.transfer' }>): FinanceQueryResult {
  const overflow = financeRecordLimit(database, datasetId, 'transfer', query.transferJournalId);
  if (overflow !== null) return overflow;
  const found = financeRow(database, datasetId, 'transfer', query.transferJournalId);
  if (found === undefined) return reject('not_found', 'The transfer and its receipt do not exist.');
  if (rowFingerprint(found.row, found.columns) !== query.expectedFingerprint) return reject('stale_version', 'The transfer evidence changed after review.');
  const lines = JSON.parse(str(found.row, 'lines')) as Record<string, unknown>[];
  const debit = lines.find((line) => Number(line.debit_minor_units) > 0);
  const credit = lines.find((line) => Number(line.credit_minor_units) > 0);
  if (str(found.row, 'operation_kind') !== 'transfer.internal' || lines.length !== 2 || debit === undefined || credit === undefined
    || debit.customer_account_id === null || credit.customer_account_id === null || debit.customer_account_id === credit.customer_account_id
    || debit.debit_minor_units !== credit.credit_minor_units || debit.currency !== credit.currency) {
    return reject('ineligible', 'The internal transfer pair is incomplete or unbalanced.');
  }
  return { kind: 'reconciled', data: { transferJournalId: query.transferJournalId, journalReference: str(found.row, 'reference'), receiptNumber: str(found.row, 'receipt_number'), sourceAccountId: debit.customer_account_id, destinationAccountId: credit.customer_account_id, amountMinorUnits: debit.debit_minor_units, currency: debit.currency, reconciled: true, writes: 0 } };
}

function reconcileSettlementRead(database: SqlDatabase, datasetId: string, query: Extract<FinanceQuery, { kind: 'reconciliation.settlement_batch' }>): FinanceQueryResult {
  const overflow = financeRecordLimit(database, datasetId, 'settlement-batch', query.settlementBatchId);
  if (overflow !== null) return overflow;
  const found = financeRow(database, datasetId, 'settlement-batch', query.settlementBatchId);
  if (found === undefined) return reject('not_found', 'The settlement batch does not exist.');
  if (rowFingerprint(found.row, found.columns) !== query.expectedFingerprint) return reject('stale_version', 'The settlement batch changed after review.');
  if (str(found.row, 'state') !== 'final' || query.cutoff !== str(found.row, 'cutoff_at')) return reject('ineligible', 'Only the exact final settlement cutoff may be reconciled.');
  if (!/^[a-f0-9]{64}$/u.test(query.settlementFileDigest)) return reject('validation', 'Settlement file digest must be lowercase SHA-256.');
  const file = one(database, `SELECT blob.bytes FROM batches input
    JOIN document_versions version ON version.dataset_id=input.dataset_id AND version.id=input.input_document_version_id
    JOIN document_blobs blob ON blob.dataset_id=version.dataset_id AND blob.digest=version.digest
    WHERE input.dataset_id=? AND input.kind='settlement' AND input.batch_number=? AND input.input_digest=?
      AND version.digest=input.input_digest AND version.status IN ('current','signed')
    ORDER BY input.id LIMIT 1`, datasetId, str(found.row, 'reference'), query.settlementFileDigest);
  const bytes = file?.bytes;
  if (!(bytes instanceof Uint8Array) || createHash('sha256').update(bytes).digest('hex') !== query.settlementFileDigest) {
    return reject('ineligible', 'The digest does not identify this settlement batch\'s stored immutable file.');
  }
  const items = JSON.parse(str(found.row, 'items')) as { id: string; payment_id: string | null; amount_minor_units: number; state: string }[];
  const fileRows = parseFinanceCsv(bytes);
  const fileHeader = fileRows?.[0];
  const amountIndex = fileHeader?.indexOf('amount_minor_units') ?? -1;
  const stateIndex = fileHeader?.indexOf('state') ?? -1;
  if (fileRows === null || amountIndex < 0 || stateIndex < 0 || fileRows.length - 1 !== items.length) return reject('ineligible', 'The stored settlement file schema or row count differs from the final batch.');
  const fileFacts = fileRows.slice(1).map(row => ({ amount: Number(row[amountIndex]), state: row[stateIndex] })).sort((left, right) => left.amount - right.amount || String(left.state).localeCompare(String(right.state)));
  const itemFacts = items.map(item => ({ amount: item.amount_minor_units, state: item.state })).sort((left, right) => left.amount - right.amount || left.state.localeCompare(right.state));
  if (fileFacts.some(item => !Number.isSafeInteger(item.amount) || typeof item.state !== 'string') || canonicalJson(fileFacts) !== canonicalJson(itemFacts)) return reject('stale_version', 'The immutable settlement file rows differ from the final batch items.');
  let calculated = 0;
  for (const item of items) {
    if (!Number.isSafeInteger(item.amount_minor_units)) return reject('validation', 'Settlement item amounts exceed exact minor-unit capacity.');
    const delta = ['accepted','settled'].includes(item.state) ? item.amount_minor_units : item.state === 'returned' ? -item.amount_minor_units : 0;
    const next = calculated + delta;
    if (!Number.isSafeInteger(next)) return reject('validation', 'Settlement control totals exceed exact minor-unit capacity.');
    calculated = next;
  }
  const exceptions = items.filter((item) => ['rejected','duplicate'].includes(item.state)).map(({ id, state }) => ({ id, state }));
  return { kind: 'reconciled', data: { settlementBatchId: query.settlementBatchId, declaredTotalMinorUnits: int(found.row, 'declared_total_minor_units'), calculatedTotalMinorUnits: calculated, currency: str(found.row, 'currency'), matched: calculated === int(found.row, 'declared_total_minor_units'), exceptions, settlementFileDigest: query.settlementFileDigest, writes: 0 } };
}

function previewBatchRead(database: SqlDatabase, datasetId: string, query: Extract<FinanceQuery, { kind: 'batch.preview' }>): FinanceQueryResult {
  const found = financeRow(database, datasetId, 'batch', query.batchId);
  if (found === undefined) return reject('not_found', 'The batch does not exist.');
  if (rowFingerprint(found.row, found.columns) !== query.expectedFingerprint) return reject('stale_version', 'The batch changed after review.');
  if (query.inputDigest !== str(found.row, 'input_digest')) return reject('stale_version', 'The input digest differs from the uploaded batch.');
  if (query.schemaVersion !== '1') return reject('validation', 'Only batch schema version 1 is supported.');
  if (query.allowedMemberIds.length > 500 || query.allowedAccountIds.length > 500) return reject('limit_exceeded', 'Preview scope exceeds 500 members or accounts.');
  const document = one(database, `SELECT v.digest,v.media_type,b.bytes,b.byte_length FROM document_versions v
    JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
    WHERE v.dataset_id=? AND v.id=?`, datasetId, str(found.row, 'input_document_version_id'));
  const bytes = document?.bytes;
  if (!(bytes instanceof Uint8Array) || str(document, 'digest') !== query.inputDigest || str(document, 'media_type') !== 'text/csv'
    || int(document, 'byte_length') !== bytes.byteLength || createHash('sha256').update(bytes).digest('hex') !== query.inputDigest) {
    return reject('ineligible', 'The batch input is not backed by the exact stored immutable CSV bytes.');
  }
  const csv = parseFinanceCsv(bytes);
  if (csv === null) return reject('validation', 'The stored batch file is not valid CSV.');
  const header = csv[0];
  if (header === undefined || new Set(header).size !== header.length) return reject('validation', 'The stored batch file has an invalid header.');
  const supportedHeaders = [
    ['member_id','email'], ['member_id','phone'], ['member_id','email','phone'], ['source_key','member_id','email'], ['source_key','member_id','phone'], ['source_key','member_id','email','phone'],
    ['fee_id','amount_minor_units','currency'], ['source_key','fee_id','amount_minor_units','currency'],
    ['source_key','member_id','account_id','amount_minor_units','currency'],
  ];
  if (!supportedHeaders.some((candidate) => canonicalJson(candidate) === canonicalJson(header))) return reject('validation', 'The stored batch file does not use a supported schema version 1 layout.');
  const column = (source: readonly string[], name: string): string | undefined => {
    const index = header.indexOf(name);
    return index < 0 ? undefined : source[index];
  };
  const items = JSON.parse(str(found.row, 'items')) as { id: string; ordinal: number; source_key: string; item_json: string; state: string; amount_minor_units: number | null; failure_code: string | null }[];
  const sourceRows = csv.slice(1);
  if (sourceRows.length !== items.length) return reject('stale_version', 'Stored batch rows differ from the immutable input file.');
  const parsedItems = items.map((item, index) => {
    const source = sourceRows[index];
    if (source === undefined || source.length !== header.length) return null;
    let value: unknown;
    try { value = JSON.parse(item.item_json) as unknown; } catch { return null; }
    if (!inputRecord(value)) return null;
    const sourceKey = column(source, 'source_key') ?? column(source, 'member_id') ?? column(source, 'fee_id');
    const memberId = column(source, 'member_id');
    const accountId = column(source, 'account_id');
    const feeId = column(source, 'fee_id');
    const amountText = column(source, 'amount_minor_units');
    const currency = column(source, 'currency');
    const email = column(source, 'email');
    const phone = column(source, 'phone');
    if (sourceKey !== item.source_key
      || memberId !== undefined && value.memberId !== memberId
      || accountId !== undefined && value.accountId !== accountId
      || feeId !== undefined && value.feeId !== feeId
      || amountText !== undefined && (!/^-?\d+$/u.test(amountText) || Number(amountText) !== item.amount_minor_units || value.amountMinorUnits !== Number(amountText))
      || currency !== undefined && value.currency !== currency
      || email !== undefined && value.email !== email
      || phone !== undefined && value.phone !== phone) return null;
    const feeOwner = feeId === undefined ? undefined : one(database, `SELECT f.account_id,a.member_id
      FROM fees f JOIN accounts a ON a.dataset_id=f.dataset_id AND a.id=f.account_id
      WHERE f.dataset_id=? AND f.id=?`, datasetId, feeId);
    return {
      item,
      memberId: memberId ?? optionalStr(feeOwner, 'member_id') ?? '',
      accountId: accountId ?? optionalStr(feeOwner, 'account_id') ?? '',
      unresolvedFee: feeId !== undefined && feeOwner === undefined,
    };
  });
  if (parsedItems.some((item) => item === null)) return reject('stale_version', 'Stored batch items differ from the immutable input file.');
  const seen = new Set<string>();
  const results = parsedItems.map((parsed) => {
    if (parsed === null) throw new Error('Batch rows were validated above.');
    const { item, memberId, accountId, unresolvedFee } = parsed;
    if (['invalid','duplicate','stale','out-of-scope'].includes(item.state)) return { id: item.id, state: item.state, reason: item.failure_code };
    if (seen.has(item.source_key)) return { id: item.id, state: 'duplicate', reason: 'duplicate-source-key' };
    seen.add(item.source_key);
    if (unresolvedFee || memberId !== '' && !query.allowedMemberIds.includes(memberId) || accountId !== '' && !query.allowedAccountIds.includes(accountId)) return { id: item.id, state: 'out-of-scope', reason: 'scope' };
    return { id: item.id, state: 'valid', reason: null };
  });
  return { kind: 'previewed', data: { batchId: query.batchId, inputDigest: query.inputDigest, total: results.length, valid: results.filter((item) => item.state === 'valid').length, items: results, writes: 0 } };
}

function reconcileCashRead(database: SqlDatabase, datasetId: string, query: Extract<FinanceQuery, { kind: 'reconciliation.cash_day' }>): FinanceQueryResult {
  if (!isIsoDate(query.businessDate) || query.cashSessionIds.length === 0 || query.cashSessionIds.length > 100 || new Set(query.cashSessionIds).size !== query.cashSessionIds.length) return reject('validation', 'Cash day requires a valid date and 1 to 100 distinct session IDs.');
  const placeholders = query.cashSessionIds.map(() => '?').join(',');
  const sessions = all(database, `SELECT s.id,s.actor_id,s.business_date,s.state,s.opened_at,s.closed_at,d.declared_minor_units,d.counted_minor_units,d.currency FROM cash_sessions s
    JOIN cash_declarations d ON d.dataset_id=s.dataset_id AND d.cash_session_id=s.id WHERE s.dataset_id=? AND s.id IN (${placeholders}) ORDER BY s.id`, datasetId, ...query.cashSessionIds);
  if (sessions.length !== query.cashSessionIds.length) return reject('not_found', 'One or more cash sessions do not exist.');
  if (sessions.some((row) => str(row, 'business_date') !== query.businessDate || str(row, 'state') === 'open')) return reject('ineligible', 'Every selected cash session must be closed for the requested date.');
  if (sessions.some((row) => str(row, 'currency') !== query.declaredTotal.currency)) return reject('currency_mismatch', 'Cash declaration currencies differ.');
  if (sessions.some((session) => typeof session.closed_at !== 'string' || str(session, 'opened_at') >= str(session, 'closed_at'))) return reject('ineligible', 'Every selected cash session must have a valid closed time window.');
  for (const [index, session] of sessions.entries()) {
    const closedAt = str(session, 'closed_at');
    if (sessions.slice(index + 1).some((other) => str(other, 'actor_id') === str(session, 'actor_id')
      && str(other, 'currency') === str(session, 'currency') && str(session, 'opened_at') < str(other, 'closed_at')
      && str(other, 'opened_at') < closedAt)) return reject('ineligible', 'Selected cash sessions for one teller and currency must not overlap.');
  }
  let declared = 0;
  for (const session of sessions) {
    const next = declared + int(session, 'declared_minor_units');
    if (!Number.isSafeInteger(next)) return reject('validation', 'Cash declaration totals exceed exact minor-unit capacity.');
    declared = next;
  }
  if (declared !== query.declaredTotal.minorUnits) return reject('validation', 'Supplied control does not equal selected session declarations.');
  const movements = sessions.map((session) => {
    const actorId = str(session, 'actor_id');
    const row = one(database, `SELECT COALESCE(SUM(CASE o.operation_kind WHEN 'cash.deposit' THEN jl.debit_minor_units WHEN 'cash.withdraw' THEN -jl.credit_minor_units ELSE 0 END),0) AS net
      FROM operations o JOIN journals j ON j.dataset_id=o.dataset_id AND j.operation_id=o.id JOIN journal_lines jl ON jl.dataset_id=j.dataset_id AND jl.journal_id=j.id
      JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id AND la.kind='cash'
      WHERE o.dataset_id=? AND o.actor_id=? AND j.status='posted' AND jl.currency=? AND j.posted_at>=? AND j.posted_at<?`, datasetId, actorId,
      str(session, 'currency'), str(session, 'opened_at'), str(session, 'closed_at'));
    return { sessionId: str(session, 'id'), declaredMinorUnits: int(session, 'declared_minor_units'), countedMinorUnits: int(session, 'counted_minor_units'), postedNetMovementMinorUnits: int(row, 'net') };
  });
  const exceptions = movements.filter((item) => item.declaredMinorUnits !== item.countedMinorUnits
    || item.countedMinorUnits !== item.postedNetMovementMinorUnits);
  return { kind: 'reconciled', data: { businessDate: query.businessDate, currency: query.declaredTotal.currency, declaredTotalMinorUnits: declared, sessionCount: sessions.length, sessions: movements, exceptions, matched: exceptions.length === 0, writes: 0 } };
}

/** Executes bounded, actor-authorized financial inquiries. All four reconciliation/preview tasks are side-effect free. */
export function queryFinance(store: FinancialStore, context: ServiceContext, input: unknown): FinanceQueryResult {
  const invalid = validateFinanceQuery(input);
  if (invalid !== null) return invalid;
  const query = input as FinanceQuery;
  if (query.kind === 'finance.record') return readFinanceRecord(store, context, query.resource, query.id);
  if (query.kind === 'finance.records') {
    const scope = query.scope ?? {};
    const mappedScope = mapFinanceListScope(scope);
    if (isRejection(mappedScope)) return mappedScope;
    const canonicalScope = mappedScope;
    const direct = { memberId: query.memberId, accountId: query.accountId, parentId: query.parentId, state: query.state, query: query.query, dateFrom: query.dateFrom, dateThrough: query.dateThrough };
    const overlapping = Object.keys(direct).some((key) => direct[key as keyof typeof direct] !== undefined && canonicalScope[key as keyof FinanceListInput] !== undefined);
    if (overlapping) return reject('validation', 'Provide list scope either in scope or as top-level filters, not both.', { field: 'scope' });
    const hasScope = Object.keys(canonicalScope).length > 0;
    if (!hasScope && financeListRequiresScope(query.resource)) return reject('validation', `The ${query.resource} list requires an explicit member, account, parent, identifier, or date scope.`, { field: 'scope' });
    return listFinanceRecords(store, context, {
      resource: query.resource,
      limit: query.limit,
      offset: query.offset ?? 0,
      ...canonicalScope,
      ...Object.fromEntries(Object.entries(direct).filter(([, value]) => value !== undefined)),
    });
  }
  return authorized(store, context, (database) => {
    switch (query.kind) {
      case 'reconciliation.transfer': return reconcileTransferRead(database, context.binding.datasetId, query);
      case 'reconciliation.settlement_batch': return reconcileSettlementRead(database, context.binding.datasetId, query);
      case 'batch.preview': return previewBatchRead(database, context.binding.datasetId, query);
      case 'reconciliation.cash_day': return reconcileCashRead(database, context.binding.datasetId, query);
    }
  });
}
