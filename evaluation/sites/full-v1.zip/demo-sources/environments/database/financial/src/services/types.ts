import type { ApprovalCommand } from './approval-types.js';
import type { ServicingCommand } from './servicing-types.js';
import type { FinanceCommand } from './finance-types.js';
import type { DatasetBinding } from '../model.js';
import type { WriteContext } from '../verification/run-types.js';

export type Visibility = 'general' | 'restricted';
export type StatementDelivery = 'paper' | 'electronic';
export type CaseState = 'open' | 'pending-customer' | 'pending-internal' | 'resolved' | 'closed' | 'reopened';
export type CasePriority = 'low' | 'normal' | 'high' | 'urgent';
export type OrganizationType = 'corporation' | 'nonprofit';

/** An exact amount in integer minor units of an explicit ISO 4217 currency. */
export interface Money {
  minorUnits: number;
  currency: string;
}

export interface AddressInput {
  line1: string;
  line2: string | null;
  city: string;
  region: string;
  postalCode: string;
  country: string;
}

/**
 * Business commands. Omitted optional patch fields preserve the stored value; `null` clears it.
 * Commands that edit an existing record carry the record version the editor reviewed.
 */
export type CoreCommand =
  | { kind: 'edit.cancel'; requestId: string; expectedUpdatedAt: string }
  | { kind: 'member.create'; legalGiven: string; legalFamily: string; preferredName: string | null; birthDate: string; email: string | null; phone: string | null; address: AddressInput | null }
  | { kind: 'member.organization.create'; legalName: string; registrationNumber: string; organizationType: OrganizationType; email: string | null; phone: string | null; address: AddressInput | null }
  | { kind: 'contact.update'; memberId: string; expectedVersion: number; email?: string | null; phone?: string | null; address?: AddressInput }
  | { kind: 'member.note.add'; memberId: string; visibility: Visibility; text: string }
  | { kind: 'account.open'; memberId: string; productId: string; nickname: string; statementDelivery: StatementDelivery }
  | { kind: 'account.nickname.update'; accountId: string; expectedVersion: number; nickname: string }
  | { kind: 'account.statement_delivery.update'; accountId: string; expectedVersion: number; statementDelivery: StatementDelivery }
  | { kind: 'account.close'; accountId: string; expectedVersion: number; reason: string }
  | { kind: 'cash.deposit'; accountId: string; expectedVersion: number; amount: Money; description: string }
  | { kind: 'cash.withdraw'; accountId: string; expectedVersion: number; amount: Money; description: string }
  | { kind: 'transfer.internal'; sourceAccountId: string; destinationAccountId: string; expectedSourceVersion: number; expectedDestinationVersion: number; amount: Money; description: string }
  | { kind: 'case.open'; memberId: string; accountId: string | null; queueId: string; assignedActorId: string | null; category: string; priority: CasePriority; summary: string; dueDate: string }
  | { kind: 'case.assign'; caseId: string; expectedVersion: number; queueId: string; assignedActorId: string | null; reason: string }
  | { kind: 'case.transition'; caseId: string; expectedVersion: number; toState: CaseState; reason: string }
  | { kind: 'case.note.add'; caseId: string; visibility: Visibility; text: string; evidenceVersionIds?: readonly string[] }
  | { kind: 'search.saved.create'; name: string; visibility: SavedSearchVisibility; definition: SavedSearchDefinition }
  | { kind: 'search.saved.update'; searchId: string; expectedRevision: string; name?: string; visibility?: SavedSearchVisibility; definition?: SavedSearchDefinition }
  | { kind: 'search.saved.delete'; searchId: string; expectedRevision: string };

export type ServiceCommand = CoreCommand | ServicingCommand | FinanceCommand | ApprovalCommand;

export type CommandKind = ServiceCommand['kind'];

export type ResourceKind = 'member' | 'member-note' | 'account' | 'journal' | 'case' | 'case-note' | 'saved-search' | 'identity-evidence' | 'name-history' | 'document' | 'document-version' | 'signature' | 'consent' | 'communication-job' | 'case-dependency' | 'address' | 'party-address' | 'address-destination' | 'maintenance-request' | 'document-annotation' | 'document-access' | 'retention-hold' | 'document-derivation' | 'beneficiary' | 'payment' | 'payment-schedule' | 'card' | 'dispute' | 'loan' | 'batch' | 'reconciliation' | 'hold' | 'restriction' | 'fee' | 'maturity-instruction' | 'approval' | 'loan-application';

export type SavedSearchVisibility = 'private' | 'shared';
export type SavedSearchEntity = 'members' | 'accounts' | 'cases';
export type SavedSearchFilterValue = string | boolean | string[];

/**
 * Stored meaning of a saved search. Field names are the stored column vocabulary of each entity
 * (`SAVED_SEARCH_ENTITIES`); a search keeps at most one sort key because list queries honor one.
 */
export interface SavedSearchDefinition {
  entity: SavedSearchEntity;
  filters: Readonly<Record<string, SavedSearchFilterValue>>;
  sort: readonly { field: string; direction: 'asc' | 'desc' }[];
  columns: readonly string[];
  /** Upper bound on results the search returns, when the author limited it. */
  maxResults?: number;
}

export interface AffectedRecord {
  kind: ResourceKind;
  id: string;
  /** Business identifier shown to people, such as a member, account, case or journal number. */
  label: string;
}

export interface ActorRef {
  id: string;
  actorNumber: string;
  displayName: string;
}

export interface ReceiptJournalLine {
  lineNumber: number;
  ledgerCode: string;
  accountId: string | null;
  accountNumber: string | null;
  debitMinorUnits: number;
  creditMinorUnits: number;
  currency: string;
  memo: string;
}

/** Durable evidence of one committed operation, rebuilt from stored rows on every read. */
export interface Receipt {
  operationId: string;
  receiptNumber: string;
  operationKind: string;
  businessReference: string;
  status: string;
  committedAt: string;
  /** Exact durable command output; historical seed receipts may predate a typed output. */
  result: Record<string, unknown> | null;
  actor: ActorRef;
  affected: AffectedRecord[];
  events: { sequence: number; kind: string; resourceKind: string; resourceId: string; summary: string }[];
  journals: { id: string; reference: string; description: string; effectiveDate: string; lines: ReceiptJournalLine[] }[];
}

export type RejectionCode =
  | 'validation'
  | 'not_found'
  | 'stale_version'
  | 'actor_inactive'
  | 'not_authorized'
  | 'ineligible'
  | 'insufficient_funds'
  | 'currency_mismatch'
  | 'same_account'
  | 'ownership_mismatch'
  | 'limit_exceeded'
  | 'closure_blocked'
  | 'duplicate_identity'
  | 'duplicate_open_case'
  | 'account_limit_reached'
  | 'invalid_transition'
  | 'open_dependencies'
  | 'idempotency_conflict';

export interface Rejection {
  kind: 'rejected';
  code: RejectionCode;
  message: string;
  field?: string;
  /** Current record version when the rejection is `stale_version`. */
  currentVersion?: number;
}

export interface Unchanged {
  kind: 'unchanged';
  message: string;
}

export type CommandOutcome =
  | { kind: 'committed'; receipt: Receipt }
  | { kind: 'duplicate'; receipt: Receipt }
  | Unchanged
  | Rejection;

export interface ReviewedAccount {
  id: string;
  accountNumber: string;
  memberId: string;
  memberNumber: string;
  ownerName: string;
  productName: string;
  currency: string;
  exponent: number;
  status: string;
  version: number;
  postedBeforeMinorUnits: number;
  postedAfterMinorUnits: number;
  availableBeforeMinorUnits: number;
  availableAfterMinorUnits: number;
}

/** Terms of a consequential operation as validated against current data, without any effect. */
export interface OperationReview {
  commandKind: CommandKind;
  institutionId: string;
  institutionName: string;
  amount: Money | null;
  exponent: number | null;
  description: string | null;
  accounts: ReviewedAccount[];
  consequences: string[];
}

export type ReviewOutcome = { kind: 'reviewable'; review: OperationReview } | Unchanged | Rejection;

/** Trusted context supplied by the backend or evaluator, never by browser input. */
export interface ServiceContext {
  binding: DatasetBinding;
  actorId: string;
  principalKind?: WriteContext['kind'];
  /** Correlates the transaction with its caller, for example an application session and request. */
  reference: string;
  /** Business instant; defaults to the dataset's controlled as-of clock. */
  now?: string;
}

export interface Eligibility {
  eligible: boolean;
  reasons: string[];
}
