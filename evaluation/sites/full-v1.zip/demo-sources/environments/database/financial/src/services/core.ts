import { facilityLimitSql } from '../facility-sql.js';
import { createHash } from 'node:crypto';
import type { SQLInputValue, SQLOutputValue } from 'node:sqlite';

import type { SqlDatabase } from './store.js';
import type { AccountFacts } from './rules.js';
import type { ActorRef, AffectedRecord, CommandKind, Receipt, Rejection, RejectionCode, ResourceKind, ServiceContext } from './types.js';

export type Row = Record<string, SQLOutputValue>;

export function all(database: SqlDatabase, sql: string, ...parameters: SQLInputValue[]): Row[] {
  return database.prepare(sql).all(...parameters);
}

export function one(database: SqlDatabase, sql: string, ...parameters: SQLInputValue[]): Row | undefined {
  return database.prepare(sql).get(...parameters);
}

export function run(database: SqlDatabase, sql: string, ...parameters: SQLInputValue[]): void {
  database.prepare(sql).run(...parameters);
}

export function str(row: Row | undefined, column: string): string {
  const value = row?.[column];
  if (typeof value !== 'string') throw new Error(`Expected text column ${column}.`);
  return value;
}

export function optionalStr(row: Row | undefined, column: string): string | null {
  const value = row?.[column];
  if (value === null || value === undefined) return null;
  if (typeof value !== 'string') throw new Error(`Expected text column ${column}.`);
  return value;
}

export function int(row: Row | undefined, column: string): number {
  const value = row?.[column];
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error(`Expected integer column ${column}.`);
  return value;
}

export function optionalInt(row: Row | undefined, column: string): number | null {
  const value = row?.[column];
  if (value === null || value === undefined) return null;
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error(`Expected integer column ${column}.`);
  return value;
}

/** Aborts a write transaction with a business outcome; the store rolls back every statement. */
export class OutcomeAbort extends Error {
  constructor(readonly outcome: Rejection | { kind: 'unchanged'; message: string } | { kind: 'duplicate'; receipt: Receipt }) {
    super(outcome.kind);
  }
}

export function reject(code: RejectionCode, message: string, extra: { field?: string; currentVersion?: number } = {}): Rejection {
  return { kind: 'rejected', code, message, ...extra };
}

export function canonicalJson(value: unknown): string {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  const entries = Object.entries(value).filter(([, item]) => item !== undefined).sort(([a], [b]) => a.localeCompare(b));
  return `{${entries.map(([key, item]) => `${JSON.stringify(key)}:${canonicalJson(item)}`).join(',')}}`;
}

export function sha256(value: string | Uint8Array): string {
  return createHash('sha256').update(value).digest('hex');
}

/** Allocates the next business number with a fixed prefix and width inside the current write lock. */
export function nextNumber(database: SqlDatabase, table: string, column: string, datasetId: string, prefix: string, width: number): string {
  const pattern = `${prefix}${'[0-9]'.repeat(width)}`;
  const row = one(database, `SELECT MAX(CAST(substr(${column},${prefix.length + 1}) AS INTEGER)) AS maximum FROM ${table} WHERE dataset_id=? AND ${column} GLOB ?`, datasetId, pattern);
  const next = (optionalInt(row, 'maximum') ?? 0) + 1;
  const formatted = String(next);
  if (formatted.length > width) throw new Error(`Business number space ${prefix} is exhausted.`);
  return `${prefix}${formatted.padStart(width, '0')}`;
}

export function datasetClock(database: SqlDatabase, datasetId: string): { asOf: string; timeZone: string; institutionName: string; institutionId: string } {
  const row = one(database, 'SELECT d.as_of,i.time_zone,i.display_name,i.id AS institution_id FROM datasets d JOIN institutions i ON i.id=d.institution_id WHERE d.id=?', datasetId);
  if (row === undefined) throw new Error('Unknown dataset.');
  return { asOf: str(row, 'as_of'), timeZone: str(row, 'time_zone'), institutionName: str(row, 'display_name'), institutionId: str(row, 'institution_id') };
}

/** Local calendar date of an instant in the institution's time zone. */
export function localDate(instant: string, timeZone: string): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(instant));
}

/** Resolves a local wall-clock time; ambiguous or nonexistent DST times require explicit caller resolution. */
export function zonedInstant(date: string, time: string, timeZone: string): string {
  if (!isIsoDate(date) || !/^([01]\d|2[0-3]):[0-5]\d$/u.test(time)) throw new RangeError('Invalid local date or time.');
  const guess = Date.parse(`${date}T${time}:00.000Z`);
  const formatter = new Intl.DateTimeFormat('en-US', { timeZone, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const wallTime = (instant: number): number => {
    const parts = Object.fromEntries(formatter.formatToParts(instant).map(part=>[part.type,part.value]));
    return Date.UTC(Number(parts.year),Number(parts.month)-1,Number(parts.day),Number(parts.hour),Number(parts.minute),Number(parts.second));
  };
  const offsets = new Set<number>();
  for(let hours=-48;hours<=48;hours+=6) { const instant=guess+hours*3_600_000; offsets.add(wallTime(instant)-instant); }
  const candidates = [...offsets].map(offset=>guess-offset).filter(instant=>wallTime(instant)===guess);
  if(candidates.length!==1) throw new RangeError(candidates.length===0 ? 'The local time does not exist in this time zone.' : 'The local time is ambiguous in this time zone; an explicit instant is required.');
  const candidate=candidates[0];
  if(candidate===undefined) throw new Error('Missing resolved time.');
  return new Date(candidate).toISOString();
}

export function isIsoDate(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/u.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
}

export function actorRef(database: SqlDatabase, datasetId: string, actorId: string): ActorRef | undefined {
  const row = one(database, 'SELECT id,actor_number,display_name FROM actors WHERE dataset_id=? AND id=?', datasetId, actorId);
  return row === undefined ? undefined : { id: str(row, 'id'), actorNumber: str(row, 'actor_number'), displayName: str(row, 'display_name') };
}

/** Permissions the actor holds at an instant, limited to grants scoped to the institution. */
export function actorPermissions(database: SqlDatabase, datasetId: string, institutionId: string, actorId: string, instant: string): Set<string> {
  if (!Number.isFinite(Date.parse(instant))) return new Set();
  instant = new Date(instant).toISOString();
  const binding = one(database, 'SELECT institution_id FROM datasets WHERE id=?', datasetId);
  if (binding === undefined || str(binding, 'institution_id') !== institutionId) return new Set();
  const rows = all(database, `SELECT p.permission,p.scope_json FROM actor_roles ar JOIN role_permissions p ON p.dataset_id=ar.dataset_id AND p.role_id=ar.role_id
    WHERE ar.dataset_id=? AND ar.actor_id=? AND ar.starts_at<=? AND (ar.ends_at IS NULL OR ar.ends_at>?)`, datasetId, actorId, instant, instant);
  const permissions = new Set<string>();
  for (const row of rows) {
    let scope: unknown;
    try { scope = JSON.parse(str(row, 'scope_json')); } catch { continue; }
    if (scope === null || typeof scope !== 'object' || Array.isArray(scope) || Object.keys(scope).some(key => key !== 'institutionId')) continue;
    if ('institutionId' in scope && scope.institutionId === institutionId) permissions.add(str(row, 'permission'));
  }
  return permissions;
}

export function authorize(database: SqlDatabase, datasetId: string, institutionId: string, actorId: string, instant: string, grants: readonly string[] | null): Rejection | null {
  const actor = one(database, 'SELECT status FROM actors WHERE dataset_id=? AND id=?', datasetId, actorId);
  if (actor === undefined) return reject('not_authorized', 'The operator is not registered at this institution.');
  if (str(actor, 'status') !== 'active') return reject('actor_inactive', 'The operator account is disabled.');
  const permissions = actorPermissions(database, datasetId, institutionId, actorId, instant);
  if (permissions.size === 0) return reject('not_authorized', 'The operator holds no active role at this institution.');
  if (grants !== null && !grants.some((grant) => permissions.has(grant))) {
    return reject('not_authorized', `The operator lacks the ${grants.join(' or ')} permission required for this action.`);
  }
  return null;
}

/** Authorizes a scoped read at the same business clock and institution boundary as a command. */
export const READ_GRANTS: readonly string[] = ['read', 'maintain', 'payment.prepare', 'payment.approve', 'case.manage', 'supervise'];

export function authorizeQuery(database: SqlDatabase, context: ServiceContext, grants: readonly string[] = READ_GRANTS): Rejection | null {
  const dataset = one(database, 'SELECT institution_id,as_of FROM datasets WHERE id=?', context.binding.datasetId);
  if (dataset === undefined || str(dataset, 'institution_id') !== context.binding.institutionId) return reject('not_authorized', 'The dataset does not belong to the requested institution.');
  const now = context.now ?? str(dataset, 'as_of');
  if (!/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:\d{2})$/u.test(now) || !Number.isFinite(Date.parse(now))) return reject('validation', 'Business time must be a valid instant with an explicit offset.');
  return authorize(database, context.binding.datasetId, context.binding.institutionId, context.actorId, new Date(now).toISOString(), grants);
}

export function accountFacts(database: SqlDatabase, datasetId: string, accountId: string, instant: string): (AccountFacts & { currency: string; availableMinorUnits: number; version: number }) | undefined {
  instant = new Date(instant).toISOString();
  const clockLiteral=`'${instant}'`;
  const row = one(database, `SELECT a.status,a.currency,a.version,b.posted_balance_minor_units,b.available_balance_minor_units,
      (SELECT COALESCE(SUM(MAX(0,${facilityLimitSql(clockLiteral)}-f.used_minor_units)),0) FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id AND f.status='active')
      - (SELECT COALESCE(SUM(MAX(0,${facilityLimitSql('(SELECT as_of FROM datasets WHERE id=f.dataset_id)')}-f.used_minor_units)),0) FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id AND f.status='active') AS facility_clock_adjustment,
      (SELECT COALESCE(SUM(h.amount_minor_units),0) FROM holds h WHERE h.dataset_id=a.dataset_id AND h.account_id=a.id AND h.status='active' AND (h.expires_at IS NULL OR h.expires_at>(SELECT as_of FROM datasets WHERE id=a.dataset_id)))
        - (SELECT COALESCE(SUM(h.amount_minor_units),0) FROM holds h WHERE h.dataset_id=a.dataset_id AND h.account_id=a.id AND h.status='active' AND (h.expires_at IS NULL OR h.expires_at>?)) AS held_clock_adjustment,
      (SELECT COUNT(*) FROM holds h WHERE h.dataset_id=a.dataset_id AND h.account_id=a.id AND h.status='active' AND (h.expires_at IS NULL OR h.expires_at>?)) AS holds,
      (SELECT COUNT(*) FROM reservations r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active') AS reservations,
      (SELECT group_concat(kind) FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active') AS restrictions,
      (SELECT COALESCE(SUM(used_minor_units),0) FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id) AS facility_used,
      (SELECT COUNT(*) FROM loans l WHERE l.dataset_id=a.dataset_id AND l.account_id=a.id AND l.state<>'closed') AS loans,
      (SELECT COUNT(*) FROM cards c WHERE c.dataset_id=a.dataset_id AND c.account_id=a.id AND c.status IN ('active','temporarily-locked')) AS cards,
      (SELECT COUNT(*) FROM payments p WHERE p.dataset_id=a.dataset_id AND p.source_account_id=a.id AND p.state IN ('draft','pending-approval','released','cancellation-requested')) AS payments,
      (SELECT COUNT(*) FROM payment_schedules s WHERE s.dataset_id=a.dataset_id AND s.source_account_id=a.id AND (s.state IN ('active','paused') AND (s.end_date IS NULL OR s.end_date>=?) OR EXISTS (SELECT 1 FROM schedule_occurrences o WHERE o.dataset_id=s.dataset_id AND o.schedule_id=s.id AND o.state IN ('planned','materialized','released')))) AS schedules
    FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.id=?`, instant, instant, localDate(instant, datasetClock(database, datasetId).timeZone), datasetId, accountId);
  if (row === undefined) return undefined;
  const restrictions = optionalStr(row, 'restrictions');
  return {
    status: str(row, 'status'), currency: str(row, 'currency'), version: int(row, 'version'),
    postedMinorUnits: int(row, 'posted_balance_minor_units'), availableMinorUnits: int(row, 'available_balance_minor_units') + int(row, 'held_clock_adjustment') + int(row,'facility_clock_adjustment'),
    activeHolds: int(row, 'holds'), activeReservations: int(row, 'reservations'),
    activeRestrictions: restrictions === null ? [] : restrictions.split(','),
    facilityUsedMinorUnits: int(row, 'facility_used'), openLoans: int(row, 'loans'), activeCards: int(row, 'cards'),
    pendingPayments: int(row, 'payments'), activeSchedules: int(row, 'schedules'),
  };
}

export interface LedgerPostingEntry {
  ledgerAccountId: string;
  currency: string;
  debitMinorUnits: number;
  creditMinorUnits: number;
}

/** Rejects a posting when any resulting posted ledger balance would leave JavaScript's exact integer range. */
export function requireSafeLedgerPosting(database: SqlDatabase, datasetId: string, entries: readonly LedgerPostingEntry[]): Rejection | null {
  const grouped = new Map<string, LedgerPostingEntry>();
  for (const entry of entries) {
    if (!Number.isSafeInteger(entry.debitMinorUnits) || !Number.isSafeInteger(entry.creditMinorUnits)
      || entry.debitMinorUnits < 0 || entry.creditMinorUnits < 0
      || (entry.debitMinorUnits === 0) === (entry.creditMinorUnits === 0)) {
      return reject('validation', 'Ledger posting amounts must be positive exact debit or credit values.');
    }
    const current = grouped.get(entry.ledgerAccountId);
    if (current === undefined) {
      grouped.set(entry.ledgerAccountId, { ...entry });
      continue;
    }
    if (current.currency !== entry.currency) return reject('currency_mismatch', 'One ledger cannot receive postings in different currencies.');
    const debitMinorUnits = current.debitMinorUnits + entry.debitMinorUnits;
    const creditMinorUnits = current.creditMinorUnits + entry.creditMinorUnits;
    if (!Number.isSafeInteger(debitMinorUnits) || !Number.isSafeInteger(creditMinorUnits)) {
      return reject('limit_exceeded', 'The posting exceeds the supported exact ledger balance range.');
    }
    grouped.set(entry.ledgerAccountId, { ...current, debitMinorUnits, creditMinorUnits });
  }
  for (const entry of grouped.values()) {
    const ledger = one(database, `SELECT la.currency,la.normal_side,
      COALESCE(SUM(CASE WHEN j.status='posted' THEN CASE la.normal_side WHEN 'credit' THEN l.credit_minor_units-l.debit_minor_units ELSE l.debit_minor_units-l.credit_minor_units END ELSE 0 END),0) AS balance_minor_units
      FROM ledger_accounts la LEFT JOIN journal_lines l ON l.dataset_id=la.dataset_id AND l.ledger_account_id=la.id
      LEFT JOIN journals j ON j.dataset_id=l.dataset_id AND j.id=l.journal_id
      WHERE la.dataset_id=? AND la.id=? GROUP BY la.currency,la.normal_side`, datasetId, entry.ledgerAccountId);
    if (ledger === undefined) return reject('not_found', 'A posting ledger does not exist at this institution.');
    if (str(ledger, 'currency') !== entry.currency) return reject('currency_mismatch', 'The posting currency differs from its ledger currency.');
    const balance = ledger.balance_minor_units;
    if (typeof balance !== 'number' || !Number.isSafeInteger(balance)) {
      return reject('limit_exceeded', 'The current ledger balance is outside the supported exact range.');
    }
    const delta = str(ledger, 'normal_side') === 'credit'
      ? entry.creditMinorUnits - entry.debitMinorUnits
      : entry.debitMinorUnits - entry.creditMinorUnits;
    if (!Number.isSafeInteger(delta) || !Number.isSafeInteger(balance + delta)) {
      return reject('limit_exceeded', 'The posting would exceed the supported exact ledger balance range.');
    }
  }
  return null;
}

export function currencyExponent(database: SqlDatabase, currency: string): number | undefined {
  return optionalInt(one(database, 'SELECT exponent FROM currencies WHERE code=?', currency), 'exponent') ?? undefined;
}

export interface RecordedOperation {
  operationId: string;
  receiptNumber: string;
}

export function recordOperation(database: SqlDatabase, input: {
  datasetId: string; actorId: string; kind: string; businessReference: string; idempotencyKey: string; commandDigest: string; resultDigest: string; result: Record<string, unknown>; now: string; operationId: string;
}): RecordedOperation {
  run(database, 'INSERT INTO operations (dataset_id,id,actor_id,operation_kind,business_reference,idempotency_key,command_digest,status,occurred_at) VALUES (?,?,?,?,?,?,?,?,?)',
    input.datasetId, input.operationId, input.actorId, input.kind, input.businessReference, input.idempotencyKey, input.commandDigest, 'committed', input.now);
  const receiptNumber = nextNumber(database, 'operation_receipts', 'receipt_number', input.datasetId, 'RCP', 8);
  run(database, 'INSERT INTO operation_receipts (dataset_id,id,operation_id,receipt_number,result_digest,committed_at,result_json) VALUES (?,?,?,?,?,?,?)',
    input.datasetId, `receipt-${input.operationId.slice(3)}`, input.operationId, receiptNumber, input.resultDigest, input.now, canonicalJson(input.result));
  return { operationId: input.operationId, receiptNumber };
}

export function recordEvent(database: SqlDatabase, input: {
  datasetId: string; actorId: string; operationId: string; now: string; kind: CommandKind; resource: { kind: ResourceKind; id: string }; summary: string; eventId: string;
}): void {
  const sequence = (optionalInt(one(database, 'SELECT MAX(sequence) AS maximum FROM business_events WHERE dataset_id=?', input.datasetId), 'maximum') ?? 0) + 1;
  run(database, 'INSERT INTO business_events (dataset_id,id,actor_id,operation_id,sequence,occurred_at,kind,resource_kind,resource_id,summary) VALUES (?,?,?,?,?,?,?,?,?,?)',
    input.datasetId, input.eventId, input.actorId, input.operationId, sequence, input.now, input.kind, input.resource.kind, input.resource.id, input.summary);
}

const RESOURCE_LABELS: Readonly<Record<ResourceKind, string>> = {
  approval: 'SELECT id AS label FROM business_approvals WHERE dataset_id=? AND id=?',
  'loan-application': 'SELECT id AS label FROM loan_applications WHERE dataset_id=? AND id=?',
  'beneficiary': 'SELECT display_name AS label FROM beneficiaries WHERE dataset_id=? AND id=?',
  'payment': 'SELECT reference AS label FROM payments WHERE dataset_id=? AND id=?',
  'payment-schedule': 'SELECT id AS label FROM payment_schedules WHERE dataset_id=? AND id=?',
  'card': 'SELECT last_four AS label FROM cards WHERE dataset_id=? AND id=?',
  'dispute': 'SELECT case_number AS label FROM disputes WHERE dataset_id=? AND id=?',
  'loan': 'SELECT id AS label FROM loans WHERE dataset_id=? AND id=?',
  'batch': 'SELECT batch_number AS label FROM batches WHERE dataset_id=? AND id=?',
  'reconciliation': 'SELECT id AS label FROM reconciliation_runs WHERE dataset_id=? AND id=?',
  'hold': 'SELECT id AS label FROM holds WHERE dataset_id=? AND id=?',
  'restriction': 'SELECT id AS label FROM restrictions WHERE dataset_id=? AND id=?',
  'fee': 'SELECT id AS label FROM fees WHERE dataset_id=? AND id=?',
  'maturity-instruction': 'SELECT id AS label FROM maturity_instructions WHERE dataset_id=? AND id=?',
  'identity-evidence': 'SELECT reference AS label FROM identity_evidence WHERE dataset_id=? AND id=?',
  'name-history': 'SELECT id AS label FROM name_history WHERE dataset_id=? AND id=?',
  'document': 'SELECT display_name AS label FROM documents WHERE dataset_id=? AND id=?',
  'document-version': 'SELECT id AS label FROM document_versions WHERE dataset_id=? AND id=?',
  'signature': 'SELECT id AS label FROM signatures WHERE dataset_id=? AND id=?',
  'consent': 'SELECT id AS label FROM consents WHERE dataset_id=? AND id=?',
  'communication-job': 'SELECT id AS label FROM communication_jobs WHERE dataset_id=? AND id=?',
  'case-dependency': 'SELECT id AS label FROM case_dependencies WHERE dataset_id=? AND id=?',
  'address': 'SELECT line1 AS label FROM addresses WHERE dataset_id=? AND id=?',
  'party-address': 'SELECT id AS label FROM party_addresses WHERE dataset_id=? AND id=?',
  'address-destination': 'SELECT context_kind || \':\' || COALESCE(member_id,account_id,card_id,loan_id) AS label FROM address_destinations WHERE dataset_id=? AND id=?',
  'maintenance-request': 'SELECT request_number AS label FROM maintenance_requests WHERE dataset_id=? AND id=?',
  'document-annotation': 'SELECT id AS label FROM document_annotations WHERE dataset_id=? AND id=?',
  'document-access': 'SELECT id AS label FROM document_access_events WHERE dataset_id=? AND id=?',
  'retention-hold': 'SELECT id AS label FROM retention_holds WHERE dataset_id=? AND id=?',
  'document-derivation': 'SELECT id AS label FROM document_derivations WHERE dataset_id=? AND id=?',
  member: "SELECT member_number AS label FROM members WHERE dataset_id=? AND id=?",
  'member-note': "SELECT 'Note on ' || m.member_number AS label FROM member_notes n JOIN members m ON m.dataset_id=n.dataset_id AND m.id=n.member_id WHERE n.dataset_id=? AND n.id=?",
  account: 'SELECT account_number AS label FROM accounts WHERE dataset_id=? AND id=?',
  journal: 'SELECT reference AS label FROM journals WHERE dataset_id=? AND id=?',
  case: 'SELECT case_number AS label FROM cases WHERE dataset_id=? AND id=?',
  'case-note': "SELECT 'Note on ' || c.case_number AS label FROM case_notes n JOIN cases c ON c.dataset_id=n.dataset_id AND c.id=n.case_id WHERE n.dataset_id=? AND n.id=?",
  'saved-search': 'SELECT name AS label FROM saved_searches WHERE dataset_id=? AND id=?',
};

function resourceKind(value: string): ResourceKind | null {
  return value in RESOURCE_LABELS ? value as ResourceKind : null;
}

/** Rebuilds a receipt from stored operation, event and journal rows. */
export function loadReceipt(database: SqlDatabase, datasetId: string, where: { operationId: string } | { receiptNumber: string }): Receipt | undefined {
  const operation = 'operationId' in where
    ? one(database, `SELECT o.*,r.receipt_number,r.committed_at,r.result_json,r.result_digest FROM operations o JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id WHERE o.dataset_id=? AND o.id=?`, datasetId, where.operationId)
    : one(database, `SELECT o.*,r.receipt_number,r.committed_at,r.result_json,r.result_digest FROM operations o JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id WHERE o.dataset_id=? AND r.receipt_number=?`, datasetId, where.receiptNumber);
  if (operation === undefined) return undefined;
  const resultJson = optionalStr(operation, 'result_json');
  if (resultJson !== null && createHash('sha256').update(resultJson).digest('hex') !== str(operation, 'result_digest')) throw new Error('Stored command output digest mismatch.');
  const operationId = str(operation, 'id');
  const actor = actorRef(database, datasetId, str(operation, 'actor_id')) ?? { id: str(operation, 'actor_id'), actorNumber: '', displayName: 'Unknown operator' };
  const events = all(database, 'SELECT sequence,kind,resource_kind,resource_id,summary FROM business_events WHERE dataset_id=? AND operation_id=? ORDER BY sequence', datasetId, operationId)
    .map((row) => ({ sequence: int(row, 'sequence'), kind: str(row, 'kind'), resourceKind: str(row, 'resource_kind'), resourceId: str(row, 'resource_id'), summary: str(row, 'summary') }));
  const affected: AffectedRecord[] = [];
  const seen = new Set<string>();
  for (const event of events) {
    const kind = resourceKind(event.resourceKind);
    const key = `${event.resourceKind}:${event.resourceId}`;
    if (kind === null || seen.has(key)) continue;
    seen.add(key);
    affected.push({ kind, id: event.resourceId, label: optionalStr(one(database, RESOURCE_LABELS[kind], datasetId, event.resourceId), 'label') ?? event.resourceId });
  }
  const journals = all(database, 'SELECT id,reference,description,effective_date FROM journals WHERE dataset_id=? AND operation_id=? ORDER BY reference', datasetId, operationId).map((journal) => ({
    id: str(journal, 'id'), reference: str(journal, 'reference'), description: str(journal, 'description'), effectiveDate: str(journal, 'effective_date'),
    lines: all(database, `SELECT l.line_number,g.code,g.customer_account_id,a.account_number,l.debit_minor_units,l.credit_minor_units,l.currency,l.memo FROM journal_lines l
        JOIN ledger_accounts g ON g.dataset_id=l.dataset_id AND g.id=l.ledger_account_id LEFT JOIN accounts a ON a.dataset_id=g.dataset_id AND a.id=g.customer_account_id
        WHERE l.dataset_id=? AND l.journal_id=? ORDER BY l.line_number`, datasetId, str(journal, 'id')).map((line) => ({
      lineNumber: int(line, 'line_number'), ledgerCode: str(line, 'code'), accountId: optionalStr(line, 'customer_account_id'), accountNumber: optionalStr(line, 'account_number'),
      debitMinorUnits: int(line, 'debit_minor_units'), creditMinorUnits: int(line, 'credit_minor_units'), currency: str(line, 'currency'), memo: str(line, 'memo'),
    })),
  }));
  return {
    operationId, receiptNumber: str(operation, 'receipt_number'), operationKind: str(operation, 'operation_kind'), businessReference: str(operation, 'business_reference'),
    status: str(operation, 'status'), committedAt: str(operation, 'committed_at'), result: readResult(optionalStr(operation, 'result_json')), actor, affected, events, journals,
  };
}

function readResult(json: string | null): Record<string, unknown> | null {
  if (json === null) return null;
  const value: unknown = JSON.parse(json);
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('Stored command output is not an object.');
  return value as Record<string, unknown>;
}

export function cleanText(value: string): string {
  return value.normalize('NFC').trim();
}

/** Rejects empty, oversized or control-character text after trimming. */
export function textProblem(value: string, label: string, maximum: number, allowNewlines = false): string | null {
  const cleaned = cleanText(value);
  if (cleaned.length === 0) return `${label} is required.`;
  if (cleaned.length > maximum) return `${label} must be at most ${maximum} characters.`;
  if (Array.from(cleaned).some((character) => { const code = character.codePointAt(0) ?? 0; return (code < 32 && !(allowNewlines && (code === 10 || code === 13 || code === 9))) || code === 127; })) {
    return `${label} contains control characters.`;
  }
  return null;
}
