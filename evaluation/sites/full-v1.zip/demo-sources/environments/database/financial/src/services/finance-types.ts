import type { Money, Rejection } from './types.js';

export type RestrictionKind = 'debit-block' | 'credit-block' | 'closure-block' | 'fraud-review' | 'legal-hold';
export type CardLimitKind = 'daily-purchase' | 'cash' | 'online';
export type PaymentFrequency = 'daily' | 'weekly' | 'monthly';

export interface BeneficialOwnerInput {
  memberId: string;
  ownershipBps: number;
  isControlPerson: boolean;
  evidenceId: string;
}

export type FinanceCommand =
  | { kind: 'member.merge'; mergePlanId: string; sourceMemberId: string; targetMemberId: string; expectedSourceVersion: number; expectedTargetVersion: number; relationshipAccountIds: readonly string[]; expectedInventoryFingerprint: string; approvalId: string }
  | { kind: 'member.deceased.record'; memberId: string; expectedVersion: number; evidenceId: string; effectiveDate: string; approvalId: string }
  | { kind: 'member.beneficial_owners.update'; organizationMemberId: string; expectedVersion: number; owners: readonly BeneficialOwnerInput[]; effectiveDate: string; approvalId: string }
  | { kind: 'member.tax_classification.update'; memberId: string; expectedVersion: number; classification: string; effectiveYear: number; evidenceId: string; approvalId: string }
  | { kind: 'account.product.convert'; accountId: string; expectedVersion: number; targetProductId: string; effectiveDate: string; feeDisclosureAccepted: boolean; approvalId: string }
  | { kind: 'account.owner.add'; accountId: string; expectedVersion: number; memberId: string; role: 'owner' | 'joint-owner'; effectiveDate: string; identityEvidenceId: string; consentId: string; approvalId: string }
  | { kind: 'account.signer.remove'; accountId: string; expectedVersion: number; signerMemberId: string; effectiveAt: string; approvalId: string }
  | { kind: 'account.overdraft_limit.update'; accountId: string; expectedVersion: number; expectedFacilityFingerprint: string | null; limit: Money; effectiveDate: string; expiresAt: string | null; approvalId: string }
  | { kind: 'account.hold.place'; accountId: string; expectedVersion: number; amount: Money; reason: string; expiresAt: string; releaseAuthority: string }
  | { kind: 'account.hold.release'; holdId: string; expectedFingerprint: string; amountMinorUnits: number; releaseAuthority: string; evidenceReference: string }
  | { kind: 'account.restriction.apply'; accountId: string; expectedVersion: number; restrictionType: RestrictionKind; reason: string; authority: string; caseId: string; approvalId: string }
  | { kind: 'account.restriction.release'; restrictionId: string; expectedFingerprint: string; clearanceEvidenceId: string; approvalId: string }
  | { kind: 'fee.assess'; accountId: string; expectedVersion: number; feeCode: string; amount: Money; basis: string; policyVersionId: string }
  | { kind: 'fee.waiver.create'; accountId: string; feeCode: string; validFrom: string; validThrough: string; amountLimit: Money; maxOccurrences: number; reason: string; approvalId: string }
  | { kind: 'fee.refund'; feeId: string; expectedFingerprint: string; amount: Money; reason: string }
  | { kind: 'cash.deposit.reverse'; journalId: string; expectedFingerprint: string; correctionEvidenceId: string; approvalId: string }
  | { kind: 'cash.withdrawal.reverse'; journalId: string; expectedFingerprint: string; reason: string; approvalId: string }
  | { kind: 'transfer.internal.reverse'; transferJournalId: string; expectedFingerprint: string; amount: Money; reason: string; approvalId: string }
  | { kind: 'interest.adjust'; accountId: string; calculationId: string; expectedFingerprint: string; approvedDelta: Money; approvalId: string }
  | { kind: 'transaction.effective_date.correct'; journalId: string; expectedFingerprint: string; correctedDate: string; policyVersionId: string; reason: string; approvalId: string }
  | { kind: 'beneficiary.create'; memberId: string; expectedMemberVersion: number; displayName: string; routingKind: string; maskedDestination: string; simulatedToken: string; allowedRails: readonly string[] }
  | { kind: 'beneficiary.verify'; beneficiaryId: string; routeId: string; expectedFingerprint: string; evidenceId: string; approvalId: string }
  | { kind: 'beneficiary.routing.update'; beneficiaryId: string; expectedRouteFingerprint: string; routingKind: string; maskedDestination: string; simulatedToken: string; effectiveDate: string; approvalId: string }
  | { kind: 'beneficiary.retire'; beneficiaryId: string; expectedFingerprint: string; dependentDisposition: 'reject-if-active' | 'cancel-drafts'; reason: string }
  | { kind: 'payment.create'; sourceAccountId: string; expectedSourceVersion: number; beneficiaryRouteId: string; expectedRouteFingerprint: string; amount: Money; rail: string; requestedDate: string; calendarVersion: string; cutoffAt: string; reference: string; targetState: 'draft' | 'pending-approval' }
  | { kind: 'payment.submit'; paymentId: string; expectedVersion: number }
  | { kind: 'payment.approve_release'; paymentId: string; expectedVersion: number; requestedDate: string; calendarVersion: string; cutoffAt: string; approvalId: string }
  | { kind: 'payment.settle'; paymentId: string; expectedVersion: number; settlementReference: string }
  | { kind: 'payment.schedule.create'; sourceAccountId: string; expectedSourceVersion: number; beneficiaryRouteId: string; expectedRouteFingerprint: string; amount: Money; frequency: PaymentFrequency; interval: number; startDate: string; endDate: string; approvalId: string }
  | { kind: 'payment.schedule.materialize'; occurrenceId: string; expectedFingerprint: string }
  | { kind: 'payment.occurrence.amend'; occurrenceId: string; expectedFingerprint: string; newAmount: Money; newDate: string }
  | { kind: 'payment.cancel'; paymentId: string; expectedVersion: number; reason: string }
  | { kind: 'payment.return.resolve'; returnId: string; expectedFingerprint: string; paymentId: string; disposition: 'credit-source' | 'investigate'; approvalId: string }
  | { kind: 'card.replace'; cardId: string; expectedFingerprint: string; reason: string; identityEvidenceId: string; deliveryDestinationId: string; deliveryAddressId: string }
  | { kind: 'card.lock.update'; cardId: string; expectedFingerprint: string; requestedState: 'locked' | 'unlocked'; authority: string }
  | { kind: 'card.limit.update'; cardId: string; expectedFingerprint: string; limitKind: CardLimitKind; amount: Money; effectiveAt: string; expiresAt: string | null; approvalId: string }
  | { kind: 'dispute.open'; cardTransactionId: string; expectedFingerprint: string; reason: string; assertedAmount: Money; evidenceIds: readonly string[] }
  | { kind: 'dispute.provisional_credit.issue'; disputeId: string; expectedFingerprint: string; amount: Money; approvalId: string }
  | { kind: 'dispute.evidence.submit'; disputeId: string; expectedFingerprint: string; documentVersionIds: readonly string[]; deadline: string; recipient: string; channel: string; approvalId: string }
  | { kind: 'dispute.settle'; disputeId: string; expectedFingerprint: string; decision: 'approved' | 'denied'; finalAmount: Money; approvalId: string }
  | { kind: 'loan.application.prepare'; memberId: string; expectedMemberVersion: number; productId: string; requestedAmount: Money; termMonths: number; purpose: string; evidenceIds: readonly string[] }
  | { kind: 'loan.payment.allocate'; loanId: string; expectedFingerprint: string; receivedFundsReference: string; amount: Money; allocationPolicy: 'fees-interest-principal' | 'fees-interest-principal-hold-remainder' }
  | { kind: 'loan.payoff.quote'; loanId: string; expectedFingerprint: string; payoffDate: string; policyVersionId: string }
  | { kind: 'reconciliation.suspense.investigate'; suspenseId: string; expectedFingerprint: string; evidenceReferences: readonly string[]; proposedAccountId: string | null }
  | { kind: 'reconciliation.suspense.clear'; suspenseId: string; expectedFingerprint: string; destinationAccountId: string; amount: Money; evidenceReference: string; approvalId: string }
  | { kind: 'batch.import'; documentVersionId: string; inputDigest: string; batchNumber: string; batchKind: 'contact-update' | 'fee-refund'; currency: string | null }
  | { kind: 'batch.contacts.apply'; batchId: string; itemId: string; expectedFingerprint: string; approvalId: string; conflictPolicy: 'skip-stale' | 'reject-all' }
  | { kind: 'batch.fee_refunds.apply'; batchId: string; itemId: string; expectedFingerprint: string; approvalId: string }
  | { kind: 'payment.schedule.end'; scheduleId: string; expectedFingerprint: string; endFromDate: string; pendingDisposition: 'cancel-planned' | 'retain-released'; approvalId: string }
  | { kind: 'account.maturity.instruct'; accountId: string; expectedVersion: number; expectedInstructionFingerprint: string | null; disposition: 'renew' | 'transfer' | 'hold'; destinationAccountId: string | null; termMonths: number | null; approvedAnnualRateBps: number | null; approvalId: string }
  | { kind: 'transaction.description.update'; journalId: string; expectedFingerprint: string; description: string }
  | { kind: 'loan.close'; loanId: string; expectedFingerprint: string; payoffEvidenceId: string; approvalId: string }
  | { kind: 'document.loan_closure.issue'; loanId: string; expectedClosureFingerprint: string; templateVersionId: string; recipientPartyId: string; documentType: 'loan-closure-confirmation' | 'simulated-lien-release'; approvalId: string };

export type FinanceCommandKind = FinanceCommand['kind'];

export const FINANCE_GRANTS: Readonly<Record<FinanceCommandKind, readonly string[]>> = {
  'member.merge': ['supervise'], 'member.deceased.record': ['supervise'], 'member.beneficial_owners.update': ['supervise'], 'member.tax_classification.update': ['supervise'],
  'account.product.convert': ['supervise'], 'account.owner.add': ['supervise'], 'account.signer.remove': ['supervise'], 'account.overdraft_limit.update': ['supervise'],
  'account.hold.place': ['maintain'], 'account.hold.release': ['maintain'], 'account.restriction.apply': ['supervise'], 'account.restriction.release': ['supervise'],
  'fee.assess': ['payment.prepare'], 'fee.waiver.create': ['supervise'], 'fee.refund': ['payment.prepare'], 'cash.deposit.reverse': ['financial.correction.approve'],
  'cash.withdrawal.reverse': ['financial.correction.approve'], 'transfer.internal.reverse': ['transfer.internal.reverse'], 'interest.adjust': ['interest.adjust'],
  'transaction.effective_date.correct': ['transaction.effective-date.correct'],
  'beneficiary.create': ['payment.prepare'], 'beneficiary.verify': ['payment.approve'], 'beneficiary.routing.update': ['payment.approve'], 'beneficiary.retire': ['payment.prepare'],
  'payment.create': ['payment.prepare'], 'payment.submit': ['payment.prepare'], 'payment.approve_release': ['payment.approve'], 'payment.settle': ['payment.approve'], 'payment.schedule.create': ['payment.approve'], 'payment.schedule.materialize': ['payment.prepare'], 'payment.occurrence.amend': ['payment.prepare'],
  'payment.cancel': ['payment.prepare'], 'payment.return.resolve': ['payment.approve'],
  'card.replace': ['maintain'], 'card.lock.update': ['maintain'], 'card.limit.update': ['supervise'], 'dispute.open': ['maintain'],
  'dispute.provisional_credit.issue': ['financial.correction.approve'], 'dispute.evidence.submit': ['maintain'], 'dispute.settle': ['financial.correction.approve'],
  'loan.application.prepare': ['maintain'], 'loan.payment.allocate': ['payment.prepare'], 'loan.payoff.quote': ['read'],
  'reconciliation.suspense.investigate': ['case.manage'], 'reconciliation.suspense.clear': ['financial.correction.approve'], 'batch.import': ['maintain'], 'batch.contacts.apply': ['supervise'],
  'batch.fee_refunds.apply': ['financial.correction.approve'], 'payment.schedule.end': ['payment.approve'],
  'account.maturity.instruct': ['supervise'], 'transaction.description.update': ['maintain'], 'loan.close': ['supervise'], 'document.loan_closure.issue': ['supervise'],
};

const REQUIRED: Readonly<Record<FinanceCommandKind, readonly string[]>> = Object.freeze({
  'member.merge': ['mergePlanId','sourceMemberId','targetMemberId','expectedSourceVersion','expectedTargetVersion','relationshipAccountIds','expectedInventoryFingerprint','approvalId'],
  'member.deceased.record': ['memberId','expectedVersion','evidenceId','effectiveDate','approvalId'],
  'member.beneficial_owners.update': ['organizationMemberId','expectedVersion','owners','effectiveDate','approvalId'],
  'member.tax_classification.update': ['memberId','expectedVersion','classification','effectiveYear','evidenceId','approvalId'],
  'account.product.convert': ['accountId','expectedVersion','targetProductId','effectiveDate','feeDisclosureAccepted','approvalId'],
  'account.owner.add': ['accountId','expectedVersion','memberId','role','effectiveDate','identityEvidenceId','consentId','approvalId'],
  'account.signer.remove': ['accountId','expectedVersion','signerMemberId','effectiveAt','approvalId'],
  'account.overdraft_limit.update': ['accountId','expectedVersion','expectedFacilityFingerprint','limit','effectiveDate','expiresAt','approvalId'],
  'account.hold.place': ['accountId','expectedVersion','amount','reason','expiresAt','releaseAuthority'],
  'account.hold.release': ['holdId','expectedFingerprint','amountMinorUnits','releaseAuthority','evidenceReference'],
  'account.restriction.apply': ['accountId','expectedVersion','restrictionType','reason','authority','caseId','approvalId'],
  'account.restriction.release': ['restrictionId','expectedFingerprint','clearanceEvidenceId','approvalId'],
  'fee.assess': ['accountId','expectedVersion','feeCode','amount','basis','policyVersionId'],
  'fee.waiver.create': ['accountId','feeCode','validFrom','validThrough','amountLimit','maxOccurrences','reason','approvalId'],
  'fee.refund': ['feeId','expectedFingerprint','amount','reason'],
  'cash.deposit.reverse': ['journalId','expectedFingerprint','correctionEvidenceId','approvalId'],
  'cash.withdrawal.reverse': ['journalId','expectedFingerprint','reason','approvalId'],
  'transfer.internal.reverse': ['transferJournalId','expectedFingerprint','amount','reason','approvalId'],
  'interest.adjust': ['accountId','calculationId','expectedFingerprint','approvedDelta','approvalId'],
  'transaction.effective_date.correct': ['journalId','expectedFingerprint','correctedDate','policyVersionId','reason','approvalId'],
  'beneficiary.create': ['memberId','expectedMemberVersion','displayName','routingKind','maskedDestination','simulatedToken','allowedRails'],
  'beneficiary.verify': ['beneficiaryId','routeId','expectedFingerprint','evidenceId','approvalId'],
  'beneficiary.routing.update': ['beneficiaryId','expectedRouteFingerprint','routingKind','maskedDestination','simulatedToken','effectiveDate','approvalId'],
  'beneficiary.retire': ['beneficiaryId','expectedFingerprint','dependentDisposition','reason'],
  'payment.create': ['sourceAccountId','expectedSourceVersion','beneficiaryRouteId','expectedRouteFingerprint','amount','rail','requestedDate','calendarVersion','cutoffAt','reference','targetState'],
  'payment.submit': ['paymentId','expectedVersion'],
  'payment.approve_release': ['paymentId','expectedVersion','requestedDate','calendarVersion','cutoffAt','approvalId'],
  'payment.settle': ['paymentId','expectedVersion','settlementReference'],
  'payment.schedule.create': ['sourceAccountId','expectedSourceVersion','beneficiaryRouteId','expectedRouteFingerprint','amount','frequency','interval','startDate','endDate','approvalId'],
  'payment.schedule.materialize': ['occurrenceId','expectedFingerprint'],
  'payment.occurrence.amend': ['occurrenceId','expectedFingerprint','newAmount','newDate'], 'payment.cancel': ['paymentId','expectedVersion','reason'],
  'payment.return.resolve': ['returnId','expectedFingerprint','paymentId','disposition','approvalId'],
  'card.replace': ['cardId','expectedFingerprint','reason','identityEvidenceId','deliveryDestinationId','deliveryAddressId'], 'card.lock.update': ['cardId','expectedFingerprint','requestedState','authority'],
  'card.limit.update': ['cardId','expectedFingerprint','limitKind','amount','effectiveAt','expiresAt','approvalId'],
  'dispute.open': ['cardTransactionId','expectedFingerprint','reason','assertedAmount','evidenceIds'],
  'dispute.provisional_credit.issue': ['disputeId','expectedFingerprint','amount','approvalId'],
  'dispute.evidence.submit': ['disputeId','expectedFingerprint','documentVersionIds','deadline','recipient','channel','approvalId'],
  'dispute.settle': ['disputeId','expectedFingerprint','decision','finalAmount','approvalId'],
  'loan.application.prepare': ['memberId','expectedMemberVersion','productId','requestedAmount','termMonths','purpose','evidenceIds'],
  'loan.payment.allocate': ['loanId','expectedFingerprint','receivedFundsReference','amount','allocationPolicy'],
  'loan.payoff.quote': ['loanId','expectedFingerprint','payoffDate','policyVersionId'],
  'reconciliation.suspense.investigate': ['suspenseId','expectedFingerprint','evidenceReferences','proposedAccountId'],
  'reconciliation.suspense.clear': ['suspenseId','expectedFingerprint','destinationAccountId','amount','evidenceReference','approvalId'],
  'batch.import': ['documentVersionId','inputDigest','batchNumber','batchKind','currency'],
  'batch.contacts.apply': ['batchId','itemId','expectedFingerprint','approvalId','conflictPolicy'], 'batch.fee_refunds.apply': ['batchId','itemId','expectedFingerprint','approvalId'],
  'payment.schedule.end': ['scheduleId','expectedFingerprint','endFromDate','pendingDisposition','approvalId'],
  'account.maturity.instruct': ['accountId','expectedVersion','expectedInstructionFingerprint','disposition','destinationAccountId','termMonths','approvedAnnualRateBps','approvalId'],
  'transaction.description.update': ['journalId','expectedFingerprint','description'], 'loan.close': ['loanId','expectedFingerprint','payoffEvidenceId','approvalId'],
  'document.loan_closure.issue': ['loanId','expectedClosureFingerprint','templateVersionId','recipientPartyId','documentType','approvalId'],
});

function record(value: unknown): value is Record<string, unknown> { return value !== null && typeof value === 'object' && !Array.isArray(value); }
function money(value: unknown): boolean { return record(value) && Object.keys(value).sort().join(',') === 'currency,minorUnits' && Number.isSafeInteger(value.minorUnits) && typeof value.currency === 'string'; }

const NUMBER_FIELDS = new Set([
  'expectedSourceVersion','expectedTargetVersion','expectedVersion','effectiveYear','amountMinorUnits','maxOccurrences','expectedMemberVersion','interval',
]);
const BOOLEAN_FIELDS = new Set(['feeDisclosureAccepted']);
const NUMBER_KEYS = new Set(['loan.application.prepare.termMonths']);
const NULLABLE_STRING_KEYS = new Set([
  'account.overdraft_limit.update.expectedFacilityFingerprint', 'account.overdraft_limit.update.expiresAt',
  'card.limit.update.expiresAt', 'reconciliation.suspense.investigate.proposedAccountId',
  'batch.import.currency',
  'account.maturity.instruct.expectedInstructionFingerprint', 'account.maturity.instruct.destinationAccountId',
]);
const NULLABLE_NUMBER_KEYS = new Set(['account.maturity.instruct.termMonths','account.maturity.instruct.approvedAnnualRateBps']);
const STRING_ARRAY_FIELDS = new Set(['relationshipAccountIds','allowedRails','evidenceIds','documentVersionIds','evidenceReferences','allowedMemberIds','allowedAccountIds','cashSessionIds']);
const ENUM_KEYS: Readonly<Record<string, readonly string[]>> = {
  'account.owner.add.role': ['owner','joint-owner'],
  'account.restriction.apply.restrictionType': ['debit-block','credit-block','closure-block','fraud-review','legal-hold'],
  'beneficiary.retire.dependentDisposition': ['reject-if-active','cancel-drafts'],
  'payment.create.targetState': ['draft','pending-approval'],
  'payment.schedule.create.frequency': ['daily','weekly','monthly'],
  'payment.return.resolve.disposition': ['credit-source','investigate'],
  'card.lock.update.requestedState': ['locked','unlocked'],
  'card.limit.update.limitKind': ['daily-purchase','cash','online'],
  'dispute.settle.decision': ['approved','denied'],
  'loan.payment.allocate.allocationPolicy': ['fees-interest-principal','fees-interest-principal-hold-remainder'],
  'batch.contacts.apply.conflictPolicy': ['skip-stale','reject-all'],
  'batch.import.batchKind': ['contact-update','fee-refund'],
  'payment.schedule.end.pendingDisposition': ['cancel-planned','retain-released'],
  'account.maturity.instruct.disposition': ['renew','transfer','hold'],
  'document.loan_closure.issue.documentType': ['loan-closure-confirmation','simulated-lien-release'],
};

/** Rejects unknown command kinds and fields before business validation or a write transaction begins. */
export function validateFinanceCommand(value: unknown): Rejection | null {
  if (!record(value) || typeof value.kind !== 'string' || !Object.hasOwn(REQUIRED, value.kind)) return { kind: 'rejected', code: 'validation', message: 'Unknown financial command kind.', field: 'kind' };
  const kind = value.kind as FinanceCommandKind;
  const required = REQUIRED[kind];
  const allowed = new Set(['kind', ...required]);
  const unknown = Object.keys(value).find((field) => !allowed.has(field));
  if (unknown !== undefined) return { kind: 'rejected', code: 'validation', message: `Unknown field ${unknown} for ${kind}.`, field: unknown };
  const missing = required.find((field) => !(field in value));
  if (missing !== undefined) return { kind: 'rejected', code: 'validation', message: `Missing required field ${missing}.`, field: missing };
  for (const [field, candidate] of Object.entries(value)) {
    if (field === 'kind') continue;
    const key = `${kind}.${field}`;
    if (field === 'amount' || field === 'limit' || field === 'amountLimit' || field === 'approvedDelta' || field === 'newAmount' || field === 'assertedAmount' || field === 'finalAmount' || field === 'requestedAmount' || field === 'declaredTotal') {
      if (!money(candidate)) return { kind: 'rejected', code: 'validation', message: `${field} must be an exact Money object.`, field };
      continue;
    }
    if (STRING_ARRAY_FIELDS.has(field)) {
      if (!Array.isArray(candidate) || candidate.some((item) => typeof item !== 'string')) return { kind: 'rejected', code: 'validation', message: `${field} must be an array of strings.`, field };
      continue;
    }
    if (field === 'owners') continue;
    if (BOOLEAN_FIELDS.has(field)) {
      if (typeof candidate !== 'boolean') return { kind: 'rejected', code: 'validation', message: `${field} must be boolean.`, field };
      continue;
    }
    if (NULLABLE_STRING_KEYS.has(key)) {
      if (candidate !== null && typeof candidate !== 'string') return { kind: 'rejected', code: 'validation', message: `${field} must be text or null.`, field };
      continue;
    }
    if (NULLABLE_NUMBER_KEYS.has(key)) {
      if (candidate !== null && !Number.isSafeInteger(candidate)) return { kind: 'rejected', code: 'validation', message: `${field} must be a safe integer or null.`, field };
      continue;
    }
    if (NUMBER_FIELDS.has(field) || NUMBER_KEYS.has(key)) {
      if (!Number.isSafeInteger(candidate)) return { kind: 'rejected', code: 'validation', message: `${field} must be a safe integer.`, field };
      continue;
    }
    const choices = ENUM_KEYS[key];
    if (choices !== undefined) {
      if (typeof candidate !== 'string' || !choices.includes(candidate)) return { kind: 'rejected', code: 'validation', message: `${field} is not a supported option.`, field };
      continue;
    }
    if (typeof candidate !== 'string') return { kind: 'rejected', code: 'validation', message: `${field} must be text.`, field };
  }
  if (kind === 'member.beneficial_owners.update' && (!Array.isArray(value.owners) || value.owners.some((owner) => !record(owner) || Object.keys(owner).sort().join(',') !== 'evidenceId,isControlPerson,memberId,ownershipBps' || typeof owner.memberId !== 'string' || typeof owner.evidenceId !== 'string' || typeof owner.isControlPerson !== 'boolean' || !Number.isSafeInteger(owner.ownershipBps)))) {
    return { kind: 'rejected', code: 'validation', message: 'Each beneficial owner must contain only memberId, ownershipBps, isControlPerson and evidenceId.', field: 'owners' };
  }
  return null;
}

export function isFinanceCommand(value: unknown): value is FinanceCommand { return validateFinanceCommand(value) === null; }
