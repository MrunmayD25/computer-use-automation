import { all, canonicalJson, int, one, optionalInt, optionalStr, reject, sha256, str, type Row } from './core.js';
import type { FinanceCommand } from './finance-types.js';
import type { SqlDatabase } from './store.js';
import type { Money, Rejection } from './types.js';

type RefundCommand = Extract<FinanceCommand, { kind: 'batch.fee_refunds.apply' }>;
type ContactCommand = Extract<FinanceCommand, { kind: 'batch.contacts.apply' }>;

const BATCH_COLUMNS = ['id','batch_number','kind','input_document_version_id','input_digest','state','approved_total_limit_minor_units','currency','created_at','items'] as const;

function batchSnapshot(database: SqlDatabase, datasetId: string, batchId: string): Row | undefined {
  const row = one(database, 'SELECT id,batch_number,kind,input_document_version_id,input_digest,state,approved_total_limit_minor_units,currency,created_at FROM batches WHERE dataset_id=? AND id=?', datasetId, batchId);
  if (row === undefined) return undefined;
  const items = all(database, 'SELECT id,ordinal,source_key,item_json,state,receipt_id,amount_minor_units,failure_code FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal,id', datasetId, batchId);
  return { ...row, items: canonicalJson(items) };
}

function batchFingerprint(row: Row): string {
  return sha256(canonicalJson(Object.fromEntries(BATCH_COLUMNS.map((column) => [column, row[column] ?? null]))));
}

export interface RefundCampaignApproval {
  scope: Record<string, unknown>;
  amount: Money;
}

export interface ContactCampaignApproval {
  scope: Record<string, unknown>;
}

/** Builds the immutable preview scope shared by contact approval and every item checkpoint. */
export function contactCampaignApproval(
  database: SqlDatabase,
  datasetId: string,
  command: ContactCommand,
): ContactCampaignApproval | Rejection {
  const batch = batchSnapshot(database, datasetId, command.batchId);
  if (batch === undefined) return reject('not_found', 'The contact batch does not exist.');
  if (batchFingerprint(batch) !== command.expectedFingerprint) return reject('stale_version', 'The batch changed after review. Reopen it before continuing.');
  if (str(batch, 'kind') !== 'contact-update' || !['previewed','approved','processing'].includes(str(batch, 'state'))) {
    return reject('ineligible', 'Only an immutable contact-update batch may receive campaign approval.');
  }
  const rows = all(database, 'SELECT id,ordinal,source_key,item_json FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal,id', datasetId, command.batchId);
  if (!rows.some((row) => str(row, 'id') === command.itemId)) return reject('ownership_mismatch', 'The selected item does not belong to this batch.', { field: 'itemId' });
  const items: Record<string, unknown>[] = [];
  for (const row of rows) {
    let input: unknown;
    try { input = JSON.parse(str(row, 'item_json')) as unknown; }
    catch { return reject('ineligible', 'The approved preview contains malformed item data.'); }
    items.push({ itemId: str(row, 'id'), ordinal: int(row, 'ordinal'), sourceKey: str(row, 'source_key'), input });
  }
  return {
    scope: {
      kind: command.kind,
      batchId: command.batchId,
      inputDocumentVersionId: str(batch, 'input_document_version_id'),
      inputDigest: str(batch, 'input_digest'),
      items,
      conflictPolicy: command.conflictPolicy,
    },
  };
}

/** Builds the immutable preview scope shared by approval request and every item checkpoint. */
export function refundCampaignApproval(
  database: SqlDatabase,
  datasetId: string,
  command: RefundCommand,
): RefundCampaignApproval | Rejection {
  const batch = batchSnapshot(database, datasetId, command.batchId);
  if (batch === undefined) return reject('not_found', 'The refund batch does not exist.');
  if (batchFingerprint(batch) !== command.expectedFingerprint) return reject('stale_version', 'The batch changed after review. Reopen it before continuing.');
  const limit = optionalInt(batch, 'approved_total_limit_minor_units');
  const currency = optionalStr(batch, 'currency');
  if (str(batch, 'kind') !== 'fee-refund' || !['previewed','approved','processing'].includes(str(batch, 'state')) || limit === null || currency === null) {
    return reject('ineligible', 'Only an immutable bounded fee-refund batch may receive campaign approval.');
  }
  const rows = all(database, 'SELECT id,ordinal,source_key,item_json FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal,id', datasetId, command.batchId);
  if (!rows.some((row) => str(row, 'id') === command.itemId)) return reject('ownership_mismatch', 'The selected item does not belong to this batch.', { field: 'itemId' });
  const items: Record<string, unknown>[] = [];
  for (const row of rows) {
    let input: unknown;
    try { input = JSON.parse(str(row, 'item_json')) as unknown; }
    catch { return reject('ineligible', 'The approved preview contains malformed item data.'); }
    items.push({ itemId: str(row, 'id'), ordinal: int(row, 'ordinal'), sourceKey: str(row, 'source_key'), input });
  }
  return {
    amount: { minorUnits: limit, currency },
    scope: {
      kind: command.kind,
      batchId: command.batchId,
      inputDocumentVersionId: str(batch, 'input_document_version_id'),
      inputDigest: str(batch, 'input_digest'),
      items,
      maximumNewRefundMinorUnits: limit,
      currency,
      conflictPolicy: 'skip',
    },
  };
}
