import { createHash } from 'node:crypto';

import { actorPermissions, actorRef, all, authorizeQuery, canonicalJson, datasetClock, int, one, optionalStr, reject, sha256, str, type Row } from './core.js';
import { canReadDocument, documentReadFilter } from './document-access.js';
import { readsRestrictedNotes } from './queries.js';
import { FINANCE_GRANTS } from './finance-types.js';
import { SERVICING_GRANTS } from './servicing-types.js';
import type { SqlDatabase } from './store.js';
import type { Rejection, ServiceContext } from './types.js';

export type ServicingQueryResult<T> = { kind: 'authorized'; value: T } | Rejection;

const READ_GRANTS = ['read', 'maintain', 'case.manage', 'supervise'] as const;

const DEFAULT_LIST_LIMIT = 200;
const MAX_LIST_LIMIT = 500;

function isRejection(value: unknown): value is Rejection {
  return value !== null && typeof value === 'object' && 'kind' in value && value.kind === 'rejected';
}

function authorized<T>(database: SqlDatabase, context: ServiceContext, read: (datasetId: string) => T | Rejection, grants: readonly string[] = READ_GRANTS): ServicingQueryResult<T> {
  const denied = authorizeQuery(database, context, grants);
  if (denied !== null) return denied;
  const value = read(context.binding.datasetId);
  return isRejection(value) ? value : { kind: 'authorized', value };
}

function invalidLimit(limit: number): Rejection | null {
  return Number.isSafeInteger(limit) && limit >= 1 && limit <= MAX_LIST_LIMIT ? null : reject('validation', `Limit must be an integer from 1 to ${MAX_LIST_LIMIT}.`, { field: 'limit' });
}

function reader(context: ServiceContext): { institutionId: string; actorId: string; now?: string } {
  return { institutionId: context.binding.institutionId, actorId: context.actorId, ...(context.now === undefined ? {} : { now: context.now }) };
}

export interface IdentityCriteria {
  displayName?: string;
  memberNumber?: string;
  email?: string;
  phone?: string;
  birthDate?: string;
}

export interface IdentityCandidate {
  memberId: string;
  memberNumber: string;
  partyId: string;
  displayName: string;
  status: string;
  email: string | null;
  phone: string | null;
  birthDate: string | null;
}

export type IdentityResolution =
  | { resolution: 'none'; candidates: readonly [] }
  | { resolution: 'unique'; candidates: readonly [IdentityCandidate] }
  | { resolution: 'ambiguous'; candidates: readonly IdentityCandidate[] };

function candidate(row: Row, criteria: IdentityCriteria): IdentityCandidate {
  return {
    memberId: str(row, 'member_id'), memberNumber: str(row, 'member_number'), partyId: str(row, 'party_id'), displayName: str(row, 'display_name'),
    status: str(row, 'status'), email: criteria.email === undefined ? null : optionalStr(row, 'email'), phone: criteria.phone === undefined ? null : optionalStr(row, 'phone'),
    birthDate: criteria.birthDate === undefined ? null : optionalStr(row, 'birth_date'),
  };
}

/** Resolves an identity using explicit candidate facts and reports ambiguity without selecting a member. */
export function resolveMemberIdentity(database: SqlDatabase, context: ServiceContext, criteria: IdentityCriteria, limit = 50): ServicingQueryResult<IdentityResolution> {
  return authorized(database, context, datasetId => {
  const limitIssue = invalidLimit(limit); if (limitIssue !== null) return limitIssue;
  const allowed = new Set<keyof IdentityCriteria>(['displayName', 'memberNumber', 'email', 'phone', 'birthDate']);
  const untrustedCriteria: unknown = criteria;
  if (untrustedCriteria === null || typeof untrustedCriteria !== 'object' || Array.isArray(untrustedCriteria)) return reject('validation', 'Identity criteria must be an object.');
  const entries = Object.entries(untrustedCriteria);
  if (entries.some(([key]) => !allowed.has(key as keyof IdentityCriteria))) return reject('validation', 'Identity criteria contains an unknown field.');
  if (entries.some(([, value]) => typeof value !== 'string')) return reject('validation', 'Every supplied identity criterion must be text.');
  const supplied = entries as [string, string][];
  if (supplied.length === 0 || supplied.some(([, value]) => value.trim().length === 0)) return reject('validation', 'Provide at least one non-empty identity criterion.');
  const validCriteria = untrustedCriteria as IdentityCriteria;
  const clauses = ['m.dataset_id=?']; const parameters: (string | number)[] = [datasetId];
  const displayName = validCriteria.displayName?.trim();
  if (displayName !== undefined && displayName.length > 0) { clauses.push('p.display_name=?'); parameters.push(displayName); }
  if (validCriteria.memberNumber !== undefined) { clauses.push('m.member_number=?'); parameters.push(validCriteria.memberNumber.trim().toUpperCase()); }
  if (validCriteria.email !== undefined) { clauses.push(`EXISTS (SELECT 1 FROM contact_points ce WHERE ce.dataset_id=m.dataset_id AND ce.party_id=m.party_id AND ce.kind='email' AND ce.valid_to IS NULL AND lower(ce.value)=lower(?))`); parameters.push(validCriteria.email.trim()); }
  if (validCriteria.phone !== undefined) { clauses.push(`EXISTS (SELECT 1 FROM contact_points cp WHERE cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='phone' AND cp.valid_to IS NULL AND cp.value=?)`); parameters.push(validCriteria.phone.trim()); }
  if (validCriteria.birthDate !== undefined) { clauses.push('pe.birth_date=?'); parameters.push(validCriteria.birthDate); }
  const rows = all(database, `SELECT m.id AS member_id,m.member_number,m.party_id,p.display_name,m.status,pe.birth_date,
      (SELECT c.value FROM contact_points c WHERE c.dataset_id=m.dataset_id AND c.party_id=m.party_id AND c.kind='email' AND c.valid_to IS NULL ORDER BY c.valid_from DESC,c.id LIMIT 1) AS email,
      (SELECT c.value FROM contact_points c WHERE c.dataset_id=m.dataset_id AND c.party_id=m.party_id AND c.kind='phone' AND c.valid_to IS NULL ORDER BY c.valid_from DESC,c.id LIMIT 1) AS phone
    FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id LEFT JOIN people pe ON pe.dataset_id=m.dataset_id AND pe.party_id=m.party_id
    WHERE ${clauses.join(' AND ')} AND m.status<>'merged' ORDER BY m.member_number LIMIT ?`, ...parameters, limit + 1).map(row => candidate(row, validCriteria));
    if (rows.length > limit) return reject('limit_exceeded', `Identity criteria matched more than ${limit} members; add another exact criterion.`);
    if (rows.length === 0) return { resolution: 'none', candidates: [] };
    if (rows.length === 1) return { resolution: 'unique', candidates: [rows[0] as IdentityCandidate] };
    return { resolution: 'ambiguous', candidates: rows };
  });
}

export interface HistoricalStatementVersion {
  documentId: string;
  versionId: string;
  version: number;
  accountId: string;
  memberId: string;
  periodStart: string;
  periodEnd: string;
  status: string;
  mediaType: string;
  digest: string;
  byteLength: number;
  bytes: Uint8Array;
}

/** Retrieves a statement by exact account and period, including the immutable content-addressed bytes. */
export function retrieveHistoricalStatement(database: SqlDatabase, context: ServiceContext, accountId: string, periodStart: string, periodEnd: string, format?: string): ServicingQueryResult<HistoricalStatementVersion | undefined> {
  return authorized(database, context, datasetId => {
  const access = documentReadFilter(database, datasetId, reader(context));
  const row = one(database, `SELECT v.id AS version_id,v.document_id,v.version,v.digest,v.media_type,v.period_start,v.period_end,v.status,d.account_id,a.member_id,b.byte_length,b.bytes
    FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id
    JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
    WHERE v.dataset_id=? AND d.account_id=? AND d.document_type='account-statement' AND v.period_start=? AND v.period_end=?${format === undefined ? '' : ' AND v.media_type=?'}
      AND ${access}
    ORDER BY v.version DESC,v.issued_at DESC,v.id DESC LIMIT 1`, ...(format === undefined
      ? [datasetId, accountId, periodStart, periodEnd]
      : [datasetId, accountId, periodStart, periodEnd, format]));
    if (row === undefined) return undefined;
    const bytes = row.bytes; if (!(bytes instanceof Uint8Array)) throw new Error('Stored statement bytes are invalid.');
    const computed = createHash('sha256').update(bytes).digest('hex'); if (computed !== str(row, 'digest')) throw new Error('Stored statement digest does not match bytes.');
    if (bytes.byteLength !== int(row, 'byte_length')) throw new Error('Stored statement byte length does not match bytes.');
    return {
      documentId: str(row, 'document_id'), versionId: str(row, 'version_id'), version: int(row, 'version'), accountId: str(row, 'account_id'), memberId: str(row, 'member_id'),
      periodStart: str(row, 'period_start'), periodEnd: str(row, 'period_end'), status: str(row, 'status'), mediaType: str(row, 'media_type'), digest: str(row, 'digest'), byteLength: int(row, 'byte_length'), bytes: Uint8Array.from(bytes),
    };
  });
}

export interface CustomerExportArtifact {
  documentId: string;
  versionId: string;
  memberId: string;
  mediaType: 'application/json';
  digest: string;
  byteLength: number;
  bytes: Uint8Array;
}

/** Retrieves the exact immutable bytes of a generated customer export within one member scope. */
export function retrieveCustomerExportArtifact(database: SqlDatabase, context: ServiceContext, memberId: string, versionId: string): ServicingQueryResult<CustomerExportArtifact | undefined> {
  return authorized(database, context, datasetId => {
    const row = one(database, `SELECT d.id AS document_id,v.id AS version_id,m.id AS member_id,v.media_type,v.digest,b.byte_length,b.bytes
      FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
      JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      WHERE v.dataset_id=? AND v.id=? AND m.id=? AND d.document_type='customer-record-export' AND ${documentReadFilter(database, datasetId, reader(context))}`, datasetId, versionId, memberId);
    if (row === undefined) return undefined;
    if (str(row, 'media_type') !== 'application/json') throw new Error('Customer export artifact has an invalid media type.');
    const bytes = row.bytes; if (!(bytes instanceof Uint8Array)) throw new Error('Customer export artifact bytes are invalid.');
    if (bytes.byteLength !== int(row, 'byte_length') || createHash('sha256').update(bytes).digest('hex') !== str(row, 'digest')) throw new Error('Customer export artifact failed its integrity check.');
    return { documentId: str(row, 'document_id'), versionId: str(row, 'version_id'), memberId: str(row, 'member_id'), mediaType: 'application/json', digest: str(row, 'digest'), byteLength: bytes.byteLength, bytes: Uint8Array.from(bytes) };
  }, ['supervise']);
}

export interface DocumentVersionSummary {
  versionId: string;
  documentId: string;
  ownerPartyId: string;
  accountId: string | null;
  documentType: string;
  displayName: string;
  retentionClass: string;
  version: number;
  status: string;
  mediaType: string;
  digest: string;
  byteLength: number;
  periodStart: string | null;
  periodEnd: string | null;
}

/** Lists immutable document versions for one member scope, including bytes metadata but never content. */
export function listMemberDocumentVersions(database: SqlDatabase, context: ServiceContext, memberId: string, documentType?: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<DocumentVersionSummary[]> {
  return authorized(database, context, datasetId => {
  const limitIssue = invalidLimit(limit); if (limitIssue !== null) return limitIssue;
  const access = documentReadFilter(database, datasetId, reader(context));
  const rows = all(database, `SELECT v.id AS version_id,v.document_id,d.owner_party_id,d.account_id,d.document_type,d.display_name,d.retention_class,v.version,v.status,v.media_type,v.digest,b.byte_length,v.period_start,v.period_end
    FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
    JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest WHERE v.dataset_id=? AND m.id=?${documentType === undefined ? '' : ' AND d.document_type=?'}
    AND ${access}
    ORDER BY v.issued_at,v.id LIMIT ?`, ...(documentType === undefined ? [datasetId, memberId, limit + 1] : [datasetId, memberId, documentType, limit + 1]));
    if (rows.length > limit) return reject('limit_exceeded', `More than ${limit} document versions match; narrow the document type or raise the bounded limit.`);
    return rows.map(row => ({ versionId: str(row, 'version_id'), documentId: str(row, 'document_id'), ownerPartyId: str(row, 'owner_party_id'), accountId: optionalStr(row, 'account_id'), documentType: str(row, 'document_type'), displayName: str(row, 'display_name'), retentionClass: str(row, 'retention_class'), version: int(row, 'version'), status: str(row, 'status'), mediaType: str(row, 'media_type'), digest: str(row, 'digest'), byteLength: int(row, 'byte_length'), periodStart: optionalStr(row, 'period_start'), periodEnd: optionalStr(row, 'period_end') }));
  });
}

function boundedRows(database: SqlDatabase, limit: number, subject: string, sql: string, ...parameters: (string | number)[]): Row[] | Rejection {
  const limitIssue = invalidLimit(limit); if (limitIssue !== null) return limitIssue;
  const result = all(database, sql, ...parameters, limit + 1);
  return result.length > limit ? reject('limit_exceeded', `More than ${limit} ${subject} match; narrow the member or resource scope.`) : result;
}

function memberPartyId(database: SqlDatabase, datasetId: string, memberId: string): string | Rejection {
  const row = one(database, "SELECT party_id FROM members WHERE dataset_id=? AND id=? AND status<>'merged'", datasetId, memberId);
  return row === undefined ? reject('not_found', 'The member does not exist.') : str(row, 'party_id');
}

export interface IdentityEvidenceSummary {
  id: string;
  memberId: string;
  partyId: string;
  kind: string;
  status: string;
  issuedAt: string;
  expiresAt: string | null;
  sourceReference: string;
  documentVersionId: string | null;
  digest: string | null;
}

export interface CaseSubjectCorrectionEvidenceDocument extends DocumentVersionSummary {
  memberId: string;
}

export interface CaseSubjectCorrectionEvidence {
  identityEvidence: IdentityEvidenceSummary[];
  evidenceDocuments: CaseSubjectCorrectionEvidenceDocument[];
}

/** Lists the identity evidence that can be supplied to verification and legal-name commands. */
export function listMemberIdentityEvidence(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<IdentityEvidenceSummary[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const result = boundedRows(database, limit, 'identity evidence records', `SELECT id,kind,status,issued_at,expires_at,reference FROM identity_evidence
      WHERE dataset_id=? AND party_id=? ORDER BY issued_at DESC,id DESC LIMIT ?`, datasetId, partyId);
    if (!Array.isArray(result)) return result;
    return result.map(row => {
      const storedReference = str(row, 'reference');
      let sourceReference = storedReference; let documentVersionId: string | null = null; let contentDigest: string | null = null;
      try {
        const binding: unknown = JSON.parse(storedReference);
        if (binding !== null && typeof binding === 'object' && !Array.isArray(binding)) {
          const record = binding as Record<string, unknown>;
          sourceReference = typeof record.reference === 'string' ? record.reference : storedReference;
          documentVersionId = typeof record.documentVersionId === 'string' ? record.documentVersionId : null;
          contentDigest = typeof record.digest === 'string' ? record.digest : null;
        }
      } catch { /* Legacy evidence retains its opaque source reference and has no immutable document binding. */ }
      return { id: str(row, 'id'), memberId, partyId, kind: str(row, 'kind'), status: str(row, 'status'), issuedAt: str(row, 'issued_at'), expiresAt: optionalStr(row, 'expires_at'), sourceReference, documentVersionId, digest: contentDigest };
    });
  }, ['maintain', 'supervise']);
}

export interface NameHistorySummary {
  id: string;
  kind: string;
  givenName: string | null;
  familyName: string;
  validFrom: string;
  validTo: string | null;
  evidenceId: string | null;
}

/** Lists dated legal, preferred, and former names within the authorized member scope. */
export function listMemberNameHistory(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<NameHistorySummary[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const rows = boundedRows(database, limit, 'member name history', `SELECT id,kind,given_name,family_name,valid_from,valid_to,evidence_id
      FROM name_history WHERE dataset_id=? AND party_id=? ORDER BY valid_from DESC,id DESC LIMIT ?`, datasetId, partyId);
    if (!Array.isArray(rows)) return rows;
    return rows.map(row => ({ id: str(row, 'id'), kind: str(row, 'kind'), givenName: optionalStr(row, 'given_name'), familyName: str(row, 'family_name'), validFrom: str(row, 'valid_from'), validTo: optionalStr(row, 'valid_to'), evidenceId: optionalStr(row, 'evidence_id') }));
  });
}

export interface TaxHistorySummary {
  id: string;
  classification: string;
  validFrom: string;
  validTo: string | null;
  evidenceId: string | null;
}

/** Lists dated tax classifications within the authorized member scope. */
export function listMemberTaxHistory(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<TaxHistorySummary[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const rows = boundedRows(database, limit, 'member tax history', `SELECT id,classification,valid_from,valid_to,evidence_id
      FROM tax_status_history WHERE dataset_id=? AND member_id=? ORDER BY valid_from DESC,id DESC LIMIT ?`, datasetId, memberId);
    if (!Array.isArray(rows)) return rows;
    return rows.map(row => ({ id: str(row, 'id'), classification: str(row, 'classification'), validFrom: str(row, 'valid_from'), validTo: optionalStr(row, 'valid_to'), evidenceId: optionalStr(row, 'evidence_id') }));
  });
}

/** Lists bounded current evidence from both the corrected and original case-subject scopes. */
export function listCaseSubjectCorrectionEvidence(database: SqlDatabase, context: ServiceContext, originalMemberId: string, correctedMemberId: string): ServicingQueryResult<CaseSubjectCorrectionEvidence> {
  const identityEvidence = new Map<string, IdentityEvidenceSummary>();
  const evidenceDocuments = new Map<string, CaseSubjectCorrectionEvidenceDocument>();
  for (const memberId of new Set([correctedMemberId, originalMemberId])) {
    const identities = listMemberIdentityEvidence(database, context, memberId, MAX_LIST_LIMIT);
    if (identities.kind === 'rejected') return identities;
    for (const item of identities.value) identityEvidence.set(item.id, item);
    const documents = listMemberDocumentVersions(database, context, memberId, undefined, MAX_LIST_LIMIT);
    if (documents.kind === 'rejected') return documents;
    for (const item of documents.value) {
      if (item.status === 'current' || item.status === 'signed') evidenceDocuments.set(item.versionId, { ...item, memberId });
    }
  }
  return { kind: 'authorized', value: { identityEvidence: [...identityEvidence.values()], evidenceDocuments: [...evidenceDocuments.values()] } };
}

export interface MemberAddressSummary {
  partyAddressId: string;
  addressId: string;
  partyId: string;
  purpose: string;
  line1: string;
  line2: string | null;
  city: string;
  region: string;
  postalCode: string;
  country: string;
  validFrom: string;
  validTo: string | null;
  evidenceStatus: string;
  evidenceVersionId: string | null;
}

/** Lists dated address records with the stable identities required by address reconciliation. */
export function listMemberAddresses(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<MemberAddressSummary[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const result = boundedRows(database, limit, 'member addresses', `SELECT pa.id AS party_address_id,pa.address_id,pa.purpose,pa.valid_from,pa.valid_to,pa.evidence_status,pa.evidence_version_id,
      a.line1,a.line2,a.city,a.region,a.postal_code,a.country FROM party_addresses pa JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
      WHERE pa.dataset_id=? AND pa.party_id=? ORDER BY pa.valid_from DESC,pa.id DESC LIMIT ?`, datasetId, partyId);
    if (!Array.isArray(result)) return result;
    return result.map(row => ({ partyAddressId: str(row, 'party_address_id'), addressId: str(row, 'address_id'), partyId, purpose: str(row, 'purpose'), line1: str(row, 'line1'), line2: optionalStr(row, 'line2'), city: str(row, 'city'), region: str(row, 'region'), postalCode: str(row, 'postal_code'), country: str(row, 'country'), validFrom: str(row, 'valid_from'), validTo: optionalStr(row, 'valid_to'), evidenceStatus: str(row, 'evidence_status'), evidenceVersionId: optionalStr(row, 'evidence_version_id') }));
  });
}

export interface ConsentSummary {
  id: string;
  partyId: string;
  accountId: string | null;
  purpose: string;
  channel: string;
  disclosureVersionId: string;
  state: string;
  effectiveAt: string;
}

/** Lists consent history for one member while applying the disclosure document's read policy. */
export function listMemberConsents(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<ConsentSummary[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const access = documentReadFilter(database, datasetId, reader(context));
    const result = boundedRows(database, limit, 'member consent records', `SELECT c.id,c.account_id,c.purpose,c.channel,c.disclosure_version_id,c.state,c.effective_at
      FROM consents c JOIN document_versions v ON v.dataset_id=c.dataset_id AND v.id=c.disclosure_version_id
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE c.dataset_id=? AND c.party_id=? AND ${access}
      ORDER BY c.effective_at DESC,c.id DESC LIMIT ?`, datasetId, partyId);
    if (!Array.isArray(result)) return result;
    return result.map(row => ({ id: str(row, 'id'), partyId, accountId: optionalStr(row, 'account_id'), purpose: str(row, 'purpose'), channel: str(row, 'channel'), disclosureVersionId: str(row, 'disclosure_version_id'), state: str(row, 'state'), effectiveAt: str(row, 'effective_at') }));
  });
}

export interface SignatureSummary {
  id: string;
  documentVersionId: string;
  signerPartyId: string;
  status: string;
  requestedAt: string;
  signedAt: string | null;
  evidenceReference: string | null;
}

/** Lists signer states for one visible immutable document version. */
export function listDocumentSignatures(database: SqlDatabase, context: ServiceContext, documentVersionId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<SignatureSummary[]> {
  return authorized(database, context, datasetId => {
    if (!canReadDocument(database, datasetId, documentVersionId, reader(context))) return reject('not_authorized', 'This signature request belongs to a restricted document.');
    const result = boundedRows(database, limit, 'document signatures', `SELECT id,signer_party_id,status,requested_at,signed_at,evidence_reference FROM signatures
      WHERE dataset_id=? AND document_version_id=? ORDER BY requested_at,id LIMIT ?`, datasetId, documentVersionId);
    if (!Array.isArray(result)) return result;
    for (const row of result) {
      const evidenceReference = optionalStr(row, 'evidence_reference');
      if (evidenceReference !== null && !canReadDocument(database, datasetId, evidenceReference, reader(context))) return reject('not_authorized', 'A signature response references restricted evidence.');
    }
    return result.map(row => ({ id: str(row, 'id'), documentVersionId, signerPartyId: str(row, 'signer_party_id'), status: str(row, 'status'), requestedAt: str(row, 'requested_at'), signedAt: optionalStr(row, 'signed_at'), evidenceReference: optionalStr(row, 'evidence_reference') }));
  });
}

export interface RetentionHoldSummary {
  id: string;
  documentId: string | null;
  caseId: string | null;
  reason: string;
  state: string;
  placedAt: string;
  reviewAt: string;
  releasedAt: string | null;
}

/** Lists document and case retention holds within one member scope. */
export function listMemberRetentionHolds(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<RetentionHoldSummary[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const access = documentReadFilter(database, datasetId, reader(context));
    const restrictedCases = readsRestrictedNotes(database, datasetId, reader(context)) ? '' : " AND (h.case_id IS NULL OR q.visibility='general')";
    const result = boundedRows(database, limit, 'retention holds', `SELECT DISTINCT h.id,h.document_id,h.case_id,h.reason,h.state,h.placed_at,h.review_at,h.released_at FROM retention_holds h
      LEFT JOIN documents d ON d.dataset_id=h.dataset_id AND d.id=h.document_id
      LEFT JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
      LEFT JOIN cases c ON c.dataset_id=h.dataset_id AND c.id=h.case_id LEFT JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id
      WHERE h.dataset_id=? AND ((h.document_id IS NOT NULL AND d.owner_party_id=? AND ${access}) OR (h.case_id IS NOT NULL AND c.member_id=?))${restrictedCases}
      ORDER BY h.placed_at DESC,h.id DESC LIMIT ?`, datasetId, partyId, memberId);
    if (!Array.isArray(result)) return result;
    return result.map(row => ({ id: str(row, 'id'), documentId: optionalStr(row, 'document_id'), caseId: optionalStr(row, 'case_id'), reason: str(row, 'reason'), state: str(row, 'state'), placedAt: str(row, 'placed_at'), reviewAt: str(row, 'review_at'), releasedAt: optionalStr(row, 'released_at') }));
  });
}

export interface CommunicationPreferenceSummary {
  id: string;
  partyId: string;
  purpose: string;
  channel: string;
  state: string;
  updatedAt: string;
}

/** Lists the channel/purpose preferences that gate optional communications. */
export function listMemberCommunicationPreferences(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<CommunicationPreferenceSummary[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const result = boundedRows(database, limit, 'communication preferences', `SELECT id,purpose,channel,state,updated_at FROM communication_preferences
      WHERE dataset_id=? AND party_id=? ORDER BY purpose,channel,id LIMIT ?`, datasetId, partyId);
    if (!Array.isArray(result)) return result;
    return result.map(row => ({ id: str(row, 'id'), partyId, purpose: str(row, 'purpose'), channel: str(row, 'channel'), state: str(row, 'state'), updatedAt: str(row, 'updated_at') }));
  });
}

export interface AddressDestinationSummary {
  id: string;
  context: string;
  targetId: string;
  partyAddressId: string;
  evidenceVersionId: string;
  consentId: string | null;
  effectiveAt: string;
  endsAt: string | null;
  address: { line1: string; line2: string | null; city: string; region: string; postalCode: string; country: string; evidenceStatus: string };
}

/** Lists dated postal destinations for every member-owned servicing context. */
export function listMemberAddressDestinations(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<AddressDestinationSummary[]> {
  return authorized(database, context, datasetId => {
    const access = documentReadFilter(database, datasetId, reader(context));
    const result = boundedRows(database, limit, 'address destinations', `SELECT ad.id,ad.context_kind,ad.member_id,ad.account_id,ad.card_id,ad.loan_id,ad.party_address_id,ad.evidence_version_id,ad.consent_id,ad.effective_at,ad.ends_at,
      addr.line1,addr.line2,addr.city,addr.region,addr.postal_code,addr.country,pa.evidence_status FROM address_destinations ad
      JOIN party_addresses pa ON pa.dataset_id=ad.dataset_id AND pa.id=ad.party_address_id JOIN addresses addr ON addr.dataset_id=pa.dataset_id AND addr.id=pa.address_id
      JOIN document_versions v ON v.dataset_id=ad.dataset_id AND v.id=ad.evidence_version_id JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      LEFT JOIN accounts aa ON aa.dataset_id=ad.dataset_id AND aa.id=ad.account_id
      LEFT JOIN cards card ON card.dataset_id=ad.dataset_id AND card.id=ad.card_id LEFT JOIN accounts ca ON ca.dataset_id=card.dataset_id AND ca.id=card.account_id
      LEFT JOIN loans loan ON loan.dataset_id=ad.dataset_id AND loan.id=ad.loan_id LEFT JOIN accounts la ON la.dataset_id=loan.dataset_id AND la.id=loan.account_id
      WHERE ad.dataset_id=? AND (ad.member_id=? OR aa.member_id=? OR ca.member_id=? OR la.member_id=?) AND ${access}
      ORDER BY ad.effective_at DESC,ad.id DESC LIMIT ?`, datasetId, memberId, memberId, memberId, memberId);
    if (!Array.isArray(result)) return result;
    return result.map(row => {
      const destinationContext = str(row, 'context_kind');
      const targetId = optionalStr(row, destinationContext === 'member-mailing' ? 'member_id' : destinationContext === 'account-statement' ? 'account_id' : destinationContext === 'card-shipping' ? 'card_id' : 'loan_id');
      if (targetId === null) throw new Error(`Address destination ${str(row, 'id')} has no context target.`);
      return { id: str(row, 'id'), context: destinationContext, targetId, partyAddressId: str(row, 'party_address_id'), evidenceVersionId: str(row, 'evidence_version_id'), consentId: optionalStr(row, 'consent_id'), effectiveAt: str(row, 'effective_at'), endsAt: optionalStr(row, 'ends_at'), address: { line1: str(row, 'line1'), line2: optionalStr(row, 'line2'), city: str(row, 'city'), region: str(row, 'region'), postalCode: str(row, 'postal_code'), country: str(row, 'country'), evidenceStatus: str(row, 'evidence_status') } };
    });
  });
}

export interface PolicyVersionSummary { id: string; name: string; version: string; effectiveAt: string }

export interface ServicingQueueSummary { id: string; code: string; name: string; visibility: string }

export interface ServicingApprovalCheckerSummary { id: string; actorNumber: string; displayName: string }

/** Lists other active operators who currently hold a grant accepted by the servicing command. */
const APPROVAL_TARGET_GRANTS: Readonly<Record<string, readonly string[]>> = { ...SERVICING_GRANTS, ...FINANCE_GRANTS };

export function listServicingApprovalCheckers(database: SqlDatabase, context: ServiceContext, commandKind: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<ServicingApprovalCheckerSummary[]> {
  return authorized(database, context, datasetId => {
    const limitIssue = invalidLimit(limit); if (limitIssue !== null) return limitIssue;
    const grants = APPROVAL_TARGET_GRANTS[commandKind];
    if (grants === undefined) return reject('validation', 'Unknown command kind.', { field: 'commandKind' });
    const actorRows = all(database, "SELECT id FROM actors WHERE dataset_id=? AND status='active' ORDER BY actor_number,id LIMIT ?", datasetId, MAX_LIST_LIMIT + 1);
    if (actorRows.length > MAX_LIST_LIMIT) return reject('limit_exceeded', `More than ${MAX_LIST_LIMIT} active operators require a narrower checker directory.`);
    const now = context.now ?? datasetClock(database, datasetId).asOf;
    const matches = actorRows
      .map(row => str(row, 'id'))
      .filter(actorId => actorId !== context.actorId && grants.some(grant => actorPermissions(database, datasetId, context.binding.institutionId, actorId, now).has(grant)))
      .flatMap(actorId => { const actor = actorRef(database, datasetId, actorId); return actor === undefined ? [] : [actor]; });
    if (matches.length > limit) return reject('limit_exceeded', `More than ${limit} approval checkers match; lower the command scope or raise the bounded limit.`);
    return matches;
  });
}

/** Lists queue identities that can be supplied to case open and routing commands. */
export function listServicingQueues(database: SqlDatabase, context: ServiceContext, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<ServicingQueueSummary[]> {
  return authorized(database, context, datasetId => {
    const result = boundedRows(database, limit, 'servicing queues', 'SELECT id,code,name,visibility FROM queues WHERE dataset_id=? ORDER BY code,id LIMIT ?', datasetId);
    if (!Array.isArray(result)) return result;
    return result.map(row => ({ id: str(row, 'id'), code: str(row, 'code'), name: str(row, 'name'), visibility: str(row, 'visibility') }));
  });
}

/** Lists effective approval policy identities for commands that require an independent checker. */
export function listEffectivePolicyVersions(database: SqlDatabase, context: ServiceContext, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<PolicyVersionSummary[]> {
  return authorized(database, context, datasetId => {
    const result = boundedRows(database, limit, 'effective policy versions', `SELECT id,name,version,effective_at FROM policy_versions
      WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id DESC LIMIT ?`, datasetId, context.now ?? datasetClock(database, datasetId).asOf);
    if (!Array.isArray(result)) return result;
    return result.map(row => ({ id: str(row, 'id'), name: str(row, 'name'), version: str(row, 'version'), effectiveAt: str(row, 'effective_at') }));
  });
}

export interface MaintenanceRequestSummary {
  id: string;
  requestNumber: string;
  memberId: string;
  accountId: string | null;
  category: string;
  reason: string | null;
  subject: string;
  draft: unknown;
  state: string;
  createdAt: string;
  updatedAt: string;
  appliedReceiptId: string | null;
  attachments: readonly { documentVersionId: string; purpose: string }[];
}

export interface DocumentAnnotationSummary {
  id: string;
  documentVersionId: string;
  actorId: string;
  pageNumber: number;
  regionJson: string;
  text: string;
  status: string;
  createdAt: string;
  fingerprint: string;
}

function annotationSummary(row: Row): DocumentAnnotationSummary {
  const columns = ['id', 'document_version_id', 'actor_id', 'page_number', 'region_json', 'text', 'status', 'created_at'] as const;
  return {
    id: str(row, 'id'), documentVersionId: str(row, 'document_version_id'), actorId: str(row, 'actor_id'), pageNumber: int(row, 'page_number'),
    regionJson: str(row, 'region_json'), text: str(row, 'text'), status: str(row, 'status'), createdAt: str(row, 'created_at'),
    fingerprint: sha256(canonicalJson(Object.fromEntries(columns.map(column => [column, row[column] ?? null])))),
  };
}

/** Reads one visible annotation with the complete-state fingerprint required for amend/remove. */
export function documentAnnotation(database: SqlDatabase, context: ServiceContext, annotationId: string): ServicingQueryResult<DocumentAnnotationSummary | undefined> {
  return authorized(database, context, datasetId => {
    const row = one(database, `SELECT id,document_version_id,actor_id,page_number,region_json,text,status,created_at
      FROM document_annotations WHERE dataset_id=? AND id=?`, datasetId, annotationId);
    if (row === undefined) return undefined;
    const versionId = str(row, 'document_version_id');
    if (!canReadDocument(database, datasetId, versionId, reader(context))) return reject('not_authorized', 'This annotation belongs to a restricted document.');
    return annotationSummary(row);
  });
}

/** Lists annotations for one visible document version, including concurrency fingerprints. */
export function listDocumentAnnotations(database: SqlDatabase, context: ServiceContext, documentVersionId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<DocumentAnnotationSummary[]> {
  return authorized(database, context, datasetId => {
    if (!canReadDocument(database, datasetId, documentVersionId, reader(context))) return reject('not_authorized', 'These annotations belong to a restricted document.');
    const result = boundedRows(database, limit, 'document annotations', `SELECT id,document_version_id,actor_id,page_number,region_json,text,status,created_at FROM document_annotations
      WHERE dataset_id=? AND document_version_id=? ORDER BY page_number,created_at,id LIMIT ?`, datasetId, documentVersionId);
    return Array.isArray(result) ? result.map(annotationSummary) : result;
  });
}

/** Reads a durable maintenance request and its attachments by request identity. */
export function maintenanceRequest(database: SqlDatabase, context: ServiceContext, requestId: string, attachmentLimit = DEFAULT_LIST_LIMIT): ServicingQueryResult<MaintenanceRequestSummary | undefined> {
  return authorized(database, context, datasetId => {
  const limitIssue = invalidLimit(attachmentLimit); if (limitIssue !== null) return limitIssue;
  const row = one(database, 'SELECT id,request_number,member_id,account_id,category,reason,subject,draft_json,state,created_at,updated_at,applied_receipt_id FROM maintenance_requests WHERE dataset_id=? AND id=?', datasetId, requestId);
    if (row === undefined) return undefined;
    const access = documentReadFilter(database, datasetId, reader(context));
    if (one(database, `SELECT 1 AS restricted FROM request_attachments ra JOIN document_versions v
      ON v.dataset_id=ra.dataset_id AND v.id=ra.document_version_id JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE ra.dataset_id=? AND ra.request_id=? AND NOT (${access}) LIMIT 1`, datasetId, requestId) !== undefined) return reject('not_authorized', 'The maintenance request contains restricted document evidence.');
    let draft: unknown; try { draft = JSON.parse(str(row, 'draft_json')); } catch { draft = str(row, 'draft_json'); }
    const attachmentRows = all(database, 'SELECT document_version_id,purpose FROM request_attachments WHERE dataset_id=? AND request_id=? ORDER BY document_version_id LIMIT ?', datasetId, requestId, attachmentLimit + 1);
    if (attachmentRows.length > attachmentLimit) return reject('limit_exceeded', `Maintenance request has more than ${attachmentLimit} attachments.`);
    const attachments = attachmentRows.map(item => ({ documentVersionId: str(item, 'document_version_id'), purpose: str(item, 'purpose') }));
    return { id: str(row, 'id'), requestNumber: str(row, 'request_number'), memberId: str(row, 'member_id'), accountId: optionalStr(row, 'account_id'), category: str(row, 'category'), reason: optionalStr(row, 'reason'), subject: str(row, 'subject'), draft, state: str(row, 'state'), createdAt: str(row, 'created_at'), updatedAt: str(row, 'updated_at'), appliedReceiptId: optionalStr(row, 'applied_receipt_id'), attachments };
  });
}

/** Lists durable request references for one member; each returned request remains attachment bounded. */
export function listMemberMaintenanceRequests(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT, attachmentLimit = DEFAULT_LIST_LIMIT): ServicingQueryResult<MaintenanceRequestSummary[]> {
  return authorized(database, context, datasetId => {
    const member = memberPartyId(database, datasetId, memberId); if (typeof member !== 'string') return member;
    const attachmentLimitIssue = invalidLimit(attachmentLimit); if (attachmentLimitIssue !== null) return attachmentLimitIssue;
    const result = boundedRows(database, limit, 'maintenance requests', `SELECT id FROM maintenance_requests WHERE dataset_id=? AND member_id=?
      ORDER BY updated_at DESC,id DESC LIMIT ?`, datasetId, memberId);
    if (!Array.isArray(result)) return result;
    const requests: MaintenanceRequestSummary[] = [];
    for (const row of result) {
      const outcome = maintenanceRequest(database, context, str(row, 'id'), attachmentLimit);
      if (outcome.kind === 'rejected') return outcome;
      if (outcome.value !== undefined) requests.push(outcome.value);
    }
    return requests;
  });
}

export interface ServicingCaseDetail {
  id: string;
  caseNumber: string;
  memberId: string;
  accountId: string | null;
  state: string;
  priority: string;
  version: number;
  dependencies: readonly { id: string; kind: string; referenceId: string; state: string; dueAt: string | null }[];
  events: readonly { sequence: number; state: string; occurredAt: string; detail: string }[];
}

/** Reads the case timeline and dependencies without flattening or rewriting historical events. */
export function servicingCaseDetail(database: SqlDatabase, context: ServiceContext, caseId: string, collectionLimit = DEFAULT_LIST_LIMIT): ServicingQueryResult<ServicingCaseDetail | undefined> {
  return authorized(database, context, datasetId => {
  const limitIssue = invalidLimit(collectionLimit); if (limitIssue !== null) return limitIssue;
  const row = one(database, `SELECT c.id,c.case_number,c.member_id,c.account_id,c.state,c.priority,c.version,q.visibility AS queue_visibility
    FROM cases c JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id WHERE c.dataset_id=? AND c.id=?`, datasetId, caseId);
    if (row === undefined) return undefined;
    const access = documentReadFilter(database, datasetId, reader(context));
    const inaccessibleDocument = one(database, `SELECT 1 AS inaccessible FROM case_documents cd JOIN document_versions v
      ON v.dataset_id=cd.dataset_id AND v.id=cd.document_version_id JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE cd.dataset_id=? AND cd.case_id=? AND NOT (${access}) LIMIT 1`, datasetId, caseId) !== undefined
      || one(database, `SELECT 1 AS inaccessible FROM case_note_documents nd JOIN case_notes n ON n.dataset_id=nd.dataset_id AND n.id=nd.note_id
      JOIN document_versions v ON v.dataset_id=nd.dataset_id AND v.id=nd.document_version_id JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE nd.dataset_id=? AND n.case_id=? AND NOT (${access}) LIMIT 1`, datasetId, caseId) !== undefined;
    if (str(row, 'queue_visibility') !== 'general' && !readsRestrictedNotes(database, datasetId, reader(context))) return reject('not_authorized', 'This case belongs to a restricted servicing queue.');
    if (inaccessibleDocument) return reject('not_authorized', 'This case contains document evidence outside the reader scope.');
    const dependencyRows = all(database, 'SELECT id,kind,reference_id,state,due_at FROM case_dependencies WHERE dataset_id=? AND case_id=? ORDER BY id LIMIT ?', datasetId, caseId, collectionLimit + 1);
    const eventRows = all(database, 'SELECT sequence,state,occurred_at,detail FROM case_events WHERE dataset_id=? AND case_id=? ORDER BY sequence LIMIT ?', datasetId, caseId, collectionLimit + 1);
    if (dependencyRows.length > collectionLimit || eventRows.length > collectionLimit) return reject('limit_exceeded', `Case detail exceeds the ${collectionLimit}-item dependency or event limit.`);
    const dependencies = dependencyRows.map(item => ({ id: str(item, 'id'), kind: str(item, 'kind'), referenceId: str(item, 'reference_id'), state: str(item, 'state'), dueAt: optionalStr(item, 'due_at') }));
    const events = eventRows.map(item => ({ sequence: int(item, 'sequence'), state: str(item, 'state'), occurredAt: str(item, 'occurred_at'), detail: str(item, 'detail') }));
    return { id: str(row, 'id'), caseNumber: str(row, 'case_number'), memberId: str(row, 'member_id'), accountId: optionalStr(row, 'account_id'), state: str(row, 'state'), priority: str(row, 'priority'), version: int(row, 'version'), dependencies, events };
  });
}

export interface CommunicationJobSummary {
  id: string;
  partyId: string;
  documentVersionId: string | null;
  purpose: string;
  channel: string;
  destination: string;
  state: string;
  events: readonly { sequence: number; state: string; occurredAt: string; detail: string }[];
}

/** Reads queued communication state and its append-only local delivery events. */
export function communicationJob(database: SqlDatabase, context: ServiceContext, jobId: string, eventLimit = DEFAULT_LIST_LIMIT): ServicingQueryResult<CommunicationJobSummary | undefined> {
  return authorized(database, context, datasetId => {
  const limitIssue = invalidLimit(eventLimit); if (limitIssue !== null) return limitIssue;
  const row = one(database, 'SELECT id,party_id,document_version_id,purpose,channel,destination,state FROM communication_jobs WHERE dataset_id=? AND id=?', datasetId, jobId);
    if (row === undefined) return undefined;
    const documentVersionId = optionalStr(row, 'document_version_id');
    if (documentVersionId !== null && !canReadDocument(database, datasetId, documentVersionId, reader(context))) return reject('not_authorized', 'This communication references a restricted document.');
    const eventRows = all(database, 'SELECT sequence,state,occurred_at,detail FROM communication_events WHERE dataset_id=? AND job_id=? ORDER BY sequence LIMIT ?', datasetId, jobId, eventLimit + 1);
    if (eventRows.length > eventLimit) return reject('limit_exceeded', `Communication job has more than ${eventLimit} events.`);
    const events = eventRows.map(item => ({ sequence: int(item, 'sequence'), state: str(item, 'state'), occurredAt: str(item, 'occurred_at'), detail: str(item, 'detail') }));
    return { id: str(row, 'id'), partyId: str(row, 'party_id'), documentVersionId: optionalStr(row, 'document_version_id'), purpose: str(row, 'purpose'), channel: str(row, 'channel'), destination: str(row, 'destination'), state: str(row, 'state'), events };
  });
}

export type CommunicationJobListItem = Omit<CommunicationJobSummary, 'events'>;

/** Lists durable communication job identities for a member; callers can inspect one job for events. */
export function listMemberCommunicationJobs(database: SqlDatabase, context: ServiceContext, memberId: string, limit = DEFAULT_LIST_LIMIT): ServicingQueryResult<CommunicationJobListItem[]> {
  return authorized(database, context, datasetId => {
    const partyId = memberPartyId(database, datasetId, memberId); if (typeof partyId !== 'string') return partyId;
    const access = documentReadFilter(database, datasetId, reader(context));
    const result = boundedRows(database, limit, 'communication jobs', `SELECT j.id,j.party_id,j.document_version_id,j.purpose,j.channel,j.destination,j.state FROM communication_jobs j
      LEFT JOIN document_versions v ON v.dataset_id=j.dataset_id AND v.id=j.document_version_id LEFT JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE j.dataset_id=? AND j.party_id=? AND (j.document_version_id IS NULL OR ${access}) ORDER BY j.created_at DESC,j.id DESC LIMIT ?`, datasetId, partyId);
    if (!Array.isArray(result)) return result;
    return result.map(row => ({ id: str(row, 'id'), partyId, documentVersionId: optionalStr(row, 'document_version_id'), purpose: str(row, 'purpose'), channel: str(row, 'channel'), destination: str(row, 'destination'), state: str(row, 'state') }));
  });
}
