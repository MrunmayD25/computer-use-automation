import { randomUUID } from 'node:crypto';

import { accountProductSql } from '../product-sql.js';
import {
  accountFacts, all, canonicalJson, currencyExponent, int, isIsoDate, localDate, nextNumber, one, optionalInt, optionalStr, OutcomeAbort,
  reject, requireSafeLedgerPosting, run, sha256, str, type LedgerPostingEntry, type Row,
} from './core.js';
import { creditEligibility, debitEligibility } from './rules.js';
import type { ApplyEnvironment, Environment, Prepared } from './commands.js';
import type { FinanceCommand } from './finance-types.js';
import type { ServicingCommand } from './servicing-types.js';
import type { Money, Rejection } from './types.js';

export type FinanceEnvironment = Environment;
export type FinanceApplyEnvironment = ApplyEnvironment;

export const newId = (prefix: string): string => `${prefix}-${randomUUID()}`;
export const noFinanceReview = (consequences: string[]): Prepared['review'] => ({ amount: null, exponent: null, description: null, accounts: [], consequences });

export function financeApprovalScope(command: FinanceCommand | ServicingCommand): Record<string, unknown> {
  return Object.fromEntries(Object.entries(command).filter(([key]) => key !== 'approvalId'));
}

export function financeApprovalFingerprint(command: FinanceCommand | ServicingCommand): string {
  return sha256(canonicalJson(financeApprovalScope(command)));
}

export function rowFingerprint(row: Row, columns: readonly string[]): string {
  return sha256(canonicalJson(Object.fromEntries(columns.map((column) => [column, row[column] ?? null]))));
}

export function requireFingerprint(row: Row, columns: readonly string[], expected: string, label: string): Rejection | null {
  return rowFingerprint(row, columns) === expected ? null : reject('stale_version', `The ${label} changed after review. Reopen it before continuing.`);
}

export interface SuspenseClearanceFacts {
  matches: Row[];
  linkedCases: Row[];
  evidence: Row[];
}

/** Captures every mutable proposal, linked case and evidence fact required to clear one suspense item. */
export function suspenseClearanceFacts(database: FinanceEnvironment['database'], datasetId: string, suspenseId: string, sourceEvidenceId: string): SuspenseClearanceFacts {
  const matches = all(database, `SELECT m.id,m.run_id,r.as_of,m.left_reference,m.right_reference,m.amount_minor_units,m.currency,m.state
    FROM reconciliation_matches m JOIN reconciliation_runs r ON r.dataset_id=m.dataset_id AND r.id=m.run_id
    WHERE m.dataset_id=? AND r.kind='suspense' AND m.state='proposed'
      AND CASE WHEN json_valid(m.left_reference) THEN EXISTS (SELECT 1 FROM json_each(m.left_reference) WHERE value=?) ELSE 0 END
    ORDER BY r.as_of,m.id`, datasetId, sourceEvidenceId);
  const linkedCases = all(database, `SELECT d.id AS dependency_id,d.case_id,d.state AS dependency_state,d.due_at,
    c.member_id,c.account_id,c.state AS case_state,c.version,a.member_id AS account_member_id,m.party_id AS account_owner_party_id
    FROM case_dependencies d JOIN cases c ON c.dataset_id=d.dataset_id AND c.id=d.case_id
    LEFT JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
    LEFT JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
    WHERE d.dataset_id=? AND d.kind='suspense' AND d.reference_id=? ORDER BY c.id,d.id`, datasetId, suspenseId);
  const evidenceIds = new Set<string>();
  for (const match of matches) {
    try {
      const references: unknown = JSON.parse(str(match, 'left_reference'));
      if (Array.isArray(references)) for (const reference of references) if (typeof reference === 'string') evidenceIds.add(reference);
    } catch { /* The immutable malformed reference remains represented by the match row. */ }
  }
  const evidence = evidenceIds.size === 0 ? [] : all(database, `SELECT v.id,v.document_id,v.status,v.digest,v.media_type,d.account_id,d.owner_party_id,b.byte_length,b.bytes
    FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
    LEFT JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
    WHERE v.dataset_id=? AND v.id IN (${[...evidenceIds].map(() => '?').join(',')}) ORDER BY v.id`, datasetId, ...evidenceIds)
    .map(({ bytes, ...row }) => ({ ...row, actual_byte_length: bytes instanceof Uint8Array ? bytes.byteLength : null, actual_digest: bytes instanceof Uint8Array ? sha256(bytes) : null }));
  return { matches, linkedCases, evidence };
}

export function requireText(value: string, field: string, label: string, maximum = 500): Rejection | null {
  const cleaned = value.trim();
  return cleaned.length === 0 || cleaned.length > maximum ? reject('validation', `${label} must contain 1 to ${maximum} characters.`, { field }) : null;
}

export function requireDate(value: string, field: string): Rejection | null {
  return isIsoDate(value) ? null : reject('validation', 'Use a valid YYYY-MM-DD date.', { field });
}

/** Parses a strict offset-bearing ISO instant and returns its canonical UTC representation. */
export function normalizeInstant(value: string): string | null {
  const match = /^(\d{4}-\d{2}-\d{2})T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d{1,9})?(?:Z|[+-](?:0\d|1[0-4]):[0-5]\d)$/u.exec(value);
  if (match === null || match[1] === undefined || !isIsoDate(match[1])) return null;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? new Date(parsed).toISOString() : null;
}

/** Whether identity evidence is issued and unexpired at a business instant. */
export function isEvidenceValidAt(issuedAt: string, expiresAt: string | null, instant: string, timeZone: string): boolean {
  const normalizedInstant = normalizeInstant(instant);
  if (normalizedInstant === null) return false;
  const businessDate = localDate(normalizedInstant, timeZone);
  const normalizedIssue = isIsoDate(issuedAt) ? issuedAt : normalizeInstant(issuedAt);
  if (normalizedIssue === null || (isIsoDate(issuedAt) ? normalizedIssue > businessDate : normalizedIssue > normalizedInstant)) return false;
  if (expiresAt === null) return true;
  const normalizedExpiry = isIsoDate(expiresAt) ? expiresAt : normalizeInstant(expiresAt);
  return normalizedExpiry !== null && (isIsoDate(expiresAt) ? normalizedExpiry >= businessDate : normalizedExpiry > normalizedInstant);
}

export function requireInstant(value: string, field: string): Rejection | null {
  return normalizeInstant(value) === null ? reject('validation', 'Use a valid ISO-8601 instant with an explicit offset.', { field }) : null;
}

export function requireMoney(env: Environment, money: Money, field: string, allowZero = false): Rejection | null {
  if (!Number.isSafeInteger(money.minorUnits) || (allowZero ? money.minorUnits < 0 : money.minorUnits <= 0) || money.minorUnits > 1_000_000_000_000) {
    return reject('validation', `${field} minor units are outside the supported range.`, { field: `${field}.minorUnits` });
  }
  if (currencyExponent(env.database, money.currency) === undefined) return reject('validation', `Currency ${money.currency} is not supported.`, { field: `${field}.currency` });
  return null;
}

export function loadMember(env: Environment, memberId: string): Row | undefined {
  const effectiveDate = localDate(env.now, env.timeZone);
  return one(env.database, `SELECT m.id,m.member_number,m.party_id,m.status,
    COALESCE((SELECT history.classification FROM tax_status_history history
      WHERE history.dataset_id=m.dataset_id AND history.member_id=m.id AND history.valid_from<=?
        AND (history.valid_to IS NULL OR history.valid_to>?)
      ORDER BY history.valid_from DESC,history.id DESC LIMIT 1),m.tax_classification) AS tax_classification,
    m.version,p.kind,p.display_name FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
    WHERE m.dataset_id=? AND m.id=?`, effectiveDate, effectiveDate, env.datasetId, memberId);
}

export function loadAccount(env: Environment, accountId: string): Row | undefined {
  return one(env.database, `SELECT a.id,a.account_number,a.member_id,p.id AS product_id,a.currency,a.status,a.version,p.family
    FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.id=${accountProductSql('?')}
    WHERE a.dataset_id=? AND a.id=?`, env.now, env.datasetId, accountId);
}

export function requireAccountVersion(row: Row, expected: number): Rejection | null {
  const current = int(row, 'version');
  return current === expected ? null : reject('stale_version', `The account changed after review (version ${expected} is now ${current}).`, { currentVersion: current });
}

export function requireMemberVersion(row: Row, expected: number): Rejection | null {
  const current = int(row, 'version');
  return current === expected ? null : reject('stale_version', `The member changed after review (version ${expected} is now ${current}).`, { currentVersion: current });
}

export function requireDebit(env: Environment, accountId: string, amount: Money): Rejection | null {
  const account = accountFacts(env.database, env.datasetId, accountId, env.now);
  if (account === undefined) return reject('not_found', 'The source account does not exist.');
  if (account.currency !== amount.currency) return reject('currency_mismatch', 'The amount currency differs from the account currency.');
  const eligible = debitEligibility(account);
  if (!eligible.eligible) return reject('ineligible', eligible.reasons.join(' '));
  return account.availableMinorUnits < amount.minorUnits ? reject('insufficient_funds', 'Available funds do not cover this amount.') : null;
}

export function requireCredit(env: Environment, accountId: string, currency: string): Rejection | null {
  const account = accountFacts(env.database, env.datasetId, accountId, env.now);
  if (account === undefined) return reject('not_found', 'The destination account does not exist.');
  if (account.currency !== currency) return reject('currency_mismatch', 'The amount currency differs from the account currency.');
  const eligible = creditEligibility(account);
  return eligible.eligible ? null : reject('ineligible', eligible.reasons.join(' '));
}

export function ledgerForAccount(env: Environment, accountId: string): Row | undefined {
  return one(env.database, `SELECT id,code,kind,currency,normal_side FROM ledger_accounts WHERE dataset_id=? AND customer_account_id=?
    ORDER BY CASE kind WHEN 'customer-deposit' THEN 0 WHEN 'loan-principal' THEN 1 ELSE 2 END,id LIMIT 1`, env.datasetId, accountId);
}

export function generalLedger(env: Environment, currency: string, kind: 'cash' | 'fee-income' | 'settlement' | 'interest-expense'): Row | undefined {
  return one(env.database, 'SELECT id,code,normal_side FROM ledger_accounts WHERE dataset_id=? AND currency=? AND kind=? ORDER BY id LIMIT 1', env.datasetId, currency, kind);
}

export function insertJournal(env: ApplyEnvironment, input: { debitLedgerId: string; creditLedgerId: string; amount: number; currency: string; description: string; effectiveDate?: string; prefix?: string }): string {
  enforceSafeLedgerPosting(env, [
    { ledgerAccountId: input.debitLedgerId, currency: input.currency, debitMinorUnits: input.amount, creditMinorUnits: 0 },
    { ledgerAccountId: input.creditLedgerId, currency: input.currency, debitMinorUnits: 0, creditMinorUnits: input.amount },
  ]);
  const journalId = newId('journal');
  const reference = nextNumber(env.database, 'journals', 'reference', env.datasetId, input.prefix ?? 'FN', 9);
  run(env.database, 'INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,?,?,?,?,?,?,NULL)',
    env.datasetId, journalId, reference, env.operationId, 'posted', env.now, input.effectiveDate ?? localDate(env.now, env.timeZone), input.description);
  run(env.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,0,?)',
    env.datasetId, journalId, 1, input.debitLedgerId, input.currency, input.amount, input.description);
  run(env.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,0,?,?)',
    env.datasetId, journalId, 2, input.creditLedgerId, input.currency, input.amount, input.description);
  return journalId;
}

/** Aborts the current command transaction with a qualified rejection before an inexact ledger aggregate can be stored. */
export function enforceSafeLedgerPosting(env: ApplyEnvironment, entries: readonly LedgerPostingEntry[]): void {
  const unsafe = requireSafeLedgerPosting(env.database, env.datasetId, entries);
  if (unsafe !== null) throw new OutcomeAbort(unsafe);
}

export function paymentEvent(env: ApplyEnvironment, paymentId: string, state: string, detail: string): void {
  const sequence = (optionalInt(one(env.database, 'SELECT MAX(sequence) AS maximum FROM payment_events WHERE dataset_id=? AND payment_id=?', env.datasetId, paymentId), 'maximum') ?? 0) + 1;
  run(env.database, 'INSERT INTO payment_events (dataset_id,id,payment_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?,?,?,?,?)',
    env.datasetId, newId('payment-event'), paymentId, sequence, state, env.now, env.actorId, detail);
}

export function cardEvent(env: ApplyEnvironment, cardId: string, state: string, reason: string): void {
  const sequence = (optionalInt(one(env.database, 'SELECT MAX(sequence) AS maximum FROM card_events WHERE dataset_id=? AND card_id=?', env.datasetId, cardId), 'maximum') ?? 0) + 1;
  run(env.database, 'INSERT INTO card_events (dataset_id,id,card_id,sequence,state,occurred_at,reason) VALUES (?,?,?,?,?,?,?)', env.datasetId, newId('card-event'), cardId, sequence, state, env.now, reason);
}

export function requireApproval(env: Environment, command: FinanceCommand | ServicingCommand, approvalId: string, amount: Money | null = null): Rejection | null {
  return requireApprovalScope(env, approvalId, financeApprovalScope(command), amount);
}

/** Validates an approved action scope without consuming it; campaign callers consume only at their terminal checkpoint. */
export function requireApprovalScope(
  env: Environment,
  approvalId: string,
  expectedScope: Record<string, unknown>,
  amount: Money | null = null,
  exactAmount = false,
): Rejection | null {
  const approval = one(env.database, `SELECT maker_actor_id,checker_actor_id,action_fingerprint,scope_json,amount_limit_minor_units,currency,policy_version_id,status,expires_at
    FROM business_approvals WHERE dataset_id=? AND id=?`, env.datasetId, approvalId);
  if (approval === undefined) return reject('not_authorized', 'The required approval does not exist at this institution.', { field: 'approvalId' });
  if (str(approval, 'status') !== 'approved') return reject('not_authorized', `Approval status is ${str(approval, 'status')}; an active approval is required.`, { field: 'approvalId' });
  if (str(approval, 'expires_at') <= env.now) return reject('not_authorized', 'The approval expired before this action.', { field: 'approvalId' });
  if (str(approval, 'checker_actor_id') !== env.actorId) return reject('not_authorized', 'This approval is assigned to another checker.', { field: 'approvalId' });
  if (str(approval, 'maker_actor_id') === env.actorId) return reject('not_authorized', 'Maker and checker must be different operators.', { field: 'approvalId' });
  if (one(env.database, `SELECT p.id FROM policy_versions p WHERE p.dataset_id=? AND p.id=? AND p.effective_at<=?
    AND NOT EXISTS (SELECT 1 FROM policy_versions newer WHERE newer.dataset_id=p.dataset_id AND newer.name=p.name AND newer.effective_at<=?
      AND (newer.effective_at>p.effective_at OR (newer.effective_at=p.effective_at AND newer.id>p.id)))`, env.datasetId, str(approval, 'policy_version_id'), env.now, env.now) === undefined) {
    return reject('not_authorized', 'The approval policy is not current and effective for this action.', { field: 'approvalId' });
  }
  const canonicalScope = canonicalJson(expectedScope);
  let storedScope: unknown;
  try {
    storedScope = JSON.parse(str(approval, 'scope_json'));
  } catch {
    return reject('not_authorized', 'The approval has a malformed reviewed action scope.', { field: 'approvalId' });
  }
  if (str(approval, 'action_fingerprint') !== sha256(canonicalScope) || canonicalJson(storedScope) !== canonicalScope) {
    return reject('not_authorized', 'The approval does not cover the exact reviewed action.', { field: 'approvalId' });
  }
  if (amount !== null) {
    if (optionalStr(approval, 'currency') !== amount.currency) return reject('not_authorized', 'The approval currency differs from this action.', { field: 'approvalId' });
    const limit = optionalInt(approval, 'amount_limit_minor_units');
    if (limit === null || (exactAmount ? limit !== amount.minorUnits : amount.minorUnits > limit)) return reject('limit_exceeded', exactAmount ? 'The approval amount does not match the campaign limit.' : 'The action exceeds the approved amount limit.', { field: 'approvalId' });
  }
  return null;
}

export function approvalPrepared(prepared: Prepared, approvalId: string): Prepared {
  return { ...prepared, apply(env) {
    const result = env.database.prepare("UPDATE business_approvals SET status='consumed' WHERE dataset_id=? AND id=? AND status='approved'").run(env.datasetId, approvalId);
    if (result.changes !== 1) throw new Error('Approval was no longer available inside the transaction.');
    prepared.apply(env);
  } };
}

export function prepared(input: Omit<Prepared, 'kind'>): Prepared { return { kind: 'prepared', ...input }; }
