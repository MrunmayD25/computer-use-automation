import { createHash } from 'node:crypto';
import type { SQLOutputValue } from 'node:sqlite';
import type { CoreSeedReferences, SeedContext } from './contract.js';
import { insertTwoLineJournal } from './core.js';

type Row = Record<string,SQLOutputValue>;
function text(row: Row, column: string): string {
  const value=row[column];
  if (typeof value!=='string') throw new Error(`Payment accounting requires ${column}.`);
  return value;
}
function amount(row: Row): number {
  const value=row.amount_minor_units;
  if (typeof value!=='number' || !Number.isSafeInteger(value) || value<=0) throw new Error('Payment accounting requires a positive exact amount.');
  return value;
}

export function seedPaymentAccounting(context: SeedContext, refs: CoreSeedReferences): void {
  const {database,binding}=context;
  const maker=refs.actorIds[2];
  const checker=refs.actorIds[3];
  if (!maker || !checker || maker===checker) throw new Error('Payment accounting requires independent maker/checker actors.');
  const payments=database.prepare(`SELECT p.*,la.id AS customer_ledger_id,a.opened_at,a.closed_at FROM payments p
    JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id
    JOIN ledger_accounts la ON la.dataset_id=a.dataset_id AND la.customer_account_id=a.id
    WHERE p.dataset_id=? ORDER BY p.id`).all(binding.datasetId);
  for (const payment of payments) {
    const paymentId=text(payment,'id');
    const events=database.prepare('SELECT state,occurred_at FROM payment_events WHERE dataset_id=? AND payment_id=? ORDER BY sequence').all(binding.datasetId,paymentId);
    const release=events.find(event=>event.state==='released');
    const money=amount(payment);
    if (release) {
      const scope={paymentId,sourceAccountId:text(payment,'source_account_id'),beneficiaryRouteId:text(payment,'beneficiary_route_id'),amountMinorUnits:money,currency:text(payment,'currency'),requestedDate:text(payment,'requested_date')};
      const scopeJson=JSON.stringify(scope);
      const expiresAt=new Date(Date.parse(text(release,'occurred_at'))+7*86_400_000).toISOString();
      database.prepare(`INSERT INTO business_approvals (dataset_id,id,maker_actor_id,checker_actor_id,action_fingerprint,scope_json,amount_limit_minor_units,currency,policy_version_id,status,expires_at) VALUES (?,?,?,?,?,?,?,?,?,'consumed',?)`).run(binding.datasetId,context.id('payment-release-approval',paymentId),maker,checker,createHash('sha256').update(scopeJson).digest('hex'),scopeJson,money,scope.currency,context.id('policy',1),expiresAt);
    }
    const gl=refs.glAccountIdsByCurrency[text(payment,'currency')];
    if (!gl) throw new Error(`Missing settlement ledger for payment ${paymentId}.`);
    for (const event of events.filter(event=>event.state==='settled' || event.state==='returned')) {
      const occurredAt=text(event,'occurred_at');
      if (occurredAt<text(payment,'opened_at') || typeof payment.closed_at==='string' && occurredAt>payment.closed_at) throw new Error(`Payment ${paymentId} posts outside its account lifetime.`);
      const returned=event.state==='returned';
      const kind=returned ? 'return' : 'settlement';
      const key=`payment-${kind}-${paymentId}`;
      const customerLedger=text(payment,'customer_ledger_id');
      const journalId=insertTwoLineJournal(context,key,returned ? gl.settlement : customerLedger,returned ? customerLedger : gl.settlement,money,text(payment,'currency'),occurredAt,`Payment ${text(payment,'reference')} ${kind}`);
      database.prepare('UPDATE operations SET actor_id=?,operation_kind=? WHERE dataset_id=? AND id=?').run(maker,returned ? 'payment.return.post' : 'payment.settle',binding.datasetId,context.id('posting-operation',key));
      database.prepare('INSERT INTO payment_postings (dataset_id,id,payment_id,kind,journal_id) VALUES (?,?,?,?,?)').run(binding.datasetId,context.id('payment-posting',`${paymentId}-${kind}`),paymentId,kind,journalId);
    }
  }
}
