import { reject } from './core.js';
import type { CoreCommand, Rejection } from './types.js';

type Validator = (value: unknown) => boolean;
type Shape = Readonly<Record<string, Validator>>;
const text: Validator = (value) => typeof value === 'string';
const integer: Validator = (value) => Number.isSafeInteger(value);
const nullable = (validator: Validator): Validator => (value) => value === null || validator(value);
const optional = (validator: Validator): Validator => (value) => value === undefined || validator(value);
const enumeration = (...values: readonly string[]): Validator => (value) => typeof value === 'string' && values.includes(value);
const object = (shape: Shape): Validator => (value) => {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const entries = Object.entries(value);
  return entries.every(([key]) => Object.hasOwn(shape, key)) && Object.entries(shape).every(([key, validator]) => validator(Reflect.get(value, key)));
};
const address = object({ line1: text, line2: nullable(text), city: text, region: text, postalCode: text, country: text });
const money = object({ minorUnits: integer, currency: text });
const delivery = enumeration('paper', 'electronic');
const visibility = enumeration('general', 'restricted');
const searchVisibility = enumeration('private', 'shared');
const searchDefinition: Validator = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const contact = { email: nullable(text), phone: nullable(text), address: nullable(address) };
const account = { accountId: text, expectedVersion: integer };
const cash = { ...account, amount: money, description: text };
const caseVersion = { caseId: text, expectedVersion: integer };
const shapes: Readonly<Record<CoreCommand['kind'], Shape>> = {
  'edit.cancel': {requestId:text,expectedUpdatedAt:text},
  'member.create': { legalGiven: text, legalFamily: text, preferredName: nullable(text), birthDate: text, ...contact },
  'member.organization.create': { legalName: text, registrationNumber: text, organizationType: enumeration('corporation', 'nonprofit'), ...contact },
  'contact.update': { memberId: text, expectedVersion: integer, email: optional(nullable(text)), phone: optional(nullable(text)), address: optional(address) },
  'member.note.add': { memberId: text, visibility, text },
  'account.open': { memberId: text, productId: text, nickname: text, statementDelivery: delivery },
  'account.nickname.update': { ...account, nickname: text },
  'account.statement_delivery.update': { ...account, statementDelivery: delivery },
  'account.close': { ...account, reason: text },
  'cash.deposit': cash,
  'cash.withdraw': cash,
  'transfer.internal': { sourceAccountId: text, destinationAccountId: text, expectedSourceVersion: integer, expectedDestinationVersion: integer, amount: money, description: text },
  'case.open': { memberId: text, accountId: nullable(text), queueId: text, assignedActorId: nullable(text), category: text, priority: enumeration('low', 'normal', 'high', 'urgent'), summary: text, dueDate: text },
  'case.assign': { ...caseVersion, queueId: text, assignedActorId: nullable(text), reason: text },
  'case.transition': { ...caseVersion, toState: enumeration('open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened'), reason: text },
  'case.note.add': { caseId: text, visibility, text, evidenceVersionIds: optional(value=>Array.isArray(value) && value.length<=20 && value.every(text) && new Set(value).size===value.length) },
  'search.saved.create': { name: text, visibility: searchVisibility, definition: searchDefinition },
  'search.saved.update': { searchId: text, expectedRevision: text, name: optional(text), visibility: optional(searchVisibility), definition: optional(searchDefinition) },
  'search.saved.delete': { searchId: text, expectedRevision: text },
};

/** Checks the runtime boundary before domain code touches caller-supplied fields. */
export function validateCoreCommand(value: unknown): Rejection | null {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return reject('validation', 'A command must be an object.');
  const kind: unknown = Reflect.get(value, 'kind');
  if (typeof kind !== 'string' || !Object.hasOwn(shapes, kind)) return reject('validation', 'Unknown command kind.', { field: 'kind' });
  const shape = shapes[kind as CoreCommand['kind']];
  const unknown = Object.keys(value).find((key) => key !== 'kind' && !Object.hasOwn(shape, key));
  if (unknown !== undefined) return reject('validation', `Unknown command field ${unknown}.`, { field: unknown });
  const invalid = Object.entries(shape).find(([key, validator]) => !validator(Reflect.get(value, key)));
  return invalid === undefined ? null : reject('validation', `Invalid or missing ${invalid[0]}.`, { field: invalid[0] });
}
