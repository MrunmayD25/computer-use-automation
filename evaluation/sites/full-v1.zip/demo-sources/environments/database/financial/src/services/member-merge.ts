import { createHash } from 'node:crypto';
import { all, authorizeQuery, canonicalJson, int, one, reject, str, type Row } from './core.js';
import type { FinancialStore, SqlDatabase } from './store.js';
import type { Rejection, ServiceContext } from './types.js';

export const MAX_MERGE_INVENTORY_ROWS = 10_000;
export const MAX_MERGE_INVENTORY_BYTES = 64 * 1024 * 1024;
const quote = (name: string): string => `"${name.replaceAll('"', '""')}"`;
const digest = (value: unknown): string => createHash('sha256').update(canonicalJson(value)).digest('hex');
const EXCLUDED = new Set(['business_approvals', 'member_merge_plans']);
// Follow obligations to their immutable evidence/accounting parents, never to other
// people or shared policy/actor records (which would widen the identity scope).
const PARENTS = new Set(['accounts', 'addresses', 'documents', 'document_versions', 'document_blobs', 'journals', 'operations', 'operation_receipts']);
const RESOURCE_TABLES: Readonly<Record<string, string>> = {
  member: 'members', account: 'accounts', 'member-note': 'member_notes', case: 'cases', 'case-note': 'case_notes',
  document: 'documents', 'document-version': 'document_versions', card: 'cards', loan: 'loans', payment: 'payments',
  fee: 'fees', hold: 'holds', restriction: 'restrictions', beneficiary: 'beneficiaries', 'payment-schedule': 'payment_schedules',
  'loan-application': 'loan_applications', 'maturity-instruction': 'maturity_instructions', reconciliation: 'reconciliation_runs', batch: 'batches',
  dispute: 'disputes', 'maintenance-request': 'maintenance_requests', journal: 'journals', transaction: 'journals',
};

export interface MergeInventory {
  kind: 'found';
  mergePlanId: string;
  sourceMemberId: string;
  targetMemberId: string;
  planState: string;
  decisions: Readonly<Record<string, unknown>>;
  fingerprint: string;
  rowCount: number;
  tables: { table: string; count: number; fingerprint: string; records: { key: Record<string, string | number>; fingerprint: string }[] }[];
}

/** Complete connected business inventory; hashes include bytes, versions and plan decisions. */
export function memberMergeInventory(database: SqlDatabase, datasetId: string, mergePlanId: string): MergeInventory | Rejection {
  const plan = one(database, 'SELECT * FROM member_merge_plans WHERE dataset_id=? AND id=?', datasetId, mergePlanId);
  if (plan === undefined) return reject('not_found', 'The merge plan does not exist at this institution.');
  let decisions: unknown;
  try { decisions = JSON.parse(str(plan, 'conflicts_json')); } catch { return reject('ineligible', 'The merge plan contains malformed decisions.'); }
  if (decisions === null || typeof decisions !== 'object' || Array.isArray(decisions)) return reject('ineligible', 'Merge plan decisions must be an object.');
  const sourceMemberId = str(plan, 'source_member_id');
  const targetMemberId = str(plan, 'target_member_id');
  const members = all(database, 'SELECT * FROM members WHERE dataset_id=? AND id IN (?,?) ORDER BY id', datasetId, sourceMemberId, targetMemberId);
  if (members.length !== 2) return reject('ineligible', 'A merge requires two distinct existing members.');
  const columns = new Map(all(database, "SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    .map(row => { const table = str(row, 'name'); return [table, all(database, `PRAGMA table_info(${quote(table)})`)] as const; }));
  const tables = [...columns].filter(([, fields]) => fields.some(column => column.name === 'dataset_id')).map(([table]) => table);
  const selected = new Map<string, Map<number, Row>>();
  let total = 0;
  const collect = (table: string, predicate: string, parameters: string[]): boolean | Rejection => {
    if (table === 'document_blobs') {
      const size = one(database, `SELECT COALESCE(SUM(length(bytes)),0) AS total FROM document_blobs WHERE dataset_id=? AND ((${predicate}) OR rowid IN (SELECT value FROM json_each(?)))`, datasetId, ...parameters, JSON.stringify([...(selected.get(table)?.keys() ?? [])]));
      if (int(size, 'total') > MAX_MERGE_INVENTORY_BYTES) return reject('limit_exceeded', 'Merge evidence exceeds 64 MiB; no partial inventory is approved.');
    }
    const rows = all(database, `SELECT rowid AS inventory_rowid,* FROM ${quote(table)} WHERE dataset_id=? AND (${predicate}) LIMIT ?`, datasetId, ...parameters, MAX_MERGE_INVENTORY_ROWS + 1);
    const contents = selected.get(table) ?? new Map<number, Row>();
    let changed = false;
    for (const row of rows) {
      const key = int(row, 'inventory_rowid');
      if (!contents.has(key)) {
        if (++total > MAX_MERGE_INVENTORY_ROWS) return reject('limit_exceeded', `Merge inventory exceeds ${MAX_MERGE_INVENTORY_ROWS} rows; no partial inventory is approved.`);
        contents.set(key, row); changed = true;
      }
    }
    selected.set(table, contents);
    return changed;
  };
  const roots: [string, string, string[]][] = [
    ['members', 'id IN (?,?)', [sourceMemberId, targetMemberId]],
    ['parties', 'id IN (?,?)', members.map(row => str(row, 'party_id'))],
    ['member_merge_plans', 'id=?', [mergePlanId]],
    ['business_events', "resource_kind='member' AND resource_id IN (?,?)", [sourceMemberId, targetMemberId]],
  ];
  for (const [table, predicate, parameters] of roots) {
    const result = collect(table, predicate, parameters);
    if (typeof result !== 'boolean') return result;
  }
  const edges = tables.flatMap(child => {
    const groups = new Map<number, Row[]>();
    for (const fk of all(database, `PRAGMA foreign_key_list(${quote(child)})`)) {
      const id = int(fk, 'id'); groups.set(id, [...(groups.get(id) ?? []), fk]);
    }
    return [...groups.values()].filter(keys => keys.some(key => key.from !== 'dataset_id')).map(keys => ({ child, parent: str(keys[0], 'table'), keys }));
  });
  for (let depth = 0; depth < 32; depth++) {
    let changed = false;
    for (const { child, parent, keys } of edges) {
      for (const reverse of [false, true]) {
        const destination = reverse ? parent : child;
        const origin = reverse ? child : parent;
        if (EXCLUDED.has(destination) || reverse && !PARENTS.has(destination) || !tables.includes(destination)
          || !reverse && ['document_blobs', 'addresses'].includes(parent)) continue;
        const origins = selected.get(origin);
        if (!origins?.size) continue;
        const joins = keys.map(key => reverse
          ? `linked.${quote(str(key, 'from'))}=${quote(destination)}.${quote(str(key, 'to'))}`
          : `${quote(destination)}.${quote(str(key, 'from'))}=linked.${quote(str(key, 'to'))}`).join(' AND ');
        const result = collect(destination, `EXISTS (SELECT 1 FROM ${quote(origin)} linked WHERE linked.rowid IN (SELECT value FROM json_each(?)) AND ${joins})`, [JSON.stringify([...origins.keys()])]);
        if (typeof result !== 'boolean') return result;
        changed ||= result;
      }
    }
    for (const [kind, table] of Object.entries(RESOURCE_TABLES)) {
      const ids = [...(selected.get(table)?.values() ?? [])].map(row => str(row, 'id'));
      if (!ids.length) continue;
      const result = collect('business_events', 'resource_kind=? AND resource_id IN (SELECT value FROM json_each(?))', [kind, JSON.stringify(ids)]);
      if (typeof result !== 'boolean') return result;
      changed ||= result;
    }
    if (!changed) {
      const inventoryTables = [...selected].filter(([, rows]) => rows.size).map(([table, rows]) => {
        const contents = [...rows.values()].map(row => Object.fromEntries(Object.entries(row).filter(([key]) => key !== 'inventory_rowid').map(([key, value]) => [key,
          value instanceof Uint8Array ? { sha256: createHash('sha256').update(value).digest('hex'), byteLength: value.byteLength } : value])));
        contents.sort((left, right) => canonicalJson(left).localeCompare(canonicalJson(right)));
        const primary = (columns.get(table) ?? []).filter(column => int(column, 'pk') > 0 && column.name !== 'dataset_id').map(column => str(column, 'name'));
        const records = contents.map(row => ({ key: Object.fromEntries(primary.map(column => {
          const value = row[column];
          if (typeof value !== 'string' && typeof value !== 'number') throw new Error(`Invalid merge inventory identity in ${table}.${column}.`);
          return [column, value];
        })), fingerprint: digest(row) }));
        return { table, count: rows.size, fingerprint: digest(contents), records };
      }).sort((left, right) => left.table.localeCompare(right.table));
      return { kind: 'found', mergePlanId, sourceMemberId, targetMemberId, planState: str(plan, 'state'), decisions: Object.fromEntries(Object.entries(decisions)), fingerprint: digest(inventoryTables), rowCount: total, tables: inventoryTables };
    }
  }
  return reject('limit_exceeded', 'Merge relationship depth exceeds 32; no partial inventory is approved.');
}

/** Supervisory preflight discloses counts and hashes, not restricted document content. */
export function queryMemberMergePlan(store: FinancialStore, context: ServiceContext, mergePlanId: string): MergeInventory | Rejection {
  return store.read(database => {
    const denied = authorizeQuery(database, context, ['supervise']);
    if (denied !== null) return denied;
    if (typeof mergePlanId !== 'string' || !mergePlanId.trim() || mergePlanId.length > 200) return reject('validation', 'A bounded merge plan identifier is required.');
    return memberMergeInventory(database, context.binding.datasetId, mergePlanId);
  });
}
