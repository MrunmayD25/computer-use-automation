import { createHash } from 'node:crypto';

import { all, canonicalJson, int, localDate, nextNumber, one, optionalInt, optionalStr, reject, run, str, type Row } from './core.js';
import { canReadDocument } from './document-access.js';
import { contactCampaignApproval, refundCampaignApproval } from './finance-batch-approval.js';
import { parseFinanceCsv } from './finance-batch-files.js';
import { LIMITS } from './rules.js';
import type { Preparation } from './commands.js';
import type { FinanceCommand } from './finance-types.js';
import {
  approvalPrepared, enforceSafeLedgerPosting, generalLedger, ledgerForAccount, loadAccount, loadMember, newId, noFinanceReview, prepared, requireApproval, requireCredit,
  requireApprovalScope, requireFingerprint, requireMoney, requireText, rowFingerprint, suspenseClearanceFacts, type FinanceEnvironment,
} from './finance-support.js';
import type { Rejection } from './types.js';

type FinanceOf<K extends FinanceCommand['kind']> = Extract<FinanceCommand, { kind: K }>;
const BATCH_COLUMNS = ['id','batch_number','kind','input_document_version_id','input_digest','state','approved_total_limit_minor_units','currency','created_at','items'] as const;
function validation(problems: readonly (Rejection | null)[]): Rejection | null { return problems.find((problem) => problem !== null) ?? null; }
function object(value: unknown): value is Record<string, unknown> { return value !== null && typeof value === 'object' && !Array.isArray(value); }

function prepareBatchImport(env: FinanceEnvironment, command: FinanceOf<'batch.import'>): Preparation {
  if (!/^[a-f0-9]{64}$/u.test(command.inputDigest) || command.batchNumber.trim().length === 0 || command.batchNumber.length > 80) return reject('validation', 'Batch number and lowercase SHA-256 digest are required.');
  if (command.batchKind === 'contact-update' && command.currency !== null || command.batchKind === 'fee-refund' && command.currency === null) return reject('validation', 'Currency is required only for fee-refund imports.', { field: 'currency' });
  if (!canReadDocument(env.database, env.datasetId, command.documentVersionId, { institutionId: env.institutionId, actorId: env.actorId, now: env.now })) return reject('not_found', 'The batch input document is absent or not readable.');
  const document = one(env.database, `SELECT v.digest,v.media_type,b.bytes,b.byte_length FROM document_versions v
    JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest WHERE v.dataset_id=? AND v.id=?`, env.datasetId, command.documentVersionId);
  const bytes = document?.bytes;
  if (!(bytes instanceof Uint8Array) || str(document, 'digest') !== command.inputDigest || str(document, 'media_type') !== 'text/csv'
    || int(document, 'byte_length') !== bytes.byteLength || createHash('sha256').update(bytes).digest('hex') !== command.inputDigest) return reject('ineligible', 'The indexed batch document bytes do not match the supplied digest.');
  if (one(env.database, 'SELECT id FROM batches WHERE dataset_id=? AND (batch_number=? OR input_digest=?)', env.datasetId, command.batchNumber.trim(), command.inputDigest) !== undefined) return reject('duplicate_identity', 'This batch number or exact input file was already imported.');
  const csv = parseFinanceCsv(bytes);
  const header = csv?.[0];
  if (csv === null || header === undefined || csv.length < 2) return reject('validation', 'The batch CSV must contain a header and at least one row.');
  const accepted = command.batchKind === 'contact-update'
    ? [['member_id','email'], ['member_id','phone'], ['member_id','email','phone']]
    : [['fee_id','amount_minor_units','currency']];
  if (!accepted.some(candidate => canonicalJson(candidate) === canonicalJson(header))) return reject('validation', `The CSV header does not match ${command.batchKind} schema version 1.`);
  const position = (name: string): number => header.indexOf(name);
  const rows: { ordinal: number; sourceKey: string; value: Record<string, unknown>; state: string; amount: number | null; failure: string | null }[] = [];
  const seen = new Set<string>();
  for (const [index, source] of csv.slice(1).entries()) {
    if (source.length !== header.length) return reject('validation', `CSV row ${index + 1} has the wrong column count.`);
    if (command.batchKind === 'contact-update') {
      const memberId = source[position('member_id')] ?? '';
      const emailIndex = position('email');
      const phoneIndex = position('phone');
      const email = emailIndex < 0 ? undefined : source[emailIndex] ?? '';
      const phone = phoneIndex < 0 ? undefined : source[phoneIndex] ?? '';
      const member = loadMember(env, memberId);
      let state = 'valid';
      let failure: string | null = null;
      if (seen.has(memberId)) { state = 'duplicate'; failure = 'duplicate-source-key'; }
      else if (memberId.length === 0 || member === undefined || str(member, 'status') !== 'active') { state = 'invalid'; failure = 'member-ineligible'; }
      else if (email !== undefined && !EMAIL.test(email) || phone !== undefined && !PHONE.test(phone)) { state = 'invalid'; failure = 'invalid-contact'; }
      seen.add(memberId);
      rows.push({ ordinal: index + 1, sourceKey: memberId, value: { memberId, expectedVersion: member === undefined ? 0 : int(member, 'version'), ...(email === undefined ? {} : { email }), ...(phone === undefined ? {} : { phone }) }, state, amount: null, failure });
    } else {
      const feeId = source[position('fee_id')] ?? '';
      const amountText = source[position('amount_minor_units')] ?? '';
      const currency = source[position('currency')] ?? '';
      const amount = /^\d+$/u.test(amountText) && Number.isSafeInteger(Number(amountText)) && Number(amountText) > 0 ? Number(amountText) : null;
      let state = 'valid';
      let failure: string | null = null;
      if (seen.has(feeId)) { state = 'duplicate'; failure = 'duplicate-source-key'; }
      else if (feeId.length === 0 || amount === null || currency !== command.currency) { state = 'invalid'; failure = 'invalid-refund-row'; }
      seen.add(feeId);
      rows.push({ ordinal: index + 1, sourceKey: feeId, value: { feeId, amountMinorUnits: amount ?? 0, currency }, state, amount, failure });
    }
  }
  if (rows.length > 10_000) return reject('limit_exceeded', 'Batch files may contain at most 10,000 data rows.');
  const total = command.batchKind === 'fee-refund' ? rows.filter(row => row.state === 'valid').reduce((sum, row) => sum + (row.amount ?? 0), 0) : null;
  const batchId = newId('batch');
  return prepared({ businessReference: command.batchNumber.trim(), result: { batchId, batchNumber: command.batchNumber.trim(), state: 'previewed', totalRows: rows.length, validRows: rows.filter(row => row.state === 'valid').length, inputDigest: command.inputDigest }, review: noFinanceReview(['Imports and parses immutable batch bytes into review rows; it does not apply any contact or refund.']), apply(apply) {
    run(apply.database, `INSERT INTO batches (dataset_id,id,batch_number,kind,input_document_version_id,input_digest,state,approved_total_limit_minor_units,currency,created_at)
      VALUES (?,?,?,?,?,?,'previewed',?,?,?)`, apply.datasetId, batchId, command.batchNumber.trim(), command.batchKind, command.documentVersionId, command.inputDigest, total, command.currency, apply.now);
    for (const row of rows) run(apply.database, `INSERT INTO batch_items (dataset_id,id,batch_id,ordinal,source_key,item_json,state,receipt_id,amount_minor_units,failure_code)
      VALUES (?,?,?,?,?,?,?,NULL,?,?)`, apply.datasetId, newId('batch-item'), batchId, row.ordinal, row.sourceKey, canonicalJson(row.value), row.state, row.amount, row.failure);
    apply.event({ kind: 'batch', id: batchId }, `Immutable ${command.batchKind} batch ${command.batchNumber.trim()} imported with ${rows.length} retained row outcome(s).`);
  } });
}

function suspenseRow(env: FinanceEnvironment, suspenseId: string): Row | undefined {
  const row = one(env.database, `SELECT s.id,s.journal_id,s.original_amount_minor_units,s.remaining_amount_minor_units,s.currency,s.state,s.evidence_reference,
    (SELECT id FROM ledger_accounts la WHERE la.dataset_id=s.dataset_id AND la.kind='suspense' AND EXISTS
      (SELECT 1 FROM journal_lines jl WHERE jl.dataset_id=la.dataset_id AND jl.journal_id=s.journal_id AND jl.ledger_account_id=la.id) LIMIT 1) AS suspense_ledger_id
    FROM suspense_items s WHERE s.dataset_id=? AND s.id=?`, env.datasetId, suspenseId);
  return row === undefined ? undefined : { ...row, clearance_inventory: canonicalJson(suspenseClearanceFacts(env.database, env.datasetId, suspenseId, str(row, 'evidence_reference'))) };
}

function suspenseStale(row: Row, fingerprint: string): Rejection | null {
  return requireFingerprint(row, ['id','journal_id','original_amount_minor_units','remaining_amount_minor_units','currency','state','evidence_reference','suspense_ledger_id','clearance_inventory'], fingerprint, 'suspense item');
}

function prepareSuspenseInvestigate(env: FinanceEnvironment, command: FinanceOf<'reconciliation.suspense.investigate'>): Preparation {
  const suspense = suspenseRow(env, command.suspenseId);
  if (suspense === undefined) return reject('not_found', 'The suspense item does not exist.');
  const stale = suspenseStale(suspense, command.expectedFingerprint);
  if (stale !== null) return stale;
  if (str(suspense, 'state') === 'cleared' || int(suspense, 'remaining_amount_minor_units') === 0) return reject('ineligible', 'The suspense item is already cleared.');
  if (command.evidenceReferences.length < 2 || command.evidenceReferences.length > 20 || new Set(command.evidenceReferences).size !== command.evidenceReferences.length || !command.evidenceReferences.includes(str(suspense, 'evidence_reference'))) return reject('ineligible', 'A unique match requires the suspense source plus independent destination evidence.');
  if (command.proposedAccountId === null) return reject('ineligible', 'No unique evidence-backed destination was supplied; the item remains in suspense.');
  const account = loadAccount(env, command.proposedAccountId);
  if (account === undefined || str(account, 'currency') !== str(suspense, 'currency') || str(account, 'status') !== 'open') return reject('ineligible', 'The proposed destination is not an open same-currency account.');
  const member = loadMember(env, str(account, 'member_id'));
  if (member === undefined) return reject('ineligible', 'The proposed destination owner is unavailable.');
  if (command.evidenceReferences.some(versionId => !canReadDocument(env.database, env.datasetId, versionId, { institutionId: env.institutionId, actorId: env.actorId, now: env.now }))) return reject('not_found', 'Suspense evidence is absent or not readable.');
  const evidence = all(env.database, `SELECT v.id,v.status,v.digest,b.byte_length,b.bytes,d.account_id,d.owner_party_id
    FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
    JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
    WHERE v.dataset_id=? AND v.id IN (${command.evidenceReferences.map(() => '?').join(',')})`, env.datasetId, ...command.evidenceReferences);
  if (evidence.length !== command.evidenceReferences.length) return reject('ineligible', 'Every suspense evidence reference must resolve to an immutable document version.');
  for (const item of evidence) {
    const bytes = item.bytes;
    if (!['current', 'signed'].includes(str(item, 'status')) || !(bytes instanceof Uint8Array)
      || bytes.byteLength !== int(item, 'byte_length') || createHash('sha256').update(bytes).digest('hex') !== str(item, 'digest')) {
      return reject('ineligible', 'Suspense evidence must be current or signed and pass stored-byte integrity checks.');
    }
  }
  const sourceEvidenceId = str(suspense, 'evidence_reference');
  const destinationEvidence = evidence.filter((item) => str(item, 'id') !== sourceEvidenceId);
  if (destinationEvidence.length !== command.evidenceReferences.length - 1
    || destinationEvidence.some((item) => optionalStr(item, 'account_id') !== command.proposedAccountId || str(item, 'owner_party_id') !== str(member, 'party_id'))) {
    return reject('ineligible', 'All destination evidence must identify the proposed account and its member owner unambiguously.');
  }
  const queue = one(env.database, "SELECT id FROM queues WHERE dataset_id=? AND visibility='restricted' ORDER BY id LIMIT 1", env.datasetId);
  if (queue === undefined) return reject('ineligible', 'A restricted reconciliation queue is unavailable.');
  const caseId = newId('case');
  const caseNumber = nextNumber(env.database, 'cases', 'case_number', env.datasetId, 'SP', 7);
  const matchId = newId('reconciliation-match');
  return prepared({
    businessReference: command.suspenseId, result: { suspenseId: command.suspenseId, proposedAccountId: command.proposedAccountId, caseId, caseNumber, matchId, state: 'proposed' },
    review: noFinanceReview(['Records an evidence-backed proposal and case only; it does not clear suspense or credit the account.']),
    apply(apply) {
      run(apply.database, `INSERT INTO cases (dataset_id,id,case_number,member_id,account_id,queue_id,assigned_actor_id,state,priority,category,summary,opened_at,due_at,version)
        VALUES (?,?,?,?,?,?,NULL,'open','normal','suspense-investigation',?,?,?,1)`, apply.datasetId, caseId, caseNumber, str(account, 'member_id'), command.proposedAccountId, str(queue, 'id'), `Investigate suspense ${command.suspenseId} proposed match`, apply.now, new Date(Date.parse(apply.now) + 7 * 86_400_000).toISOString());
      run(apply.database, "INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,1,'open',?,?,?)", apply.datasetId, newId('case-event'), caseId, apply.now, apply.actorId, `Suspense investigation opened from item ${command.suspenseId} using ${command.evidenceReferences.length} evidence references.`);
      const runId = newId('reconciliation-run');
      const reference = nextNumber(apply.database, 'reconciliation_runs', 'reference', apply.datasetId, 'RR', 8);
      run(apply.database, "INSERT INTO reconciliation_runs (dataset_id,id,reference,kind,as_of,state,control_total_minor_units,currency) VALUES (?,?,?,'suspense',?,'matched',?,?)", apply.datasetId, runId, reference, apply.now, int(suspense, 'remaining_amount_minor_units'), str(suspense, 'currency'));
      run(apply.database, "INSERT INTO reconciliation_matches (dataset_id,id,run_id,left_reference,right_reference,amount_minor_units,currency,state) VALUES (?,?,?,?,?,?,?,'proposed')", apply.datasetId, matchId, runId, canonicalJson([...command.evidenceReferences].sort()), command.proposedAccountId ?? '', int(suspense, 'remaining_amount_minor_units'), str(suspense, 'currency'));
      run(apply.database, "INSERT INTO case_dependencies (dataset_id,id,case_id,kind,reference_id,state,due_at) VALUES (?,?,?,'suspense',?,'open',?)", apply.datasetId, newId('case-dependency'), caseId, command.suspenseId, new Date(Date.parse(apply.now) + 7 * 86_400_000).toISOString());
      apply.event({ kind: 'case', id: caseId }, `Suspense investigation case ${caseNumber} opened for item ${command.suspenseId}.`);
      apply.event({ kind: 'reconciliation', id: runId }, `Evidence-backed suspense match proposed for ${command.proposedAccountId}; no clearing entry posted.`);
    },
  });
}

function prepareSuspenseClear(env: FinanceEnvironment, command: FinanceOf<'reconciliation.suspense.clear'>): Preparation {
  const suspense = suspenseRow(env, command.suspenseId);
  if (suspense === undefined) return reject('not_found', 'The suspense item does not exist.');
  const stale = suspenseStale(suspense, command.expectedFingerprint);
  if (stale !== null) return stale;
  const invalid = validation([requireMoney(env, command.amount, 'amount'), requireText(command.evidenceReference, 'evidenceReference', 'Clearing evidence', 200)]);
  if (invalid !== null) return invalid;
  if (command.amount.currency !== str(suspense, 'currency') || command.amount.minorUnits !== int(suspense, 'remaining_amount_minor_units')) return reject('validation', 'Approved clearance must exactly equal the remaining suspense amount.');
  if (command.evidenceReference !== str(suspense, 'evidence_reference')) return reject('ineligible', 'Clearing evidence does not match the original suspense evidence.');
  const proposedMatches = all(env.database, `SELECT m.id,m.left_reference FROM reconciliation_matches m JOIN reconciliation_runs r ON r.dataset_id=m.dataset_id AND r.id=m.run_id
    WHERE m.dataset_id=? AND r.kind='suspense' AND m.right_reference=? AND m.amount_minor_units=? AND m.currency=? AND m.state='proposed'
      AND CASE WHEN json_valid(m.left_reference) THEN EXISTS (SELECT 1 FROM json_each(m.left_reference) WHERE value=?) ELSE 0 END
    ORDER BY r.as_of DESC,m.id`, env.datasetId, command.destinationAccountId, command.amount.minorUnits, command.amount.currency, command.evidenceReference);
  if (proposedMatches.length !== 1) return reject('ineligible', 'Exactly one evidence-backed reconciliation proposal must authorize this suspense destination.');
  const proposedMatch = proposedMatches[0];
  if (proposedMatch === undefined) throw new Error('The suspense proposal count was checked.');
  let evidenceReferences: unknown;
  try { evidenceReferences = JSON.parse(str(proposedMatch, 'left_reference')); } catch { return reject('ineligible', 'The reconciliation proposal evidence is malformed.'); }
  if (!Array.isArray(evidenceReferences)) return reject('ineligible', 'The reconciliation proposal evidence is malformed.');
  const evidenceIds = evidenceReferences.filter((reference): reference is string => typeof reference === 'string');
  if (evidenceIds.length < 2 || evidenceIds.length !== evidenceReferences.length || new Set(evidenceIds).size !== evidenceIds.length) return reject('ineligible', 'The reconciliation proposal evidence is malformed.');
  const destinationAccount = loadAccount(env, command.destinationAccountId);
  if (destinationAccount === undefined || str(destinationAccount, 'currency') !== command.amount.currency || str(destinationAccount, 'status') !== 'open') return reject('ineligible', 'The proposed destination is not an open same-currency account.');
  const destinationOwner = loadMember(env, str(destinationAccount, 'member_id'));
  if (destinationOwner === undefined) return reject('ineligible', 'The proposed destination owner is unavailable.');
  for (const reference of evidenceIds) {
    if (!canReadDocument(env.database, env.datasetId, reference, { institutionId: env.institutionId, actorId: env.actorId, now: env.now })) return reject('not_found', 'Proposal evidence is absent or not readable.');
    const evidence = one(env.database, `SELECT v.status,v.digest,b.byte_length,b.bytes,d.account_id,d.owner_party_id FROM document_versions v
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      WHERE v.dataset_id=? AND v.id=?`, env.datasetId, reference);
    const bytes = evidence?.bytes;
    if (evidence === undefined || !['current','signed'].includes(str(evidence, 'status')) || !(bytes instanceof Uint8Array)
      || bytes.byteLength !== int(evidence, 'byte_length') || createHash('sha256').update(bytes).digest('hex') !== str(evidence, 'digest')) return reject('ineligible', 'Proposal evidence must remain current and pass stored-byte integrity checks.');
    if (reference !== command.evidenceReference && (optionalStr(evidence, 'account_id') !== command.destinationAccountId || str(evidence, 'owner_party_id') !== str(destinationOwner, 'party_id'))) return reject('ownership_mismatch', 'Proposal evidence no longer belongs to the destination account owner.');
  }
  const linkedCases = all(env.database, `SELECT c.id AS case_id,c.member_id,c.account_id,d.id AS dependency_id FROM case_dependencies d
    JOIN cases c ON c.dataset_id=d.dataset_id AND c.id=d.case_id
    WHERE d.dataset_id=? AND d.kind='suspense' AND d.reference_id=? AND d.state='open'
      AND c.state IN ('open','pending-customer','pending-internal','reopened') ORDER BY c.id,d.id`, env.datasetId, command.suspenseId);
  if (linkedCases.length !== 1) return reject('open_dependencies', 'Suspense clearance requires exactly one active linked investigation case.');
  const linkedCase = linkedCases[0];
  if (linkedCase === undefined) throw new Error('The linked suspense case count was checked.');
  if (optionalStr(linkedCase, 'account_id') !== command.destinationAccountId || str(linkedCase, 'member_id') !== str(destinationAccount, 'member_id')) return reject('ownership_mismatch', 'The linked investigation case no longer identifies the proposed destination owner.');
  const credit = requireCredit(env, command.destinationAccountId, command.amount.currency);
  if (credit !== null) return credit;
  const customer = ledgerForAccount(env, command.destinationAccountId);
  if (customer === undefined || optionalStr(suspense, 'suspense_ledger_id') === null) return reject('ineligible', 'Suspense or destination ledger is unavailable.');
  const approval = requireApproval(env, command, command.approvalId, command.amount);
  if (approval !== null) return approval;
  return approvalPrepared(prepared({
    businessReference: command.suspenseId, result: { suspenseId: command.suspenseId, destinationAccountId: command.destinationAccountId, clearedAmount: command.amount, remainingMinorUnits: 0, caseId: str(linkedCase, 'case_id'), caseState: 'resolved' },
    review: { amount: command.amount, exponent: null, description: command.evidenceReference, accounts: [], consequences: ['Posts a balanced linked clearing entry, reduces only this suspense remainder to zero, and resolves its investigation case.'] },
    apply(apply) {
      enforceSafeLedgerPosting(apply, [
        { ledgerAccountId: str(suspense, 'suspense_ledger_id'), currency: command.amount.currency, debitMinorUnits: command.amount.minorUnits, creditMinorUnits: 0 },
        { ledgerAccountId: str(customer, 'id'), currency: command.amount.currency, debitMinorUnits: 0, creditMinorUnits: command.amount.minorUnits },
      ]);
      const journalId = newId('journal');
      const reference = nextNumber(apply.database, 'journals', 'reference', apply.datasetId, 'SC', 9);
      run(apply.database, "INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,?,?, 'posted',?,?,?,NULL)", apply.datasetId, journalId, reference, apply.operationId, apply.now, localDate(apply.now, apply.timeZone), `Clear suspense ${command.suspenseId}`);
      run(apply.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,0,?)', apply.datasetId, journalId, 1, str(suspense, 'suspense_ledger_id'), command.amount.currency, command.amount.minorUnits, command.evidenceReference);
      run(apply.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,0,?,?)', apply.datasetId, journalId, 2, str(customer, 'id'), command.amount.currency, command.amount.minorUnits, command.evidenceReference);
      run(apply.database, "UPDATE suspense_items SET remaining_amount_minor_units=0,state='cleared' WHERE dataset_id=? AND id=?", apply.datasetId, command.suspenseId);
      run(apply.database, "UPDATE reconciliation_matches SET state='confirmed' WHERE dataset_id=? AND id=?", apply.datasetId, str(proposedMatch, 'id'));
      run(apply.database, "INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,'adjustment')", apply.datasetId, newId('correction-link'), str(suspense, 'journal_id'), journalId, command.amount.minorUnits);
      run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, command.destinationAccountId);
      run(apply.database, "UPDATE case_dependencies SET state='satisfied' WHERE dataset_id=? AND id=?", apply.datasetId, str(linkedCase, 'dependency_id'));
      run(apply.database, "UPDATE cases SET state='resolved',version=version+1 WHERE dataset_id=? AND id=?", apply.datasetId, str(linkedCase, 'case_id'));
      const sequence = (optionalInt(one(apply.database, 'SELECT MAX(sequence) AS maximum FROM case_events WHERE dataset_id=? AND case_id=?', apply.datasetId, str(linkedCase, 'case_id')), 'maximum') ?? 0) + 1;
      run(apply.database, "INSERT INTO case_events (dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail) VALUES (?,?,?,?, 'resolved',?,?,?)", apply.datasetId, newId('case-event'), str(linkedCase, 'case_id'), sequence, apply.now, apply.actorId, `Suspense ${command.suspenseId} cleared in full to ${command.destinationAccountId}; dependency satisfied.`);
      apply.event({ kind: 'case', id: str(linkedCase, 'case_id') }, `Suspense investigation resolved after exact clearance of ${command.suspenseId}.`);
      apply.event({ kind: 'journal', id: journalId }, `Suspense ${command.suspenseId} cleared in full to ${command.destinationAccountId}; original evidence preserved.`);
    },
  }), command.approvalId);
}

function batchRow(env: FinanceEnvironment, batchId: string): Row | undefined {
  const row = one(env.database, 'SELECT id,batch_number,kind,input_document_version_id,input_digest,state,approved_total_limit_minor_units,currency,created_at FROM batches WHERE dataset_id=? AND id=?', env.datasetId, batchId);
  if (row === undefined) return undefined;
  const items = all(env.database, 'SELECT id,ordinal,source_key,item_json,state,receipt_id,amount_minor_units,failure_code FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal,id', env.datasetId, batchId);
  return { ...row, items: canonicalJson(items) };
}

interface ContactItem { memberId: string; expectedVersion: number; email?: string | null; phone?: string | null }
const EMAIL = /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/u;
const PHONE = /^\+?[0-9][0-9 ().-]{6,19}$/u;
function parseContactItem(json: string): ContactItem | null {
  try {
    const value = JSON.parse(json) as Record<string, unknown>;
    if (Array.isArray(value) || Object.keys(value).some((field) => !['memberId','expectedVersion','email','phone'].includes(field))) return null;
    if (typeof value.memberId !== 'string' || !Number.isSafeInteger(value.expectedVersion) || value.email === undefined && value.phone === undefined) return null;
    if (value.email !== undefined && value.email !== null && typeof value.email !== 'string' || value.phone !== undefined && value.phone !== null && typeof value.phone !== 'string') return null;
    if (typeof value.email === 'string' && (!EMAIL.test(value.email) || value.email.length > LIMITS.emailLength) || typeof value.phone === 'string' && !PHONE.test(value.phone)) return null;
    return value as unknown as ContactItem;
  } catch { return null; }
}

function prepareContactsApply(env: FinanceEnvironment, command: FinanceOf<'batch.contacts.apply'>): Preparation {
  const batch = batchRow(env, command.batchId);
  if (batch === undefined) return reject('not_found', 'The batch does not exist.');
  const stale = requireFingerprint(batch, BATCH_COLUMNS, command.expectedFingerprint, 'batch');
  if (stale !== null) return stale;
  if (str(batch, 'kind') !== 'contact-update' || !['previewed','approved','processing'].includes(str(batch, 'state'))) return reject('ineligible', 'Only an immutable contact-update batch with unfinished items may be applied.');
  const selected = one(env.database, 'SELECT id,state FROM batch_items WHERE dataset_id=? AND batch_id=? AND id=?', env.datasetId, command.batchId, command.itemId);
  if (selected === undefined) return reject('ownership_mismatch', 'The selected item does not belong to this batch.', { field: 'itemId' });
  if (!['valid','pending'].includes(str(selected, 'state'))) return { kind: 'unchanged', message: `Batch item ${command.itemId} already has terminal disposition ${str(selected, 'state')}.` };
  const campaign = contactCampaignApproval(env.database, env.datasetId, command);
  if (!('scope' in campaign)) return campaign;
  const rows = all(env.database, "SELECT id,item_json FROM batch_items WHERE dataset_id=? AND batch_id=? AND state IN ('valid','pending') ORDER BY ordinal,id", env.datasetId, command.batchId);
  const evaluated: { id: string; item: ContactItem | null; member: Row | undefined; reason: string | null }[] = [];
  const seenMembers = new Set<string>();
  for (const row of rows) {
    const item = parseContactItem(str(row, 'item_json'));
    const member = item === null ? undefined : loadMember(env, item.memberId);
    let reason: string | null = null;
    if (item === null) reason = 'invalid-schema';
    else if (member === undefined || str(member, 'status') !== 'active') reason = 'member-ineligible';
    else if (int(member, 'version') !== item.expectedVersion) reason = 'stale-version';
    else if (seenMembers.has(item.memberId)) reason = 'duplicate-member';
    if (item !== null) seenMembers.add(item.memberId);
    evaluated.push({ id: str(row, 'id'), item, member, reason });
  }
  const conflicts = evaluated.filter((entry) => entry.reason !== null);
  if (command.conflictPolicy === 'reject-all' && conflicts.length > 0) return reject('stale_version', `The batch has ${conflicts.length} invalid or stale item(s); no item was applied.`);
  const item = evaluated.find((entry) => entry.id === command.itemId);
  if (item === undefined) return reject('ineligible', 'The selected contact item is not actionable.');
  const approval = requireApprovalScope(env, command.approvalId, campaign.scope);
  if (approval !== null) return approval;
  const priorExceptions = int(one(env.database, "SELECT COUNT(*) AS count FROM batch_items WHERE dataset_id=? AND batch_id=? AND id<>? AND state NOT IN ('valid','pending','applied')", env.datasetId, command.batchId, command.itemId), 'count');
  const terminal = rows.length === 1;
  const nextState = terminal ? priorExceptions > 0 || item.reason !== null ? 'completed-with-exceptions' : 'completed' : 'processing';
  const disposition = item.reason === null ? 'applied' : 'skipped';
  return prepared({
    businessReference: `${str(batch, 'batch_number')}:${command.itemId}`, result: { batchId: command.batchId, itemId: command.itemId, disposition, reason: item.reason, batchState: nextState },
    review: noFinanceReview([item.reason === null ? `Applies contact item ${command.itemId} and persists its receipt before the next item.` : `Persists contact item ${command.itemId} as skipped with reason ${item.reason}; no contact is changed.`]),
    apply(apply) {
      const receipt = one(apply.database, 'SELECT id FROM operation_receipts WHERE dataset_id=? AND operation_id=?', apply.datasetId, apply.operationId);
      if (receipt === undefined) throw new Error('Contact checkpoint operation has no receipt.');
      if (item.reason === null && item.item !== null && item.member !== undefined) {
        for (const [kind, value, purpose] of [['email', item.item.email, 'primary'], ['phone', item.item.phone, 'mobile']] as const) {
          if (value === undefined) continue;
          run(apply.database, 'UPDATE contact_points SET valid_to=? WHERE dataset_id=? AND party_id=? AND kind=? AND valid_to IS NULL', apply.now, apply.datasetId, str(item.member, 'party_id'), kind);
          if (value !== null && value.trim() !== '') run(apply.database, 'INSERT INTO contact_points (dataset_id,id,party_id,kind,purpose,value,valid_from,valid_to,verified_at) VALUES (?,?,?,?,?,?,?,NULL,NULL)', apply.datasetId, newId('contact'), str(item.member, 'party_id'), kind, purpose, value.trim(), apply.now);
        }
        run(apply.database, 'UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(item.member, 'id'));
        run(apply.database, "UPDATE batch_items SET state='applied',receipt_id=?,failure_code=NULL WHERE dataset_id=? AND id=?", str(receipt, 'id'), apply.datasetId, command.itemId);
      } else {
        run(apply.database, "UPDATE batch_items SET state='skipped',receipt_id=?,failure_code=? WHERE dataset_id=? AND id=?", str(receipt, 'id'), item.reason, apply.datasetId, command.itemId);
      }
      if (nextState !== str(batch, 'state')) run(apply.database, 'UPDATE batches SET state=? WHERE dataset_id=? AND id=?', nextState, apply.datasetId, command.batchId);
      if (terminal) {
        const consumed = apply.database.prepare("UPDATE business_approvals SET status='consumed' WHERE dataset_id=? AND id=? AND status='approved'").run(apply.datasetId, command.approvalId);
        if (consumed.changes !== 1) throw new Error('Contact campaign approval was no longer available at its terminal checkpoint.');
      }
      apply.event({ kind: 'batch', id: command.batchId }, `Contact campaign item ${command.itemId} ${disposition}${item.reason === null ? '' : `: ${item.reason}`}; checkpoint receipt persisted.`);
    },
  });
}

function prepareRefundBatch(env: FinanceEnvironment, command: FinanceOf<'batch.fee_refunds.apply'>): Preparation {
  const batch = batchRow(env, command.batchId);
  if (batch === undefined) return reject('not_found', 'The batch does not exist.');
  const stale = requireFingerprint(batch, BATCH_COLUMNS, command.expectedFingerprint, 'batch');
  if (stale !== null) return stale;
  const limit = optionalInt(batch, 'approved_total_limit_minor_units');
  const currency = optionalStr(batch, 'currency');
  if (str(batch, 'kind') !== 'fee-refund' || !['previewed','approved','processing'].includes(str(batch, 'state')) || limit === null || currency === null) return reject('ineligible', 'Only an immutable bounded fee-refund batch with unfinished items may be applied.');
  const item = one(env.database, 'SELECT id,item_json,state FROM batch_items WHERE dataset_id=? AND batch_id=? AND id=?', env.datasetId, command.batchId, command.itemId);
  if (item === undefined) return reject('ownership_mismatch', 'The selected item does not belong to this batch.', { field: 'itemId' });
  if (!['valid','pending'].includes(str(item, 'state'))) return { kind: 'unchanged', message: `Batch item ${command.itemId} already has terminal disposition ${str(item, 'state')}.` };
  const campaign = refundCampaignApproval(env.database, env.datasetId, command);
  if (!('scope' in campaign)) return campaign;
  const approval = requireApprovalScope(env, command.approvalId, campaign.scope, campaign.amount, true);
  if (approval !== null) return approval;
  let parsed: unknown;
  try { parsed = JSON.parse(str(item, 'item_json')) as unknown; } catch { parsed = null; }
  const requested = object(parsed) && Object.keys(parsed).sort().join(',') === 'amountMinorUnits,currency,feeId'
    && typeof parsed.feeId === 'string' && typeof parsed.currency === 'string' && Number.isSafeInteger(parsed.amountMinorUnits) && Number(parsed.amountMinorUnits) > 0
    ? { feeId: parsed.feeId, amount: Number(parsed.amountMinorUnits), currency: parsed.currency }
    : null;
  const fee = requested === null ? undefined : one(env.database, `SELECT f.id,f.account_id,f.journal_id,f.original_amount_minor_units,f.currency,f.status,
    COALESCE((SELECT SUM(amount_minor_units) FROM fee_refunds r WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id),0) AS refunded
    FROM fees f WHERE f.dataset_id=? AND f.id=?`, env.datasetId, requested.feeId);
  const applied = int(one(env.database, "SELECT COALESCE(SUM(amount_minor_units),0) AS amount FROM batch_items WHERE dataset_id=? AND batch_id=? AND state='applied'", env.datasetId, command.batchId), 'amount');
  if (applied > limit) return reject('ineligible', 'Prior batch checkpoints exceed the approved campaign maximum.');
  const remainingAuthority = limit - applied;
  let reason: string | null = null;
  if (requested === null) reason = 'invalid-schema';
  else if (fee === undefined || str(fee, 'currency') !== currency || requested.currency !== currency) reason = 'fee-ineligible';
  else if (requested.amount > int(fee, 'original_amount_minor_units') - int(fee, 'refunded')) reason = 'eligibility-changed';
  else if (requested.amount > remainingAuthority) reason = 'campaign-limit';
  const requestedAmount = requested === null ? null : { minorUnits: requested.amount, currency: requested.currency };
  const actionable = int(one(env.database, "SELECT COUNT(*) AS count FROM batch_items WHERE dataset_id=? AND batch_id=? AND state IN ('valid','pending')", env.datasetId, command.batchId), 'count');
  const priorExceptions = int(one(env.database, "SELECT COUNT(*) AS count FROM batch_items WHERE dataset_id=? AND batch_id=? AND id<>? AND state NOT IN ('valid','pending','applied')", env.datasetId, command.batchId, command.itemId), 'count');
  const terminal = actionable === 1;
  const nextState = terminal ? priorExceptions > 0 || reason !== null ? 'completed-with-exceptions' : 'completed' : 'processing';
  const remainingAfter = remainingAuthority - (reason === null && requested !== null ? requested.amount : 0);
  const disposition = reason === null ? 'refunded' : 'skipped';
  const income = generalLedger(env, currency, 'fee-income');
  if (reason === null && income === undefined) return reject('ineligible', 'Fee income ledger is unavailable.');
  return prepared({
    businessReference: `${str(batch, 'batch_number')}:${command.itemId}`,
    result: { batchId: command.batchId, itemId: command.itemId, disposition, reason, feeId: requested?.feeId ?? null, requestedAmount, remainingAuthorityMinorUnits: remainingAfter, batchState: nextState },
    review: { amount: reason === null ? requestedAmount : null, exponent: null, description: str(batch, 'batch_number'), accounts: [], consequences: [reason === null ? `Posts one refund linked to item ${command.itemId} and persists its receipt before the next item.` : `Persists item ${command.itemId} as skipped with reason ${reason}; no financial entry is posted.`] },
    apply(apply) {
      const receipt = one(apply.database, 'SELECT id FROM operation_receipts WHERE dataset_id=? AND operation_id=?', apply.datasetId, apply.operationId);
      if (receipt === undefined) throw new Error('Refund checkpoint operation has no receipt.');
      if (reason === null && requested !== null && fee !== undefined && income !== undefined) {
        const customer = ledgerForAccount(apply, str(fee, 'account_id'));
        if (customer === undefined) throw new Error('Batch fee account ledger disappeared.');
        enforceSafeLedgerPosting(apply, [
          { ledgerAccountId: str(income, 'id'), currency, debitMinorUnits: requested.amount, creditMinorUnits: 0 },
          { ledgerAccountId: str(customer, 'id'), currency, debitMinorUnits: 0, creditMinorUnits: requested.amount },
        ]);
        const journalId = newId('journal');
        const reference = nextNumber(apply.database, 'journals', 'reference', apply.datasetId, 'BF', 9);
        run(apply.database, "INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,?,?, 'posted',?,?,?,NULL)", apply.datasetId, journalId, reference, apply.operationId, apply.now, localDate(apply.now, apply.timeZone), `Batch refund ${str(fee, 'id')}`);
        run(apply.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,0,?)', apply.datasetId, journalId, 1, str(income, 'id'), currency, requested.amount, 'Approved batch fee refund');
        run(apply.database, 'INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,0,?,?)', apply.datasetId, journalId, 2, str(customer, 'id'), currency, requested.amount, 'Approved batch fee refund');
        run(apply.database, 'INSERT INTO fee_refunds (dataset_id,id,fee_id,journal_id,amount_minor_units,actor_id,refunded_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, newId('fee-refund'), str(fee, 'id'), journalId, requested.amount, apply.actorId, apply.now);
        run(apply.database, "INSERT INTO correction_links (dataset_id,id,original_journal_id,correction_journal_id,amount_minor_units,kind) VALUES (?,?,?,?,?,'refund')", apply.datasetId, newId('correction-link'), str(fee, 'journal_id'), journalId, requested.amount);
        run(apply.database, "UPDATE batch_items SET state='applied',receipt_id=?,failure_code=NULL WHERE dataset_id=? AND id=?", str(receipt, 'id'), apply.datasetId, command.itemId);
        const feeRemaining = int(fee, 'original_amount_minor_units') - int(fee, 'refunded') - requested.amount;
        run(apply.database, 'UPDATE fees SET status=? WHERE dataset_id=? AND id=?', feeRemaining === 0 ? 'fully-refunded' : 'partially-refunded', apply.datasetId, str(fee, 'id'));
        run(apply.database, 'UPDATE accounts SET version=version+1 WHERE dataset_id=? AND id=?', apply.datasetId, str(fee, 'account_id'));
        apply.event({ kind: 'fee', id: str(fee, 'id') }, `Refunded ${requested.amount} ${currency} minor units from campaign item ${command.itemId}.`);
      } else run(apply.database, "UPDATE batch_items SET state='skipped',receipt_id=?,failure_code=? WHERE dataset_id=? AND id=?", str(receipt, 'id'), reason, apply.datasetId, command.itemId);
      if (nextState !== str(batch, 'state')) run(apply.database, 'UPDATE batches SET state=? WHERE dataset_id=? AND id=?', nextState, apply.datasetId, command.batchId);
      if (terminal) {
        const consumed = apply.database.prepare("UPDATE business_approvals SET status='consumed' WHERE dataset_id=? AND id=? AND status='approved'").run(apply.datasetId, command.approvalId);
        if (consumed.changes !== 1) throw new Error('Campaign approval was no longer available at its terminal checkpoint.');
      }
      apply.event({ kind: 'batch', id: command.batchId }, `Refund campaign item ${command.itemId} ${disposition}${reason === null ? ` for ${requested?.amount ?? 0} ${currency} minor units` : `: ${reason}`}; ${remainingAfter} minor units of campaign authority remain.`);
    },
  });
}

function prepareDescription(env: FinanceEnvironment, command: FinanceOf<'transaction.description.update'>): Preparation {
  const journal = one(env.database, `SELECT j.id,j.reference,j.status,j.posted_at,j.effective_date,j.description,
    (SELECT new_description FROM transaction_amendments a WHERE a.dataset_id=j.dataset_id AND a.journal_id=j.id ORDER BY amended_at DESC,id DESC LIMIT 1) AS display_description,
    COALESCE((SELECT new_effective_date FROM effective_date_corrections c WHERE c.dataset_id=j.dataset_id AND c.journal_id=j.id ORDER BY corrected_at DESC,id DESC LIMIT 1),j.effective_date) AS display_effective_date
    FROM journals j WHERE j.dataset_id=? AND j.id=?`, env.datasetId, command.journalId);
  if (journal === undefined) return reject('not_found', 'The transaction does not exist.');
  const stale = requireFingerprint(journal, ['id','reference','status','posted_at','effective_date','description','display_description','display_effective_date'], command.expectedFingerprint, 'transaction description');
  if (stale !== null) return stale;
  const invalid = requireText(command.description, 'description', 'Display description', 120);
  if (invalid !== null) return invalid;
  const current = optionalStr(journal, 'display_description') ?? str(journal, 'description');
  if (current === command.description.trim()) return { kind: 'unchanged', message: 'The transaction already has this display description.' };
  if (str(journal, 'status') !== 'posted' || str(journal, 'posted_at') < new Date(Date.parse(env.now) - 120 * 86_400_000).toISOString()) return reject('ineligible', 'The transaction is immutable or outside the open amendment period.');
  return prepared({
    businessReference: str(journal, 'reference'), result: { journalId: command.journalId, oldDescription: current, newDescription: command.description.trim() },
    review: noFinanceReview(['Appends a display-only amendment; amount, dates, status and original journal description remain unchanged.']),
    apply(apply) {
      run(apply.database, 'INSERT INTO transaction_amendments (dataset_id,id,journal_id,actor_id,old_description,new_description,amended_at) VALUES (?,?,?,?,?,?,?)', apply.datasetId, newId('transaction-amendment'), command.journalId, apply.actorId, current, command.description.trim(), apply.now);
      apply.event({ kind: 'journal', id: command.journalId }, `Display description amended from "${current}" to "${command.description.trim()}"; accounting facts unchanged.`);
    },
  });
}

export function prepareFinanceReconciliation(env: FinanceEnvironment, command: FinanceCommand): Preparation | null {
  switch (command.kind) {
    case 'batch.import': return prepareBatchImport(env, command);
    case 'reconciliation.suspense.investigate': return prepareSuspenseInvestigate(env, command);
    case 'reconciliation.suspense.clear': return prepareSuspenseClear(env, command);
    case 'batch.contacts.apply': return prepareContactsApply(env, command);
    case 'batch.fee_refunds.apply': return prepareRefundBatch(env, command);
    case 'transaction.description.update': return prepareDescription(env, command);
    default: return null;
  }
}

export function batchFingerprint(row: Row): string { return rowFingerprint(row, BATCH_COLUMNS); }
