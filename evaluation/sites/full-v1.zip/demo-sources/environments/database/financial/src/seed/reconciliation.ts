import { createHash } from 'node:crypto';
import { renderCsv } from '../documents.js';
import type { SQLInputValue, SQLOutputValue } from 'node:sqlite';
import type { CoreSeedReferences, ExtendedSeedReferences, SeedContext } from './contract.js';
import { insertTwoLineJournal } from './core.js';

type Row = Record<string, SQLOutputValue>;

function at<T>(values: readonly T[], index: number): T {
  const value = values[index];
  if (value === undefined) throw new Error(`Missing reconciliation seed value at ${index}.`);
  return value;
}

function text(row: Row, column: string): string {
  const value = row[column];
  if (typeof value !== 'string') throw new Error(`Expected reconciliation ${column}.`);
  return value;
}

function integer(row: Row, column: string): number {
  const value = row[column];
  if (typeof value !== 'number' || !Number.isSafeInteger(value)) throw new Error(`Expected integer ${column}.`);
  return value;
}

function insert(context: SeedContext, table: string, fields: Record<string, SQLInputValue>): void {
  const row = { dataset_id: context.binding.datasetId, ...fields };
  const columns = Object.keys(row);
  context.database.prepare(`INSERT INTO ${table} (${columns.join(',')}) VALUES (${columns.map(() => '?').join(',')})`).run(...Object.values(row));
}

function seedBatchFee(context: SeedContext, core: CoreSeedReferences, account: Row, key: string, amount: number, applied: boolean): { feeId: string; receiptId: string | null; journalId: string | null } {
  const ledger = text(account, 'ledger_id');
  const gl = core.glAccountIdsByCurrency.USD;
  if (gl === undefined) throw new Error('Batch refunds require USD ledger accounts.');
  const feeId = context.id('batch-fee', key);
  const assessment = insertTwoLineJournal(context, `batch-fee-${key}`, ledger, gl.feeIncome, amount, 'USD', '2026-09-10T15:00:00.000Z', 'Batch service fee assessment');
  insert(context, 'fees', { id: feeId, account_id: text(account, 'id'), journal_id: assessment, original_amount_minor_units: amount, currency: 'USD', policy_version_id: context.id('policy', 1), status: applied ? 'fully-refunded' : 'assessed' });
  if (!applied) return { feeId, receiptId: null, journalId: null };
  const journalId = insertTwoLineJournal(context, `batch-refund-${key}`, gl.feeIncome, ledger, amount, 'USD', '2026-09-12T15:00:00.000Z', 'Batch approved fee refund');
  insert(context, 'fee_refunds', { id: context.id('batch-refund', key), fee_id: feeId, journal_id: journalId, amount_minor_units: amount, actor_id: at(core.actorIds, 1), refunded_at: '2026-09-12T15:00:00.000Z' });
  const receipt = context.database.prepare(`SELECT r.id FROM operation_receipts r JOIN journals j ON j.dataset_id=r.dataset_id AND j.operation_id=r.operation_id WHERE j.dataset_id=? AND j.id=?`).get(context.binding.datasetId, journalId);
  if (receipt === undefined) throw new Error('Batch refund journal has no committed receipt.');
  return { feeId, receiptId: text(receipt, 'id'), journalId };
}

function itemState(batchState: string, index: number): string {
  switch (batchState) {
    case 'uploaded': case 'approved': return 'pending';
    case 'processing': return index < 4 ? 'applied' : 'pending';
    case 'completed': return 'applied';
    case 'completed-with-exceptions': return index < 6 ? 'applied' : at(['invalid', 'duplicate', 'stale', 'out-of-scope', 'skipped', 'failed'], index - 6);
    case 'failed': return 'failed';
    case 'previewed': return at(['valid', 'invalid', 'duplicate', 'stale', 'out-of-scope', 'valid'], index % 6);
    default: throw new Error(`Unknown batch state ${batchState}.`);
  }
}

function seedBatches(context: SeedContext, core: CoreSeedReferences, accounts: Row[]): string[] {
  const batchIds: string[] = [];
  const states = ['uploaded', 'previewed', 'approved', 'processing', 'completed', 'completed-with-exceptions', 'failed'];
  for (let batchIndex = 0; batchIndex < 12; batchIndex++) {
    const batchId = context.id('batch', batchIndex + 1);
    const state = at(states, batchIndex % states.length);
    const kind = ['processing', 'completed', 'completed-with-exceptions'].includes(state) ? 'fee-refund' : at(['contact-update', 'fee-refund', 'settlement'], batchIndex % 3);
    const items = Array.from({ length: 12 }, (_, index) => {
      const account = at(accounts, (batchIndex * 12 + index) % accounts.length);
      const key = `${batchIndex + 1}-${index + 1}`;
      const status = itemState(state, index);
      const amount = status === 'invalid' ? -1 : 200 + index * 25;
      const fee = kind === 'fee-refund' ? seedBatchFee(context, core, account, key, Math.max(200, amount), status === 'applied') : undefined;
      return { key, sourceKey: `BT-${batchIndex + 1}-ROW-${String(index + 1).padStart(4, '0')}`, memberId: text(account, 'member_id'), memberVersion: integer(account, 'member_version'), accountId: text(account, 'id'), feeId: fee?.feeId ?? '', amount, status, receiptId: fee?.receiptId ?? null, journalId: fee?.journalId ?? null };
    });
    const documentId = context.id('batch-document', batchIndex + 1);
    const versionId = context.id('batch-document-version', batchIndex + 1);
    const artifact = kind === 'contact-update'
      ? renderCsv({ columns: ['source_key', 'member_id', 'email'], rows: items.map((item, index) => [item.sourceKey, item.memberId, `batch-${batchIndex + 1}-${index + 1}@example.test`]) })
      : kind === 'fee-refund'
        ? renderCsv({ columns: ['source_key', 'fee_id', 'amount_minor_units', 'currency'], rows: items.map(item => [item.sourceKey, item.feeId, item.amount, 'USD']) })
        : renderCsv({ columns: ['source_key', 'member_id', 'account_id', 'amount_minor_units', 'currency'], rows: items.map(item => [item.sourceKey, item.memberId, item.accountId, item.amount, 'USD']) });
    insert(context, 'document_blobs', { digest: artifact.digest, media_type: 'text/csv', byte_length: artifact.bytes.length, bytes: artifact.bytes });
    insert(context, 'documents', { id: documentId, owner_party_id: at(core.partyIds, 0), account_id: null, document_type: 'batch-input', display_name: `Batch ${batchIndex + 1} source.csv`, retention_class: 'operational-evidence', created_at: '2026-09-11T15:00:00.000Z' });
    insert(context, 'document_versions', { id: versionId, document_id: documentId, version: 1, digest: artifact.digest, media_type: 'text/csv', issued_at: '2026-09-11T15:00:00.000Z', period_start: null, period_end: null, page_count: null, status: 'current' });
    const approved = ['approved', 'processing', 'completed', 'completed-with-exceptions'].includes(state);
    const eligible = items.filter((item) => ['applied', 'pending', 'valid'].includes(item.status));
    const limit = eligible.reduce((sum, item) => sum + item.amount, 0);
    insert(context, 'batches', { id: batchId, batch_number: context.businessNumber('BT', batchIndex + 1, 7), kind, input_document_version_id: versionId, input_digest: artifact.digest, state, approved_total_limit_minor_units: approved ? limit : null, currency: 'USD', created_at: '2026-09-11T15:00:00.000Z' });
    if (approved) {
      const scope = JSON.stringify({ batchId, inputDigest: artifact.digest, kind, itemIds: eligible.map((item) => context.id('batch-item', item.key)), amountLimitMinorUnits: limit, currency: 'USD' });
      insert(context, 'business_approvals', { id: context.id('batch-approval', batchIndex + 1), maker_actor_id: at(core.actorIds, 0), checker_actor_id: at(core.actorIds, 3), action_fingerprint: createHash('sha256').update(scope).digest('hex'), scope_json: scope, amount_limit_minor_units: limit, currency: 'USD', policy_version_id: context.id('policy', 1), status: state.startsWith('completed') ? 'consumed' : 'approved', expires_at: '2026-09-30T15:00:00.000Z' });
    }
    for (const [index, item] of items.entries()) {
      const itemJson = kind === 'contact-update'
        ? { memberId: item.memberId, expectedVersion: item.memberVersion, email: `batch-${batchIndex + 1}-${index + 1}@example.test` }
        : kind === 'fee-refund'
          ? { feeId: item.feeId, amountMinorUnits: item.amount, currency: 'USD' }
          : { memberId: item.memberId, accountId: item.accountId, amountMinorUnits: item.amount, currency: 'USD' };
      insert(context, 'batch_items', { id: context.id('batch-item', item.key), batch_id: batchId, ordinal: index + 1, source_key: item.sourceKey, item_json: JSON.stringify(itemJson), state: item.status, receipt_id: item.receiptId, amount_minor_units: item.amount, failure_code: ['invalid', 'stale', 'out-of-scope', 'failed'].includes(item.status) ? item.status : null });
    }
    batchIds.push(batchId);
  }
  return batchIds;
}

function seedSettlements(context: SeedContext, core: CoreSeedReferences): void {
  context.database.prepare("UPDATE payment_returns SET settlement_reference='EXT-RETURN-'||id WHERE dataset_id=?").run(context.binding.datasetId);
  const rows = context.database.prepare("SELECT id,amount_minor_units,state FROM payments WHERE dataset_id=? AND currency='USD' AND state IN ('released','rejected','settled','returned') ORDER BY id").all(context.binding.datasetId);
  const seen = new Set<string>();
  const states = ['accepted', 'rejected', 'settled', 'returned'];
  const paymentStates = ['released', 'rejected', 'settled', 'returned'];
  for (let index = 0; index < 12; index++) {
    const items = states.map((state, stateIndex) => {
      const pool = rows.filter((row) => row.state === at(paymentStates, stateIndex));
      if (pool.length === 0) throw new Error(`No settlement payment in state ${state}.`);
      const payment = at(pool, index % pool.length);
      const id = text(payment, 'id');
      const effectiveState = seen.has(id) ? 'duplicate' : state;
      seen.add(id);
      return { paymentId: id, amount: integer(payment, 'amount_minor_units'), state: effectiveState };
    });
    items.push({ ...at(items, 0), state: 'duplicate' });
    const id = context.id('settlement-batch', index + 1);
    const reference = context.businessNumber('ST', index + 1, 8);
    const total = items.reduce((sum, item) => sum + (item.state === 'returned' ? -item.amount : ['accepted', 'settled'].includes(item.state) ? item.amount : 0), 0);
    const artifact = renderCsv({
      displayName: `${id}.csv`,
      columns: ['settlement_batch_id', 'reference', 'cutoff_at', 'currency', 'payment_id', 'amount_minor_units', 'state'],
      rows: items.map((item) => [id, reference, '2026-09-14T14:00:00.000Z', 'USD', item.paymentId, item.amount, item.state]),
    });
    insert(context, 'document_blobs', { digest: artifact.digest, media_type: artifact.mediaType, byte_length: artifact.bytes.length, bytes: artifact.bytes });
    const documentId = context.id('settlement-document', index + 1);
    insert(context, 'documents', { id: documentId, owner_party_id: at(core.partyIds, 0), account_id: null, document_type: 'settlement-input', display_name: artifact.displayName, retention_class: 'operational-evidence', created_at: '2026-09-14T14:00:00.000Z' });
    const documentVersionId = context.id('settlement-document-version', index + 1);
    insert(context, 'document_versions', { id: documentVersionId, document_id: documentId, version: 1, digest: artifact.digest, media_type: artifact.mediaType, issued_at: '2026-09-14T14:00:00.000Z', period_start: null, period_end: null, page_count: null, status: 'current' });
    const fileBatchId = context.id('settlement-file-batch', index + 1);
    insert(context, 'batches', { id: fileBatchId, batch_number: reference, kind: 'settlement', input_document_version_id: documentVersionId, input_digest: artifact.digest, state: 'approved', approved_total_limit_minor_units: 0, currency: 'USD', created_at: '2026-09-14T14:00:00.000Z' });
    const approvalScope = JSON.stringify({ batchId: fileBatchId, inputDigest: artifact.digest, kind: 'settlement', settlementBatchId: id });
    insert(context, 'business_approvals', { id: context.id('settlement-file-approval', index + 1), maker_actor_id: at(core.actorIds, 0), checker_actor_id: at(core.actorIds, 3), action_fingerprint: createHash('sha256').update(approvalScope).digest('hex'), scope_json: approvalScope, amount_limit_minor_units: 0, currency: 'USD', policy_version_id: context.id('policy', 1), status: 'approved', expires_at: '2026-09-30T15:00:00.000Z' });
    insert(context, 'settlement_batches', { id, reference, currency: 'USD', declared_total_minor_units: total, state: at(['open', 'final', 'reconciled', 'exception'], index % 4), cutoff_at: '2026-09-14T14:00:00.000Z' });
    for (const [itemIndex, item] of items.entries()) {
      insert(context, 'settlement_items', { id: context.id('settlement-item', `${index + 1}-${itemIndex + 1}`), settlement_batch_id: id, payment_id: item.paymentId, amount_minor_units: item.amount, state: item.state });
      if (item.state === 'returned') context.database.prepare('UPDATE payment_returns SET settlement_reference=? WHERE dataset_id=? AND payment_id=?').run(reference, context.binding.datasetId, item.paymentId);
    }
  }
}

function seedSuspense(context: SeedContext, core: CoreSeedReferences, account: Row): void {
  const gl = core.glAccountIdsByCurrency.USD;
  if (gl === undefined) throw new Error('Suspense requires USD ledger accounts.');
  for (let index = 0; index < 3; index++) {
    const ledger = context.id('suspense-ledger', index + 1);
    insert(context, 'ledger_accounts', { id: ledger, code: `USD-SUSPENSE-${index + 1}`, kind: 'suspense', currency: 'USD', normal_side: 'credit', customer_account_id: null });
    const original = 12_345 + index * 1_000;
    const remaining = index === 0 ? original : index === 1 ? 5_000 : 0;
    const journal = insertTwoLineJournal(context, `suspense-${index + 1}`, gl.settlement, ledger, original, 'USD', '2026-09-11T15:00:00.000Z', 'Unmatched settlement credit');
    if (remaining < original) {
      const correction = insertTwoLineJournal(context, `suspense-clear-${index + 1}`, ledger, index === 1 ? text(account, 'ledger_id') : gl.settlement, original - remaining, 'USD', '2026-09-12T15:00:00.000Z', 'Evidence matched suspense clearance');
      insert(context, 'correction_links', { id: context.id('suspense-correction', index + 1), original_journal_id: journal, correction_journal_id: correction, amount_minor_units: original - remaining, kind: 'adjustment' });
    }
    insert(context, 'suspense_items', { id: context.id('suspense-item', index + 1), journal_id: journal, original_amount_minor_units: original, remaining_amount_minor_units: remaining, currency: 'USD', state: at(['open', 'partially-cleared', 'cleared'], index), evidence_reference: context.businessNumber('SUSPENSE-EVIDENCE', index + 1) });
  }
}

function seedCash(context: SeedContext, core: CoreSeedReferences): void {
  for (let index = 0; index < 6; index++) {
    const id = context.id('cash-session', index + 1);
    const state = at(['open', 'closed', 'reconciled'], index % 3);
    insert(context, 'cash_sessions', { id, actor_id: at(core.actorIds, index % core.actorIds.length), branch_id: at(core.branchIds, index % core.branchIds.length), business_date: '2026-09-13', state, opened_at: '2026-09-13T13:00:00.000Z', closed_at: state === 'open' ? null : '2026-09-13T23:00:00.000Z' });
    insert(context, 'cash_declarations', { id: context.id('cash-declaration', index + 1), cash_session_id: id, currency: 'USD', declared_minor_units: 50_000 + index * 1_000, counted_minor_units: 50_000 + index * 1_000 + (state === 'reconciled' ? 0 : 25), declared_at: '2026-09-13T23:05:00.000Z' });
  }
}

function seedMatches(context: SeedContext): void {
  const evidence = context.database.prepare(`SELECT j.reference AS left_reference,r.receipt_number AS right_reference,l.debit_minor_units AS amount
    FROM journals j JOIN operations o ON o.dataset_id=j.dataset_id AND o.id=j.operation_id
    JOIN operation_receipts r ON r.dataset_id=j.dataset_id AND r.operation_id=j.operation_id
    JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id AND l.line_number=1
    WHERE j.dataset_id=? AND l.currency='USD' AND o.operation_kind='transfer.internal' ORDER BY j.id`).all(context.binding.datasetId);
  const settlement = context.database.prepare(`SELECT b.reference AS left_reference,p.reference AS right_reference,i.amount_minor_units AS amount
    FROM settlement_batches b JOIN settlement_items i ON i.dataset_id=b.dataset_id AND i.settlement_batch_id=b.id
    JOIN payments p ON p.dataset_id=i.dataset_id AND p.id=i.payment_id WHERE b.dataset_id=? AND i.state<>'duplicate' ORDER BY i.id`).all(context.binding.datasetId);
  const suspense = context.database.prepare(`SELECT s.evidence_reference AS left_reference,j.reference AS right_reference,s.original_amount_minor_units AS amount
    FROM suspense_items s JOIN journals j ON j.dataset_id=s.dataset_id AND j.id=s.journal_id WHERE s.dataset_id=? ORDER BY s.id`).all(context.binding.datasetId);
  const cash = context.database.prepare(`SELECT s.id AS left_reference,d.id AS right_reference,d.counted_minor_units AS amount,d.declared_minor_units AS control
    FROM cash_sessions s JOIN cash_declarations d ON d.dataset_id=s.dataset_id AND d.cash_session_id=s.id WHERE s.dataset_id=? ORDER BY s.id`).all(context.binding.datasetId);
  const kinds = ['transfer', 'settlement', 'suspense', 'cash-day'];
  const pools = [evidence, settlement, suspense, cash];
  for (let index = 0; index < 16; index++) {
    const pool = at(pools, index % 4);
    if (pool.length === 0) throw new Error(`Missing actual ${at(kinds, index % 4)} reconciliation evidence.`);
    const source = at(pool, Math.floor(index / 4) % pool.length);
    const amount = integer(source, 'amount');
    const control = source.control === undefined ? amount : integer(source, 'control');
    const state = amount !== control ? 'completed-with-exceptions' : at(['open', 'matched', 'matched', 'completed'], Math.floor(index / 4));
    const matchState = state === 'open' ? 'proposed' : state === 'completed-with-exceptions' ? 'rejected' : 'confirmed';
    const id = context.id('reconciliation-run', index + 1);
    insert(context, 'reconciliation_runs', { id, reference: context.businessNumber('RR', index + 1, 8), kind: at(kinds, index % 4), as_of: context.asOf, state, control_total_minor_units: control, currency: 'USD' });
    insert(context, 'reconciliation_matches', { id: context.id('reconciliation-match', index + 1), run_id: id, left_reference: text(source, 'left_reference'), right_reference: text(source, 'right_reference'), amount_minor_units: amount, currency: 'USD', state: matchState });
  }
}

export function seedReconciliation(context: SeedContext, core: CoreSeedReferences, extended: Pick<ExtendedSeedReferences, 'paymentIds' | 'documentVersionIds'>): string[] {
  if (extended.paymentIds.length === 0) throw new Error('Reconciliation requires seeded payments.');
  const accounts = context.database.prepare(`SELECT a.id,a.member_id,m.version AS member_version,la.id AS ledger_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
    JOIN ledger_accounts la ON la.dataset_id=a.dataset_id AND la.customer_account_id=a.id
    JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
    WHERE a.dataset_id=? AND a.currency='USD' AND a.status='open' AND la.kind='customer-deposit'
      AND b.posted_balance_minor_units>100000 ORDER BY a.id`).all(context.binding.datasetId);
  if (accounts.length === 0) throw new Error('Reconciliation requires funded open USD customer accounts.');
  const batches = seedBatches(context, core, accounts);
  seedSettlements(context, core);
  seedSuspense(context, core, at(accounts, 0));
  seedCash(context, core);
  seedMatches(context);
  return batches;
}
