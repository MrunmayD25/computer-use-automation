/** Relational attribution for typed audit resources. Identical IDs in different tables are distinct subjects. */
const accountResources = [
  ['account', 'accounts', 'id'], ['fee', 'fees', 'account_id'], ['hold', 'holds', 'account_id'],
  ['restriction', 'restrictions', 'account_id'], ['card', 'cards', 'account_id'], ['dispute', 'disputes', 'account_id'],
  ['loan', 'loans', 'account_id'], ['payment', 'payments', 'source_account_id'], ['payment-schedule', 'payment_schedules', 'source_account_id'],
  ['maturity-instruction', 'maturity_instructions', 'account_id'], ['maintenance-request', 'maintenance_requests', 'account_id'],
  ['case', 'cases', 'account_id'], ['document', 'documents', 'account_id'], ['consent', 'consents', 'account_id'],
] as const;
const partyResources = [
  ['identity-evidence','identity_evidence','party_id'], ['name-history','name_history','party_id'],
  ['party-address','party_addresses','party_id'], ['beneficiary','beneficiaries','owner_party_id'],
  ['consent','consents','party_id'], ['document','documents','owner_party_id'],
  ['communication-job','communication_jobs','party_id'], ['communication-preference','communication_preferences','party_id'],
  ['signature','signatures','signer_party_id'],
] as const;
const documentResources = [
  ['document-version','document_versions','id'], ['document-annotation','document_annotations','document_version_id'],
  ['document-access','document_access_events','document_version_id'], ['signature','signatures','document_version_id'],
  ['communication-job','communication_jobs','document_version_id'], ['document-derivation','document_derivations','derivative_version_id'],
] as const;

// Approval scopes retain typed command fields. Match those fields, never arbitrary strings
// such as reasons or evidence references that happen to equal another record's ID.
const approvalFields = `business_approvals approval JOIN json_tree(CASE WHEN json_valid(approval.scope_json) THEN approval.scope_json ELSE '{}' END) field`;
const approvalWhere = `e.resource_kind='approval' AND approval.dataset_id=e.dataset_id AND approval.id=e.resource_id AND field.type='text'`;
function approvalIds(keys: readonly string[], table: string, column: string): string {
  return `SELECT subject.${column} FROM ${approvalFields} JOIN ${table} subject ON subject.dataset_id=approval.dataset_id AND subject.id=field.value
    WHERE ${approvalWhere} AND field.key IN (${keys.map(key=>`'${key}'`).join(',')})`;
}
const approvalAccountIds = [
  approvalIds(['accountId','sourceAccountId','destinationAccountId','correctAccountId','proposedAccountId'], 'accounts', 'id'),
  ...([
    ['feeId','fees','account_id'], ['cardId','cards','account_id'], ['loanId','loans','account_id'],
    ['paymentId','payments','source_account_id'], ['scheduleId','payment_schedules','source_account_id'],
    ['restrictionId','restrictions','account_id'], ['disputeId','disputes','account_id'],
    ['documentId','documents','account_id'], ['caseId','cases','account_id'],
  ] as const).map(([key,table,column])=>approvalIds([key],table,column)),
  `SELECT ledger.customer_account_id FROM ${approvalFields}
    JOIN journal_lines line ON line.dataset_id=approval.dataset_id AND line.journal_id=field.value
    JOIN ledger_accounts ledger ON ledger.dataset_id=line.dataset_id AND ledger.id=line.ledger_account_id
    WHERE ${approvalWhere} AND field.key IN ('journalId','transferJournalId')`,
  `SELECT fee.account_id FROM ${approvalFields}
    JOIN batch_items item ON item.dataset_id=approval.dataset_id AND item.batch_id=field.value
    JOIN fees fee ON fee.dataset_id=item.dataset_id AND fee.id=json_extract(CASE WHEN json_valid(item.item_json) THEN item.item_json ELSE '{}' END,'$.feeId')
    WHERE ${approvalWhere} AND field.key='batchId'`,
];

const accountIds = [
  ...accountResources.map(([kind,table,column])=>`SELECT r.${column} AS account_id FROM ${table} r WHERE e.resource_kind='${kind}' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`),
  ...approvalAccountIds,
  `SELECT m.right_reference FROM reconciliation_runs r JOIN reconciliation_matches m ON m.dataset_id=r.dataset_id AND m.run_id=r.id
    WHERE e.resource_kind='reconciliation' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id AND r.kind='suspense'`,
  `SELECT l.customer_account_id FROM journal_lines r JOIN ledger_accounts l ON l.dataset_id=r.dataset_id AND l.id=r.ledger_account_id WHERE e.resource_kind='journal' AND r.dataset_id=e.dataset_id AND r.journal_id=e.resource_id`,
  ...['case_notes','case_dependencies'].map((table,index)=>`SELECT c.account_id FROM ${table} r JOIN cases c ON c.dataset_id=r.dataset_id AND c.id=r.case_id WHERE e.resource_kind='${index===0?'case-note':'case-dependency'}' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`),
  ...documentResources.map(([kind,table,column])=>`SELECT d.account_id FROM ${table} r JOIN document_versions v ON v.dataset_id=r.dataset_id AND v.id=r.${column} JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE e.resource_kind='${kind}' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`),
  `SELECT d.account_id FROM retention_holds r JOIN documents d ON d.dataset_id=r.dataset_id AND d.id=r.document_id WHERE e.resource_kind='retention-hold' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`,
  `SELECT c.account_id FROM retention_holds r JOIN cases c ON c.dataset_id=r.dataset_id AND c.id=r.case_id WHERE e.resource_kind='retention-hold' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`,
  `SELECT d.account_id FROM communication_events r JOIN communication_jobs j ON j.dataset_id=r.dataset_id AND j.id=r.job_id JOIN document_versions v ON v.dataset_id=j.dataset_id AND v.id=j.document_version_id JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE e.resource_kind='communication-event' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`,
  `SELECT COALESCE(r.account_id,c.account_id,l.account_id) FROM address_destinations r
    LEFT JOIN cards c ON c.dataset_id=r.dataset_id AND c.id=r.card_id LEFT JOIN loans l ON l.dataset_id=r.dataset_id AND l.id=r.loan_id
    WHERE e.resource_kind='address-destination' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`,
  `SELECT f.account_id FROM batch_items r JOIN fees f ON f.dataset_id=r.dataset_id AND f.id=json_extract(CASE WHEN json_valid(r.item_json) THEN r.item_json ELSE '{}' END,'$.feeId') WHERE e.resource_kind='batch' AND r.dataset_id=e.dataset_id AND r.batch_id=e.resource_id`,
].join(' UNION ALL ');
const partyIds = [
  ...partyResources.map(([kind,table,column])=>`SELECT r.${column} AS party_id FROM ${table} r WHERE e.resource_kind='${kind}' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`),
  approvalIds(['ownerPartyId','recipientPartyId','partyId'], 'parties', 'id'),
  approvalIds(['beneficiaryId'], 'beneficiaries', 'owner_party_id'),
  ...documentResources.map(([kind,table,column])=>`SELECT d.owner_party_id FROM ${table} r JOIN document_versions v ON v.dataset_id=r.dataset_id AND v.id=r.${column} JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE e.resource_kind='${kind}' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`),
  `SELECT r.party_id FROM party_addresses r WHERE e.resource_kind='address' AND r.dataset_id=e.dataset_id AND r.address_id=e.resource_id`,
  `SELECT pa.party_id FROM address_destinations r JOIN party_addresses pa ON pa.dataset_id=r.dataset_id AND pa.id=r.party_address_id
    WHERE e.resource_kind='address-destination' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`,
  `SELECT j.party_id FROM communication_events r JOIN communication_jobs j ON j.dataset_id=r.dataset_id AND j.id=r.job_id WHERE e.resource_kind='communication-event' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`,
  `SELECT d.owner_party_id FROM retention_holds r JOIN documents d ON d.dataset_id=r.dataset_id AND d.id=r.document_id WHERE e.resource_kind='retention-hold' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`,
].join(' UNION ALL ');

/** One bound member or account ID; resource identity and dataset are always correlated to event alias e. */
export function activityScopePredicate(scope: 'member' | 'account' | 'case'): string {
  if (scope==='case') return `EXISTS (SELECT 1 FROM (
    SELECT r.id AS case_id FROM cases r WHERE e.resource_kind='case' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id
    UNION ALL SELECT r.case_id FROM case_notes r WHERE e.resource_kind='case-note' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id
    UNION ALL SELECT r.case_id FROM case_dependencies r WHERE e.resource_kind='case-dependency' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id
    UNION ALL SELECT r.case_id FROM retention_holds r WHERE e.resource_kind='retention-hold' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id
    UNION ALL ${approvalIds(['caseId'], 'cases', 'id')}
  ) subject WHERE subject.case_id=?)`;
  if (scope==='account') return `EXISTS (SELECT 1 FROM (${accountIds}) subject WHERE subject.account_id=?)`;
  const memberIds = [
    `SELECT a.member_id FROM accounts a WHERE a.dataset_id=e.dataset_id AND a.id IN (${accountIds})`,
    approvalIds(['memberId','sourceMemberId','targetMemberId','organizationMemberId','signerMemberId','correctMemberId'], 'members', 'id'),
    `SELECT m.id FROM members m WHERE m.dataset_id=e.dataset_id AND m.party_id IN (${partyIds})`,
    ...[['member','members','id'],['member-note','member_notes','member_id'],['case','cases','member_id'],['maintenance-request','maintenance_requests','member_id'],['loan-application','loan_applications','member_id']].map(([kind,table,column])=>`SELECT r.${column} FROM ${table} r WHERE e.resource_kind='${kind}' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`),
    ...['case_notes','case_dependencies'].map((table,index)=>`SELECT c.member_id FROM ${table} r JOIN cases c ON c.dataset_id=r.dataset_id AND c.id=r.case_id WHERE e.resource_kind='${index===0?'case-note':'case-dependency'}' AND r.dataset_id=e.dataset_id AND r.id=e.resource_id`),
    `SELECT m.id FROM batch_items r JOIN members m ON m.dataset_id=r.dataset_id AND m.id=json_extract(CASE WHEN json_valid(r.item_json) THEN r.item_json ELSE '{}' END,'$.memberId') WHERE e.resource_kind='batch' AND r.dataset_id=e.dataset_id AND r.batch_id=e.resource_id`,
  ].join(' UNION ALL ');
  return `EXISTS (SELECT 1 FROM (${memberIds}) subject WHERE subject.member_id=?)`;
}
