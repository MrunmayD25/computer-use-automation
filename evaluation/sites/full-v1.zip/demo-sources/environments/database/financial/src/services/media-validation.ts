import { spawnSync } from 'node:child_process';

import { decode as decodeJpeg } from 'jpeg-js';
import { PNG } from 'pngjs';

export const MAX_DOCUMENT_BYTES = 20 * 1024 * 1024;
export const MAX_IMAGE_DIMENSION = 16_384;
export const MAX_IMAGE_PIXELS = 16_000_000;
export const MAX_IMAGE_DECODE_MEMORY_MIB = 64;

export interface MediaDimensions {
  width: number;
  height: number;
}

export type DocumentMediaValidation =
  | { valid: true; dimensions: MediaDimensions | null; pageCount?: number }
  | { valid: false; message: string };

function invalid(message: string): DocumentMediaValidation {
  return { valid: false, message };
}

function dimensionProblem(width: number, height: number, label: string): string | null {
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 1 || height < 1) return `${label} dimensions must be positive integers.`;
  if (width > MAX_IMAGE_DIMENSION || height > MAX_IMAGE_DIMENSION) return `${label} dimensions cannot exceed ${MAX_IMAGE_DIMENSION} pixels.`;
  if (width * height > MAX_IMAGE_PIXELS) return `${label} cannot exceed ${MAX_IMAGE_PIXELS} pixels.`;
  return null;
}

function validatePng(bytes: Uint8Array): DocumentMediaValidation {
  const source = Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const signature = '89504e470d0a1a0a';
  if (source.byteLength < 33 || source.subarray(0, 8).toString('hex') !== signature
    || source.readUInt32BE(8) !== 13 || source.subarray(12, 16).toString('ascii') !== 'IHDR') {
    return invalid('PNG bytes must contain a complete signature and IHDR chunk.');
  }
  const width = source.readUInt32BE(16); const height = source.readUInt32BE(20);
  const problem = dimensionProblem(width, height, 'PNG'); if (problem !== null) return invalid(problem);
  try {
    const decoded = PNG.sync.read(source, { checkCRC: true });
    if (decoded.width !== width || decoded.height !== height) return invalid('Decoded PNG dimensions do not match its IHDR chunk.');
    return { valid: true, dimensions: { width, height } };
  } catch {
    return invalid('PNG bytes could not be decoded as a structurally valid image.');
  }
}

function validateJpeg(bytes: Uint8Array): DocumentMediaValidation {
  if (bytes.byteLength < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8 || bytes[2] !== 0xff
    || bytes.at(-2) !== 0xff || bytes.at(-1) !== 0xd9) return invalid('JPEG bytes do not contain complete start and end markers.');
  try {
    const decoded = decodeJpeg(bytes, {
      useTArray: true,
      formatAsRGBA: false,
      tolerantDecoding: false,
      maxResolutionInMP: MAX_IMAGE_PIXELS / 1_000_000,
      maxMemoryUsageInMB: MAX_IMAGE_DECODE_MEMORY_MIB,
    });
    const problem = dimensionProblem(decoded.width, decoded.height, 'JPEG'); if (problem !== null) return invalid(problem);
    return { valid: true, dimensions: { width: decoded.width, height: decoded.height } };
  } catch {
    return invalid('JPEG bytes could not be decoded as a structurally valid image.');
  }
}

function validatePdf(bytes: Uint8Array): DocumentMediaValidation {
  const inspected = spawnSync('pdfinfo', ['-'], {
    input: Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength),
    encoding: 'utf8',
    timeout: 5_000,
    maxBuffer: 1024 * 1024,
  });
  if (inspected.error !== undefined || inspected.status !== 0 || inspected.signal !== null) {
    return invalid('PDF bytes could not be decoded as a structurally valid document.');
  }
  const match = /^Pages:\s+([1-9]\d*)\s*$/mu.exec(inspected.stdout);
  if (match === null) return invalid('Decoded PDF did not report a positive page count.');
  const pageCount = Number(match[1]);
  if (!Number.isSafeInteger(pageCount)) return invalid('Decoded PDF page count is outside the supported range.');
  return { valid: true, dimensions: null, pageCount };
}

/** Validates bounded document bytes and fully decodes each supported media format. */
export function validateDocumentMedia(bytes: Uint8Array, mediaType: string): DocumentMediaValidation {
  if (!(bytes instanceof Uint8Array) || bytes.byteLength < 1 || bytes.byteLength > MAX_DOCUMENT_BYTES) {
    return invalid(`Document bytes must contain 1 to ${MAX_DOCUMENT_BYTES} bytes.`);
  }
  switch (mediaType) {
    case 'application/pdf': return validatePdf(bytes);
    case 'image/png': return validatePng(bytes);
    case 'image/jpeg': return validateJpeg(bytes);
    default: return invalid('Media type must be application/pdf, image/png or image/jpeg.');
  }
}
