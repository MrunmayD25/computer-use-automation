import { constants } from 'node:buffer';
import { createHash } from 'node:crypto';
import { closeSync, openSync, readFileSync, readSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { isDeepStrictEqual } from 'node:util';
import { attachSnapshot, captureSnapshot, closeSnapshot, digest, freeze, inheritSnapshot, replaySnapshot, snapshotHistory, snapshotLifetime, type SnapshotLifetime } from './run-storage.js';
import type { CapturedTransaction, RunEvidence, RunSnapshot } from './run-types.js';

interface EvidenceIdentity { lifetime: SnapshotLifetime; parent?: RunEvidence; reconstruction?: readonly string[] }
const identities = new WeakMap<RunEvidence, EvidenceIdentity>();
export function fileDigest(path: string): { byteLength: number; digest: string } {
  const file = openSync(path, 'r');
  const hash = createHash('sha256');
  const buffer = Buffer.allocUnsafe(1024 * 1024);
  let byteLength = 0;
  try {
    for (;;) {
      const count = readSync(file, buffer, 0, buffer.length, null);
      if (count === 0) break;
      byteLength += count; hash.update(buffer.subarray(0, count));
    }
  } finally { closeSync(file); }
  return { byteLength, digest: hash.digest('hex') };
}
export function registerEvidence(evidence: RunEvidence, reconstruction?: readonly string[]): RunEvidence {
  identities.set(evidence, { lifetime: snapshotLifetime(evidence.before), ...(reconstruction === undefined ? {} : { reconstruction: freeze([...reconstruction]) }) });
  return freeze(evidence);
}
function identity(evidence: RunEvidence): EvidenceIdentity {
  const value = identities.get(evidence);
  if (value === undefined) throw new Error('Evidence is not an authentic registered verification result.');
  if (value.lifetime.closed) throw new Error('Evidence reader is closed.');
  return value;
}
function readManifest(path: string): unknown {
  if (statSync(path).size > constants.MAX_STRING_LENGTH) throw new Error('Evidence manifest byte limit exceeded.');
  return JSON.parse(readFileSync(path, 'utf8')) as unknown;
}
function record(value: unknown, label: string): Record<string, unknown> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error(`Invalid ${label}.`);
  return value as Record<string, unknown>;
}
function validateSnapshot(value: unknown): asserts value is RunSnapshot {
  const snapshot = record(value, 'snapshot');
  const { digest: expected, ...body } = snapshot;
  if (typeof expected !== 'string' || digest(body) !== expected) throw new Error('Snapshot digest mismatch.');
  if (typeof body.label !== 'string' || typeof body.schemaDigest !== 'string' || !Number.isSafeInteger(body.sequence) || Number(body.sequence) < 0) throw new Error('Invalid snapshot metadata.');
  for (const entry of Object.values(record(body.tables, 'snapshot tables'))) {
    const table = record(entry, 'snapshot table');
    if (!Array.isArray(table.columns) || !table.columns.every((column: unknown) => typeof column === 'string')
      || !Array.isArray(table.primaryKey) || table.primaryKey.length === 0
      || !table.primaryKey.every((column: unknown) => typeof column === 'string' && (table.columns as unknown[]).includes(column))
      || !['canonical-json-v1', 'sqlite-pk-v1'].includes(String(table.ordering))
      || !Array.isArray(table.primaryKeyTypes)
      || !table.primaryKeyTypes.every((type: unknown) => ['TEXT', 'INTEGER', 'REAL'].includes(String(type)))
      || (table.ordering === 'sqlite-pk-v1' && table.primaryKeyTypes.length !== table.primaryKey.length)
      || (table.ordering === 'canonical-json-v1' && table.primaryKeyTypes.length !== 0)
      || 'rows' in table || typeof table.digest !== 'string') throw new Error('Invalid snapshot table shape.');
    for (const field of ['rowCount', 'blobBytes', 'byteLength']) if (!Number.isSafeInteger(table[field]) || Number(table[field]) < 0) throw new Error('Invalid snapshot table count.');
  }
}
function validateRow(value: unknown): void {
  for (const cell of Object.values(record(value, 'captured row'))) {
    if (cell === null || typeof cell === 'string' || (typeof cell === 'number' && Number.isFinite(cell) && (!Number.isInteger(cell) || Number.isSafeInteger(cell)))) continue;
    const encoded = record(cell, 'captured value');
    if (encoded.kind === 'integer' && typeof encoded.decimal === 'string' && /^-?\d+$/.test(encoded.decimal)) continue;
    if (encoded.kind === 'blob' && typeof encoded.digest === 'string' && /^[a-f0-9]{64}$/.test(encoded.digest)
      && Number.isSafeInteger(encoded.byteLength) && Number(encoded.byteLength) >= 0) continue;
    throw new Error('Invalid captured value encoding.');
  }
}
function validateManifest(value: unknown): asserts value is RunEvidence {
  const evidence = record(value, 'evidence manifest');
  const { digest: expected, ...body } = evidence;
  if (typeof expected !== 'string' || digest(body) !== expected) throw new Error('Run evidence digest mismatch.');
  if (body.version !== 2 || typeof body.captureComplete !== 'boolean' || !Array.isArray(body.transactions)
    || !Array.isArray(body.diagnostics) || !body.diagnostics.every((item: unknown) => typeof item === 'string')) throw new Error('Invalid run evidence envelope.');
  const descriptor = record(body.descriptor, 'descriptor');
  for (const field of ['runId', 'contractDigest', 'databasePath', 'evidencePath', 'schemaDigest']) if (typeof descriptor[field] !== 'string' || descriptor[field].length === 0) throw new Error(`Invalid run descriptor ${field}.`);
  if (!Array.isArray(descriptor.bindings) || descriptor.bindings.length === 0) throw new Error('Missing recorded bindings.');
  for (const item of descriptor.bindings) {
    const binding = record(item, 'binding');
    if (typeof binding.datasetId !== 'string' || typeof binding.institutionId !== 'string') throw new Error('Invalid recorded binding.');
  }
  const baseline = record(body.baseline, 'baseline artifact');
  if (baseline.file !== 'baseline.sqlite' || !Number.isSafeInteger(baseline.byteLength) || Number(baseline.byteLength) <= 0
    || typeof baseline.digest !== 'string' || !/^[a-f0-9]{64}$/.test(baseline.digest)) throw new Error('Invalid baseline artifact.');
  const limits = record(body.limits, 'run limits');
  for (const field of ['maxRows', 'maxChanges', 'maxBlobBytes', 'maxSnapshotBytes', 'busyTimeoutMs']) if (!Number.isSafeInteger(limits[field]) || Number(limits[field]) <= 0) throw new Error('Invalid run limits.');
  if (body.transactions.length > Number(limits.maxChanges)) throw new Error('Capture transaction limit exceeded.');
  validateSnapshot(body.before); validateSnapshot(body.after);
  if (body.before.schemaDigest !== descriptor.schemaDigest || body.before.sequence !== 0 || body.before.label !== 'before' || body.after.label !== 'after') throw new Error('Baseline schema, label or sequence does not match the run.');
  let sequence = 0;
  const ids = new Set<string>();
  for (const item of body.transactions) {
    const transaction = record(item, 'transaction');
    if (typeof transaction.id !== 'string' || ids.has(transaction.id) || !Array.isArray(transaction.changes)) throw new Error('Invalid or duplicate captured transaction.');
    ids.add(transaction.id);
    const context = record(transaction.context, 'transaction context');
    if (!['automation', 'human', 'peer', 'system'].includes(String(context.kind)) || typeof context.reference !== 'string' || context.reference.trim().length === 0) throw new Error('Invalid captured principal.');
    for (const item of transaction.changes) {
      const change = record(item, 'row change');
      if (change.sequence !== ++sequence || change.transactionId !== transaction.id || typeof change.table !== 'string' || !['insert', 'update', 'delete'].includes(String(change.operation))) throw new Error('Invalid change sequence or transaction binding.');
      validateRow(change.key);
      if (change.before !== null) validateRow(change.before);
      if (change.after !== null) validateRow(change.after);
    }
  }
  if (sequence > Number(limits.maxChanges) || body.after.sequence !== sequence) throw new Error('Invalid final capture sequence or change limit.');
}
function verifyBaseline(evidence: RunEvidence): string {
  const path = join(dirname(evidence.descriptor.evidencePath), evidence.baseline.file);
  if (!isDeepStrictEqual(fileDigest(path), { byteLength: evidence.baseline.byteLength, digest: evidence.baseline.digest })) throw new Error('Baseline artifact digest mismatch.');
  return path;
}
/** Validates the private reader identity and retained artifact binding before grading. */
export function assertRunEvidence(evidence: RunEvidence): void {
  const registered = identity(evidence);
  if (registered.parent !== undefined) { identity(registered.parent); return; }
  const stored = readManifest(evidence.descriptor.evidencePath);
  validateManifest(stored);
  if (!isDeepStrictEqual(stored, evidence)) throw new Error('Supplied evidence differs from the sealed capture.');
  verifyBaseline(evidence);
}
export function isEvidenceSlice(evidence: RunEvidence): boolean { return identity(evidence).parent !== undefined; }
export function closeRunEvidence(evidence: RunEvidence): void {
  const registered = identities.get(evidence);
  if (registered !== undefined && registered.parent === undefined) closeSnapshot(evidence.before);
}
export function checkEvidenceReconstruction(evidence: RunEvidence): readonly string[] {
  try {
    const registered = identity(evidence);
    if (registered.reconstruction !== undefined) return registered.reconstruction;
    const reconstructed = replaySnapshot(evidence.before, evidence.transactions, evidence.after.label);
    registered.reconstruction = freeze(reconstructionDifferences(reconstructed, evidence.after));
    return registered.reconstruction;
  } catch (error) { return [error instanceof Error ? error.message : String(error)]; }
}
function reconstructionDifferences(reconstructed: RunSnapshot, after: RunSnapshot): string[] {
  const failures: string[] = [];
  if (reconstructed.schemaDigest !== after.schemaDigest || reconstructed.sequence !== after.sequence) failures.push('Snapshot schema or sequence does not reconstruct.');
  for (const name of new Set([...Object.keys(reconstructed.tables), ...Object.keys(after.tables)])) {
    if (!isDeepStrictEqual(reconstructed.tables[name], after.tables[name])) failures.push(`Capture does not reconstruct table ${name}.`);
  }
  return failures;
}
export function createEvidenceSlice(evidence: RunEvidence, before: RunSnapshot, after: RunSnapshot, transactions: readonly CapturedTransaction[]): RunEvidence {
  const registered = identity(evidence);
  if (snapshotLifetime(before) !== registered.lifetime || snapshotLifetime(after) !== registered.lifetime || before.sequence > after.sequence) throw new Error('Invalid child snapshot ownership or sequence.');
  for (const snapshot of [before, after]) {
    const history = snapshotHistory(snapshot);
    if (!isDeepStrictEqual(history, evidence.transactions.slice(0, history.length))) throw new Error('Child snapshot history is not a real parent transaction boundary.');
  }
  for (const transaction of transactions) if (!evidence.transactions.includes(transaction)) throw new Error('Child transaction is absent from parent evidence.');
  const slice = freeze({ ...evidence, before, after, transactions: [...transactions] });
  identities.set(slice, { lifetime: registered.lifetime, parent: evidence });
  return slice;
}
export function loadRunEvidence(evidencePath: string): RunEvidence {
  const parsed = readManifest(evidencePath);
  validateManifest(parsed);
  if (parsed.descriptor.evidencePath !== evidencePath) throw new Error('Evidence manifest path does not match its descriptor.');
  const baselinePath = verifyBaseline(parsed);
  using database = new DatabaseSync(baselinePath, { readOnly: true });
  database.exec('PRAGMA query_only=ON; BEGIN');
  const actual = captureSnapshot(database, 'before', parsed.limits);
  if (!isDeepStrictEqual(actual, parsed.before)) throw new Error('Baseline snapshot metadata or digest mismatch.');
  const lifetime = { closed: false };
  attachSnapshot(parsed.before, baselinePath, parsed.limits, lifetime);
  try {
    const after = replaySnapshot(parsed.before, parsed.transactions, 'after');
    inheritSnapshot(parsed.after, after);
    const failures = reconstructionDifferences(after, parsed.after);
    if (parsed.captureComplete && (parsed.diagnostics.length !== 0 || failures.length !== 0)) throw new Error(`Complete evidence has inconsistent snapshots or changes: ${failures.join(' ')}`);
    return registerEvidence(parsed, failures);
  } catch (error) { closeSnapshot(parsed.before); throw error; }
}
