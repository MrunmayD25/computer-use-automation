import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import fontkit from '@pdf-lib/fontkit';
import { renderAsync } from '@resvg/resvg-js';
import { PDFDocument, degrees, rgb, type PDFFont, type PDFPage } from 'pdf-lib';

export interface DocumentArtifact {
  bytes: Uint8Array;
  displayName: string;
  mediaType: 'application/pdf' | 'text/csv' | 'image/png' | 'text/html';
  pageCount: number;
  digest: string;
  extractedText?: string;
}

export interface DocumentSection {
  heading: string;
  lines: readonly string[];
}

export interface FinancialDocumentInput {
  title: string;
  displayName?: string;
  institutionName: string;
  ownerName: string;
  memberNumber: string;
  accountNumber?: string;
  asOf: string;
  documentType: string;
  version: number;
  sections: readonly DocumentSection[];
}

export interface StatementEntry {
  reference: string;
  date: string;
  description: string;
  amountMinor: number;
}

export interface StatementDocumentInput {
  institutionName: string;
  ownerName: string;
  memberNumber: string;
  accountNumber: string;
  currency: string;
  currencyExponent: number;
  periodStart: string;
  periodEndExclusive: string;
  asOf: string;
  openingBalanceMinor: number;
  entries: readonly StatementEntry[];
}

export interface CsvDocumentInput {
  displayName?: string;
  columns: readonly string[];
  rows: readonly (readonly (string | number)[])[];
}

const maximumRows = 10_000;
const maximumTextLength = 1_000_000;
const maximumMoney = 1_000_000_000_000;
const pageWidth = 612;
const pageHeight = 792;
const margin = 44;
const fontPath = fileURLToPath(new URL('../src/assets/NotoSans-Regular.ttf', import.meta.url));
const fontBytes = readFileSync(fontPath);
const glyphFont = fontkit.create(fontBytes);

function requireGlyphs(text: string): void {
  for (const character of text) {
    const codepoint = character.codePointAt(0);
    if (codepoint !== undefined && character !== '\n' && character !== '\r' && !glyphFont.hasGlyphForCodePoint(codepoint)) {
      throw new Error(`Unsupported glyph U+${codepoint.toString(16).toUpperCase()} in document text.`);
    }
  }
}

function artifact(bytes: Uint8Array, mediaType: DocumentArtifact['mediaType'], pageCount: number, extractedText?: string): DocumentArtifact {
  return { bytes, mediaType, pageCount, displayName: mediaType === 'application/pdf' ? 'document.pdf' : mediaType === 'image/png' ? 'scan.png' : 'records.csv', digest: createHash('sha256').update(bytes).digest('hex'),
    ...(extractedText === undefined ? {} : { extractedText }) };
}

function requireText(value: string, name: string, maximum = maximumTextLength): void {
  if (typeof value !== 'string' || value.length === 0 || value.length > maximum || Array.from(value).some(character => { const code = character.codePointAt(0) ?? 0; return code < 32 && code !== 9 && code !== 10 && code !== 13; })) {
    throw new Error(`${name} must be non-empty bounded text without control characters.`);
  }
}

function requireDate(value: string): void {
  if (!/^\d{4}-\d{2}-\d{2}$/u.test(value) || new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) !== value) {
    throw new Error('Date must be a valid ISO local date.');
  }
}

function requireMoney(value: number): void {
  if (!Number.isSafeInteger(value)) throw new Error('Money must be an exact integer.');
  if (Math.abs(value) > maximumMoney) throw new Error('Money exceeds the supported range.');
}

export function formatMinorUnits(value: number, currency: string, exponent: number): string {
  requireMoney(value);
  if (!/^[A-Z]{3}$/u.test(currency) || !Number.isInteger(exponent) || exponent < 0 || exponent > 3) throw new Error('Currency and exponent are invalid.');
  const absolute = Math.abs(value);
  const divisor = 10 ** exponent;
  const integer = Math.floor(absolute / divisor).toString().replace(/\B(?=(\d{3})+(?!\d))/gu, ',');
  const decimal = exponent === 0 ? '' : `.${(absolute % divisor).toString().padStart(exponent, '0')}`;
  return `${value < 0 ? '-' : ''}${integer}${decimal} ${currency}`;
}

function wrap(text: string, font: PDFFont, size: number, width: number): string[] {
  const lines: string[] = [];
  for (const paragraph of text.split(/\r?\n/u)) {
    let current = '';
    for (const character of paragraph) {
      const next = current + character;
      if (font.widthOfTextAtSize(next, size) > width && current.length > 0) {
        lines.push(current);
        current = character;
      } else {
        current = next;
      }
    }
    lines.push(current);
  }
  return lines;
}

export async function renderDocument(input: FinancialDocumentInput): Promise<DocumentArtifact> {
  requireText(input.title, 'Title', 200);
  requireText(input.institutionName, 'Institution', 200);
  requireText(input.ownerName, 'Owner', 300);
  requireText(input.memberNumber, 'Member number', 100);
  requireText(input.documentType, 'Document type', 100);
  if (!Number.isSafeInteger(input.version) || input.version < 1) throw new Error('Version must be a positive integer.');
  const instant = new Date(input.asOf);
  if (!Number.isFinite(instant.getTime()) || !/(Z|[+-]\d\d:\d\d)$/u.test(input.asOf)) throw new Error('asOf must be an explicit valid instant.');
  const text = input.sections.flatMap(section => [section.heading, ...section.lines]).join('\n');
  requireText(text, 'Document content');
  if (input.sections.reduce((count, section) => count + section.lines.length, 0) > maximumRows) throw new Error('Document row limit exceeded.');
  const document = await PDFDocument.create();
  document.setCreationDate(instant);
  document.setModificationDate(instant);
  document.setTitle(input.title);
  document.setAuthor(input.institutionName);
  document.setSubject(`${input.documentType}; ${input.memberNumber}; version ${input.version}`);
  document.setCreator('Synthetic financial document generator v1');
  document.setProducer('Synthetic financial document generator v1');
  requireGlyphs([input.title, input.institutionName, input.ownerName, input.memberNumber, input.accountNumber ?? '', text].join('\n'));
  document.registerFontkit(fontkit);
  const font = await document.embedFont(fontBytes, { subset: true });
  const bold = font;
  let page: PDFPage;
  let y = 0;
  const newPage = (): void => {
    page = document.addPage([pageWidth, pageHeight]);
    page.drawRectangle({ x: 0, y: pageHeight - 16, width: pageWidth, height: 16, color: rgb(0.09, 0.23, 0.29) });
    let headerY = pageHeight - 46;
    for (const line of wrap(input.institutionName, bold, 13, pageWidth - 2 * margin)) {
      page.drawText(line, { x: margin, y: headerY, size: 13, font: bold, color: rgb(0.09, 0.23, 0.29) });
      headerY -= 17;
    }
    for (const line of wrap(`Member: ${input.memberNumber}${input.accountNumber === undefined ? '' : `    Account: ${input.accountNumber}`}`, font, 8, pageWidth - 2 * margin)) {
      page.drawText(line, { x: margin, y: headerY, size: 8, font });
      headerY -= 12;
    }
    page.drawText('SYNTHETIC RECORD - LOCAL SIMULATION ONLY', { x: margin, y: 29, size: 8, font });
    y = headerY - 14;
  };
  const draw = (value: string, size = 10, strong = false): void => {
    const selected = strong ? bold : font;
    for (const line of wrap(value, selected, size, pageWidth - 2 * margin)) {
      if (y < 64) newPage();
      page.drawText(line, { x: margin, y, size, font: selected, color: rgb(0.12, 0.16, 0.2) });
      y -= size + 5;
    }
  };
  newPage();
  draw(input.title, 20, true);
  draw(`Owner: ${input.ownerName}`);
  draw(`Member: ${input.memberNumber}${input.accountNumber === undefined ? '' : `    Account: ${input.accountNumber}`}`);
  draw(`Issued: ${input.asOf}    Version: ${input.version}`, 9);
  y -= 9;
  for (const section of input.sections) {
    if (y < 110) newPage();
    draw(section.heading, 12, true);
    for (const line of section.lines) draw(line);
    y -= 10;
  }
  const pages = document.getPages();
  pages.forEach((item, index) => item.drawText(`${index + 1} / ${pages.length}`, { x: pageWidth - 77, y: 29, size: 8, font }));
  const bytes = await document.save({ useObjectStreams: false });
  return { ...artifact(bytes, 'application/pdf', pages.length, [input.title, input.ownerName, input.memberNumber, text].join('\n')), displayName: input.displayName ?? `${input.documentType}.pdf` };
}

export async function renderStatementPdf(input: StatementDocumentInput): Promise<DocumentArtifact> {
  requireDate(input.periodStart);
  requireDate(input.periodEndExclusive);
  if (input.periodStart >= input.periodEndExclusive) throw new Error('Statement period must have positive duration.');
  if (!/^[A-Z]{3}$/u.test(input.currency) || !Number.isInteger(input.currencyExponent) || input.currencyExponent < 0 || input.currencyExponent > 3) {
    throw new Error('Statement currency and exponent are invalid.');
  }
  if (input.entries.length > maximumRows) throw new Error('Statement row limit exceeded.');
  requireMoney(input.openingBalanceMinor);
  let balance = input.openingBalanceMinor;
  let credits = 0;
  let debits = 0;
  let previous = input.periodStart;
  const lines = input.entries.map(entry => {
    requireDate(entry.date);
    requireText(entry.reference, 'Transaction reference', 100);
    requireText(entry.description, 'Transaction description', 500);
    if (entry.date < input.periodStart || entry.date >= input.periodEndExclusive || entry.date < previous) throw new Error('Entry is outside its statement period or chronological order.');
    previous = entry.date;
    requireMoney(entry.amountMinor);
    balance += entry.amountMinor;
    requireMoney(balance);
    if (entry.amountMinor >= 0) credits += entry.amountMinor;
    else debits -= entry.amountMinor;
    requireMoney(credits);
    requireMoney(debits);
    return `${entry.date} | ${entry.reference} | ${entry.description} | ${formatMinorUnits(entry.amountMinor, input.currency, input.currencyExponent)} | Balance ${formatMinorUnits(balance, input.currency, input.currencyExponent)}`;
  });
  return renderDocument({
    title: 'Account statement', institutionName: input.institutionName, ownerName: input.ownerName,
    memberNumber: input.memberNumber, accountNumber: input.accountNumber, asOf: input.asOf,
    documentType: 'account-statement', version: 1,
    sections: [
      { heading: 'Statement period', lines: [`${input.periodStart} inclusive to ${input.periodEndExclusive} exclusive`] },
      { heading: 'Balance summary', lines: [
        `Opening balance: ${formatMinorUnits(input.openingBalanceMinor, input.currency, input.currencyExponent)}`,
        `Credits: ${formatMinorUnits(credits, input.currency, input.currencyExponent)}`,
        `Debits: ${formatMinorUnits(debits, input.currency, input.currencyExponent)}`,
        `Closing balance: ${formatMinorUnits(balance, input.currency, input.currencyExponent)}`,
      ] },
      { heading: 'Posted transactions', lines: lines.length === 0 ? ['No posted transactions in this period.'] : lines },
    ],
  });
}

export function renderCsv(input: CsvDocumentInput): DocumentArtifact {
  if (input.columns.length === 0 || input.columns.length > 100 || input.rows.length > maximumRows) throw new Error('CSV dimensions exceed limits.');
  const escape = (value: string | number): string => {
    if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('CSV numeric value must be finite.');
    const text = String(value);
    if (text.length > 10_000 || text.includes('\0')) throw new Error('CSV field exceeds limits or contains NUL.');
    const safe = typeof value === 'string' && /^[\s]*[=+@-]/u.test(text) ? `'${text}` : text;
    return /[",\r\n]/u.test(safe) ? `"${safe.replaceAll('"', '""')}"` : safe;
  };
  const rows = [input.columns, ...input.rows].map(row => {
    if (row.length !== input.columns.length) throw new Error('CSV row does not match its columns.');
    return row.map(escape).join(',');
  });
  const text = `${rows.join('\r\n')}\r\n`;
  if (text.length > maximumTextLength * 8) throw new Error('CSV file exceeds size limit.');
  return { ...artifact(Buffer.from(text, 'utf8'), 'text/csv', 0, text), displayName: input.displayName ?? 'records.csv' };
}


export interface ScanDocumentInput extends FinancialDocumentInput {
  rotation?: 0 | 90 | 180 | 270;
  embeddedTranscript?: string;
}

export async function renderScanPng(input: FinancialDocumentInput): Promise<DocumentArtifact> {
  const text = [input.institutionName, input.title, `Owner: ${input.ownerName}`, `Member: ${input.memberNumber}`,
    `Issued: ${input.asOf}   Version: ${input.version}`,
    ...input.sections.flatMap(section => [section.heading, ...section.lines]),
    'SYNTHETIC RECORD - LOCAL SIMULATION ONLY'];
  requireText(text.join('\n'), 'Scan text', 5000);
  requireGlyphs(text.join('\n'));
  const wrapped = text.flatMap(line => {
    const chunks: string[] = [];
    let current = '';
    for (const character of line) {
      if (Array.from(current).length >= 65) {
        chunks.push(current);
        current = '';
      }
      current += character;
    }
    chunks.push(current);
    return chunks;
  });
  if (wrapped.length > 32) throw new Error('Scan text exceeds one-page capacity.');
  const xml = (value: string): string => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1224" height="1584" viewBox="0 0 1224 1584">
    <rect width="1224" height="1584" fill="#f9f7ef"/>
    <rect x="54" y="54" width="1116" height="1476" rx="2" fill="none" stroke="#aaa89d" stroke-width="2"/>
    <path d="M90 155 L1134 155" stroke="#52666d" stroke-width="3"/>
    ${wrapped.map((line, index) => `<text x="90" y="${112 + index * 41}" font-family="Noto Sans" font-size="${index === 0 ? 30 : 25}" fill="#252c30">${xml(line)}</text>`).join('')}
    <text x="90" y="1480" font-family="Noto Sans" font-size="20" fill="#666">Local scanned evidence copy - page 1</text>
  </svg>`;
  const image = await renderAsync(svg, { font: { loadSystemFonts: false, fontFiles: [fontPath], defaultFontFamily: 'Noto Sans' },
    fitTo: { mode: 'original' }, textRendering: 2 });
  return { ...artifact(image.asPng(), 'image/png', 1), displayName: input.displayName ?? `${input.documentType}-scan.png` };
}

export async function renderScanPdf(input: ScanDocumentInput): Promise<DocumentArtifact> {
  const scan = await renderScanPng(input);
  const document = await PDFDocument.create();
  const instant = new Date(input.asOf);
  if (!Number.isFinite(instant.getTime())) throw new Error('Scan asOf must be a valid instant.');
  document.setCreationDate(instant);
  document.setModificationDate(instant);
  document.setTitle(input.title);
  document.setProducer('Synthetic financial scan generator v1');
  document.setCreator('Synthetic financial scan generator v1');
  const page = document.addPage([pageWidth, pageHeight]);
  const image = await document.embedPng(scan.bytes);
  page.drawImage(image, { x: 0, y: 0, width: pageWidth, height: pageHeight });
  if (input.embeddedTranscript !== undefined) {
    requireText(input.embeddedTranscript, 'Embedded transcript', 3000);
    requireGlyphs(input.embeddedTranscript);
    document.registerFontkit(fontkit);
    const font = await document.embedFont(fontBytes, { subset: true });
    for (const [index, line] of wrap(input.embeddedTranscript, font, 10, pageWidth - 2 * margin).entries()) {
      if (index > 40) throw new Error('Embedded transcript exceeds page bounds.');
      page.drawText(line, { x: margin, y: pageHeight - margin - index * 14, size: 10, font, opacity: 0 });
    }
  }
  page.setRotation(degrees(input.rotation ?? 0));
  return { ...artifact(await document.save({ useObjectStreams: false }), 'application/pdf', 1),
    displayName: input.displayName ?? `${input.documentType}-scan.pdf` };
}
