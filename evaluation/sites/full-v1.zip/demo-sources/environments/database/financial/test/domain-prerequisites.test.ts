import { DatabaseSync } from 'node:sqlite';
import { describe, expect, it } from 'vitest';

import type { DatasetId, InstitutionId } from '../src/model.js';
import { createSchema } from '../src/schema.js';
import { seedCore } from '../src/seed/core.js';
import { seedFinancialDomains } from '../src/seed/financial.js';
import { createSeedRandom } from '../src/seed/random.js';

describe('financial command prerequisites', () => {
  it('seeds prospective waivers, effective-date history, and quantified beneficial ownership', () => {
    using database = new DatabaseSync(':memory:');
    createSchema(database);
    database.prepare('INSERT INTO institutions VALUES (?,?,?,?,?,?)').run('northstar', 'Northstar Cooperative', 'Northstar', 'US', 'America/Chicago', 'USD');
    database.prepare('INSERT INTO datasets (id,institution_id,name,seed,scale,as_of,generator_version,schema_version,revision) VALUES (?,?,?,?,?,?,?,?,?)')
      .run('prerequisites', 'northstar', 'prerequisites', 42, 'small', '2026-09-14T15:00:00.000Z', '1', 1, 0);
    const context = { database, binding: { institutionId: 'northstar' as InstitutionId, datasetId: 'prerequisites' as DatasetId },
      institution: { id: 'northstar', legalName: 'Northstar Cooperative', displayName: 'Northstar', timeZone: 'America/Chicago', defaultCurrency: 'USD' as const },
      scale: 'small' as const, profile: { membersPerInstitution: 48, organizationsPerInstitution: 4, historyMonths: 18, ordinaryJournalTransactionsPerAccount: 20 },
      seed: 42, asOf: '2026-09-14T15:00:00.000Z', random: createSeedRandom(42),
      id: (kind: string, ordinal: number | string): string => `${kind}-${ordinal}`,
      businessNumber: (prefix: string, ordinal: number, width = 6): string => `${prefix}-${ordinal.toString().padStart(width, '0')}` };
    const refs = seedCore(context);
    seedFinancialDomains(context, refs);

    const waiver = database.prepare(`SELECT w.*,f.id AS assessed_fee FROM fee_waivers w LEFT JOIN fees f
      ON f.dataset_id=w.dataset_id AND f.id=w.fee_id WHERE w.state='approved' LIMIT 1`).get();
    expect(waiver?.account_id).toBeTypeOf('string');
    expect(waiver?.fee_code).toBeTypeOf('string');
    expect(waiver?.assessed_fee).toBeNull();
    expect(String(waiver?.valid_from) < String(waiver?.valid_through)).toBe(true);

    const correction = database.prepare(`SELECT c.* FROM effective_date_corrections c JOIN operation_receipts r
      ON r.dataset_id=c.dataset_id AND r.id=c.receipt_id WHERE c.old_effective_date<>c.new_effective_date LIMIT 1`).get();
    expect(correction?.policy_version_id).toBeTypeOf('string');
    expect(String(correction?.policy_period_start) < String(correction?.policy_period_end)).toBe(true);

    const ownership = database.prepare(`SELECT organization_party_id,SUM(ownership_bps) AS total,
      SUM(is_control_person) AS control_people FROM organization_ownership WHERE ends_at IS NULL
      GROUP BY organization_party_id LIMIT 1`).get();
    expect(ownership?.total).toBe(10_000);
    expect(Number(ownership?.control_people)).toBeGreaterThan(0);
    const invalidCardPostings = database.prepare(`SELECT ct.id FROM card_transactions ct JOIN cards c
      ON c.dataset_id=ct.dataset_id AND c.id=ct.card_id JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
      WHERE (ct.state='pending' AND ct.journal_id IS NOT NULL) OR (ct.state='posted' AND NOT EXISTS (
        SELECT 1 FROM journals j JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id
        JOIN ledger_accounts gl ON gl.dataset_id=l.dataset_id AND gl.id=l.ledger_account_id
        WHERE j.dataset_id=ct.dataset_id AND j.id=ct.journal_id AND j.posted_at=ct.occurred_at
          AND gl.customer_account_id=a.id AND l.debit_minor_units=ct.amount_minor_units))`).all();
    expect(invalidCardPostings).toEqual([]);
    const incoherentDisputes = database.prepare(`SELECT d.id FROM disputes d LEFT JOIN dispute_credits c
      ON c.dataset_id=d.dataset_id AND c.dispute_id=d.id WHERE d.state='draft'
      GROUP BY d.id HAVING COUNT(c.id)>0`).all();
    expect(incoherentDisputes).toEqual([]);
    const currentExpiredCards = database.prepare(`SELECT c.id FROM cards c JOIN datasets d ON d.id=c.dataset_id
      WHERE c.status='expired' AND c.expiry_year>=CAST(substr(d.as_of,1,4) AS INTEGER)`).all();
    expect(currentExpiredCards).toEqual([]);
    expect(database.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
  });
});
