import { createHash } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { PDFDocument, StandardFonts } from 'pdf-lib';
import { encode as encodeJpeg } from 'jpeg-js';
import { PNG } from 'pngjs';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding, InstitutionId } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import { MAX_IMAGE_DIMENSION, validateDocumentMedia } from '../src/services/media-validation.js';
import {
  executeCommand,
  communicationJob,
  documentAnnotation,
  isMaintenanceRequestedCommand,
  listMemberDocumentVersions,
  listApprovals,
  maintenanceRequest,
  openFinancialStore,
  resolveMemberIdentity,
  retrieveCustomerExportArtifact,
  retrieveHistoricalStatement,
  servicingCaseDetail,
  type AddressReconcileCommand,
  type CommandOutcome,
  type CustomerExportCreateCommand,
  type FinancialStore,
  type Receipt,
  type ServiceContext,
  type ServicingCommand,
} from '../src/services.js';

let directory: string;
let path: string;
let bindings: readonly DatasetBinding[];
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'financial-servicing-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  bindings = (await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'servicing-foundation-test', scale: 'small' })).bindings;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function clone(institution = 'northstar'): DatasetBinding {
  const source = bindings.find(binding => binding.institutionId === institution);
  if (source === undefined) throw new Error(`Missing ${institution} binding.`);
  using database = openFinancialDatabase({ path });
  return database.cloneDataset(source);
}

function context(binding: DatasetBinding, actorOrdinal = 2, principalKind?: ServiceContext['principalKind']): ServiceContext {
  return { binding, actorId: `${binding.institutionId}-actor-${actorOrdinal}`, reference: 'servicing-foundation-test', ...(principalKind === undefined ? {} : { principalKind }) };
}

function sql<T = Record<string, unknown>>(query: string, ...parameters: (string | number | null)[]): T[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return database.prepare(query).all(...parameters) as T[];
}

function committed(outcome: CommandOutcome): Receipt {
  if (outcome.kind !== 'committed') throw new Error(`Expected commit, received ${JSON.stringify(outcome)}`);
  return outcome.receipt;
}

function approve(binding: DatasetBinding, target: ServicingCommand, key: string): string {
  const policy = sql<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
  if (policy === undefined) throw new Error('No effective approval policy exists.');
  const requested = committed(executeCommand(store, context(binding, 2), {
    kind: 'approval.request', target, checkerActorId: `${binding.institutionId}-actor-5`, policyVersionId: policy.id,
    expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: null,
  }, `svc-approval-request-${key}`));
  const approvalId = requested.affected.find(record => record.kind === 'approval')?.id;
  if (approvalId === undefined) throw new Error('Approval request receipt omitted the approval.');
  const listed = listApprovals(store, context(binding, 5));
  if (listed.kind !== 'found') throw new Error('Approval list was rejected.');
  const approval = listed.approvals.find(item => item.id === approvalId);
  if (approval === undefined) throw new Error('Requested approval was not listed.');
  committed(executeCommand(store, context(binding, 5), {
    kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Exact servicing export inventory reviewed.',
  }, `svc-approval-decide-${key}`));
  return approvalId;
}

async function textPdf(lines: readonly string[]): Promise<Uint8Array> {
  const document = await PDFDocument.create(); const font = await document.embedFont(StandardFonts.Helvetica); const page = document.addPage([612, 792]);
  lines.forEach((line, index) => page.drawText(line, { x: 54, y: 738 - index * 18, size: 11, font }));
  return document.save({ useObjectStreams: false });
}

describe('servicing reads and immutable documents', () => {
  it('preserves identity ambiguity, authorizes the institution boundary, and returns exact historical bytes', () => {
    const binding = clone();
    const duplicateName = sql<{ display_name: string }>(`SELECT p.display_name FROM parties p JOIN members m ON m.dataset_id=p.dataset_id AND m.party_id=p.id
      WHERE p.dataset_id=? GROUP BY p.display_name HAVING COUNT(*)>1 ORDER BY p.display_name LIMIT 1`, binding.datasetId)[0];
    if (duplicateName === undefined) throw new Error('Seed has no ambiguous display name.');
    const before = sql<{ count: number }>('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId)[0]?.count;
    const resolution = store.read(database => resolveMemberIdentity(database, context(binding), { displayName: duplicateName.display_name }));
    expect(resolution).toMatchObject({ kind: 'authorized', value: { resolution: 'ambiguous' } });
    const ambiguousMember = sql<{ member_number: string }>(`SELECT m.member_number FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
      WHERE m.dataset_id=? AND p.display_name=? AND m.status<>'merged' ORDER BY m.member_number LIMIT 1`, binding.datasetId, duplicateName.display_name)[0];
    const uniqueEmail = sql<{ value: string }>(`SELECT cp.value FROM contact_points cp JOIN members m ON m.dataset_id=cp.dataset_id AND m.party_id=cp.party_id
      WHERE cp.dataset_id=? AND cp.kind='email' AND cp.valid_to IS NULL AND m.status<>'merged'
      GROUP BY lower(cp.value) HAVING COUNT(DISTINCT cp.party_id)=1 ORDER BY cp.value LIMIT 1`, binding.datasetId)[0];
    const uniquePhone = sql<{ value: string }>(`SELECT cp.value FROM contact_points cp JOIN members m ON m.dataset_id=cp.dataset_id AND m.party_id=cp.party_id
      WHERE cp.dataset_id=? AND cp.kind='phone' AND cp.valid_to IS NULL AND m.status<>'merged'
      GROUP BY cp.value HAVING COUNT(DISTINCT cp.party_id)=1 ORDER BY cp.value LIMIT 1`, binding.datasetId)[0];
    const uniqueBirthDate = sql<{ birth_date: string }>(`SELECT pe.birth_date FROM people pe JOIN members m ON m.dataset_id=pe.dataset_id AND m.party_id=pe.party_id
      WHERE pe.dataset_id=? AND m.status<>'merged' GROUP BY pe.birth_date HAVING COUNT(*)=1 ORDER BY pe.birth_date LIMIT 1`, binding.datasetId)[0];
    if (ambiguousMember === undefined || uniqueEmail === undefined || uniquePhone === undefined || uniqueBirthDate === undefined) throw new Error('Seed lacks independently resolvable identity criteria.');
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { memberNumber: ambiguousMember.member_number.toLowerCase() })))
      .toMatchObject({ kind: 'authorized', value: { resolution: 'unique' } });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { email: uniqueEmail.value.toUpperCase() })))
      .toMatchObject({ kind: 'authorized', value: { resolution: 'unique' } });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { phone: uniquePhone.value })))
      .toMatchObject({ kind: 'authorized', value: { resolution: 'unique' } });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { birthDate: uniqueBirthDate.birth_date })))
      .toMatchObject({ kind: 'authorized', value: { resolution: 'unique' } });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), {
      displayName: duplicateName.display_name, memberNumber: ambiguousMember.member_number,
    }))).toMatchObject({ kind: 'authorized', value: { resolution: 'unique' } });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { memberNumber: ambiguousMember.member_number }, 500)))
      .toMatchObject({ kind: 'authorized', value: { resolution: 'unique' } });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { memberNumber: ambiguousMember.member_number }, 0)))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { memberNumber: ambiguousMember.member_number }, 501)))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), {}))).toMatchObject({ kind: 'rejected', code: 'validation' });
    const invalidResolution = (criteria: unknown) => store.read(database => resolveMemberIdentity(database, context(binding), criteria as never));
    expect(invalidResolution(null)).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(invalidResolution([])).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(invalidResolution({ unexpected: 'value' })).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(invalidResolution({ displayName: duplicateName.display_name, email: 5 })).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(store.read(database => resolveMemberIdentity(database, context(binding), { displayName: duplicateName.display_name }, 1))).toMatchObject({ kind: 'rejected', code: 'limit_exceeded' });
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId)[0]?.count).toBe(before);
    const wrongInstitution = { ...context(binding), binding: { ...binding, institutionId: 'riverton' as InstitutionId } };
    expect(store.read(database => resolveMemberIdentity(database, wrongInstitution, { displayName: duplicateName.display_name }))).toMatchObject({ kind: 'rejected', code: 'not_authorized' });

    const statement = sql<{ version_id: string; document_id: string; version: number; account_id: string; period_start: string; period_end: string; digest: string }>(`SELECT v.id AS version_id,v.document_id,v.version,d.account_id,v.period_start,v.period_end,v.digest FROM document_versions v
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id WHERE v.dataset_id=? AND d.document_type='account-statement'
      AND v.period_start IS NOT NULL AND v.period_end IS NOT NULL ORDER BY v.id LIMIT 1`, binding.datasetId)[0];
    if (statement === undefined) throw new Error('Seed has no historical statement fixture.');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare("UPDATE document_versions SET status='superseded' WHERE dataset_id=? AND id=?").run(binding.datasetId, statement.version_id);
    const retrieved = store.read(database => retrieveHistoricalStatement(database, context(binding), statement.account_id, statement.period_start, statement.period_end, 'application/pdf'));
    if (retrieved.kind !== 'authorized' || retrieved.value === undefined) throw new Error('Historical statement retrieval failed.');
    expect(retrieved.value.status).toBe('superseded');
    expect(createHash('sha256').update(retrieved.value.bytes).digest('hex')).toBe(statement.digest);
    expect(retrieved.value.byteLength).toBe(retrieved.value.bytes.byteLength);
    expect(store.read(database => retrieveHistoricalStatement(database, context(binding), statement.account_id, 'not-a-period', statement.period_end)))
      .toEqual({ kind: 'authorized', value: undefined });
    const csvBytes = Buffer.from('date,description,amount\n2026-01-02,Opening,100.00\n');
    const csvDigest = createHash('sha256').update(csvBytes).digest('hex');
    fixtureDatabase.prepare("INSERT INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'text/csv',?,?)")
      .run(binding.datasetId, csvDigest, csvBytes.byteLength, csvBytes);
    fixtureDatabase.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,?,?,'text/csv','2026-09-14T15:00:00.000Z',?,?,NULL,'current')`)
      .run(binding.datasetId, 'historical-statement-csv-v2', statement.document_id, statement.version + 1, csvDigest, statement.period_start, statement.period_end);
    const csvRetrieved = store.read(database => retrieveHistoricalStatement(database, context(binding), statement.account_id, statement.period_start, statement.period_end, 'text/csv'));
    expect(csvRetrieved).toMatchObject({ kind: 'authorized', value: { versionId: 'historical-statement-csv-v2', mediaType: 'text/csv', digest: csvDigest } });
    expect(store.read(database => retrieveHistoricalStatement(database, context(binding), statement.account_id, statement.period_start, statement.period_end, 'application/pdf')))
      .toMatchObject({ kind: 'authorized', value: { versionId: statement.version_id, mediaType: 'application/pdf' } });
    const restrictedCase = sql<{ id: string }>("SELECT id FROM cases WHERE dataset_id=? ORDER BY id LIMIT 1", binding.datasetId)[0];
    if (restrictedCase === undefined) throw new Error('Restricted statement case fixture is missing.');
    fixtureDatabase.prepare("INSERT INTO case_documents (dataset_id,case_id,document_version_id,purpose,visibility) VALUES (?,?,?,'statement-review','restricted')")
      .run(binding.datasetId, restrictedCase.id, statement.version_id);
    expect(store.read(database => retrieveHistoricalStatement(database, context(binding, 1), statement.account_id, statement.period_start, statement.period_end, 'application/pdf')))
      .toEqual({ kind: 'authorized', value: undefined });
    expect(store.read(database => retrieveHistoricalStatement(database, context(binding, 2), statement.account_id, statement.period_start, statement.period_end, 'application/pdf')))
      .toMatchObject({ kind: 'authorized', value: { versionId: statement.version_id } });
  });

  it('decodes bounded media, rejects malformed indexing, and creates source-derived redaction bytes', async () => {
    const binding = clone();
    const owner = sql<{ member_id: string; party_id: string; account_id: string }>(`SELECT m.id AS member_id,m.party_id,a.id AS account_id FROM members m
      JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id WHERE m.dataset_id=? ORDER BY m.id,a.id LIMIT 1`, binding.datasetId)[0];
    if (owner === undefined) throw new Error('Document owner fixture is missing.');
    const approvedExcerpt = 'Approved evidence confirms the requested servicing action.'; const secret = 'PROTECTED-IDENTIFIER-8811'; const bytes = await textPdf([approvedExcerpt, secret]);
    const command = { kind: 'document.index' as const, memberId: owner.member_id, ownerPartyId: owner.party_id, accountId: owner.account_id,
      documentId: 'servicing-source-a', documentType: 'servicing-upload', displayName: 'evidence.pdf', retentionClass: 'servicing-7y',
      bytes, mediaType: 'application/pdf', pageCount: 1, source: 'approved-local-source' };
    const first = committed(executeCommand(store, context(binding), command, 'servicing-index-0001'));
    expect(executeCommand(store, context(binding), command, 'servicing-index-0001')).toEqual({ kind: 'duplicate', receipt: first });
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-source-b' }, 'servicing-index-0002')).toMatchObject({ kind: 'unchanged' });
    const contentDigest = createHash('sha256').update(bytes).digest('hex');
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM document_blobs WHERE dataset_id=? AND digest=?', binding.datasetId, contentDigest)).toEqual([{ count: 1 }]);
    expect(sql('SELECT page_count FROM document_versions WHERE dataset_id=? AND id=?', binding.datasetId, 'servicing-source-a-v1')).toEqual([{ page_count: 1 }]);
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-invalid', bytes: Buffer.from('not a pdf') }, 'servicing-index-0003')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'mediaType' });
    const markerOnlyPdf = Buffer.from('%PDF-1.7\nThis is not a PDF document.\n%%EOF\n');
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-marker-pdf', bytes: markerOnlyPdf }, 'servicing-index-pdf-mark')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'mediaType' });
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-page-mismatch', pageCount: 2 }, 'servicing-index-pdf-page')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'pageCount' });
    expect(sql<{ count: number }>(`SELECT COUNT(*) AS count FROM operations WHERE dataset_id=? AND idempotency_key IN ('servicing-index-pdf-mark','servicing-index-pdf-page')`, binding.datasetId)).toEqual([{ count: 0 }]);

    const policy = sql<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
    if (policy === undefined) throw new Error('Redaction policy fixture is missing.');
    const sourceVersionId = first.affected.find(record => record.kind === 'document-version')?.id ?? '';
    using policyDatabase = new DatabaseSync(path);
    policyDatabase.prepare('UPDATE policy_versions SET rules_json=? WHERE dataset_id=? AND id=?').run('{}', binding.datasetId, policy.id);
    const redact = (approvedExcerpts: readonly { sourceVersionId: string; text: string }[]) => ({ kind: 'document.bundle.redact' as const, memberId: owner.member_id,
      sourceVersionIds: [sourceVersionId], recipientPurpose: 'case evidence disclosure', redactionPolicyVersionId: policy.id, approvedExcerpts });
    expect(executeCommand(store, context(binding), redact([{ sourceVersionId, text: approvedExcerpt }]), 'servicing-redact-policy')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    policyDatabase.prepare('UPDATE policy_versions SET rules_json=? WHERE dataset_id=? AND id=?').run(JSON.stringify({ redaction: { enabled: true, maxExcerpts: 32, maxExcerptChars: 300, denyPatterns: [] } }), binding.datasetId, policy.id);
    expect(executeCommand(store, context(binding), redact([{ sourceVersionId, text: 'Text absent from the source.' }]), 'servicing-redact-absent')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding), redact([{ sourceVersionId, text: secret }]), 'servicing-redact-protected')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    const pngImage = new PNG({ width: 2, height: 1 });
    pngImage.data.set([12, 34, 56, 255, 78, 90, 123, 255]);
    const png = PNG.sync.write(pngImage);
    expect(validateDocumentMedia(png, 'image/png')).toEqual({ valid: true, dimensions: { width: 2, height: 1 } });
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-image-header',
      bytes: Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), mediaType: 'image/png' }, 'servicing-index-png-head')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'mediaType' });
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-image-truncated',
      bytes: png.subarray(0, png.byteLength - 4), mediaType: 'image/png' }, 'servicing-index-png-trunc')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'mediaType' });
    const oversizedPng = Buffer.from(png); oversizedPng.writeUInt32BE(MAX_IMAGE_DIMENSION + 1, 16);
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-image-oversized',
      bytes: oversizedPng, mediaType: 'image/png' }, 'servicing-index-png-size')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'mediaType' });
    const imageReceipt = committed(executeCommand(store, context(binding), { ...command, documentId: 'servicing-image', bytes: png, mediaType: 'image/png' }, 'servicing-index-image'));
    const imageVersionId = imageReceipt.affected.find(record => record.kind === 'document-version')?.id ?? '';
    expect(executeCommand(store, context(binding), { ...redact([{ sourceVersionId: imageVersionId, text: approvedExcerpt }]), sourceVersionIds: [imageVersionId] }, 'servicing-redact-image')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    const jpeg = encodeJpeg({ width: 2, height: 1, data: Buffer.from([12, 34, 56, 255, 78, 90, 123, 255]) }, 85).data;
    expect(validateDocumentMedia(jpeg, 'image/jpeg')).toEqual({ valid: true, dimensions: { width: 2, height: 1 } });
    committed(executeCommand(store, context(binding), { ...command, documentId: 'servicing-jpeg', bytes: jpeg, mediaType: 'image/jpeg' }, 'servicing-index-jpeg'));
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-jpeg-markers',
      bytes: Uint8Array.from([0xff, 0xd8, 0xff, 0xd9]), mediaType: 'image/jpeg' }, 'servicing-index-jpeg-mark')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'mediaType' });
    expect(executeCommand(store, context(binding), { ...command, documentId: 'servicing-jpeg-truncated',
      bytes: jpeg.subarray(0, jpeg.byteLength - 2), mediaType: 'image/jpeg' }, 'servicing-index-jpeg-trunc')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'mediaType' });
    const redacted = committed(executeCommand(store, context(binding), { kind: 'document.bundle.redact', memberId: owner.member_id,
      sourceVersionIds: [sourceVersionId], recipientPurpose: 'case evidence disclosure', redactionPolicyVersionId: policy.id,
      approvedExcerpts: [{ sourceVersionId, text: approvedExcerpt }] }, 'servicing-redact-0001'));
    const derivative = redacted.affected.find(record => record.kind === 'document-version')?.id ?? '';
    const artifact = sql<{ bytes: Uint8Array; digest: string }>(`SELECT b.bytes,b.digest FROM document_versions v JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      WHERE v.dataset_id=? AND v.id=?`, binding.datasetId, derivative)[0];
    if (artifact === undefined) throw new Error('Redacted artifact is missing.');
    expect(Buffer.from(artifact.bytes).toString('utf8')).toContain(approvedExcerpt);
    expect(Buffer.from(artifact.bytes).toString('utf8')).not.toContain(secret);
    expect(artifact.digest).not.toBe(contentDigest);
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM document_derivations WHERE dataset_id=? AND source_version_id=? AND derivative_version_id=?', binding.datasetId, sourceVersionId, derivative)).toEqual([{ count: 1 }]);
    expect(executeCommand(store, context(binding), { kind: 'document.bundle.redact', memberId: owner.member_id,
      sourceVersionIds: [sourceVersionId, sourceVersionId], recipientPurpose: 'case evidence disclosure', redactionPolicyVersionId: policy.id,
      approvedExcerpts: [{ sourceVersionId, text: approvedExcerpt }] }, 'servicing-redact-duplicate-source')).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding), { kind: 'document.bundle.redact', memberId: owner.member_id,
      sourceVersionIds: [sourceVersionId], recipientPurpose: 'case evidence disclosure', redactionPolicyVersionId: policy.id,
      approvedExcerpts: [{ sourceVersionId: 'outside-source-inventory', text: approvedExcerpt }] }, 'servicing-redact-wrong-source')).toMatchObject({ kind: 'rejected', code: 'validation' });
    const sourceIds = [sourceVersionId];
    for (let index = 2; index <= 20; index += 1) {
      const documentId = `servicing-redaction-source-${index}`; const versionId = `${documentId}-v1`;
      policyDatabase.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
        VALUES (?,?,?,?,?,?,?,'2026-09-14T15:00:00.000Z')`)
        .run(binding.datasetId, documentId, owner.party_id, owner.account_id, 'servicing-upload', `evidence-${index}.pdf`, 'servicing-7y');
      policyDatabase.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
        VALUES (?,?,?,1,?,'application/pdf','2026-09-14T15:00:00.000Z',NULL,NULL,1,'current')`)
        .run(binding.datasetId, versionId, documentId, contentDigest);
      sourceIds.push(versionId);
    }
    committed(executeCommand(store, context(binding), { kind: 'document.bundle.redact', memberId: owner.member_id,
      sourceVersionIds: sourceIds, recipientPurpose: 'case evidence disclosure', redactionPolicyVersionId: policy.id,
      approvedExcerpts: sourceIds.map(id => ({ sourceVersionId: id, text: approvedExcerpt })) }, 'servicing-redact-twenty-sources'));
    expect(executeCommand(store, context(binding), { kind: 'document.bundle.redact', memberId: owner.member_id,
      sourceVersionIds: [...sourceIds, 'source-over-limit'], recipientPurpose: 'case evidence disclosure', redactionPolicyVersionId: policy.id,
      approvedExcerpts: sourceIds.map(id => ({ sourceVersionId: id, text: approvedExcerpt })) }, 'servicing-redact-over-limit')).toMatchObject({ kind: 'rejected', code: 'validation' });
  });

  it('bounds servicing reads and withholds restricted case documents from general readers', () => {
    const binding = clone();
    const restricted = sql<{ case_id: string; member_id: string; version_id: string }>(`SELECT cd.case_id,c.member_id,cd.document_version_id AS version_id FROM case_documents cd
      JOIN cases c ON c.dataset_id=cd.dataset_id AND c.id=cd.case_id WHERE cd.dataset_id=? AND cd.visibility='restricted' ORDER BY cd.case_id LIMIT 1`, binding.datasetId)[0];
    if (restricted === undefined) throw new Error('Restricted servicing fixture is missing.');
    const viewerDocuments = store.read(database => listMemberDocumentVersions(database, context(binding, 1), restricted.member_id));
    if (viewerDocuments.kind !== 'authorized') throw new Error('General document list was rejected.');
    expect(viewerDocuments.value.map(item => item.versionId)).not.toContain(restricted.version_id);
    const privilegedDocuments = store.read(database => listMemberDocumentVersions(database, context(binding, 2), restricted.member_id));
    if (privilegedDocuments.kind !== 'authorized') throw new Error('Privileged document list was rejected.');
    expect(privilegedDocuments.value.map(item => item.versionId)).toContain(restricted.version_id);
    expect(store.read(database => listMemberDocumentVersions(database, context(binding, 2), restricted.member_id, undefined, 1))).toMatchObject({ kind: 'rejected', code: 'limit_exceeded' });
    expect(store.read(database => servicingCaseDetail(database, context(binding, 1), restricted.case_id))).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    expect(store.read(database => servicingCaseDetail(database, context(binding, 2), restricted.case_id))).toMatchObject({ kind: 'authorized' });
  });
});

describe('servicing write lifecycles', () => {
  it('registers an immutable identity document before recording verification', async () => {
    const binding = clone();
    const owner = sql<{ member_id: string; party_id: string; account_id: string }>(`SELECT m.id AS member_id,m.party_id,a.id AS account_id FROM members m
      JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id WHERE m.dataset_id=? ORDER BY m.id,a.id LIMIT 1`, binding.datasetId)[0];
    if (owner === undefined) throw new Error('Identity document owner fixture is missing.');
    const bytes = await textPdf(['Synthetic passport evidence', `Member party: ${owner.party_id}`]);
    const indexed = committed(executeCommand(store, context(binding), { kind: 'document.index', memberId: owner.member_id, ownerPartyId: owner.party_id,
      accountId: owner.account_id, documentId: 'onboarding-identity-document', documentType: 'identity-document', displayName: 'passport.pdf',
      retentionClass: 'identity-7y', bytes, mediaType: 'application/pdf', pageCount: 1, source: 'approved-local-scan' }, 'identity-document-index'));
    const documentVersionId = indexed.affected.find(record => record.kind === 'document-version')?.id ?? '';
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare(`INSERT INTO identity_evidence
      (dataset_id,id,party_id,kind,status,issued_at,expires_at,reference) VALUES (?,?,?,?,?,?,?,?)`)
      .run(binding.datasetId, 'legacy-unbound-identity-evidence', owner.party_id, 'passport', 'unverified', '2024-01-10', '2034-01-10', 'LEGACY-PASSPORT-001');
    expect(executeCommand(store, context(binding), { kind: 'member.identity.verify', memberId: owner.member_id,
      evidenceId: 'legacy-unbound-identity-evidence', method: 'approved-local-document-review' }, 'legacy-identity-evidence-verify'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    const typedBytes = await textPdf(['Synthetic typed passport evidence', `Member party: ${owner.party_id}`]);
    const typed = committed(executeCommand(store, context(binding), { kind: 'document.index', memberId: owner.member_id, ownerPartyId: owner.party_id,
      accountId: owner.account_id, documentId: 'typed-passport-document', documentType: 'passport', displayName: 'typed-passport.pdf',
      retentionClass: 'identity-7y', bytes: typedBytes, mediaType: 'application/pdf', pageCount: 1, source: 'approved-local-scan' }, 'typed-passport-index'));
    const typedVersionId = typed.affected.find(record => record.kind === 'document-version')?.id ?? '';
    expect(executeCommand(store, context(binding), { kind: 'member.identity_evidence.register', memberId: owner.member_id,
      documentVersionId: typedVersionId, evidenceId: 'mismatched-typed-evidence', evidenceKind: 'drivers-license', issuedAt: '2024-01-10',
      expiresAt: '2034-01-10', reference: 'SYNTH-LICENSE-001' }, 'mismatched-typed-evidence-register'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    const registered = committed(executeCommand(store, context(binding), { kind: 'member.identity_evidence.register', memberId: owner.member_id,
      documentVersionId, evidenceId: 'onboarding-identity-evidence', evidenceKind: 'passport', issuedAt: '2024-01-10', expiresAt: '2034-01-10', reference: 'SYNTH-PASSPORT-001' }, 'identity-evidence-register'));
    expect(registered.result).toMatchObject({ evidenceId: 'onboarding-identity-evidence', documentVersionId, status: 'unverified' });
    const contentDigest = createHash('sha256').update(bytes).digest('hex');
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=zeroblob(byte_length) WHERE dataset_id=? AND digest=?').run(binding.datasetId, contentDigest);
    expect(executeCommand(store, context(binding), { kind: 'member.identity.verify', memberId: owner.member_id,
      evidenceId: 'onboarding-identity-evidence', method: 'approved-local-document-review' }, 'corrupt-identity-evidence-verify'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=? WHERE dataset_id=? AND digest=?').run(bytes, binding.datasetId, contentDigest);
    fixtureDatabase.prepare("UPDATE document_blobs SET media_type='image/png' WHERE dataset_id=? AND digest=?").run(binding.datasetId, contentDigest);
    fixtureDatabase.prepare("UPDATE document_versions SET media_type='image/png' WHERE dataset_id=? AND id=?").run(binding.datasetId, documentVersionId);
    expect(executeCommand(store, context(binding), { kind: 'member.identity.verify', memberId: owner.member_id,
      evidenceId: 'onboarding-identity-evidence', method: 'approved-local-document-review' }, 'unreadable-identity-evidence-verify'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE document_blobs SET media_type='application/pdf' WHERE dataset_id=? AND digest=?").run(binding.datasetId, contentDigest);
    fixtureDatabase.prepare("UPDATE document_versions SET media_type='application/pdf' WHERE dataset_id=? AND id=?").run(binding.datasetId, documentVersionId);
    committed(executeCommand(store, context(binding), { kind: 'member.identity.verify', memberId: owner.member_id, evidenceId: 'onboarding-identity-evidence', method: 'approved-local-document-review' }, 'identity-evidence-verify'));
    expect(sql('SELECT status FROM identity_evidence WHERE dataset_id=? AND id=?', binding.datasetId, 'onboarding-identity-evidence')).toEqual([{ status: 'verified' }]);
    expect(executeCommand(store, context(binding), { kind: 'member.identity.verify', memberId: owner.member_id,
      evidenceId: 'onboarding-identity-evidence', method: 'approved-local-document-review' }, 'identity-evidence-already-verified'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });

  it('rejects expired and non-authoritative evidence for a legal-name amendment', () => {
    const binding = clone();
    const member = sql<{ member_id: string; party_id: string; version: number; legal_given: string; legal_family: string }>(`SELECT m.id AS member_id,m.party_id,m.version,p.legal_given,p.legal_family FROM members m
      JOIN people p ON p.dataset_id=m.dataset_id AND p.party_id=m.party_id WHERE m.dataset_id=? AND m.status='active' ORDER BY m.id LIMIT 1`, binding.datasetId)[0];
    if (member === undefined) throw new Error('Legal-name member fixture is missing.');
    using fixtureDatabase = new DatabaseSync(path);
    const insertEvidence = fixtureDatabase.prepare(`INSERT INTO identity_evidence
      (dataset_id,id,party_id,kind,status,issued_at,expires_at,reference) VALUES (?,?,?,?,?,?,?,?)`);
    insertEvidence.run(binding.datasetId, 'expired-legal-name-evidence', member.party_id, 'court-order', 'verified', '2020-01-01', '2025-01-01', 'COURT-EXPIRED');
    insertEvidence.run(binding.datasetId, 'preferred-name-only-evidence', member.party_id, 'preferred-name-request', 'verified', '2026-09-01', null, 'PREFERRED-ONLY');
    const command = (evidenceId: string) => ({ kind: 'member.legal_name.update' as const, memberId: member.member_id, expectedVersion: member.version,
      legalGiven: 'Authorized', legalFamily: 'Name', evidenceId, approvalId: 'unused-because-evidence-must-fail-first' });
    expect(executeCommand(store, context(binding, 5), command('expired-legal-name-evidence'), 'legal-name-expired-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding, 5), command('preferred-name-only-evidence'), 'legal-name-preference-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    for (const evidenceKind of ['marriage-certificate', 'divorce-decree', 'passport', 'drivers-license', 'national-id', 'state-id']) {
      const evidenceId = `legal-name-authority-${evidenceKind}`;
      insertEvidence.run(binding.datasetId, evidenceId, member.party_id, evidenceKind, 'verified', '2026-09-01', null, `AUTHORITY-${evidenceKind}`);
      expect(executeCommand(store, context(binding, 5), { kind: 'member.legal_name.update', memberId: member.member_id, expectedVersion: member.version,
        legalGiven: member.legal_given, legalFamily: member.legal_family, evidenceId, approvalId: 'not-needed-for-unchanged-name' }, `legal-name-authority-${evidenceKind}`))
        .toMatchObject({ kind: 'unchanged' });
    }
  });

  it('amends an approved legal name while keeping preferred-name changes separate', () => {
    const binding = clone();
    const member = sql<{ member_id: string; party_id: string; version: number; preferred_name: string | null; preferred_name_scope: string | null }>(`SELECT m.id AS member_id,m.party_id,m.version,p.preferred_name,p.preferred_name_scope FROM members m
      JOIN people p ON p.dataset_id=m.dataset_id AND p.party_id=m.party_id WHERE m.dataset_id=? AND m.status='active' ORDER BY m.id LIMIT 1`, binding.datasetId)[0];
    if (member === undefined) throw new Error('Legal-name member fixture is missing.');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare(`INSERT INTO identity_evidence
      (dataset_id,id,party_id,kind,status,issued_at,expires_at,reference) VALUES (?,?,?,?,?,?,?,?)`)
      .run(binding.datasetId, 'current-legal-name-evidence', member.party_id, 'court-order', 'verified', '2026-09-01', null, 'COURT-CURRENT');
    const target = { kind: 'member.legal_name.update' as const, memberId: member.member_id, expectedVersion: member.version,
      legalGiven: 'Authorized', legalFamily: 'Name', evidenceId: 'current-legal-name-evidence', approvalId: 'pending-approval-id' };
    const approvalId = approve(binding, target, 'legal-name-amendment');
    fixtureDatabase.prepare("UPDATE identity_evidence SET status='contradictory' WHERE dataset_id=? AND id=?").run(binding.datasetId, target.evidenceId);
    expect(executeCommand(store, context(binding, 5), { ...target, approvalId }, 'legal-name-evidence-changed-after-approval'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE identity_evidence SET status='verified' WHERE dataset_id=? AND id=?").run(binding.datasetId, target.evidenceId);
    const amended = committed(executeCommand(store, context(binding, 5), { ...target, approvalId }, 'legal-name-amendment'));
    expect(amended.result).toMatchObject({ memberId: member.member_id, displayName: 'Authorized Name' });
    expect(sql('SELECT legal_given,legal_family,preferred_name,preferred_name_scope FROM people WHERE dataset_id=? AND party_id=?', binding.datasetId, member.party_id))
      .toEqual([{ legal_given: 'Authorized', legal_family: 'Name', preferred_name: member.preferred_name, preferred_name_scope: member.preferred_name_scope }]);
    expect(sql('SELECT kind,given_name,family_name,valid_to,evidence_id FROM name_history WHERE dataset_id=? AND party_id=? ORDER BY valid_from DESC', binding.datasetId, member.party_id)[0])
      .toMatchObject({ kind: 'legal', given_name: 'Authorized', family_name: 'Name', valid_to: null, evidence_id: 'current-legal-name-evidence' });
    const preferred = committed(executeCommand(store, context(binding), { kind: 'member.preferred_name.update', memberId: member.member_id,
      expectedVersion: member.version + 1, preferredName: 'Service Name', communicationScope: 'communications' }, 'preferred-name-set'));
    expect(preferred.result).toMatchObject({ memberId: member.member_id, preferredName: 'Service Name', communicationScope: 'communications' });
    expect(sql('SELECT preferred_name,preferred_name_scope FROM people WHERE dataset_id=? AND party_id=?', binding.datasetId, member.party_id))
      .toEqual([{ preferred_name: 'Service Name', preferred_name_scope: 'communications' }]);
    expect(executeCommand(store, context(binding), { kind: 'member.preferred_name.update', memberId: member.member_id,
      expectedVersion: member.version + 2, preferredName: 'Service Name', communicationScope: 'communications' }, 'preferred-name-unchanged'))
      .toMatchObject({ kind: 'unchanged' });
    expect(executeCommand(store, context(binding), { kind: 'member.preferred_name.update', memberId: member.member_id,
      expectedVersion: member.version + 1, preferredName: 'Stale Name', communicationScope: 'servicing' }, 'preferred-name-stale'))
      .toMatchObject({ kind: 'rejected', code: 'stale_version' });
    expect(executeCommand(store, context(binding), { kind: 'member.preferred_name.update', memberId: member.member_id,
      expectedVersion: member.version + 2, preferredName: 'x'.repeat(61), communicationScope: 'servicing' }, 'preferred-name-too-long'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    committed(executeCommand(store, context(binding), { kind: 'member.preferred_name.update', memberId: member.member_id,
      expectedVersion: member.version + 2, preferredName: 'Service Name', communicationScope: 'servicing' }, 'preferred-name-servicing-scope'));
    expect(sql('SELECT preferred_name,preferred_name_scope FROM people WHERE dataset_id=? AND party_id=?', binding.datasetId, member.party_id))
      .toEqual([{ preferred_name: 'Service Name', preferred_name_scope: 'servicing' }]);
    committed(executeCommand(store, context(binding), { kind: 'member.preferred_name.update', memberId: member.member_id,
      expectedVersion: member.version + 3, preferredName: 'Service Name', communicationScope: 'all' }, 'preferred-name-all-scope'));
    expect(sql('SELECT preferred_name,preferred_name_scope FROM people WHERE dataset_id=? AND party_id=?', binding.datasetId, member.party_id))
      .toEqual([{ preferred_name: 'Service Name', preferred_name_scope: 'all' }]);
    committed(executeCommand(store, context(binding), { kind: 'member.preferred_name.update', memberId: member.member_id,
      expectedVersion: member.version + 4, preferredName: null, communicationScope: 'all' }, 'preferred-name-clear'));
    expect(sql('SELECT legal_given,legal_family,preferred_name,preferred_name_scope FROM people WHERE dataset_id=? AND party_id=?', binding.datasetId, member.party_id))
      .toEqual([{ legal_given: 'Authorized', legal_family: 'Name', preferred_name: null, preferred_name_scope: null }]);
  });

  it('uses an exact communication preference without changing legal consent', () => {
    const binding = clone();
    const fixture = sql<{ party_id: string; destination: string; notice_id: string }>(`SELECT m.party_id,cp.value AS destination,v.id AS notice_id FROM members m
      JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='servicing-notice'
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status<>'superseded'
      WHERE m.dataset_id=? ORDER BY m.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Communication preference fixture is missing.');
    const consentCount = sql<{ count: number }>('SELECT COUNT(*) AS count FROM consents WHERE dataset_id=?', binding.datasetId)[0]?.count;
    const preference = { kind: 'communication.preference.update' as const, partyId: fixture.party_id,
      purpose: 'optional-product-updates', channel: 'email', state: 'enabled' as const };
    expect(committed(executeCommand(store, context(binding), preference, 'optional-preference-enable')).result)
      .toMatchObject({ partyId: fixture.party_id, purpose: preference.purpose, channel: 'email', state: 'enabled', legalConsentChanged: false });
    const send = { kind: 'communication.send' as const, partyId: fixture.party_id, channel: 'email', destination: fixture.destination,
      purpose: preference.purpose, documentVersionId: fixture.notice_id, jobId: 'optional-product-update-job' };
    expect(committed(executeCommand(store, context(binding), send, 'optional-product-update-send')).result)
      .toMatchObject({ jobId: send.jobId, versionId: fixture.notice_id, state: 'queued', delivered: false });
    committed(executeCommand(store, context(binding), { ...preference, state: 'disabled' }, 'optional-preference-disable'));
    expect(executeCommand(store, context(binding), { ...send, jobId: 'blocked-optional-product-update-job' }, 'optional-product-update-blocked'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM consents WHERE dataset_id=?', binding.datasetId)[0]?.count).toBe(consentCount);
  });

  it('qualifies unchanged and invalid communication-preference updates', () => {
    const binding = clone();
    const party = sql<{ id: string }>('SELECT id FROM parties WHERE dataset_id=? ORDER BY id LIMIT 1', binding.datasetId)[0];
    if (party === undefined) throw new Error('Communication-preference party fixture is missing.');
    const preference = { kind: 'communication.preference.update' as const, partyId: party.id, purpose: 'service-research', channel: 'email', state: 'enabled' as const };
    committed(executeCommand(store, context(binding), preference, 'preference-create-missing'));
    expect(executeCommand(store, context(binding), preference, 'preference-unchanged')).toMatchObject({ kind: 'unchanged' });
    expect(executeCommand(store, context(binding), { ...preference, partyId: 'missing-party-id' }, 'preference-missing-party'))
      .toMatchObject({ kind: 'rejected', code: 'not_found' });
    expect(executeCommand(store, context(binding), { ...preference, purpose: '   ' }, 'preference-blank-purpose'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding), { ...preference, channel: '' }, 'preference-blank-channel'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
  });

  it('queues every exempt notice purpose and rejects invalid local send options', () => {
    const binding = clone();
    const fixture = sql<{ party_id: string; destination: string; notice_id: string }>(`SELECT m.party_id,cp.value AS destination,v.id AS notice_id FROM members m
      JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='servicing-notice'
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status IN ('current','signed')
      WHERE m.dataset_id=? ORDER BY m.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Communication-send option fixture is missing.');
    const base = { kind: 'communication.send' as const, partyId: fixture.party_id, channel: 'email', destination: fixture.destination,
      purpose: 'servicing', documentVersionId: fixture.notice_id };
    for (const [index, purpose] of ['servicing', 'required-servicing', 'card-replacement'].entries()) {
      const jobId = `communication-exempt-${index}`;
      expect(committed(executeCommand(store, context(binding), { ...base, purpose, jobId }, `communication-exempt-${index}`)).result)
        .toMatchObject({ jobId, versionId: fixture.notice_id, state: 'queued', delivered: false });
    }
    expect(executeCommand(store, context(binding), { ...base, purpose: 'required-servicing', jobId: 'communication-exempt-0' }, 'communication-job-collision'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding), { ...base, channel: 'sms' }, 'communication-non-email'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding), { ...base, destination: 'wrong-current-contact@example.invalid' }, 'communication-wrong-contact'))
      .toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare("UPDATE document_versions SET status='superseded' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.notice_id);
    expect(executeCommand(store, context(binding), base, 'communication-superseded-document'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });

  it('rejects foreign information-request documents and destinations without queue effects', () => {
    const binding = clone();
    const fixture = sql<{ case_id: string; version: number; party_id: string; destination: string; notice_id: string }>(`SELECT c.id AS case_id,c.version,m.party_id,cp.value AS destination,v.id AS notice_id FROM cases c
      JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id
      JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='servicing-notice'
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status<>'superseded'
      WHERE c.dataset_id=? AND c.state IN ('open','reopened','pending-internal') AND NOT EXISTS
        (SELECT 1 FROM case_dependencies dep WHERE dep.dataset_id=c.dataset_id AND dep.case_id=c.id AND dep.kind='requested-document' AND dep.state='open')
      ORDER BY c.id,v.issued_at DESC LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Information request fixture is missing.');
    const foreign = sql<{ party_id: string; destination: string; notice_id: string }>(`SELECT m.party_id,cp.value AS destination,v.id AS notice_id FROM members m
      JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='servicing-notice'
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status<>'superseded'
      WHERE m.dataset_id=? AND m.party_id<>? ORDER BY m.id LIMIT 1`, binding.datasetId, fixture.party_id)[0];
    if (foreign === undefined) throw new Error('Foreign notice fixture is missing.');
    const before = sql<{ count: number }>('SELECT COUNT(*) AS count FROM communication_jobs WHERE dataset_id=?', binding.datasetId)[0]?.count;
    const base = { kind: 'case.information.request' as const, caseId: fixture.case_id, expectedVersion: fixture.version, fields: ['proof-of-address'],
      recipientPartyId: fixture.party_id, channel: 'email', dueAt: '2026-09-20T15:00:00.000Z' };
    expect(executeCommand(store, context(binding), { ...base, documentVersionId: foreign.notice_id, destination: fixture.destination }, 'info-foreign-document')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    expect(executeCommand(store, context(binding), { ...base, documentVersionId: fixture.notice_id, destination: foreign.destination }, 'info-foreign-destination')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM communication_jobs WHERE dataset_id=?', binding.datasetId)[0]?.count).toBe(before);
    const requested = committed(executeCommand(store, context(binding), { ...base, documentVersionId: fixture.notice_id, destination: fixture.destination }, 'info-request-valid'));
    expect(requested.result).toMatchObject({ caseId: fixture.case_id, caseVersion: fixture.version + 1, deliveryState: 'queued', dueAt: '2026-09-20T15:00:00.000Z' });
    const jobId = typeof requested.result?.jobId === 'string' ? requested.result.jobId : '';
    const dependencyId = typeof requested.result?.dependencyId === 'string' ? requested.result.dependencyId : '';
    expect(sql('SELECT state,destination FROM communication_jobs WHERE dataset_id=? AND id=?', binding.datasetId, jobId)).toEqual([{ state: 'queued', destination: fixture.destination }]);
    expect(sql('SELECT state,due_at FROM case_dependencies WHERE dataset_id=? AND id=?', binding.datasetId, dependencyId)).toEqual([{ state: 'open', due_at: '2026-09-20T15:00:00.000Z' }]);
  });

  it('qualifies explicit and default information-request fields at their boundaries', () => {
    const variants = [
      { explicitDestination: true, explicitDocument: false, fields: ['proof-of-address'] },
      { explicitDestination: false, explicitDocument: true, fields: ['proof-of-identity'] },
      { explicitDestination: false, explicitDocument: false, fields: Array.from({ length: 20 }, (_, index) => `field-${index + 1}`) },
    ] as const;
    for (const [index, variant] of variants.entries()) {
      const binding = clone();
      const fixture = sql<{ case_id: string; version: number; party_id: string; destination: string; notice_id: string }>(`SELECT c.id AS case_id,c.version,m.party_id,cp.value AS destination,v.id AS notice_id FROM cases c
        JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id
        JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
        JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='servicing-notice'
        JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status<>'superseded'
        WHERE c.dataset_id=? AND c.state IN ('open','reopened','pending-internal') AND NOT EXISTS
          (SELECT 1 FROM case_dependencies dep WHERE dep.dataset_id=c.dataset_id AND dep.case_id=c.id AND dep.kind='requested-document' AND dep.state='open')
        ORDER BY c.id,v.issued_at DESC LIMIT 1`, binding.datasetId)[0];
      if (fixture === undefined) throw new Error(`Information-request option fixture ${index} is missing.`);
      const target = { kind: 'case.information.request' as const, caseId: fixture.case_id, expectedVersion: fixture.version, fields: variant.fields,
        recipientPartyId: fixture.party_id, channel: 'email', dueAt: '2026-09-21T15:00:00.000Z',
        ...(variant.explicitDestination ? { destination: fixture.destination } : {}),
        ...(variant.explicitDocument ? { documentVersionId: fixture.notice_id } : {}) };
      if (index === 0) {
        expect(executeCommand(store, context(binding), { ...target, fields: ['duplicate', 'duplicate'] }, 'info-fields-duplicate'))
          .toMatchObject({ kind: 'rejected', code: 'validation' });
        expect(executeCommand(store, context(binding), { ...target, dueAt: '2026-09-14T15:00:00.000Z' }, 'info-due-boundary'))
          .toMatchObject({ kind: 'rejected', code: 'validation' });
      }
      const requested = committed(executeCommand(store, context(binding), target, `info-option-${index}`));
      expect(requested.result).toMatchObject({ caseId: fixture.case_id, deliveryState: 'queued', dueAt: '2026-09-21T15:00:00.000Z' });
    }

    const missingBinding = clone();
    const missing = sql<{ case_id: string; version: number; party_id: string }>(`SELECT c.id AS case_id,c.version,m.party_id FROM cases c
      JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id
      WHERE c.dataset_id=? AND c.state IN ('open','reopened','pending-internal') AND EXISTS
        (SELECT 1 FROM contact_points cp WHERE cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL)
      ORDER BY c.id LIMIT 1`, missingBinding.datasetId)[0];
    if (missing === undefined) throw new Error('Missing-contact information-request fixture is unavailable.');
    using missingDatabase = new DatabaseSync(path);
    missingDatabase.prepare("UPDATE contact_points SET valid_to='2026-09-14T14:59:59.000Z' WHERE dataset_id=? AND party_id=? AND kind='email' AND valid_to IS NULL")
      .run(missingBinding.datasetId, missing.party_id);
    expect(executeCommand(store, context(missingBinding), { kind: 'case.information.request', caseId: missing.case_id, expectedVersion: missing.version,
      fields: ['proof-of-address'], recipientPartyId: missing.party_id, channel: 'email', dueAt: '2026-09-21T15:00:00.000Z' }, 'info-missing-contact'))
      .toMatchObject({ kind: 'rejected', code: 'not_found' });
  });

  it('records signature request and exact verified response as separate states', async () => {
    const binding = clone();
    const fixture = sql<{ target_id: string; target_digest: string; unrelated_evidence_id: string; party_id: string; member_id: string; account_id: string }>(`SELECT target.id AS target_id,target.digest AS target_digest,evidence.id AS unrelated_evidence_id,td.owner_party_id AS party_id,m.id AS member_id,td.account_id
      FROM document_versions target JOIN documents td ON td.dataset_id=target.dataset_id AND td.id=target.document_id
      JOIN members m ON m.dataset_id=td.dataset_id AND m.party_id=td.owner_party_id
      JOIN documents ed ON ed.dataset_id=td.dataset_id AND ed.owner_party_id=td.owner_party_id AND ed.document_type='signature-evidence'
      JOIN document_versions evidence ON evidence.dataset_id=ed.dataset_id AND evidence.document_id=ed.id AND evidence.status='signed'
      WHERE target.dataset_id=? AND td.document_type='servicing-notice' AND target.status='current'
      AND NOT EXISTS (SELECT 1 FROM signatures s WHERE s.dataset_id=target.dataset_id AND s.document_version_id=target.id)
      ORDER BY target.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Signature lifecycle fixture is missing.');
    const evidenceBytes = await textPdf([`Document version: ${fixture.target_id}`, `Document SHA-256: ${fixture.target_digest}`,
      `Signer party: ${fixture.party_id}`, 'Channel: authorized-local-signature', 'Response: signed']);
    const indexedEvidence = committed(executeCommand(store, context(binding, 5, 'system'), { kind: 'document.index', memberId: fixture.member_id, ownerPartyId: fixture.party_id,
      accountId: fixture.account_id, documentId: 'signature-response-evidence', documentType: 'signature-evidence', displayName: 'signature-response.pdf',
      retentionClass: 'servicing-7y', bytes: evidenceBytes, mediaType: 'application/pdf', pageCount: 1, source: 'trusted-local-signature-response' }, 'signature-evidence-0001'));
    const evidenceReference = indexedEvidence.affected.find(record => record.kind === 'document-version')?.id ?? '';
    const response = { kind: 'document.signature.collect' as const, action: 'sign' as const, documentVersionId: fixture.target_id,
      signerPartyIds: [fixture.party_id], channel: 'authorized-local-signature', evidenceReference };
    expect(executeCommand(store, context(binding, 5, 'system'), response, 'signature-direct-0001')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    committed(executeCommand(store, context(binding), { kind: 'document.signature.collect', action: 'request', documentVersionId: fixture.target_id,
      signerPartyIds: [fixture.party_id], channel: 'authorized-local-signature' }, 'signature-request-0001'));
    expect(sql('SELECT status,signed_at,evidence_reference FROM signatures WHERE dataset_id=? AND document_version_id=?', binding.datasetId, fixture.target_id)).toEqual([{ status: 'requested', signed_at: null, evidence_reference: null }]);
    expect(executeCommand(store, context(binding), response, 'signature-human-0001')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    expect(executeCommand(store, context(binding, 5, 'system'), { ...response, evidenceReference: fixture.unrelated_evidence_id }, 'signature-unrelated-0001')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const prefixBytes = await textPdf([`Document version: ${fixture.target_id}`, `Document SHA-256: ${fixture.target_digest}`,
      `Signer party: ${fixture.party_id}1`, 'Channel: authorized-local-signature', 'Response: signed']);
    const prefixReceipt = committed(executeCommand(store, context(binding, 5, 'system'), { kind: 'document.index', memberId: fixture.member_id, ownerPartyId: fixture.party_id,
      accountId: fixture.account_id, documentId: 'signature-prefix-evidence', documentType: 'signature-evidence', displayName: 'signature-prefix.pdf',
      retentionClass: 'servicing-7y', bytes: prefixBytes, mediaType: 'application/pdf', pageCount: 1, source: 'trusted-local-signature-response' }, 'signature-prefix-index'));
    const prefixReference = prefixReceipt.affected.find(record => record.kind === 'document-version')?.id ?? '';
    expect(executeCommand(store, context(binding, 5, 'system'), { ...response, evidenceReference: prefixReference }, 'signature-prefix-response')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    committed(executeCommand(store, context(binding, 5, 'system'), response, 'signature-response-0001'));
    expect(sql<{ status: string; signed_at: string | null; evidence_reference: string | null }>('SELECT status,signed_at,evidence_reference FROM signatures WHERE dataset_id=? AND document_version_id=?', binding.datasetId, fixture.target_id)).toEqual([{ status: 'signed', signed_at: '2026-09-14T15:00:00.000Z', evidence_reference: evidenceReference }]);
    expect(sql('SELECT status FROM document_versions WHERE dataset_id=? AND id=?', binding.datasetId, fixture.target_id)).toEqual([{ status: 'signed' }]);
    expect(sql('SELECT status FROM document_versions WHERE dataset_id=? AND id=?', binding.datasetId, evidenceReference)).toEqual([{ status: 'current' }]);
  });

  it('creates an approved immutable customer export with exact source bytes and access logs', () => {
    const binding = clone();
    const source = sql<{ version_id: string; member_id: string; period_start: string; period_end: string; digest: string }>(`SELECT v.id AS version_id,a.member_id,v.period_start,v.period_end,v.digest
      FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id
      WHERE v.dataset_id=? AND d.document_type='account-statement' AND v.period_start IS NOT NULL AND v.period_end IS NOT NULL ORDER BY v.id LIMIT 1`, binding.datasetId)[0];
    if (source === undefined) throw new Error('Export source fixture is missing.');
    const inclusiveThrough = new Date(Date.parse(`${source.period_end}T00:00:00.000Z`) - 86_400_000).toISOString().slice(0, 10);
    const inventory = sql<{ version_id: string }>(`SELECT v.id AS version_id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id WHERE v.dataset_id=? AND a.member_id=? AND d.document_type='account-statement'
      AND v.period_end>? AND v.period_start<=? ORDER BY v.id`, binding.datasetId, source.member_id, source.period_start, inclusiveThrough).map(item => item.version_id);
    const target: CustomerExportCreateCommand = { kind: 'document.customer_export.create', memberId: source.member_id, categories: ['statements'],
      from: source.period_start, through: inclusiveThrough, destination: 'local-vault', documentVersionIds: inventory, approvalId: 'pending-approval-id' };
    expect(executeCommand(store, context(binding, 5), target, 'export-unapproved-0001')).toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'approvalId' });
    const approvalId = approve(binding, target, source.version_id);
    const receipt = committed(executeCommand(store, context(binding, 5), { ...target, approvalId }, 'export-approved-0001'));
    const artifactVersionId = receipt.affected.find(record => record.kind === 'document-version')?.id;
    if (artifactVersionId === undefined) throw new Error('Export receipt omitted the artifact version.');
    expect(store.read(database => retrieveCustomerExportArtifact(database, context(binding), source.member_id, artifactVersionId))).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const artifact = store.read(database => retrieveCustomerExportArtifact(database, context(binding, 5), source.member_id, artifactVersionId));
    if (artifact.kind !== 'authorized' || artifact.value === undefined) throw new Error('Export artifact retrieval failed.');
    const decoded = JSON.parse(Buffer.from(artifact.value.bytes).toString('utf8')) as { documents: { versionId: string; digest: string; contentBase64: string }[] };
    expect(decoded.documents).toHaveLength(inventory.length);
    const exportedSource = decoded.documents.find(item => item.versionId === source.version_id);
    expect(exportedSource).toMatchObject({ versionId: source.version_id, digest: source.digest });
    expect(createHash('sha256').update(Buffer.from(exportedSource?.contentBase64 ?? '', 'base64')).digest('hex')).toBe(source.digest);
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM document_access_events WHERE dataset_id=? AND document_version_id=? AND action=?', binding.datasetId, source.version_id, 'export')).toEqual([{ count: 1 }]);
    expect(sql('SELECT status FROM business_approvals WHERE dataset_id=? AND id=?', binding.datasetId, approvalId)).toEqual([{ status: 'consumed' }]);
  });

  it('qualifies every customer-export category, destination, nullable date scope, and inventory limit', async () => {
    const binding = clone();
    const categoryTypes = {
      statements: ['account-statement'], disclosures: ['delivery-disclosure'], 'servicing-notices': ['servicing-notice'],
      'servicing-evidence': ['redacted-evidence'], 'signed-evidence': ['signature-evidence'],
    } as const;
    const destinations = ['local-vault', 'approved-local-output', 'approved-local-destination'] as const;
    for (const [index, category] of Object.keys(categoryTypes).entries()) {
      const types = categoryTypes[category as keyof typeof categoryTypes];
      const placeholders = types.map(() => '?').join(',');
      const member = sql<{ member_id: string }>(`SELECT m.id AS member_id FROM members m WHERE m.dataset_id=? AND EXISTS (
        SELECT 1 FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
        WHERE d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type IN (${placeholders})
          AND (d.document_type<>'redacted-evidence' OR EXISTS (SELECT 1 FROM document_derivations dd
            WHERE dd.dataset_id=v.dataset_id AND dd.derivative_version_id=v.id AND dd.purpose='redaction')))
        ORDER BY m.id LIMIT 1`, binding.datasetId, ...types)[0];
      if (member === undefined) throw new Error(`Export category ${category} has no seeded member fixture.`);
      const inventory = sql<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
        JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
        WHERE v.dataset_id=? AND m.id=? AND d.document_type IN (${placeholders})
          AND (d.document_type<>'redacted-evidence' OR EXISTS (SELECT 1 FROM document_derivations dd
            WHERE dd.dataset_id=v.dataset_id AND dd.derivative_version_id=v.id AND dd.purpose='redaction'))
        ORDER BY v.id`, binding.datasetId, member.member_id, ...types).map(row => row.id);
      const target: CustomerExportCreateCommand = { kind: 'document.customer_export.create', memberId: member.member_id, categories: [category],
        from: null, through: null, destination: destinations[index % destinations.length] ?? 'local-vault', documentVersionIds: inventory,
        approvalId: 'pending-approval-id' };
      const approvalId = approve(binding, target, `export-category-${index}`);
      expect(committed(executeCommand(store, context(binding, 5), { ...target, approvalId }, `export-category-${index}`)).result)
        .toMatchObject({ categories: [category], destination: target.destination, from: null, through: null });
    }

    const statement = sql<{ member_id: string; period_start: string; period_end: string }>(`SELECT m.id AS member_id,v.period_start,v.period_end
      FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
      WHERE v.dataset_id=? AND d.document_type='account-statement' AND v.period_start IS NOT NULL AND v.period_end IS NOT NULL
      ORDER BY v.id LIMIT 1`, binding.datasetId)[0];
    if (statement === undefined) throw new Error('Nullable export-date fixture is missing.');
    const dateScopes = [[statement.period_start, null], [null, statement.period_end], [statement.period_start, statement.period_end]] as const;
    for (const [index, [from, through]] of dateScopes.entries()) {
      const inventory = sql<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
        JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
        WHERE v.dataset_id=? AND m.id=? AND d.document_type='account-statement'
          AND (((v.period_start IS NOT NULL OR v.period_end IS NOT NULL) AND (? IS NULL OR v.period_end IS NULL OR v.period_end>?)
            AND (? IS NULL OR v.period_start IS NULL OR v.period_start<=?))
          OR (v.period_start IS NULL AND v.period_end IS NULL AND (? IS NULL OR substr(v.issued_at,1,10)>=?)
            AND (? IS NULL OR substr(v.issued_at,1,10)<=?))) ORDER BY v.id`,
      binding.datasetId, statement.member_id, from, from, through, through, from, from, through, through).map(row => row.id);
      const target: CustomerExportCreateCommand = { kind: 'document.customer_export.create', memberId: statement.member_id, categories: ['statements'],
        from, through, destination: 'local-vault', documentVersionIds: inventory, approvalId: 'pending-approval-id' };
      const approvalId = approve(binding, target, `export-date-${index}`);
      expect(committed(executeCommand(store, context(binding, 5), { ...target, approvalId }, `export-date-${index}`)).result)
        .toMatchObject({ from, through });
    }

    const limitBinding = clone();
    const limitMember = sql<{ member_id: string; party_id: string; existing_count: number }>(`SELECT m.id AS member_id,m.party_id,
      (SELECT COUNT(*) FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
        WHERE d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='servicing-notice') AS existing_count
      FROM members m WHERE m.dataset_id=? ORDER BY existing_count,m.id LIMIT 1`, limitBinding.datasetId)[0];
    if (limitMember === undefined || limitMember.existing_count > 100) throw new Error('Export inventory-limit fixture is unavailable.');
    const bytes = await textPdf(['Bounded customer-export inventory source.']);
    const contentDigest = createHash('sha256').update(bytes).digest('hex');
    using limitDatabase = new DatabaseSync(path);
    limitDatabase.prepare("INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'application/pdf',?,?)")
      .run(limitBinding.datasetId, contentDigest, bytes.byteLength, bytes);
    const addNotice = (index: number): void => {
      const documentId = `export-limit-document-${index}`; const versionId = `${documentId}-v1`;
      limitDatabase.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
        VALUES (?,?,?,NULL,'servicing-notice',?,'servicing-7y','2026-09-14T15:00:00.000Z')`)
        .run(limitBinding.datasetId, documentId, limitMember.party_id, `${documentId}.pdf`);
      limitDatabase.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
        VALUES (?,?,?,1,?,'application/pdf','2026-09-14T15:00:00.000Z',NULL,NULL,1,'current')`)
        .run(limitBinding.datasetId, versionId, documentId, contentDigest);
    };
    for (let index = limitMember.existing_count; index < 100; index += 1) addNotice(index);
    const exactInventory = sql<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE v.dataset_id=? AND d.owner_party_id=? AND d.document_type='servicing-notice' ORDER BY v.id`, limitBinding.datasetId, limitMember.party_id).map(row => row.id);
    expect(exactInventory).toHaveLength(100);
    const exactTarget: CustomerExportCreateCommand = { kind: 'document.customer_export.create', memberId: limitMember.member_id,
      categories: ['servicing-notices'], from: null, through: null, destination: 'approved-local-output', documentVersionIds: exactInventory,
      approvalId: 'pending-approval-id' };
    const exactApprovalId = approve(limitBinding, exactTarget, 'export-exact-100');
    expect(committed(executeCommand(store, context(limitBinding, 5), { ...exactTarget, approvalId: exactApprovalId }, 'export-exact-100')).result)
      .toMatchObject({ versionIds: exactInventory });
    addNotice(100);
    expect(executeCommand(store, context(limitBinding, 5), exactTarget, 'export-over-100')).toMatchObject({ kind: 'rejected', code: 'limit_exceeded' });
  });

  it('applies approved retention holds to either exact document or case scope', () => {
    const binding = clone();
    const fixture = sql<{ document_id: string; case_id: string }>(`SELECT d.id AS document_id,c.id AS case_id FROM documents d CROSS JOIN cases c
      WHERE d.dataset_id=? AND c.dataset_id=d.dataset_id
        AND NOT EXISTS (SELECT 1 FROM retention_holds h WHERE h.dataset_id=d.dataset_id AND h.document_id=d.id AND h.state='active')
        AND NOT EXISTS (SELECT 1 FROM retention_holds h WHERE h.dataset_id=c.dataset_id AND h.case_id=c.id AND h.state='active')
      ORDER BY d.id,c.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Retention-hold fixture is missing.');
    const documentTarget = { kind: 'document.retention_hold.apply' as const, documentId: fixture.document_id,
      reason: 'Preserve exact document evidence.', reviewAt: '2027-09-14T15:00:00Z', approvalId: 'pending-approval-id' };
    expect(executeCommand(store, context(binding, 5), { ...documentTarget, caseId: fixture.case_id }, 'retention-both-scopes'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding, 5), { kind: 'document.retention_hold.apply', reason: documentTarget.reason,
      reviewAt: documentTarget.reviewAt, approvalId: documentTarget.approvalId }, 'retention-no-scope'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding, 5), { ...documentTarget, reviewAt: '2026-09-14' }, 'retention-past-review'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    const documentApprovalId = approve(binding, documentTarget, 'retention-document');
    const documentHold = committed(executeCommand(store, context(binding, 5), { ...documentTarget, approvalId: documentApprovalId }, 'retention-document-apply'));
    expect(documentHold.result).toMatchObject({ documentId: fixture.document_id, caseId: null, reviewAt: '2027-09-14T15:00:00.000Z' });
    expect(executeCommand(store, context(binding, 5), { ...documentTarget, approvalId: documentApprovalId }, 'retention-document-overlap'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    const caseTarget = { kind: 'document.retention_hold.apply' as const, caseId: fixture.case_id,
      reason: 'Preserve exact case evidence.', reviewAt: '2027-10-01', approvalId: 'pending-approval-id' };
    const caseApprovalId = approve(binding, caseTarget, 'retention-case');
    const caseHold = committed(executeCommand(store, context(binding, 5), { ...caseTarget, approvalId: caseApprovalId }, 'retention-case-apply'));
    expect(caseHold.result).toMatchObject({ documentId: null, caseId: fixture.case_id, reviewAt: '2027-10-01' });
    expect(sql('SELECT document_id,case_id,state,review_at FROM retention_holds WHERE dataset_id=? AND id IN (?,?) ORDER BY case_id', binding.datasetId,
      documentHold.affected.find(record => record.kind === 'retention-hold')?.id ?? '', caseHold.affected.find(record => record.kind === 'retention-hold')?.id ?? '')).toEqual([
      { document_id: fixture.document_id, case_id: null, state: 'active', review_at: '2027-09-14T15:00:00.000Z' },
      { document_id: null, case_id: fixture.case_id, state: 'active', review_at: '2027-10-01' },
    ]);
  });

  it('records independent decline and expiry responses for a multi-signer request', async () => {
    const binding = clone();
    const fixture = sql<{ account_id: string; member_id: string; owner_party_id: string; signer_party_id: string }>(`SELECT a.id AS account_id,a.member_id,m.party_id AS owner_party_id,ap.party_id AS signer_party_id
      FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      JOIN account_parties ap ON ap.dataset_id=a.dataset_id AND ap.account_id=a.id AND ap.party_id<>m.party_id
        AND ap.role IN ('owner','joint-owner','signer') AND ap.ends_at IS NULL
      WHERE a.dataset_id=? AND a.status<>'closed' ORDER BY a.id,ap.party_id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Multi-signer account fixture is missing.');
    const targetBytes = await textPdf(['Document requiring two independent signer responses.']);
    const indexedTarget = committed(executeCommand(store, context(binding), { kind: 'document.index', memberId: fixture.member_id,
      ownerPartyId: fixture.owner_party_id, accountId: fixture.account_id, documentId: 'multi-signature-target', documentType: 'servicing-notice',
      displayName: 'multi-signature-target.pdf', retentionClass: 'servicing-7y', bytes: targetBytes, mediaType: 'application/pdf', pageCount: 1,
      source: 'approved-local-source' }, 'multi-signature-target-index'));
    const targetId = indexedTarget.affected.find(record => record.kind === 'document-version')?.id ?? '';
    const targetDigest = sql<{ digest: string }>('SELECT digest FROM document_versions WHERE dataset_id=? AND id=?', binding.datasetId, targetId)[0]?.digest ?? '';
    const signerPartyIds = [fixture.owner_party_id, fixture.signer_party_id];
    const request = { kind: 'document.signature.collect' as const, action: 'request' as const, documentVersionId: targetId,
      signerPartyIds, channel: 'secure-message-signature' };
    expect(executeCommand(store, context(binding), { ...request, signerPartyIds: [fixture.owner_party_id, fixture.owner_party_id] }, 'multi-signature-duplicate'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    committed(executeCommand(store, context(binding), request, 'multi-signature-request'));

    const respond = async (signerPartyId: string, action: 'decline' | 'expire', index: number): Promise<void> => {
      const bytes = await textPdf([`Document version: ${targetId}`, `Document SHA-256: ${targetDigest}`, `Signer party: ${signerPartyId}`,
        'Channel: secure-message-signature', `Response: ${action === 'decline' ? 'declined' : 'expired'}`]);
      const evidence = committed(executeCommand(store, context(binding, 5, 'system'), { kind: 'document.index', memberId: fixture.member_id,
        ownerPartyId: fixture.owner_party_id, accountId: fixture.account_id, documentId: `multi-signature-evidence-${index}`,
        documentType: 'signature-evidence', displayName: `multi-signature-evidence-${index}.pdf`, retentionClass: 'servicing-7y', bytes,
        mediaType: 'application/pdf', pageCount: 1, source: 'trusted-local-signature-response' }, `multi-signature-evidence-${index}`));
      const evidenceReference = evidence.affected.find(record => record.kind === 'document-version')?.id ?? '';
      committed(executeCommand(store, context(binding, 5, 'system'), { kind: 'document.signature.collect', action, documentVersionId: targetId,
        signerPartyIds: [signerPartyId], channel: 'secure-message-signature', evidenceReference }, `multi-signature-response-${index}`));
    };
    await respond(fixture.owner_party_id, 'decline', 1);
    expect(sql('SELECT signer_party_id,status FROM signatures WHERE dataset_id=? AND document_version_id=? ORDER BY signer_party_id', binding.datasetId, targetId))
      .toEqual([{ signer_party_id: fixture.owner_party_id, status: 'declined' }, { signer_party_id: fixture.signer_party_id, status: 'requested' }].sort((left, right) => left.signer_party_id.localeCompare(right.signer_party_id)));
    await respond(fixture.signer_party_id, 'expire', 2);
    expect(sql('SELECT signer_party_id,status FROM signatures WHERE dataset_id=? AND document_version_id=? ORDER BY signer_party_id', binding.datasetId, targetId))
      .toEqual([{ signer_party_id: fixture.owner_party_id, status: 'declined' }, { signer_party_id: fixture.signer_party_id, status: 'expired' }].sort((left, right) => left.signer_party_id.localeCompare(right.signer_party_id)));
  });

  it('requires annotation fingerprints and keeps removal terminal', () => {
    const binding = clone();
    const version = sql<{ version_id: string }>(`SELECT v.id AS version_id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE v.dataset_id=? AND v.page_count IS NOT NULL AND NOT EXISTS (SELECT 1 FROM case_documents cd WHERE cd.dataset_id=v.dataset_id AND cd.document_version_id=v.id AND cd.visibility='restricted')
      ORDER BY v.id LIMIT 1`, binding.datasetId)[0];
    if (version === undefined) throw new Error('Annotation document fixture is missing.');
    const base = { kind: 'document.annotation.update' as const, annotationId: 'annotation-concurrency-test', documentVersionId: version.version_id, pageNumber: 1,
      regionMicros: { x: 10_000, y: 10_000, width: 100_000, height: 50_000 } };
    committed(executeCommand(store, context(binding), { ...base, action: 'create', text: 'Initial review note.' }, 'annotation-create'));
    const initial = store.read(database => documentAnnotation(database, context(binding), 'annotation-concurrency-test'));
    if (initial.kind !== 'authorized' || initial.value === undefined) throw new Error('Created annotation is missing.');
    expect(executeCommand(store, context(binding), { ...base, action: 'amend', text: 'Stale edit.', expectedAnnotationFingerprint: 'stale' }, 'annotation-amend-stale')).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    committed(executeCommand(store, context(binding), { ...base, action: 'amend', text: 'Current edit.', expectedAnnotationFingerprint: initial.value.fingerprint }, 'annotation-amend'));
    const amended = store.read(database => documentAnnotation(database, context(binding), 'annotation-concurrency-test'));
    if (amended.kind !== 'authorized' || amended.value === undefined) throw new Error('Amended annotation is missing.');
    expect(executeCommand(store, context(binding), { ...base, action: 'remove', expectedAnnotationFingerprint: initial.value.fingerprint }, 'annotation-remove-stale')).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    committed(executeCommand(store, context(binding), { ...base, action: 'remove', expectedAnnotationFingerprint: amended.value.fingerprint }, 'annotation-remove'));
    expect(executeCommand(store, context(binding), { ...base, action: 'amend', text: 'Revive removed note.', expectedAnnotationFingerprint: amended.value.fingerprint }, 'annotation-revive')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });

  it('anchors annotations at normalized region boundaries across multiple pages', async () => {
    const binding = clone();
    const owner = sql<{ member_id: string; party_id: string }>(`SELECT id AS member_id,party_id FROM members WHERE dataset_id=? AND status<>'merged' ORDER BY id LIMIT 1`, binding.datasetId)[0];
    if (owner === undefined) throw new Error('Multi-page annotation owner is missing.');
    const document = await PDFDocument.create(); const font = await document.embedFont(StandardFonts.Helvetica);
    document.addPage([612, 792]).drawText('Annotation page one.', { x: 54, y: 738, size: 11, font });
    document.addPage([612, 792]).drawText('Annotation page two.', { x: 54, y: 738, size: 11, font });
    const bytes = await document.save({ useObjectStreams: false });
    const indexed = committed(executeCommand(store, context(binding), { kind: 'document.index', memberId: owner.member_id, ownerPartyId: owner.party_id,
      accountId: null, documentId: 'annotation-multipage-document', documentType: 'servicing-upload', displayName: 'annotation-multipage.pdf',
      retentionClass: 'servicing-7y', bytes, mediaType: 'application/pdf', pageCount: 2, source: 'approved-local-source' }, 'annotation-multipage-index'));
    const versionId = indexed.affected.find(record => record.kind === 'document-version')?.id ?? '';
    const annotations = [
      { annotationId: 'annotation-region-zero', pageNumber: 1, regionMicros: { x: 0, y: 0, width: 1, height: 1 } },
      { annotationId: 'annotation-region-one', pageNumber: 2, regionMicros: { x: 999_999, y: 999_999, width: 1, height: 1 } },
    ];
    for (const [index, annotation] of annotations.entries()) {
      committed(executeCommand(store, context(binding), { kind: 'document.annotation.update', ...annotation, documentVersionId: versionId,
        action: 'create', text: `Boundary annotation ${index + 1}.` }, `annotation-boundary-${index}`));
    }
    expect(sql('SELECT id,page_number,region_json FROM document_annotations WHERE dataset_id=? AND document_version_id=? ORDER BY page_number',
      binding.datasetId, versionId)).toEqual([
      { id: 'annotation-region-zero', page_number: 1, region_json: JSON.stringify({ x: 0, y: 0, width: 0.000001, height: 0.000001 }) },
      { id: 'annotation-region-one', page_number: 2, region_json: JSON.stringify({ x: 0.999999, y: 0.999999, width: 0.000001, height: 0.000001 }) },
    ]);
  });

  it('requires independent approval before unencumbered document reassociation', async () => {
    const binding = clone();
    const members = sql<{ member_id: string; party_id: string; account_id: string }>(`SELECT m.id AS member_id,m.party_id,a.id AS account_id FROM members m
      JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id WHERE m.dataset_id=? ORDER BY m.id LIMIT 2`, binding.datasetId);
    const source = members[0]; const targetOwner = members[1]; if (source === undefined || targetOwner === undefined) throw new Error('Metadata owner fixtures are missing.');
    const bytes = await textPdf(['Unencumbered document for metadata correction.']);
    committed(executeCommand(store, context(binding), { kind: 'document.index', memberId: source.member_id, ownerPartyId: source.party_id, accountId: source.account_id,
      documentId: 'metadata-reassociation-document', documentType: 'servicing-upload', displayName: 'before.pdf', retentionClass: 'servicing-7y', bytes,
      mediaType: 'application/pdf', pageCount: 1, source: 'approved-local-source' }, 'metadata-document-index'));
    const expectedMetadata = { ownerPartyId: source.party_id, accountId: source.account_id, documentType: 'servicing-upload', displayName: 'before.pdf', retentionClass: 'servicing-7y' };
    const target: ServicingCommand = { kind: 'document.metadata.update', documentId: 'metadata-reassociation-document', expectedMetadata,
      ownerPartyId: targetOwner.party_id, accountId: targetOwner.account_id, documentType: 'servicing-upload', displayName: 'after.pdf', retentionClass: 'servicing-7y', approvalId: 'pending-approval-id' };
    const withoutApproval = { kind: 'document.metadata.update' as const, documentId: 'metadata-reassociation-document', expectedMetadata,
      ownerPartyId: targetOwner.party_id, accountId: targetOwner.account_id, documentType: 'servicing-upload', displayName: 'after.pdf', retentionClass: 'servicing-7y' };
    expect(executeCommand(store, context(binding), withoutApproval, 'metadata-without-approval')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const approvalId = approve(binding, target, 'metadata-reassociation');
    committed(executeCommand(store, context(binding, 5), { ...target, approvalId }, 'metadata-with-approval'));
    expect(sql('SELECT owner_party_id,account_id,display_name FROM documents WHERE dataset_id=? AND id=?', binding.datasetId, 'metadata-reassociation-document')).toEqual([
      { owner_party_id: targetOwner.party_id, account_id: targetOwner.account_id, display_name: 'after.pdf' },
    ]);
    expect(sql('SELECT COUNT(*) AS count FROM document_access_events dae JOIN document_versions v ON v.dataset_id=dae.dataset_id AND v.id=dae.document_version_id WHERE v.dataset_id=? AND v.document_id=?', binding.datasetId, 'metadata-reassociation-document')).toEqual([{ count: 0 }]);
  });

  it('blocks owner reassociation across indirect identity, case-note, and lineage dependencies', async () => {
    const binding = clone();
    const members = sql<{ member_id: string; party_id: string; account_id: string }>(`SELECT m.id AS member_id,m.party_id,a.id AS account_id FROM members m
      JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id WHERE m.dataset_id=? ORDER BY m.id LIMIT 2`, binding.datasetId);
    const source = members[0]; const targetOwner = members[1]; if (source === undefined || targetOwner === undefined) throw new Error('Metadata dependency fixtures are missing.');
    const index = async (documentId: string, documentType: string): Promise<string> => {
      const receipt = committed(executeCommand(store, context(binding), { kind: 'document.index', memberId: source.member_id, ownerPartyId: source.party_id,
        accountId: source.account_id, documentId, documentType, displayName: `${documentId}.pdf`, retentionClass: 'servicing-7y',
        bytes: await textPdf([`Immutable ${documentId} bytes.`]), mediaType: 'application/pdf', pageCount: 1, source: 'approved-local-source' }, `index-${documentId}`));
      return receipt.affected.find(record => record.kind === 'document-version')?.id ?? '';
    };
    const reassociation = (documentId: string, documentType: string): ServicingCommand => ({ kind: 'document.metadata.update', documentId,
      expectedMetadata: { ownerPartyId: source.party_id, accountId: source.account_id, documentType, displayName: `${documentId}.pdf`, retentionClass: 'servicing-7y' },
      ownerPartyId: targetOwner.party_id, accountId: targetOwner.account_id, documentType, displayName: `${documentId}.pdf`, retentionClass: 'servicing-7y',
      approvalId: 'pending-approval-id' });

    const identityVersionId = await index('metadata-identity-dependent', 'identity-document');
    committed(executeCommand(store, context(binding), { kind: 'member.identity_evidence.register', memberId: source.member_id, documentVersionId: identityVersionId,
      evidenceId: 'metadata-identity-binding', evidenceKind: 'passport', issuedAt: '2024-01-10', expiresAt: '2034-01-10', reference: 'METADATA-IDENTITY-001' }, 'metadata-identity-reg'));
    expect(executeCommand(store, context(binding, 5), reassociation('metadata-identity-dependent', 'identity-document'), 'metadata-identity-move')).toMatchObject({ kind: 'rejected', code: 'ineligible' });

    const noteVersionId = await index('metadata-note-dependent', 'servicing-upload');
    const caseRow = sql<{ id: string; version: number }>(`SELECT c.id,c.version FROM cases c JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id
      WHERE c.dataset_id=? AND c.member_id=? AND q.visibility='general' ORDER BY c.id LIMIT 1`, binding.datasetId, source.member_id)[0];
    if (caseRow === undefined) throw new Error('Case-note dependency fixture is missing.');
    committed(executeCommand(store, context(binding), { kind: 'case.note.add', caseId: caseRow.id, visibility: 'general', text: 'Document-linked review note.',
      evidenceVersionIds: [noteVersionId] }, 'metadata-case-note-link'));
    expect(executeCommand(store, context(binding, 5), reassociation('metadata-note-dependent', 'servicing-upload'), 'metadata-note-move')).toMatchObject({ kind: 'rejected', code: 'ineligible' });

    const lineageSourceVersionId = await index('metadata-lineage-source', 'servicing-upload');
    const lineageDerivativeVersionId = await index('metadata-lineage-derivative', 'servicing-upload');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare('INSERT INTO document_derivations (dataset_id,id,source_version_id,derivative_version_id,purpose,policy_version_id) VALUES (?,?,?,?,?,NULL)')
      .run(binding.datasetId, 'metadata-lineage-link', lineageSourceVersionId, lineageDerivativeVersionId, 'format-conversion');
    expect(executeCommand(store, context(binding, 5), reassociation('metadata-lineage-source', 'servicing-upload'), 'metadata-lineage-move')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });

  it('qualifies ordinary and sensitive metadata corrections and every reassociation dependency', async () => {
    const binding = clone();
    const members = sql<{ member_id: string; party_id: string; account_id: string }>(`SELECT m.id AS member_id,m.party_id,a.id AS account_id FROM members m
      JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id WHERE m.dataset_id=? AND m.status<>'merged' ORDER BY m.id,a.id`, binding.datasetId);
    const source = members[0]; const targetOwner = members.find(member => member.member_id !== source?.member_id);
    if (source === undefined || targetOwner === undefined) throw new Error('Metadata option owners are missing.');
    const bytes = await textPdf(['Immutable metadata option coverage.']);
    const contentDigest = createHash('sha256').update(bytes).digest('hex');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare("INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'application/pdf',?,?)")
      .run(binding.datasetId, contentDigest, bytes.byteLength, bytes);
    const createDocument = (documentId: string): string => {
      const versionId = `${documentId}-v1`;
      fixtureDatabase.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
        VALUES (?,?,?,?,'servicing-upload',?,'servicing-7y','2026-09-14T15:00:00.000Z')`)
        .run(binding.datasetId, documentId, source.party_id, source.account_id, `${documentId}.pdf`);
      fixtureDatabase.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
        VALUES (?,?,?,1,?,'application/pdf','2026-09-14T15:00:00.000Z',NULL,NULL,1,'current')`)
        .run(binding.datasetId, versionId, documentId, contentDigest);
      return versionId;
    };
    const expectedMetadata = (documentId: string) => ({ ownerPartyId: source.party_id, accountId: source.account_id,
      documentType: 'servicing-upload', displayName: `${documentId}.pdf`, retentionClass: 'servicing-7y' });
    const reassociation = (documentId: string): ServicingCommand => ({ kind: 'document.metadata.update', documentId, expectedMetadata: expectedMetadata(documentId),
      ownerPartyId: targetOwner.party_id, accountId: targetOwner.account_id, documentType: 'servicing-upload', displayName: `${documentId}.pdf`,
      retentionClass: 'servicing-7y', approvalId: 'pending-approval-id' });

    const ordinaryId = 'metadata-ordinary-correction'; createDocument(ordinaryId);
    committed(executeCommand(store, context(binding), { kind: 'document.metadata.update', documentId: ordinaryId,
      expectedMetadata: expectedMetadata(ordinaryId), ownerPartyId: source.party_id, accountId: source.account_id, documentType: 'servicing-upload',
      displayName: 'metadata-ordinary-corrected.pdf', retentionClass: 'servicing-10y' }, 'metadata-ordinary-correct'));
    const sensitiveTarget: ServicingCommand = { kind: 'document.metadata.update', documentId: ordinaryId,
      expectedMetadata: { ownerPartyId: source.party_id, accountId: source.account_id, documentType: 'servicing-upload',
        displayName: 'metadata-ordinary-corrected.pdf', retentionClass: 'servicing-10y' }, ownerPartyId: source.party_id, accountId: source.account_id,
      documentType: 'identity-document', displayName: 'metadata-ordinary-corrected.pdf', retentionClass: 'servicing-10y', approvalId: 'pending-approval-id' };
    expect(executeCommand(store, context(binding), sensitiveTarget, 'metadata-sensitive-unapproved')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const sensitiveApprovalId = approve(binding, sensitiveTarget, 'metadata-sensitive-type');
    committed(executeCommand(store, context(binding, 5), { ...sensitiveTarget, approvalId: sensitiveApprovalId }, 'metadata-sensitive-approved'));

    const baseCase = sql<{ id: string }>('SELECT id FROM cases WHERE dataset_id=? ORDER BY id LIMIT 1', binding.datasetId)[0];
    const baseDispute = sql<{ id: string }>('SELECT id FROM disputes WHERE dataset_id=? ORDER BY id LIMIT 1', binding.datasetId)[0];
    const baseLoanReceipt = sql<{ loan_id: string; receipt_id: string }>(`SELECT l.id AS loan_id,r.id AS receipt_id FROM loans l CROSS JOIN operation_receipts r
      WHERE l.dataset_id=? AND r.dataset_id=l.dataset_id ORDER BY l.id,r.id LIMIT 1`, binding.datasetId)[0];
    if (baseCase === undefined || baseDispute === undefined || baseLoanReceipt === undefined) throw new Error('Metadata dependency parents are missing.');
    const dependencies = [
      { name: 'active-hold', attach(documentId: string): void {
        fixtureDatabase.prepare(`INSERT INTO retention_holds (dataset_id,id,document_id,case_id,reason,state,placed_at,review_at,released_at)
          VALUES (?,?,?,NULL,'Dependency coverage','active','2026-09-14T15:00:00.000Z','2027-09-14',NULL)`)
          .run(binding.datasetId, 'metadata-active-hold', documentId);
      } },
      { name: 'case-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare("INSERT INTO case_documents (dataset_id,case_id,document_version_id,purpose,visibility) VALUES (?,?,?,'metadata-dependency','general')")
          .run(binding.datasetId, baseCase.id, versionId);
      } },
      { name: 'case-note-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare("INSERT INTO case_notes (dataset_id,id,case_id,actor_id,visibility,text,created_at) VALUES (?,?,?,?,'general','Metadata dependency','2026-09-14T15:00:00.000Z')")
          .run(binding.datasetId, `metadata-note-${versionId}`, baseCase.id, `${binding.institutionId}-actor-2`);
        fixtureDatabase.prepare('INSERT INTO case_note_documents (dataset_id,note_id,document_version_id) VALUES (?,?,?)')
          .run(binding.datasetId, `metadata-note-${versionId}`, versionId);
      } },
      { name: 'request-link', attach(_documentId: string, versionId: string): void {
        const requestId = `metadata-request-${versionId}`;
        fixtureDatabase.prepare(`INSERT INTO maintenance_requests (dataset_id,id,request_number,member_id,account_id,category,reason,subject,draft_json,state,created_at,updated_at,applied_receipt_id)
          VALUES (?,?,?,?,?,'metadata',NULL,'Metadata dependency','{}','draft','2026-09-14T15:00:00.000Z','2026-09-14T15:00:00.000Z',NULL)`)
          .run(binding.datasetId, requestId, `MR-${versionId}`, source.member_id, source.account_id);
        fixtureDatabase.prepare("INSERT INTO request_attachments (dataset_id,request_id,document_version_id,purpose) VALUES (?,?,?,'evidence')")
          .run(binding.datasetId, requestId, versionId);
      } },
      { name: 'signature-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO signatures (dataset_id,id,document_version_id,signer_party_id,status,requested_at,signed_at,evidence_reference)
          VALUES (?,?,?,?,'requested','2026-09-14T15:00:00.000Z',NULL,NULL)`)
          .run(binding.datasetId, `metadata-signature-${versionId}`, versionId, source.party_id);
      } },
      { name: 'consent-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO consents (dataset_id,id,party_id,account_id,purpose,channel,disclosure_version_id,state,effective_at)
          VALUES (?,?,?,?,'metadata','email',?,'granted','2026-09-14T15:00:00.000Z')`)
          .run(binding.datasetId, `metadata-consent-${versionId}`, source.party_id, source.account_id, versionId);
      } },
      { name: 'communication-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO communication_jobs (dataset_id,id,party_id,document_version_id,purpose,channel,destination,state,created_at)
          VALUES (?,?,?,?,'servicing','email','metadata@example.invalid','queued','2026-09-14T15:00:00.000Z')`)
          .run(binding.datasetId, `metadata-job-${versionId}`, source.party_id, versionId);
      } },
      { name: 'identity-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO identity_evidence (dataset_id,id,party_id,kind,status,issued_at,expires_at,reference)
          VALUES (?,?,?,'passport','unverified','2026-01-01','2030-01-01',?)`)
          .run(binding.datasetId, `metadata-identity-${versionId}`, source.party_id, JSON.stringify({ documentVersionId: versionId, digest: contentDigest }));
      } },
      { name: 'derivation-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare("INSERT INTO document_derivations (dataset_id,id,source_version_id,derivative_version_id,purpose,policy_version_id) VALUES (?,?,?,?,'format-conversion',NULL)")
          .run(binding.datasetId, `metadata-derivation-${versionId}`, versionId, versionId);
      } },
      { name: 'annotation-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO document_annotations (dataset_id,id,document_version_id,actor_id,page_number,region_json,text,status,created_at)
          VALUES (?,?,?, ?,1,'{"x":0,"y":0,"width":1,"height":1}','Metadata dependency','active','2026-09-14T15:00:00.000Z')`)
          .run(binding.datasetId, `metadata-annotation-${versionId}`, versionId, `${binding.institutionId}-actor-2`);
      } },
      { name: 'access-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO document_access_events (dataset_id,id,document_version_id,actor_id,action,occurred_at,purpose)
          VALUES (?,?,?,?,'view','2026-09-14T15:00:00.000Z','metadata-dependency')`)
          .run(binding.datasetId, `metadata-access-${versionId}`, versionId, `${binding.institutionId}-actor-2`);
      } },
      { name: 'batch-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO batches (dataset_id,id,batch_number,kind,input_document_version_id,input_digest,state,approved_total_limit_minor_units,currency,created_at)
          VALUES (?,? ,?,'contact-update',?,?,'uploaded',NULL,NULL,'2026-09-14T15:00:00.000Z')`)
          .run(binding.datasetId, `metadata-batch-${versionId}`, `BT-${versionId}`, versionId, contentDigest);
      } },
      { name: 'dispute-link', attach(_documentId: string, versionId: string): void {
        fixtureDatabase.prepare(`INSERT INTO dispute_evidence (dataset_id,id,dispute_id,document_version_id,evidence_kind,digest,status,received_at)
          VALUES (?,?,?,?,'metadata',?,'received','2026-09-14T15:00:00.000Z')`)
          .run(binding.datasetId, `metadata-dispute-${versionId}`, baseDispute.id, versionId, contentDigest);
      } },
      { name: 'loan-closure-link', attach(_documentId: string, versionId: string): void {
        const existing = sql<{ id: string }>('SELECT id FROM loan_closures WHERE dataset_id=? AND loan_id=?', binding.datasetId, baseLoanReceipt.loan_id)[0];
        if (existing === undefined) {
          fixtureDatabase.prepare(`INSERT INTO loan_closures (dataset_id,id,loan_id,receipt_id,closed_at,closure_document_version_id)
            VALUES (?,?,?,?, '2026-09-14T15:00:00.000Z',?)`)
            .run(binding.datasetId, `metadata-loan-closure-${versionId}`, baseLoanReceipt.loan_id, baseLoanReceipt.receipt_id, versionId);
        } else fixtureDatabase.prepare('UPDATE loan_closures SET closure_document_version_id=? WHERE dataset_id=? AND id=?')
          .run(versionId, binding.datasetId, existing.id);
      } },
    ];
    for (const dependency of dependencies) {
      const documentId = `metadata-dependency-${dependency.name}`; const versionId = createDocument(documentId);
      dependency.attach(documentId, versionId);
      expect(executeCommand(store, context(binding, 5), reassociation(documentId), `metadata-block-${dependency.name}`))
        .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    }
  });

  it('accepts every exact maintenance business-command option and preserves it in the draft', () => {
    const binding = clone();
    const fixture = sql<{ member_id: string; member_version: number; account_id: string; account_version: number; statement_delivery: 'paper' | 'electronic' }>(`SELECT m.id AS member_id,m.version AS member_version,a.id AS account_id,a.version AS account_version,a.statement_delivery
      FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id WHERE m.dataset_id=? AND a.status<>'closed' ORDER BY a.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Maintenance command-option fixture is missing.');
    const commands = [
      { kind: 'contact.update' as const, memberId: fixture.member_id, expectedVersion: fixture.member_version, email: 'pending-contact@example.invalid' },
      { kind: 'member.note.add' as const, memberId: fixture.member_id, visibility: 'general' as const, text: 'Pending maintenance note.' },
      { kind: 'account.nickname.update' as const, accountId: fixture.account_id, expectedVersion: fixture.account_version, nickname: 'Pending nickname' },
      { kind: 'account.statement_delivery.update' as const, accountId: fixture.account_id, expectedVersion: fixture.account_version, statementDelivery: fixture.statement_delivery === 'paper' ? 'electronic' as const : 'paper' as const },
      { kind: 'account.close' as const, accountId: fixture.account_id, expectedVersion: fixture.account_version, reason: 'Pending eligible closure review.' },
    ];
    for (const [index, requestedCommand] of commands.entries()) {
      expect(isMaintenanceRequestedCommand(requestedCommand)).toBe(true);
      committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.save', memberId: fixture.member_id, accountId: fixture.account_id,
        requestId: `maintenance-option-${index}`, requestNumber: `MR-OPTION-${index}`, category: 'option-coverage', subject: `Review ${requestedCommand.kind}`,
        requestedCommand, missingFields: ['reason'] }, `maintenance-option-${index}`));
      const saved = store.read(database => maintenanceRequest(database, context(binding), `maintenance-option-${index}`));
      if (saved.kind !== 'authorized' || saved.value === undefined) throw new Error(`Maintenance option ${requestedCommand.kind} was not saved.`);
      expect(saved.value.draft).toMatchObject({ requestedCommand });
    }
  });

  it('revalidates communication consent before a trusted delivery callback', () => {
    const binding = clone();
    const fixture = sql<{ party_id: string; destination: string; version_id: string }>(`SELECT p.party_id,cp.value AS destination,v.id AS version_id FROM communication_preferences p
      JOIN contact_points cp ON cp.dataset_id=p.dataset_id AND cp.party_id=p.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      JOIN documents d ON d.dataset_id=p.dataset_id AND d.owner_party_id=p.party_id AND d.document_type='servicing-notice'
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status<>'superseded'
      WHERE p.dataset_id=? AND p.purpose='marketing' AND p.channel='email' AND p.state='enabled' ORDER BY p.party_id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Communication race fixture is missing.');
    const queued = committed(executeCommand(store, context(binding), { kind: 'communication.send', partyId: fixture.party_id, channel: 'email', destination: fixture.destination,
      purpose: 'marketing', documentVersionId: fixture.version_id, jobId: 'communication-race-job' }, 'communication-race-queue'));
    expect(queued.result).toMatchObject({ state: 'queued', delivered: false });
    committed(executeCommand(store, context(binding), { kind: 'communication.preference.update', partyId: fixture.party_id, purpose: 'marketing', channel: 'email', state: 'disabled' }, 'communication-race-optout'));
    const callback = { kind: 'communication.delivery.update' as const, jobId: 'communication-race-job', expectedState: 'queued' as const, action: 'deliver' as const, detail: 'Synthetic delivery callback.' };
    expect(executeCommand(store, context(binding, 5), callback, 'communication-human-callback')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const cancelled = committed(executeCommand(store, context(binding, 5, 'system'), callback, 'communication-system-callback'));
    expect(cancelled.result).toMatchObject({ state: 'cancelled', delivered: false, consentRevalidated: true });
    const job = store.read(database => communicationJob(database, context(binding), 'communication-race-job'));
    expect(job).toMatchObject({ kind: 'authorized', value: { state: 'cancelled', events: [{ state: 'queued' }, { state: 'cancelled' }] } });
  });

  it('records an affirmative account-scoped consent before withdrawing that exact grant', () => {
    const binding = clone();
    const fixture = sql<{ party_id: string; account_id: string; disclosure_version_id: string }>(`SELECT m.party_id,a.id AS account_id,v.id AS disclosure_version_id FROM members m
      JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.account_id=a.id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status<>'superseded'
      WHERE m.dataset_id=? ORDER BY m.id,a.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Consent lifecycle fixture is missing.');
    const grantContext = { ...context(binding), now: '2026-09-13T15:00:00.000Z' };
    const granted = committed(executeCommand(store, grantContext, { kind: 'consent.delivery.record', partyId: fixture.party_id,
      accountId: fixture.account_id, purpose: 'foundation-electronic-delivery', channel: 'email', disclosureVersionId: fixture.disclosure_version_id,
      evidence: 'Affirmative acknowledgement captured on the approved local surface.' }, 'consent-record-foundation'));
    const consentId = typeof granted.result?.consentId === 'string' ? granted.result.consentId : '';
    expect(granted.result).toMatchObject({ consentId, partyId: fixture.party_id, accountId: fixture.account_id, purpose: 'foundation-electronic-delivery', channel: 'email', disclosureVersionId: fixture.disclosure_version_id });
    expect(executeCommand(store, grantContext, { kind: 'consent.delivery.record', partyId: fixture.party_id,
      accountId: fixture.account_id, purpose: 'foundation-electronic-delivery', channel: 'email', disclosureVersionId: fixture.disclosure_version_id,
      evidence: 'Affirmative acknowledgement captured on the approved local surface.' }, 'consent-record-duplicate')).toMatchObject({ kind: 'unchanged' });
    const withdrawn = committed(executeCommand(store, context(binding), { kind: 'consent.withdraw', consentId, affectedChannels: ['email'] }, 'consent-withdraw-foundation'));
    const withdrawalId = typeof withdrawn.result?.withdrawalId === 'string' ? withdrawn.result.withdrawalId : '';
    expect(withdrawn.result).toMatchObject({ consentId, withdrawalId, accountId: fixture.account_id, state: 'withdrawn', effectiveAt: '2026-09-14T15:00:00.000Z' });
    expect(sql('SELECT id,account_id,state,effective_at,disclosure_version_id FROM consents WHERE dataset_id=? AND id IN (?,?) ORDER BY state', binding.datasetId, consentId, withdrawalId)).toEqual([
      { id: consentId, account_id: fixture.account_id, state: 'granted', effective_at: '2026-09-13T15:00:00.000Z', disclosure_version_id: fixture.disclosure_version_id },
      { id: withdrawalId, account_id: fixture.account_id, state: 'withdrawn', effective_at: '2026-09-14T15:00:00.000Z', disclosure_version_id: fixture.disclosure_version_id },
    ]);
  });

  it('does not use consent granted for one account to authorize another account statement', () => {
    const binding = clone();
    const fixture = sql<{ party_id: string; account_a: string; account_b: string; disclosure_version_id: string; notice_document_id: string; notice_version_id: string; destination: string }>(`SELECT m.party_id,a.id AS account_a,b.id AS account_b,dv.id AS disclosure_version_id,
      nd.id AS notice_document_id,nv.id AS notice_version_id,cp.value AS destination
      FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
      JOIN accounts b ON b.dataset_id=a.dataset_id AND b.member_id=m.id AND b.id>a.id
      JOIN documents dd ON dd.dataset_id=m.dataset_id AND dd.owner_party_id=m.party_id AND dd.account_id=a.id AND dd.document_type='delivery-disclosure'
      JOIN document_versions dv ON dv.dataset_id=dd.dataset_id AND dv.document_id=dd.id AND dv.status<>'superseded'
      JOIN documents nd ON nd.dataset_id=m.dataset_id AND nd.owner_party_id=m.party_id AND nd.account_id=a.id AND nd.document_type='servicing-notice'
      JOIN document_versions nv ON nv.dataset_id=nd.dataset_id AND nv.document_id=nd.id AND nv.status<>'superseded'
      JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      WHERE m.dataset_id=? ORDER BY m.id,a.id,b.id,dv.id,nv.id,cp.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Cross-account consent fixture is missing.');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare("DELETE FROM consents WHERE dataset_id=? AND party_id=? AND purpose='account-statements' AND channel='electronic'")
      .run(binding.datasetId, fixture.party_id);
    fixtureDatabase.prepare('UPDATE documents SET account_id=? WHERE dataset_id=? AND id=?')
      .run(fixture.account_b, binding.datasetId, fixture.notice_document_id);
    expect(executeCommand(store, context(binding), { kind: 'consent.delivery.record', partyId: fixture.party_id, accountId: fixture.account_b,
      purpose: 'account-statements', channel: 'electronic', disclosureVersionId: fixture.disclosure_version_id,
      evidence: 'Mismatched account acknowledgement.' }, 'consent-mismatched-disclosure'))
      .toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    committed(executeCommand(store, context(binding), { kind: 'consent.delivery.record', partyId: fixture.party_id, accountId: fixture.account_a,
      purpose: 'account-statements', channel: 'electronic', disclosureVersionId: fixture.disclosure_version_id,
      evidence: 'Affirmative account A acknowledgement.' }, 'consent-account-a'));
    expect(executeCommand(store, context(binding), { kind: 'communication.send', partyId: fixture.party_id, channel: 'email', destination: fixture.destination,
      purpose: 'account-statements', documentVersionId: fixture.notice_version_id, jobId: 'cross-account-statement-job' }, 'consent-account-b-send'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });

  it('uses party-wide statement consent when the notice account has no exact consent state', () => {
    const binding = clone();
    const fixture = sql<{ party_id: string; account_b: string; disclosure_document_id: string; disclosure_version_id: string; notice_document_id: string; notice_version_id: string; destination: string }>(`SELECT m.party_id,b.id AS account_b,dd.id AS disclosure_document_id,dv.id AS disclosure_version_id,
      nd.id AS notice_document_id,nv.id AS notice_version_id,cp.value AS destination
      FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
      JOIN accounts b ON b.dataset_id=a.dataset_id AND b.member_id=m.id AND b.id>a.id
      JOIN documents dd ON dd.dataset_id=m.dataset_id AND dd.owner_party_id=m.party_id AND dd.account_id=a.id AND dd.document_type='delivery-disclosure'
      JOIN document_versions dv ON dv.dataset_id=dd.dataset_id AND dv.document_id=dd.id AND dv.status<>'superseded'
      JOIN documents nd ON nd.dataset_id=m.dataset_id AND nd.owner_party_id=m.party_id AND nd.account_id=a.id AND nd.document_type='servicing-notice'
      JOIN document_versions nv ON nv.dataset_id=nd.dataset_id AND nv.document_id=nd.id AND nv.status<>'superseded'
      JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      WHERE m.dataset_id=? ORDER BY m.id,a.id,b.id,dv.id,nv.id,cp.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Party-wide consent fixture is missing.');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare("DELETE FROM consents WHERE dataset_id=? AND party_id=? AND purpose='account-statements' AND channel='electronic'")
      .run(binding.datasetId, fixture.party_id);
    fixtureDatabase.prepare('UPDATE documents SET account_id=NULL WHERE dataset_id=? AND id=?')
      .run(binding.datasetId, fixture.disclosure_document_id);
    fixtureDatabase.prepare('UPDATE documents SET account_id=? WHERE dataset_id=? AND id=?')
      .run(fixture.account_b, binding.datasetId, fixture.notice_document_id);
    const granted = committed(executeCommand(store, context(binding), { kind: 'consent.delivery.record', partyId: fixture.party_id, accountId: null,
      purpose: 'account-statements', channel: 'electronic', disclosureVersionId: fixture.disclosure_version_id,
      evidence: 'Affirmative party-wide acknowledgement.' }, 'consent-party-wide'));
    expect(granted.result).toMatchObject({ partyId: fixture.party_id, accountId: null, purpose: 'account-statements', channel: 'electronic' });
    expect(executeCommand(store, context(binding), { kind: 'communication.send', partyId: fixture.party_id, channel: 'email', destination: fixture.destination,
      purpose: 'account-statements', documentVersionId: fixture.notice_version_id, jobId: 'party-wide-statement-job' }, 'consent-party-wide-send'))
      .toMatchObject({ kind: 'committed', receipt: { result: { state: 'queued', delivered: false } } });
  });

  it('lets an exact account withdrawal override party-wide consent for only that account', () => {
    const binding = clone();
    const fixture = sql<{ party_id: string; account_a: string; account_b: string; fallback_document_id: string; fallback_version_id: string; exact_version_id: string; notice_document_id: string; notice_version_id: string; destination: string }>(`SELECT m.party_id,a.id AS account_a,b.id AS account_b,fd.id AS fallback_document_id,fv.id AS fallback_version_id,
      ev.id AS exact_version_id,nd.id AS notice_document_id,nv.id AS notice_version_id,cp.value AS destination
      FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
      JOIN accounts b ON b.dataset_id=a.dataset_id AND b.member_id=m.id AND b.id>a.id
      JOIN documents fd ON fd.dataset_id=m.dataset_id AND fd.owner_party_id=m.party_id AND fd.account_id=a.id AND fd.document_type='delivery-disclosure'
      JOIN document_versions fv ON fv.dataset_id=fd.dataset_id AND fv.document_id=fd.id AND fv.status<>'superseded'
      JOIN documents ed ON ed.dataset_id=m.dataset_id AND ed.owner_party_id=m.party_id AND ed.account_id=a.id AND ed.document_type='account-statement'
      JOIN document_versions ev ON ev.dataset_id=ed.dataset_id AND ev.document_id=ed.id AND ev.status<>'superseded'
      JOIN documents nd ON nd.dataset_id=m.dataset_id AND nd.owner_party_id=m.party_id AND nd.account_id=a.id AND nd.document_type='servicing-notice'
      JOIN document_versions nv ON nv.dataset_id=nd.dataset_id AND nv.document_id=nd.id AND nv.status<>'superseded'
      JOIN contact_points cp ON cp.dataset_id=m.dataset_id AND cp.party_id=m.party_id AND cp.kind='email' AND cp.valid_to IS NULL
      WHERE m.dataset_id=? ORDER BY m.id,a.id,b.id,fv.id,ev.id,nv.id,cp.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Consent precedence fixture is missing.');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare("DELETE FROM consents WHERE dataset_id=? AND party_id=? AND purpose='account-statements' AND channel='electronic'")
      .run(binding.datasetId, fixture.party_id);
    fixtureDatabase.prepare('UPDATE documents SET account_id=NULL WHERE dataset_id=? AND id=?')
      .run(binding.datasetId, fixture.fallback_document_id);
    committed(executeCommand(store, context(binding), { kind: 'consent.delivery.record', partyId: fixture.party_id, accountId: null,
      purpose: 'account-statements', channel: 'electronic', disclosureVersionId: fixture.fallback_version_id,
      evidence: 'Affirmative party-wide acknowledgement.' }, 'consent-fallback-grant'));
    const exactGrant = committed(executeCommand(store, context(binding), { kind: 'consent.delivery.record', partyId: fixture.party_id, accountId: fixture.account_a,
      purpose: 'account-statements', channel: 'electronic', disclosureVersionId: fixture.exact_version_id,
      evidence: 'Affirmative account A acknowledgement.' }, 'consent-exact-grant'));
    const exactConsentId = typeof exactGrant.result?.consentId === 'string' ? exactGrant.result.consentId : '';
    committed(executeCommand(store, context(binding), { kind: 'consent.withdraw', consentId: exactConsentId,
      affectedChannels: ['electronic'] }, 'consent-exact-withdraw'));
    expect(executeCommand(store, context(binding), { kind: 'communication.send', partyId: fixture.party_id, channel: 'email', destination: fixture.destination,
      purpose: 'account-statements', documentVersionId: fixture.notice_version_id, jobId: 'withdrawn-account-a-job' }, 'consent-account-a-blocked'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare('UPDATE documents SET account_id=? WHERE dataset_id=? AND id=?')
      .run(fixture.account_b, binding.datasetId, fixture.notice_document_id);
    expect(executeCommand(store, context(binding), { kind: 'communication.send', partyId: fixture.party_id, channel: 'email', destination: fixture.destination,
      purpose: 'account-statements', documentVersionId: fixture.notice_version_id, jobId: 'fallback-account-b-job' }, 'consent-account-b-fallback'))
      .toMatchObject({ kind: 'committed', receipt: { result: { state: 'queued', delivered: false } } });
  });

  it('withdraws exactly one stored consent channel and rejects future scheduling', () => {
    const binding = clone();
    const consent = sql<{ id: string; account_id: string | null; channel: string; effective_at: string }>("SELECT id,account_id,channel,effective_at FROM consents WHERE dataset_id=? AND state='granted' ORDER BY id LIMIT 1", binding.datasetId)[0];
    if (consent === undefined) throw new Error('Granted consent fixture is missing.');
    expect(executeCommand(store, context(binding), { kind: 'consent.withdraw', consentId: consent.id, affectedChannels: [consent.channel, 'email'] }, 'consent-extra-channel')).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding), { kind: 'consent.withdraw', consentId: consent.id, affectedChannels: [consent.channel], effectiveAt: '2026-09-15T15:00:00.000Z' }, 'consent-future')).toMatchObject({ kind: 'rejected', code: 'validation' });
    const withdrawal = committed(executeCommand(store, context(binding), { kind: 'consent.withdraw', consentId: consent.id, affectedChannels: [consent.channel],
      effectiveAt: '2026-09-14T15:00:00Z' }, 'consent-withdraw-now'));
    const withdrawalId = typeof withdrawal.result?.withdrawalId === 'string' ? withdrawal.result.withdrawalId : '';
    expect(sql('SELECT id,account_id,state,effective_at FROM consents WHERE dataset_id=? AND id IN (?,?) ORDER BY state', binding.datasetId, consent.id, withdrawalId)).toEqual([
      { id: consent.id, account_id: consent.account_id, state: 'granted', effective_at: consent.effective_at },
      { id: withdrawalId, account_id: consent.account_id, state: 'withdrawn', effective_at: '2026-09-14T15:00:00.000Z' },
    ]);
  });

  it('preserves address history and rejects an approved reconciliation after the member version changes', () => {
    const binding = clone();
    const fixture = sql<{ member_id: string; member_version: number; address_id: string; line1: string; line2: string | null; city: string; region: string; postal_code: string; country: string; evidence_id: string; evidence_document_id: string; digest: string }>(`SELECT m.id AS member_id,m.version AS member_version,a.id AS address_id,a.line1,a.line2,a.city,a.region,a.postal_code,a.country,v.id AS evidence_id,v.document_id AS evidence_document_id,v.digest
      FROM members m JOIN party_addresses pa ON pa.dataset_id=m.dataset_id AND pa.party_id=m.party_id AND pa.evidence_status='conflicting'
      JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='address-evidence'
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id WHERE m.dataset_id=? ORDER BY m.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Address reconciliation fixture is missing.');
    const target: AddressReconcileCommand = { kind: 'maintenance.address.reconcile', memberId: fixture.member_id, expectedMemberVersion: fixture.member_version,
      conflictingAddressId: fixture.address_id, winningEvidenceVersionId: fixture.evidence_id, winningEvidenceDigest: fixture.digest, precedence: 'verified-evidence',
      address: { line1: '500 Approved Avenue', line2: fixture.line2, city: fixture.city, region: fixture.region, postalCode: fixture.postal_code, country: fixture.country }, approvalId: 'pending-approval-id' };
    expect(executeCommand(store, context(binding, 5), { ...target, winningEvidenceDigest: '0'.repeat(64) }, 'address-wrong-digest'))
      .toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    const foreignEvidence = sql<{ id: string; digest: string }>(`SELECT v.id,v.digest FROM document_versions v
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
      WHERE v.dataset_id=? AND m.id<>? AND d.document_type='address-evidence' AND v.status='current' ORDER BY v.id LIMIT 1`,
    binding.datasetId, fixture.member_id)[0];
    if (foreignEvidence === undefined) throw new Error('Foreign address-evidence fixture is missing.');
    expect(executeCommand(store, context(binding, 5), { ...target, winningEvidenceVersionId: foreignEvidence.id,
      winningEvidenceDigest: foreignEvidence.digest }, 'address-foreign-evidence')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    using fixtureDatabase = new DatabaseSync(path);
    const evidenceBlob = sql<{ bytes: Uint8Array }>('SELECT bytes FROM document_blobs WHERE dataset_id=? AND digest=?', binding.datasetId, fixture.digest)[0];
    if (evidenceBlob === undefined) throw new Error('Address evidence blob is missing.');
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=zeroblob(byte_length) WHERE dataset_id=? AND digest=?').run(binding.datasetId, fixture.digest);
    expect(executeCommand(store, context(binding, 5), target, 'address-corrupt-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(sql('SELECT a.line1,pa.valid_to,pa.evidence_status FROM addresses a JOIN party_addresses pa ON pa.dataset_id=a.dataset_id AND pa.address_id=a.id WHERE a.dataset_id=? AND a.id=?',
      binding.datasetId, fixture.address_id)).toEqual([{ line1: fixture.line1, valid_to: null, evidence_status: 'conflicting' }]);
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=? WHERE dataset_id=? AND digest=?').run(evidenceBlob.bytes, binding.datasetId, fixture.digest);
    fixtureDatabase.prepare("UPDATE party_addresses SET evidence_status='verified' WHERE dataset_id=? AND address_id=?").run(binding.datasetId, fixture.address_id);
    expect(executeCommand(store, context(binding, 5), target, 'address-no-longer-conflicting')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE party_addresses SET evidence_status='conflicting' WHERE dataset_id=? AND address_id=?").run(binding.datasetId, fixture.address_id);
    fixtureDatabase.prepare("UPDATE documents SET document_type='servicing-notice' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_document_id);
    expect(executeCommand(store, context(binding, 5), target, 'address-wrong-evidence-type')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE documents SET document_type='address-evidence' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_document_id);
    fixtureDatabase.prepare("UPDATE document_versions SET status='superseded' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_id);
    expect(executeCommand(store, context(binding, 5), target, 'address-stale-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE document_versions SET status='current' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_id);
    const expiredTarget = { ...target, address: { ...target.address, line1: '501 Expired Approval Avenue' } };
    const expiredApprovalId = approve(binding, expiredTarget, 'address-expired');
    expect(executeCommand(store, { ...context(binding, 5), now: '2026-09-16T15:00:00.000Z' }, { ...expiredTarget, approvalId: expiredApprovalId }, 'address-expired-approval'))
      .toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const approvalId = approve(binding, target, 'address-concurrency');
    fixtureDatabase.prepare('UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?').run(binding.datasetId, fixture.member_id);
    expect(executeCommand(store, context(binding, 5), { ...target, approvalId }, 'address-stale-after-approval')).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    expect(sql<{ line1: string }>('SELECT line1 FROM addresses WHERE dataset_id=? AND id=?', binding.datasetId, fixture.address_id)).toEqual([{ line1: fixture.line1 }]);

    const freshBinding = clone();
    const fresh = sql<typeof fixture>(`SELECT m.id AS member_id,m.version AS member_version,a.id AS address_id,a.line1,a.line2,a.city,a.region,a.postal_code,a.country,v.id AS evidence_id,v.document_id AS evidence_document_id,v.digest
      FROM members m JOIN party_addresses pa ON pa.dataset_id=m.dataset_id AND pa.party_id=m.party_id AND pa.evidence_status='conflicting' AND pa.valid_to IS NULL
      JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id AND d.document_type='address-evidence'
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.status='current' WHERE m.dataset_id=? ORDER BY m.id,v.id LIMIT 1`, freshBinding.datasetId)[0];
    if (fresh === undefined) throw new Error('Fresh address reconciliation fixture is missing.');
    const freshTarget: AddressReconcileCommand = { kind: 'maintenance.address.reconcile', memberId: fresh.member_id, expectedMemberVersion: fresh.member_version,
      conflictingAddressId: fresh.address_id, winningEvidenceVersionId: fresh.evidence_id, winningEvidenceDigest: fresh.digest, precedence: 'verified-evidence',
      address: { line1: '500 Approved Avenue', line2: fresh.line2, city: fresh.city, region: fresh.region, postalCode: fresh.postal_code, country: fresh.country }, approvalId: 'pending-approval-id' };
    const freshApprovalId = approve(freshBinding, freshTarget, 'address-positive');
    const reconciled = committed(executeCommand(store, context(freshBinding, 5), { ...freshTarget, approvalId: freshApprovalId }, 'address-positive'));
    const canonicalAddressId = typeof reconciled.result?.addressId === 'string' ? reconciled.result.addressId : '';
    expect(reconciled.result).toMatchObject({ memberId: fresh.member_id, addressId: canonicalAddressId, supersededAddressId: fresh.address_id,
      winningEvidenceVersionId: fresh.evidence_id, sourceDisposition: 'verified-over-conflicting' });
    expect(sql('SELECT a.line1,pa.evidence_status,pa.valid_to FROM addresses a JOIN party_addresses pa ON pa.dataset_id=a.dataset_id AND pa.address_id=a.id WHERE a.dataset_id=? AND a.id=?',
      freshBinding.datasetId, fresh.address_id)).toEqual([{ line1: fresh.line1, evidence_status: 'conflicting', valid_to: '2026-09-14T15:00:00.000Z' }]);
    expect(sql('SELECT a.line1,pa.evidence_status,pa.valid_to FROM addresses a JOIN party_addresses pa ON pa.dataset_id=a.dataset_id AND pa.address_id=a.id WHERE a.dataset_id=? AND a.id=?',
      freshBinding.datasetId, canonicalAddressId)).toEqual([{ line1: '500 Approved Avenue', evidence_status: 'verified', valid_to: null }]);
  });

  it('opens every case category across all priorities at the exact business-date boundary', () => {
    const binding = clone();
    const member = sql<{ id: string }>(`SELECT m.id FROM members m WHERE m.dataset_id=? AND m.status<>'merged'
      AND NOT EXISTS (SELECT 1 FROM cases c WHERE c.dataset_id=m.dataset_id AND c.member_id=m.id) ORDER BY m.id LIMIT 1`, binding.datasetId)[0];
    const queue = sql<{ id: string }>("SELECT id FROM queues WHERE dataset_id=? AND visibility='general' ORDER BY id LIMIT 1", binding.datasetId)[0];
    if (member === undefined || queue === undefined) throw new Error('Case-opening option fixtures are missing.');
    const categories = ['account-servicing', 'address-evidence', 'contact-evidence', 'statement-copy', 'transaction-inquiry', 'fee-inquiry', 'complaint', 'general'] as const;
    const priorities = ['low', 'normal', 'high', 'urgent'] as const;
    for (const [index, category] of categories.entries()) {
      const opened = committed(executeCommand(store, context(binding), { kind: 'case.open', memberId: member.id, accountId: null, queueId: queue.id,
        assignedActorId: null, category, priority: priorities[index % priorities.length] ?? 'normal', summary: `Exact option coverage for ${category}.`,
        dueDate: '2026-09-14' }, `case-open-option-${index}`));
      expect(typeof opened.result?.caseNumber).toBe('string');
    }
    const base = { kind: 'case.open' as const, memberId: member.id, accountId: null, queueId: queue.id, assignedActorId: null,
      category: 'account-servicing' as const, priority: 'normal' as const, summary: 'Reject a foreign route target.', dueDate: '2026-09-15' };
    expect(executeCommand(store, context(binding), { ...base, queueId: 'foreign-queue-id' }, 'case-open-foreign-queue'))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'queueId' });
    expect(executeCommand(store, context(binding), { ...base, assignedActorId: 'foreign-actor-id', category: 'general' }, 'case-open-foreign-assignee'))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'assignedActorId' });
  });

  it('escalates at the exact stored deadline and leaves urgent priority unchanged', () => {
    const binding = clone();
    const target = sql<{ id: string; version: number }>("SELECT id,version FROM cases WHERE dataset_id=? AND state IN ('open','pending-customer','pending-internal','reopened') ORDER BY id LIMIT 1", binding.datasetId)[0];
    if (target === undefined) throw new Error('Exact-deadline escalation fixture is missing.');
    using caseDatabase = new DatabaseSync(path);
    caseDatabase.prepare("UPDATE cases SET priority='normal',due_at='2026-09-14T15:00:00.000Z' WHERE dataset_id=? AND id=?").run(binding.datasetId, target.id);
    expect(committed(executeCommand(store, context(binding), { kind: 'case.escalate', caseId: target.id, expectedVersion: target.version,
      escalationRule: 'Escalate at the exact stored deadline.' }, 'case-escalate-exact')).result).toMatchObject({ priority: 'high' });
    caseDatabase.prepare("UPDATE cases SET priority='urgent' WHERE dataset_id=? AND id=?").run(binding.datasetId, target.id);
    expect(executeCommand(store, context(binding), { kind: 'case.escalate', caseId: target.id, expectedVersion: target.version + 1,
      escalationRule: 'Urgent priority is already terminal.' }, 'case-escalate-urgent')).toMatchObject({ kind: 'unchanged' });
  });

  it('escalates an overdue case and closes then reopens a resolved case with preserved evidence history', () => {
    const binding = clone();
    const overdue = sql<{ id: string; version: number; priority: 'normal' | 'high' }>(`SELECT id,version,priority FROM cases WHERE dataset_id=?
      AND state IN ('open','pending-customer','pending-internal','reopened') AND due_at<=? AND priority IN ('normal','high') ORDER BY id LIMIT 1`, binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
    if (overdue === undefined) throw new Error('Overdue escalation fixture is missing.');
    using caseDatabase = new DatabaseSync(path);
    caseDatabase.prepare("UPDATE cases SET priority='low' WHERE dataset_id=? AND id=?").run(binding.datasetId, overdue.id);
    const escalated = committed(executeCommand(store, context(binding), { kind: 'case.escalate', caseId: overdue.id, expectedVersion: overdue.version,
      escalationRule: 'Stored due time has passed.' }, 'case-escalate-overdue'));
    expect(escalated.result).toMatchObject({ caseId: overdue.id, priority: 'normal' });

    const resolved = sql<{ id: string; version: number; member_id: string; evidence_id: string; event_count: number }>(`SELECT c.id,c.version,c.member_id,v.id AS evidence_id,
      (SELECT COUNT(*) FROM case_events e WHERE e.dataset_id=c.dataset_id AND e.case_id=c.id) AS event_count
      FROM cases c JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
      WHERE c.dataset_id=? AND c.state='resolved' AND NOT EXISTS
        (SELECT 1 FROM case_dependencies dep WHERE dep.dataset_id=c.dataset_id AND dep.case_id=c.id AND dep.state='open')
      ORDER BY c.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (resolved === undefined) throw new Error('Resolved case lifecycle fixture is missing.');
    committed(executeCommand(store, context(binding), { kind: 'case.close', caseId: resolved.id, expectedVersion: resolved.version,
      resolutionCode: 'completed-with-evidence', effectEvidenceVersionId: resolved.evidence_id }, 'case-close-resolved'));
    const reopened = committed(executeCommand(store, context(binding), { kind: 'case.reopen', caseId: resolved.id, expectedVersion: resolved.version + 1,
      evidenceVersionId: resolved.evidence_id, reopeningBasis: 'New material evidence requires another review.' }, 'case-reopen-closed'));
    expect(reopened.result).toMatchObject({ caseId: resolved.id, state: 'reopened', evidenceVersionId: resolved.evidence_id });
    expect(sql('SELECT state,version FROM cases WHERE dataset_id=? AND id=?', binding.datasetId, resolved.id)).toEqual([{ state: 'reopened', version: resolved.version + 2 }]);
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM case_events WHERE dataset_id=? AND case_id=?', binding.datasetId, resolved.id)).toEqual([{ count: resolved.event_count + 2 }]);
    expect(sql('SELECT kind,reference_id,state,due_at FROM case_dependencies WHERE dataset_id=? AND case_id=? AND kind=?', binding.datasetId, resolved.id, 'new-evidence')).toEqual([
      { kind: 'new-evidence', reference_id: resolved.evidence_id, state: 'open', due_at: '2026-09-21T15:00:00.000Z' },
    ]);
  });

  it('requires explicit current immutable evidence for case closure and reopening', () => {
    const binding = clone();
    const fixture = sql<{ case_id: string; version: number; member_id: string; evidence_id: string; document_id: string; digest: string }>(`SELECT c.id AS case_id,c.version,c.member_id,v.id AS evidence_id,v.document_id,v.digest
      FROM cases c JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
      WHERE c.dataset_id=? AND c.state='resolved' AND v.status IN ('current','signed') AND v.media_type='application/pdf'
        AND NOT EXISTS (SELECT 1 FROM case_dependencies dep WHERE dep.dataset_id=c.dataset_id AND dep.case_id=c.id AND dep.state='open')
        AND NOT EXISTS (SELECT 1 FROM case_documents cd WHERE cd.dataset_id=v.dataset_id AND cd.document_version_id=v.id)
      ORDER BY c.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Explicit case evidence fixture is missing.');
    const foreign = sql<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
      WHERE v.dataset_id=? AND m.id<>? AND v.status IN ('current','signed') AND v.media_type='application/pdf'
        AND NOT EXISTS (SELECT 1 FROM case_documents cd WHERE cd.dataset_id=v.dataset_id AND cd.document_version_id=v.id AND cd.visibility='restricted')
      ORDER BY v.id LIMIT 1`, binding.datasetId, fixture.member_id)[0];
    if (foreign === undefined) throw new Error('Foreign case evidence fixture is missing.');
    const close = { kind: 'case.close' as const, caseId: fixture.case_id, expectedVersion: fixture.version,
      resolutionCode: 'completed-with-evidence', effectEvidenceVersionId: fixture.evidence_id };
    expect(executeCommand(store, context(binding), { kind: 'case.transition', caseId: fixture.case_id, expectedVersion: fixture.version,
      toState: 'closed', reason: 'Attempt generic closure.' }, 'case-close-generic-bypass')).toMatchObject({ kind: 'rejected', code: 'invalid_transition' });
    expect(executeCommand(store, context(binding), { ...close, expectedVersion: fixture.version + 1 }, 'case-close-stale'))
      .toMatchObject({ kind: 'rejected', code: 'stale_version' });
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare("INSERT INTO case_dependencies (dataset_id,id,case_id,kind,reference_id,state,due_at) VALUES (?,?,?,'required-effect','pending','open',NULL)")
      .run(binding.datasetId, 'case-close-blocker', fixture.case_id);
    expect(executeCommand(store, context(binding), close, 'case-close-open-dependency')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare('DELETE FROM case_dependencies WHERE dataset_id=? AND id=?').run(binding.datasetId, 'case-close-blocker');
    fixtureDatabase.prepare("UPDATE cases SET state='open' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.case_id);
    expect(executeCommand(store, context(binding), close, 'case-close-wrong-state')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE cases SET state='resolved' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.case_id);
    expect(executeCommand(store, context(binding), { ...close, effectEvidenceVersionId: foreign.id }, 'case-close-foreign-evidence'))
      .toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    fixtureDatabase.prepare("UPDATE document_versions SET status='superseded' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_id);
    expect(executeCommand(store, context(binding), close, 'case-close-superseded-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE document_versions SET status='current' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_id);
    const originalBlob = sql<{ bytes: Uint8Array }>('SELECT bytes FROM document_blobs WHERE dataset_id=? AND digest=?', binding.datasetId, fixture.digest)[0];
    if (originalBlob === undefined) throw new Error('Case evidence blob is missing.');
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=zeroblob(byte_length) WHERE dataset_id=? AND digest=?').run(binding.datasetId, fixture.digest);
    expect(executeCommand(store, context(binding), close, 'case-close-corrupt-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=? WHERE dataset_id=? AND digest=?').run(originalBlob.bytes, binding.datasetId, fixture.digest);
    committed(executeCommand(store, context(binding), close, 'case-close-explicit'));

    const reopen = { kind: 'case.reopen' as const, caseId: fixture.case_id, expectedVersion: fixture.version + 1,
      evidenceVersionId: fixture.evidence_id, reopeningBasis: 'New immutable evidence requires renewed work.', dueAt: '2026-09-22T15:00:00.000Z' };
    expect(executeCommand(store, context(binding), { kind: 'case.transition', caseId: fixture.case_id, expectedVersion: fixture.version + 1,
      toState: 'reopened', reason: 'Attempt generic reopening.' }, 'case-reopen-generic-bypass')).toMatchObject({ kind: 'rejected', code: 'invalid_transition' });
    expect(executeCommand(store, context(binding), { ...reopen, expectedVersion: fixture.version }, 'case-reopen-stale'))
      .toMatchObject({ kind: 'rejected', code: 'stale_version' });
    expect(executeCommand(store, context(binding), { ...reopen, evidenceVersionId: foreign.id }, 'case-reopen-foreign-evidence'))
      .toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    expect(executeCommand(store, context(binding), { ...reopen, dueAt: '2026-09-14T15:00:00.000Z' }, 'case-reopen-past-due'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    fixtureDatabase.prepare("UPDATE cases SET state='open' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.case_id);
    expect(executeCommand(store, context(binding), reopen, 'case-reopen-wrong-state')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE cases SET state='closed' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.case_id);
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=zeroblob(byte_length) WHERE dataset_id=? AND digest=?').run(binding.datasetId, fixture.digest);
    expect(executeCommand(store, context(binding), reopen, 'case-reopen-corrupt-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare('UPDATE document_blobs SET bytes=? WHERE dataset_id=? AND digest=?').run(originalBlob.bytes, binding.datasetId, fixture.digest);
    expect(committed(executeCommand(store, context(binding), reopen, 'case-reopen-explicit')).result)
      .toMatchObject({ caseId: fixture.case_id, state: 'reopened', evidenceVersionId: fixture.evidence_id });
    expect(sql('SELECT due_at FROM case_dependencies WHERE dataset_id=? AND case_id=? AND kind=?', binding.datasetId, fixture.case_id, 'new-evidence'))
      .toEqual([{ due_at: '2026-09-22T15:00:00.000Z' }]);
  });

  it('corrects a case to a member-only subject after approval revalidation', () => {
    const binding = clone();
    const fixture = sql<{ case_id: string; version: number; member_id: string; account_id: string | null; evidence_id: string }>(`SELECT c.id AS case_id,c.version,c.member_id,c.account_id,v.id AS evidence_id
      FROM cases c JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
      WHERE c.dataset_id=? AND c.account_id IS NOT NULL AND v.status IN ('current','signed') AND v.media_type='application/pdf'
        AND NOT EXISTS (SELECT 1 FROM case_documents cd WHERE cd.dataset_id=v.dataset_id AND cd.document_version_id=v.id AND cd.visibility='restricted')
      ORDER BY c.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Case-subject correction fixture is missing.');
    const target = sql<{ member_id: string; account_id: string }>(`SELECT m.id AS member_id,a.id AS account_id FROM members m
      JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
      WHERE m.dataset_id=? AND m.id<>? AND m.status<>'merged' ORDER BY m.id,a.id LIMIT 1`, binding.datasetId, fixture.member_id)[0];
    if (target === undefined) throw new Error('Corrected case-subject target is missing.');
    expect(executeCommand(store, context(binding, 5), { kind: 'case.subject.correct', caseId: fixture.case_id, expectedVersion: fixture.version,
      correctMemberId: fixture.member_id, correctAccountId: fixture.account_id, evidenceVersionId: fixture.evidence_id,
      approvalId: 'not-required-for-unchanged' }, 'case-subject-unchanged')).toMatchObject({ kind: 'unchanged' });
    expect(executeCommand(store, context(binding, 5), { kind: 'case.subject.correct', caseId: fixture.case_id, expectedVersion: fixture.version,
      correctMemberId: target.member_id, correctAccountId: fixture.account_id, evidenceVersionId: fixture.evidence_id,
      approvalId: 'pending-approval-id' }, 'case-subject-wrong-account')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    const correction = { kind: 'case.subject.correct' as const, caseId: fixture.case_id, expectedVersion: fixture.version,
      correctMemberId: target.member_id, correctAccountId: null, evidenceVersionId: fixture.evidence_id, approvalId: 'pending-approval-id' };
    const approvalId = approve(binding, correction, 'case-subject-null-account');
    using fixtureDatabase = new DatabaseSync(path);
    fixtureDatabase.prepare('UPDATE cases SET version=version+1 WHERE dataset_id=? AND id=?').run(binding.datasetId, fixture.case_id);
    expect(executeCommand(store, context(binding, 5), { ...correction, approvalId }, 'case-subject-stale-after-approval'))
      .toMatchObject({ kind: 'rejected', code: 'stale_version' });
    fixtureDatabase.prepare('UPDATE cases SET version=? WHERE dataset_id=? AND id=?').run(fixture.version, binding.datasetId, fixture.case_id);
    fixtureDatabase.prepare("UPDATE document_versions SET status='superseded' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_id);
    expect(executeCommand(store, context(binding, 5), { ...correction, approvalId }, 'case-subject-evidence-changed'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    fixtureDatabase.prepare("UPDATE document_versions SET status='current' WHERE dataset_id=? AND id=?").run(binding.datasetId, fixture.evidence_id);
    expect(committed(executeCommand(store, context(binding, 5), { ...correction, approvalId }, 'case-subject-correct')).result)
      .toMatchObject({ caseId: fixture.case_id, memberId: target.member_id, accountId: null });
    expect(sql<{ member_id: string; account_id: string | null; visibility: string }>(`SELECT c.member_id,c.account_id,q.visibility FROM cases c
      JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id WHERE c.dataset_id=? AND c.id=?`, binding.datasetId, fixture.case_id))
      .toEqual([{ member_id: target.member_id, account_id: null, visibility: 'restricted' }]);
  });

  it('preserves omitted draft fields and attachments and rejects stale submit and withdrawal', () => {
    const binding = clone();
    const fixture = sql<{ member_id: string; account_id: string; account_version: number; version_id: string }>(`SELECT a.member_id,a.id AS account_id,a.version AS account_version,v.id AS version_id FROM accounts a
      JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id WHERE a.dataset_id=? ORDER BY a.id,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Draft fixture is missing.');
    const saved = committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.save', memberId: fixture.member_id, accountId: fixture.account_id,
      category: 'contact-review', subject: 'Review address evidence', requestedCommand: { kind: 'account.nickname.update', accountId: fixture.account_id,
        expectedVersion: fixture.account_version, nickname: 'Approved service nickname' }, missingFields: ['reason'],
      evidenceDocumentVersionIds: [fixture.version_id] }, 'draft-save-0001'));
    const requestId = saved.affected.find(record => record.kind === 'maintenance-request')?.id ?? '';
    const initial = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (initial.kind !== 'authorized' || initial.value === undefined) throw new Error('Saved draft is missing.');
    const amended = committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.amend', requestId, expectedUpdatedAt: initial.value.updatedAt,
      patch: { reason: 'customer-request', note: 'Verified by the servicing desk.', missingFields: [] } }, 'draft-amend-0001'));
    expect(amended.operationKind).toBe('maintenance.draft.amend');
    const current = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (current.kind !== 'authorized' || current.value === undefined) throw new Error('Amended draft is missing.');
    expect(current.value.attachments).toEqual(initial.value.attachments);
    expect(current.value.updatedAt).not.toBe(initial.value.updatedAt);
    expect(executeCommand(store, context(binding), { kind: 'maintenance.request.submit', requestId, expectedUpdatedAt: initial.value.updatedAt, declaredState: 'submitted' }, 'draft-submit-stale')).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    committed(executeCommand(store, context(binding), { kind: 'maintenance.request.submit', requestId, expectedUpdatedAt: current.value.updatedAt, declaredState: 'submitted' }, 'draft-submit-0001'));
    const submitted = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (submitted.kind !== 'authorized' || submitted.value === undefined) throw new Error('Submitted request is missing.');
    committed(executeCommand(store, context(binding, 5), { kind: 'maintenance.request.review', requestId, expectedUpdatedAt: submitted.value.updatedAt,
      decision: 'return-for-information', reason: 'Supporting confirmation is still required.', missingFields: ['supporting-confirmation'] }, 'request-return-info'));
    const returned = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (returned.kind !== 'authorized' || returned.value === undefined) throw new Error('Returned request is missing.');
    expect(returned.value).toMatchObject({ state: 'draft', draft: { missingFields: ['supporting-confirmation'] } });
    committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.amend', requestId, expectedUpdatedAt: returned.value.updatedAt,
      patch: { note: 'Supporting confirmation received.', missingFields: [] } }, 'request-return-amend'));
    const ready = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (ready.kind !== 'authorized' || ready.value === undefined) throw new Error('Completed returned request is missing.');
    committed(executeCommand(store, context(binding), { kind: 'maintenance.request.submit', requestId, expectedUpdatedAt: ready.value.updatedAt, declaredState: 'submitted' }, 'request-resubmit'));
    const resubmitted = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (resubmitted.kind !== 'authorized' || resubmitted.value === undefined) throw new Error('Resubmitted request is missing.');
    committed(executeCommand(store, context(binding, 5), { kind: 'maintenance.request.review', requestId, expectedUpdatedAt: resubmitted.value.updatedAt,
      decision: 'approve', reason: 'Complete request approved for processing.' }, 'request-approve'));
    const approved = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (approved.kind !== 'authorized' || approved.value === undefined) throw new Error('Approved request is missing.');
    const processed = committed(executeCommand(store, context(binding, 5), { kind: 'maintenance.request.process', requestId, expectedUpdatedAt: approved.value.updatedAt,
      disposition: 'reject', reason: 'No eligible business effect exists.' }, 'request-process-reject'));
    expect(processed.result).toMatchObject({ state: 'rejected', appliedReceiptId: null, businessChangeApplied: false });

    const withdrawSaved = committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.save', memberId: fixture.member_id, accountId: null,
      category: 'profile-review', subject: 'Withdraw test', requestedCommand: { kind: 'member.note.add', memberId: fixture.member_id,
        visibility: 'general', text: 'Requested servicing follow-up.' }, missingFields: [] }, 'draft-save-0002'));
    const withdrawId = withdrawSaved.affected.find(record => record.kind === 'maintenance-request')?.id ?? '';
    const withdraw = store.read(database => maintenanceRequest(database, context(binding), withdrawId));
    if (withdraw.kind !== 'authorized' || withdraw.value === undefined) throw new Error('Withdrawal draft is missing.');
    expect(executeCommand(store, context(binding), { kind: 'maintenance.request.withdraw', requestId: withdrawId, expectedUpdatedAt: '2020-01-01T00:00:00.000Z', reason: 'Created in error' }, 'draft-withdraw-stale')).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    committed(executeCommand(store, context(binding), { kind: 'maintenance.request.withdraw', requestId: withdrawId, expectedUpdatedAt: withdraw.value.updatedAt, reason: 'Created in error' }, 'draft-withdraw-0001'));
    expect(sql('SELECT state,applied_receipt_id FROM maintenance_requests WHERE dataset_id=? AND id=?', binding.datasetId, withdrawId)).toEqual([{ state: 'withdrawn', applied_receipt_id: null }]);
  });

  it('qualifies maintenance draft identities, nullable scope, and attachment boundaries', () => {
    const binding = clone();
    const fixtures = sql<{ member_id: string; account_id: string; account_version: number; party_id: string; version_id: string }>(`SELECT m.id AS member_id,a.id AS account_id,a.version AS account_version,m.party_id,v.id AS version_id
      FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
      JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
      WHERE m.dataset_id=? AND a.status<>'closed' ORDER BY m.id,a.id,v.id`, binding.datasetId);
    const own = fixtures[0]; const foreign = fixtures.find(row => row.member_id !== own?.member_id);
    if (own === undefined || foreign === undefined) throw new Error('Maintenance attachment fixtures are missing.');
    const memberOnly = { kind: 'maintenance.draft.save' as const, memberId: own.member_id, accountId: null,
      requestId: 'maintenance-explicit-member-only', requestNumber: 'MR-EXPLICIT-MEMBER', category: 'profile-review', subject: 'Explicit member-only request',
      requestedCommand: { kind: 'member.note.add' as const, memberId: own.member_id, visibility: 'general' as const, text: 'Pending member-only review.' },
      missingFields: ['reason'], evidenceDocumentVersionIds: [own.version_id] };
    committed(executeCommand(store, context(binding), memberOnly, 'maintenance-explicit-null'));
    expect(executeCommand(store, context(binding), { ...memberOnly, requestNumber: 'MR-OTHER-NUMBER' }, 'maintenance-id-collision'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding), { ...memberOnly, requestId: 'maintenance-other-id' }, 'maintenance-number-collision'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding), { ...memberOnly, requestId: 'maintenance-duplicate-attachments', requestNumber: 'MR-DUPLICATE-ATTACH',
      evidenceDocumentVersionIds: [own.version_id, own.version_id] }, 'maintenance-duplicate-attachments'))
      .toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding), { ...memberOnly, requestId: 'maintenance-foreign-evidence', requestNumber: 'MR-FOREIGN-EVIDENCE',
      evidenceDocumentVersionIds: [foreign.version_id] }, 'maintenance-foreign-evidence'))
      .toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    const automaticAccount = committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.save', memberId: own.member_id,
      accountId: own.account_id, category: 'account-review', subject: 'Automatic account request identity', requestedCommand: { kind: 'account.nickname.update',
        accountId: own.account_id, expectedVersion: own.account_version, nickname: 'Pending automatic identity' }, missingFields: ['reason'] }, 'maintenance-auto-account'));
    expect(typeof automaticAccount.result?.requestId === 'string' && automaticAccount.result.requestId.startsWith('maintenance-request-')).toBe(true);
    expect(typeof automaticAccount.result?.requestNumber === 'string' && automaticAccount.result.requestNumber.length > 0).toBe(true);
  });

  it('amends each maintenance draft field independently and replaces then removes attachments', () => {
    const binding = clone();
    const fixture = sql<{ member_id: string; account_id: string; account_version: number }>(`SELECT m.id AS member_id,a.id AS account_id,a.version AS account_version
      FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id WHERE m.dataset_id=? AND a.status<>'closed' ORDER BY a.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Maintenance amendment fixture is missing.');
    const versions = sql<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id WHERE v.dataset_id=? AND m.id=? ORDER BY v.id LIMIT 2`,
    binding.datasetId, fixture.member_id).map(row => row.id);
    const firstVersion = versions[0]; const secondVersion = versions[1];
    if (firstVersion === undefined || secondVersion === undefined) throw new Error('Maintenance amendment needs two owned attachments.');
    const saved = committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.save', memberId: fixture.member_id,
      accountId: fixture.account_id, category: 'account-review', subject: 'Initial draft subject', requestedCommand: { kind: 'account.nickname.update',
        accountId: fixture.account_id, expectedVersion: fixture.account_version, nickname: 'Initial pending nickname' }, note: 'Initial note',
      missingFields: ['reason'], evidenceDocumentVersionIds: [firstVersion] }, 'maintenance-amend-all-save'));
    const requestId = saved.affected.find(record => record.kind === 'maintenance-request')?.id ?? '';
    let current = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (current.kind !== 'authorized' || current.value === undefined) throw new Error('Maintenance amendment draft is missing.');
    type DraftPatch = Extract<ServicingCommand, { kind: 'maintenance.draft.amend' }>['patch'];
    const amend = (patch: DraftPatch, index: number): void => {
      if (current.kind !== 'authorized' || current.value === undefined) throw new Error('Maintenance amendment state is missing.');
      committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.amend', requestId,
        expectedUpdatedAt: current.value.updatedAt, patch }, `maintenance-amend-field-${index}`));
      current = store.read(database => maintenanceRequest(database, context(binding), requestId));
    };
    amend({ subject: 'Amended subject' }, 1);
    amend({ reason: 'customer-request' }, 2);
    amend({ note: 'Amended note' }, 3);
    amend({ requestedCommand: { kind: 'account.nickname.update', accountId: fixture.account_id, expectedVersion: fixture.account_version,
      nickname: 'Amended pending nickname' } }, 4);
    amend({ missingFields: [] }, 5);
    amend({ evidenceVersionId: secondVersion }, 6);
    expect(current).toMatchObject({ kind: 'authorized', value: { attachments: [{ documentVersionId: firstVersion }, { documentVersionId: secondVersion }] } });
    amend({ evidenceDocumentVersionIds: [secondVersion] }, 7);
    expect(current).toMatchObject({ kind: 'authorized', value: { attachments: [{ documentVersionId: secondVersion }] } });
    amend({ evidenceDocumentVersionIds: [] }, 8);
    expect(current).toMatchObject({ kind: 'authorized', value: { subject: 'Amended subject', reason: 'customer-request', attachments: [],
      draft: { note: 'Amended note', missingFields: [], requestedCommand: { nickname: 'Amended pending nickname' } } } });
  });

  it('withdraws draft, submitted, and approved requests while rejecting every terminal state', () => {
    const binding = clone();
    const fixture = sql<{ member_id: string }>('SELECT id AS member_id FROM members WHERE dataset_id=? AND status<>\'merged\' ORDER BY id LIMIT 1', binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Withdrawal state fixture is missing.');
    const save = (suffix: string): string => {
      const receipt = committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.save', memberId: fixture.member_id, accountId: null,
        requestId: `withdraw-${suffix}`, requestNumber: `MR-WITHDRAW-${suffix}`, category: 'profile-review', subject: `Withdrawal ${suffix}`,
        requestedCommand: { kind: 'member.note.add', memberId: fixture.member_id, visibility: 'general', text: `Pending withdrawal ${suffix}.` },
        missingFields: ['reason'] }, `withdraw-save-${suffix}`));
      return receipt.affected.find(record => record.kind === 'maintenance-request')?.id ?? '';
    };
    const read = (requestId: string) => {
      const result = store.read(database => maintenanceRequest(database, context(binding), requestId));
      if (result.kind !== 'authorized' || result.value === undefined) throw new Error(`Withdrawal request ${requestId} is missing.`);
      return result.value;
    };
    const ready = (suffix: string): string => {
      const requestId = save(suffix); const draft = read(requestId);
      committed(executeCommand(store, context(binding), { kind: 'maintenance.draft.amend', requestId, expectedUpdatedAt: draft.updatedAt,
        patch: { reason: 'customer-request', missingFields: [] } }, `withdraw-ready-${suffix}`));
      return requestId;
    };
    const withdraw = (requestId: string, suffix: string): void => {
      const request = read(requestId);
      committed(executeCommand(store, context(binding), { kind: 'maintenance.request.withdraw', requestId, expectedUpdatedAt: request.updatedAt,
        reason: `Withdraw ${suffix}.` }, `withdraw-${suffix}`));
    };

    withdraw(save('draft'), 'draft');
    const submittedId = ready('submitted'); const submitted = read(submittedId);
    committed(executeCommand(store, context(binding), { kind: 'maintenance.request.submit', requestId: submittedId,
      expectedUpdatedAt: submitted.updatedAt, declaredState: 'submitted' }, 'withdraw-submit-submitted'));
    withdraw(submittedId, 'submitted');
    const approvedId = ready('approved'); let approved = read(approvedId);
    committed(executeCommand(store, context(binding), { kind: 'maintenance.request.submit', requestId: approvedId,
      expectedUpdatedAt: approved.updatedAt, declaredState: 'submitted' }, 'withdraw-submit-approved'));
    approved = read(approvedId);
    committed(executeCommand(store, context(binding, 5), { kind: 'maintenance.request.review', requestId: approvedId,
      expectedUpdatedAt: approved.updatedAt, decision: 'approve', reason: 'Approved before member withdrawal.' }, 'withdraw-review-approved'));
    withdraw(approvedId, 'approved');

    const terminalStates = ['applied', 'rejected', 'withdrawn', 'cancelled'] as const;
    using fixtureDatabase = new DatabaseSync(path);
    for (const state of terminalStates) {
      const requestId = save(`terminal-${state}`); const request = read(requestId);
      fixtureDatabase.prepare('UPDATE maintenance_requests SET state=? WHERE dataset_id=? AND id=?').run(state, binding.datasetId, requestId);
      expect(executeCommand(store, context(binding), { kind: 'maintenance.request.withdraw', requestId, expectedUpdatedAt: request.updatedAt,
        reason: 'Terminal state cannot withdraw.' }, `withdraw-terminal-${state}`)).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    }

    const concurrentId = ready('concurrent'); const beforeSubmit = read(concurrentId);
    committed(executeCommand(store, context(binding), { kind: 'maintenance.request.submit', requestId: concurrentId,
      expectedUpdatedAt: beforeSubmit.updatedAt, declaredState: 'submitted' }, 'withdraw-concurrent-submit'));
    expect(executeCommand(store, context(binding), { kind: 'maintenance.request.withdraw', requestId: concurrentId,
      expectedUpdatedAt: beforeSubmit.updatedAt, reason: 'Stale approval state.' }, 'withdraw-concurrent-stale'))
      .toMatchObject({ kind: 'rejected', code: 'stale_version' });
  });

  it('binds maintenance application to exact post-approval command evidence', () => {
    const binding = clone();
    const sameTime = '2026-09-14T15:00:00.000Z';
    const fixture = sql<{ member_id: string; account_id: string; account_version: number }>('SELECT member_id,id AS account_id,version AS account_version FROM accounts WHERE dataset_id=? AND status<>\'closed\' ORDER BY id LIMIT 1', binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Maintenance application fixture is missing.');
    const requestedCommand = { kind: 'account.nickname.update' as const, accountId: fixture.account_id, expectedVersion: fixture.account_version, nickname: 'Approved service nickname' };
    const saved = committed(executeCommand(store, { ...context(binding), now: sameTime }, { kind: 'maintenance.draft.save', memberId: fixture.member_id,
      accountId: fixture.account_id, category: 'account-profile', subject: 'Apply approved nickname', requestedCommand, missingFields: ['reason'] }, 'maintenance-exact-save'));
    const requestId = saved.affected.find(record => record.kind === 'maintenance-request')?.id ?? '';
    const draft = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (draft.kind !== 'authorized' || draft.value === undefined) throw new Error('Exact maintenance draft is missing.');
    committed(executeCommand(store, { ...context(binding), now: sameTime }, { kind: 'maintenance.draft.amend', requestId,
      expectedUpdatedAt: draft.value.updatedAt, patch: { reason: 'customer-request', missingFields: [] } }, 'maintenance-exact-amend'));
    const amended = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (amended.kind !== 'authorized' || amended.value === undefined) throw new Error('Exact amended request is missing.');
    committed(executeCommand(store, { ...context(binding), now: sameTime }, { kind: 'maintenance.request.submit', requestId,
      expectedUpdatedAt: amended.value.updatedAt, declaredState: 'submitted' }, 'maintenance-exact-submit'));
    const submitted = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (submitted.kind !== 'authorized' || submitted.value === undefined) throw new Error('Exact submitted request is missing.');
    committed(executeCommand(store, { ...context(binding, 5), now: sameTime }, { kind: 'maintenance.request.review', requestId,
      expectedUpdatedAt: submitted.value.updatedAt, decision: 'approve', reason: 'Exact command terms approved.' }, 'maintenance-exact-approve'));
    const approved = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (approved.kind !== 'authorized' || approved.value === undefined) throw new Error('Exact approved request is missing.');
    const effect = committed(executeCommand(store, { ...context(binding), now: sameTime }, requestedCommand, 'maintenance-exact-effect'));
    const effectReceiptId = sql<{ id: string }>('SELECT id FROM operation_receipts WHERE dataset_id=? AND operation_id=?', binding.datasetId, effect.operationId)[0]?.id ?? '';
    const processed = committed(executeCommand(store, { ...context(binding, 5), now: sameTime }, { kind: 'maintenance.request.process', requestId,
      expectedUpdatedAt: approved.value.updatedAt, disposition: 'apply', reason: 'Verified exact committed effect.', appliedReceiptId: effectReceiptId }, 'maintenance-exact-process'));
    expect(processed.result).toMatchObject({ state: 'applied', appliedReceiptId: effectReceiptId, businessChangeApplied: true });
    expect(sql('SELECT nickname FROM accounts WHERE dataset_id=? AND id=?', binding.datasetId, fixture.account_id)).toEqual([{ nickname: requestedCommand.nickname }]);
  });

  it('rejects same-kind maintenance receipts committed before approval', () => {
    const binding = clone();
    const sameTime = '2026-09-14T15:00:00.000Z';
    const fixture = sql<{ member_id: string; account_id: string; account_version: number }>('SELECT member_id,id AS account_id,version AS account_version FROM accounts WHERE dataset_id=? AND status<>\'closed\' ORDER BY id LIMIT 1', binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Maintenance chronology fixture is missing.');
    const unrelated = committed(executeCommand(store, { ...context(binding), now: sameTime }, { kind: 'account.nickname.update', accountId: fixture.account_id,
      expectedVersion: fixture.account_version, nickname: 'Unrelated nickname' }, 'maintenance-old-other'));
    const requestedCommand = { kind: 'account.nickname.update' as const, accountId: fixture.account_id, expectedVersion: fixture.account_version + 1, nickname: 'Premature requested nickname' };
    const premature = committed(executeCommand(store, { ...context(binding), now: sameTime }, requestedCommand, 'maintenance-old-exact'));
    const saved = committed(executeCommand(store, { ...context(binding), now: sameTime }, { kind: 'maintenance.draft.save', memberId: fixture.member_id,
      accountId: fixture.account_id, category: 'account-profile', subject: 'Late approval attempt', requestedCommand, missingFields: ['reason'] }, 'maintenance-old-save'));
    const requestId = saved.affected.find(record => record.kind === 'maintenance-request')?.id ?? '';
    const draft = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (draft.kind !== 'authorized' || draft.value === undefined) throw new Error('Chronology draft is missing.');
    committed(executeCommand(store, { ...context(binding), now: sameTime }, { kind: 'maintenance.draft.amend', requestId,
      expectedUpdatedAt: draft.value.updatedAt, patch: { reason: 'customer-request', missingFields: [] } }, 'maintenance-old-amend'));
    const amended = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (amended.kind !== 'authorized' || amended.value === undefined) throw new Error('Chronology amended request is missing.');
    committed(executeCommand(store, { ...context(binding), now: sameTime }, { kind: 'maintenance.request.submit', requestId,
      expectedUpdatedAt: amended.value.updatedAt, declaredState: 'submitted' }, 'maintenance-old-submit'));
    const submitted = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (submitted.kind !== 'authorized' || submitted.value === undefined) throw new Error('Chronology submitted request is missing.');
    committed(executeCommand(store, { ...context(binding, 5), now: sameTime }, { kind: 'maintenance.request.review', requestId,
      expectedUpdatedAt: submitted.value.updatedAt, decision: 'approve', reason: 'Terms reviewed after the claimed effects.' }, 'maintenance-old-approve'));
    const approved = store.read(database => maintenanceRequest(database, context(binding), requestId));
    if (approved.kind !== 'authorized' || approved.value === undefined) throw new Error('Chronology approved request is missing.');
    const unrelatedReceiptId = sql<{ id: string }>('SELECT id FROM operation_receipts WHERE dataset_id=? AND operation_id=?', binding.datasetId, unrelated.operationId)[0]?.id ?? '';
    const prematureReceiptId = sql<{ id: string }>('SELECT id FROM operation_receipts WHERE dataset_id=? AND operation_id=?', binding.datasetId, premature.operationId)[0]?.id ?? '';
    const approvedUpdatedAt = approved.value.updatedAt;
    const process = (appliedReceiptId: string) => ({ kind: 'maintenance.request.process' as const, requestId, expectedUpdatedAt: approvedUpdatedAt,
      disposition: 'apply' as const, reason: 'Attempt to link an old receipt.', appliedReceiptId });
    expect(executeCommand(store, { ...context(binding, 5), now: sameTime }, process(unrelatedReceiptId), 'maintenance-old-wrong')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    expect(executeCommand(store, { ...context(binding, 5), now: sameTime }, process(prematureReceiptId), 'maintenance-old-before')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(sql('SELECT state,applied_receipt_id FROM maintenance_requests WHERE dataset_id=? AND id=?', binding.datasetId, requestId)).toEqual([{ state: 'approved', applied_receipt_id: null }]);
    expect(sql('SELECT nickname FROM accounts WHERE dataset_id=? AND id=?', binding.datasetId, fixture.account_id)).toEqual([{ nickname: requestedCommand.nickname }]);
  });
});
