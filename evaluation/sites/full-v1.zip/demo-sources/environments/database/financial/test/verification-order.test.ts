import { dirname, join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { checkEvidenceReconstruction, closeRunEvidence, createRun, loadRunEvidence, selectSnapshotRows } from '../src/verification.js';
import type { VerificationRun } from '../src/verification.js';
import type { DatasetId, InstitutionId } from '../src/model.js';
import { createSchema } from '../src/schema.js';
import { createCoreSeedFixture, createTestDatabasePath } from './conftest.js';

describe('verification snapshot ordering', () => {
  let target: ReturnType<typeof createTestDatabasePath>;
  let fixture: ReturnType<typeof createCoreSeedFixture>;
  let run: VerificationRun;

  beforeEach(async () => {
    target = createTestDatabasePath();
    fixture = createCoreSeedFixture(target.path);
    fixture.database.exec(`
      CREATE TABLE native_order (
        bucket TEXT NOT NULL,
        position INTEGER NOT NULL,
        text_key TEXT NOT NULL,
        score REAL NOT NULL,
        value TEXT NOT NULL,
        bytes BLOB,
        PRIMARY KEY(bucket,position,text_key,score)
      ) STRICT;
      INSERT INTO native_order VALUES
        ('same',10,'z',1,'ten',x'01'),
        ('same',2,'😀',1,'two-emoji',x'02'),
        ('same',2,'é',1,'two-accent',x'03'),
        ('same',2,'A',1,'two-ascii',x'04'),
        ('same',2,'􏿿',1,'two-max',x'05'),
        ('same',-9007199254740993,'negative',1,'negative',x'06'),
        ('same',9007199254740993,'large',1,'large',x'07'),
        ('same',9007199254740993,'large',-1.5,'real-low',x'08');
      CREATE TABLE nullable_order (part INTEGER,name TEXT,value TEXT,PRIMARY KEY(part,name));
      INSERT INTO nullable_order VALUES (NULL,'one','first'),(NULL,'two','second');
      CREATE TABLE blob_order (id BLOB PRIMARY KEY,value TEXT);
      INSERT INTO blob_order VALUES (x'01','one'),(x'02','two');
      CREATE TABLE nocase_order (id TEXT PRIMARY KEY COLLATE NOCASE,value TEXT) STRICT;
      INSERT INTO nocase_order VALUES ('a','one');
    `);
    run = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'order' });
  });

  afterEach(() => { run.close(); fixture.database.close(); target.cleanup(); });

  it('uses native binary strict primary-key order and preserves generic canonical fallback', () => {
    const before = run.begin();
    expect(before.tables.native_order?.ordering).toBe('sqlite-pk-v1');
    expect(before.tables.native_order?.primaryKeyTypes).toEqual(['TEXT', 'INTEGER', 'TEXT', 'REAL']);
    expect(before.tables.nullable_order?.ordering).toBe('canonical-json-v1');
    expect(before.tables.blob_order?.ordering).toBe('canonical-json-v1');
    expect(before.tables.nocase_order?.ordering).toBe('canonical-json-v1');
    expect([...selectSnapshotRows(before, 'native_order')].map((row) => [row.position, row.text_key, row.score, row.value])).toEqual([
      [{ kind: 'integer', decimal: '-9007199254740993' }, 'negative', 1, 'negative'],
      [2, 'A', 1, 'two-ascii'],
      [2, 'é', 1, 'two-accent'],
      [2, '😀', 1, 'two-emoji'],
      [2, '􏿿', 1, 'two-max'],
      [10, 'z', 1, 'ten'],
      [{ kind: 'integer', decimal: '9007199254740993' }, 'large', -1.5, 'real-low'],
      [{ kind: 'integer', decimal: '9007199254740993' }, 'large', 1, 'large'],
    ]);
    expect([...selectSnapshotRows(before, 'nullable_order', { part: null })].map((row) => row.name)).toHaveLength(2);
    expect([...selectSnapshotRows(before, 'blob_order')]).toHaveLength(2);
  });

  it('merges native-order overlays after insert, delete, and primary-key movement', () => {
    run.begin();
    run.write({ kind: 'automation', reference: 'native-order' }, (database) => database.exec(`
      UPDATE native_order SET position=-2,text_key='moved',value='moved',bytes=x'ff' WHERE bucket='same' AND position=10;
      DELETE FROM native_order WHERE bucket='same' AND position=2 AND text_key='A';
      INSERT INTO native_order VALUES ('same',3,'inserted',0,'inserted',x'616263');
      UPDATE blob_order SET id=x'03',value='moved' WHERE id=x'01';
    `));
    const evidence = run.finish();
    expect(evidence.captureComplete).toBe(true);
    expect(checkEvidenceReconstruction(evidence)).toEqual([]);
    expect([...selectSnapshotRows(evidence.after, 'native_order')].map((row) => [row.position, row.text_key, row.value])).toEqual([
      [{ kind: 'integer', decimal: '-9007199254740993' }, 'negative', 'negative'],
      [-2, 'moved', 'moved'],
      [2, 'é', 'two-accent'],
      [2, '😀', 'two-emoji'],
      [2, '􏿿', 'two-max'],
      [3, 'inserted', 'inserted'],
      [{ kind: 'integer', decimal: '9007199254740993' }, 'large', 'real-low'],
      [{ kind: 'integer', decimal: '9007199254740993' }, 'large', 'large'],
    ]);
    const blobValues = [...selectSnapshotRows(evidence.after, 'blob_order')].map((row) => {
      if (typeof row.value !== 'string') throw new Error('Expected BLOB fallback row value to remain text.');
      return row.value;
    });
    expect(blobValues.toSorted()).toEqual(['moved', 'two']);
    const reopened = loadRunEvidence(evidence.descriptor.evidencePath);
    expect(checkEvidenceReconstruction(reopened)).toEqual([]);
    expect([...selectSnapshotRows(reopened.after, 'native_order')].map((row) => row.value)).toEqual([
      'negative', 'moved', 'two-accent', 'two-emoji', 'two-max', 'inserted', 'real-low', 'large',
    ]);
    const reopenedBlobValues = [...selectSnapshotRows(reopened.after, 'blob_order')].map((row) => {
      if (typeof row.value !== 'string') throw new Error('Expected reopened BLOB fallback row value to remain text.');
      return row.value;
    });
    expect(reopenedBlobValues.toSorted()).toEqual(['moved', 'two']);
    closeRunEvidence(reopened);
  });

  it('does not push replacement-character text filters into SQLite', () => {
    run.prepare((database) => database.exec(`
      CREATE TABLE malformed_text (id TEXT PRIMARY KEY,label TEXT NOT NULL) STRICT;
      INSERT INTO malformed_text VALUES ('invalid',CAST(x'80' AS TEXT)),('replacement','�');
    `));
    const before = run.begin();
    expect([...selectSnapshotRows(before, 'malformed_text', { label: '�' })].map((row) => row.id).toSorted()).toEqual(['invalid', 'replacement']);
  });

  it('rejects strict native primary keys whose SQLite byte order conflicts with normalized text order', async () => {
    run.close();
    fixture.database.exec(`
      CREATE TABLE malformed_key (id TEXT PRIMARY KEY,value TEXT NOT NULL) STRICT;
      INSERT INTO malformed_key VALUES (CAST(x'80' AS TEXT),'invalid'),('😀','emoji'),(CAST(x'FF' AS TEXT),'invalid-late');
    `);
    run = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'invalid-key-order' });
    expect(() => run.begin()).toThrow(/primary key.*normaliz/i);
  });
});

describe('UTF-16 verification snapshot ordering', () => {
  it.each(['UTF-16le', 'UTF-16be'])('uses UTF-8 canonical keys and replays them for %s databases', async (encoding) => {
    const target = createTestDatabasePath();
    const database = new DatabaseSync(target.path);
    let run: VerificationRun | undefined;
    let reopened: ReturnType<typeof loadRunEvidence> | undefined;
    try {
      database.exec(`PRAGMA encoding='${encoding}';`);
      createSchema(database);
      database.prepare('INSERT INTO institutions VALUES (?,?,?,?,?,?)').run('northstar', 'Northstar Cooperative', 'Northstar', 'US', 'America/Chicago', 'USD');
      database.prepare('INSERT INTO datasets VALUES (?,?,?,?,?,?,?,?,?)').run('domain-test', 'northstar', 'domain-test', 42, 'small', '2026-09-14T15:00:00.000Z', '1', 1, 0);
      database.exec(`
        CREATE TABLE utf16_text_order (id TEXT PRIMARY KEY,value TEXT NOT NULL) STRICT;
        INSERT INTO utf16_text_order VALUES ('a','a'),('','80'),('Ā','100'),('＀','ff00'),('𐀀','10000');
        CREATE TABLE utf16_numeric_order (id INTEGER PRIMARY KEY,value TEXT NOT NULL) STRICT;
        INSERT INTO utf16_numeric_order VALUES (2,'two'),(1,'one');
      `);
      run = await createRun({
        root: join(dirname(target.path), 'runs'),
        sourcePath: target.path,
        bindings: [{ institutionId: 'northstar' as InstitutionId, datasetId: 'domain-test' as DatasetId }],
        contractDigest: `utf16-${encoding}`,
      });

      const before = run.begin();
      expect(before.tables.utf16_text_order?.ordering).toBe('canonical-json-v1');
      expect(before.tables.utf16_numeric_order?.ordering).toBe('sqlite-pk-v1');
      expect([...selectSnapshotRows(before, 'utf16_text_order')].map((row) => row.id)).toEqual(['a', '', 'Ā', '＀', '𐀀']);
      expect([...selectSnapshotRows(before, 'utf16_numeric_order')].map((row) => row.id)).toEqual([1, 2]);

      run.write({ kind: 'automation', reference: 'utf16-text-key-move' }, (writer) => writer.exec("UPDATE utf16_text_order SET id='b',value='b' WHERE id='a'"));
      const evidence = run.finish();
      expect(checkEvidenceReconstruction(evidence)).toEqual([]);
      expect([...selectSnapshotRows(evidence.after, 'utf16_text_order')].map((row) => row.id)).toEqual(['b', '', 'Ā', '＀', '𐀀']);

      reopened = loadRunEvidence(evidence.descriptor.evidencePath);
      expect(checkEvidenceReconstruction(reopened)).toEqual([]);
      expect([...selectSnapshotRows(reopened.after, 'utf16_text_order')].map((row) => row.id)).toEqual(['b', '', 'Ā', '＀', '𐀀']);
    } finally {
      if (reopened !== undefined) closeRunEvidence(reopened);
      run?.close();
      database.close();
      target.cleanup();
    }
  });
});
