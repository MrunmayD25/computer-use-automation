import {DatabaseSync} from 'node:sqlite';
import {expect,it,vi} from 'vitest';
import {createCoreSeedFixture,createTestDatabasePath} from './conftest.js';
import {seedCore} from '../src/seed/core.js';
import {openFinancialDatabase} from '../src/public.js';

it('clones the revision and business rows from the same transaction snapshot', () => {
  const target=createTestDatabasePath();
  try {
    const context=createCoreSeedFixture(target.path);
    seedCore(context);
    context.database.close();
    using database=openFinancialDatabase({path:target.path});
    const originalExec=Object.getOwnPropertyDescriptor(DatabaseSync.prototype,'exec')?.value as
      ((this:DatabaseSync,sql:string)=>void) | undefined;
    if (!originalExec) throw new Error('Expected original SQLite exec implementation.');
    const spy=vi.spyOn(DatabaseSync.prototype,'exec');
    let armed=true;
    spy.mockImplementation(function(this:DatabaseSync,sql:string):void {
      if(armed && sql==='BEGIN IMMEDIATE') {
        armed=false;
        using peer=new DatabaseSync(target.path);
        originalExec.call(peer,'BEGIN IMMEDIATE');
        peer.prepare('UPDATE datasets SET revision=99 WHERE id=?').run(context.binding.datasetId);
        peer.prepare("UPDATE contact_points SET value='peer@example.test' WHERE dataset_id=? AND id='email-1'").run(context.binding.datasetId);
        originalExec.call(peer,'COMMIT');
      }
      originalExec.call(this,sql);
    });
    try {
      const clone=database.cloneDataset(context.binding,'coherent-clone');
      using inspection=new DatabaseSync(target.path,{readOnly:true});
      expect(inspection.prepare('SELECT revision FROM datasets WHERE id=?').get(clone.datasetId)?.revision).toBe(99);
      expect(inspection.prepare("SELECT value FROM contact_points WHERE dataset_id=? AND id='email-1'").get(clone.datasetId)?.value).toBe('peer@example.test');
      expect(inspection.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
      const page = database.dataset(context.binding).members.list({ limit: 1 });
      if (!page.nextCursor) throw new Error('Expected member page cursor.');
      expect(() => database.dataset(clone).members.list({ limit: 1, cursor: page.nextCursor ?? '' })).toThrow(/cursor/i);
      expect(() => database.dataset(context.binding).accounts.list({ limit: 1, cursor: page.nextCursor ?? '' })).toThrow(/cursor/i);
    } finally {spy.mockRestore();}
  } finally {target.cleanup();}
});
