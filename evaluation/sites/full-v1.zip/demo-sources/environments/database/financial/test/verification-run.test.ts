import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { closeRunEvidence, createRun, loadRunEvidence, selectSnapshotRows } from '../src/verification.js';
import type { CapturedRow, CapturedValue, RunSnapshot, RunSqlDatabase, VerificationRun } from '../src/verification.js';
import { createCoreSeedFixture, createTestDatabasePath } from './conftest.js';
const actor = { kind: 'automation', reference: 'session-1', actorId: 'operator' } as const;
function snapshotRows(snapshot: RunSnapshot, table: string, equals: Readonly<Record<string, CapturedValue>> = {}): CapturedRow[] {
  return [...selectSnapshotRows(snapshot, table, equals)];
}
describe('trusted verification runs', () => {
  let target: ReturnType<typeof createTestDatabasePath>;
  let fixture: ReturnType<typeof createCoreSeedFixture>;
  let run: VerificationRun;
  beforeEach(async () => {
    target = createTestDatabasePath(); fixture = createCoreSeedFixture(target.path);
    fixture.database.exec('PRAGMA journal_mode=WAL');
    fixture.database.prepare('INSERT INTO addresses VALUES (?,?,?,?,?,?,?,?)').run('domain-test', 'address-1', 'Original', null, 'Chicago', 'IL', '60601', 'US');
    run = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'contract-a' });
  });
  afterEach(() => { run.close(); fixture.database.close(); target.cleanup(); });
  it('backs up current WAL data and isolates changes from source and another run', async () => {
    const second = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'contract-b' });
    try {
      run.begin(); run.write(actor, (db) => { db.exec("UPDATE addresses SET line1='Changed'"); });
      expect(snapshotRows(run.finish().after, 'addresses')[0]?.line1).toBe('Changed');
      expect(snapshotRows(second.begin(), 'addresses')[0]?.line1).toBe('Original'); second.finish();
      expect(fixture.database.prepare('SELECT line1 FROM addresses').get()?.line1).toBe('Original');
    } finally { second.close(); }
  });
  it('retains wrong then restored changes and discards transaction rollback', () => {
    const before = run.begin();
    expect(() => run.write(actor, (db) => { db.exec("UPDATE addresses SET line1='Rollback'"); throw new Error('reject'); })).toThrow('reject');
    run.write(actor, (db) => { db.exec("UPDATE addresses SET line1='Wrong'"); });
    run.write(actor, (db) => { db.exec("UPDATE addresses SET line1='Original'"); });
    const evidence = run.finish();
    expect(evidence.after.tables.addresses).toEqual(before.tables.addresses);
    expect(evidence.transactions.flatMap((tx) => tx.changes)).toMatchObject([{ before: { line1: 'Original' }, after: { line1: 'Wrong' } }, { before: { line1: 'Wrong' }, after: { line1: 'Original' } }]);
    expect(evidence.captureComplete).toBe(true);
  });
  it('keeps multi-write effects scoped to their recorded principals', () => {
    const peer = { kind: 'peer', reference: 'peer-session', actorId: 'peer-operator' } as const;
    run.begin();
    run.write(actor, (db) => { db.exec("UPDATE addresses SET line1='Automation value'"); });
    run.write(peer, (db) => { db.exec("UPDATE addresses SET city='Evanston'"); });
    const evidence = run.finish();
    expect(evidence.transactions.map(({ context, changes }) => ({ context, tables: changes.map(({ table }) => table) }))).toEqual([
      { context: actor, tables: ['addresses'] },
      { context: peer, tables: ['addresses'] },
    ]);
  });
  it('reads coherently through the owned connection without recording an empty write', () => {
    expect(() => run.read(() => undefined)).toThrow(/begin|running/i);
    run.begin();
    expect(run.read((db) => db.prepare('SELECT line1 FROM addresses').get()?.line1)).toBe('Original');
    expect(() => run.read((db) => db.exec("UPDATE addresses SET line1='Read mutation'"))).toThrow(/authoriz|read|denied/i);
    const evidence = run.finish();
    expect(evidence.transactions).toEqual([]);
    expect(() => run.read(() => undefined)).toThrow(/sealed|running/i);
  });
  it('revokes an iterator method retained after a read callback', () => {
    let next: (() => IteratorResult<Record<string, unknown>>) | undefined;
    run.begin();
    run.read((db) => {
      const iterator = db.prepare('SELECT line1 FROM addresses').iterate();
      next = iterator.next.bind(iterator);
    });
    expect(() => next?.()).toThrow(/ended|transaction/i);
    run.finish();
  });
  it('requires begin and refuses unregistered and escaped connections', () => {
    expect(() => run.write(actor, () => undefined)).toThrow(/begin|running/i); run.begin();
    const raw = new DatabaseSync(run.descriptor().databasePath);
    expect(() => raw.exec("UPDATE addresses SET line1='Raw'")).toThrow(); raw.close();
    let escaped: RunSqlDatabase | undefined;
    let escapedStatement: ReturnType<RunSqlDatabase['prepare']> | undefined;
    run.write(actor, (db) => { escaped = db; escapedStatement = db.prepare("UPDATE addresses SET line1='Escaped statement'"); });
    expect(() => escaped?.exec("UPDATE addresses SET line1='Escaped'")).toThrow(); run.finish();
    expect(() => escapedStatement?.run()).toThrow(/ended|transaction/i);
    expect(() => run.write(actor, () => undefined)).toThrow(/sealed|running/i);
  });
  it('closes a running database and invalidates its snapshot readers', () => {
    const before = run.begin();
    run.close();
    expect(() => snapshotRows(before, 'addresses')).toThrow(/closed/i);
    expect(() => run.read(() => undefined)).toThrow(/closed|running/i);
    expect(() => run.finish()).toThrow(/closed|running/i);
    run.close();
  });
  it('denies attached-database changes from running callbacks', () => {
    run.begin();
    expect(() => run.write(actor, (db) => {
      db.prepare('ATTACH DATABASE ? AS source_db').run(target.path);
      db.exec("UPDATE source_db.addresses SET line1='Source modified'");
    })).toThrow(/authoriz|attach|denied/i);
    const evidence = run.finish();
    expect(evidence.captureComplete).toBe(true);
    expect(evidence.transactions).toEqual([]);
    expect(fixture.database.prepare('SELECT line1 FROM addresses').get()?.line1).toBe('Original');
  });
  it('denies callback attempts to replace guards or control the transaction', () => {
    run.begin();
    expect(() => run.write(actor, (db) => {
      const leaked = (db as unknown as { valueOf(): DatabaseSync }).valueOf();
      (leaked as unknown as { setAuthorizer(authorizer: null): void }).setAuthorizer(null);
      leaked.exec('DROP TRIGGER __verification_0_update');
    })).toThrow(/function|control|authoriz|available/i);
    expect(() => run.write(actor, (db) => {
      (db as unknown as { setAuthorizer(authorizer: null): void }).setAuthorizer(null);
    })).toThrow(/control|authoriz/i);
    expect(() => run.write(actor, (db) => {
      db.exec('COMMIT; BEGIN IMMEDIATE');
    })).toThrow(/authoriz|transaction|denied/i);
    const evidence = run.finish();
    expect(evidence.captureComplete).toBe(true);
    expect(evidence.transactions).toEqual([]);
  });
  it('denies attached-database changes while preparing the isolated fixture', () => {
    expect(() => run.prepare((db) => {
      db.prepare('ATTACH DATABASE ? AS source_db').run(target.path);
      db.exec("UPDATE source_db.addresses SET line1='Source modified during prepare'");
    })).toThrow(/authoriz|attach|denied/i);
    expect(fixture.database.prepare('SELECT line1 FROM addresses').get()?.line1).toBe('Original');
  });
  it('rejects prepared schema objects that impersonate verifier capture triggers', () => {
    run.prepare((db) => {
      db.exec(`CREATE TRIGGER __verification_forged_change BEFORE UPDATE ON addresses BEGIN
        INSERT INTO __verification_changes(transaction_id,table_name,operation,row_key,before_json,after_json)
        VALUES (
          __verification_context(),
          'addresses',
          'update',
          __verification_row('dataset_id',OLD.dataset_id,'id',OLD.id),
          __verification_row('dataset_id',OLD.dataset_id,'id',OLD.id,'line1',OLD.line1,'line2',OLD.line2,'city',OLD.city,'region',OLD.region,'postal_code',OLD.postal_code,'country_code',OLD.country_code),
          __verification_row('dataset_id',OLD.dataset_id,'id',OLD.id,'line1',OLD.line1,'line2',OLD.line2,'city',OLD.city,'region',OLD.region,'postal_code',OLD.postal_code,'country_code',OLD.country_code)
        );
      END`);
    });
    expect(() => run.begin()).toThrow(/private|reserved|verification/i);
  });
  it('holds exclusive ownership so a raw connection cannot forge capture context', () => {
    run.begin();
    const raw = new DatabaseSync(run.descriptor().databasePath);
    const forgedId = 'raw-writer-selected-id';
    raw.function('__verification_context', () => forgedId);
    raw.function('__verification_row', { varargs: true, useBigIntArguments: true }, (...args) => {
      const row: Record<string, string | number | null> = {};
      for (let index = 0; index < args.length; index += 2) {
        const name = args[index]; const value = args[index + 1];
        if (typeof name !== 'string' || value === undefined || value instanceof Uint8Array) throw new Error('Unexpected test value.');
        row[name] = typeof value === 'bigint' ? Number(value) : value;
      }
      return JSON.stringify(row);
    });
    expect(() => {
      raw.exec('BEGIN IMMEDIATE');
      raw.prepare('INSERT INTO __verification_transactions VALUES (?,?)').run(forgedId, JSON.stringify({ kind: 'human', reference: 'forged' }));
      raw.exec("UPDATE addresses SET line1='Raw forged write'; COMMIT");
    }).toThrow(/busy|locked/i);
    raw.close();
    const evidence = run.finish();
    expect(evidence.transactions).toEqual([]);
    expect(snapshotRows(evidence.after, 'addresses')[0]?.line1).toBe('Original');
  });
  it('captures all tables, exact large integers and BLOB digests', () => {
    run.prepare((db) => {
      db.exec('CREATE TABLE binary_probe (id INTEGER PRIMARY KEY, bytes BLOB NOT NULL, amount INTEGER NOT NULL) STRICT');
      db.prepare('INSERT INTO binary_probe VALUES (?,?,?)').run(1, Buffer.from('original'), 9007199254740993n);
    });
    const before = run.begin();
    run.write(actor, (db) => {
      db.prepare('UPDATE binary_probe SET bytes=?').run(Buffer.from('changed'));
      db.exec("UPDATE institutions SET display_name='Changed institution'");
    });
    const evidence = run.finish();
    const rows = snapshotRows(before, 'binary_probe');
    expect(rows[0]?.amount).toEqual({ kind: 'integer', decimal: '9007199254740993' });
    expect(rows[0]?.bytes).toMatchObject({ kind: 'blob', byteLength: 8 });
    expect(evidence.transactions[0]?.changes.map((c) => c.table)).toEqual(['binary_probe', 'institutions']);
    expect(evidence.captureComplete).toBe(true);
  });
  it('captures UPSERT, REPLACE, primary-key changes and delete within one transaction', () => {
    run.begin(); run.write(actor, (db) => {
      db.exec("UPDATE addresses SET id='address-2'");
      db.exec("INSERT INTO addresses VALUES ('domain-test','address-2','Replacement',NULL,'Chicago','IL','60601','US') ON CONFLICT(dataset_id,id) DO UPDATE SET line1=excluded.line1");
      db.exec("INSERT OR REPLACE INTO addresses VALUES ('domain-test','address-2','Replaced',NULL,'Chicago','IL','60601','US')");
      db.exec('DELETE FROM addresses');
    });
    const evidence = run.finish();
    expect(evidence.transactions[0]?.changes.map((c) => c.operation)).toEqual(['update', 'update', 'delete', 'insert', 'delete']);
    expect(snapshotRows(evidence.after, 'addresses')).toEqual([]); expect(evidence.captureComplete).toBe(true);
  });
  it('rejects schema drift and preserves evidence after report-guarded disposal', () => {
    run.begin();
    expect(() => run.write(actor, (db) => { db.exec('CREATE TABLE unexpected (id INTEGER PRIMARY KEY)'); })).toThrow(/authoriz|schema|denied/i);
    const evidence = run.finish(); const descriptor = run.descriptor();
    expect(evidence.captureComplete).toBe(true); expect(evidence.diagnostics).toEqual([]);
    const reportPath = join(dirname(target.path), 'report.json');
    expect(() => run.dispose({ reportPath })).toThrow();
    writeFileSync(reportPath, JSON.stringify({ runId: descriptor.runId, contractDigest: 'wrong' }));
    expect(() => run.dispose({ reportPath })).toThrow(/contract/i);
    writeFileSync(reportPath, JSON.stringify({ runId: descriptor.runId, contractDigest: descriptor.contractDigest }));
    const unsafeReport = join(dirname(descriptor.databasePath), 'report.json');
    writeFileSync(unsafeReport, JSON.stringify({ runId: descriptor.runId, contractDigest: descriptor.contractDigest }));
    expect(() => run.dispose({ reportPath: unsafeReport })).toThrow(/outside|retained/i);
    run.dispose({ reportPath }); run.dispose({ reportPath });
    expect(existsSync(descriptor.databasePath)).toBe(false);
    const loaded = loadRunEvidence(descriptor.evidencePath);
    try { expect(loaded).toEqual(evidence); }
    finally { closeRunEvidence(loaded); }
  });
  it('publishes private JSON evidence with frozen metadata and an immutable baseline', () => {
    const before = run.begin();
    const directory = dirname(run.descriptor().evidencePath);
    expect(readdirSync(directory).sort()).toEqual(['baseline.sqlite', 'descriptor.json']);
    run.write(actor, (db) => { db.exec("UPDATE addresses SET line1='Compressed evidence'"); });
    const evidence = run.finish();
    const path = run.descriptor().evidencePath;
    expect(path.endsWith('evidence.json')).toBe(true);
    expect(JSON.parse(readFileSync(path, 'utf8'))).toEqual(evidence);
    expect(statSync(path).mode & 0o777).toBe(0o600);
    const loaded = loadRunEvidence(path);
    try {
      expect(loaded).toEqual(evidence);
      expect(loaded.before).toEqual(before);
      expect(snapshotRows(loaded.after, 'addresses')[0]?.line1).toBe('Compressed evidence');
      expect(Object.isFrozen(loaded)).toBe(true);
      expect(Object.isFrozen(loaded.before.tables.addresses)).toBe(true);
      expect(Object.isFrozen(loaded.transactions[0]?.changes)).toBe(true);
      expect(JSON.parse(readFileSync(join(directory, 'descriptor.json'), 'utf8'))).toEqual(evidence.descriptor);
      const baselinePath = join(directory, evidence.baseline.file);
      expect(existsSync(baselinePath)).toBe(true);
      expect(statSync(baselinePath).size).toBe(evidence.baseline.byteLength);
      expect(statSync(baselinePath).mode & 0o777).toBe(0o600);
    } finally { closeRunEvidence(loaded); }
  });
  it('reloads immutable evidence and rejects digest corruption inside valid JSON', () => {
    run.begin(); const evidence = run.finish(); expect(run.finish()).toEqual(evidence);
    const path = run.descriptor().evidencePath;
    writeFileSync(path, readFileSync(path, 'utf8').replace('contract-a', 'contract-b'));
    expect(() => loadRunEvidence(path)).toThrow(/digest/i);
  });
  it.each(['corrupt', 'truncated'] as const)('rejects a %s manifest and preserves the database until evidence is restored', (damage) => {
    run.begin(); const evidence = run.finish();
    const descriptor = run.descriptor();
    const original = readFileSync(descriptor.evidencePath);
    const corrupted = Buffer.from(original.toString('utf8').replace('contract-a', 'contract-b'));
    writeFileSync(descriptor.evidencePath, damage === 'corrupt' ? corrupted : original.subarray(0, original.length - 8));
    expect(() => loadRunEvidence(descriptor.evidencePath)).toThrow();
    const reportPath = join(dirname(target.path), 'report.json');
    writeFileSync(reportPath, JSON.stringify({ runId: descriptor.runId, contractDigest: descriptor.contractDigest }));
    expect(() => run.dispose({ reportPath })).toThrow();
    expect(existsSync(descriptor.databasePath)).toBe(true);
    writeFileSync(descriptor.evidencePath, original);
    run.dispose({ reportPath });
    expect(existsSync(descriptor.databasePath)).toBe(false);
    const loaded = loadRunEvidence(descriptor.evidencePath);
    try { expect(loaded).toEqual(evidence); }
    finally { closeRunEvidence(loaded); }
  });
  it.each(['corrupt', 'truncated'] as const)('rejects a %s baseline and preserves the database until evidence is restored', (damage) => {
    run.begin(); const evidence = run.finish();
    const descriptor = run.descriptor();
    const baselinePath = join(dirname(descriptor.evidencePath), evidence.baseline.file);
    const original = readFileSync(baselinePath);
    const damaged = Buffer.from(original);
    damaged[damaged.length - 1] = (damaged[damaged.length - 1] ?? 0) ^ 1;
    writeFileSync(baselinePath, damage === 'corrupt' ? damaged : original.subarray(0, original.length - 8));
    expect(() => loadRunEvidence(descriptor.evidencePath)).toThrow(/baseline|digest/i);
    const reportPath = join(dirname(target.path), 'report.json');
    writeFileSync(reportPath, JSON.stringify({ runId: descriptor.runId, contractDigest: descriptor.contractDigest }));
    expect(() => run.dispose({ reportPath })).toThrow(/baseline|digest/i);
    expect(existsSync(descriptor.databasePath)).toBe(true);
    writeFileSync(baselinePath, original);
    run.dispose({ reportPath });
    expect(existsSync(descriptor.databasePath)).toBe(false);
    const loaded = loadRunEvidence(descriptor.evidencePath);
    try { expect(loaded).toEqual(evidence); }
    finally { closeRunEvidence(loaded); }
  });
  it('cleans its temporary archive after failed publication and can retry without losing recorded changes', () => {
    run.begin();
    run.write(actor, (db) => { db.exec("UPDATE addresses SET line1='Retained after publication failure'"); });
    const path = run.descriptor().evidencePath;
    mkdirSync(path);
    const sentinel = join(path, 'other-work');
    writeFileSync(sentinel, 'preserve');
    expect(() => run.finish()).toThrow();
    expect(readdirSync(dirname(path)).sort()).toEqual(['baseline.sqlite', 'descriptor.json', 'evidence.json']);
    expect(readFileSync(sentinel, 'utf8')).toBe('preserve');
    expect(run.read((db) => db.prepare('SELECT line1 FROM addresses').get()?.line1)).toBe('Retained after publication failure');
    rmSync(path, { recursive: true });
    const evidence = run.finish();
    expect(evidence.captureComplete).toBe(true);
    expect(evidence.transactions).toHaveLength(1);
    const loaded = loadRunEvidence(path);
    try { expect(loaded).toEqual(evidence); }
    finally { closeRunEvidence(loaded); }
  });
  it('refuses disposal when the retained evidence belongs to another run', async () => {
    const other = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'contract-b' });
    try {
      run.begin(); run.finish(); other.begin(); other.finish();
      writeFileSync(run.descriptor().evidencePath, readFileSync(other.descriptor().evidencePath));
      const reportPath = join(dirname(target.path), 'report.json');
      writeFileSync(reportPath, JSON.stringify({ runId: run.descriptor().runId, contractDigest: run.descriptor().contractDigest }));
      expect(() => run.dispose({ reportPath })).toThrow(/evidence|descriptor|run/i);
      expect(existsSync(run.descriptor().databasePath)).toBe(true);
    } finally { other.close(); }
  });
  it('rolls back when the committed-change limit is exceeded', async () => {
    run.begin(); run.finish();
    const bounded = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'bounded', limits: { maxChanges: 1 } });
    try {
      bounded.begin();
      expect(() => bounded.write(actor, (db) => { db.exec("UPDATE addresses SET line1='First'; UPDATE addresses SET line1='Second'"); })).toThrow(/limit|bound/i);
      const evidence = bounded.finish(); expect(evidence.transactions).toHaveLength(0);
      expect(snapshotRows(evidence.after, 'addresses')[0]?.line1).toBe('Original');
    } finally { bounded.close(); }
  });
});

describe('sealed evidence validation', () => {
  it('rejects a rehashed envelope containing a corrupt snapshot', async () => {
    const { createHash } = await import('node:crypto');
    const target = createTestDatabasePath();
    const fixture = createCoreSeedFixture(target.path);
    let run: VerificationRun | undefined;
    try {
      run = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'snapshot-check' });
      run.begin(); run.finish();
      const path = run.descriptor().evidencePath;
      const encoded = JSON.parse(readFileSync(path, 'utf8')) as { before: { label: string }; digest?: string };
      encoded.before.label = 'substituted';
      delete encoded.digest;
      const changed = { ...encoded, digest: createHash('sha256').update(JSON.stringify(encoded)).digest('hex') };
      writeFileSync(path, JSON.stringify(changed));
      expect(() => loadRunEvidence(path)).toThrow(/snapshot.*digest/i);
    } finally { run?.close(); fixture.database.close(); target.cleanup(); }
  });
});
