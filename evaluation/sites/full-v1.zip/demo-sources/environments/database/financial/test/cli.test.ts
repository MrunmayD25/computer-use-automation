import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { describe, expect, it } from 'vitest';

import { createTestDatabasePath } from './conftest.js';

describe('financial-seed CLI', () => {
  it('requires an explicit command and supports verbose seed output', () => {
    const missing = spawnSync(process.execPath, ['dist/cli.js'], { encoding: 'utf8' });
    expect(missing.status).not.toBe(0);
    expect(missing.stderr).toContain('Usage:');

    const target = createTestDatabasePath();
    try {
      const seeded = spawnSync(
        process.execPath,
        ['dist/cli.js', 'seed', '--path', target.path, '--name', 'cli-small', '--scale', 'small', '--verbose'],
        { encoding: 'utf8' },
      );
      expect(seeded.status, seeded.stderr).toBe(0);
      expect(seeded.stderr).toContain('Seeded 3 institution datasets');
      expect(JSON.parse(seeded.stdout)).toMatchObject({ kind: 'created' });
      const verified = spawnSync(process.execPath, ['dist/cli.js','verify','--path',target.path,'--name','cli-small'], {encoding:'utf8'});
      expect(verified.status,verified.stderr).toBe(0);
      using database = new DatabaseSync(target.path);
      database.exec('UPDATE journal_lines SET debit_minor_units=debit_minor_units+1 WHERE rowid=(SELECT rowid FROM journal_lines WHERE debit_minor_units>0 LIMIT 1)');
      const corrupted = spawnSync(process.execPath, ['dist/cli.js','verify','--path',target.path,'--name','cli-small'], {encoding:'utf8'});
      expect(corrupted.status).not.toBe(0);
      expect(corrupted.stderr).toContain('balanced journals');
    } finally {
      target.cleanup();
    }
  });

  it('does not create a database while verifying a nonexistent path', () => {
    const target=createTestDatabasePath();
    try {
      const result=spawnSync(process.execPath,['dist/cli.js','verify','--path',target.path],{encoding:'utf8'});
      expect(result.status).not.toBe(0);
      expect(existsSync(target.path)).toBe(false);
    } finally {target.cleanup();}
  });
});
