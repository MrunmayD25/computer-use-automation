import { localDate, zonedInstant } from '../src/services/core.js';
import { queryCore } from '../src/services/core-queries.js';
import { exportStatement } from '../src/services/statement-export.js';
import { accountDetail, searchAccounts } from '../src/services/queries.js';
import { listApprovals } from '../src/services/approvals.js';
import { afterEach, expect, it } from 'vitest';
import { seedCore } from '../src/seed/core.js';
import { executeCommand, reviewCommand, validateServiceCommand } from '../src/services/commands.js';
import { openFinancialStore, type FinancialStore } from '../src/services/store.js';
import type { ServiceContext, ServiceCommand } from '../src/services/types.js';
import type { InstitutionId } from '../src/model.js';
import { createCoreSeedFixture, createTestDatabasePath } from './conftest.js';

const cleanups: (() => void)[] = [];
afterEach(() => { for (const cleanup of cleanups.reverse()) cleanup(); cleanups.length = 0; });
function fixture(): { store: FinancialStore; context: ServiceContext; command: ServiceCommand } {
  const location = createTestDatabasePath();
  cleanups.push(() => location.cleanup());
  const seed = createCoreSeedFixture(location.path);
  seed.database.exec('BEGIN');
  try { seedCore(seed); seed.database.exec('COMMIT'); }
  catch (error) { seed.database.exec('ROLLBACK'); seed.database.close(); throw error; }
  const member = seed.database.prepare('SELECT id FROM members WHERE dataset_id=? ORDER BY id LIMIT 1').get(seed.binding.datasetId);
  if (typeof member?.id !== 'string') throw new Error('Missing seeded member');
  seed.database.close();
  const store = openFinancialStore({ path: location.path });
  cleanups.push(() => store.close());
  return { store, context: { binding: seed.binding, actorId: 'actor-2', reference: 'boundary-test' },
    command: { kind: 'member.note.add', memberId: member.id, visibility: 'general', text: 'Approved test note' } };
}
it('does not reveal a duplicate receipt to a caller without authority', () => {
  const { store, context, command } = fixture();
  expect(executeCommand(store, context, command, 'boundary-key-001').kind).toBe('committed');
  expect(executeCommand(store, { ...context, actorId: 'missing-actor' }, command, 'boundary-key-001')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
  expect(executeCommand(store, context, command, 'boundary-key-001').kind).toBe('duplicate');
  expect(executeCommand(store,{...context,now:'2026-09-15T15:00:00.000Z'},command,'boundary-clock-forward').kind).toBe('committed');
  const count=store.read(database=>database.prepare('SELECT COUNT(*) AS n FROM operations').get()?.n);
  expect(executeCommand(store,context,command,'boundary-clock-backward')).toMatchObject({kind:'rejected',code:'stale_version'});
  expect(store.read(database=>database.prepare('SELECT COUNT(*) AS n FROM operations').get()?.n)).toBe(count);
});
it('rejects a mismatched institution binding before review or duplicate lookup', () => {
  const { store, context, command } = fixture();
  expect(executeCommand(store, context, command, 'boundary-key-002').kind).toBe('committed');
  const wrong = { ...context, binding: { ...context.binding, institutionId: 'harbor' as InstitutionId } };
  expect(executeCommand(store, wrong, command, 'boundary-key-002')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
  expect(reviewCommand(store, wrong, command)).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
});
it('rejects invalid or timezone-free business clocks without a write', () => {
  const { store, context, command } = fixture();
  for (const now of ['invalid', '2026-09-14T15:00:00']) {
    expect(executeCommand(store, { ...context, now }, command, 'boundary-key-003')).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(reviewCommand(store, { ...context, now }, command)).toMatchObject({ kind: 'rejected', code: 'validation' });
  }
});
it('rejects malformed command shapes before domain code or a transaction', () => {
  for (const value of [null, {kind: 'unknown'}, {kind: 'cash.deposit', accountId: 'x', expectedVersion: 1, amount: {minorUnits: 1, currency: 'USD', rounding: 'nearest'}, description: 'x'}, {kind: 'member.note.add', memberId: 'x', text: 4, visibility: 'general'}]) {
    expect(validateServiceCommand(value)).toMatchObject({kind: 'rejected', code: 'validation'});
  }
});

it('validates exact scoped-address and channel-specific communication command shapes', () => {
  const destinationUpdate = {
    kind: 'maintenance.address.destination.update', memberId: 'member-primary', context: 'card-shipping', targetId: 'card-1',
    addressId: 'address-1', evidenceVersionId: 'address-evidence-1', effectiveDate: '2026-09-14', expectedCurrentDestinationId: null,
    consentId: null, approvalId: 'approval-1',
  };
  const email = {
    kind: 'communication.send', partyId: 'party-1', channel: 'email', destination: 'member@example.invalid', purpose: 'servicing',
    documentVersionId: 'notice-1', jobId: 'job-email-1',
  };
  const mail = {
    kind: 'communication.send', partyId: 'party-1', channel: 'mail', addressDestinationId: 'destination-1', purpose: 'servicing',
    documentVersionId: 'notice-1', jobId: 'job-mail-1',
  };
  for (const command of [destinationUpdate, email, mail]) expect(validateServiceCommand(command)).toBeNull();
  for (const command of [
    {...destinationUpdate, context: 'all-addresses'},
    {...destinationUpdate, unexpected: true},
    {...destinationUpdate, expectedCurrentDestinationId: undefined},
    {...email, addressDestinationId: 'destination-1'},
    {...mail, destination: 'caller-supplied postal text'},
    {...mail, addressDestinationId: 1},
  ]) expect(validateServiceCommand(command)).toMatchObject({kind: 'rejected', code: 'validation'});
});

it('rejects a deposit whose resulting balance cannot be represented as exact minor units', () => {
  const {store,context}=fixture();
  const account=store.write({kind:'system',actorId:context.actorId,reference:'exact-balance-fixture'},database=>{
    const row=database.prepare(`SELECT a.id,a.version,a.currency,b.posted_balance_minor_units AS balance,l.id AS ledger
      FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
      JOIN ledger_accounts l ON l.dataset_id=a.dataset_id AND l.customer_account_id=a.id
      WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' ORDER BY a.id LIMIT 1`).get(context.binding.datasetId);
    if(typeof row?.id!=='string'||typeof row.version!=='number'||typeof row.balance!=='number'||typeof row.ledger!=='string') throw new Error('Missing exact balance fixture');
    const counterpart=database.prepare("SELECT id FROM ledger_accounts WHERE dataset_id=? AND kind='opening-equity' AND currency='USD' LIMIT 1").get(context.binding.datasetId);
    if(typeof counterpart?.id!=='string') throw new Error('Missing opening ledger');
    const delta=Number.MAX_SAFE_INTEGER-1-row.balance;
    database.prepare('INSERT INTO journals(dataset_id,id,reference,status,posted_at,effective_date,description) VALUES (?,?,?,?,?,?,?)').run(context.binding.datasetId,'exact-boundary','EXACT-BOUNDARY','posted','2026-09-13T15:00:00.000Z','2026-09-13','Exact boundary funding');
    const insert=database.prepare('INSERT INTO journal_lines(dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,?,?)');
    insert.run(context.binding.datasetId,'exact-boundary',1,counterpart.id,'USD',delta,0,'Exact boundary funding');
    insert.run(context.binding.datasetId,'exact-boundary',2,row.ledger,'USD',0,delta,'Exact boundary funding');
    return {id:row.id,version:row.version};
  });
  const command={kind:'cash.deposit' as const,accountId:account.id,expectedVersion:account.version,amount:{minorUnits:2,currency:'USD'},description:'Exceeds exact balance capacity'};
  const before=store.read(database=>database.prepare('SELECT COUNT(*) AS count FROM operations').get());
  expect(reviewCommand(store,context,command)).toMatchObject({kind:'rejected',code:'limit_exceeded'});
  expect(executeCommand(store,context,command,'exact-balance-overflow')).toMatchObject({kind:'rejected',code:'limit_exceeded'});
  expect(store.read(database=>database.prepare('SELECT COUNT(*) AS count FROM operations').get())).toEqual(before);
  expect(store.read(database=>database.prepare('SELECT posted_balance_minor_units FROM account_balances WHERE dataset_id=? AND account_id=?').get(context.binding.datasetId,account.id)?.posted_balance_minor_units)).toBe(Number.MAX_SAFE_INTEGER-1);
});

it('requires statement consent for electronic selection and new accounts while preserving paper and unchanged choices', () => {
  const {store,context}=fixture();
  const selected=store.write({kind:'system',actorId:context.actorId,reference:'consent-boundary-fixture'},database=>{
    const row=database.prepare("SELECT a.id,a.member_id,a.version,p.id AS product_id FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.code='USD-SAVINGS' WHERE a.dataset_id=? AND a.status='open' ORDER BY a.id LIMIT 1").get(context.binding.datasetId);
    if(typeof row?.id!=='string'||typeof row.member_id!=='string'||typeof row.version!=='number'||typeof row.product_id!=='string') throw new Error('Missing consent fixture');
    database.prepare("UPDATE accounts SET statement_delivery='paper' WHERE dataset_id=? AND id=?").run(context.binding.datasetId,row.id);
    return {id:row.id,memberId:row.member_id,version:row.version,productId:row.product_id};
  });
  const delivery={kind:'account.statement_delivery.update' as const,accountId:selected.id,expectedVersion:selected.version,statementDelivery:'electronic' as const};
  const opening={kind:'account.open' as const,memberId:selected.memberId,productId:selected.productId,nickname:'Approved new account',statementDelivery:'electronic' as const};
  const before=store.read(database=>database.prepare('SELECT COUNT(*) AS count FROM operations').get());
  for(const [index,command] of [delivery,opening].entries()) {
    expect(reviewCommand(store,context,command)).toMatchObject({kind:'rejected',code:'ineligible',field:'statementDelivery'});
    expect(executeCommand(store,context,command,`consent-boundary-${index}`)).toMatchObject({kind:'rejected',code:'ineligible',field:'statementDelivery'});
  }
  expect(store.read(database=>database.prepare('SELECT COUNT(*) AS count FROM operations').get())).toEqual(before);
  expect(executeCommand(store,context,{...delivery,statementDelivery:'paper'},'consent-paper-unchanged').kind).toBe('unchanged');
  expect(executeCommand(store,context,{...opening,statementDelivery:'paper'},'consent-paper-opening').kind).toBe('committed');
  store.write({kind:'system',actorId:context.actorId,reference:'existing-electronic-fixture'},database=>database.prepare("UPDATE accounts SET statement_delivery='electronic' WHERE dataset_id=? AND id=?").run(context.binding.datasetId,selected.id));
  expect(executeCommand(store,context,delivery,'consent-electronic-unchanged').kind).toBe('unchanged');
});
it('prepares and independently decides exact approval scope without executing the target', () => {
  const {store, context} = fixture();
  const records = store.read(database => ({account: database.prepare('SELECT id,member_id,version FROM accounts WHERE dataset_id=? ORDER BY id LIMIT 1').get(context.binding.datasetId), policy: database.prepare('SELECT id FROM policy_versions WHERE dataset_id=? LIMIT 1').get(context.binding.datasetId)}));
  if (typeof records.account?.id !== 'string' || typeof records.account.member_id !== 'string' || typeof records.account.version !== 'number' || typeof records.policy?.id !== 'string') throw new Error('Missing approval fixtures');
  const target = { kind: 'account.owner.add' as const, accountId: records.account.id, memberId: records.account.member_id, expectedVersion: records.account.version, role: 'joint-owner' as const, effectiveDate: '2026-09-14', identityEvidenceId: 'reviewed-evidence', consentId: 'reviewed-consent', approvalId: 'not-yet-issued' };
  const checker = {...context, actorId: 'actor-5'};
  expect(executeCommand(store, context, {kind:'approval.request', target, checkerActorId: checker.actorId, policyVersionId:records.policy.id, expiresAt:'2026-09-15T15:00:00Z', amountLimit:null}, 'approval-boundary-01').kind).toBe('committed');
  const listed = listApprovals(store, checker);
  if (listed.kind !== 'found') throw new Error('Approval query rejected');
  const approval = listed.approvals.find(item => item.status === 'pending' && typeof item.target === 'object' && item.target !== null && Reflect.get(item.target, 'kind') === target.kind);
  if (!approval) throw new Error('New pending approval missing');
  const decision = {kind:'approval.decide' as const, approvalId:approval.id, expectedFingerprint:approval.fingerprint, decision:'approve' as const, reason:'Independently checked the exact requested owner scope'};
  expect(executeCommand(store, context, decision, 'approval-boundary-02')).toMatchObject({kind:'rejected',code:'not_authorized'});
  expect(executeCommand(store, checker, decision, 'approval-boundary-03').kind).toBe('committed');
  expect(executeCommand(store, checker, decision, 'approval-boundary-03').kind).toBe('duplicate');
  expect(executeCommand(store, checker, {...decision,reason:'Changed reason'}, 'approval-boundary-03')).toMatchObject({kind:'rejected',code:'idempotency_conflict'});
  expect(store.read(database => database.prepare('SELECT version FROM accounts WHERE dataset_id=? AND id=?').get(context.binding.datasetId, target.accountId)?.version)).toBe(target.expectedVersion);
});

it('returns durable identical command output after retries and detects corrupted output bytes', () => {
  const {store,context,command}=fixture();
  const first=executeCommand(store,context,command,'durable-output-key-001');
  expect(first.kind).toBe('committed');
  if(first.kind!=='committed') throw new Error('Expected commit');
  expect(first.receipt.result).not.toBeNull();
  const retry=executeCommand(store,context,command,'durable-output-key-001');
  expect(retry.kind).toBe('duplicate');
  if(retry.kind!=='duplicate') throw new Error('Expected duplicate');
  expect(retry.receipt).toEqual(first.receipt);
  store.write({kind:'system',actorId:context.actorId,reference:'deliberate-test-fault'},database=>{
    database.prepare('UPDATE operation_receipts SET result_json=? WHERE dataset_id=? AND operation_id=?').run('{"wrong":true}',context.binding.datasetId,first.receipt.operationId);
  });
  expect(()=>executeCommand(store,context,command,'durable-output-key-001')).toThrow('Stored command output digest mismatch');
});

it('uses the supplied inquiry clock for hold availability and expiring restricted-note authority', () => {
  const {store,context,command}=fixture();
  if(command.kind!=='member.note.add') throw new Error('Expected note fixture');
  const later='2026-09-18T15:00:00.000Z';
  const accountId=store.write({kind:'system',actorId:context.actorId,reference:'clock-fixture'},database=>{
    const account=database.prepare('SELECT id FROM accounts WHERE dataset_id=? ORDER BY id LIMIT 1').get(context.binding.datasetId);
    if(typeof account?.id!=='string') throw new Error('Missing account');
    database.prepare("INSERT INTO holds(dataset_id,id,account_id,amount_minor_units,status,reason,release_authority,placed_at,expires_at) VALUES (?,'clock-hold',?,777,'active','Clock boundary','supervisor','2026-09-14T15:00:00.000Z','2026-09-16T15:00:00.000Z')").run(context.binding.datasetId,account.id);
    database.prepare("UPDATE actor_roles SET ends_at='2026-09-16T15:00:00.000Z' WHERE dataset_id=? AND actor_id=?").run(context.binding.datasetId,context.actorId);
    database.prepare("INSERT INTO actor_roles(dataset_id,actor_id,role_id,starts_at,ends_at) VALUES (?,?,'role-1','2026-01-01T00:00:00.000Z',NULL)").run(context.binding.datasetId,context.actorId);
    database.prepare("INSERT INTO member_notes(dataset_id,id,member_id,actor_id,visibility,text,created_at) VALUES (?,'clock-note',?,?,'restricted','Restricted clock evidence','2026-09-14T15:00:00.000Z')").run(context.binding.datasetId,command.memberId,context.actorId);
    return account.id;
  });
  const before=store.read(database=>accountDetail(database,context.binding.datasetId,accountId));
  const after=store.read(database=>accountDetail(database,context.binding.datasetId,accountId,later));
  expect(after?.account.availableMinorUnits).toBe((before?.account.availableMinorUnits??0)+777);
  const listed=store.read(database=>searchAccounts(database,context.binding.datasetId,{ids:[accountId],limit:10,offset:0,sort:'available'},later));
  expect(listed.items[0]?.availableMinorUnits).toBe(after?.account.availableMinorUnits);
  const member=queryCore(store,{...context,now:later},{kind:'member.inspect',memberId:command.memberId});
  expect(member.kind).toBe('queried');
  expect(JSON.stringify(member)).not.toContain('Restricted clock evidence');
});


it('resolves local financial dates and rejects ambiguous or nonexistent daylight-saving times', () => {
  expect(localDate('2026-09-15T02:00:00.000Z','America/Chicago')).toBe('2026-09-14');
  expect(zonedInstant('2026-03-08','17:00','America/Chicago')).toBe('2026-03-08T22:00:00.000Z');
  expect(zonedInstant('2026-11-01','17:00','America/Chicago')).toBe('2026-11-01T23:00:00.000Z');
  expect(()=>zonedInstant('2026-03-08','02:30','America/Chicago')).toThrow('does not exist');
  expect(()=>zonedInstant('2026-11-01','01:30','America/Chicago')).toThrow('ambiguous');
  expect(()=>zonedInstant('2026-02-30','17:00','America/Chicago')).toThrow('Invalid local date');
});

it('rejects an oversized statement explicitly without returning partial artifacts or writing effects', async () => {
  const {store,context}=fixture();
  const account=store.write({kind:'system',actorId:context.actorId,reference:'statement-capacity-fixture'},database=>{
    const row=database.prepare("SELECT a.id,a.member_id,la.id AS ledger_id FROM accounts a JOIN ledger_accounts la ON la.dataset_id=a.dataset_id AND la.customer_account_id=a.id WHERE a.dataset_id=? AND a.currency='USD' LIMIT 1").get(context.binding.datasetId);
    if(typeof row?.id!=='string' || typeof row.member_id!=='string' || typeof row.ledger_id!=='string') throw new Error('Missing statement fixture');
    const journal=database.prepare("SELECT id FROM journals WHERE dataset_id=? AND status='posted' LIMIT 1").get(context.binding.datasetId);
    if(typeof journal?.id!=='string') throw new Error('Missing journal fixture');
    database.prepare("UPDATE journals SET effective_date='2026-09-14' WHERE dataset_id=? AND id=?").run(context.binding.datasetId,journal.id);
    database.prepare(`WITH RECURSIVE numbers(n) AS (SELECT 100000 UNION ALL SELECT n+1 FROM numbers WHERE n<110000)
      INSERT INTO journal_lines(dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo)
      SELECT ?,?,n,?,'USD',0,1,'capacity witness' FROM numbers`).run(context.binding.datasetId,journal.id,row.ledger_id);
    return {id:row.id,memberId:row.member_id};
  });
  const before=store.read(database=>database.prepare('SELECT count(*) AS n FROM operations').get()?.n);
  const inquiry=queryCore(store,context,{kind:'statement.inspect',accountId:account.id,period:'2026-09'});
  const exported=await exportStatement(store,context,{memberId:account.memberId,accountId:account.id,period:'2026-09',formats:['pdf','csv'],destinationId:'local'},['local']);
  for(const result of [inquiry,exported]) {
    expect(result).toMatchObject({kind:'rejected',code:'validation'});
    if(result.kind!=='rejected') throw new Error('Oversized statement unexpectedly succeeded');
    expect(result.message).toContain('10,000');
    expect(result.message).toContain('No partial statement');
  }
  expect(store.read(database=>database.prepare('SELECT count(*) AS n FROM operations').get()?.n)).toBe(before);
});

it('keeps future product and facility decisions inactive until effective and does not revive an expired limit', () => {
  const {store,context}=fixture();
  const ids=store.write({kind:'system',actorId:context.actorId,reference:'dated-decisions-fixture'},database=>{
    const account=database.prepare("SELECT a.id,a.product_id FROM accounts a WHERE a.dataset_id=? AND a.currency='USD' AND NOT EXISTS(SELECT 1 FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id) ORDER BY a.id LIMIT 1").get(context.binding.datasetId);
    const product=database.prepare("SELECT id FROM products WHERE dataset_id=? AND currency='USD' AND id<>? ORDER BY id LIMIT 1").get(context.binding.datasetId,account?.product_id??'');
    const operation=database.prepare('SELECT id FROM operations WHERE dataset_id=? LIMIT 1').get(context.binding.datasetId);
    if(typeof account?.id!=='string' || typeof account.product_id!=='string' || typeof product?.id!=='string' || typeof operation?.id!=='string') throw new Error('Missing dated-decision fixture');
    database.prepare("INSERT INTO facilities(dataset_id,id,account_id,kind,limit_minor_units,used_minor_units,status) VALUES (?,'dated-facility',?,'overdraft',5000,1000,'active')").run(context.binding.datasetId,account.id);
    database.prepare("INSERT INTO facility_limit_terms(dataset_id,id,facility_id,limit_minor_units,effective_at,expires_at,operation_id) VALUES (?,'dated-limit','dated-facility',2000,'2026-09-15T00:00:00.000Z','2026-09-16T00:00:00.000Z',?)").run(context.binding.datasetId,operation.id);
    database.prepare("INSERT INTO account_product_history(dataset_id,id,account_id,product_id,effective_at,operation_id) VALUES (?,'dated-product',?,?,'2026-09-15T00:00:00.000Z',?)").run(context.binding.datasetId,account.id,product.id,operation.id);
    return {accountId:account.id,originalProduct:account.product_id,newProduct:product.id};
  });
  const read=(now:string)=>store.read(database=>accountDetail(database,context.binding.datasetId,ids.accountId,now));
  const before=read('2026-09-14T15:00:00.000Z');
  const effective=read('2026-09-15T00:00:00.000Z');
  const expired=read('2026-09-16T00:00:00.000Z');
  expect(before?.account.productId).toBe(ids.originalProduct);
  expect(effective?.account.productId).toBe(ids.newProduct);
  expect(effective?.account.availableMinorUnits).toBe((before?.account.availableMinorUnits??0)-3000);
  expect(expired?.account.availableMinorUnits).toBe((before?.account.availableMinorUnits??0)-4000);
  expect(expired?.facilities.find(item=>item.id==='dated-facility')?.limitMinorUnits).toBe(0);
  expect(store.read(database=>searchAccounts(database,context.binding.datasetId,{ids:[ids.accountId],limit:1,offset:0,sort:'available'},'2026-09-16T00:00:00.000Z')).items[0]?.availableMinorUnits).toBe(expired?.account.availableMinorUnits);
});
