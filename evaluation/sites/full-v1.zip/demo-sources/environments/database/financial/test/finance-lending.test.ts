import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import { executeCommand, openFinancialStore, queryFinance, type CommandOutcome, type FinanceCommand, type FinancialStore, type Receipt, type ServiceContext } from '../src/services.js';
import { financeApprovalFingerprint, financeApprovalScope } from '../src/services/finance-support.js';
import { withTrustedFixtureTransaction } from '../src/testing.js';

let directory: string;
let path: string;
let source: DatasetBinding;
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'finance-lending-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  const seeded = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'finance-lending-test', scale: 'small' });
  const binding = seeded.bindings.find((candidate) => candidate.institutionId === 'northstar');
  if (binding === undefined) throw new Error('Northstar seed binding is missing.');
  source = binding;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function clone(): DatasetBinding {
  using database = openFinancialDatabase({ path });
  return database.cloneDataset(source);
}

function context(binding: DatasetBinding, actorOrdinal = 2): ServiceContext {
  return { binding, actorId: `${binding.institutionId}-actor-${actorOrdinal}`, reference: 'finance-lending-test' };
}

function rows<T = Record<string, unknown>>(query: string, ...parameters: (string | number | null)[]): T[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return database.prepare(query).all(...parameters) as T[];
}

function committed(outcome: CommandOutcome): Receipt {
  if (outcome.kind !== 'committed') throw new Error(`Expected committed outcome, received ${JSON.stringify(outcome)}`);
  return outcome.receipt;
}

function fingerprint(binding: DatasetBinding, resource: 'loan' | 'loan-closure', id: string): string {
  const result = queryFinance(store, context(binding), { kind: 'finance.record', resource, id });
  if (result.kind !== 'found') throw new Error(`Expected ${resource} snapshot, received ${JSON.stringify(result)}`);
  return result.snapshot.fingerprint;
}

function installApproval(binding: DatasetBinding, command: FinanceCommand, checkerOrdinal = 4): void {
  if (!('approvalId' in command)) throw new Error(`${command.kind} does not name an approval.`);
  const policy = rows<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
  if (policy === undefined) throw new Error('Approval policy is missing.');
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare(`INSERT INTO business_approvals
      (dataset_id,id,maker_actor_id,checker_actor_id,action_fingerprint,scope_json,amount_limit_minor_units,currency,policy_version_id,status,expires_at)
      VALUES (?,?,?,?,?,?,NULL,NULL,?,'approved','2026-09-16T15:00:00.000Z')`).run(
      binding.datasetId, command.approvalId, `${binding.institutionId}-actor-3`, `${binding.institutionId}-actor-${checkerOrdinal}`,
      financeApprovalFingerprint(command), JSON.stringify(financeApprovalScope(command)), policy.id,
    );
  });
}

function loanFixture(binding: DatasetBinding): { id: string; account_id: string; member_id: string; currency: string; total: number } {
  const loan = rows<{ id: string; account_id: string; member_id: string; currency: string; total: number }>(`SELECT l.id,l.account_id,a.member_id,l.currency,SUM(c.balance_minor_units) AS total
    FROM loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id JOIN loan_components c ON c.dataset_id=l.dataset_id AND c.loan_id=l.id
    WHERE l.dataset_id=? AND l.state IN ('active','delinquent') GROUP BY l.id,l.account_id,a.member_id,l.currency HAVING total>0 ORDER BY l.id LIMIT 1`, binding.datasetId)[0];
  if (loan === undefined) throw new Error('Payable loan fixture is missing.');
  return loan;
}

function addReceivedFunds(binding: DatasetBinding, loan: ReturnType<typeof loanFixture>, amount: number): void {
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    const ledgers = database.prepare(`SELECT
      (SELECT id FROM ledger_accounts WHERE dataset_id=? AND currency=? AND kind='settlement' ORDER BY id LIMIT 1) AS holding_id,
      (SELECT id FROM ledger_accounts WHERE dataset_id=? AND currency=? AND kind='cash' ORDER BY id LIMIT 1) AS source_id`).get(binding.datasetId, loan.currency, binding.datasetId, loan.currency);
    if (ledgers === undefined || typeof ledgers.holding_id !== 'string' || typeof ledgers.source_id !== 'string') throw new Error('Received-funds ledgers are missing.');
    database.prepare("INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,'OVERPAY-RECEIVED',NULL,'posted','2026-09-14T14:00:00.000Z','2026-09-14','Confirmed overpayment funds',NULL)").run(binding.datasetId, 'journal-overpayment-funds');
    const insert = database.prepare('INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,?,?)');
    insert.run(binding.datasetId, 'journal-overpayment-funds', 1, ledgers.source_id, loan.currency, amount, 0, 'Confirmed overpayment funds');
    insert.run(binding.datasetId, 'journal-overpayment-funds', 2, ledgers.holding_id, loan.currency, 0, amount, 'Confirmed overpayment funds');
    database.prepare("INSERT INTO received_funds (dataset_id,id,reference,member_id,currency,amount_minor_units,source_journal_id,holding_ledger_account_id,state,received_at) VALUES (?,?,'OVERPAY-FUNDS',?,?,?,?,?,'confirmed','2026-09-14T14:00:00.000Z')").run(
      binding.datasetId, 'received-overpayment', loan.member_id, loan.currency, amount, 'journal-overpayment-funds', ledgers.holding_id,
    );
  });
}

function addTemplate(binding: DatasetBinding, ownerPartyId: string, accountId: string, id: string, documentType: string): string {
  const versionId = `${id}-v1`;
  const bytes = Buffer.from(`Approved template ${id}`, 'utf8');
  const digest = createHash('sha256').update(bytes).digest('hex');
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare("INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'text/plain',?,?)").run(binding.datasetId, digest, bytes.byteLength, bytes);
    database.prepare("INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at) VALUES (?,?,?,?,?,?,'loan-lifecycle','2026-09-14T14:00:00.000Z')").run(binding.datasetId, id, ownerPartyId, accountId, documentType, id);
    database.prepare("INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status) VALUES (?,?,?,1,?,'text/plain','2026-09-14T14:00:00.000Z',NULL,NULL,NULL,'current')").run(binding.datasetId, versionId, id, digest);
  });
  return versionId;
}

describe('loan payoff completion', () => {
  it('requires an explicit hold disposition for excess received funds and blocks closure on that open obligation', () => {
    const binding = clone();
    const loan = loanFixture(binding);
    addReceivedFunds(binding, loan, loan.total + 1_000);
    const base = {
      kind: 'loan.payment.allocate' as const, loanId: loan.id, expectedFingerprint: fingerprint(binding, 'loan', loan.id),
      receivedFundsReference: 'OVERPAY-FUNDS', amount: { minorUnits: loan.total, currency: loan.currency },
    };
    expect(executeCommand(store, context(binding, 3), { ...base, allocationPolicy: 'fees-interest-principal' }, 'overpayment-without-disposition')).toMatchObject({ kind: 'rejected', code: 'open_dependencies' });
    const allocation = committed(executeCommand(store, context(binding, 3), { ...base, allocationPolicy: 'fees-interest-principal-hold-remainder' }, 'overpayment-held'));
    expect(allocation.result).toMatchObject({ remainingReceivedFundsMinorUnits: 1_000, overpaymentDisposition: 'hold-for-return', overpaymentMinorUnits: 1_000 });
    expect(rows('SELECT state,kind FROM loan_obligations WHERE dataset_id=? AND loan_id=? AND kind LIKE ?', binding.datasetId, loan.id, 'received-funds-overpayment:%')).toEqual([{ state: 'open', kind: `received-funds-overpayment:received-overpayment:1000` }]);

    const payoffPolicy = rows<{ id: string }>("SELECT id FROM policy_versions WHERE dataset_id=? AND json_type(rules_json,'$.loanPayoff')='object' AND effective_at<='2026-09-14T15:00:00.000Z' ORDER BY effective_at DESC,id DESC LIMIT 1", binding.datasetId)[0];
    if (payoffPolicy === undefined) throw new Error('Payoff policy is missing.');
    const quote = committed(executeCommand(store, context(binding, 1), {
      kind: 'loan.payoff.quote', loanId: loan.id, expectedFingerprint: fingerprint(binding, 'loan', loan.id), payoffDate: '2026-09-14', policyVersionId: payoffPolicy.id,
    }, 'overpayment-zero-quote'));
    const quoteId = quote.result?.quoteId;
    if (typeof quoteId !== 'string') throw new Error('Zero quote ID is missing.');
    const closeCommand: FinanceCommand = { kind: 'loan.close', loanId: loan.id, expectedFingerprint: fingerprint(binding, 'loan', loan.id), payoffEvidenceId: quoteId, approvalId: 'approval-overpayment-close' };
    installApproval(binding, closeCommand, 5);
    expect(executeCommand(store, context(binding, 5), closeCommand, 'overpayment-close')).toMatchObject({ kind: 'rejected', code: 'open_dependencies' });
  });

  it('closes only an authoritative zero-residual loan and issues exact immutable owner-scoped closure content', () => {
    const binding = clone();
    const loan = loanFixture(binding);
    const allocationCount = rows<{ count: number }>('SELECT COUNT(*) AS count FROM loan_allocations WHERE dataset_id=? AND loan_id=?', binding.datasetId, loan.id)[0]?.count ?? 0;
    const policy = rows<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId)[0];
    if (policy === undefined) throw new Error('Policy fixture is missing.');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare('UPDATE loan_components SET balance_minor_units=0 WHERE dataset_id=? AND loan_id=?').run(binding.datasetId, loan.id);
      database.prepare("UPDATE loans SET state='paid-off' WHERE dataset_id=? AND id=?").run(binding.datasetId, loan.id);
      database.prepare("UPDATE loan_obligations SET state='satisfied' WHERE dataset_id=? AND loan_id=?").run(binding.datasetId, loan.id);
      database.prepare("INSERT INTO payoff_quotes (dataset_id,id,loan_id,as_of,expires_at,total_minor_units,lines_json,policy_version_id) VALUES (?,? ,?,'2026-09-14','2026-09-15T23:59:59.999Z',0,'{\"principal\":0,\"interest\":0,\"fee\":0}',?)").run(binding.datasetId, 'zero-payoff-evidence', loan.id, policy.id);
    });
    const closeCommand: FinanceCommand = { kind: 'loan.close', loanId: loan.id, expectedFingerprint: fingerprint(binding, 'loan', loan.id), payoffEvidenceId: 'zero-payoff-evidence', approvalId: 'approval-loan-close' };
    installApproval(binding, closeCommand, 5);
    const closure = committed(executeCommand(store, context(binding, 5), closeCommand, 'loan-close-zero'));
    const closureId = closure.result?.closureId;
    if (typeof closureId !== 'string') throw new Error('Closure ID is missing.');
    expect(rows('SELECT state FROM loans WHERE dataset_id=? AND id=?', binding.datasetId, loan.id)).toEqual([{ state: 'closed' }]);
    expect(rows('SELECT status FROM accounts WHERE dataset_id=? AND id=?', binding.datasetId, loan.account_id)).toEqual([{ status: 'closed' }]);
    const closureReceiptId = `receipt-${closure.operationId.slice(3)}`;
    expect(rows('SELECT receipt_id FROM loan_closures WHERE dataset_id=? AND id=?', binding.datasetId, closureId)).toEqual([{ receipt_id: closureReceiptId }]);
    expect(rows<{ count: number }>('SELECT COUNT(*) AS count FROM loan_allocations WHERE dataset_id=? AND loan_id=?', binding.datasetId, loan.id)[0]?.count).toBe(allocationCount);

    const owner = rows<{ party_id: string }>('SELECT m.party_id FROM members m WHERE m.dataset_id=? AND m.id=?', binding.datasetId, loan.member_id)[0];
    if (owner === undefined) throw new Error('Loan owner is missing.');
    const templateVersionId = addTemplate(binding, owner.party_id, loan.account_id, 'closure-template', 'loan-closure-confirmation-template');
    const alternateTemplateVersionId = addTemplate(binding, owner.party_id, loan.account_id, 'alternate-closure-template', 'loan-closure-confirmation-template');
    const corruptTemplateVersionId = addTemplate(binding, owner.party_id, loan.account_id, 'corrupt-closure-template', 'loan-closure-confirmation-template');
    const wrongTemplateVersionId = addTemplate(binding, owner.party_id, loan.account_id, 'wrong-template', 'account-statement-template');
    const releaseTemplateVersionId = addTemplate(binding, owner.party_id, loan.account_id, 'release-template', 'simulated-lien-release-template');
    const closureFingerprint = fingerprint(binding, 'loan-closure', loan.id);
    const operationCount = rows('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId);
    expect(executeCommand(store, context(binding, 5), {
      kind: 'document.loan_closure.issue', loanId: loan.id, expectedClosureFingerprint: closureFingerprint, templateVersionId,
      recipientPartyId: 'party-not-owner', documentType: 'loan-closure-confirmation', approvalId: 'unused-owner-approval',
    }, 'closure-document-wrong-owner')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    expect(executeCommand(store, context(binding, 5), {
      kind: 'document.loan_closure.issue', loanId: loan.id, expectedClosureFingerprint: closureFingerprint, templateVersionId: wrongTemplateVersionId,
      recipientPartyId: owner.party_id, documentType: 'loan-closure-confirmation', approvalId: 'unused-template-approval',
    }, 'closure-document-wrong-template')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding, 5), {
      kind: 'document.loan_closure.issue', loanId: loan.id, expectedClosureFingerprint: closureFingerprint, templateVersionId: releaseTemplateVersionId,
      recipientPartyId: owner.party_id, documentType: 'simulated-lien-release', approvalId: 'unused-release-approval',
    }, 'closure-document-no-release')).toMatchObject({ kind: 'rejected', code: 'open_dependencies' });
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare(`UPDATE document_blobs SET bytes=zeroblob(byte_length) WHERE dataset_id=? AND digest=(
        SELECT digest FROM document_versions WHERE dataset_id=? AND id=?)`).run(binding.datasetId, binding.datasetId, corruptTemplateVersionId);
    });
    expect(() => executeCommand(store, context(binding, 5), {
      kind: 'document.loan_closure.issue', loanId: loan.id, expectedClosureFingerprint: closureFingerprint, templateVersionId: corruptTemplateVersionId,
      recipientPartyId: owner.party_id, documentType: 'loan-closure-confirmation', approvalId: 'unused-corrupt-template-approval',
    }, 'closure-document-corrupt-template')).toThrow(/integrity check/u);
    expect(rows('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId)).toEqual(operationCount);

    const documentCommand: FinanceCommand = {
      kind: 'document.loan_closure.issue', loanId: loan.id, expectedClosureFingerprint: closureFingerprint, templateVersionId,
      recipientPartyId: owner.party_id, documentType: 'loan-closure-confirmation', approvalId: 'approval-closure-document',
    };
    installApproval(binding, documentCommand, 5);
    const issued = committed(executeCommand(store, context(binding, 5), documentCommand, 'closure-document-issue'));
    expect(issued.result).toMatchObject({ loanId: loan.id, documentType: 'loan-closure-confirmation', issued: true, delivered: false });
    const versionId = issued.result?.versionId;
    const digest = issued.result?.digest;
    if (typeof versionId !== 'string' || typeof digest !== 'string') throw new Error('Closure document output is incomplete.');
    const stored = rows<{ bytes: Uint8Array; stored_digest: string; document_type: string; owner_party_id: string; source_version_id: string }>(`SELECT b.bytes,b.digest AS stored_digest,d.document_type,d.owner_party_id,x.source_version_id FROM document_versions v
      JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN document_derivations x ON x.dataset_id=v.dataset_id AND x.derivative_version_id=v.id WHERE v.dataset_id=? AND v.id=?`, binding.datasetId, versionId)[0];
    if (stored === undefined) throw new Error('Issued closure document is missing.');
    const text = Buffer.from(stored.bytes).toString('utf8');
    expect(createHash('sha256').update(stored.bytes).digest('hex')).toBe(digest);
    expect(stored).toMatchObject({ stored_digest: digest, document_type: 'loan-closure-confirmation', owner_party_id: owner.party_id, source_version_id: templateVersionId });
    expect(text).toContain(`Loan: ${loan.id}`);
    expect(text.startsWith('Approved template closure-template')).toBe(true);
    expect(text).toContain(`Account: ${loan.account_id}`);
    expect(text).toContain(`Owner party: ${owner.party_id}`);
    expect(text).toContain(`Closure receipt: ${closureReceiptId}`);
    expect(text).toContain('Issued: yes');
    expect(text).toContain('Delivered: no');
    const issuedFingerprint = fingerprint(binding, 'loan-closure', loan.id);
    expect(executeCommand(store, context(binding, 5), { ...documentCommand, expectedClosureFingerprint: issuedFingerprint }, 'closure-document-same-again'))
      .toEqual({ kind: 'unchanged', message: 'The same loan closure document was already issued.' });
    expect(executeCommand(store, context(binding, 5), {
      ...documentCommand, expectedClosureFingerprint: issuedFingerprint, templateVersionId: alternateTemplateVersionId,
    }, 'closure-document-different-template')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding, 5), {
      ...documentCommand, expectedClosureFingerprint: issuedFingerprint, templateVersionId: releaseTemplateVersionId, documentType: 'simulated-lien-release',
    }, 'closure-document-different-type')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });
});
