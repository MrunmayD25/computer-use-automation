import { DatabaseSync } from 'node:sqlite';
import { describe, expect, it } from 'vitest';

import type { DatasetId, InstitutionId } from '../src/model.js';
import { createSchema } from '../src/schema.js';
import { seedCore } from '../src/seed/core.js';
import { createSeedRandom } from '../src/seed/random.js';
import { seedHistoricalTransfers } from '../src/seed/transfers.js';

describe('historical transfers and corrections', () => {
  it('preserves balanced same-owner transfer history, reversal entitlements, receipts, and exact interest calculations', () => {
    using database = new DatabaseSync(':memory:');
    createSchema(database);
    database.prepare('INSERT INTO institutions VALUES (?,?,?,?,?,?)').run('northstar', 'Northstar Cooperative', 'Northstar', 'US', 'America/Chicago', 'USD');
    database.prepare('INSERT INTO datasets (id,institution_id,name,seed,scale,as_of,generator_version,schema_version,revision) VALUES (?,?,?,?,?,?,?,?,?)')
      .run('transfers', 'northstar', 'transfers', 42, 'small', '2026-09-14T15:00:00.000Z', '1', 1, 0);
    const context = { database, binding: { institutionId: 'northstar' as InstitutionId, datasetId: 'transfers' as DatasetId },
      institution: { id: 'northstar', legalName: 'Northstar Cooperative', displayName: 'Northstar', timeZone: 'America/Chicago', defaultCurrency: 'USD' as const },
      scale: 'small' as const, profile: { membersPerInstitution: 48, organizationsPerInstitution: 4, historyMonths: 18, ordinaryJournalTransactionsPerAccount: 20 },
      seed: 42, asOf: '2026-09-14T15:00:00.000Z', random: createSeedRandom(42),
      id: (kind: string, ordinal: number | string): string => `${kind}-${ordinal}`,
      businessNumber: (prefix: string, ordinal: number, width = 6): string => `${prefix}-${ordinal.toString().padStart(width, '0')}` };
    const refs = seedCore(context);
    const result = seedHistoricalTransfers(context, refs);
    expect(result.transferJournalIds.length).toBeGreaterThanOrEqual(12);
    const transfers = database.prepare(`SELECT j.id,j.status,COUNT(*) AS lines,SUM(l.debit_minor_units-l.credit_minor_units) AS net,
      COUNT(DISTINCT a.member_id) AS owners,COUNT(DISTINCT a.currency) AS currencies,COUNT(DISTINCT a.id) AS accounts,
      r.id AS receipt_id FROM journals j JOIN operations o ON o.dataset_id=j.dataset_id AND o.id=j.operation_id
      JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id
      JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id
      JOIN ledger_accounts gl ON gl.dataset_id=l.dataset_id AND gl.id=l.ledger_account_id
      JOIN accounts a ON a.dataset_id=gl.dataset_id AND a.id=gl.customer_account_id
      WHERE o.operation_kind='transfer.internal' GROUP BY j.id ORDER BY j.id`).all();
    expect(transfers.length).toBe(result.transferJournalIds.length);
    for (const transfer of transfers) {
      expect(transfer.lines).toBe(2);
      expect(transfer.net).toBe(0);
      expect(transfer.owners).toBe(1);
      expect(transfer.currencies).toBe(1);
      expect(transfer.accounts).toBe(2);
      expect(transfer.status).toBe('posted');
      expect(typeof transfer.receipt_id).toBe('string');
    }
    const reversals = database.prepare(`SELECT c.original_journal_id,SUM(c.amount_minor_units) AS refunded,
      (SELECT SUM(l.debit_minor_units) FROM journal_lines l WHERE l.dataset_id=c.dataset_id AND l.journal_id=c.original_journal_id) AS original
      FROM correction_links c WHERE c.kind='reversal' GROUP BY c.original_journal_id`).all();
    expect(reversals.some(row => Number(row.refunded) < Number(row.original))).toBe(true);
    expect(reversals.some(row => row.refunded === row.original)).toBe(true);
    for (const row of reversals) expect(Number(row.refunded)).toBeLessThanOrEqual(Number(row.original));
    const invalidLinks = database.prepare(`SELECT COUNT(*) AS count FROM correction_links c JOIN journals j
      ON j.dataset_id=c.dataset_id AND j.id=c.correction_journal_id
      WHERE c.kind='reversal' AND ((c.amount_minor_units=(SELECT SUM(l.debit_minor_units) FROM journal_lines l WHERE l.dataset_id=c.dataset_id AND l.journal_id=c.original_journal_id) AND (j.reversal_of_id IS NULL OR j.reversal_of_id<>c.original_journal_id)) OR (c.amount_minor_units<(SELECT SUM(l.debit_minor_units) FROM journal_lines l WHERE l.dataset_id=c.dataset_id AND l.journal_id=c.original_journal_id) AND j.reversal_of_id IS NOT NULL))`).get();
    expect(invalidLinks?.count).toBe(0);
    const wrongActors = database.prepare(`SELECT COUNT(*) AS count FROM operations o JOIN actor_roles ar
      ON ar.dataset_id=o.dataset_id AND ar.actor_id=o.actor_id JOIN roles r ON r.dataset_id=ar.dataset_id AND r.id=ar.role_id
      WHERE o.operation_kind IN ('transfer.internal','transfer.internal.reverse','interest.accrual','interest.adjust') AND r.code<>'payments-maker'`).get();
    expect(wrongActors?.count).toBe(0);
    const missingPermission = database.prepare(`SELECT COUNT(*) AS count FROM operations o WHERE o.operation_kind IN ('transfer.internal','transfer.internal.reverse','interest.accrual','interest.adjust') AND NOT EXISTS (
      SELECT 1 FROM actor_roles ar JOIN role_permissions p ON p.dataset_id=ar.dataset_id AND p.role_id=ar.role_id
      WHERE ar.dataset_id=o.dataset_id AND ar.actor_id=o.actor_id AND p.permission=o.operation_kind
      AND ar.starts_at<=o.occurred_at AND (ar.ends_at IS NULL OR ar.ends_at>o.occurred_at))`).get();
    expect(missingPermission?.count).toBe(0);
    const unapproved = database.prepare(`SELECT COUNT(*) AS count FROM operations o LEFT JOIN business_approvals a
      ON a.dataset_id=o.dataset_id AND a.action_fingerprint=o.command_digest AND a.status='consumed'
      WHERE o.operation_kind IN ('transfer.internal.reverse','interest.adjust') AND a.id IS NULL`).get();
    expect(unapproved?.count).toBe(0);
    const calculations = database.prepare('SELECT * FROM interest_calculations ORDER BY id').all();
    expect(calculations.some(row => Number(row.delta_minor_units) > 0)).toBe(true);
    expect(calculations.some(row => Number(row.delta_minor_units) < 0)).toBe(true);
    expect(calculations.some(row => row.delta_minor_units === 0 && row.adjustment_journal_id === null)).toBe(true);
    for (const calculation of calculations) {
      const numerator = BigInt(String(calculation.balance_days_minor_units)) * BigInt(String(calculation.annual_rate_bps));
      const denominator = BigInt(String(calculation.year_basis)) * 10000n;
      const quotient = numerator / denominator;
      const remainder = numerator % denominator;
      const rounded = quotient + (remainder * 2n > denominator || remainder * 2n === denominator && quotient % 2n === 1n ? 1n : 0n);
      expect(calculation.calculated_interest_minor_units).toBe(Number(rounded));
      expect(calculation.delta_minor_units).toBe(Number(calculation.calculated_interest_minor_units) - Number(calculation.booked_interest_minor_units));
    }
    expect(database.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
  });
});
