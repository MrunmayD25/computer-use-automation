import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import {
  caseGroupCounts, executeCommand, listCaseSubjectCorrectionEvidence, listSavedSearches, openFinancialStore, parseSavedSearchDefinition, reviewCommand, searchAccounts, searchCases, searchDocuments, searchMembers, validateServiceCommand,
  type CommandOutcome, type FinancialStore, type Receipt, type SavedSearchDefinition, type ServiceContext,
} from '../src/services.js';
import { findAuditViolations } from '../src/verification/independent-audit.js';

let directory: string;
let path: string;
let worldBindings: readonly DatasetBinding[];
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'financial-workspace-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  worldBindings = (await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'workspace-services-test', scale: 'small' })).bindings;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function clone(institution = 'northstar'): DatasetBinding {
  const source = worldBindings.find((binding) => binding.institutionId === institution);
  if (source === undefined) throw new Error(`Missing ${institution} binding.`);
  using database = openFinancialDatabase({ path });
  return database.cloneDataset(source);
}

/** Actor 1 is a viewer, 2 a servicer, 3 a payments maker and 5 a supervisor in the canonical seed. */
function context(binding: DatasetBinding, actorOrdinal = 2): ServiceContext {
  return { binding, actorId: `${binding.institutionId}-actor-${actorOrdinal}`, reference: 'workspace-services-test' };
}

function sql<T = Record<string, unknown>>(query: string, ...parameters: (string | number | null)[]): T[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return database.prepare(query).all(...parameters) as T[];
}

function audit(): unknown[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return findAuditViolations(database).filter((failure) => failure.name !== 'positive and negative state witnesses');
}

function committed(outcome: CommandOutcome): Receipt {
  if (outcome.kind !== 'committed') throw new Error(`Expected a commit, got ${JSON.stringify(outcome)}`);
  return outcome.receipt;
}

const openCases: SavedSearchDefinition = {
  entity: 'cases', filters: { states: ['open', 'reopened'], queueIds: [] }, sort: [{ field: 'due_at', direction: 'asc' }], columns: ['case_number', 'priority', 'due_at'],
};

describe('saved search definitions', () => {
  it('canonicalizes filters, drops empty ones and keeps field order meaning', () => {
    const parsed = parseSavedSearchDefinition({ entity: 'accounts', filters: { query: '  AC00 ', currency: 'USD', status: '' }, sort: [], columns: ['nickname', 'account_number'] });
    expect(parsed).toEqual({ ok: true, definition: { entity: 'accounts', filters: { query: 'AC00', currency: 'USD' }, sort: [], columns: ['nickname', 'account_number'] } });
  });

  it('rejects unknown entities, filters, columns, sort fields and duplicate columns with the offending field', () => {
    const problem = (value: unknown): string | undefined => { const result = parseSavedSearchDefinition(value); return result.ok ? undefined : result.field; };
    expect(problem({ entity: 'loans', filters: {}, sort: [], columns: ['id'] })).toBe('definition.entity');
    expect(problem({ entity: 'cases', filters: { balance: 'x' }, sort: [], columns: ['case_number'] })).toBe('definition.filters.balance');
    expect(problem({ entity: 'cases', filters: {}, sort: [], columns: ['case_number', 'posted_minor_units'] })).toBe('definition.columns');
    expect(problem({ entity: 'cases', filters: {}, sort: [{ field: 'summary', direction: 'asc' }], columns: ['case_number'] })).toBe('definition.sort');
    expect(problem({ entity: 'cases', filters: {}, sort: [{ field: 'due_at', direction: 'asc' }, { field: 'state', direction: 'desc' }], columns: ['case_number'] })).toBe('definition.sort');
    expect(problem({ entity: 'cases', filters: {}, sort: [], columns: ['case_number', 'case_number'] })).toBe('definition.columns');
    expect(problem({ entity: 'cases', filters: {}, sort: [], columns: [] })).toBe('definition.columns');
    expect(problem({ entity: 'cases', filters: {}, sort: [], columns: ['case_number'], extra: 1 })).toBe('definition');
  });

  it('reads the seeded team searches, including their result limit', () => {
    const binding = clone();
    const rows = store.read((database) => listSavedSearches(database, binding.datasetId, `${binding.institutionId}-actor-2`, 'cases'));
    expect(rows.slice(0, 3).map((row) => [row.name, row.visibility, row.mine, row.owner.actorNumber])).toEqual([
      ['My pending servicing cases', 'private', true, 'OP0002'],
      ['Team pending servicing cases', 'shared', true, 'OP0002'],
      ['Team pending servicing cases', 'shared', false, 'OP0001'],
    ]);
    expect(rows.every((row) => row.visibility === 'shared' || row.mine)).toBe(true);
    expect(rows[0]?.definition).toEqual({ entity: 'cases', filters: { states: ['pending-customer', 'pending-internal'] }, sort: [{ field: 'due_at', direction: 'asc' }], columns: ['case_number', 'member_number', 'state', 'due_at'], maxResults: 200 });
    expect(rows[0]?.problem).toBeNull();
  });
});

describe('saved search commands', () => {
  it('creates, renames, updates and deletes an owned search with receipts and stale-revision checks', () => {
    const binding = clone();
    const created = committed(executeCommand(store, context(binding), { kind: 'search.saved.create', name: 'My open cases', visibility: 'private', definition: openCases }, 'saved-search-0001'));
    expect(created.operationKind).toBe('search.saved.create');
    expect(created.affected.map((record) => record.kind)).toEqual(['saved-search']);
    const searchId = created.affected[0]?.id ?? '';
    const stored = sql<{ actor_id: string; name: string; visibility: string; definition_json: string }>('SELECT actor_id,name,visibility,definition_json FROM saved_searches WHERE dataset_id=? AND id=?', binding.datasetId, searchId);
    expect(stored).toEqual([{ actor_id: 'northstar-actor-2', name: 'My open cases', visibility: 'private',
      definition_json: '{"entity":"cases","filters":{"states":["open","reopened"]},"sort":[{"field":"due_at","direction":"asc"}],"columns":["case_number","priority","due_at"]}' }]);

    const mine = () => store.read((database) => listSavedSearches(database, binding.datasetId, 'northstar-actor-2', 'cases')).find((row) => row.id === searchId);
    const first = mine();
    if (first === undefined) throw new Error('Created search is not listed.');
    expect(first.definition).toEqual({ ...openCases, filters: { states: ['open', 'reopened'] } });

    expect(executeCommand(store, context(binding), { kind: 'search.saved.update', searchId, expectedRevision: first.revision, name: 'My open cases' }, 'saved-search-0002'))
      .toMatchObject({ kind: 'unchanged' });
    committed(executeCommand(store, context(binding), { kind: 'search.saved.update', searchId, expectedRevision: first.revision, name: 'Open and reopened' }, 'saved-search-0003'));
    expect(executeCommand(store, context(binding), { kind: 'search.saved.update', searchId, expectedRevision: first.revision, name: 'Lost update' }, 'saved-search-0004'))
      .toMatchObject({ kind: 'rejected', code: 'stale_version' });
    const renamed = mine();
    expect(renamed?.name).toBe('Open and reopened');
    expect(renamed?.definition).toEqual(first.definition);

    const narrowed: SavedSearchDefinition = { ...openCases, filters: { states: ['open'], queueIds: ['northstar-queue-1'] }, sort: [{ field: 'priority', direction: 'desc' }] };
    committed(executeCommand(store, context(binding), { kind: 'search.saved.update', searchId, expectedRevision: renamed?.revision ?? '', definition: narrowed }, 'saved-search-0005'));
    const updated = mine();
    expect(updated?.definition).toEqual(narrowed);

    const deleteCommand = { kind: 'search.saved.delete', searchId, expectedRevision: updated?.revision ?? '' } as const;
    const removed = committed(executeCommand(store, context(binding), deleteCommand, 'saved-search-0006'));
    expect(executeCommand(store, context(binding), deleteCommand, 'saved-search-0006')).toEqual({ kind: 'duplicate', receipt: removed });
    expect(executeCommand(store, context(binding), deleteCommand, 'saved-search-0007')).toMatchObject({ kind: 'rejected', code: 'not_found' });
    expect(mine()).toBeUndefined();
    expect(sql('SELECT resource_kind,summary FROM business_events WHERE dataset_id=? AND resource_id=? ORDER BY sequence', binding.datasetId, searchId)).toEqual([
      { resource_kind: 'saved-search', summary: 'Saved search "My open cases" created (private, cases).' },
      { resource_kind: 'saved-search', summary: 'Saved search "Open and reopened" updated: name.' },
      { resource_kind: 'saved-search', summary: 'Saved search "Open and reopened" updated: definition.' },
      { resource_kind: 'saved-search', summary: 'Saved search "Open and reopened" deleted.' },
    ]);
    expect(audit()).toEqual([]);
  });

  it('keeps private searches private and lets only owners change shared ones', () => {
    const binding = clone();
    const privateSearch = committed(executeCommand(store, context(binding, 2), { kind: 'search.saved.create', name: 'Only mine', visibility: 'private', definition: openCases }, 'saved-privacy-1')).affected[0]?.id ?? '';
    const sharedSearch = committed(executeCommand(store, context(binding, 2), { kind: 'search.saved.create', name: 'Team view', visibility: 'shared', definition: openCases }, 'saved-privacy-2')).affected[0]?.id ?? '';
    const seenBySupervisor = store.read((database) => listSavedSearches(database, binding.datasetId, 'northstar-actor-5', 'cases'));
    expect(seenBySupervisor.some((row) => row.id === privateSearch)).toBe(false);
    const shared = seenBySupervisor.find((row) => row.id === sharedSearch);
    expect(shared).toMatchObject({ mine: false, owner: { actorNumber: 'OP0002' } });

    expect(executeCommand(store, context(binding, 5), { kind: 'search.saved.delete', searchId: privateSearch, expectedRevision: 'anything' }, 'saved-privacy-3'))
      .toMatchObject({ kind: 'rejected', code: 'not_found' });
    expect(executeCommand(store, context(binding, 5), { kind: 'search.saved.update', searchId: sharedSearch, expectedRevision: shared?.revision ?? '', name: 'Hijacked' }, 'saved-privacy-4'))
      .toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    expect(executeCommand(store, context(binding, 1), { kind: 'search.saved.create', name: 'Viewer team view', visibility: 'shared', definition: openCases }, 'saved-privacy-5'))
      .toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'visibility' });
    committed(executeCommand(store, context(binding, 1), { kind: 'search.saved.create', name: 'Viewer own view', visibility: 'private', definition: openCases }, 'saved-privacy-6'));
    expect(executeCommand(store, context(binding, 3), { kind: 'search.saved.create', name: 'Maker view', visibility: 'private', definition: openCases }, 'saved-privacy-7'))
      .toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    expect(executeCommand(store, context(binding, 2), { kind: 'search.saved.create', name: 'only MINE', visibility: 'private', definition: openCases }, 'saved-privacy-8'))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'name' });
  });

  it('validates filter references against the institution before saving', () => {
    const binding = clone();
    expect(reviewCommand(store, context(binding), { kind: 'search.saved.create', name: 'Ghost queue', visibility: 'private', definition: { ...openCases, filters: { queueIds: ['riverton-queue-1'] } } }))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'definition.filters.queueIds' });
    expect(reviewCommand(store, context(binding), { kind: 'search.saved.create', name: 'Bad state', visibility: 'private', definition: { ...openCases, filters: { states: ['archived'] } } }))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'definition.filters.states' });
    expect(reviewCommand(store, context(binding), { kind: 'search.saved.create', name: 'Euro accounts', visibility: 'private', definition: { entity: 'accounts', filters: { currency: 'XYZ' }, sort: [], columns: ['account_number'] } }))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'definition.filters.currency' });
  });
});

describe('removed commands', () => {
  it('rejects the untyped case.link bypass at the runtime boundary', () => {
    const legacyCommand: unknown = { kind: 'case.link', caseId: 'case-1', expectedVersion: 1, accountId: null, reason: 'Bypass approval' };
    expect(validateServiceCommand(legacyCommand)).toMatchObject({ kind: 'rejected', code: 'validation', field: 'kind', message: 'Unknown command kind.' });
  });
});

describe('case subject correction evidence', () => {
  it('finds eligible evidence beyond 200 newer versions and explicitly refuses an over-500 member scope', () => {
    const binding = clone();
    const fixture = sql<{ member_id: string; party_id: string; version_id: string; digest: string; media_type: string; page_count: number | null }>(`SELECT m.id AS member_id,m.party_id,v.id AS version_id,v.digest,v.media_type,v.page_count
      FROM members m JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
      WHERE m.dataset_id=? AND m.status<>'merged' AND v.status IN ('current','signed') ORDER BY m.member_number,v.id LIMIT 1`, binding.datasetId)[0];
    if (fixture === undefined) throw new Error('Current correction evidence fixture is missing.');
    const addSuperseded = (from: number, through: number): void => {
      store.write({ kind: 'system', actorId: context(binding).actorId, reference: `correction-evidence-${String(from)}-${String(through)}` }, (database) => {
        for (let index = from; index <= through; index += 1) {
          const suffix = String(index).padStart(3, '0');
          const documentId = `correction-boundary-document-${suffix}`;
          database.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
            VALUES (?,?,?,?,?,?,?,'2026-09-15T00:00:00.000Z')`).run(binding.datasetId, documentId, fixture.party_id, null, 'correction-boundary', `superseded-${suffix}.pdf`, 'servicing-evidence');
          database.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
            VALUES (?,?,?,1,?,?,'2026-09-15T00:00:00.000Z',NULL,NULL,?,'superseded')`).run(binding.datasetId, `${documentId}-v1`, documentId, fixture.digest, fixture.media_type, fixture.page_count);
        }
      });
    };
    addSuperseded(1, 205);
    const oldFirstPage = store.read((database) => searchDocuments(database, binding.datasetId, { memberId: fixture.member_id, limit: 200, offset: 0 }));
    expect(oldFirstPage.items.filter((item) => item.status === 'current' || item.status === 'signed')).toEqual([]);
    const complete = store.read((database) => listCaseSubjectCorrectionEvidence(database, context(binding), fixture.member_id, fixture.member_id));
    expect(complete).toMatchObject({ kind: 'authorized' });
    if (complete.kind !== 'authorized') throw new Error(complete.message);
    expect(complete.value.evidenceDocuments.map((item) => item.versionId)).toContain(fixture.version_id);

    const count = sql<{ count: number }>(`SELECT COUNT(*) AS count FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE v.dataset_id=? AND d.owner_party_id=?`, binding.datasetId, fixture.party_id)[0]?.count ?? 0;
    addSuperseded(206, 205 + (501 - count));
    const exhausted = store.read((database) => listCaseSubjectCorrectionEvidence(database, context(binding), fixture.member_id, fixture.member_id));
    expect(exhausted).toMatchObject({ kind: 'rejected', code: 'limit_exceeded' });
    if (exhausted.kind !== 'rejected') throw new Error('The over-500 evidence scope was not refused.');
    expect(exhausted.message).toContain('More than 500 document versions');
  });
});

describe('workspace queries', () => {
  it('filters cases by several queues and groups counts that add up to the filtered total', () => {
    const binding = clone();
    const queues = ['northstar-queue-1', 'northstar-queue-2'];
    const filtered = store.read((database) => searchCases(database, binding.datasetId, { queueIds: queues, limit: 200, offset: 0 }));
    expect(filtered.total).toBeGreaterThan(0);
    expect(new Set(filtered.items.map((row) => row.queueId))).toEqual(new Set(queues.filter((queue) => filtered.items.some((row) => row.queueId === queue))));
    expect(filtered.items.every((row) => queues.includes(row.queueId))).toBe(true);
    for (const groupBy of ['state', 'queue', 'priority', 'assignee'] as const) {
      const groups = store.read((database) => caseGroupCounts(database, binding.datasetId, { queueIds: queues }, groupBy));
      expect(groups.reduce((sum, group) => sum + group.count, 0)).toBe(filtered.total);
      expect(new Set(groups.map((group) => group.key)).size).toBe(groups.length);
    }
    const byState = store.read((database) => caseGroupCounts(database, binding.datasetId, {}, 'state'));
    const openGroup = byState.find((group) => group.key === 'open');
    const openCount = store.read((database) => searchCases(database, binding.datasetId, { states: ['open'], limit: 1, offset: 0 })).total;
    expect(openGroup).toEqual({ key: 'open', label: 'Open', count: openCount, filter: { states: ['open'] } });
    const unassigned = store.read((database) => caseGroupCounts(database, binding.datasetId, {}, 'assignee')).find((group) => group.key === 'unassigned');
    if (unassigned !== undefined) expect(unassigned.filter).toEqual({ assignedActorId: null });
  });

  it('restricts list queries to explicit identities within a bound', () => {
    const binding = clone();
    const all = store.read((database) => searchAccounts(database, binding.datasetId, { limit: 5, offset: 0, sort: 'accountNumber' }));
    const chosen = [all.items[4]?.id ?? '', all.items[1]?.id ?? ''];
    const restricted = store.read((database) => searchAccounts(database, binding.datasetId, { ids: chosen, limit: 50, offset: 0, sort: 'accountNumber' }));
    expect(restricted.items.map((row) => row.id)).toEqual([all.items[1]?.id, all.items[4]?.id]);
    expect(store.read((database) => searchMembers(database, binding.datasetId, { ids: [], limit: 5, offset: 0 })).total).toBe(0);
    expect(() => store.read((database) => searchCases(database, binding.datasetId, { ids: Array.from({ length: 501 }, (_, index) => `case-${String(index)}`), limit: 5, offset: 0 }))).toThrow(RangeError);
  });

  it('pages documents with their owning member and account', () => {
    const binding = clone();
    const first = store.read((database) => searchDocuments(database, binding.datasetId, { documentType: 'account-statement', limit: 5, offset: 0 }));
    expect(first.items).toHaveLength(Math.min(5, first.total));
    for (const document of first.items) {
      expect(document.documentType).toBe('account-statement');
      expect(document.memberNumber).toMatch(/^NM\d{6}$/u);
      expect(document.accountNumber).toMatch(/^AC\d{7}$/u);
    }
    const second = store.read((database) => searchDocuments(database, binding.datasetId, { documentType: 'account-statement', limit: 5, offset: 5 }));
    expect(second.items.map((row) => row.versionId)).not.toContain(first.items[0]?.versionId);
    const byMember = store.read((database) => searchDocuments(database, binding.datasetId, { query: first.items[0]?.memberNumber ?? '', limit: 50, offset: 0 }));
    expect(byMember.items.every((row) => row.memberNumber === first.items[0]?.memberNumber)).toBe(true);
  });
});
