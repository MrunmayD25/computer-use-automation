import { DatabaseSync } from 'node:sqlite';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { captureSnapshot, matchesSnapshot, selectSnapshotRows } from '../src/verification/run-storage.js';
import type { RunLimits, RunSnapshot } from '../src/verification/run-types.js';

const limits: RunLimits = { maxRows: 100, maxChanges: 100, maxBlobBytes: 1000, maxSnapshotBytes: 10000, busyTimeoutMs: 1000 };

describe('sealed database snapshot comparison', () => {
  let database: DatabaseSync;
  let expected: RunSnapshot;
  beforeEach(() => {
    database = new DatabaseSync(':memory:');
    database.exec(`CREATE TABLE records (dataset_id TEXT, id TEXT, amount INTEGER, bytes BLOB, note TEXT, PRIMARY KEY(dataset_id,id)) STRICT;
      CREATE TABLE secondary (id INTEGER PRIMARY KEY, note TEXT) STRICT;
      CREATE TABLE __verification_changes (sequence INTEGER PRIMARY KEY) STRICT;
      INSERT INTO __verification_changes VALUES (1);
      INSERT INTO secondary VALUES (1,'another table');`);
    const insert = database.prepare('INSERT INTO records VALUES (?,?,?,?,?)');
    insert.run('second', 'shared', -9007199254740993n, Buffer.from('four'), null);
    insert.run('first', 'shared', 9007199254740993n, Buffer.from('abc'), 'Unicode 文🙂');
    insert.run('first', 'earlier', 42, Buffer.from('xy'), 'ordinary integer');
    expected = captureSnapshot(database, 'after', limits);
  });
  afterEach(() => { database.close(); });

  it('matches exact composite-key order, normalized BLOBs and large integers across tables', () => {
    const rows = [...selectSnapshotRows(expected, 'records')];
    expect(rows.map((row) => [row.dataset_id, row.id])).toEqual([
      ['first', 'earlier'], ['first', 'shared'], ['second', 'shared'],
    ]);
    expect(rows[1]?.amount).toEqual({ kind: 'integer', decimal: '9007199254740993' });
    expect(rows[1]?.bytes).toMatchObject({ kind: 'blob', byteLength: 3 });
    expect(matchesSnapshot(database, 'after', limits, expected)).toBe(true);
    expect(captureSnapshot(database, 'after', limits)).toEqual(expected);
  });

  it.each([
    ['changed scalar', "UPDATE records SET note='changed' WHERE dataset_id='first' AND id='shared'"],
    ['changed BLOB with equal length', "UPDATE records SET bytes=x'78797a' WHERE dataset_id='first' AND id='shared'"],
    ['changed large integer', "UPDATE records SET amount=9007199254740994 WHERE dataset_id='first' AND id='shared'"],
    ['added row', "INSERT INTO secondary VALUES (2,'extra')"],
    ['deleted row', 'DELETE FROM secondary'],
    ['changed schema', 'ALTER TABLE secondary ADD COLUMN extra TEXT'],
    ['added table', 'CREATE TABLE extra (id INTEGER PRIMARY KEY)'],
    ['deleted table', 'DROP TABLE secondary'],
    ['changed sequence', 'INSERT INTO __verification_changes VALUES (2)'],
  ])('rejects %s', (_name, sql) => {
    database.exec(sql);
    expect(matchesSnapshot(database, 'after', limits, expected)).toBe(false);
    expect(captureSnapshot(database, 'after', limits).digest).not.toBe(expected.digest);
  });

  it('checks labels, table identities, columns and primary-key order', () => {
    const records = expected.tables.records;
    if (records === undefined) throw new Error('Missing fixture table.');
    const reordered = Object.fromEntries(Object.entries(expected.tables).reverse());
    expect(matchesSnapshot(database, 'after', limits, { ...expected, tables: reordered })).toBe(true);
    expect(matchesSnapshot(database, 'before', limits, expected)).toBe(false);
    expect(matchesSnapshot(database, 'after', limits, { ...expected, schemaDigest: 'different' })).toBe(false);
    expect(matchesSnapshot(database, 'after', limits, { ...expected, tables: { records } })).toBe(false);
    expect(matchesSnapshot(database, 'after', limits, { ...expected, tables: {
      ...expected.tables, records: { ...records, columns: [...records.columns].reverse() },
    } })).toBe(false);
    expect(matchesSnapshot(database, 'after', limits, { ...expected, tables: {
      ...expected.tables, records: { ...records, primaryKey: [...records.primaryKey].reverse() },
    } })).toBe(false);
  });

  it('shares cumulative row, BLOB and normalized UTF-8 byte limits with full capture', () => {
    const tables = Object.values(expected.tables);
    const exactLimits = { ...limits,
      maxRows: tables.reduce((total, table) => total + table.rowCount, 0),
      maxBlobBytes: tables.reduce((total, table) => total + table.blobBytes, 0),
      maxSnapshotBytes: tables.reduce((total, table) => total + table.byteLength, 0) };
    expect(matchesSnapshot(database, 'after', exactLimits, expected)).toBe(true);
    expect(captureSnapshot(database, 'after', exactLimits)).toEqual(expected);
    for (const key of ['maxRows', 'maxBlobBytes', 'maxSnapshotBytes'] as const) {
      const tooSmall = { ...exactLimits, [key]: exactLimits[key] - 1 };
      expect(() => captureSnapshot(database, 'after', tooSmall)).toThrow(/limit exceeded/);
      expect(() => matchesSnapshot(database, 'after', tooSmall, expected)).toThrow(/limit exceeded/);
    }
  });
});
