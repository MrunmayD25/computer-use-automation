import { createHash } from 'node:crypto';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import { openTrustedReadOnly } from '../src/testing.js';
import { createTestDatabasePath } from './conftest.js';

describe('reconciliation source and accounting evidence', () => {
  const target = createTestDatabasePath();
  beforeAll(async () => {
    using database = openFinancialDatabase({ path: target.path });
    await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'reconciliation-audit', scale: 'small', seed: 91 });
  }, 120_000);
  afterAll(() => { target.cleanup(); });

  it('preserves unfunded and one-cent accounts after historical batch processing', () => {
    using database = openTrustedReadOnly(target.path);
    expect(database.prepare(`SELECT DISTINCT a.dataset_id FROM accounts a
      WHERE NOT EXISTS (SELECT 1 FROM ledger_accounts la JOIN journal_lines l
        ON l.dataset_id=la.dataset_id AND l.ledger_account_id=la.id
        WHERE la.dataset_id=a.dataset_id AND la.customer_account_id=a.id)`).all()).toHaveLength(3);
    expect(database.prepare(`SELECT DISTINCT dataset_id FROM account_balances
      WHERE posted_balance_minor_units=1`).all()).toHaveLength(3);
  });

  it('binds every imported row to the exact batch CSV bytes and digest', () => {
    const database = openTrustedReadOnly(target.path);
    try {
      const batches = database.prepare(`SELECT b.dataset_id,b.id,b.batch_number,b.kind,b.input_digest,v.digest,bl.bytes
        FROM batches b JOIN document_versions v ON v.dataset_id=b.dataset_id AND v.id=b.input_document_version_id
        JOIN document_blobs bl ON bl.dataset_id=v.dataset_id AND bl.digest=v.digest ORDER BY b.dataset_id,b.id`).all();
      expect(batches).toHaveLength(72);
      const observedHeaders = new Set<string>();
      for (const batch of batches) {
        if (!(batch.bytes instanceof Uint8Array) || typeof batch.id !== 'string' || typeof batch.dataset_id !== 'string' || typeof batch.batch_number !== 'string') throw new Error('Invalid batch bytes');
        expect(createHash('sha256').update(batch.bytes).digest('hex')).toBe(batch.input_digest);
        expect(batch.digest).toBe(batch.input_digest);
        const lines = Buffer.from(batch.bytes).toString('utf8').trimEnd().split('\r\n');
        const header = lines[0];
        if (header === undefined) throw new Error(`Batch ${batch.id} has no CSV header.`);
        observedHeaders.add(header);
        if (header === 'source_key,member_id,email') {
          const rows = database.prepare(`SELECT source_key,json_extract(item_json,'$.memberId') AS member_id,
            json_extract(item_json,'$.email') AS email FROM batch_items
            WHERE dataset_id=? AND batch_id=? ORDER BY ordinal`).all(batch.dataset_id, batch.id);
          expect(rows).toHaveLength(12);
          expect(lines.slice(1)).toEqual(rows.map((row) => [row.source_key,row.member_id,row.email].join(',')));
        } else if (header === 'source_key,fee_id,amount_minor_units,currency') {
          const rows = database.prepare(`SELECT source_key,json_extract(item_json,'$.feeId') AS fee_id,
            json_extract(item_json,'$.amountMinorUnits') AS amount_minor_units,json_extract(item_json,'$.currency') AS currency
            FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal`).all(batch.dataset_id, batch.id);
          expect(rows).toHaveLength(12);
          expect(lines.slice(1)).toEqual(rows.map((row) => [row.source_key,row.fee_id,row.amount_minor_units,row.currency].join(',')));
        } else if (header === 'source_key,member_id,account_id,amount_minor_units,currency') {
          const rows = database.prepare(`SELECT source_key,json_extract(item_json,'$.memberId') AS member_id,
            json_extract(item_json,'$.accountId') AS account_id,json_extract(item_json,'$.amountMinorUnits') AS amount_minor_units,
            json_extract(item_json,'$.currency') AS currency FROM batch_items
            WHERE dataset_id=? AND batch_id=? ORDER BY ordinal`).all(batch.dataset_id, batch.id);
          expect(rows).toHaveLength(12);
          expect(lines.slice(1)).toEqual(rows.map((row) => [row.source_key,row.member_id,row.account_id,row.amount_minor_units,row.currency].join(',')));
        } else if (header === 'settlement_batch_id,reference,cutoff_at,currency,payment_id,amount_minor_units,state') {
          const rows = database.prepare(`SELECT s.id AS settlement_batch_id,s.reference,s.cutoff_at,s.currency,
            i.payment_id,i.amount_minor_units,i.state FROM settlement_batches s
            JOIN settlement_items i ON i.dataset_id=s.dataset_id AND i.settlement_batch_id=s.id
            WHERE s.dataset_id=? AND s.reference=? ORDER BY i.id`).all(batch.dataset_id, batch.batch_number);
          expect(rows).toHaveLength(5);
          expect(lines.slice(1)).toEqual(rows.map((row) => [row.settlement_batch_id,row.reference,row.cutoff_at,row.currency,row.payment_id,row.amount_minor_units,row.state].join(',')));
        } else throw new Error(`Unexpected batch CSV header ${header}.`);
      }
      expect([...observedHeaders].sort()).toEqual([
        'settlement_batch_id,reference,cutoff_at,currency,payment_id,amount_minor_units,state',
        'source_key,fee_id,amount_minor_units,currency',
        'source_key,member_id,account_id,amount_minor_units,currency',
        'source_key,member_id,email',
      ]);
    } finally { database.close(); }
  });

  it('applies refund rows to their actual fee, owner, journal and receipt within batch scope', () => {
    const database = openTrustedReadOnly(target.path);
    try {
      const applied = database.prepare("SELECT COUNT(*) AS count FROM batch_items WHERE state='applied'").get();
      expect(Number(applied?.count)).toBeGreaterThan(0);
      expect(database.prepare(`SELECT i.id FROM batch_items i JOIN batches b ON b.dataset_id=i.dataset_id AND b.id=i.batch_id
        LEFT JOIN fees f ON f.dataset_id=i.dataset_id AND f.id=json_extract(i.item_json,'$.feeId')
        WHERE i.state='applied' AND (b.kind<>'fee-refund' OR f.id IS NULL
          OR json_extract(i.item_json,'$.amountMinorUnits')<>i.amount_minor_units
          OR json_extract(i.item_json,'$.currency')<>f.currency OR f.currency<>b.currency
          OR b.state IN ('uploaded','previewed','approved','failed')
          OR NOT EXISTS (SELECT 1 FROM fee_refunds r
            JOIN journals j ON j.dataset_id=r.dataset_id AND j.id=r.journal_id
            JOIN operation_receipts receipt ON receipt.dataset_id=j.dataset_id AND receipt.operation_id=j.operation_id
            WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id AND r.amount_minor_units=i.amount_minor_units
              AND receipt.id=i.receipt_id
              AND EXISTS (SELECT 1 FROM journal_lines credit JOIN ledger_accounts owner
                ON owner.dataset_id=credit.dataset_id AND owner.id=credit.ledger_account_id
                WHERE credit.dataset_id=j.dataset_id AND credit.journal_id=j.id AND owner.kind='customer-deposit'
                  AND owner.customer_account_id=f.account_id AND credit.credit_minor_units=i.amount_minor_units AND credit.debit_minor_units=0)
              AND EXISTS (SELECT 1 FROM journal_lines debit JOIN ledger_accounts income
                ON income.dataset_id=debit.dataset_id AND income.id=debit.ledger_account_id
                WHERE debit.dataset_id=j.dataset_id AND debit.journal_id=j.id AND income.kind='fee-income'
                  AND debit.currency=f.currency AND debit.debit_minor_units=i.amount_minor_units AND debit.credit_minor_units=0)))`).all()).toEqual([]);
      expect(database.prepare(`SELECT b.id FROM batches b JOIN batch_items i ON i.dataset_id=b.dataset_id AND i.batch_id=b.id
        GROUP BY b.dataset_id,b.id HAVING (b.state='completed' AND SUM(i.state<>'applied')<>0)
          OR (b.state='completed-with-exceptions' AND (SUM(i.state='applied')=0 OR SUM(i.state IN ('invalid','failed','skipped'))=0))
          OR SUM(CASE WHEN i.state='applied' THEN i.amount_minor_units ELSE 0 END)>b.approved_total_limit_minor_units`).all()).toEqual([]);
      expect(database.prepare(`SELECT b.id FROM batches b WHERE b.state IN ('approved','processing','completed','completed-with-exceptions')
        AND NOT EXISTS (SELECT 1 FROM business_approvals a WHERE a.dataset_id=b.dataset_id
          AND json_extract(a.scope_json,'$.batchId')=b.id AND json_extract(a.scope_json,'$.inputDigest')=b.input_digest
          AND json_extract(a.scope_json,'$.kind')=b.kind AND a.amount_limit_minor_units IS b.approved_total_limit_minor_units
          AND a.currency=b.currency)`).all()).toEqual([]);
    } finally { database.close(); }
  });

  it('backs each suspense original and residual with its own ledger entries', () => {
    const database = openTrustedReadOnly(target.path);
    try {
      expect(database.prepare('SELECT dataset_id,journal_id FROM suspense_items GROUP BY dataset_id,journal_id HAVING COUNT(*)<>1').all()).toEqual([]);
      expect(database.prepare(`SELECT s.id FROM suspense_items s JOIN journal_lines l ON l.dataset_id=s.dataset_id AND l.journal_id=s.journal_id
        JOIN ledger_accounts a ON a.dataset_id=l.dataset_id AND a.id=l.ledger_account_id AND a.kind='suspense'
        WHERE l.credit_minor_units-l.debit_minor_units<>s.original_amount_minor_units`).all()).toEqual([]);
      expect(database.prepare(`SELECT s.id,s.remaining_amount_minor_units,SUM(all_lines.credit_minor_units-all_lines.debit_minor_units) AS balance
        FROM suspense_items s JOIN journal_lines original ON original.dataset_id=s.dataset_id AND original.journal_id=s.journal_id
        JOIN ledger_accounts la ON la.dataset_id=original.dataset_id AND la.id=original.ledger_account_id AND la.kind='suspense'
        JOIN journal_lines all_lines ON all_lines.dataset_id=la.dataset_id AND all_lines.ledger_account_id=la.id
        GROUP BY s.dataset_id,s.id HAVING balance<>s.remaining_amount_minor_units`).all()).toEqual([]);
    } finally { database.close(); }
  });

  it('classifies repeated settlement sources as duplicates and excludes them from controls', () => {
    const database = openTrustedReadOnly(target.path);
    try {
      expect(database.prepare('SELECT DISTINCT state FROM settlement_items ORDER BY state').all()).toEqual([
        { state: 'accepted' }, { state: 'duplicate' }, { state: 'rejected' }, { state: 'returned' }, { state: 'settled' },
      ]);
      expect(database.prepare(`SELECT dataset_id,payment_id FROM settlement_items WHERE state<>'duplicate'
        AND payment_id IS NOT NULL GROUP BY dataset_id,payment_id HAVING COUNT(*)>1`).all()).toEqual([]);
      expect(database.prepare(`SELECT b.id FROM settlement_batches b JOIN settlement_items i
        ON i.dataset_id=b.dataset_id AND i.settlement_batch_id=b.id GROUP BY b.dataset_id,b.id
        HAVING b.declared_total_minor_units<>SUM(CASE WHEN i.state IN ('accepted','settled') THEN i.amount_minor_units
          WHEN i.state='returned' THEN -i.amount_minor_units ELSE 0 END)`).all()).toEqual([]);
      expect(database.prepare(`SELECT r.id FROM payment_returns r WHERE r.settlement_reference NOT LIKE 'EXT-RETURN-%'
        AND NOT EXISTS (SELECT 1 FROM settlement_batches b JOIN settlement_items i
          ON i.dataset_id=b.dataset_id AND i.settlement_batch_id=b.id
          WHERE b.dataset_id=r.dataset_id AND b.reference=r.settlement_reference AND i.payment_id=r.payment_id AND i.state='returned')`).all()).toEqual([]);
    } finally { database.close(); }
  });

  it('resolves reconciliation references to real business evidence', () => {
    const database = openTrustedReadOnly(target.path);
    try {
      expect(database.prepare(`WITH evidence(dataset_id,reference) AS (
        SELECT dataset_id,reference FROM journals UNION SELECT dataset_id,reference FROM payments
        UNION SELECT dataset_id,reference FROM settlement_batches UNION SELECT dataset_id,receipt_number FROM operation_receipts
        UNION SELECT dataset_id,id FROM cash_sessions UNION SELECT dataset_id,id FROM cash_declarations
        UNION SELECT dataset_id,evidence_reference FROM suspense_items)
        SELECT m.id FROM reconciliation_matches m WHERE NOT EXISTS (SELECT 1 FROM evidence e WHERE e.dataset_id=m.dataset_id AND e.reference=m.left_reference)
          OR NOT EXISTS (SELECT 1 FROM evidence e WHERE e.dataset_id=m.dataset_id AND e.reference=m.right_reference)`).all()).toEqual([]);
      expect(database.prepare(`SELECT m.id FROM reconciliation_matches m JOIN reconciliation_runs run ON run.dataset_id=m.dataset_id AND run.id=m.run_id
        WHERE (run.kind='transfer' AND NOT EXISTS (SELECT 1 FROM journals j JOIN operation_receipts r ON r.dataset_id=j.dataset_id AND r.operation_id=j.operation_id
          JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id AND l.line_number=1
          WHERE j.dataset_id=m.dataset_id AND j.reference=m.left_reference AND r.receipt_number=m.right_reference AND l.debit_minor_units=m.amount_minor_units))
        OR (run.kind='cash-day' AND NOT EXISTS (SELECT 1 FROM cash_declarations d WHERE d.dataset_id=m.dataset_id
          AND d.cash_session_id=m.left_reference AND d.id=m.right_reference AND d.counted_minor_units=m.amount_minor_units AND d.declared_minor_units=run.control_total_minor_units))
        OR (run.kind<>'cash-day' AND run.control_total_minor_units<>m.amount_minor_units)`).all()).toEqual([]);
    } finally { database.close(); }
  });
});
