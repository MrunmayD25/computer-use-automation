import { Worker } from 'node:worker_threads';
import { afterEach, expect, it } from 'vitest';

import { executeAtomicCommandBatch } from '../src/services/atomic-batch.js';
import { executeCommand } from '../src/services/commands.js';
import { openFinancialStore, type FinancialStore, type SqlDatabase } from '../src/services/store.js';
import type { ServiceCommand, ServiceContext } from '../src/services/types.js';
import { seedCore } from '../src/seed/core.js';
import { createCoreSeedFixture, createTestDatabasePath } from './conftest.js';

interface Fixture {
  path: string;
  store: FinancialStore;
  context: ServiceContext;
  memberId: string;
}

interface AtomicWorkerOptions {
  servicesUrl: string;
  path: string;
  context: ServiceContext;
  commands: ServiceCommand[];
  key: string;
  barrier: SharedArrayBuffer;
  exitBeforeReady?: boolean;
  barrierTimeoutMs?: number;
}

interface AtomicWorkerHandle {
  worker: Worker;
  ready: Promise<void>;
  result: Promise<Record<string, unknown>>;
}

const atomicWorkerSource = `
  const { parentPort, workerData } = require('node:worker_threads');
  (async () => {
    const { openFinancialStore, executeAtomicCommandBatch } = await import(workerData.servicesUrl);
    const store = openFinancialStore({ path: workerData.path, busyTimeoutMs: 10000 });
    try {
      if (workerData.exitBeforeReady) {
        parentPort.close();
        return;
      }
      parentPort.postMessage({ kind: 'ready' });
      const barrier = new Int32Array(workerData.barrier);
      if (Atomics.wait(barrier, 0, 0, workerData.barrierTimeoutMs) === 'timed-out') {
        throw new Error('atomic-worker-barrier-timeout');
      }
      parentPort.postMessage({ kind: 'result', outcome: executeAtomicCommandBatch(store, workerData.context, workerData.commands, workerData.key) });
    } finally {
      store.close();
    }
  })().catch(error => parentPort.postMessage({ kind: 'error', message: error?.stack ?? String(error) }));
`;

function runAtomicWorker(options: AtomicWorkerOptions): AtomicWorkerHandle {
  const worker = new Worker(atomicWorkerSource, {
    eval: true,
    workerData: { barrierTimeoutMs: 10_000, ...options },
  });
  let readyResolve: (() => void) | undefined;
  let readyReject: ((reason: Error) => void) | undefined;
  let resultResolve: ((value: Record<string, unknown>) => void) | undefined;
  let resultReject: ((reason: Error) => void) | undefined;
  let reportedReady = false;
  let reportedResult = false;
  const ready = new Promise<void>((resolve, reject) => { readyResolve = resolve; readyReject = reject; });
  const result = new Promise<Record<string, unknown>>((resolve, reject) => { resultResolve = resolve; resultReject = reject; });
  void result.catch(() => undefined);
  worker.on('message', (message: { kind: string; outcome?: Record<string, unknown>; message?: string }) => {
    if (message.kind === 'ready') {
      reportedReady = true;
      readyResolve?.();
    }
    if (message.kind === 'result' && message.outcome !== undefined) {
      reportedResult = true;
      resultResolve?.(message.outcome);
    }
    if (message.kind === 'error') {
      const error = new Error(message.message);
      readyReject?.(error);
      resultReject?.(error);
    }
  });
  worker.on('error', (error) => {
    readyReject?.(error);
    resultReject?.(error);
  });
  worker.on('exit', (code) => {
    if (!reportedResult) {
      const phase = reportedReady ? 'after readiness' : 'before readiness';
      const error = new Error(`Atomic worker exited ${phase} without a result (code ${code}).`);
      readyReject?.(error);
      resultReject?.(error);
    }
  });
  return { worker, ready, result };
}

const cleanups: (() => void)[] = [];
afterEach(() => {
  for (const cleanup of cleanups.reverse()) cleanup();
  cleanups.length = 0;
});

function fixture(): Fixture {
  const location = createTestDatabasePath();
  cleanups.push(() => location.cleanup());
  const seed = createCoreSeedFixture(location.path);
  seedCore(seed);
  const member = seed.database.prepare('SELECT id FROM members WHERE dataset_id=? ORDER BY id LIMIT 1').get(seed.binding.datasetId);
  if (typeof member?.id !== 'string') throw new Error('Missing seeded member.');
  seed.database.close();
  const store = openFinancialStore({ path: location.path });
  cleanups.push(() => store.close());
  return {
    path: location.path,
    store,
    context: { binding: seed.binding, actorId: 'actor-2', reference: 'atomic-batch-test' },
    memberId: member.id,
  };
}

function note(memberId: string, text: string): ServiceCommand {
  return { kind: 'member.note.add', memberId, visibility: 'general', text };
}

function counts(store: FinancialStore, datasetId: string): Record<string, number> {
  return store.read((database) => Object.fromEntries(['operations', 'operation_receipts', 'business_events', 'member_notes'].map((table) => {
    const row = database.prepare(`SELECT COUNT(*) AS count FROM ${table} WHERE dataset_id=?`).get(datasetId);
    if (typeof row?.count !== 'number') throw new Error(`Missing ${table} count.`);
    return [table, row.count];
  })));
}

it('rolls back every child effect and receipt for malformed and domain-invalid later children', () => {
  const { store, context, memberId } = fixture();
  const before = counts(store, context.binding.datasetId);
  expect(executeAtomicCommandBatch(store, context, [], 'atomic-empty-0001')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'commands' });
  expect(executeAtomicCommandBatch(store, context, Array.from({ length: 101 }, (_, index) => note(memberId, `Oversized ${index}`)), 'atomic-oversized-0001'))
    .toMatchObject({ kind: 'rejected', code: 'validation', field: 'commands' });
  const malformed = [note(memberId, 'First note must roll back'), { kind: 'member.note.add', memberId, visibility: 'general', text: 4 }] as unknown as ServiceCommand[];
  expect(executeAtomicCommandBatch(store, context, malformed, 'atomic-malformed-0001')).toMatchObject({ kind: 'rejected', code: 'validation', itemIndex: 1 });
  expect(counts(store, context.binding.datasetId)).toEqual(before);

  const domainInvalid = [note(memberId, 'First domain note must roll back'), note('missing-member', 'Missing member')];
  expect(executeAtomicCommandBatch(store, context, domainInvalid, 'atomic-domain-0001')).toMatchObject({ kind: 'rejected', code: 'not_found', itemIndex: 1 });
  expect(counts(store, context.binding.datasetId)).toEqual(before);
});

it('owns exact ordered payload replay and rejects shorter, longer, reordered, or changed reuse', () => {
  const { store, context, memberId } = fixture();
  const commands = [note(memberId, 'Atomic first note'), note(memberId, 'Atomic second note')];
  const committed = executeAtomicCommandBatch(store, context, commands, 'atomic-payload-0001');
  expect(committed.kind).toBe('committed');
  if (committed.kind !== 'committed') throw new Error(`Expected commit: ${JSON.stringify(committed)}`);
  expect(committed.receipt.operationKind).toBe('command.batch.atomic');
  expect(committed.receipt.result).toMatchObject({ commandCount: 2, items: [{ itemIndex: 0, kind: 'committed' }, { itemIndex: 1, kind: 'committed' }] });
  expect(committed.items.map((item) => item.outcome.kind)).toEqual(['committed', 'committed']);
  const afterCommit = counts(store, context.binding.datasetId);

  expect(executeAtomicCommandBatch(store, context, commands, 'atomic-payload-0001')).toEqual({ kind: 'duplicate', receipt: committed.receipt });
  for (const changed of [
    commands.slice(0, 1),
    [...commands, note(memberId, 'Atomic third note')],
    [...commands].reverse(),
    [commands[0] as ServiceCommand, note(memberId, 'Changed second note')],
  ]) {
    expect(executeAtomicCommandBatch(store, context, changed, 'atomic-payload-0001')).toMatchObject({ kind: 'rejected', code: 'idempotency_conflict' });
    expect(counts(store, context.binding.datasetId)).toEqual(afterCommit);
  }
});

it('treats refreshed child bindings as the same atomic intent while preserving payload conflicts', () => {
  const { store, context } = fixture();
  const account = store.read((database) => database.prepare("SELECT id,version FROM accounts WHERE dataset_id=? AND status='open' ORDER BY id LIMIT 1").get(context.binding.datasetId) as { id?: string; version?: number } | undefined);
  if (account?.id === undefined || account.version === undefined) throw new Error('Missing atomic account fixture.');
  const command = { kind: 'account.nickname.update' as const, accountId: account.id, expectedVersion: account.version, nickname: 'Atomic refreshed binding' };
  const committed = executeAtomicCommandBatch(store, context, [command], 'atomic-refreshed-binding-0001');
  expect(committed.kind).toBe('committed');
  if (committed.kind !== 'committed') throw new Error(`Expected commit: ${JSON.stringify(committed)}`);
  expect(executeAtomicCommandBatch(store, context, [{ ...command, expectedVersion: account.version + 1 }], 'atomic-refreshed-binding-0001'))
    .toEqual({ kind: 'duplicate', receipt: committed.receipt });
  expect(executeAtomicCommandBatch(store, context, [{ ...command, nickname: 'Changed payload' }], 'atomic-refreshed-binding-0001'))
    .toMatchObject({ kind: 'rejected', code: 'idempotency_conflict' });
});

it('isolates the internal parent and child keys from ordinary command keys', () => {
  const { store, context, memberId } = fixture();
  const key = 'atomic-isolation-0001';
  expect(executeAtomicCommandBatch(store, context, [note(memberId, 'Batch namespace note')], key).kind).toBe('committed');
  expect(executeCommand(store, context, note(memberId, 'Ordinary namespace note'), key).kind).toBe('committed');

  const before = counts(store, context.binding.datasetId);
  for (const reserved of [`internal:atomic-batch:parent:${'a'.repeat(64)}`, `internal:atomic-batch:child:${'b'.repeat(64)}:0`]) {
    expect(executeCommand(store, context, note(memberId, 'Reserved key must not run'), reserved)).toMatchObject({ kind: 'rejected', code: 'validation', field: 'idempotencyKey' });
    expect(executeAtomicCommandBatch(store, context, [note(memberId, 'Reserved batch key must not run')], reserved)).toMatchObject({ kind: 'rejected', code: 'validation', field: 'idempotencyKey' });
  }
  expect(counts(store, context.binding.datasetId)).toEqual(before);
});

it('rechecks current actor and role authority before returning a duplicate parent receipt', () => {
  const { store, context, memberId } = fixture();
  const commands = [note(memberId, 'Authority-bound atomic note')];
  const key = 'atomic-authority-0001';
  expect(executeAtomicCommandBatch(store, context, commands, key).kind).toBe('committed');
  store.write({ kind: 'system', actorId: context.actorId, reference: 'disable-batch-actor' }, (database) => {
    database.prepare("UPDATE actors SET status='disabled' WHERE dataset_id=? AND id=?").run(context.binding.datasetId, context.actorId);
  });
  expect(executeAtomicCommandBatch(store, context, commands, key)).toMatchObject({ kind: 'rejected', code: 'actor_inactive' });
  store.write({ kind: 'system', actorId: context.actorId, reference: 'expire-batch-role' }, (database) => {
    database.prepare("UPDATE actors SET status='active' WHERE dataset_id=? AND id=?").run(context.binding.datasetId, context.actorId);
    database.prepare('UPDATE actor_roles SET ends_at=? WHERE dataset_id=? AND actor_id=?').run('2026-09-14T15:00:00.000Z', context.binding.datasetId, context.actorId);
  });
  expect(executeAtomicCommandBatch(store, { ...context, now: '2026-09-14T15:00:00.000Z' }, commands, key)).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
});

it('serializes two stores racing the same batch into one commit and one duplicate', async () => {
  const { path, store, context, memberId } = fixture();
  const servicesUrl = new URL('../dist/services.js', import.meta.url).href;
  const commands = [note(memberId, 'Concurrent atomic note')];
  const before = counts(store, context.binding.datasetId);
  const barrier = new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT);
  const workerOptions = { servicesUrl, path, context, commands, key: 'atomic-concurrent-0001', barrier };
  const first = runAtomicWorker(workerOptions);
  const second = runAtomicWorker(workerOptions);
  let outcomes: Record<string, unknown>[];
  try {
    await Promise.all([first.ready, second.ready]);
    Atomics.store(new Int32Array(barrier), 0, 1);
    Atomics.notify(new Int32Array(barrier), 0, 2);
    outcomes = await Promise.all([first.result, second.result]);
  } finally {
    await Promise.allSettled([first.worker.terminate(), second.worker.terminate()]);
  }
  expect(outcomes.map((outcome) => outcome.kind).sort()).toEqual(['committed', 'duplicate']);
  const after = counts(store, context.binding.datasetId);
  expect(after.operations).toBe((before.operations ?? 0) + 2);
  expect(after.operation_receipts).toBe((before.operation_receipts ?? 0) + 2);
});

it('rejects readiness and result when an atomic worker exits cleanly before reporting', async () => {
  const { path, context, memberId } = fixture();
  const handle = runAtomicWorker({
    servicesUrl: new URL('../dist/services.js', import.meta.url).href,
    path,
    context,
    commands: [note(memberId, 'Unreported atomic note')],
    key: 'atomic-unreported-0001',
    barrier: new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT),
    exitBeforeReady: true,
  });
  let outcomes: PromiseSettledResult<unknown>[];
  try {
    outcomes = await Promise.allSettled([handle.ready, handle.result]);
  } finally {
    await handle.worker.terminate();
  }
  expect(outcomes).toHaveLength(2);
  for (const outcome of outcomes) {
    expect(outcome.status).toBe('rejected');
    if (outcome.status === 'rejected') {
      expect(outcome.reason).toMatchObject({ message: 'Atomic worker exited before readiness without a result (code 0).' });
    }
  }
});

it('rolls back all children when an unexpected failure is thrown during a later child', () => {
  const { store, context, memberId } = fixture();
  const before = counts(store, context.binding.datasetId);
  let noteInserts = 0;
  const writeWithFault: FinancialStore['write'] = (principal, callback) => store.write(principal, (database) => {
    const faultDatabase: SqlDatabase = {
      exec: (sql) => database.exec(sql),
      prepare: (sql) => {
          const statement = database.prepare(sql);
        if (/INSERT INTO member_notes/u.test(sql)) {
          const wrapped = {
            run: (...parameters: Parameters<typeof statement.run>): ReturnType<typeof statement.run> => {
              const result = statement.run(...parameters);
              noteInserts += 1;
              if (noteInserts === 2) throw new Error('injected-atomic-child-failure');
              return result;
            },
          };
          return wrapped as unknown as ReturnType<SqlDatabase['prepare']>;
        }
        return statement;
      },
    };
    return callback(faultDatabase);
  });
  const faultStore: FinancialStore = {
    read: (callback) => store.read(callback),
    close() {},
    write: writeWithFault,
  };
  expect(() => executeAtomicCommandBatch(faultStore, context, [note(memberId, 'First fault note'), note(memberId, 'Second fault note')], 'atomic-fault-0001')).toThrow('injected-atomic-child-failure');
  expect(noteInserts).toBe(2);
  expect(counts(store, context.binding.datasetId)).toEqual(before);
});
