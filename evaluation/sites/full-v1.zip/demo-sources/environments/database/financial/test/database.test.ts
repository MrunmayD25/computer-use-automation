import { describe, expect, it } from 'vitest';

import {
  DEFAULT_SEED_MANIFEST,
  openFinancialDatabase,
  type DatasetBinding,
} from '../src/public.js';
import { createTestDatabasePath } from './conftest.js';

describe('financial database', () => {
  it('seeds three institution-bound small datasets with diverse core records', async () => {
    const target = createTestDatabasePath();
    try {
      using database = openFinancialDatabase({ path: target.path });
      const result = await database.seedWorld({
        ...DEFAULT_SEED_MANIFEST,
        name: 'test-small',
        seed: 17,
        scale: 'small',
      });

      expect(result.kind).toBe('created');
      expect(result.bindings).toHaveLength(3);
      for (const binding of result.bindings) {
        const summary = database.dataset(binding).summary();
        expect(summary.members).toBeGreaterThanOrEqual(48);
        expect(summary.organizations).toBeGreaterThanOrEqual(4);
        expect(summary.accounts).toBeGreaterThan(summary.members);
        expect(summary.journalLines).toBeGreaterThan(2_000);
        expect(summary.documents).toBeGreaterThan(0);
        expect(summary.cases).toBeGreaterThan(0);
        expect(summary.loans).toBeGreaterThan(0);
      }
    } finally {
      target.cleanup();
    }
  });

  it('preserves a matching named world and rejects a changed manifest', async () => {
    const target = createTestDatabasePath();
    try {
      using database = openFinancialDatabase({ path: target.path });
      const manifest = { ...DEFAULT_SEED_MANIFEST, name: 'stable', seed: 31, scale: 'small' as const };
      const first = await database.seedWorld(manifest);
      const second = await database.seedWorld(manifest);
      expect(first.kind).toBe('created');
      expect(second).toEqual({ kind: 'existing', bindings: first.bindings });
      await expect(database.seedWorld({ ...manifest, seed: 32 })).rejects.toThrow(/manifest/i);
    } finally {
      target.cleanup();
    }
  });

  it('rejects an institution and dataset mismatch', async () => {
    const target = createTestDatabasePath();
    try {
      using database = openFinancialDatabase({ path: target.path });
      const world = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'binding', scale: 'small' });
      const first = world.bindings[0];
      const second = world.bindings[1];
      expect(first).toBeDefined();
      expect(second).toBeDefined();
      const invalid = {
        institutionId: first?.institutionId,
        datasetId: second?.datasetId,
      } as DatasetBinding;
      expect(() => database.dataset(invalid)).toThrow(/binding/i);
    } finally {
      target.cleanup();
    }
  });

  it('clones a dataset without sharing mutable rows', async () => {
    const target = createTestDatabasePath();
    try {
      using database = openFinancialDatabase({ path: target.path });
      const world = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'clone', scale: 'small' });
      const source = world.bindings[0];
      expect(source).toBeDefined();
      const clone = database.cloneDataset(source as DatasetBinding, 'case-copy');
      expect(clone.institutionId).toBe(source?.institutionId);
      expect(clone.datasetId).not.toBe(source?.datasetId);
      expect(database.dataset(clone).summary()).toEqual(database.dataset(source as DatasetBinding).summary());
    } finally {
      target.cleanup();
    }
  });
});
