import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import {
  accountTransactions, caseDetail, executeCommand, memberDetail, openFinancialStore, type CommandOutcome, type FinancialStore, type Receipt, type ServiceContext,
} from '../src/services.js';
import { withTrustedFixtureTransaction } from '../src/testing.js';

let directory: string;
let path: string;
let worldBindings: readonly DatasetBinding[];
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'financial-identity-notes-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  worldBindings = (await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'identity-notes-test', scale: 'small' })).bindings;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function clone(): DatasetBinding {
  const source = worldBindings.find((binding) => binding.institutionId === 'northstar');
  if (source === undefined) throw new Error('Missing northstar binding.');
  using database = openFinancialDatabase({ path });
  return database.cloneDataset(source);
}

/** Seeded actors: 1 viewer, 2 servicer, 3 payments maker, 5 supervisor. */
function context(binding: DatasetBinding, actorOrdinal: number): ServiceContext {
  return { binding, actorId: `${binding.institutionId}-actor-${actorOrdinal}`, reference: 'identity-notes-test' };
}

function viewer(binding: DatasetBinding, actorOrdinal: number): { institutionId: string; actorId: string } {
  return { institutionId: binding.institutionId, actorId: `${binding.institutionId}-actor-${actorOrdinal}` };
}

function sql<T>(query: string, ...parameters: (string | number | null)[]): T[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return database.prepare(query).all(...parameters) as T[];
}

function committed(outcome: CommandOutcome): Receipt {
  if (outcome.kind !== 'committed') throw new Error(`Expected a commit, received ${JSON.stringify(outcome)}`);
  return outcome.receipt;
}

const organization = {
  kind: 'member.organization.create' as const, legalName: 'Harbor Light Community Kitchen', registrationNumber: 'reg-7781-il', organizationType: 'nonprofit' as const,
  email: 'office@harborlight.example.test', phone: '+1 312 555 0142', address: { line1: '400 Pier Road', line2: 'Suite 2', city: 'Chicago', region: 'IL', postalCode: '60611', country: 'US' },
};

describe('organization members', () => {
  it('creates an organization member with its legal identity, derived tax class and contact points', () => {
    const binding = clone();
    const receipt = committed(executeCommand(store, context(binding, 2), organization, 'org-create-0001'));
    const member = receipt.affected.find((record) => record.kind === 'member');
    expect(member?.label).toMatch(/^NM\d{6}$/u);
    const detail = store.read((database) => memberDetail(database, binding.datasetId, member?.id ?? ''));
    expect(detail).toMatchObject({
      member: { kind: 'organization', displayName: 'Harbor Light Community Kitchen', status: 'active', taxClassification: 'tax-exempt', version: 1 },
      person: null,
      organization: { legalName: 'Harbor Light Community Kitchen', registrationNumber: 'REG-7781-IL', organizationType: 'nonprofit' },
      email: { value: 'office@harborlight.example.test' }, phone: { value: '+1 312 555 0142' },
      address: { line1: '400 Pier Road', line2: 'Suite 2', city: 'Chicago', evidenceStatus: 'unverified' },
    });
    expect(sql<{ kind: string; given_name: string | null; family_name: string }>('SELECT kind,given_name,family_name FROM name_history WHERE dataset_id=? AND party_id=?', binding.datasetId, detail?.member.partyId ?? ''))
      .toEqual([{ kind: 'legal', given_name: null, family_name: 'Harbor Light Community Kitchen' }]);
    expect(sql<{ classification: string }>('SELECT classification FROM tax_status_history WHERE dataset_id=? AND member_id=?', binding.datasetId, member?.id ?? ''))
      .toEqual([{ classification: 'tax-exempt' }]);
  });

  it('rejects a registration number already on file, bad input and operators without maintenance authority, writing nothing', () => {
    const binding = clone();
    const before = sql<{ count: number }>('SELECT COUNT(*) AS count FROM members WHERE dataset_id=?', binding.datasetId)[0]?.count;
    const seeded = sql<{ registration_number: string }>('SELECT registration_number FROM organizations WHERE dataset_id=? ORDER BY registration_number LIMIT 1', binding.datasetId)[0];
    if (seeded === undefined) throw new Error('The seed has no organizations.');
    expect(executeCommand(store, context(binding, 2), { ...organization, registrationNumber: seeded.registration_number.toLowerCase() }, 'org-create-0002'))
      .toMatchObject({ kind: 'rejected', code: 'duplicate_identity', field: 'registrationNumber' });
    expect(executeCommand(store, context(binding, 2), { ...organization, legalName: ' ' }, 'org-create-0003')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'legalName' });
    expect(executeCommand(store, context(binding, 2), { ...organization, registrationNumber: 'no spaces allowed' }, 'org-create-0004')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'registrationNumber' });
    const unknownType = { ...organization };
    Reflect.set(unknownType, 'organizationType', 'cooperative');
    expect(executeCommand(store, context(binding, 2), unknownType, 'org-create-0005')).toMatchObject({ kind: 'rejected', code: 'validation', field: 'organizationType' });
    expect(executeCommand(store, context(binding, 1), organization, 'org-create-0006')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM members WHERE dataset_id=?', binding.datasetId)[0]?.count).toBe(before);
  });

  it('accepts a legal name longer than a person name field', () => {
    const binding = clone();
    const legalName = 'Northern Lakes Regional Agricultural Producers Cooperative Association of Illinois';
    expect(legalName.length).toBeGreaterThan(60);
    const receipt = committed(executeCommand(store, context(binding, 2), { ...organization, legalName, registrationNumber: 'REG-LONG-0001', organizationType: 'corporation' }, 'org-create-0007'));
    const memberId = receipt.affected.find((record) => record.kind === 'member')?.id ?? '';
    expect(store.read((database) => memberDetail(database, binding.datasetId, memberId)?.member)).toMatchObject({ displayName: legalName, taxClassification: 'organization' });
  });
});

describe('restricted notes', () => {
  function firstMember(binding: DatasetBinding): string {
    return sql<{ id: string }>("SELECT id FROM members WHERE dataset_id=? AND status='active' ORDER BY member_number LIMIT 1", binding.datasetId)[0]?.id ?? '';
  }

  it('withholds restricted member notes from readers without case or supervisory authority and from unidentified readers', () => {
    const binding = clone();
    const memberId = firstMember(binding);
    const notes = (reader?: { institutionId: string; actorId: string }) => store.read((database) => memberDetail(database, binding.datasetId, memberId, reader));
    const baseline = notes(viewer(binding, 2));
    committed(executeCommand(store, context(binding, 2), { kind: 'member.note.add', memberId, visibility: 'restricted', text: 'Fraud referral on file; discuss only with the fraud team.' }, 'note-restricted-0001'));
    committed(executeCommand(store, context(binding, 2), { kind: 'member.note.add', memberId, visibility: 'general', text: 'Prefers morning calls.' }, 'note-general-0001'));
    const servicer = notes(viewer(binding, 2));
    expect(servicer?.notes.slice(0, 2).map((note) => [note.visibility, note.text])).toEqual([['general', 'Prefers morning calls.'], ['restricted', 'Fraud referral on file; discuss only with the fraud team.']]);
    expect(servicer?.restrictedNotesWithheld).toBe(0);
    expect(notes(viewer(binding, 5))?.notes).toHaveLength((baseline?.notes.length ?? 0) + 2);
    for (const reader of [viewer(binding, 1), viewer(binding, 3), undefined]) {
      const limited = notes(reader);
      expect(limited?.notes.some((note) => note.visibility === 'restricted')).toBe(false);
      expect(limited?.notes[0]?.text).toBe('Prefers morning calls.');
      expect(limited?.restrictedNotesWithheld).toBe((servicer?.notes.filter((note) => note.visibility === 'restricted').length ?? 0));
    }
  });

  it('refuses a restricted note from a note writer who lacks restricted authority but accepts a general one', () => {
    const binding = clone();
    const memberId = firstMember(binding);
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare("DELETE FROM role_permissions WHERE dataset_id=? AND permission='case.manage' AND role_id IN (SELECT role_id FROM actor_roles WHERE dataset_id=? AND actor_id=?)")
        .run(binding.datasetId, binding.datasetId, `${binding.institutionId}-actor-2`);
    });
    const count = (): number | undefined => sql<{ count: number }>('SELECT COUNT(*) AS count FROM member_notes WHERE dataset_id=?', binding.datasetId)[0]?.count;
    const before = count();
    expect(executeCommand(store, context(binding, 2), { kind: 'member.note.add', memberId, visibility: 'restricted', text: 'Sensitive.' }, 'note-restricted-0002'))
      .toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'visibility' });
    expect(count()).toBe(before);
    committed(executeCommand(store, context(binding, 2), { kind: 'member.note.add', memberId, visibility: 'general', text: 'Routine.' }, 'note-general-0002'));
    expect(count()).toBe((before ?? 0) + 1);
  });

  it('withholds restricted case notes the same way', () => {
    const binding = clone();
    const caseId = sql<{ id: string }>("SELECT id FROM cases WHERE dataset_id=? AND state<>'closed' ORDER BY case_number LIMIT 1", binding.datasetId)[0]?.id ?? '';
    committed(executeCommand(store, context(binding, 2), { kind: 'case.note.add', caseId, visibility: 'restricted', text: 'Law enforcement request reference LE-44.' }, 'case-note-0001'));
    const read = (reader?: { institutionId: string; actorId: string }) => store.read((database) => caseDetail(database, binding.datasetId, caseId, reader));
    expect(read(viewer(binding, 2))?.notes[0]).toMatchObject({ visibility: 'restricted', text: 'Law enforcement request reference LE-44.' });
    const hidden = read(viewer(binding, 1));
    expect(hidden?.notes.some((note) => note.text.includes('LE-44'))).toBe(false);
    expect(hidden?.restrictedNotesWithheld).toBeGreaterThanOrEqual(1);
    expect(read()?.notes.some((note) => note.visibility === 'restricted')).toBe(false);
  });
});

describe('transaction search by reference', () => {
  it('matches the whole journal reference, ignoring letter case, and nothing that merely contains it', () => {
    const binding = clone();
    const account = sql<{ id: string }>(`SELECT la.customer_account_id AS id FROM ledger_accounts la JOIN journal_lines jl ON jl.dataset_id=la.dataset_id AND jl.ledger_account_id=la.id
      WHERE la.dataset_id=? AND la.customer_account_id IS NOT NULL GROUP BY la.customer_account_id HAVING COUNT(*)>3 ORDER BY la.customer_account_id LIMIT 1`, binding.datasetId)[0]?.id ?? '';
    const all = store.read((database) => accountTransactions(database, binding.datasetId, account, { limit: 200, offset: 0 }));
    const target = all.items[1];
    if (target === undefined) throw new Error('The account has too little history.');
    const search = (reference: string) => store.read((database) => accountTransactions(database, binding.datasetId, account, { limit: 200, offset: 0, reference }));
    const exact = search(target.reference);
    expect(exact.total).toBeGreaterThan(0);
    expect(exact.items.every((row) => row.reference === target.reference)).toBe(true);
    expect(exact.total).toBe(all.items.filter((row) => row.reference === target.reference).length);
    expect(search(target.reference.slice(0, -1)).total).toBe(0);
    expect(search(target.reference.toLowerCase()).total).toBe(exact.total);
  });
});
