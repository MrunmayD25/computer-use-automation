import { copyFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { PNG } from 'pngjs';
import { encode as encodeJpeg } from 'jpeg-js';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase, type AccountListItem } from '../src/public.js';
import { openTrustedReadOnly } from '../src/testing.js';
import { auditDocuments, auditQueries, findAuditViolations } from '../src/verification/independent-audit.js';
import { createCoreSeedFixture, createTestDatabasePath } from './conftest.js';

it('independently rejects damaged PNG and JPEG payloads even with matching hashes', async () => {
  using database = new DatabaseSync(':memory:');
  database.exec('CREATE TABLE document_blobs(dataset_id TEXT,digest TEXT,media_type TEXT,byte_length INTEGER,bytes BLOB)');
  const pixels = Buffer.from([20,40,60,255]);
  const png = new PNG({width:1,height:1});
  png.data.set(pixels);
  const images = [
    {media:'image/png', bytes:PNG.sync.write(png), failure:'parseable PNG'},
    {media:'image/jpeg', bytes:encodeJpeg({width:1,height:1,data:pixels},80).data, failure:'parseable JPEG'},
  ];
  for (const sample of images) {
    for (const damaged of [false,true]) {
      database.exec('DELETE FROM document_blobs');
      const bytes = damaged ? sample.bytes.subarray(0, Math.floor(sample.bytes.length / 2)) : sample.bytes;
      database.prepare('INSERT INTO document_blobs VALUES (?,?,?,?,?)').run('disposable',createHash('sha256').update(bytes).digest('hex'),sample.media,bytes.length,bytes);
      const failures = await auditDocuments(database);
      if (damaged) {
        expect(failures.map(failure => failure.name)).toEqual([sample.failure]);
        expect(failures[0]?.witnesses[0]?.error).toEqual(expect.any(String));
      } else expect(failures).toEqual([]);
    }
  }
});

describe('independent available balance calculation', () => {
  it('preserves dataset ownership, empty accounts, ledger signs and active adjustments in discrepancy witnesses', () => {
    using database = createCoreSeedFixture().database;
    database.exec(`PRAGMA foreign_keys=OFF;
      INSERT INTO datasets SELECT 'first',institution_id,'first',seed,scale,as_of,generator_version,schema_version,revision FROM datasets WHERE id='domain-test';
      INSERT INTO datasets SELECT 'second',institution_id,'second',seed,scale,as_of,generator_version,schema_version,revision FROM datasets WHERE id='domain-test';
      INSERT INTO accounts(dataset_id,id,member_id,account_number,product_id,currency,status,nickname,statement_delivery,opened_at)
      VALUES ('first','shared','member','1','product','USD','open','','paper','2026-01-01'),
        ('second','shared','member','1','product','USD','open','','paper','2026-01-01'),
        ('first','empty','member','2','product','USD','open','','paper','2026-01-01'),
        ('first','empty-ledger','member','3','product','USD','open','','paper','2026-01-01');
      INSERT INTO ledger_accounts VALUES
        ('first','credit','credit','customer-deposit','USD','credit','shared'),
        ('first','debit','debit','customer-deposit','USD','debit','shared'),
        ('second','credit','credit','customer-deposit','USD','credit','shared'),
        ('first','empty','empty','customer-deposit','USD','credit','empty-ledger'),
        ('first','system','system','cash','USD','debit',NULL);
      INSERT INTO journals VALUES
        ('first','journal','1',NULL,'posted','2026-01-01','2026-01-01','',NULL),
        ('second','journal','1',NULL,'posted','2026-01-01','2026-01-01','',NULL);
      INSERT INTO journal_lines VALUES
        ('first','journal',1,'credit','USD',0,1000,''),
        ('first','journal',2,'credit','USD',100,0,''),
        ('first','journal',3,'debit','USD',200,0,''),
        ('first','journal',4,'debit','USD',0,50,''),
        ('first','journal',5,'system','USD',999999,0,''),
        ('second','journal',1,'credit','USD',0,300,'');
      INSERT INTO holds (dataset_id,id,account_id,amount_minor_units,status,reason,release_authority,placed_at,released_at) VALUES
        ('first','active','shared',40,'active','','','2026-01-01',NULL),
        ('first','inactive','shared',400,'released','','','2026-01-01',NULL),
        ('second','active','shared',5,'active','','','2026-01-01',NULL);
      INSERT INTO reservations VALUES
        ('first','active','shared','payment',70,'active','2026-01-01',NULL),
        ('first','inactive','shared','other-payment',700,'consumed','2026-01-01',NULL),
        ('second','active','shared','payment',7,'active','2026-01-01',NULL);
      INSERT INTO facilities VALUES
        ('first','active','shared','overdraft',200,20,'active'),
        ('first','inactive','shared','overdraft',1000,0,'suspended'),
        ('second','active','shared','overdraft',30,10,'active');`);
    const query = auditQueries.find((candidate) => candidate.name === 'independent available balances');
    if (query === undefined) throw new Error('Missing independent available balance audit.');
    expect(database.prepare(query.sql).all()).toEqual([]);

    const view = database.prepare("SELECT sql FROM sqlite_schema WHERE name='account_balances'").get()?.sql;
    if (typeof view !== 'string') throw new Error('Missing account balance view.');
    database.exec(`DROP VIEW account_balances;
      ${view.replace('CREATE VIEW account_balances', 'CREATE VIEW actual_account_balances')};
      CREATE VIEW account_balances AS SELECT dataset_id,account_id,currency,
        posted_balance_minor_units+1 AS posted_balance_minor_units,available_balance_minor_units
        FROM actual_account_balances;`);
    expect(database.prepare(`${query.sql} ORDER BY p.dataset_id,p.id`).all()).toEqual([
      { dataset_id: 'first', id: 'empty', amount: 0, held: 0, reserved: 0, credit: 0,
        posted_balance_minor_units: 1, available_balance_minor_units: 0 },
      { dataset_id: 'first', id: 'empty-ledger', amount: 0, held: 0, reserved: 0, credit: 0,
        posted_balance_minor_units: 1, available_balance_minor_units: 0 },
      { dataset_id: 'first', id: 'shared', amount: 1050, held: 40, reserved: 70, credit: 180,
        posted_balance_minor_units: 1051, available_balance_minor_units: 1120 },
      { dataset_id: 'second', id: 'shared', amount: 300, held: 5, reserved: 7, credit: 20,
        posted_balance_minor_units: 301, available_balance_minor_units: 308 },
    ]);
    database.exec(`DROP VIEW account_balances;
      CREATE VIEW account_balances AS SELECT dataset_id,account_id,currency,posted_balance_minor_units,
        available_balance_minor_units+CASE WHEN dataset_id='second' THEN 1 ELSE 0 END AS available_balance_minor_units
        FROM actual_account_balances;`);
    expect(database.prepare(query.sql).all()).toEqual([
      { dataset_id: 'second', id: 'shared', amount: 300, held: 5, reserved: 7, credit: 20,
        posted_balance_minor_units: 300, available_balance_minor_units: 309 },
    ]);
    database.exec(`DROP VIEW account_balances; DROP VIEW actual_account_balances; ${view};
      UPDATE journals SET status='reversed' WHERE dataset_id='first';`);
    expect(database.prepare(query.sql).all()).toEqual([]);
    database.exec(`DROP VIEW account_balances;
      ${view.replace('CREATE VIEW account_balances', 'CREATE VIEW actual_account_balances')};
      CREATE VIEW account_balances AS SELECT dataset_id,account_id,currency,
        posted_balance_minor_units+CASE WHEN dataset_id='first' AND account_id='shared' THEN 1050 ELSE 0 END AS posted_balance_minor_units,
        available_balance_minor_units FROM actual_account_balances;`);
    expect(database.prepare(query.sql).all()).toEqual([
      { dataset_id: 'first', id: 'shared', amount: 0, held: 40, reserved: 70, credit: 180,
        posted_balance_minor_units: 1050, available_balance_minor_units: 70 },
    ]);
  });
});

describe('independent persisted seed audit', () => {
  const target = createTestDatabasePath();

  beforeAll(async () => {
    using database = openFinancialDatabase({ path: target.path });
    await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'independent-audit', seed: 719, scale: 'small' });
  }, 120_000);

  afterAll(() => { target.cleanup(); });

  it.each(auditQueries)('$name holds after closing and reopening the seeded world', ({ sql }) => {
    const database = openTrustedReadOnly(target.path);
    try {
      expect(database.prepare('SELECT COUNT(*) AS count FROM datasets').get()).toEqual({ count: 3 });
      const violations = database.prepare(sql).all();
      expect({ count: violations.length, firstFive: violations.slice(0, 5) }).toEqual({ count: 0, firstFive: [] });
    } finally {
      database.close();
    }
  });

  it('persists real document bytes matching digests, formats, versions and page metadata', async () => {
    const database = openTrustedReadOnly(target.path);
    try {
      expect(await auditDocuments(database)).toEqual([]);
    } finally {
      database.close();
    }
  }, 120_000);

  it('returns every persisted account and its audited balances through bounded public pages', () => {
    using publicDatabase = openFinancialDatabase({ path: target.path });
    const persisted = openTrustedReadOnly(target.path);
    try {
      const bindings = publicDatabase.getNamedWorld('independent-audit');
      expect(bindings).toHaveLength(3);
      for (const binding of bindings) {
        const dataset = publicDatabase.dataset(binding);
        const accounts: AccountListItem[] = [];
        let cursor: string | undefined;
        for (let pageNumber = 0; pageNumber < 100; pageNumber++) {
          const page = dataset.accounts.list({ limit: 17, ...(cursor === undefined ? {} : { cursor }) });
          expect(page.items.length).toBeLessThanOrEqual(17);
          accounts.push(...page.items);
          if (page.nextCursor === null) break;
          cursor = page.nextCursor;
          if (pageNumber === 99) throw new Error('Account pagination did not terminate within 100 pages');
        }
        const expected = persisted.prepare(`SELECT a.id,a.account_number AS accountNumber,a.member_id AS memberId,
          p.code AS productCode,a.currency,a.status,b.posted_balance_minor_units AS postedBalanceMinorUnits,
          b.available_balance_minor_units AS availableBalanceMinorUnits
          FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id
          JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
          WHERE a.dataset_id=? ORDER BY a.id`).all(binding.datasetId);
        expect(accounts.length).toBeGreaterThanOrEqual(48);
        expect(accounts.sort((left, right) => left.id < right.id ? -1 : left.id > right.id ? 1 : 0)).toEqual(expected);
      }
    } finally {
      persisted.close();
    }
  });

  it.each([
    {
      name: 'a deposit maturity contract in the wrong currency', audit: 'deposit maturity contract scope',
      sql: `UPDATE deposit_maturity_terms SET currency=CASE currency WHEN 'USD' THEN 'EUR' ELSE 'USD' END
        WHERE rowid=(SELECT rowid FROM deposit_maturity_terms LIMIT 1)`,
    },
    {
      name: 'a missing cent in a journal leg', audit: 'balanced journals',
      sql: `UPDATE journal_lines SET debit_minor_units=debit_minor_units+1
        WHERE rowid=(SELECT rowid FROM journal_lines WHERE debit_minor_units>0 LIMIT 1)`,
    },
    {
      name: 'a journal line in the wrong currency', audit: 'consistent accounting currencies',
      sql: `UPDATE journal_lines SET currency=CASE currency WHEN 'USD' THEN 'EUR' ELSE 'USD' END
        WHERE rowid=(SELECT rowid FROM journal_lines LIMIT 1)`,
    },
    {
      name: 'a payment event after the frozen clock', audit: 'payment lifecycle',
      sql: `UPDATE payment_events SET occurred_at='2099-01-01T00:00:00.000Z'
        WHERE rowid=(SELECT rowid FROM payment_events LIMIT 1)`,
    },
    {
      name: 'a payment state detached from its history', audit: 'payment lifecycle',
      sql: `UPDATE payments SET state=CASE state WHEN 'draft' THEN 'settled' ELSE 'draft' END
        WHERE rowid=(SELECT rowid FROM payments LIMIT 1)`,
    },
    {
      name: 'a reservation exceeding its payment', audit: 'payment execution evidence',
      sql: `UPDATE reservations SET amount_minor_units=amount_minor_units+1
        WHERE rowid=(SELECT rowid FROM reservations LIMIT 1)`,
    },
    {
      name: 'an approval checked by its maker', audit: 'approval separation and scope',
      sql: `UPDATE business_approvals SET checker_actor_id=maker_actor_id
        WHERE rowid=(SELECT rowid FROM business_approvals WHERE status='approved' LIMIT 1)`,
    },
    {
      name: 'a refund exceeding the original fee', audit: 'remaining fee entitlement',
      sql: `UPDATE fee_refunds SET amount_minor_units=1000000000000
        WHERE rowid=(SELECT rowid FROM fee_refunds LIMIT 1)`,
    },
    {
      name: 'a loan balance detached from the ledger', audit: 'loan component accounting',
      sql: `UPDATE loan_components SET balance_minor_units=balance_minor_units+1
        WHERE rowid=(SELECT rowid FROM loan_components LIMIT 1)`,
    },
    {
      name: 'a document annotation beyond the final page', audit: 'document evidence relationships',
      sql: `UPDATE document_annotations SET page_number=1000000
        WHERE rowid=(SELECT rowid FROM document_annotations LIMIT 1)`,
    },
    {
      name: 'a world bound to the wrong institution', audit: 'institution dataset identity',
      sql: `UPDATE world_datasets SET institution_id='missing-institution'
        WHERE rowid=(SELECT rowid FROM world_datasets LIMIT 1)`,
    },
  ])('rejects $name in an isolated database copy', ({ audit, sql }) => {
    const corrupt = createTestDatabasePath();
    copyFileSync(target.path, corrupt.path);
    const database = new DatabaseSync(corrupt.path);
    try {
      database.exec('PRAGMA foreign_keys=OFF');
      const baseline = auditQueries.find((query) => query.name === audit);
      if (baseline === undefined) throw new Error(`Missing independent audit ${audit}`);
      const violations = database.prepare(baseline.sql).all();
      expect({ count: violations.length, firstFive: violations.slice(0, 5) }).toEqual({ count: 0, firstFive: [] });
      const change = database.prepare(sql).run();
      expect(change.changes).toBe(1);
      expect(findAuditViolations(database).map((failure) => failure.name)).toContain(audit);
    } finally {
      database.close();
      corrupt.cleanup();
    }
  });

  it('rejects altered document bytes even when their stored length still matches', async () => {
    const corrupt = createTestDatabasePath();
    copyFileSync(target.path, corrupt.path);
    const database = new DatabaseSync(corrupt.path);
    try {
      expect(await auditDocuments(database)).toEqual([]);
      const change = database.prepare(`UPDATE document_blobs SET bytes=zeroblob(byte_length)
        WHERE rowid=(SELECT rowid FROM document_blobs WHERE media_type='application/pdf' LIMIT 1)`).run();
      expect(change.changes).toBe(1);
      expect((await auditDocuments(database)).map((failure) => failure.name)).toContain('document digest');
    } finally {
      database.close();
      corrupt.cleanup();
    }
  }, 120_000);
});

it('requires operation and resource audit evidence for a lifecycle event after the seed clock', () => {
  using database=createCoreSeedFixture().database;
  database.exec(`PRAGMA foreign_keys=OFF;
    INSERT INTO cases(dataset_id,id,case_number,member_id,account_id,queue_id,assigned_actor_id,category,priority,state,summary,opened_at,due_at)
    VALUES ('domain-test','future-case','CASE-FUTURE','member',NULL,'queue',NULL,'general','normal','open','Later work','2026-09-15T15:00:00.000Z','2026-09-18T15:00:00.000Z');
    INSERT INTO case_events(dataset_id,id,case_id,sequence,state,occurred_at,actor_id,detail)
    VALUES ('domain-test','future-event','future-case',1,'open','2026-09-15T15:00:00.000Z','actor','Opened case');`);
  const query=auditQueries.find(item=>item.name==='case lifecycle');
  if(query===undefined) throw new Error('Missing lifecycle audit');
  expect(database.prepare(query.sql).all()).toHaveLength(1);
  database.exec(`INSERT INTO operations(dataset_id,id,actor_id,operation_kind,business_reference,idempotency_key,command_digest,status,occurred_at)
    VALUES ('domain-test','future-operation','actor','case.open','CASE-FUTURE','future-operation-key','digest','committed','2026-09-15T15:00:00.000Z');`);
  expect(database.prepare(query.sql).all()).toHaveLength(1);
  database.exec(`INSERT INTO business_events(dataset_id,id,actor_id,operation_id,sequence,occurred_at,kind,resource_kind,resource_id,summary)
    VALUES ('domain-test','future-audit','actor','future-operation',1,'2026-09-15T15:00:00.000Z','case.open','case','future-case','Opened case');`);
  expect(database.prepare(query.sql).all()).toEqual([]);
  database.exec("UPDATE business_events SET resource_id='other-case'");
  expect(database.prepare(query.sql).all()).toHaveLength(1);
});
