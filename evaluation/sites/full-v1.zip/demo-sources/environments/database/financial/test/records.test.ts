import {expect,it} from 'vitest';
import {createCoreSeedFixture} from './conftest.js';
import {seedCore} from '../src/seed/core.js';
import {createRecordReader} from '../src/records.js';

it('pages every composite journal key exactly once and rejects foreign or tampered cursors', () => {
  const context=createCoreSeedFixture();
  using database=context.database;
  seedCore(context);
  const records=createRecordReader(database,context.binding.datasetId,()=>undefined);
  const expected=database.prepare('SELECT journal_id,line_number FROM journal_lines ORDER BY journal_id,line_number').all().map(row=>`${String(row.journal_id)}:${String(row.line_number)}`);
  const found:string[]=[];
  let cursor:string|undefined;
  do {
    const page=records.list('journal_lines',{limit:73,...(cursor ? {cursor} : {})});
    found.push(...page.items.map(row=>`${String(row.journal_id)}:${String(row.line_number)}`));
    cursor=page.nextCursor ?? undefined;
  } while(cursor);
  expect(found).toEqual(expected);
  const first=records.list('members',{limit:2});
  if (!first.nextCursor) throw new Error('Expected member cursor.');
  expect(()=>records.list('accounts',{limit:2,cursor:first.nextCursor ?? ''})).toThrow(/cursor/i);
  expect(()=>records.list('members',{limit:101})).toThrow(/limit/i);
  expect(()=>records.list('members',{limit:2,cursor:'not a cursor'})).toThrow(/cursor/i);
  expect(()=>records.list('document_blobs' as 'documents',{limit:2})).toThrow(/table/i);
  expect(()=>records.list('members; DROP TABLE members' as 'members',{limit:2})).toThrow(/table/i);
  expect(records.list('role_permissions',{limit:100}).items.length).toBeGreaterThan(4);
  expect(records.list('party_relationships',{limit:100}).items.length).toBeGreaterThan(0);
});
