import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import { executeCommand, openFinancialStore, type CommandOutcome, type FinancialStore, type ServiceContext } from '../src/services.js';

let directory: string;
let path: string;
let worldBindings: readonly DatasetBinding[];
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'financial-case-routing-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  worldBindings = (await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'case-routing-test', scale: 'small' })).bindings;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function clone(): DatasetBinding {
  const source = worldBindings.find((binding) => binding.institutionId === 'northstar');
  if (source === undefined) throw new Error('Missing northstar binding.');
  using database = openFinancialDatabase({ path });
  return database.cloneDataset(source);
}

/** Seeded actors: 1 viewer, 2 servicer (case.manage), 5 supervisor (supervise). */
function context(binding: DatasetBinding, actorOrdinal: number): ServiceContext {
  return { binding, actorId: `${binding.institutionId}-actor-${actorOrdinal}`, reference: 'case-routing-test' };
}

function one(query: string, ...parameters: string[]): Record<string, unknown> {
  using database = new DatabaseSync(path, { readOnly: true });
  const row = database.prepare(query).get(...parameters);
  if (row === undefined) throw new Error(`No row for ${query}`);
  return { ...row };
}

const text = (value: unknown): string => typeof value === 'string' ? value : '';

function committed(outcome: CommandOutcome): void {
  if (outcome.kind !== 'committed') throw new Error(`Expected a commit, received ${JSON.stringify(outcome)}`);
}

describe('case routing exposure', () => {
  it('needs supervisory authority to route a restricted case into a wider queue', () => {
    const binding = clone();
    const queue = (code: string): string => text(one('SELECT id FROM queues WHERE dataset_id=? AND code=?', binding.datasetId, code).id);
    const found = one(`SELECT c.id, c.version FROM cases c JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id
      WHERE c.dataset_id=? AND q.code='RESTRICTED' AND c.state<>'closed' ORDER BY c.case_number LIMIT 1`, binding.datasetId);
    const restricted = { id: text(found.id), version: Number(found.version) };
    const stored = () => one('SELECT queue_id, version FROM cases WHERE dataset_id=? AND id=?', binding.datasetId, restricted.id);
    const widen = { kind: 'case.assign' as const, caseId: restricted.id, expectedVersion: restricted.version, queueId: queue('GENERAL'), assignedActorId: null, reason: 'Wider team' };

    expect(executeCommand(store, context(binding, 1), widen, 'route-viewer')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    expect(executeCommand(store, context(binding, 2), widen, 'route-servicer')).toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'queueId' });
    expect(stored()).toEqual({ queue_id: queue('RESTRICTED'), version: restricted.version });

    committed(executeCommand(store, context(binding, 5), widen, 'route-supervisor'));
    expect(stored()).toEqual({ queue_id: queue('GENERAL'), version: restricted.version + 1 });

    const narrow = { ...widen, expectedVersion: restricted.version + 1, queueId: queue('RESTRICTED'), reason: 'Back to the restricted team' };
    committed(executeCommand(store, context(binding, 2), narrow, 'route-narrow'));
    expect(stored()).toEqual({ queue_id: queue('RESTRICTED'), version: restricted.version + 2 });
  });
});
