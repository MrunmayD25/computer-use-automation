import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { DatasetId, InstitutionId } from '../src/model.js';
import { PDFDocument } from 'pdf-lib';
import { describe, expect, it } from 'vitest';

import { renderCsv, renderDocument, renderStatementPdf, renderScanPdf, renderScanPng, type StatementDocumentInput } from '../src/documents.js';

const statement: StatementDocumentInput = {
  institutionName: 'Northstar Cooperative', ownerName: 'Mara Vance', memberNumber: 'NM-001042',
  accountNumber: 'AC-000071', currency: 'USD', currencyExponent: 2,
  periodStart: '2026-08-01', periodEndExclusive: '2026-09-01',
  asOf: '2026-09-01T12:00:00Z', openingBalanceMinor: 100000,
  entries: [
    { reference: 'TX-001', date: '2026-08-03', description: 'Payroll deposit', amountMinor: 25000 },
    { reference: 'TX-002', date: '2026-08-04', description: 'Local market', amountMinor: -1240 },
  ],
};

function textOfPdf(bytes: Uint8Array): string {
  const directory = mkdtempSync(join(tmpdir(), 'financial-document-'));
  try {
    const input = join(directory, 'document.pdf');
    const output = join(directory, 'document.txt');
    writeFileSync(input, bytes);
    execFileSync('pdftotext', ['-layout', input, output]);
    return readFileSync(output, 'utf8');
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
}

describe('financial document bytes', () => {
  it('loads the real renderer in a native Node process and preserves deterministic bytes', async () => {
    const artifact = await renderStatementPdf(statement);
    const source = `import { renderStatementPdf } from ${JSON.stringify(new URL('../src/documents.ts', import.meta.url).href)};
      const artifact = await renderStatementPdf(${JSON.stringify(statement)});
      process.stdout.write(JSON.stringify({ digest: artifact.digest, mediaType: artifact.mediaType, pageCount: artifact.pageCount }));`;
    const output = execFileSync(process.execPath, ['--experimental-strip-types', '--input-type=module', '-e', source], { encoding: 'utf8' });
    expect(JSON.parse(output)).toEqual({ digest: artifact.digest, mediaType: 'application/pdf', pageCount: 1 });
  });
  it('renders a deterministic statement with exact identity, period, amounts, and history', async () => {
    const artifact = await renderStatementPdf(statement);
    const repeated = await renderStatementPdf(statement);
    expect(artifact.bytes).toEqual(repeated.bytes);
    expect(artifact.digest).toBe(createHash('sha256').update(artifact.bytes).digest('hex'));
    expect(artifact.mediaType).toBe('application/pdf');
    expect((await PDFDocument.load(artifact.bytes)).getPageCount()).toBe(1);
    const text = textOfPdf(artifact.bytes);
    expect(text).toContain('NM-001042');
    expect(text).toContain('AC-000071');
    expect(text).toContain('2026-08-01');
    expect(text).toContain('2026-09-01');
    expect(text).toContain('1,000.00 USD');
    expect(text).toContain('1,237.60 USD');
    expect(text).toContain('Payroll deposit');
    expect(text).toContain('TX-002');
  });

  it('paginates long histories while preserving all rows and the final balance', async () => {
    const entries = Array.from({ length: 125 }, (_, index) => ({
      reference: `ROW-${index.toString().padStart(3, '0')}`, date: '2026-08-10',
      description: `Approved transaction ${index}`, amountMinor: index % 2 === 0 ? 2 : -1,
    }));
    const artifact = await renderStatementPdf({ ...statement, entries });
    expect(artifact.pageCount).toBeGreaterThan(2);
    const text = textOfPdf(artifact.bytes);
    expect(text).toContain('ROW-000');
    expect(text).toContain('ROW-124');
    expect(text.match(/AC-000071/gu)?.length).toBeGreaterThanOrEqual(artifact.pageCount);
    expect(text).toContain('1,000.64 USD');
  });

  it('creates distinct immutable revisions and preserves visible synthetic evidence', async () => {
    const input = { title: 'Identity verification', institutionName: 'Northstar Cooperative',
      ownerName: 'Mara Vance', memberNumber: 'NM-001042', asOf: '2026-08-01T12:00:00Z',
      documentType: 'identity-evidence', version: 1,
      sections: [{ heading: 'Review evidence', lines: ['Status: verified', 'Expires: 2027-08-01'] }] };
    const first = await renderDocument(input);
    const second = await renderDocument({ ...input, version: 2,
      sections: [{ heading: 'Review evidence', lines: ['Status: expired', 'Expires: 2026-07-31'] }] });
    expect(first.digest).not.toBe(second.digest);
    expect(textOfPdf(first.bytes)).toContain('SYNTHETIC');
    expect(textOfPdf(first.bytes)).toContain('Status: verified');
    expect(textOfPdf(second.bytes)).toContain('Status: expired');
  });

  it('encodes CSV quoting, leading zeros, Unicode, and formula-like values safely', () => {
    const artifact = renderCsv({ columns: ['member', 'name', 'note'],
      rows: [['000071', 'Zoë O’Brien', '=HYPERLINK("https://example.test")'],
        ['000072', 'Lee, Jr.', 'Line one\nLine two']] });
    const csv = Buffer.from(artifact.bytes).toString('utf8');
    expect(csv).toContain('000071,Zoë O’Brien');
    expect(csv).toContain('"\'=HYPERLINK(""https://example.test"")"');
    expect(csv).toContain('"Lee, Jr."');
    expect(csv).toContain('"Line one\nLine two"');
    expect(artifact.digest).toBe(createHash('sha256').update(artifact.bytes).digest('hex'));
  });

  it('preserves supported Unicode and rejects unsupported glyphs', async () => {
    const artifact = await renderStatementPdf({ ...statement, ownerName: 'Zoë O’Brien — José Łukasz' });
    const text = textOfPdf(artifact.bytes);
    expect(text).toContain('Zoë O’Brien');
    expect(text).toContain('Łukasz');
    await expect(renderStatementPdf({ ...statement, ownerName: '漢字' })).rejects.toThrow(/glyph|supported/i);
  });

  it('produces deterministic legible scan PNGs and image-only rotated PDFs', async () => {
    const input = { title: 'Address verification', institutionName: 'Northstar Cooperative',
      ownerName: 'Mara Vance', memberNumber: 'NM-001042', asOf: '2026-08-01T12:00:00Z',
      documentType: 'address-evidence', version: 1,
      sections: [{ heading: 'Verified address', lines: ['42 Oak Street', 'Chicago IL 60601', 'Evidence reference EV-00042'] }] };
    const png = await renderScanPng(input);
    const repeat = await renderScanPng(input);
    expect(png.bytes).toEqual(repeat.bytes);
    expect(Buffer.from(png.bytes).subarray(0, 8).toString('hex')).toBe('89504e470d0a1a0a');
    expect(Buffer.from(png.bytes).readUInt32BE(16)).toBe(1224);
    expect(Buffer.from(png.bytes).readUInt32BE(20)).toBe(1584);
    const scanDirectory = mkdtempSync(join(tmpdir(), 'financial-scan-'));
    try {
      const scanPath = join(scanDirectory, 'scan.png');
      writeFileSync(scanPath, png.bytes);
      const visibleText = execFileSync('tesseract', [scanPath, 'stdout', '--psm', '6'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
      expect(visibleText).toContain('42 Oak Street');
      expect(visibleText).toContain('Chicago IL 60601');
      expect(visibleText).toContain('SYNTHETIC RECORD');
    } finally {
      rmSync(scanDirectory, { recursive: true, force: true });
    }
    const pdf = await renderScanPdf({ ...input, rotation: 90 });
    const parsed = await PDFDocument.load(pdf.bytes);
    expect(parsed.getPageCount()).toBe(1);
    expect(parsed.getPage(0).getRotation().angle).toBe(90);
    expect(textOfPdf(pdf.bytes).trim()).toBe('');
    expect(pdf.bytes.length).toBeGreaterThan(15000);
  });

  it('keeps conflicting embedded scan text explicitly separate from visible evidence', async () => {
    const input = { title: 'Address evidence', institutionName: 'Northstar Cooperative', ownerName: 'Mara Vance',
      memberNumber: 'NM-001042', asOf: '2026-08-01T12:00:00Z', documentType: 'address-evidence', version: 1,
      sections: [{ heading: 'Scanned original', lines: ['42 Oak Street', 'Visible evidence reference EV-042'] }],
      embeddedTranscript: 'Conflicting OCR transcript: 99 Pine Avenue' };
    const artifact = await renderScanPdf(input);
    expect(textOfPdf(artifact.bytes)).toContain('99 Pine Avenue');
    expect(artifact.extractedText).toBeUndefined();
    expect((await PDFDocument.load(artifact.bytes)).getPageCount()).toBe(1);
  });

  it('rejects fractional, overflowing, and out-of-period accounting input', async () => {
    await expect(renderStatementPdf({ ...statement, openingBalanceMinor: 0.5 })).rejects.toThrow(/integer/i);
    await expect(renderStatementPdf({ ...statement, openingBalanceMinor: Number.MAX_SAFE_INTEGER })).rejects.toThrow(/range|overflow/i);
    await expect(renderStatementPdf({ ...statement, entries: [{ reference: 'BAD', date: '2026-09-01', description: 'Outside', amountMinor: 1 }] })).rejects.toThrow(/period/i);
  });
});

it('seeds linked document and servicing lifecycles with real historical statements', async () => {
  const { DatabaseSync } = await import('node:sqlite');
  const { createSchema } = await import('../src/schema.js');
  const { seedCore } = await import('../src/seed/core.js');
  const { seedFinancialDomains } = await import('../src/seed/financial.js');
  const { createSeedRandom } = await import('../src/seed/random.js');
  const { seedDocumentsAndServicing } = await import('../src/seed/documents-servicing.js');
  const directory = mkdtempSync(join(tmpdir(), 'financial-document-seed-'));
  const path = join(directory, 'world.sqlite');
  try {
    using database = new DatabaseSync(path);
    createSchema(database);
    const institution = { id: 'northstar', legalName: 'Northstar Cooperative', displayName: 'Northstar Cooperative',
      timeZone: 'America/Chicago', defaultCurrency: 'USD' as const };
    const binding = { institutionId: 'northstar' as InstitutionId, datasetId: 'document-test' as DatasetId };
    database.prepare('INSERT INTO institutions VALUES (?,?,?,?,?,?)').run('northstar', institution.legalName, institution.displayName, 'US', institution.timeZone, 'USD');
    database.prepare('INSERT INTO datasets (id,institution_id,name,seed,scale,as_of,generator_version,schema_version,revision) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(binding.datasetId, binding.institutionId, 'documents', 42, 'small', '2026-09-14T15:00:00.000Z', '1', 1, 0);
    const context = { database, binding, institution, scale: 'small' as const, profile: { membersPerInstitution: 48, organizationsPerInstitution: 4,
      historyMonths: 18, ordinaryJournalTransactionsPerAccount: 20 }, seed: 42, asOf: '2026-09-14T15:00:00.000Z',
      random: createSeedRandom(42), id: (kind: string, ordinal: number | string): string => `${kind}-${ordinal}`,
      businessNumber: (prefix: string, ordinal: number, width = 6): string => `${prefix}-${ordinal.toString().padStart(width, '0')}` };
    const refs = seedCore(context);
    seedFinancialDomains(context, refs);
    const result = await seedDocumentsAndServicing(context, refs);
    expect(result.caseIds.length).toBeGreaterThanOrEqual(48);
    const closureEvidence = database.prepare(`SELECT COUNT(*) AS count FROM loan_closures c
      JOIN document_versions v ON v.dataset_id=c.dataset_id AND v.id=c.closure_document_version_id
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE c.dataset_id=? AND d.document_type='loan-closure-confirmation'`).get(binding.datasetId);
    expect(Number(closureEvidence?.count)).toBeGreaterThanOrEqual(1);
    using inspection = new DatabaseSync(path, { readOnly: true });
    const states = inspection.prepare('SELECT DISTINCT state FROM communication_jobs WHERE dataset_id=? ORDER BY state').all(binding.datasetId);
    expect(states.map(row => row.state)).toEqual(['accepted', 'bounced', 'cancelled', 'delivered', 'draft', 'queued']);
    const consentStates = inspection.prepare('SELECT DISTINCT state FROM consents WHERE dataset_id=? ORDER BY state').all(binding.datasetId);
    expect(consentStates.map(row => row.state)).toEqual(['expired', 'granted', 'pending', 'withdrawn']);
    const queuedAfterWithdrawal = inspection.prepare(`SELECT COUNT(*) AS count FROM communication_jobs j
      JOIN document_versions v ON v.dataset_id=j.dataset_id AND v.id=j.document_version_id
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN consents c ON c.dataset_id=j.dataset_id AND c.party_id=j.party_id AND c.purpose=j.purpose
        AND (c.account_id=d.account_id OR c.account_id IS NULL)
      WHERE j.dataset_id=? AND j.state='queued' AND c.state='withdrawn' AND j.created_at<c.effective_at`).get(binding.datasetId);
    expect(Number(queuedAfterWithdrawal?.count)).toBeGreaterThanOrEqual(2);
    const signedEvidence = inspection.prepare(`SELECT COUNT(*) AS count FROM signatures s JOIN document_versions v
      ON v.dataset_id=s.dataset_id AND v.id=s.evidence_reference JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE s.dataset_id=? AND s.status='signed' AND d.document_type='signature-evidence'`).get(binding.datasetId);
    expect(Number(signedEvidence?.count)).toBeGreaterThanOrEqual(12);
    const filing = inspection.prepare(`SELECT COUNT(*) AS count FROM case_documents c JOIN document_annotations a
      ON a.dataset_id=c.dataset_id AND a.document_version_id=c.document_version_id WHERE c.dataset_id=?`).get(binding.datasetId);
    expect(Number(filing?.count)).toBeGreaterThanOrEqual(8);
    const preferenceJobs = inspection.prepare(`SELECT COUNT(*) AS count FROM communication_jobs j JOIN communication_preferences p
      ON p.dataset_id=j.dataset_id AND p.party_id=j.party_id AND p.channel=j.channel WHERE j.dataset_id=? AND j.state='queued'`).get(binding.datasetId);
    expect(Number(preferenceJobs?.count)).toBeGreaterThanOrEqual(4);
    const disputeFiles = inspection.prepare(`SELECT COUNT(*) AS count FROM dispute_evidence e JOIN document_versions v
      ON v.dataset_id=e.dataset_id AND v.id=e.document_version_id AND v.digest=e.digest WHERE e.dataset_id=?`).get(binding.datasetId);
    expect(Number(disputeFiles?.count)).toBeGreaterThanOrEqual(4);
    const counts = inspection.prepare(`SELECT COUNT(*) AS count FROM documents d
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
      JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      WHERE d.dataset_id=? AND d.document_type='account-statement' AND b.byte_length>1000`).get(binding.datasetId);
    expect(Number(counts?.count)).toBeGreaterThanOrEqual(12);
    const missing = inspection.prepare(`SELECT COUNT(*) AS count FROM cases c JOIN case_dependencies dep
      ON dep.dataset_id=c.dataset_id AND dep.case_id=c.id
      WHERE c.dataset_id=? AND c.state IN ('closed','resolved') AND dep.state='open'`).get(binding.datasetId);
    expect(missing?.count).toBe(0);
    expect(inspection.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
    const linked = inspection.prepare(`SELECT COUNT(*) AS count FROM case_documents cd
      JOIN documents d ON d.dataset_id=cd.dataset_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id AND v.id=cd.document_version_id
      JOIN cases c ON c.dataset_id=cd.dataset_id AND c.id=cd.case_id
      JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id
      WHERE cd.dataset_id=? AND d.owner_party_id=m.party_id`).get(binding.datasetId);
    expect(Number(linked?.count)).toBeGreaterThanOrEqual(96);
    const derivative = inspection.prepare(`SELECT b.bytes,a.line1 FROM document_derivations der
      JOIN document_versions v ON v.dataset_id=der.dataset_id AND v.id=der.derivative_version_id
      JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest
      JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      JOIN party_addresses pa ON pa.dataset_id=d.dataset_id AND pa.party_id=d.owner_party_id
      JOIN addresses a ON a.dataset_id=pa.dataset_id AND a.id=pa.address_id
      WHERE der.dataset_id=? ORDER BY der.id,pa.id LIMIT 1`).get(binding.datasetId);
    if (derivative === undefined || !(derivative.bytes instanceof Uint8Array) || typeof derivative.line1 !== 'string') {
      throw new Error('Missing redacted document bytes and source address.');
    }
    const derivativeText = textOfPdf(derivative.bytes);
    expect(derivativeText).toContain('Evidence received for address review.');
    expect(derivativeText).not.toContain(derivative.line1);
    for (const row of inspection.prepare('SELECT digest,bytes,byte_length FROM document_blobs WHERE dataset_id=?').all(binding.datasetId)) {
      if (!(row.bytes instanceof Uint8Array)) throw new Error('Document blob is not bytes.');
      expect(row.bytes.length).toBe(row.byte_length);
      expect(createHash('sha256').update(row.bytes).digest('hex')).toBe(row.digest);
    }
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});
