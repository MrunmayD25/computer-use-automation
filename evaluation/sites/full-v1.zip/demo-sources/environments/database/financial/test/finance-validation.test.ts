import { describe, expect, it } from 'vitest';

import { validateFinanceQuery, validateServiceCommand, type FinanceCommand } from '../src/services.js';
import { normalizeInstant } from '../src/services/finance-support.js';

const USD = { minorUnits: 1_000, currency: 'USD' } as const;

const VALID_COMMANDS = [
  { kind: 'member.merge', mergePlanId: 'plan-1', sourceMemberId: 'member-1', targetMemberId: 'member-2', expectedSourceVersion: 1, expectedTargetVersion: 1, relationshipAccountIds: ['account-1'], expectedInventoryFingerprint: 'a'.repeat(64), approvalId: 'approval-1' },
  { kind: 'member.deceased.record', memberId: 'member-1', expectedVersion: 1, evidenceId: 'evidence-1', effectiveDate: '2026-09-14', approvalId: 'approval-1' },
  { kind: 'member.beneficial_owners.update', organizationMemberId: 'member-1', expectedVersion: 1, owners: [{ memberId: 'member-2', ownershipBps: 10_000, isControlPerson: true, evidenceId: 'evidence-1' }], effectiveDate: '2026-09-14', approvalId: 'approval-1' },
  { kind: 'member.tax_classification.update', memberId: 'member-1', expectedVersion: 1, classification: 'individual', effectiveYear: 2027, evidenceId: 'evidence-1', approvalId: 'approval-1' },
  { kind: 'account.product.convert', accountId: 'account-1', expectedVersion: 1, targetProductId: 'product-1', effectiveDate: '2026-09-14', feeDisclosureAccepted: true, approvalId: 'approval-1' },
  { kind: 'account.owner.add', accountId: 'account-1', expectedVersion: 1, memberId: 'member-1', role: 'joint-owner', effectiveDate: '2026-09-14', identityEvidenceId: 'evidence-1', consentId: 'consent-1', approvalId: 'approval-1' },
  { kind: 'account.signer.remove', accountId: 'account-1', expectedVersion: 1, signerMemberId: 'member-1', effectiveAt: '2026-09-14T16:00:00.000Z', approvalId: 'approval-1' },
  { kind: 'account.overdraft_limit.update', accountId: 'account-1', expectedVersion: 1, expectedFacilityFingerprint: null, limit: USD, effectiveDate: '2026-09-14', expiresAt: null, approvalId: 'approval-1' },
  { kind: 'account.hold.place', accountId: 'account-1', expectedVersion: 1, amount: USD, reason: 'Review', expiresAt: '2026-09-15T15:00:00.000Z', releaseAuthority: 'case-1' },
  { kind: 'account.hold.release', holdId: 'hold-1', expectedFingerprint: 'fingerprint', amountMinorUnits: 500, releaseAuthority: 'case-1', evidenceReference: 'evidence-1' },
  { kind: 'account.restriction.apply', accountId: 'account-1', expectedVersion: 1, restrictionType: 'debit-block', reason: 'Review', authority: 'policy-1', caseId: 'case-1', approvalId: 'approval-1' },
  { kind: 'account.restriction.release', restrictionId: 'restriction-1', expectedFingerprint: 'fingerprint', clearanceEvidenceId: 'evidence-1', approvalId: 'approval-1' },
  { kind: 'fee.assess', accountId: 'account-1', expectedVersion: 1, feeCode: 'monthly', amount: USD, basis: 'Policy fee', policyVersionId: 'policy-1' },
  { kind: 'fee.waiver.create', accountId: 'account-1', feeCode: 'monthly', validFrom: '2026-09-14', validThrough: '2026-10-14', amountLimit: USD, maxOccurrences: 1, reason: 'Courtesy', approvalId: 'approval-1' },
  { kind: 'fee.refund', feeId: 'fee-1', expectedFingerprint: 'fingerprint', amount: USD, reason: 'Correction' },
  { kind: 'cash.deposit.reverse', journalId: 'journal-1', expectedFingerprint: 'fingerprint', correctionEvidenceId: 'evidence-1', approvalId: 'approval-1' },
  { kind: 'cash.withdrawal.reverse', journalId: 'journal-1', expectedFingerprint: 'fingerprint', reason: 'Correction', approvalId: 'approval-1' },
  { kind: 'transfer.internal.reverse', transferJournalId: 'journal-1', expectedFingerprint: 'fingerprint', amount: USD, reason: 'Correction', approvalId: 'approval-1' },
  { kind: 'interest.adjust', accountId: 'account-1', calculationId: 'calculation-1', expectedFingerprint: 'fingerprint', approvedDelta: USD, approvalId: 'approval-1' },
  { kind: 'transaction.effective_date.correct', journalId: 'journal-1', expectedFingerprint: 'fingerprint', correctedDate: '2026-09-14', policyVersionId: 'policy-1', reason: 'Correction', approvalId: 'approval-1' },
  { kind: 'beneficiary.create', memberId: 'member-1', expectedMemberVersion: 1, displayName: 'Payee', routingKind: 'ach', maskedDestination: '****1234', simulatedToken: 'token-1', allowedRails: ['ach'] },
  { kind: 'beneficiary.verify', beneficiaryId: 'beneficiary-1', routeId: 'route-1', expectedFingerprint: 'fingerprint', evidenceId: 'evidence-1', approvalId: 'approval-1' },
  { kind: 'beneficiary.routing.update', beneficiaryId: 'beneficiary-1', expectedRouteFingerprint: 'fingerprint', routingKind: 'ach', maskedDestination: '****4321', simulatedToken: 'token-2', effectiveDate: '2026-09-14', approvalId: 'approval-1' },
  { kind: 'beneficiary.retire', beneficiaryId: 'beneficiary-1', expectedFingerprint: 'fingerprint', dependentDisposition: 'reject-if-active', reason: 'Unused' },
  { kind: 'payment.create', sourceAccountId: 'account-1', expectedSourceVersion: 1, beneficiaryRouteId: 'route-1', expectedRouteFingerprint: 'fingerprint', amount: USD, rail: 'ach', requestedDate: '2026-09-14', calendarVersion: 'US-FI-2026.1', cutoffAt: '2026-09-14T21:00:00.000Z', reference: 'Invoice', targetState: 'draft' },
  { kind: 'payment.submit', paymentId: 'payment-1', expectedVersion: 1 },
  { kind: 'payment.approve_release', paymentId: 'payment-1', expectedVersion: 1, requestedDate: '2026-09-14', calendarVersion: 'US-FI-2026.1', cutoffAt: '2026-09-14T21:00:00.000Z', approvalId: 'approval-1' },
  { kind: 'payment.settle', paymentId: 'payment-1', expectedVersion: 1, settlementReference: 'settlement-1' },
  { kind: 'payment.schedule.create', sourceAccountId: 'account-1', expectedSourceVersion: 1, beneficiaryRouteId: 'route-1', expectedRouteFingerprint: 'fingerprint', amount: USD, frequency: 'monthly', interval: 1, startDate: '2026-09-14', endDate: '2027-09-14', approvalId: 'approval-1' },
  { kind: 'payment.schedule.materialize', occurrenceId: 'occurrence-1', expectedFingerprint: 'fingerprint' },
  { kind: 'payment.occurrence.amend', occurrenceId: 'occurrence-1', expectedFingerprint: 'fingerprint', newAmount: USD, newDate: '2026-09-14' },
  { kind: 'payment.cancel', paymentId: 'payment-1', expectedVersion: 1, reason: 'Customer request' },
  { kind: 'payment.return.resolve', returnId: 'return-1', expectedFingerprint: 'fingerprint', paymentId: 'payment-1', disposition: 'credit-source', approvalId: 'approval-1' },
  { kind: 'card.replace', cardId: 'card-1', expectedFingerprint: 'fingerprint', reason: 'Lost', identityEvidenceId: 'evidence-1', deliveryDestinationId: 'destination-1', deliveryAddressId: 'address-1' },
  { kind: 'card.lock.update', cardId: 'card-1', expectedFingerprint: 'fingerprint', requestedState: 'locked', authority: 'Customer' },
  { kind: 'card.limit.update', cardId: 'card-1', expectedFingerprint: 'fingerprint', limitKind: 'cash', amount: USD, effectiveAt: '2026-09-14T15:00:00.000Z', expiresAt: null, approvalId: 'approval-1' },
  { kind: 'dispute.open', cardTransactionId: 'transaction-1', expectedFingerprint: 'fingerprint', reason: 'Unknown purchase', assertedAmount: USD, evidenceIds: [] },
  { kind: 'dispute.provisional_credit.issue', disputeId: 'dispute-1', expectedFingerprint: 'fingerprint', amount: USD, approvalId: 'approval-1' },
  { kind: 'dispute.evidence.submit', disputeId: 'dispute-1', expectedFingerprint: 'fingerprint', documentVersionIds: ['document-version-1'], deadline: '2026-10-01T00:00:00.000Z', recipient: 'simulated-card-network', channel: 'simulated-dispute-channel', approvalId: 'approval-1' },
  { kind: 'dispute.settle', disputeId: 'dispute-1', expectedFingerprint: 'fingerprint', decision: 'approved', finalAmount: USD, approvalId: 'approval-1' },
  { kind: 'loan.application.prepare', memberId: 'member-1', expectedMemberVersion: 1, productId: 'product-1', requestedAmount: USD, termMonths: 36, purpose: 'Vehicle', evidenceIds: ['evidence-1'] },
  { kind: 'loan.payment.allocate', loanId: 'loan-1', expectedFingerprint: 'fingerprint', receivedFundsReference: 'funds-1', amount: USD, allocationPolicy: 'fees-interest-principal' },
  { kind: 'loan.payoff.quote', loanId: 'loan-1', expectedFingerprint: 'fingerprint', payoffDate: '2026-09-14', policyVersionId: 'policy-1' },
  { kind: 'reconciliation.suspense.investigate', suspenseId: 'suspense-1', expectedFingerprint: 'fingerprint', evidenceReferences: ['evidence-1'], proposedAccountId: null },
  { kind: 'reconciliation.suspense.clear', suspenseId: 'suspense-1', expectedFingerprint: 'fingerprint', destinationAccountId: 'account-1', amount: USD, evidenceReference: 'evidence-1', approvalId: 'approval-1' },
  { kind: 'batch.import', documentVersionId: 'document-version-1', inputDigest: 'a'.repeat(64), batchNumber: 'batch-1', batchKind: 'fee-refund', currency: 'USD' },
  { kind: 'batch.contacts.apply', batchId: 'batch-1', itemId: 'item-1', expectedFingerprint: 'fingerprint', approvalId: 'approval-1', conflictPolicy: 'skip-stale' },
  { kind: 'batch.fee_refunds.apply', batchId: 'batch-1', itemId: 'item-1', expectedFingerprint: 'fingerprint', approvalId: 'approval-1' },
  { kind: 'payment.schedule.end', scheduleId: 'schedule-1', expectedFingerprint: 'fingerprint', endFromDate: '2026-09-14', pendingDisposition: 'cancel-planned', approvalId: 'approval-1' },
  { kind: 'account.maturity.instruct', accountId: 'account-1', expectedVersion: 1, expectedInstructionFingerprint: null, disposition: 'hold', destinationAccountId: null, termMonths: null, approvedAnnualRateBps: null, approvalId: 'approval-1' },
  { kind: 'transaction.description.update', journalId: 'journal-1', expectedFingerprint: 'fingerprint', description: 'Correct description' },
  { kind: 'loan.close', loanId: 'loan-1', expectedFingerprint: 'fingerprint', payoffEvidenceId: 'quote-1', approvalId: 'approval-1' },
  { kind: 'document.loan_closure.issue', loanId: 'loan-1', expectedClosureFingerprint: 'fingerprint', templateVersionId: 'document-version-1', recipientPartyId: 'party-1', documentType: 'loan-closure-confirmation', approvalId: 'approval-1' },
] as const satisfies readonly FinanceCommand[];

function validCommand(kind: FinanceCommand['kind']): FinanceCommand {
  const command = VALID_COMMANDS.find((candidate) => candidate.kind === kind);
  if (command === undefined) throw new Error(`Missing valid ${kind} command fixture.`);
  return command;
}

describe('finance boundary validation', () => {
  it('canonicalizes offset-equivalent instants and rejects malformed or offset-free values', () => {
    expect(normalizeInstant('2026-09-14T10:00:00-05:00')).toBe('2026-09-14T15:00:00.000Z');
    expect(normalizeInstant('2026-09-14T15:00:00Z')).toBe('2026-09-14T15:00:00.000Z');
    expect(normalizeInstant('2026-09-14T15:00:00')).toBeNull();
    expect(normalizeInstant('2026-02-30T15:00:00Z')).toBeNull();
    expect(normalizeInstant('2026-09-14')).toBeNull();
  });

  it('accepts the complete finance command vocabulary and rejects missing, unknown and wrong primitive fields', () => {
    for (const command of VALID_COMMANDS) {
      expect(validateServiceCommand(command), command.kind).toBeNull();
      expect(validateServiceCommand({ ...command, extra: true }), command.kind).toMatchObject({ kind: 'rejected', code: 'validation', field: 'extra' });
      const entries = Object.entries(command).filter(([field]) => field !== 'kind');
      const [required] = entries;
      if (required === undefined) throw new Error(`Command ${command.kind} has no required input.`);
      const missing = Object.fromEntries(Object.entries(command).filter(([field]) => field !== required[0]));
      expect(validateServiceCommand(missing), command.kind).toMatchObject({ kind: 'rejected', code: 'validation', field: required[0] });
      for (const [field, value] of entries) {
        const wrong = Array.isArray(value) ? 1 : value !== null && typeof value === 'object' ? 'wrong' : typeof value === 'number' ? 'wrong' : typeof value === 'boolean' ? 'wrong' : { wrong: true };
        expect(validateServiceCommand({ ...command, [field]: wrong }), `${command.kind}.${field}`).toMatchObject({ kind: 'rejected', code: 'validation', field });
      }
    }
  });

  it('validates nested money and owners exactly and keeps enum choices scoped to their command', () => {
    expect(validateServiceCommand({ ...validCommand('account.hold.place'), amount: { ...USD, extra: 1 } })).toMatchObject({ field: 'amount' });
    expect(validateServiceCommand({ ...validCommand('member.beneficial_owners.update'), owners: [{ memberId: 'member-2', ownershipBps: 10_000, isControlPerson: true, evidenceId: 'evidence-1', extra: true }] })).toMatchObject({ field: 'owners' });
    expect(validateServiceCommand({ ...validCommand('payment.return.resolve'), disposition: 'renew' })).toMatchObject({ field: 'disposition' });
    expect(validateServiceCommand({ ...validCommand('account.maturity.instruct'), disposition: 'investigate' })).toMatchObject({ field: 'disposition' });
    expect(validateServiceCommand({ ...validCommand('account.hold.place'), expiresAt: null })).toMatchObject({ field: 'expiresAt' });
    expect(validateServiceCommand({ ...validCommand('loan.application.prepare'), termMonths: null })).toMatchObject({ field: 'termMonths' });
    expect(validateServiceCommand({ kind: 'toString' })).toMatchObject({ kind: 'rejected', code: 'validation', field: 'kind' });
  });

  it('rejects malformed query kinds, fields, arrays, record kinds and controls', () => {
    expect(validateFinanceQuery({ kind: 'finance.record', resource: 'payment', id: 'payment-1' })).toBeNull();
    expect(validateFinanceQuery({ kind: 'finance.record', resource: 'received-funds', id: 'funds-1' })).toBeNull();
    expect(validateFinanceQuery({ kind: 'finance.record', resource: 'facility', id: 'facility-1' })).toBeNull();
    expect(validateFinanceQuery({ kind: 'finance.record', resource: 'secret-route', id: 'route-1' })).toMatchObject({ field: 'resource' });
    expect(validateFinanceQuery({ kind: 'reconciliation.transfer', transferJournalId: 'journal-1', expectedFingerprint: 'fingerprint', mutate: true })).toMatchObject({ field: 'mutate' });
    expect(validateFinanceQuery({ kind: 'batch.preview', batchId: 'batch-1', expectedFingerprint: 'fingerprint', inputDigest: 'digest', schemaVersion: '1', allowedMemberIds: 'member-1', allowedAccountIds: [] })).toMatchObject({ field: 'allowedMemberIds' });
    expect(validateFinanceQuery({ kind: 'reconciliation.cash_day', businessDate: '2026-09-14', cashSessionIds: [], declaredTotal: { currency: 'USD', minorUnits: 0, extra: true } })).toMatchObject({ field: 'declaredTotal' });
  });
});
