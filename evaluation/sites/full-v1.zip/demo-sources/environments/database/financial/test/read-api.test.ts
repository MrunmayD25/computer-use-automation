import { describe, expect, it } from 'vitest';
import { DatabaseSync } from 'node:sqlite';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import { createTestDatabasePath } from './conftest.js';

describe('bounded read API', () => {
  it('exposes every seeded domain through institution-bound pages', async () => {
    const target = createTestDatabasePath();
    try {
      using database = openFinancialDatabase({ path: target.path });
      const world = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'reads', scale: 'small' });
      const binding = world.bindings[0];
      expect(binding).toBeDefined();
      if (binding === undefined) throw new Error('Seeded world has no dataset binding.');
      const dataset = database.dataset(binding);

      expect(dataset.members.list({ limit: 10 }).items).toHaveLength(10);
      expect(dataset.accounts.list({ limit: 10 }).items).toHaveLength(10);
      expect(dataset.payments.list({ limit: 10 }).items.length).toBeGreaterThan(0);
      expect(dataset.cards.list({ limit: 10 }).items.length).toBeGreaterThan(0);
      expect(dataset.loans.list({ limit: 10 }).items.length).toBeGreaterThan(0);
      expect(dataset.documents.list({ limit: 10 }).items.length).toBeGreaterThan(0);
      expect(dataset.servicing.listCases({ limit: 10 }).items.length).toBeGreaterThan(0);
      expect(dataset.reconciliation.listBatches({ limit: 10 }).items.length).toBeGreaterThan(0);
      expect(dataset.policy.listActors({ limit: 10 }).items.length).toBeGreaterThan(0);
      using inspection = new DatabaseSync(target.path, { readOnly: true });
      const expected = inspection.prepare('SELECT journal_id,line_number FROM journal_lines WHERE dataset_id=? ORDER BY journal_id,line_number').all(binding.datasetId)
        .map(row => `${String(row.journal_id)}:${String(row.line_number)}`);
      const actual: string[] = [];
      let cursor: string | undefined;
      do {
        const page = dataset.accounting.journalLines({ limit: 17, ...(cursor ? { cursor } : {}) });
        actual.push(...page.items.map(row => `${row.journalId}:${row.lineNumber}`));
        cursor = page.nextCursor ?? undefined;
      } while (cursor);
      expect(actual).toEqual(expected);
    } finally {
      target.cleanup();
    }
  });

  it('returns real parseable PDF bytes and a CSV linked to its account history', async () => {
    const target = createTestDatabasePath();
    try {
      using database = openFinancialDatabase({ path: target.path });
      const world = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'documents', scale: 'small' });
      const binding = world.bindings[0];
      if (binding === undefined) throw new Error('Seeded world has no dataset binding.');
      const dataset = database.dataset(binding);
      let page = dataset.documents.list({ limit: 100 });
      const documents = [...page.items];
      while (page.nextCursor) {
        page = dataset.documents.list({ limit: 100, cursor: page.nextCursor });
        documents.push(...page.items);
      }
      const pdf = documents.find((document) => document.mediaType === 'application/pdf');
      const csv = documents.find((document) => document.documentType === 'statement-csv');
      expect(pdf).toBeDefined();
      expect(csv).toBeDefined();
      if (pdf === undefined || csv === undefined) throw new Error('Expected both PDF and CSV documents.');
      const pdfBytes = dataset.documents.bytes(pdf.versionId);
      expect(new TextDecoder().decode(pdfBytes.subarray(0, 5))).toBe('%PDF-');
      const { PDFDocument } = await import('pdf-lib');
      expect((await PDFDocument.load(pdfBytes)).getPageCount()).toBeGreaterThan(0);
      const csvText = new TextDecoder().decode(dataset.documents.bytes(csv.versionId));
      expect(csvText.startsWith('date,reference,description,amount_minor_units,currency\r\n')).toBe(true);
      using inspection = new DatabaseSync(target.path, { readOnly: true });
      const history = inspection.prepare(`SELECT j.reference FROM document_versions v
        JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
        JOIN ledger_accounts la ON la.dataset_id=d.dataset_id AND la.customer_account_id=d.account_id
        JOIN journal_lines l ON l.dataset_id=la.dataset_id AND l.ledger_account_id=la.id
        JOIN journals j ON j.dataset_id=l.dataset_id AND j.id=l.journal_id
        WHERE v.dataset_id=? AND v.id=? AND substr(j.posted_at,1,10)>=v.period_start
          AND substr(j.posted_at,1,10)<v.period_end`).all(binding.datasetId,csv.versionId);
      expect(history.length).toBeGreaterThan(0);
      expect(csvText.trimEnd().split('\r\n')).toHaveLength(history.length+1);
      for (const row of history) expect(csvText).toContain(`,${String(row.reference)},`);
    } finally {
      target.cleanup();
    }
  });
});
