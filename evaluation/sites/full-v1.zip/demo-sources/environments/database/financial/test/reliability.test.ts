import { DatabaseSync } from 'node:sqlite';
import { expect, it } from 'vitest';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase, validateSeedManifest } from '../src/public.js';
import { createTestDatabasePath } from './conftest.js';
import { withTrustedFixtureTransaction } from '../src/testing.js';

it('validates unknown manifest values and returns a canonical property order', () => {
  for (const institutions of [null,[null,null,null],[{id:'x'},{id:'y'},{id:'z'}]]) {
    expect(() => validateSeedManifest({...DEFAULT_SEED_MANIFEST,institutions})).toThrow(/institution/i);
  }
  expect(() => validateSeedManifest({...DEFAULT_SEED_MANIFEST,unexpected:'secret'})).toThrow(/unexpected/i);
  expect(() => validateSeedManifest({...DEFAULT_SEED_MANIFEST,institutions:DEFAULT_SEED_MANIFEST.institutions.map((institution,index) => index===0 ? {...institution,defaultCurrency:'BTC'} : institution)})).toThrow(/currency/i);
  expect(() => validateSeedManifest({...DEFAULT_SEED_MANIFEST,institutions:DEFAULT_SEED_MANIFEST.institutions.map((institution,index) => index===0 ? {...institution,timeZone:'Not/AZone'} : institution)})).toThrow(/time.zone/i);
  const reversed = Object.fromEntries(Object.entries(DEFAULT_SEED_MANIFEST).reverse());
  expect(JSON.stringify(validateSeedManifest(reversed))).toBe(JSON.stringify(validateSeedManifest(DEFAULT_SEED_MANIFEST)));
});

it('rejects invalid direct seed calls without creating a named world', async () => {
  using database = openFinancialDatabase({path:':memory:'});
  await expect(database.seedWorld({...DEFAULT_SEED_MANIFEST,seed:-1})).rejects.toThrow(/seed/i);
  expect(database.getNamedWorld(DEFAULT_SEED_MANIFEST.name)).toEqual([]);
});

it('rejects concurrent access during async seed and preserves the completed world', async () => {
  const target=createTestDatabasePath();
  try {
    using database=openFinancialDatabase({path:target.path});
    const pending=database.seedWorld({...DEFAULT_SEED_MANIFEST,scale:'small'});
    try {
      expect(() => database.getNamedWorld(DEFAULT_SEED_MANIFEST.name)).toThrow(/seed.*progress/i);
      expect(() => database.close()).toThrow(/seed.*progress/i);
      await expect(database.seedWorld({...DEFAULT_SEED_MANIFEST,scale:'small'})).rejects.toThrow(/seed.*progress/i);
    } finally { await pending; }
    const original=database.getNamedWorld(DEFAULT_SEED_MANIFEST.name)[0];
    if (!original) throw new Error('Expected seeded institution.');
    const mutable={...original};
    const bound=database.dataset(mutable);
    const before=bound.summary();
    const alternate=database.getNamedWorld(DEFAULT_SEED_MANIFEST.name)[1];
    if (!alternate) throw new Error('Expected alternate institution.');
    withTrustedFixtureTransaction({path:target.path,binding:alternate}, inspection => {
      inspection.prepare('INSERT INTO parties VALUES (?,?,?,?,?)').run(alternate.datasetId,'extra-party','person','Extra Member','2026-09-14T15:00:00.000Z');
      inspection.prepare('INSERT INTO people VALUES (?,?,?,?,?,?,?,?)').run(alternate.datasetId,'extra-party','Extra','Member',null,null,'1980-01-01',null);
      inspection.prepare('INSERT INTO members VALUES (?,?,?,?,?,?,?,?)').run(alternate.datasetId,'extra-member','extra-party','EXTRA-001','active','2026-09-14T15:00:00.000Z','individual',1);
    });
    expect(database.dataset(alternate).summary().members).toBe(before.members+1);
    mutable.datasetId=alternate.datasetId;
    mutable.institutionId=alternate.institutionId;
    expect(bound.summary()).toEqual(before);
    const clone=database.cloneDataset(original,'reliability-copy');
    expect(database.dataset(clone).summary()).toEqual(before);
    using inspection=new DatabaseSync(target.path,{readOnly:true});
    expect(inspection.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
  } finally {target.cleanup();}
},120000);
