import { DatabaseSync } from 'node:sqlite';
import { Worker } from 'node:worker_threads';
import { afterEach, expect, it } from 'vitest';
import { seedCore } from '../src/seed/core.js';
import { executeCommand } from '../src/services/commands.js';
import { queryCore } from '../src/services/core-queries.js';
import { openFinancialStore, type FinancialStore } from '../src/services/store.js';
import type { CommandOutcome, ServiceCommand, ServiceContext } from '../src/services/types.js';
import { createCoreSeedFixture, createTestDatabasePath } from './conftest.js';

const cleanups: (() => void)[] = [];
afterEach(() => { for (const cleanup of cleanups.reverse()) cleanup(); cleanups.length = 0; });
function fixture(): { path: string; store: FinancialStore; context: ServiceContext; command: ServiceCommand } {
  const location = createTestDatabasePath(); cleanups.push(() => location.cleanup());
  const seed = createCoreSeedFixture(location.path);
  let memberId: string;
  try {
    seed.database.exec('BEGIN');
    seedCore(seed);
    seed.database.exec('COMMIT');
    const member = seed.database.prepare('SELECT id FROM members WHERE dataset_id=? ORDER BY id LIMIT 1').get(seed.binding.datasetId);
    if (typeof member?.id !== 'string') throw new Error('Missing seeded member.');
    memberId = member.id;
  } finally { seed.database.close(); }
  const store = openFinancialStore({ path: location.path, busyTimeoutMs: 20 }); cleanups.push(() => store.close());
  return { path: location.path, store, context: { binding: seed.binding, actorId: 'actor-2', reference: 'single-command-contention' },
    command: { kind: 'member.note.add', memberId, visibility: 'general', text: 'Exactly one concurrent note' } };
}
function fullRows(store: FinancialStore): unknown {
  return store.read(database => database.prepare("SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name").all().map(table => {
    if (typeof table.name !== 'string') throw new Error('Invalid table name.');
    return [table.name, database.prepare(`SELECT * FROM "${table.name.replaceAll('"', '""')}" ORDER BY rowid`).all()];
  }));
}
function effectCounts(store: FinancialStore): number[] {
  return store.read(database => ['member_notes', 'operations', 'operation_receipts', 'business_events'].map(table => {
    const row = database.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get();
    if (typeof row?.n !== 'number') throw new Error(`Missing ${table} count.`);
    return row.n;
  }));
}
it('A023 refuses one bounded contended write without consuming any row and safely retries its original token', () => {
  const { path, store, context, command } = fixture();
  const before = fullRows(store); const counts = effectCounts(store);
  const peer = new DatabaseSync(path); cleanups.push(() => peer.close());
  peer.exec('BEGIN IMMEDIATE');
  try { expect(() => executeCommand(store, context, command, 'single-command-lock-0001')).toThrow(/busy|locked/iu); }
  finally { peer.exec('ROLLBACK'); }
  expect(fullRows(store)).toEqual(before);
  expect(queryCore(store, context, { kind: 'operation.inspect', idempotencyKey: 'single-command-lock-0001' })).toMatchObject({ kind: 'rejected', code: 'not_found' });
  const result = executeCommand(store, context, command, 'single-command-lock-0001');
  expect(result.kind).toBe('committed');
  const duplicate = executeCommand(store, context, command, 'single-command-lock-0001');
  expect(duplicate.kind).toBe('duplicate');
  if (result.kind !== 'committed' || duplicate.kind !== 'duplicate') throw new Error('Retry did not recover the sole commit.');
  if (result.receipt.result === null) throw new Error('Committed note is missing its durable result.');
  expect(duplicate.receipt).toEqual(result.receipt);
  expect(effectCounts(store)).toEqual(counts.map((count, index) => count + (index === 3 ? 2 : 1)));
  expect(store.read(database => database.prepare('SELECT resource_kind,resource_id FROM business_events WHERE operation_id=? ORDER BY resource_kind').all(result.receipt.operationId)))
    .toEqual([{ resource_kind: 'member', resource_id: result.receipt.result.memberId }, { resource_kind: 'member-note', resource_id: result.receipt.result.noteId }]);
});

it('T211/A024 two simultaneous connections converge on one exact command receipt and effect', async () => {
  const { path, store, context, command } = fixture(); const counts = effectCounts(store);
  const barrier = new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT);
  const source = `
    const { parentPort, workerData } = require('node:worker_threads');
    (async () => {
      const { openFinancialStore, executeCommand } = await import(workerData.servicesUrl);
      const store = openFinancialStore({ path: workerData.path, busyTimeoutMs: 1000 });
      try {
        parentPort.postMessage({ kind: 'ready' });
        if (Atomics.wait(new Int32Array(workerData.barrier), 0, 0, 5000) === 'timed-out') throw new Error('Start barrier expired');
        parentPort.postMessage({ kind: 'result', outcome: executeCommand(store, workerData.context, workerData.command, 'single-command-concurrent-0001') });
      } finally { store.close(); }
    })().catch(error => parentPort.postMessage({ kind: 'error', message: error.stack }));
  `;
  const launch = (): { worker: Worker; ready: Promise<void>; result: Promise<CommandOutcome>; timer: ReturnType<typeof setTimeout> } => {
    const worker = new Worker(source, { eval: true, workerData: { path, context, command, barrier, servicesUrl: new URL('../dist/services.js', import.meta.url).href } });
    let readyResolve: (() => void) | undefined;
    let readyReject: ((error: Error) => void) | undefined;
    let resultResolve: ((outcome: CommandOutcome) => void) | undefined;
    let resultReject: ((error: Error) => void) | undefined;
    const ready = new Promise<void>((resolve, reject) => { readyResolve = resolve; readyReject = reject; });
    const result = new Promise<CommandOutcome>((resolve, reject) => { resultResolve = resolve; resultReject = reject; });
    const fail = (error: Error): void => { readyReject?.(error); resultReject?.(error); };
    const timer = setTimeout(() => fail(new Error('Concurrent command worker exceeded 10 seconds.')), 10_000);
    worker.on('message', (message: { kind: string; outcome?: CommandOutcome; message?: string }) => {
      if (message.kind === 'ready') readyResolve?.();
      else if (message.kind === 'result' && message.outcome) resultResolve?.(message.outcome);
      else if (message.kind === 'error') fail(new Error(message.message));
    });
    worker.on('error', fail);
    worker.on('exit', code => { if (code !== 0) fail(new Error(`Concurrent command worker exited ${code}.`)); });
    // Attach rejection handlers before waiting for both workers to reach the start barrier.
    void Promise.allSettled([result]);
    return { worker, ready, result, timer };
  };
  const workers = [launch(), launch()];
  try {
    await Promise.all(workers.map(worker => worker.ready));
    Atomics.store(new Int32Array(barrier), 0, 1); Atomics.notify(new Int32Array(barrier), 0, 2);
    const outcomes = await Promise.all(workers.map(worker => worker.result));
    expect(outcomes.map(outcome => outcome.kind).sort()).toEqual(['committed', 'duplicate']);
    const receipts = outcomes.map(outcome => {
      if (outcome.kind !== 'committed' && outcome.kind !== 'duplicate') throw new Error('Concurrent delivery failed.');
      return outcome.receipt;
    });
    expect(receipts[0]).toEqual(receipts[1]);
    expect(effectCounts(store)).toEqual(counts.map((count, index) => count + (index === 3 ? 2 : 1)));
  } finally {
    for (const worker of workers) clearTimeout(worker.timer);
    await Promise.all(workers.map(worker => worker.worker.terminate()));
  }
}, 15_000);
