import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding, InstitutionId } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import {
  accountDetail, accountTransactions, caseDetail, executeCommand, memberDetail, openFinancialStore, receiptByIdempotencyKey, recordStamps, reviewCommand, statementData,
  verificationRunStore, type CommandOutcome, type FinancialStore, type Receipt, type ServiceContext, type TransactionSearch,
} from '../src/services.js';
import { withTrustedFixtureTransaction } from '../src/testing.js';
import { findAuditViolations } from '../src/verification/independent-audit.js';
import { createRun } from '../src/verification/run.js';

let directory: string;
let path: string;
let worldBindings: readonly DatasetBinding[];
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'financial-services-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  const result = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'services-test', scale: 'small' });
  worldBindings = result.bindings;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function clone(institution = 'northstar'): DatasetBinding {
  const source = worldBindings.find((binding) => binding.institutionId === institution);
  if (source === undefined) throw new Error(`Missing ${institution} binding.`);
  using database = openFinancialDatabase({ path });
  return database.cloneDataset(source);
}

function context(binding: DatasetBinding, actorOrdinal = 2): ServiceContext {
  return { binding, actorId: `${binding.institutionId}-actor-${actorOrdinal}`, reference: 'services-test' };
}

function sql<T = Record<string, unknown>>(query: string, ...parameters: (string | number | null)[]): T[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return database.prepare(query).all(...parameters) as T[];
}

function count(table: string, datasetId: string): number {
  return sql<{ count: number }>(`SELECT COUNT(*) AS count FROM ${table} WHERE dataset_id=?`, datasetId)[0]?.count ?? -1;
}

/** An open USD account with a positive balance, no holds or restrictions, whose member owns another such account. */
function eligiblePair(binding: DatasetBinding): { source: { id: string; version: number; posted: number }; destination: { id: string; version: number; posted: number } } {
  const rows = sql<{ id: string; member_id: string; version: number; posted: number }>(`SELECT a.id,a.member_id,a.version,b.posted_balance_minor_units AS posted FROM accounts a
    JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
    WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' AND b.posted_balance_minor_units>50000 AND b.available_balance_minor_units=b.posted_balance_minor_units
      AND NOT EXISTS (SELECT 1 FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active')
    ORDER BY a.member_id,a.account_number`, binding.datasetId);
  for (const [index, row] of rows.entries()) {
    const next = rows[index + 1];
    if (next !== undefined && next.member_id === row.member_id) return { source: row, destination: next };
  }
  throw new Error('No eligible same-member account pair.');
}

function committed(outcome: CommandOutcome): Receipt {
  if (outcome.kind !== 'committed') throw new Error(`Expected a commit, received ${JSON.stringify(outcome)}`);
  return outcome.receipt;
}

function posted(binding: DatasetBinding, accountId: string): number {
  return store.read((database) => accountDetail(database, binding.datasetId, accountId)?.account.postedMinorUnits ?? Number.NaN);
}

describe('shared financial services', () => {
  it('posts one exact balanced cash deposit, returns the stored receipt on retry and rejects a reused key for another command', () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const command = { kind: 'cash.deposit' as const, accountId: source.id, expectedVersion: source.version, amount: { minorUnits: 12_345, currency: 'USD' }, description: 'Branch cash deposit' };
    const receipt = committed(executeCommand(store, context(binding), command, 'deposit-key-0001'));
    expect(posted(binding, source.id)).toBe(source.posted + 12_345);
    expect(receipt.operationKind).toBe('cash.deposit');
    expect(receipt.receiptNumber).toMatch(/^RCP\d{8}$/u);
    expect(receipt.journals).toHaveLength(1);
    expect(receipt.journals[0]?.lines.map((line) => [line.debitMinorUnits, line.creditMinorUnits, line.accountId])).toEqual([[12_345, 0, null], [0, 12_345, source.id]]);
    expect(receipt.affected.map((record) => record.kind)).toEqual(['journal', 'account']);

    const operations = count('operations', binding.datasetId);
    const retry = executeCommand(store, context(binding), command, 'deposit-key-0001');
    expect(retry).toEqual({ kind: 'duplicate', receipt });
    // The account version is now newer, but the stale binding is review metadata rather than intent.
    const refreshedRetry = executeCommand(store, context(binding), { ...command, expectedVersion: source.version + 1 }, 'deposit-key-0001');
    expect(refreshedRetry).toEqual({ kind: 'duplicate', receipt });
    expect(count('operations', binding.datasetId)).toBe(operations);
    expect(posted(binding, source.id)).toBe(source.posted + 12_345);

    const conflict = executeCommand(store, context(binding), { ...command, amount: { minorUnits: 99, currency: 'USD' } }, 'deposit-key-0001');
    expect(conflict).toMatchObject({ kind: 'rejected', code: 'idempotency_conflict' });
  });

  it('rejects withdrawals beyond availability, currency mismatches and same-account transfers without writing rows', () => {
    const binding = clone();
    const { source, destination } = eligiblePair(binding);
    const before = [count('operations', binding.datasetId), count('journals', binding.datasetId), count('business_events', binding.datasetId)];
    expect(executeCommand(store, context(binding), { kind: 'cash.withdraw', accountId: source.id, expectedVersion: source.version, amount: { minorUnits: source.posted + 1, currency: 'USD' }, description: 'Too much' }, 'withdraw-key-0001'))
      .toMatchObject({ kind: 'rejected', code: 'insufficient_funds', field: 'amount' });
    expect(executeCommand(store, context(binding), { kind: 'cash.deposit', accountId: source.id, expectedVersion: source.version, amount: { minorUnits: 100, currency: 'EUR' }, description: 'Wrong currency' }, 'deposit-key-0002'))
      .toMatchObject({ kind: 'rejected', code: 'currency_mismatch' });
    expect(executeCommand(store, context(binding, 3), { kind: 'transfer.internal', sourceAccountId: source.id, destinationAccountId: source.id, expectedSourceVersion: source.version, expectedDestinationVersion: source.version, amount: { minorUnits: 100, currency: 'USD' }, description: 'Loop' }, 'transfer-key-0001'))
      .toMatchObject({ kind: 'rejected', code: 'same_account' });
    expect(executeCommand(store, context(binding), { kind: 'cash.deposit', accountId: destination.id, expectedVersion: destination.version, amount: { minorUnits: 1.5, currency: 'USD' }, description: 'Fraction' }, 'deposit-key-0003'))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'amount' });
    expect([count('operations', binding.datasetId), count('journals', binding.datasetId), count('business_events', binding.datasetId)]).toEqual(before);
  });

  it('transfers between one member\'s accounts only for an operator with the transfer grant', () => {
    const binding = clone();
    const { source, destination } = eligiblePair(binding);
    const command = { kind: 'transfer.internal' as const, sourceAccountId: source.id, destinationAccountId: destination.id, expectedSourceVersion: source.version, expectedDestinationVersion: destination.version, amount: { minorUnits: 2_500, currency: 'USD' }, description: 'Move to reserve' };
    expect(executeCommand(store, context(binding, 2), command, 'transfer-key-0002')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const review = reviewCommand(store, context(binding, 3), command);
    expect(review).toMatchObject({ kind: 'reviewable', review: { accounts: [{ id: source.id, postedAfterMinorUnits: source.posted - 2_500 }, { id: destination.id, postedAfterMinorUnits: destination.posted + 2_500 }] } });
    expect(posted(binding, source.id)).toBe(source.posted);
    committed(executeCommand(store, context(binding, 3), command, 'transfer-key-0003'));
    expect([posted(binding, source.id), posted(binding, destination.id)]).toEqual([source.posted - 2_500, destination.posted + 2_500]);
    const other = sql<{ id: string; version: number }>("SELECT a.id,a.version FROM accounts a WHERE a.dataset_id=? AND a.member_id<>(SELECT member_id FROM accounts WHERE dataset_id=? AND id=?) AND a.status='open' AND a.currency='USD' LIMIT 1", binding.datasetId, binding.datasetId, source.id)[0];
    if (other === undefined) throw new Error('No account owned by another member.');
    expect(executeCommand(store, context(binding, 3), { ...command, expectedSourceVersion: source.version + 1, destinationAccountId: other.id, expectedDestinationVersion: other.version }, 'transfer-key-0004')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
  });

  it('detects stale edits and reviews after a posting while unrelated account changes remain independent', () => {
    const binding = clone();
    const { source, destination } = eligiblePair(binding);
    committed(executeCommand(store, context(binding), { kind: 'account.nickname.update', accountId: destination.id, expectedVersion: destination.version, nickname: 'Other editor' }, 'nickname-key-0001'));
    committed(executeCommand(store, context(binding), { kind: 'cash.deposit', accountId: source.id, expectedVersion: source.version, amount: { minorUnits: 500, currency: 'USD' }, description: 'Concurrent deposit' }, 'deposit-key-0004'));
    committed(executeCommand(store, context(binding), { kind: 'account.nickname.update', accountId: source.id, expectedVersion: source.version + 1, nickname: 'Emergency fund' }, 'nickname-key-0002'));
    const stale = executeCommand(store, context(binding), { kind: 'account.statement_delivery.update', accountId: source.id, expectedVersion: source.version, statementDelivery: 'paper' }, 'delivery-key-0001');
    expect(stale).toMatchObject({ kind: 'rejected', code: 'stale_version', currentVersion: source.version + 2 });
    const stamps = store.read((database) => recordStamps(database, binding.datasetId, { accounts: [source.id, destination.id] }));
    expect([stamps.accounts[source.id]?.version, stamps.accounts[destination.id]?.version]).toEqual([source.version + 2, destination.version + 1]);
    expect(executeCommand(store, context(binding), { kind: 'account.nickname.update', accountId: source.id, expectedVersion: source.version + 2, nickname: 'Emergency fund' }, 'nickname-key-0003'))
      .toEqual({ kind: 'unchanged', message: 'The account nickname is already Emergency fund.' });
  });

  it('opens a zero-balance account, blocks closure of funded accounts and closes the empty one without postings', () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const member = sql<{ member_id: string; product_id: string }>("SELECT a.member_id,p.id AS product_id FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.code='USD-SAVINGS' WHERE a.dataset_id=? AND a.id=?", binding.datasetId, source.id)[0];
    if (member === undefined) throw new Error('Missing member.');
    const opening = { kind: 'account.open' as const, memberId: member.member_id, productId: member.product_id, nickname: 'Holiday fund', statementDelivery: 'electronic' as const };
    expect(executeCommand(store, context(binding), opening, 'open-electronic-no-consent')).toMatchObject({kind:'rejected',code:'ineligible',field:'statementDelivery'});
    const opened = committed(executeCommand(store, context(binding), { ...opening, statementDelivery: 'paper' }, 'open-key-0001'));
    const account = opened.affected.find((record) => record.kind === 'account');
    if (account === undefined) throw new Error('No account in receipt.');
    expect(account.label).toMatch(/^AC\d{7}$/u);
    expect(store.read((database) => accountDetail(database, binding.datasetId, account.id))).toMatchObject({ account: { status: 'open', postedMinorUnits: 0, nickname: 'Holiday fund', statementDelivery: 'paper', version: 1 }, eligibility: { closure: { eligible: true } } });
    expect(executeCommand(store, context(binding), { kind: 'account.close', accountId: source.id, expectedVersion: source.version, reason: 'Member request' }, 'close-key-0001'))
      .toMatchObject({ kind: 'rejected', code: 'closure_blocked', message: 'Posted balance must be exactly zero.' });
    const lines = count('journal_lines', binding.datasetId);
    committed(executeCommand(store, context(binding), { kind: 'account.close', accountId: account.id, expectedVersion: 1, reason: 'Opened in error' }, 'close-key-0002'));
    expect(count('journal_lines', binding.datasetId)).toBe(lines);
    expect(store.read((database) => accountDetail(database, binding.datasetId, account.id)?.account)).toMatchObject({ status: 'closed', closedAt: '2026-09-14T15:00:00.000Z', version: 2 });
    expect(executeCommand(store, context(binding), { kind: 'cash.deposit', accountId: account.id, expectedVersion: 2, amount: { minorUnits: 100, currency: 'USD' }, description: 'After closure' }, 'deposit-key-0005'))
      .toMatchObject({ kind: 'rejected', code: 'ineligible', message: 'Account status is closed; money movement requires an open account.' });
  });

  it('creates members, rejects duplicate identities and keeps contact history with a version bump', () => {
    const binding = clone();
    const created = committed(executeCommand(store, context(binding), { kind: 'member.create', legalGiven: 'Priya', legalFamily: 'Raman', preferredName: null, birthDate: '1988-02-29', email: 'priya.raman@example.test', phone: '312-555-0199', address: { line1: '12 Lake St', line2: null, city: 'Chicago', region: 'IL', postalCode: '60601', country: 'US' } }, 'member-key-0001'));
    const memberId = created.affected[0]?.id ?? '';
    expect(created.affected[0]?.label).toMatch(/^NM\d{6}$/u);
    expect(executeCommand(store, context(binding), { kind: 'member.create', legalGiven: 'priya', legalFamily: 'RAMAN', preferredName: null, birthDate: '1988-02-29', email: null, phone: null, address: null }, 'member-key-0002'))
      .toMatchObject({ kind: 'rejected', code: 'duplicate_identity' });
    committed(executeCommand(store, context(binding), { kind: 'contact.update', memberId, expectedVersion: 1, email: 'p.raman@example.test', phone: null }, 'contact-key-0001'));
    const detail = store.read((database) => memberDetail(database, binding.datasetId, memberId));
    expect(detail).toMatchObject({ member: { version: 2, email: 'p.raman@example.test', phone: null }, email: { value: 'p.raman@example.test' }, phone: null, address: { city: 'Chicago', evidenceStatus: 'unverified' } });
    expect(sql<{ value: string; ended: number }>('SELECT value,valid_to IS NOT NULL AS ended FROM contact_points WHERE dataset_id=? AND party_id=(SELECT party_id FROM members WHERE dataset_id=? AND id=?) ORDER BY kind,rowid', binding.datasetId, binding.datasetId, memberId))
      .toEqual([{ value: 'priya.raman@example.test', ended: 1 }, { value: 'p.raman@example.test', ended: 0 }, { value: '312-555-0199', ended: 1 }]);
    expect(executeCommand(store, context(binding), { kind: 'contact.update', memberId, expectedVersion: 1, email: 'late@example.test' }, 'contact-key-0002')).toMatchObject({ kind: 'rejected', code: 'stale_version', currentVersion: 2 });
    committed(executeCommand(store, context(binding), { kind: 'member.note.add', memberId, visibility: 'restricted', text: 'Verified identity in branch.' }, 'note-key-0001'));
    const servicer = { institutionId: binding.institutionId, actorId: `${binding.institutionId}-actor-2` };
    expect(store.read((database) => memberDetail(database, binding.datasetId, memberId, servicer)?.notes.map((note) => [note.visibility, note.text, note.actor?.actorNumber]))).toEqual([['restricted', 'Verified identity in branch.', 'OP0002']]);
  });

  it('keeps duplicate business numbers isolated by institution binding', () => {
    const northstar = clone('northstar');
    const riverton = clone('riverton');
    const number = 'NM000002';
    const find = (binding: DatasetBinding): { id: string; version: number } => {
      const row = sql<{ id: string; version: number }>('SELECT id,version FROM members WHERE dataset_id=? AND member_number=?', binding.datasetId, number)[0];
      if (row === undefined) throw new Error(`Missing ${number}.`);
      return row;
    };
    const north = find(northstar);
    const river = find(riverton);
    committed(executeCommand(store, context(northstar), { kind: 'contact.update', memberId: north.id, expectedVersion: north.version, email: 'northstar.only@example.test' }, 'contact-key-0003'));
    expect(store.read((database) => memberDetail(database, northstar.datasetId, north.id)?.email?.value)).toBe('northstar.only@example.test');
    expect(store.read((database) => memberDetail(database, riverton.datasetId, river.id)?.member.version)).toBe(river.version);
    expect(executeCommand(store, context(riverton), { kind: 'contact.update', memberId: north.id, expectedVersion: north.version + 1, email: 'cross@example.test' }, 'contact-key-0004'))
      .toMatchObject({ kind: 'rejected', code: 'not_found' });
  });

  it('runs the servicing case lifecycle with valid transitions, dependency checks and audit-consistent history', () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const memberId = sql<{ member_id: string }>('SELECT member_id FROM accounts WHERE dataset_id=? AND id=?', binding.datasetId, source.id)[0]?.member_id ?? '';
    const queues = sql<{ id: string; code: string }>('SELECT id,code FROM queues WHERE dataset_id=? ORDER BY code', binding.datasetId);
    const general = queues.find((queue) => queue.code === 'GENERAL')?.id ?? '';
    const restricted = queues.find((queue) => queue.code === 'RESTRICTED')?.id ?? '';
    const opened = committed(executeCommand(store, context(binding), { kind: 'case.open', memberId, accountId: source.id, queueId: general, assignedActorId: null, category: 'statement-copy', priority: 'normal', summary: 'Copy of August statement', dueDate: '2026-09-18' }, 'case-key-0001'));
    const caseId = opened.affected[0]?.id ?? '';
    expect(executeCommand(store, context(binding), { kind: 'case.open', memberId, accountId: source.id, queueId: general, assignedActorId: null, category: 'statement-copy', priority: 'high', summary: 'Again', dueDate: '2026-09-18' }, 'case-key-0002'))
      .toMatchObject({ kind: 'rejected', code: 'duplicate_open_case' });
    committed(executeCommand(store, context(binding), { kind: 'case.assign', caseId, expectedVersion: 1, queueId: restricted, assignedActorId: `${binding.institutionId}-actor-7`, reason: 'Restricted evidence' }, 'case-key-0003'));
    expect(executeCommand(store, context(binding), { kind: 'case.assign', caseId, expectedVersion: 2, queueId: restricted, assignedActorId: `${binding.institutionId}-actor-1`, reason: 'Viewer' }, 'case-key-0004'))
      .toMatchObject({ kind: 'rejected', code: 'validation', field: 'assignedActorId' });
    expect(executeCommand(store, context(binding), { kind: 'case.transition', caseId, expectedVersion: 2, toState: 'closed', reason: 'Skip' }, 'case-key-0005')).toMatchObject({ kind: 'rejected', code: 'invalid_transition' });
    committed(executeCommand(store, context(binding), { kind: 'case.transition', caseId, expectedVersion: 2, toState: 'pending-customer', reason: 'Awaiting ID' }, 'case-key-0006'));
    committed(executeCommand(store, context(binding), { kind: 'case.note.add', caseId, visibility: 'general', text: 'Customer called back.' }, 'case-key-0007'));
    committed(executeCommand(store, context(binding), { kind: 'case.transition', caseId, expectedVersion: 3, toState: 'resolved', reason: 'Statement mailed' }, 'case-key-0008'));
    expect(executeCommand(store, context(binding), { kind: 'case.transition', caseId, expectedVersion: 4, toState: 'closed', reason: 'Confirmed receipt' }, 'case-key-0009'))
      .toMatchObject({ kind: 'rejected', code: 'invalid_transition' });
    const detail = store.read((database) => caseDetail(database, binding.datasetId, caseId));
    expect(detail?.events.map((event) => event.state)).toEqual(['open', 'open', 'pending-customer', 'resolved']);
    expect(detail?.case).toMatchObject({ state: 'resolved', queueCode: 'RESTRICTED', version: 4, dueAt: '2026-09-18T22:00:00.000Z' });
    expect(detail?.notes.map((note) => note.text)).toEqual(['Customer called back.']);
    expect(detail?.sla.map((interval) => [interval.state, interval.endsAt !== null])).toEqual([['running', true], ['completed', true]]);
    const blocked = sql<{ id: string; version: number }>("SELECT c.id,c.version FROM cases c JOIN case_dependencies d ON d.dataset_id=c.dataset_id AND d.case_id=c.id WHERE c.dataset_id=? AND c.state='resolved' AND d.state='open' LIMIT 1", binding.datasetId)[0];
    if (blocked !== undefined) expect(executeCommand(store, context(binding), { kind: 'case.transition', caseId: blocked.id, expectedVersion: blocked.version, toState: 'closed', reason: 'Close' }, 'case-key-0010')).toMatchObject({ kind: 'rejected', code: 'invalid_transition' });
    using database = new DatabaseSync(path, { readOnly: true });
    expect(findAuditViolations(database).filter((failure) => failure.name !== 'positive and negative state witnesses')).toEqual([]);
  });

  it('enforces operator status and grants', () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const deposit = { kind: 'cash.deposit' as const, accountId: source.id, expectedVersion: source.version, amount: { minorUnits: 100, currency: 'USD' }, description: 'Deposit' };
    expect(executeCommand(store, context(binding, 1), deposit, 'grant-key-0001')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    expect(executeCommand(store, context(binding, 8), deposit, 'grant-key-0002')).toMatchObject({ kind: 'rejected', code: 'actor_inactive' });
    expect(executeCommand(store, { ...context(binding), binding: { ...binding, institutionId: 'riverton' as InstitutionId } }, deposit, 'grant-key-0003')).toMatchObject({ kind: 'rejected' });
  });

  it('produces statement data that reconciles opening, activity and closing balances', () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const statement = store.read((database) => statementData(database, binding.datasetId, source.id, '2026-08'));
    if (statement === undefined) throw new Error('Missing statement.');
    const net = statement.entries.reduce((total, entry) => total + entry.amountMinorUnits, 0);
    expect(statement.closingMinorUnits).toBe(statement.openingMinorUnits + net);
    const history = store.read((database) => accountTransactions(database, binding.datasetId, source.id, { limit: 200, offset: 0, startDate: '2026-08-01', endDate: '2026-09-01', order: 'oldest' }));
    expect(history.items.map((row) => row.reference)).toEqual(statement.entries.map((entry) => entry.reference));
    expect(history.items.at(-1)?.runningBalanceMinorUnits).toBe(statement.closingMinorUnits);
  });

  it('filters transaction history by journal status', () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const all = store.read((database) => accountTransactions(database, binding.datasetId, source.id, { limit: 200, offset: 0 }));
    const target = all.items[0];
    if (target === undefined) throw new Error('The account has no history.');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare("UPDATE journals SET status='reversed' WHERE dataset_id=? AND id=?").run(binding.datasetId, target.journalId);
    });
    const search = (status: 'posted' | 'reversed') => store.read((database) => accountTransactions(database, binding.datasetId, source.id, { limit: 200, offset: 0, status }));
    expect(search('reversed').items.map((row) => [row.journalId, row.status])).toEqual([[target.journalId, 'reversed']]);
    expect(search('posted').total).toBe(all.total - 1);
    expect(search('posted').items.every((row) => row.status === 'posted')).toBe(true);
    const invalid: TransactionSearch = { limit: 10, offset: 0 };
    Reflect.set(invalid, 'status', 'pending');
    expect(() => store.read((database) => accountTransactions(database, binding.datasetId, source.id, invalid))).toThrow(RangeError);
  });

  it('finds entries by exact reference and settles an attempt by its idempotency key', () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const deposit = { kind: 'cash.deposit', accountId: source.id, expectedVersion: source.version, amount: { minorUnits: 4321, currency: 'USD' }, description: 'Reference search deposit' } as const;
    const receipt = committed(executeCommand(store, context(binding), deposit, 'reference-key-0001'));
    const byReference = (reference: string) => store.read((database) => accountTransactions(database, binding.datasetId, source.id, { limit: 200, offset: 0, reference }));
    expect(byReference(receipt.businessReference.toLowerCase()).items.map((row) => [row.reference, row.amountMinorUnits, row.receiptNumber])).toEqual([[receipt.businessReference, 4321, receipt.receiptNumber]]);
    expect(byReference(receipt.businessReference.slice(0, -1)).total).toBe(0);
    expect(store.read((database) => receiptByIdempotencyKey(database, binding.datasetId, 'reference-key-0001'))).toEqual(receipt);
    expect(store.read((database) => receiptByIdempotencyKey(database, binding.datasetId, 'reference-key-0002'))).toBeUndefined();
  });

  it('routes writes through an evaluator-owned run and captures only committed transactions', async () => {
    const binding = clone();
    const { source } = eligiblePair(binding);
    const run = await createRun({ root: join(directory, 'runs'), sourcePath: path, bindings: [binding], contractDigest: 'services-test' });
    run.begin();
    const runStore = verificationRunStore(run);
    const actor = `${binding.institutionId}-actor-2`;
    const runContext: ServiceContext = { binding, actorId: actor, principalKind: 'automation', reference: 'run-write' };
    expect(executeCommand(runStore, runContext, { kind: 'cash.withdraw', accountId: source.id, expectedVersion: source.version, amount: { minorUnits: source.posted + 1, currency: 'USD' }, description: 'Too much' }, 'run-key-0001'))
      .toMatchObject({ kind: 'rejected', code: 'insufficient_funds' });
    committed(executeCommand(runStore, runContext, { kind: 'cash.deposit', accountId: source.id, expectedVersion: source.version, amount: { minorUnits: 700, currency: 'USD' }, description: 'Run deposit' }, 'run-key-0002'));
    runStore.close();
    const evidence = run.finish();
    expect(evidence.captureComplete).toBe(true);
    expect(evidence.transactions).toHaveLength(1);
    expect(evidence.transactions[0]?.context).toEqual({ kind: 'automation', actorId: actor, reference: 'run-write' });
    expect(evidence.transactions[0]?.changes.map((change) => `${change.operation}:${change.table}`)).toEqual([
      'insert:operations', 'insert:operation_receipts', 'insert:journals', 'insert:journal_lines', 'insert:journal_lines', 'update:accounts', 'insert:business_events', 'insert:business_events',
    ]);
  });
});
