import { DatabaseSync } from 'node:sqlite';
import { expect, it } from 'vitest';
import { createSchema } from '../src/schema.js';
import { seedCore } from '../src/seed/core.js';
import { accountDetail } from '../src/services/queries.js';
import { createSeedRandom } from '../src/seed/random.js';
import type { DatasetId, InstitutionId } from '../src/model.js';

it('builds connected, chronological portfolios with rare states and attributable money history', () => {
  using database = new DatabaseSync(':memory:');
  createSchema(database);
  const institution = { id: 'northstar', legalName: 'Northstar Cooperative', displayName: 'Northstar', timeZone: 'America/Chicago', defaultCurrency: 'USD' as const };
  const binding = { institutionId: 'northstar' as InstitutionId, datasetId: 'core-test' as DatasetId };
  database.prepare('INSERT INTO institutions VALUES (?,?,?,?,?,?)').run('northstar',institution.legalName,institution.displayName,'US',institution.timeZone,'USD');
  database.prepare('INSERT INTO datasets VALUES (?,?,?,?,?,?,?,?,?)').run(binding.datasetId,binding.institutionId,'core',42,'small','2026-09-14T15:00:00.000Z','1',1,0);
  seedCore({database,binding,institution,scale:'small',profile:{membersPerInstitution:48,organizationsPerInstitution:4,historyMonths:18,ordinaryJournalTransactionsPerAccount:20},seed:42,asOf:'2026-09-14T15:00:00.000Z',random:createSeedRandom(42),id:(kind,ordinal)=>`${kind}-${ordinal}`,businessNumber:(prefix,ordinal,width=6)=>`${prefix}-${String(ordinal).padStart(width,'0')}`});
  const count = (sql: string): number => Number(database.prepare(`SELECT count(*) AS n FROM (${sql})`).get()?.n);
  expect(count("SELECT member_id FROM accounts WHERE status='open' GROUP BY member_id,currency HAVING count(*)>=2")).toBeGreaterThan(10);
  expect(count('SELECT member_id FROM accounts GROUP BY member_id HAVING count(*)>25')).toBeGreaterThan(0);
  expect(count('SELECT la.customer_account_id FROM ledger_accounts la JOIN journal_lines l ON l.ledger_account_id=la.id GROUP BY la.customer_account_id HAVING count(*)>1000')).toBeGreaterThan(0);
  expect(count('SELECT account_id FROM account_balances WHERE posted_balance_minor_units=1')).toBeGreaterThan(0);
  expect(count('SELECT a.id FROM accounts a WHERE NOT EXISTS(SELECT 1 FROM ledger_accounts la JOIN journal_lines l ON l.ledger_account_id=la.id WHERE la.customer_account_id=a.id)')).toBeGreaterThan(0);
  expect(count('SELECT j.id FROM journals j JOIN journal_lines l ON l.journal_id=j.id JOIN ledger_accounts la ON la.id=l.ledger_account_id JOIN accounts a ON a.id=la.customer_account_id WHERE j.posted_at<a.opened_at OR j.posted_at>coalesce(a.closed_at,\'9999\')')).toBe(0);
  expect(count('SELECT j.id FROM journals j LEFT JOIN operations o ON o.id=j.operation_id LEFT JOIN operation_receipts r ON r.operation_id=o.id WHERE o.id IS NULL OR r.id IS NULL')).toBe(0);
  expect(count("SELECT p.id FROM member_merge_plans p JOIN members m ON m.id=p.source_member_id WHERE p.state='applied' AND m.status<>'merged'")).toBe(0);
  expect(count("SELECT a.id FROM accounts a JOIN members m ON m.id=a.member_id WHERE m.status='merged'")).toBe(0);
  expect(count('SELECT journal_id FROM journal_lines GROUP BY journal_id HAVING sum(debit_minor_units)<>sum(credit_minor_units)')).toBe(0);
  const contracts=database.prepare(`SELECT t.account_id,t.projected_proceeds_minor_units,b.posted_balance_minor_units,t.currency
    FROM deposit_maturity_terms t JOIN account_balances b ON b.dataset_id=t.dataset_id AND b.account_id=t.account_id
    WHERE t.dataset_id=? ORDER BY t.account_id`).all(binding.datasetId);
  expect(contracts.length).toBeGreaterThan(10);
  for(const contract of contracts) {
    if(typeof contract.account_id!=='string' || typeof contract.posted_balance_minor_units!=='number') throw new Error('Invalid seeded deposit contract');
    const expected=contract.posted_balance_minor_units+Math.floor(contract.posted_balance_minor_units*385*50/3_650_000+0.5);
    expect(contract.projected_proceeds_minor_units).toBe(expected);
    const terms=accountDetail(database,binding.datasetId,contract.account_id)?.maturityTerms;
    expect(terms).toHaveLength(1);
    expect(terms?.[0]).toMatchObject({maturityDate:'2026-11-03',cutoffAt:'2026-11-01T15:00:00.000Z',projectedProceedsMinorUnits:expected,currency:contract.currency});
  }
});
