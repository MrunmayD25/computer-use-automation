import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import { accountDetail, executeCommand, listApprovals, memberDetail, openFinancialStore, queryFinance, queryMemberMergePlan, type CommandOutcome, type FinanceCommand, type FinanceRecordKind, type FinancialStore, type Money, type Receipt, type ServiceContext } from '../src/services.js';
import { financeApprovalFingerprint, financeApprovalScope } from '../src/services/finance-support.js';
import { openTrustedReadOnly, withTrustedFixtureTransaction } from '../src/testing.js';
import { findAuditViolations } from '../src/verification/independent-audit.js';

let directory: string;
let path: string;
let source: DatasetBinding;
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'finance-holds-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  const seeded = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'finance-holds-test', scale: 'small' });
  const binding = seeded.bindings.find((candidate) => candidate.institutionId === 'northstar');
  if (binding === undefined) throw new Error('Northstar seed binding is missing.');
  source = binding;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function clone(): DatasetBinding {
  using database = openFinancialDatabase({ path });
  return database.cloneDataset(source);
}

function context(binding: DatasetBinding, actorOrdinal = 2, now?: string): ServiceContext {
  const base = { binding, actorId: `${binding.institutionId}-actor-${actorOrdinal}`, reference: 'finance-holds-test' };
  return now === undefined ? base : { ...base, now };
}

function sql<T = Record<string, unknown>>(query: string, ...parameters: (string | number | null)[]): T[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return database.prepare(query).all(...parameters) as T[];
}

function committed(outcome: CommandOutcome): Receipt {
  if (outcome.kind !== 'committed') throw new Error(`Expected committed outcome, received ${JSON.stringify(outcome)}`);
  return outcome.receipt;
}

function recordFingerprint(binding: DatasetBinding, resource: FinanceRecordKind, id: string, now?: string): string {
  const result = queryFinance(store, context(binding, 2, now), { kind: 'finance.record', resource, id });
  if (result.kind !== 'found') throw new Error(`Expected hold snapshot, received ${JSON.stringify(result)}`);
  return result.snapshot.fingerprint;
}

function bindingAuditFailures(binding: DatasetBinding): ReturnType<typeof findAuditViolations> {
  using database = new DatabaseSync(path, { readOnly: true });
  return findAuditViolations(database).flatMap((failure) => {
    const witnesses = failure.witnesses.filter((witness) => !Object.hasOwn(witness, 'dataset_id') || witness.dataset_id === binding.datasetId);
    return witnesses.length === 0 ? [] : [{ ...failure, witnesses }];
  });
}

function holdFingerprint(binding: DatasetBinding, holdId: string, now?: string): string {
  return recordFingerprint(binding, 'hold', holdId, now);
}

function installApproval(binding: DatasetBinding, command: FinanceCommand, checkerOrdinal: 2 | 3 | 4 | 5, amountLimit: Money | null = null, makerOrdinal = 3): void {
  if (!('approvalId' in command)) throw new Error(`${command.kind} does not name an approval.`);
  const approvalId = command.approvalId;
  const policy = sql<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
  if (policy === undefined) throw new Error('No effective approval policy exists.');
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare(`INSERT INTO business_approvals
      (dataset_id,id,maker_actor_id,checker_actor_id,action_fingerprint,scope_json,amount_limit_minor_units,currency,policy_version_id,status,expires_at)
      VALUES (?,?,?,?,?,?,?,?,?,'approved','2026-09-16T15:00:00.000Z')`).run(
      binding.datasetId, approvalId, `${binding.institutionId}-actor-${makerOrdinal}`, `${binding.institutionId}-actor-${checkerOrdinal}`,
      financeApprovalFingerprint(command), JSON.stringify(financeApprovalScope(command)), amountLimit?.minorUnits ?? null, amountLimit?.currency ?? null, policy.id,
    );
  });
}

function commitApproved(binding: DatasetBinding, command: FinanceCommand, checkerOrdinal: 3 | 4 | 5, idempotencyKey: string, amountLimit: Money | null = null, makerOrdinal = 3): Receipt {
  installApproval(binding, command, checkerOrdinal, amountLimit, makerOrdinal);
  return committed(executeCommand(store, context(binding, checkerOrdinal), command, idempotencyKey));
}

function addRedactedDisputePackage(binding: DatasetBinding, ownerPartyId: string, accountId: string, sourceVersionId: string, suffix: string): string {
  const documentId = `dispute-redacted-${suffix}`;
  const versionId = `${documentId}-v1`;
  const bytes = Buffer.from(`Approved redacted dispute package ${suffix}`, 'utf8');
  const digest = createHash('sha256').update(bytes).digest('hex');
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare("INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'text/plain',?,?)")
      .run(binding.datasetId, digest, bytes.byteLength, bytes);
    database.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
      VALUES (?,?,?,?,?,'Approved redacted dispute package','dispute-life-plus-7y','2026-09-14T14:00:00.000Z')`)
      .run(binding.datasetId, documentId, ownerPartyId, accountId, 'redacted-evidence');
    database.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,1,?,'text/plain','2026-09-14T14:00:00.000Z',NULL,NULL,NULL,'redacted')`)
      .run(binding.datasetId, versionId, documentId, digest);
    database.prepare(`INSERT INTO document_derivations (dataset_id,id,source_version_id,derivative_version_id,purpose,policy_version_id)
      VALUES (?,?,?,?,'redaction',(SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<='2026-09-14T15:00:00.000Z' ORDER BY effective_at DESC,id LIMIT 1))`)
      .run(binding.datasetId, `dispute-redaction-${suffix}`, sourceVersionId, versionId, binding.datasetId);
  });
  return versionId;
}

function addImmutableEvidence(binding: DatasetBinding, input: { versionId: string; ownerPartyId: string; accountId: string | null; status?: 'current' | 'signed' }): string {
  const bytes = Buffer.from(`Immutable evidence ${input.versionId}`, 'utf8');
  const digest = createHash('sha256').update(bytes).digest('hex');
  const documentId = `document-${input.versionId}`;
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare("INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'text/plain',?,?)")
      .run(binding.datasetId, digest, bytes.byteLength, bytes);
    database.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
      VALUES (?,?,?,?,?,'Immutable test evidence','operations-7y','2026-09-14T14:00:00.000Z')`)
      .run(binding.datasetId, documentId, input.ownerPartyId, input.accountId, 'test-evidence');
    database.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,1,?,'text/plain','2026-09-14T14:00:00.000Z',NULL,NULL,NULL,?)`)
      .run(binding.datasetId, input.versionId, documentId, digest, input.status ?? 'current');
  });
  return input.versionId;
}

function addVerifiedIdentityEvidence(binding: DatasetBinding, evidenceId: string, ownerPartyId: string): string {
  const versionId = addImmutableEvidence(binding, { versionId: `${evidenceId}-document-v1`, ownerPartyId, accountId: null, status: 'signed' });
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare(`INSERT INTO identity_evidence (dataset_id,id,party_id,kind,status,issued_at,expires_at,reference)
      VALUES (?,?,?,'correction-authorization','verified','2026-09-14T14:00:00.000Z',NULL,?)`)
      .run(binding.datasetId, evidenceId, ownerPartyId, `document-version:${versionId}`);
  });
  return evidenceId;
}

function addCardShippingDestination(binding: DatasetBinding, input: {
  cardId: string; partyAddressId: string; ownerPartyId: string; accountId: string; suffix: string; previousDestinationId?: string;
}): string {
  const bytes = Buffer.from(`Verified address evidence ${input.suffix}`, 'utf8');
  const digest = createHash('sha256').update(bytes).digest('hex');
  const documentId = `card-address-document-${input.suffix}`;
  const versionId = `${documentId}-v1`;
  const destinationId = `card-shipping-${input.suffix}`;
  const effectiveAt = input.previousDestinationId === undefined ? '2026-09-14T14:00:00.000Z' : '2026-09-14T15:00:00.000Z';
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare("INSERT OR IGNORE INTO document_blobs (dataset_id,digest,media_type,byte_length,bytes) VALUES (?,?,'text/plain',?,?)")
      .run(binding.datasetId, digest, bytes.byteLength, bytes);
    database.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
      VALUES (?,?,?,?,?,'Verified card shipping address','servicing-7y','2026-09-14T14:00:00.000Z')`)
      .run(binding.datasetId, documentId, input.ownerPartyId, input.accountId, 'address-evidence');
    database.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
      VALUES (?,?,?,1,?,'text/plain','2026-09-14T14:00:00.000Z',NULL,NULL,NULL,'current')`)
      .run(binding.datasetId, versionId, documentId, digest);
    database.prepare("UPDATE party_addresses SET evidence_status='verified',evidence_version_id=? WHERE dataset_id=? AND id=?")
      .run(versionId, binding.datasetId, input.partyAddressId);
    if (input.previousDestinationId !== undefined) database.prepare('UPDATE address_destinations SET ends_at=? WHERE dataset_id=? AND id=?')
      .run(effectiveAt, binding.datasetId, input.previousDestinationId);
    database.prepare(`INSERT INTO address_destinations
      (dataset_id,id,context_kind,member_id,account_id,card_id,loan_id,party_address_id,evidence_version_id,consent_id,effective_at,ends_at)
      VALUES (?,?,'card-shipping',NULL,NULL,?,NULL,?,?,NULL,?,NULL)`)
      .run(binding.datasetId, destinationId, input.cardId, input.partyAddressId, versionId, effectiveAt);
  });
  return destinationId;
}

function addContactCampaign(binding: DatasetBinding, suffix: string): { batchId: string; itemIds: [string, string]; memberIds: [string, string] } {
  const members = sql<{ id: string; version: number }>("SELECT id,version FROM members WHERE dataset_id=? AND status='active' ORDER BY id LIMIT 2", binding.datasetId);
  const document = sql<{ id: string; digest: string }>("SELECT id,digest FROM document_versions WHERE dataset_id=? AND status IN ('current','signed') ORDER BY id LIMIT 1", binding.datasetId)[0];
  const first = members[0];
  const second = members[1];
  if (first === undefined || second === undefined || document === undefined) throw new Error('Contact campaign prerequisites are missing.');
  const batchId = `contact-campaign-${suffix}`;
  const itemIds: [string, string] = [`contact-campaign-${suffix}-item-1`, `contact-campaign-${suffix}-item-2`];
  withTrustedFixtureTransaction({ path, binding }, (database) => {
    database.prepare(`INSERT INTO batches (dataset_id,id,batch_number,kind,input_document_version_id,input_digest,state,approved_total_limit_minor_units,currency,created_at)
      VALUES (?,?,?,'contact-update',?,?,'approved',NULL,NULL,'2026-09-14T14:00:00.000Z')`).run(binding.datasetId, batchId, `CONTACT-${suffix}`, document.id, document.digest);
    const insert = database.prepare(`INSERT INTO batch_items (dataset_id,id,batch_id,ordinal,source_key,item_json,state,receipt_id,amount_minor_units,failure_code)
      VALUES (?,?,?,?,?,?,'pending',NULL,NULL,NULL)`);
    insert.run(binding.datasetId, itemIds[0], batchId, 1, first.id, JSON.stringify({ memberId: first.id, expectedVersion: first.version, email: `${suffix}-first@example.invalid` }));
    insert.run(binding.datasetId, itemIds[1], batchId, 2, second.id, JSON.stringify({ memberId: second.id, expectedVersion: second.version, phone: '+13125550199' }));
  });
  return { batchId, itemIds, memberIds: [first.id, second.id] };
}

function approveContactCampaign(binding: DatasetBinding, target: Extract<FinanceCommand, { kind: 'batch.contacts.apply' }>, key: string): string {
  const policy = sql<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
  if (policy === undefined) throw new Error('Contact campaign approval policy is missing.');
  const requested = committed(executeCommand(store, context(binding, 3), {
    kind: 'approval.request', target, checkerActorId: `${binding.institutionId}-actor-5`, policyVersionId: policy.id,
    expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: null,
  }, `${key}-request`));
  const approvalId = requested.affected.find((record) => record.kind === 'approval')?.id;
  if (approvalId === undefined) throw new Error('Contact campaign approval ID is missing.');
  const listed = listApprovals(store, context(binding, 5));
  if (listed.kind !== 'found') throw new Error(`Contact campaign approval list failed: ${JSON.stringify(listed)}`);
  const approval = listed.approvals.find((candidate) => candidate.id === approvalId);
  if (approval === undefined) throw new Error('Contact campaign approval was not listed.');
  committed(executeCommand(store, context(binding, 5), {
    kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Exact immutable contact campaign reviewed',
  }, `${key}-decide`));
  return approvalId;
}

describe('finance hold lifecycle', () => {
  it('places, partially releases and fully releases one hold with stale-edit and retry protection', () => {
    const binding = clone();
    const account = sql<{ id: string; version: number; available: number }>(`SELECT a.id,a.version,b.available_balance_minor_units AS available FROM accounts a
      JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
      WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' AND b.available_balance_minor_units>20000 ORDER BY a.id LIMIT 1`, binding.datasetId)[0];
    if (account === undefined) throw new Error('No holdable account exists.');
    const placement = committed(executeCommand(store, context(binding), {
      kind: 'account.hold.place', accountId: account.id, expectedVersion: account.version, amount: { minorUnits: 9_000, currency: 'USD' },
      reason: 'Pending check review', expiresAt: '2026-09-16T10:00:00-05:00', releaseAuthority: 'case-HOLD-1',
    }, 'hold-place-0001'));
    const affectedHold = placement.affected.find((record) => record.kind === 'hold');
    expect(affectedHold).toBeDefined();
    const holdId = affectedHold?.id ?? '';
    expect(placement.result).toMatchObject({ expiresAt: '2026-09-16T15:00:00.000Z' });
    expect(placement.events.some((event) => event.summary.includes('until 2026-09-16T15:00:00.000Z'))).toBe(true);
    const originalFingerprint = holdFingerprint(binding, holdId);
    const partial = { kind: 'account.hold.release' as const, holdId, expectedFingerprint: originalFingerprint, amountMinorUnits: 4_000, releaseAuthority: 'case-HOLD-1', evidenceReference: 'clearance-partial-1' };
    const partialReceipt = committed(executeCommand(store, context(binding), partial, 'hold-release-0001'));
    expect(partialReceipt.affected).toContainEqual(expect.objectContaining({ kind: 'hold', id: holdId }));
    expect(executeCommand(store, context(binding), partial, 'hold-release-0001')).toEqual({ kind: 'duplicate', receipt: partialReceipt });
    expect(executeCommand(store, context(binding), { ...partial, amountMinorUnits: 1_000 }, 'hold-release-0002')).toMatchObject({ kind: 'rejected', code: 'stale_version' });

    const freshFingerprint = holdFingerprint(binding, holdId);
    committed(executeCommand(store, context(binding), { ...partial, expectedFingerprint: freshFingerprint, amountMinorUnits: 5_000, evidenceReference: 'clearance-full-1' }, 'hold-release-0003'));
    expect(sql('SELECT amount_minor_units,status,released_at FROM holds WHERE dataset_id=? AND id=?', binding.datasetId, holdId)).toEqual([
      expect.objectContaining({ amount_minor_units: 0, status: 'released' }),
    ]);
    expect(sql('SELECT amount_minor_units,evidence_reference FROM hold_releases WHERE dataset_id=? AND hold_id=? ORDER BY amount_minor_units', binding.datasetId, holdId)).toEqual([
      { amount_minor_units: 4_000, evidence_reference: 'clearance-partial-1' },
      { amount_minor_units: 5_000, evidence_reference: 'clearance-full-1' },
    ]);
    expect(executeCommand(store, context(binding), { ...partial, expectedFingerprint: holdFingerprint(binding, holdId), amountMinorUnits: 1 }, 'hold-release-0004')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });

  it('rejects expired and corrupt zero-remaining active holds without recording operations or release history', () => {
    const binding = clone();
    const account = sql<{ id: string; version: number }>(`SELECT a.id,a.version FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
      WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' AND b.available_balance_minor_units>10000 ORDER BY a.id LIMIT 1`, binding.datasetId)[0];
    if (account === undefined) throw new Error('No holdable account exists.');
    const receipt = committed(executeCommand(store, context(binding), {
      kind: 'account.hold.place', accountId: account.id, expectedVersion: account.version, amount: { minorUnits: 1_000, currency: 'USD' },
      reason: 'Short review', expiresAt: '2026-09-14T16:00:00.000Z', releaseAuthority: 'case-HOLD-2',
    }, 'hold-place-0002'));
    const holdId = receipt.affected.find((record) => record.kind === 'hold')?.id ?? '';
    const expiredFingerprint = holdFingerprint(binding, holdId, '2026-09-14T17:00:00.000Z');
    const before = sql<{ operations: number; releases: number }>(`SELECT
      (SELECT COUNT(*) FROM operations WHERE dataset_id=?) AS operations,
      (SELECT COUNT(*) FROM hold_releases WHERE dataset_id=? AND hold_id=?) AS releases`, binding.datasetId, binding.datasetId, holdId)[0];
    expect(executeCommand(store, context(binding, 2, '2026-09-14T17:00:00.000Z'), {
      kind: 'account.hold.release', holdId, expectedFingerprint: expiredFingerprint, amountMinorUnits: 1_000,
      releaseAuthority: 'case-HOLD-2', evidenceReference: 'late-clearance',
    }, 'hold-release-0005')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(sql(`SELECT
      (SELECT COUNT(*) FROM operations WHERE dataset_id=?) AS operations,
      (SELECT COUNT(*) FROM hold_releases WHERE dataset_id=? AND hold_id=?) AS releases`, binding.datasetId, binding.datasetId, holdId)[0]).toEqual(before);

    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare("UPDATE holds SET amount_minor_units=0,expires_at='2026-09-20T15:00:00.000Z' WHERE dataset_id=? AND id=?").run(binding.datasetId, holdId);
    });
    expect(executeCommand(store, context(binding), {
      kind: 'account.hold.release', holdId, expectedFingerprint: holdFingerprint(binding, holdId), amountMinorUnits: 1,
      releaseAuthority: 'case-HOLD-2', evidenceReference: 'corrupt-clearance',
    }, 'hold-release-0006')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
  });
});

describe('composed account closure workflow', () => {
  it('clears each named dependency before transferring the exact balance and closing from a fresh read', () => {
    const binding = clone();
    const candidate = sql<{
      member_id: string; destination_id: string; product_id: string; route_id: string; routing_kind: string; evidence_id: string;
    }>(`SELECT DISTINCT a.member_id,a.id AS destination_id,p.id AS product_id,r.id AS route_id,r.routing_kind,e.id AS evidence_id
      FROM accounts a JOIN account_balances balance ON balance.dataset_id=a.dataset_id AND balance.account_id=a.id
      JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id
      JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      JOIN beneficiaries beneficiary ON beneficiary.dataset_id=m.dataset_id AND beneficiary.owner_party_id=m.party_id AND beneficiary.status='active'
      JOIN beneficiary_routes r ON r.dataset_id=beneficiary.dataset_id AND r.beneficiary_id=beneficiary.id AND r.status='verified'
      JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id AND e.status='verified'
      WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' AND balance.available_balance_minor_units>20000
        AND p.family='deposit' AND p.status='active' AND p.code NOT LIKE '%-TERM'
        AND r.expires_at>'2026-09-14T15:00:00.000Z' AND (e.expires_at IS NULL OR e.expires_at>'2026-09-14T15:00:00.000Z')
        AND NOT EXISTS (SELECT 1 FROM restrictions restriction WHERE restriction.dataset_id=a.dataset_id AND restriction.account_id=a.id
          AND restriction.status='active' AND restriction.kind IN ('debit-block','fraud-review','legal-hold'))
      ORDER BY a.account_number,r.id,e.id LIMIT 1`, binding.datasetId)[0];
    const queue = sql<{ id: string }>("SELECT id FROM queues WHERE dataset_id=? AND visibility='restricted' ORDER BY id LIMIT 1", binding.datasetId)[0];
    if (candidate === undefined || queue === undefined) throw new Error('Account closure workflow prerequisites are missing.');

    const opened = committed(executeCommand(store, context(binding), {
      kind: 'account.open', memberId: candidate.member_id, productId: candidate.product_id, nickname: 'Closure workflow', statementDelivery: 'paper',
    }, 'closure-workflow-open'));
    const accountId = opened.affected.find((record) => record.kind === 'account')?.id;
    if (accountId === undefined) throw new Error('Opened closure account is missing.');
    const detail = () => {
      const current = store.read((database) => accountDetail(database, binding.datasetId, accountId, '2026-09-14T15:00:00.000Z'));
      if (current === undefined) throw new Error('Closure account cannot be reread.');
      return current;
    };
    const destinationDetail = () => {
      const current = store.read((database) => accountDetail(database, binding.datasetId, candidate.destination_id, '2026-09-14T15:00:00.000Z'));
      if (current === undefined) throw new Error('Closure destination cannot be reread.');
      return current;
    };

    committed(executeCommand(store, context(binding, 3), {
      kind: 'transfer.internal', sourceAccountId: candidate.destination_id, destinationAccountId: accountId,
      expectedSourceVersion: destinationDetail().account.version, expectedDestinationVersion: detail().account.version,
      amount: { minorUnits: 10_000, currency: 'USD' }, description: 'Fund account before requested closure',
    }, 'closure-workflow-fund'));

    const payment = committed(executeCommand(store, context(binding, 3), {
      kind: 'payment.create', sourceAccountId: accountId, expectedSourceVersion: detail().account.version,
      beneficiaryRouteId: candidate.route_id, expectedRouteFingerprint: recordFingerprint(binding, 'beneficiary-route', candidate.route_id),
      amount: { minorUnits: 1_000, currency: 'USD' }, rail: candidate.routing_kind, requestedDate: '2026-09-15',
      calendarVersion: 'US-FI-2026.1', cutoffAt: '2026-09-15T21:00:00.000Z',
      reference: 'CLOSURE-WORKFLOW-PAYMENT', targetState: 'pending-approval',
    }, 'closure-workflow-payment'));
    const paymentId = payment.affected.find((record) => record.kind === 'payment')?.id;
    if (paymentId === undefined) throw new Error('Closure workflow payment is missing.');

    const scheduleCommand = {
      kind: 'payment.schedule.create' as const, sourceAccountId: accountId, expectedSourceVersion: detail().account.version,
      beneficiaryRouteId: candidate.route_id, expectedRouteFingerprint: recordFingerprint(binding, 'beneficiary-route', candidate.route_id),
      amount: { minorUnits: 250, currency: 'USD' }, frequency: 'daily' as const, interval: 1,
      startDate: '2026-09-15', endDate: '2026-09-17', approvalId: 'approval-closure-workflow-schedule',
    };
    const schedule = commitApproved(binding, scheduleCommand, 4, 'closure-workflow-schedule', scheduleCommand.amount);
    const scheduleId = schedule.affected.find((record) => record.kind === 'payment-schedule')?.id;
    if (scheduleId === undefined) throw new Error('Closure workflow schedule is missing.');

    const hold = committed(executeCommand(store, context(binding), {
      kind: 'account.hold.place', accountId, expectedVersion: detail().account.version, amount: { minorUnits: 2_000, currency: 'USD' },
      reason: 'Closure review hold', expiresAt: '2026-09-20T15:00:00.000Z', releaseAuthority: 'closure-plan-W04',
    }, 'closure-workflow-hold'));
    const holdId = hold.affected.find((record) => record.kind === 'hold')?.id;
    if (holdId === undefined) throw new Error('Closure workflow hold is missing.');

    const openedCase = committed(executeCommand(store, context(binding), {
      kind: 'case.open', memberId: candidate.member_id, accountId, queueId: queue.id, assignedActorId: null,
      category: 'account-servicing', priority: 'normal', summary: 'Review account closure dependencies', dueDate: '2026-09-20',
    }, 'closure-workflow-case'));
    const caseId = openedCase.affected.find((record) => record.kind === 'case')?.id;
    if (caseId === undefined) throw new Error('Closure workflow case is missing.');

    const applyRestriction = {
      kind: 'account.restriction.apply' as const, accountId, expectedVersion: detail().account.version, restrictionType: 'closure-block' as const,
      reason: 'Closure dependencies need independent clearance', authority: 'closure-plan-W04', caseId, approvalId: 'approval-closure-workflow-restriction',
    };
    const restriction = commitApproved(binding, applyRestriction, 5, 'closure-workflow-restriction');
    const restrictionId = restriction.affected.find((record) => record.kind === 'restriction')?.id;
    if (restrictionId === undefined) throw new Error('Closure workflow restriction is missing.');

    const blocked = detail();
    expect(blocked.eligibility.closure.eligible).toBe(false);
    for (const reason of [
      'Posted balance must be exactly zero.', '1 active hold(s) must be released first.', '1 active payment reservation(s) remain.',
      'Active closure block restriction must be released first.', '1 payment(s) are still in progress.', '1 unretired payment schedule(s) use this account.',
    ]) expect(blocked.eligibility.closure.reasons).toContain(reason);
    expect(executeCommand(store, context(binding), {
      kind: 'account.close', accountId, expectedVersion: blocked.account.version, reason: 'Dependencies reviewed and resolved',
    }, 'closure-workflow-close-blocked')).toMatchObject({ kind: 'rejected', code: 'closure_blocked' });

    const releaseRestriction = {
      kind: 'account.restriction.release' as const, restrictionId, expectedFingerprint: recordFingerprint(binding, 'restriction', restrictionId),
      clearanceEvidenceId: candidate.evidence_id, approvalId: 'approval-closure-workflow-restriction-release',
    };
    commitApproved(binding, releaseRestriction, 5, 'closure-workflow-restriction-release');
    committed(executeCommand(store, context(binding), {
      kind: 'account.hold.release', holdId, expectedFingerprint: holdFingerprint(binding, holdId), amountMinorUnits: 2_000,
      releaseAuthority: 'closure-plan-W04', evidenceReference: 'closure-review-complete',
    }, 'closure-workflow-hold-release'));

    const paymentSnapshot = queryFinance(store, context(binding, 3), { kind: 'finance.record', resource: 'payment', id: paymentId });
    if (paymentSnapshot.kind !== 'found' || typeof paymentSnapshot.snapshot.record.version !== 'number') throw new Error('Closure payment cannot be reread.');
    committed(executeCommand(store, context(binding, 3), {
      kind: 'payment.cancel', paymentId, expectedVersion: paymentSnapshot.snapshot.record.version, reason: 'Account closure requested',
    }, 'closure-workflow-payment-cancel'));

    const endSchedule = {
      kind: 'payment.schedule.end' as const, scheduleId, expectedFingerprint: recordFingerprint(binding, 'payment-schedule', scheduleId),
      endFromDate: '2026-09-15', pendingDisposition: 'cancel-planned' as const, approvalId: 'approval-closure-workflow-schedule-end',
    };
    commitApproved(binding, endSchedule, 4, 'closure-workflow-schedule-end');

    const beforeTransfer = detail();
    const destinationBeforeTransfer = destinationDetail();
    expect(beforeTransfer.account.postedMinorUnits).toBe(10_000);
    committed(executeCommand(store, context(binding, 3), {
      kind: 'transfer.internal', sourceAccountId: accountId, destinationAccountId: candidate.destination_id,
      expectedSourceVersion: beforeTransfer.account.version, expectedDestinationVersion: destinationBeforeTransfer.account.version,
      amount: { minorUnits: beforeTransfer.account.postedMinorUnits, currency: 'USD' }, description: 'Approved account closure disposition',
    }, 'closure-workflow-disposition'));

    const ready = detail();
    expect(ready.account.postedMinorUnits).toBe(0);
    expect(ready.eligibility.closure).toEqual({ eligible: true, reasons: [] });
    const journalLinesBeforeClose = sql<{ count: number }>('SELECT COUNT(*) AS count FROM journal_lines WHERE dataset_id=?', binding.datasetId)[0]?.count;
    committed(executeCommand(store, context(binding), {
      kind: 'account.close', accountId, expectedVersion: ready.account.version, reason: 'Dependencies reviewed and resolved',
    }, 'closure-workflow-close'));

    expect(detail().account).toMatchObject({ status: 'closed', postedMinorUnits: 0, closedAt: '2026-09-14T15:00:00.000Z' });
    expect(sql('SELECT state FROM payments WHERE dataset_id=? AND id=?', binding.datasetId, paymentId)).toEqual([{ state: 'cancelled' }]);
    expect(sql('SELECT state FROM payment_schedules WHERE dataset_id=? AND id=?', binding.datasetId, scheduleId)).toEqual([{ state: 'ended' }]);
    expect(sql('SELECT status FROM holds WHERE dataset_id=? AND id=?', binding.datasetId, holdId)).toEqual([{ status: 'released' }]);
    expect(sql('SELECT status FROM restrictions WHERE dataset_id=? AND id=?', binding.datasetId, restrictionId)).toEqual([{ status: 'released' }]);
    expect(sql<{ count: number }>('SELECT COUNT(*) AS count FROM journal_lines WHERE dataset_id=?', binding.datasetId)[0]?.count).toBe(journalLinesBeforeClose);
    expect(bindingAuditFailures(binding)).toEqual([]);
  });
});

describe('payment maker and checker workflow', () => {
  it('creates a reserved payment, obtains independent approval and releases the exact instruction once', () => {
    const binding = clone();
    const candidate = sql<{ account_id: string; version: number; route_id: string; routing_kind: string }>(`SELECT a.id AS account_id,a.version,r.id AS route_id,r.routing_kind FROM accounts a
      JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      JOIN beneficiaries b ON b.dataset_id=m.dataset_id AND b.owner_party_id=m.party_id AND b.status='active'
      JOIN beneficiary_routes r ON r.dataset_id=b.dataset_id AND r.beneficiary_id=b.id AND r.status='verified'
      JOIN account_balances ab ON ab.dataset_id=a.dataset_id AND ab.account_id=a.id
      WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' AND r.expires_at>'2026-09-14T15:00:00.000Z' AND ab.available_balance_minor_units>10000
      ORDER BY a.id,r.id LIMIT 1`, binding.datasetId)[0];
    if (candidate === undefined) throw new Error('No eligible verified payment route exists.');
    const routeFingerprint = recordFingerprint(binding, 'beneficiary-route', candidate.route_id);
    const paymentReceipt = committed(executeCommand(store, context(binding, 3), {
      kind: 'payment.create', sourceAccountId: candidate.account_id, expectedSourceVersion: candidate.version,
      beneficiaryRouteId: candidate.route_id, expectedRouteFingerprint: routeFingerprint, amount: { minorUnits: 2_500, currency: 'USD' },
      rail: candidate.routing_kind, requestedDate: '2026-09-15', reference: 'FINANCE-PAYMENT-0001', targetState: 'pending-approval',
      calendarVersion: 'US-FI-2026.1', cutoffAt: '2026-09-15T21:00:00.000Z',
    }, 'payment-create-0001'));
    const paymentId = paymentReceipt.affected.find((record) => record.kind === 'payment')?.id ?? '';
    expect(paymentId).not.toBe('');
    expect(sql('SELECT state,version FROM payments WHERE dataset_id=? AND id=?', binding.datasetId, paymentId)).toEqual([{ state: 'pending-approval', version: 1 }]);
    expect(sql('SELECT amount_minor_units,status FROM reservations WHERE dataset_id=? AND payment_id=?', binding.datasetId, paymentId)).toEqual([{ amount_minor_units: 2_500, status: 'active' }]);

    const policy = sql<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
    if (policy === undefined) throw new Error('No effective approval policy exists.');
    const target = { kind: 'payment.approve_release' as const, paymentId, expectedVersion: 1, requestedDate: '2026-09-15', calendarVersion: 'US-FI-2026.1', cutoffAt: '2026-09-15T21:00:00.000Z', approvalId: 'pending-approval-id' };
    const requested = committed(executeCommand(store, context(binding, 3), {
      kind: 'approval.request', target, checkerActorId: `${binding.institutionId}-actor-4`, policyVersionId: policy.id,
      expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: { minorUnits: 2_500, currency: 'USD' },
    }, 'approval-request-0001'));
    const approvalId = requested.affected.find((record) => record.kind === 'approval')?.id ?? '';
    const approvals = listApprovals(store, context(binding, 4));
    if (approvals.kind !== 'found') throw new Error(`Expected checker approval list, received ${JSON.stringify(approvals)}`);
    const approval = approvals.approvals.find((item) => item.id === approvalId);
    if (approval === undefined) throw new Error('The requested approval was not listed for its checker.');
    committed(executeCommand(store, context(binding, 4), {
      kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Payment details and destination verified',
    }, 'approval-decide-0001'));

    expect(executeCommand(store, context(binding, 4), { ...target, approvalId, expectedVersion: 2 }, 'payment-release-0000')).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    const releaseReceipt = committed(executeCommand(store, context(binding, 4), { ...target, approvalId }, 'payment-release-0001'));
    expect(releaseReceipt.affected).toContainEqual(expect.objectContaining({ kind: 'payment', id: paymentId }));
    expect(sql('SELECT state,version FROM payments WHERE dataset_id=? AND id=?', binding.datasetId, paymentId)).toEqual([{ state: 'released', version: 2 }]);
    expect(sql('SELECT status FROM business_approvals WHERE dataset_id=? AND id=?', binding.datasetId, approvalId)).toEqual([{ status: 'consumed' }]);
    expect(executeCommand(store, context(binding, 4), { ...target, approvalId }, 'payment-release-0001')).toEqual({ kind: 'duplicate', receipt: releaseReceipt });
  });

  it('rejects a mismatched approval scope and amount limit without consuming approval or changing payment', () => {
    const binding = clone();
    const payment = sql<{ id: string; version: number; amount: number; currency: string }>("SELECT id,version,amount_minor_units AS amount,currency FROM payments WHERE dataset_id=? AND state='pending-approval' ORDER BY id LIMIT 1", binding.datasetId)[0];
    const policy = sql<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
    if (payment === undefined || policy === undefined) throw new Error('Payment approval fixtures are missing.');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare("UPDATE payment_events SET actor_id=? WHERE dataset_id=? AND payment_id=? AND state='pending-approval'").run(`${binding.institutionId}-actor-3`, binding.datasetId, payment.id);
      database.prepare("UPDATE payments SET requested_date='2026-09-14' WHERE dataset_id=? AND id=?").run(binding.datasetId, payment.id);
    });
    const wrongTarget = { kind: 'payment.approve_release' as const, paymentId: `${payment.id}-other`, expectedVersion: payment.version, requestedDate: '2026-09-14', calendarVersion: 'US-FI-2026.1', cutoffAt: '2026-09-14T21:00:00.000Z', approvalId: 'pending-approval-id' };
    const requested = committed(executeCommand(store, context(binding, 3), {
      kind: 'approval.request', target: wrongTarget, checkerActorId: `${binding.institutionId}-actor-4`, policyVersionId: policy.id,
      expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: { minorUnits: Math.max(1, payment.amount - 1), currency: payment.currency },
    }, 'approval-request-0002'));
    const approvalId = requested.affected.find((record) => record.kind === 'approval')?.id ?? '';
    const approvals = listApprovals(store, context(binding, 4));
    if (approvals.kind !== 'found') throw new Error('Approval list failed.');
    const approval = approvals.approvals.find((item) => item.id === approvalId);
    if (approval === undefined) throw new Error('Approval was not listed.');
    committed(executeCommand(store, context(binding, 4), { kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Reviewed' }, 'approval-decide-0002'));
    expect(executeCommand(store, context(binding, 4), {
      kind: 'payment.approve_release', paymentId: payment.id, expectedVersion: payment.version, requestedDate: '2026-09-14', calendarVersion: 'US-FI-2026.1', cutoffAt: '2026-09-14T21:00:00.000Z', approvalId,
    }, 'payment-release-0002')).toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'approvalId' });
    expect(sql('SELECT state,version FROM payments WHERE dataset_id=? AND id=?', binding.datasetId, payment.id)).toEqual([{ state: 'pending-approval', version: payment.version }]);
    expect(sql('SELECT status FROM business_approvals WHERE dataset_id=? AND id=?', binding.datasetId, approvalId)).toEqual([{ status: 'approved' }]);
  });
});

describe('beneficiary, schedule, cancellation and return services', () => {
  it('creates, verifies, versions and retires a beneficiary without exposing its simulated route token', () => {
    const binding = clone();
    const owner = sql<{ member_id: string; version: number; evidence_id: string }>(`SELECT m.id AS member_id,m.version,e.id AS evidence_id FROM members m
      JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id
      WHERE m.dataset_id=? AND m.status='active' AND e.status='verified' AND (e.expires_at IS NULL OR e.expires_at>'2026-09-14T15:00:00.000Z')
      ORDER BY m.id,e.id LIMIT 1`, binding.datasetId)[0];
    if (owner === undefined) throw new Error('No beneficiary owner with current evidence exists.');
    const created = committed(executeCommand(store, context(binding, 3), {
      kind: 'beneficiary.create', memberId: owner.member_id, expectedMemberVersion: owner.version, displayName: 'Verified Test Payee', routingKind: 'ach',
      maskedDestination: '****9042', simulatedToken: 'test-route-token-9042', allowedRails: ['ach'],
    }, 'beneficiary-create-0001'));
    const beneficiaryId = created.affected.find((record) => record.kind === 'beneficiary')?.id ?? '';
    const route = sql<{ id: string }>('SELECT id FROM beneficiary_routes WHERE dataset_id=? AND beneficiary_id=?', binding.datasetId, beneficiaryId)[0];
    if (route === undefined) throw new Error('Created beneficiary route is missing.');
    const routeRead = queryFinance(store, context(binding), { kind: 'finance.record', resource: 'beneficiary-route', id: route.id });
    if (routeRead.kind !== 'found') throw new Error('Created beneficiary route cannot be read.');
    expect(routeRead.snapshot.record).not.toHaveProperty('simulated_token');

    const verifyCommand = {
      kind: 'beneficiary.verify' as const, beneficiaryId, routeId: route.id, expectedFingerprint: routeRead.snapshot.fingerprint,
      evidenceId: owner.evidence_id, approvalId: 'test-approval-beneficiary-verify',
    };
    installApproval(binding, verifyCommand, 4);
    committed(executeCommand(store, context(binding, 4), verifyCommand, 'beneficiary-verify-0001'));
    expect(sql('SELECT status,verified_at FROM beneficiary_routes WHERE dataset_id=? AND id=?', binding.datasetId, route.id)).toEqual([
      expect.objectContaining({ status: 'verified', verified_at: '2026-09-14T15:00:00.000Z' }),
    ]);

    const routingCommand = {
      kind: 'beneficiary.routing.update' as const, beneficiaryId, expectedRouteFingerprint: recordFingerprint(binding, 'beneficiary-route', route.id),
      routingKind: 'ach', maskedDestination: '****7791', simulatedToken: 'test-route-token-7791', effectiveDate: '2026-09-14',
      approvalId: 'test-approval-beneficiary-routing',
    };
    installApproval(binding, routingCommand, 4);
    committed(executeCommand(store, context(binding, 4), routingCommand, 'beneficiary-route-0001'));
    expect(sql('SELECT version,masked_destination,status FROM beneficiary_routes WHERE dataset_id=? AND beneficiary_id=? ORDER BY version', binding.datasetId, beneficiaryId)).toEqual([
      { version: 1, masked_destination: '****9042', status: 'superseded' },
      { version: 2, masked_destination: '****7791', status: 'unverified' },
    ]);
    const retireCommand = { kind: 'beneficiary.retire' as const, beneficiaryId, expectedFingerprint: recordFingerprint(binding, 'beneficiary', beneficiaryId), dependentDisposition: 'reject-if-active' as const, reason: 'No longer used' };
    committed(executeCommand(store, context(binding, 3), retireCommand, 'beneficiary-retire-0001'));
    expect(sql('SELECT status FROM beneficiaries WHERE dataset_id=? AND id=?', binding.datasetId, beneficiaryId)).toEqual([{ status: 'disabled' }]);
  });

  it('creates a finite schedule, amends one occurrence and ends remaining future occurrences', () => {
    const binding = clone();
    const candidate = sql<{ account_id: string; version: number; route_id: string }>(`SELECT a.id AS account_id,a.version,r.id AS route_id FROM accounts a
      JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN beneficiaries b ON b.dataset_id=m.dataset_id AND b.owner_party_id=m.party_id AND b.status='active'
      JOIN beneficiary_routes r ON r.dataset_id=b.dataset_id AND r.beneficiary_id=b.id AND r.status='verified'
      WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' AND r.expires_at>'2026-09-14T15:00:00.000Z' ORDER BY a.id,r.id LIMIT 1`, binding.datasetId)[0];
    if (candidate === undefined) throw new Error('No schedulable beneficiary route exists.');
    const scheduleCommand = {
      kind: 'payment.schedule.create' as const, sourceAccountId: candidate.account_id, expectedSourceVersion: candidate.version,
      beneficiaryRouteId: candidate.route_id, expectedRouteFingerprint: recordFingerprint(binding, 'beneficiary-route', candidate.route_id),
      amount: { minorUnits: 750, currency: 'USD' }, frequency: 'daily' as const, interval: 1, startDate: '2026-09-15', endDate: '2026-09-17',
      approvalId: 'test-approval-schedule-create',
    };
    installApproval(binding, scheduleCommand, 4, scheduleCommand.amount);
    const created = committed(executeCommand(store, context(binding, 4), scheduleCommand, 'schedule-create-0001'));
    const scheduleId = created.affected.find((record) => record.kind === 'payment-schedule')?.id ?? '';
    expect(sql('SELECT local_date,state FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? ORDER BY local_date', binding.datasetId, scheduleId)).toEqual([
      { local_date: '2026-09-15', state: 'planned' }, { local_date: '2026-09-16', state: 'planned' }, { local_date: '2026-09-17', state: 'planned' },
    ]);
    const occurrence = sql<{ id: string }>('SELECT id FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? ORDER BY local_date LIMIT 1', binding.datasetId, scheduleId)[0];
    if (occurrence === undefined) throw new Error('Created occurrence is missing.');
    const amended = committed(executeCommand(store, context(binding, 3), {
      kind: 'payment.occurrence.amend', occurrenceId: occurrence.id, expectedFingerprint: recordFingerprint(binding, 'schedule-occurrence', occurrence.id),
      newAmount: { minorUnits: 825, currency: 'USD' }, newDate: '2026-09-20',
    }, 'occurrence-amend-0001'));
    expect(amended.affected.some((record) => record.kind === 'payment')).toBe(true);
    expect(sql('SELECT local_date,payment_id,state FROM schedule_occurrences WHERE dataset_id=? AND id=?', binding.datasetId, occurrence.id)).toEqual([
      expect.objectContaining({ local_date: '2026-09-20', state: 'planned' }),
    ]);
    const endCommand = {
      kind: 'payment.schedule.end' as const, scheduleId, expectedFingerprint: recordFingerprint(binding, 'payment-schedule', scheduleId),
      endFromDate: '2026-09-16', pendingDisposition: 'cancel-planned' as const, approvalId: 'test-approval-schedule-end',
    };
    installApproval(binding, endCommand, 4);
    committed(executeCommand(store, context(binding, 4), endCommand, 'schedule-end-0001'));
    expect(sql('SELECT state,end_date FROM payment_schedules WHERE dataset_id=? AND id=?', binding.datasetId, scheduleId)).toEqual([{ state: 'ended', end_date: '2026-09-16' }]);
    expect(sql('SELECT local_date,state FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? ORDER BY local_date', binding.datasetId, scheduleId)).toEqual([
      { local_date: '2026-09-16', state: 'cancelled' }, { local_date: '2026-09-17', state: 'cancelled' }, { local_date: '2026-09-20', state: 'cancelled' },
    ]);
  });

  it('cancels a draft immediately and resolves a returned payment without changing its beneficiary route', () => {
    const binding = clone();
    const draft = sql<{ id: string; version: number }>("SELECT id,version FROM payments WHERE dataset_id=? AND state='draft' ORDER BY id LIMIT 1", binding.datasetId)[0];
    const returned = sql<{ return_id: string; payment_id: string; route_id: string; amount: number; currency: string }>(`SELECT pr.id AS return_id,p.id AS payment_id,p.beneficiary_route_id AS route_id,pr.amount_minor_units AS amount,p.currency
      FROM payment_returns pr JOIN payments p ON p.dataset_id=pr.dataset_id AND p.id=pr.payment_id WHERE pr.dataset_id=? ORDER BY pr.id LIMIT 1`, binding.datasetId)[0];
    if (draft === undefined || returned === undefined) throw new Error('Payment lifecycle fixtures are missing.');
    committed(executeCommand(store, context(binding, 3), { kind: 'payment.cancel', paymentId: draft.id, expectedVersion: draft.version, reason: 'Customer withdrew instruction' }, 'payment-cancel-0001'));
    expect(sql('SELECT state FROM payments WHERE dataset_id=? AND id=?', binding.datasetId, draft.id)).toEqual([{ state: 'cancelled' }]);
    expect(sql('SELECT status FROM reservations WHERE dataset_id=? AND payment_id=?', binding.datasetId, draft.id)).toEqual([]);

    const returnCommand = {
      kind: 'payment.return.resolve' as const, returnId: returned.return_id, expectedFingerprint: recordFingerprint(binding, 'payment-return', returned.return_id),
      paymentId: returned.payment_id, disposition: 'credit-source' as const, approvalId: 'test-approval-return-resolve',
    };
    installApproval(binding, returnCommand, 4, { minorUnits: returned.amount, currency: returned.currency });
    const beforeRoute = sql('SELECT * FROM beneficiary_routes WHERE dataset_id=? AND id=?', binding.datasetId, returned.route_id);
    committed(executeCommand(store, context(binding, 4), returnCommand, 'payment-return-0001'));
    expect(sql('SELECT * FROM beneficiary_routes WHERE dataset_id=? AND id=?', binding.datasetId, returned.route_id)).toEqual(beforeRoute);
    expect(sql("SELECT COUNT(*) AS count FROM payment_postings WHERE dataset_id=? AND payment_id=? AND kind='return'", binding.datasetId, returned.payment_id)).toEqual([{ count: 1 }]);
  });

  it('opens a numbered return-investigation case with lifecycle provenance and no automatic resend', () => {
    const binding = clone();
    const returned = sql<{ return_id: string; payment_id: string; amount: number; currency: string }>(`SELECT pr.id AS return_id,p.id AS payment_id,pr.amount_minor_units AS amount,p.currency
      FROM payment_returns pr JOIN payments p ON p.dataset_id=pr.dataset_id AND p.id=pr.payment_id
      WHERE pr.dataset_id=? ORDER BY pr.id LIMIT 1`, binding.datasetId)[0];
    if (returned === undefined) throw new Error('Returned payment fixture is missing.');
    const command = {
      kind: 'payment.return.resolve' as const,
      returnId: returned.return_id,
      expectedFingerprint: recordFingerprint(binding, 'payment-return', returned.return_id),
      paymentId: returned.payment_id,
      disposition: 'investigate' as const,
      approvalId: 'test-approval-return-investigate',
    };
    installApproval(binding, command, 4, { minorUnits: returned.amount, currency: returned.currency });
    const paymentCount = sql('SELECT COUNT(*) AS count FROM payments WHERE dataset_id=?', binding.datasetId);
    const postingCount = sql('SELECT COUNT(*) AS count FROM payment_postings WHERE dataset_id=? AND payment_id=?', binding.datasetId, returned.payment_id);
    const receipt = committed(executeCommand(store, context(binding, 4), command, 'payment-return-investigate-0001'));
    const caseId = receipt.result?.caseId;
    const caseNumber = receipt.result?.caseNumber;
    if (typeof caseId !== 'string' || typeof caseNumber !== 'string') throw new Error('Return investigation case output is missing.');
    expect(caseNumber).toMatch(/^RT\d{7}$/u);
    expect(sql('SELECT case_number,state,category,account_id FROM cases WHERE dataset_id=? AND id=?', binding.datasetId, caseId)).toEqual([
      expect.objectContaining({ case_number: caseNumber, state: 'open', category: 'payment-return' }),
    ]);
    expect(sql('SELECT sequence,state,actor_id FROM case_events WHERE dataset_id=? AND case_id=?', binding.datasetId, caseId)).toEqual([
      { sequence: 1, state: 'open', actor_id: `${binding.institutionId}-actor-4` },
    ]);
    expect(sql('SELECT kind,reference_id,state FROM case_dependencies WHERE dataset_id=? AND case_id=?', binding.datasetId, caseId)).toEqual([
      { kind: 'payment-return', reference_id: returned.return_id, state: 'open' },
    ]);
    expect(sql('SELECT COUNT(*) AS count FROM payments WHERE dataset_id=?', binding.datasetId)).toEqual(paymentCount);
    expect(sql('SELECT COUNT(*) AS count FROM payment_postings WHERE dataset_id=? AND payment_id=?', binding.datasetId, returned.payment_id)).toEqual(postingCount);
  });
});

describe('restartable fee-refund campaign', () => {
  it('requests one immutable campaign approval and checkpoints each applied or stale item exactly once', () => {
    const binding = clone();
    const batch = sql<{ id: string; approved_total_limit_minor_units: number; currency: string }>(`SELECT id,approved_total_limit_minor_units,currency FROM batches b
      WHERE dataset_id=? AND kind='fee-refund' AND state='processing' AND EXISTS
        (SELECT 1 FROM batch_items i WHERE i.dataset_id=b.dataset_id AND i.batch_id=b.id AND i.state='pending')
      ORDER BY id LIMIT 1`, binding.datasetId)[0];
    const pending = batch === undefined ? [] : sql<{ id: string; fee_id: string; amount: number; currency: string }>(`SELECT id,
      json_extract(item_json,'$.feeId') AS fee_id,json_extract(item_json,'$.amountMinorUnits') AS amount,
      json_extract(item_json,'$.currency') AS currency FROM batch_items
      WHERE dataset_id=? AND batch_id=? AND state='pending' ORDER BY ordinal`, binding.datasetId, batch.id);
    const policy = sql<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id LIMIT 1', binding.datasetId, '2026-09-14T15:00:00.000Z')[0];
    if (batch === undefined || pending.length < 3 || policy === undefined) throw new Error('Refund campaign fixtures are missing.');
    const target: FinanceCommand = { kind: 'batch.fee_refunds.apply', batchId: batch.id, itemId: pending[0]?.id ?? '', expectedFingerprint: recordFingerprint(binding, 'batch', batch.id), approvalId: 'pending-campaign-approval' };
    const requested = committed(executeCommand(store, context(binding, 3), {
      kind: 'approval.request', target, checkerActorId: `${binding.institutionId}-actor-4`, policyVersionId: policy.id,
      expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: { minorUnits: batch.approved_total_limit_minor_units, currency: batch.currency },
    }, 'refund-campaign-request'));
    const approvalId = requested.affected.find((record) => record.kind === 'approval')?.id ?? '';
    const listed = listApprovals(store, context(binding, 4));
    if (listed.kind !== 'found') throw new Error(`Campaign approval list failed: ${JSON.stringify(listed)}`);
    const approval = listed.approvals.find((candidate) => candidate.id === approvalId);
    if (approval === undefined) throw new Error('Campaign approval was not listed.');
    const campaignTarget = approval.target;
    if (typeof campaignTarget !== 'object' || campaignTarget === null) throw new Error('Campaign approval target is missing.');
    expect(campaignTarget).toMatchObject({ kind: 'batch.fee_refunds.apply', batchId: batch.id, maximumNewRefundMinorUnits: batch.approved_total_limit_minor_units, conflictPolicy: 'skip' });
    const inputDigest = 'inputDigest' in campaignTarget ? campaignTarget.inputDigest : undefined;
    if (typeof inputDigest !== 'string') throw new Error('Campaign approval input digest is missing.');
    expect(inputDigest).toMatch(/^[a-f0-9]{64}$/u);
    committed(executeCommand(store, context(binding, 4), { kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Exact immutable rows and aggregate maximum reviewed' }, 'refund-campaign-decide'));

    const firstItem = pending[0];
    const peerItem = pending[1];
    if (firstItem === undefined || peerItem === undefined) throw new Error('Refund campaign rows disappeared.');
    const firstCommand: FinanceCommand = { kind: 'batch.fee_refunds.apply', batchId: batch.id, itemId: firstItem.id, expectedFingerprint: recordFingerprint(binding, 'batch', batch.id), approvalId };
    const first = committed(executeCommand(store, context(binding, 4), firstCommand, 'refund-campaign-item-1'));
    expect(first.result).toMatchObject({ itemId: firstItem.id, disposition: 'refunded', batchState: 'processing' });
    expect(executeCommand(store, context(binding, 4), firstCommand, 'refund-campaign-item-1')).toEqual({ kind: 'duplicate', receipt: first });

    const peerFee = sql<{ original_amount_minor_units: number; refunded: number }>(`SELECT f.original_amount_minor_units,
      COALESCE((SELECT SUM(r.amount_minor_units) FROM fee_refunds r WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id),0) AS refunded
      FROM fees f WHERE f.dataset_id=? AND f.id=?`, binding.datasetId, peerItem.fee_id)[0];
    if (peerFee === undefined) throw new Error('Peer refund fee is missing.');
    committed(executeCommand(store, context(binding, 3), { kind: 'fee.refund', feeId: peerItem.fee_id, expectedFingerprint: recordFingerprint(binding, 'fee', peerItem.fee_id), amount: { minorUnits: peerFee.original_amount_minor_units - peerFee.refunded, currency: peerItem.currency }, reason: 'Peer completed refund before campaign checkpoint' }, 'refund-campaign-peer'));
    const skipped = committed(executeCommand(store, context(binding, 4), { kind: 'batch.fee_refunds.apply', batchId: batch.id, itemId: peerItem.id, expectedFingerprint: recordFingerprint(binding, 'batch', batch.id), approvalId }, 'refund-campaign-item-2'));
    expect(skipped.result).toMatchObject({ itemId: peerItem.id, disposition: 'skipped', reason: 'eligibility-changed', batchState: 'processing' });
    expect(skipped.journals).toEqual([]);

    for (const [index, item] of pending.slice(2).entries()) {
      const outcome = committed(executeCommand(store, context(binding, 4), { kind: 'batch.fee_refunds.apply', batchId: batch.id, itemId: item.id, expectedFingerprint: recordFingerprint(binding, 'batch', batch.id), approvalId }, `refund-campaign-item-${index + 3}`));
      expect(outcome.result).toMatchObject({ itemId: item.id, disposition: 'refunded' });
      expect(outcome.journals).toHaveLength(1);
    }
    expect(sql('SELECT state FROM batches WHERE dataset_id=? AND id=?', binding.datasetId, batch.id)).toEqual([{ state: 'completed-with-exceptions' }]);
    expect(sql(`SELECT i.state,i.failure_code,r.receipt_number FROM batch_items i JOIN operation_receipts r
      ON r.dataset_id=i.dataset_id AND r.id=i.receipt_id WHERE i.dataset_id=? AND i.id=?`, binding.datasetId, peerItem.id)).toEqual([{ state: 'skipped', failure_code: 'eligibility-changed', receipt_number: skipped.receiptNumber }]);
    expect(sql("SELECT COUNT(*) AS count FROM batch_items WHERE dataset_id=? AND batch_id=? AND state IN ('valid','pending')", binding.datasetId, batch.id)).toEqual([{ count: 0 }]);
    expect(sql('SELECT status FROM business_approvals WHERE dataset_id=? AND id=?', binding.datasetId, approvalId)).toEqual([{ status: 'consumed' }]);
    expect(sql('SELECT COUNT(*) AS count FROM fee_refunds WHERE dataset_id=? AND fee_id=?', binding.datasetId, peerItem.fee_id)).toEqual([{ count: 1 }]);
    expect(bindingAuditFailures(binding)).toEqual([]);
  });
});

describe('restartable contact campaign', () => {
  it('checkpoints each item with its own receipt and resumes after a peer makes the next row stale', () => {
    const binding = clone();
    const campaign = addContactCampaign(binding, 'RESUME');
    const target: Extract<FinanceCommand, { kind: 'batch.contacts.apply' }> = {
      kind: 'batch.contacts.apply', batchId: campaign.batchId, itemId: campaign.itemIds[0],
      expectedFingerprint: recordFingerprint(binding, 'batch', campaign.batchId), approvalId: 'pending-contact-campaign', conflictPolicy: 'skip-stale',
    };
    const approvalId = approveContactCampaign(binding, target, 'contact-campaign-resume');
    const firstCommand = { ...target, approvalId };
    const first = committed(executeCommand(store, context(binding, 5), firstCommand, 'contact-campaign-resume-item-1'));
    expect(first.result).toMatchObject({ itemId: campaign.itemIds[0], disposition: 'applied', reason: null, batchState: 'processing' });
    expect(executeCommand(store, context(binding, 5), firstCommand, 'contact-campaign-resume-item-1')).toEqual({ kind: 'duplicate', receipt: first });

    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare('UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?').run(binding.datasetId, campaign.memberIds[1]);
    });
    const second = committed(executeCommand(store, context(binding, 5), {
      kind: 'batch.contacts.apply', batchId: campaign.batchId, itemId: campaign.itemIds[1],
      expectedFingerprint: recordFingerprint(binding, 'batch', campaign.batchId), approvalId, conflictPolicy: 'skip-stale',
    }, 'contact-campaign-resume-item-2'));
    expect(second.result).toMatchObject({ itemId: campaign.itemIds[1], disposition: 'skipped', reason: 'stale-version', batchState: 'completed-with-exceptions' });
    expect(sql('SELECT state FROM batches WHERE dataset_id=? AND id=?', binding.datasetId, campaign.batchId)).toEqual([{ state: 'completed-with-exceptions' }]);
    const checkpoints = sql<{ id: string; state: string; receipt_id: string | null; failure_code: string | null }>('SELECT id,state,receipt_id,failure_code FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal', binding.datasetId, campaign.batchId);
    expect(checkpoints).toEqual([
      expect.objectContaining({ id: campaign.itemIds[0], state: 'applied', failure_code: null }),
      expect.objectContaining({ id: campaign.itemIds[1], state: 'skipped', failure_code: 'stale-version' }),
    ]);
    expect(checkpoints[0]?.receipt_id).toBeTruthy();
    expect(checkpoints[1]?.receipt_id).toBeTruthy();
    expect(checkpoints[0]?.receipt_id).not.toBe(checkpoints[1]?.receipt_id);
    expect(sql('SELECT status FROM business_approvals WHERE dataset_id=? AND id=?', binding.datasetId, approvalId)).toEqual([{ status: 'consumed' }]);
    expect(sql('SELECT COUNT(*) AS count FROM contact_points WHERE dataset_id=? AND value=?', binding.datasetId, 'RESUME-first@example.invalid')).toEqual([{ count: 1 }]);
    expect(sql('SELECT COUNT(*) AS count FROM contact_points WHERE dataset_id=? AND value=?', binding.datasetId, '+13125550199')).toEqual([{ count: 0 }]);
  });

  it('rejects the whole campaign before its first checkpoint when reject-all sees a stale peer', () => {
    const binding = clone();
    const campaign = addContactCampaign(binding, 'REJECT');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare('UPDATE members SET version=version+1 WHERE dataset_id=? AND id=?').run(binding.datasetId, campaign.memberIds[1]);
    });
    const target: Extract<FinanceCommand, { kind: 'batch.contacts.apply' }> = {
      kind: 'batch.contacts.apply', batchId: campaign.batchId, itemId: campaign.itemIds[0],
      expectedFingerprint: recordFingerprint(binding, 'batch', campaign.batchId), approvalId: 'pending-contact-reject-all', conflictPolicy: 'reject-all',
    };
    const approvalId = approveContactCampaign(binding, target, 'contact-campaign-reject-all');
    const contactsBefore = sql('SELECT * FROM contact_points WHERE dataset_id=?', binding.datasetId);
    expect(executeCommand(store, context(binding, 5), { ...target, approvalId }, 'contact-campaign-reject-all-item-1')).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    expect(sql('SELECT * FROM contact_points WHERE dataset_id=?', binding.datasetId)).toEqual(contactsBefore);
    expect(sql('SELECT state,receipt_id FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal', binding.datasetId, campaign.batchId)).toEqual([
      { state: 'pending', receipt_id: null }, { state: 'pending', receipt_id: null },
    ]);
    expect(sql('SELECT status FROM business_approvals WHERE dataset_id=? AND id=?', binding.datasetId, approvalId)).toEqual([{ status: 'approved' }]);
  });
});

describe('suspense investigation clearance', () => {
  it('confirms the proposed match and resolves its one linked case only after exact approved clearance', () => {
    const binding = clone();
    const suspense = sql<{ id: string; amount: number; currency: string; evidence: string }>(`SELECT id,remaining_amount_minor_units AS amount,currency,evidence_reference AS evidence
      FROM suspense_items WHERE dataset_id=? AND state<>'cleared' AND remaining_amount_minor_units>0 ORDER BY id LIMIT 1`, binding.datasetId)[0];
    if (suspense === undefined) throw new Error('Open suspense fixture is missing.');
    const destination = sql<{ id: string; owner_party_id: string }>(`SELECT a.id,m.party_id AS owner_party_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id WHERE a.dataset_id=? AND a.status='open' AND a.currency=?
      AND NOT EXISTS (SELECT 1 FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active'
        AND r.kind IN ('credit-block','fraud-review')) ORDER BY a.id LIMIT 1`, binding.datasetId, suspense.currency)[0];
    if (destination === undefined) throw new Error('Eligible suspense destination is missing.');
    const sourceEvidence = addImmutableEvidence(binding, { versionId: 'suspense-source-evidence-v1', ownerPartyId: destination.owner_party_id, accountId: null, status: 'signed' });
    const destinationEvidence = addImmutableEvidence(binding, { versionId: 'suspense-destination-evidence-v1', ownerPartyId: destination.owner_party_id, accountId: destination.id });
    withTrustedFixtureTransaction({ path, binding }, (database) => database.prepare('UPDATE suspense_items SET evidence_reference=? WHERE dataset_id=? AND id=?').run(sourceEvidence, binding.datasetId, suspense.id));
    suspense.evidence = sourceEvidence;
    const investigated = committed(executeCommand(store, context(binding, 2), {
      kind: 'reconciliation.suspense.investigate', suspenseId: suspense.id, expectedFingerprint: recordFingerprint(binding, 'suspense-item', suspense.id),
      evidenceReferences: [suspense.evidence, destinationEvidence], proposedAccountId: destination.id,
    }, 'suspense-investigate-lifecycle'));
    const caseId = investigated.result?.caseId;
    const matchId = investigated.result?.matchId;
    if (typeof caseId !== 'string' || typeof matchId !== 'string') throw new Error('Suspense investigation output is missing.');
    const otherDestination = sql<{ id: string }>("SELECT id FROM accounts WHERE dataset_id=? AND status='open' AND currency=? AND id<>? ORDER BY id LIMIT 1", binding.datasetId, suspense.currency, destination.id)[0];
    if (otherDestination === undefined) throw new Error('Alternate suspense destination is missing.');
    const operationCount = sql('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId);
    const clearBase = {
      kind: 'reconciliation.suspense.clear' as const, suspenseId: suspense.id, expectedFingerprint: recordFingerprint(binding, 'suspense-item', suspense.id),
      destinationAccountId: destination.id, amount: { minorUnits: suspense.amount, currency: suspense.currency }, evidenceReference: suspense.evidence,
      approvalId: 'unused-invalid-suspense-clear',
    };
    expect(executeCommand(store, context(binding, 4), { ...clearBase, amount: { ...clearBase.amount, minorUnits: suspense.amount + 1 } }, 'suspense-clear-wrong-amount')).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(executeCommand(store, context(binding, 4), { ...clearBase, evidenceReference: 'wrong-evidence' }, 'suspense-clear-wrong-evidence')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(executeCommand(store, context(binding, 4), { ...clearBase, destinationAccountId: otherDestination.id }, 'suspense-clear-wrong-destination')).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    expect(sql('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId)).toEqual(operationCount);
    const clearCommand: FinanceCommand = {
      ...clearBase,
      approvalId: 'test-approval-suspense-clear',
    };
    installApproval(binding, clearCommand, 4, clearCommand.amount);
    const cleared = committed(executeCommand(store, context(binding, 4), clearCommand, 'suspense-clear-lifecycle'));
    expect(cleared.result).toMatchObject({ suspenseId: suspense.id, destinationAccountId: destination.id, remainingMinorUnits: 0, caseId, caseState: 'resolved' });
    expect(sql('SELECT state,remaining_amount_minor_units FROM suspense_items WHERE dataset_id=? AND id=?', binding.datasetId, suspense.id)).toEqual([{ state: 'cleared', remaining_amount_minor_units: 0 }]);
    expect(sql('SELECT state,version FROM cases WHERE dataset_id=? AND id=?', binding.datasetId, caseId)).toEqual([{ state: 'resolved', version: 2 }]);
    expect(sql('SELECT kind,reference_id,state FROM case_dependencies WHERE dataset_id=? AND case_id=?', binding.datasetId, caseId)).toEqual([{ kind: 'suspense', reference_id: suspense.id, state: 'satisfied' }]);
    expect(sql('SELECT sequence,state,actor_id FROM case_events WHERE dataset_id=? AND case_id=? ORDER BY sequence', binding.datasetId, caseId)).toEqual([
      { sequence: 1, state: 'open', actor_id: `${binding.institutionId}-actor-2` },
      { sequence: 2, state: 'resolved', actor_id: `${binding.institutionId}-actor-4` },
    ]);
    expect(sql('SELECT state FROM reconciliation_matches WHERE dataset_id=? AND id=?', binding.datasetId, matchId)).toEqual([{ state: 'confirmed' }]);
    expect(cleared.journals).toHaveLength(1);
    expect(bindingAuditFailures(binding)).toEqual([]);
  });
});

describe('card dispute case provenance', () => {
  it('opens one deterministic linked case with an initial lifecycle event and no final finding', () => {
    const binding = clone();
    const transaction = sql<{ id: string; amount_minor_units: number; currency: string; owner_party_id: string; account_id: string }>(`SELECT t.id,t.amount_minor_units,t.currency,m.party_id AS owner_party_id,a.id AS account_id FROM card_transactions t
      JOIN cards c ON c.dataset_id=t.dataset_id AND c.id=t.card_id JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      WHERE t.dataset_id=? AND t.state='posted' AND t.journal_id IS NOT NULL AND NOT EXISTS
        (SELECT 1 FROM disputes d WHERE d.dataset_id=t.dataset_id AND d.journal_id=t.journal_id AND d.state NOT IN ('denied','closed'))
      ORDER BY t.id LIMIT 1`, binding.datasetId)[0];
    if (transaction === undefined) throw new Error('No disputable card transaction exists.');
    const evidenceId = addImmutableEvidence(binding, { versionId: 'dispute-provenance-evidence-v1', ownerPartyId: transaction.owner_party_id, accountId: transaction.account_id });
    const receipt = committed(executeCommand(store, context(binding, 2), {
      kind: 'dispute.open', cardTransactionId: transaction.id, expectedFingerprint: recordFingerprint(binding, 'card-transaction', transaction.id),
      reason: 'Cardholder does not recognize this purchase', assertedAmount: { minorUnits: Math.min(500, transaction.amount_minor_units), currency: transaction.currency }, evidenceIds: [evidenceId],
    }, 'dispute-open-provenance'));
    const result = receipt.result;
    if (result === null || typeof result.caseId !== 'string') throw new Error('Dispute receipt omitted its linked case.');
    const serviceCase = sql<{ case_number: string; state: string }>('SELECT case_number,state FROM cases WHERE dataset_id=? AND id=?', binding.datasetId, result.caseId)[0];
    expect(serviceCase?.case_number).toMatch(/^DS\d{7}$/u);
    const caseEvents = sql<{ sequence: number; state: string; actor_id: string; detail: string }>('SELECT sequence,state,actor_id,detail FROM case_events WHERE dataset_id=? AND case_id=?', binding.datasetId, result.caseId);
    expect(caseEvents).toHaveLength(1);
    expect(caseEvents[0]).toMatchObject({ sequence: 1, state: 'open', actor_id: `${binding.institutionId}-actor-2` });
    expect(caseEvents[0]?.detail).toContain(transaction.id);
    expect(receipt.affected.some((record) => record.kind === 'case' && record.id === result.caseId)).toBe(true);
    expect(receipt.affected.some((record) => record.kind === 'dispute')).toBe(true);
    expect(bindingAuditFailures(binding)).toEqual([]);
  });

  it('accepts owner evidence, reconciles provisional credit and resolves the linked case at settlement', () => {
    const binding = clone();
    const transaction = sql<{ id: string; amount_minor_units: number; currency: string; owner_party_id: string; account_id: string }>(`SELECT t.id,t.amount_minor_units,t.currency,m.party_id AS owner_party_id,a.id AS account_id FROM card_transactions t
      JOIN cards c ON c.dataset_id=t.dataset_id AND c.id=t.card_id JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
      JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      WHERE t.dataset_id=? AND t.state='posted' AND t.journal_id IS NOT NULL
        AND NOT EXISTS (SELECT 1 FROM disputes d WHERE d.dataset_id=t.dataset_id AND d.journal_id=t.journal_id AND d.state NOT IN ('denied','closed'))
      ORDER BY t.id LIMIT 1`, binding.datasetId)[0];
    if (transaction === undefined) throw new Error('Disputable card transaction is missing.');
    const claimed = Math.min(1_000, transaction.amount_minor_units);
    const openingEvidenceId = addImmutableEvidence(binding, { versionId: 'dispute-lifecycle-opening-evidence-v1', ownerPartyId: transaction.owner_party_id, accountId: transaction.account_id });
    const opened = committed(executeCommand(store, context(binding, 2), {
      kind: 'dispute.open', cardTransactionId: transaction.id, expectedFingerprint: recordFingerprint(binding, 'card-transaction', transaction.id),
      reason: 'Complete dispute lifecycle test', assertedAmount: { minorUnits: claimed, currency: transaction.currency }, evidenceIds: [openingEvidenceId],
    }, 'dispute-lifecycle-open'));
    const disputeId = opened.result?.disputeId;
    const caseId = opened.result?.caseId;
    if (typeof disputeId !== 'string' || typeof caseId !== 'string') throw new Error('Dispute receipt omitted its linked identifiers.');

    const provisionalAmount = { minorUnits: Math.max(1, Math.floor(claimed / 2)), currency: transaction.currency };
    const provisionalCommand: FinanceCommand = {
      kind: 'dispute.provisional_credit.issue', disputeId, expectedFingerprint: recordFingerprint(binding, 'dispute', disputeId),
      amount: provisionalAmount, approvalId: 'test-approval-dispute-provisional',
    };
    commitApproved(binding, provisionalCommand, 4, 'dispute-lifecycle-provisional', provisionalAmount);

    const evidence = sql<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
      WHERE v.dataset_id=? AND d.owner_party_id=? AND d.account_id=? AND v.status IN ('current','signed') ORDER BY v.id LIMIT 1`, binding.datasetId, transaction.owner_party_id, transaction.account_id)[0];
    const deadline = sql<{ deadline: string }>('SELECT deadline FROM disputes WHERE dataset_id=? AND id=?', binding.datasetId, disputeId)[0]?.deadline;
    if (evidence === undefined || deadline === undefined) throw new Error('Owner evidence or dispute deadline is missing.');
    const redactedVersionId = addRedactedDisputePackage(binding, transaction.owner_party_id, transaction.account_id, evidence.id, 'lifecycle');
    expect(executeCommand(store, context(binding, 2), {
      kind: 'dispute.evidence.submit', disputeId, expectedFingerprint: recordFingerprint(binding, 'dispute', disputeId),
      documentVersionIds: [evidence.id], deadline, recipient: 'simulated-card-network', channel: 'simulated-dispute-channel',
      approvalId: 'not-approved-unredacted-evidence',
    }, 'dispute-lifecycle-unredacted')).toMatchObject({ kind: 'rejected', code: 'ineligible', field: 'documentVersionIds' });
    const evidenceCommand: FinanceCommand = {
      kind: 'dispute.evidence.submit', disputeId, expectedFingerprint: recordFingerprint(binding, 'dispute', disputeId),
      documentVersionIds: [redactedVersionId], deadline, recipient: 'simulated-card-network', channel: 'simulated-dispute-channel',
      approvalId: 'test-approval-dispute-evidence',
    };
    installApproval(binding, evidenceCommand, 2);
    expect(executeCommand(store, context(binding, 2), { ...evidenceCommand, recipient: 'unapproved-recipient' }, 'dispute-lifecycle-wrong-recipient'))
      .toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'approvalId' });
    const submitted = committed(executeCommand(store, context(binding, 2), evidenceCommand, 'dispute-lifecycle-evidence'));
    expect(submitted.result).toMatchObject({
      disputeId, documentVersionIds: [redactedVersionId], recipient: 'simulated-card-network', channel: 'simulated-dispute-channel',
      state: 'accepted', delivered: false,
    });
    const submissionId = submitted.result?.submissionId;
    const packageDigest = submitted.result?.packageDigest;
    if (typeof submissionId !== 'string' || typeof packageDigest !== 'string') throw new Error('Dispute evidence receipt omitted package acknowledgement identifiers.');
    expect(sql('SELECT dispute_id,recipient,channel,package_digest,state,delivered FROM dispute_evidence_submissions WHERE dataset_id=? AND id=?', binding.datasetId, submissionId)).toEqual([
      { dispute_id: disputeId, recipient: 'simulated-card-network', channel: 'simulated-dispute-channel', package_digest: packageDigest, state: 'accepted', delivered: 0 },
    ]);

    const finalAmount = { minorUnits: claimed, currency: transaction.currency };
    const settleCommand: FinanceCommand = {
      kind: 'dispute.settle', disputeId, expectedFingerprint: recordFingerprint(binding, 'dispute', disputeId), decision: 'approved', finalAmount,
      approvalId: 'test-approval-dispute-settle',
    };
    const settled = commitApproved(binding, settleCommand, 4, 'dispute-lifecycle-settle', finalAmount);
    expect(settled.result).toMatchObject({ disputeId, decision: 'approved', finalAmount, accountingDeltaMinorUnits: claimed - provisionalAmount.minorUnits, caseId, caseState: 'resolved' });
    expect(sql('SELECT state,version FROM cases WHERE dataset_id=? AND id=?', binding.datasetId, caseId)).toEqual([{ state: 'resolved', version: 2 }]);
    expect(sql('SELECT state FROM case_dependencies WHERE dataset_id=? AND case_id=?', binding.datasetId, caseId)).toEqual([{ state: 'satisfied' }]);
    expect(sql('SELECT sequence,state FROM case_events WHERE dataset_id=? AND case_id=? ORDER BY sequence', binding.datasetId, caseId)).toEqual([{ sequence: 1, state: 'open' }, { sequence: 2, state: 'resolved' }]);
    expect(sql('SELECT SUM(CASE kind WHEN \'provisional\' THEN amount_minor_units WHEN \'final\' THEN amount_minor_units ELSE -amount_minor_units END) AS credited FROM dispute_credits WHERE dataset_id=? AND dispute_id=?', binding.datasetId, disputeId)).toEqual([{ credited: claimed }]);
  });
});

describe('card temporary-lock boundaries', () => {
  it('rejects lock and unlock requests for a terminal card without changing its status or lock evidence', () => {
    const binding = clone();
    const card = sql<{ id: string; status: string }>("SELECT id,status FROM cards WHERE dataset_id=? AND status IN ('expired','replaced','permanently-blocked') ORDER BY id LIMIT 1", binding.datasetId)[0];
    if (card === undefined) throw new Error('No terminal card fixture exists.');
    const before = sql('SELECT * FROM card_locks WHERE dataset_id=? AND card_id=? ORDER BY id', binding.datasetId, card.id);
    for (const requestedState of ['locked','unlocked'] as const) {
      expect(executeCommand(store, context(binding, 2), {
        kind: 'card.lock.update', cardId: card.id, expectedFingerprint: recordFingerprint(binding, 'card', card.id), requestedState, authority: 'Cardholder request',
      }, `terminal-card-${requestedState}`)).toMatchObject({ kind: 'rejected', code: 'ineligible' });
    }
    expect(sql('SELECT status FROM cards WHERE dataset_id=? AND id=?', binding.datasetId, card.id)).toEqual([{ status: card.status }]);
    expect(sql('SELECT * FROM card_locks WHERE dataset_id=? AND card_id=? ORDER BY id', binding.datasetId, card.id)).toEqual(before);
  });
});

describe('card replacement order lifecycle', () => {
  it('cancels and reissues a pending replacement to a newly verified address without reviving the card', () => {
    const binding = clone();
    const card = sql<{ id: string; account_id: string; member_id: string; party_id: string; party_address_id: string; address_id: string; identity_evidence_id: string }>(`SELECT c.id,a.id AS account_id,a.member_id,m.party_id,pa.id AS party_address_id,pa.address_id,e.id AS identity_evidence_id FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
      JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN party_addresses pa ON pa.dataset_id=m.dataset_id AND pa.party_id=m.party_id
      JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id
      WHERE c.dataset_id=? AND c.status='active' AND a.status='open' AND pa.evidence_status='verified' AND pa.valid_to IS NULL
        AND e.status='verified' AND e.issued_at<='2026-09-14' AND (e.expires_at IS NULL OR e.expires_at>='2026-09-14') ORDER BY c.id,pa.id,e.id LIMIT 1`, binding.datasetId)[0];
    if (card === undefined) throw new Error('Replaceable card with verified address is missing.');
    const firstDestinationId = addCardShippingDestination(binding, {
      cardId: card.id, partyAddressId: card.party_address_id, ownerPartyId: card.party_id, accountId: card.account_id, suffix: 'initial',
    });
    const first = committed(executeCommand(store, context(binding, 2), {
      kind: 'card.replace', cardId: card.id, expectedFingerprint: recordFingerprint(binding, 'card', card.id), reason: 'Lost card',
      identityEvidenceId: card.identity_evidence_id, deliveryDestinationId: firstDestinationId, deliveryAddressId: card.address_id,
    }, 'card-replacement-initial'));
    const firstOrderId = first.result?.replacementOrderId;
    if (typeof firstOrderId !== 'string') throw new Error('Initial replacement omitted its order.');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare("INSERT INTO addresses (dataset_id,id,line1,line2,city,region,postal_code,country) VALUES (?,?,'44 Verified Way',NULL,'Chicago','IL','60602','US')").run(binding.datasetId, 'verified-reissue-address');
      database.prepare("INSERT INTO party_addresses (dataset_id,id,party_id,address_id,purpose,valid_from,valid_to,evidence_status) VALUES (?,?,?,?,'mailing','2026-09-14',NULL,'verified')").run(binding.datasetId, 'verified-reissue-link', card.party_id, 'verified-reissue-address');
    });
    const reissueDestinationId = addCardShippingDestination(binding, {
      cardId: card.id, partyAddressId: 'verified-reissue-link', ownerPartyId: card.party_id, accountId: card.account_id, suffix: 'reissue',
      previousDestinationId: firstDestinationId,
    });
    const reissued = committed(executeCommand(store, context(binding, 2), {
      kind: 'card.replace', cardId: card.id, expectedFingerprint: recordFingerprint(binding, 'card', card.id), reason: 'Verified address changed',
      identityEvidenceId: card.identity_evidence_id, deliveryDestinationId: reissueDestinationId, deliveryAddressId: 'verified-reissue-address',
    }, 'card-replacement-reissue'));
    expect(reissued.result).toMatchObject({ cardId: card.id, reissued: true, cancelledOrderId: firstOrderId, state: 'pending' });
    expect(sql("SELECT id,address_id,state FROM card_replacement_orders WHERE dataset_id=? AND card_id=? ORDER BY CASE state WHEN 'cancelled' THEN 0 ELSE 1 END,id", binding.datasetId, card.id)).toEqual([
      { id: firstOrderId, address_id: card.address_id, state: 'cancelled' },
      { id: reissued.result?.replacementOrderId, address_id: 'verified-reissue-address', state: 'pending' },
    ]);
    expect(sql('SELECT status FROM cards WHERE dataset_id=? AND id=?', binding.datasetId, card.id)).toEqual([{ status: 'replaced' }]);
    expect(sql("SELECT COUNT(*) AS count FROM card_locks WHERE dataset_id=? AND card_id=? AND kind='permanent' AND state='active'", binding.datasetId, card.id)).toEqual([{ count: 1 }]);
  });

  it('refuses replacement when the explicitly reviewed identity evidence is no longer verified', () => {
    const binding = clone();
    const card = sql<{ id: string; account_id: string; party_id: string; party_address_id: string; address_id: string; identity_evidence_id: string }>(`SELECT c.id,a.id AS account_id,m.party_id,pa.id AS party_address_id,pa.address_id,e.id AS identity_evidence_id
      FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
      JOIN party_addresses pa ON pa.dataset_id=m.dataset_id AND pa.party_id=m.party_id JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id
      WHERE c.dataset_id=? AND c.status='active' AND a.status='open' AND pa.evidence_status='verified' AND pa.valid_to IS NULL
        AND e.status='verified' AND e.issued_at<='2026-09-14' AND (e.expires_at IS NULL OR e.expires_at>='2026-09-14') ORDER BY c.id,pa.id,e.id LIMIT 1`, binding.datasetId)[0];
    if (card === undefined) throw new Error('Replacement identity fixture is missing.');
    const destinationId = addCardShippingDestination(binding, {
      cardId: card.id, partyAddressId: card.party_address_id, ownerPartyId: card.party_id, accountId: card.account_id, suffix: 'expired-identity',
    });
    const command: FinanceCommand = {
      kind: 'card.replace', cardId: card.id, expectedFingerprint: recordFingerprint(binding, 'card', card.id), reason: 'Lost card',
      identityEvidenceId: card.identity_evidence_id, deliveryDestinationId: destinationId, deliveryAddressId: card.address_id,
    };
    withTrustedFixtureTransaction({ path, binding }, database => database.prepare("UPDATE identity_evidence SET status='expired' WHERE dataset_id=? AND id=?")
      .run(binding.datasetId, card.identity_evidence_id));
    expect(executeCommand(store, context(binding, 2), command, 'card-replacement-expired-identity')).toMatchObject({ kind: 'rejected', code: 'ineligible', field: 'identityEvidenceId' });
    expect(sql('SELECT COUNT(*) AS count FROM card_replacement_orders WHERE dataset_id=? AND card_id=?', binding.datasetId, card.id)).toEqual([{ count: 0 }]);
  });
});

describe('card limit policy boundaries', () => {
  it('uses the facility effective at the proposed instant and an explicit policy ceiling when no facility exists', () => {
    const facilityBinding = clone();
    const card = sql<{ id: string; account_id: string; currency: string }>(`SELECT c.id,c.account_id,a.currency FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
      WHERE c.dataset_id=? AND c.status='active' AND a.status='open' ORDER BY c.id LIMIT 1`, facilityBinding.datasetId)[0];
    if (card === undefined) throw new Error('Active card fixture is missing.');
    withTrustedFixtureTransaction({ path, binding: facilityBinding }, (database) => {
      database.prepare('DELETE FROM card_limits WHERE dataset_id=? AND card_id=?').run(facilityBinding.datasetId, card.id);
      database.prepare('DELETE FROM facility_limit_terms WHERE dataset_id=? AND facility_id IN (SELECT id FROM facilities WHERE dataset_id=? AND account_id=?)').run(facilityBinding.datasetId, facilityBinding.datasetId, card.account_id);
      database.prepare('DELETE FROM facilities WHERE dataset_id=? AND account_id=?').run(facilityBinding.datasetId, card.account_id);
      const operation = database.prepare('SELECT id FROM operations WHERE dataset_id=? ORDER BY id LIMIT 1').get(facilityBinding.datasetId);
      if (operation === undefined || typeof operation.id !== 'string') throw new Error('Fixture operation is missing.');
      database.prepare("INSERT INTO facilities (dataset_id,id,account_id,kind,limit_minor_units,used_minor_units,status) VALUES (?,?,?,'credit-line',1000,0,'active')").run(facilityBinding.datasetId, 'future-card-facility', card.account_id);
      database.prepare('INSERT INTO facility_limit_terms (dataset_id,id,facility_id,limit_minor_units,effective_at,expires_at,operation_id) VALUES (?,?,?,?,?,NULL,?)').run(
        facilityBinding.datasetId, 'future-card-facility-term', 'future-card-facility', 5_000, '2026-09-15T15:00:00.000Z', operation.id,
      );
    });
    const futureCommand: FinanceCommand = {
      kind: 'card.limit.update', cardId: card.id, expectedFingerprint: recordFingerprint(facilityBinding, 'card', card.id),
      limitKind: 'daily-purchase', amount: { minorUnits: 4_000, currency: card.currency }, effectiveAt: '2026-09-16T15:00:00.000Z', expiresAt: null,
      approvalId: 'test-approval-future-card-limit',
    };
    const future = commitApproved(facilityBinding, futureCommand, 5, 'future-card-limit', futureCommand.amount);
    expect(future.result).toMatchObject({ cardId: card.id, amount: futureCommand.amount, effectiveAt: futureCommand.effectiveAt });
    expect(sql('SELECT limit_minor_units FROM facilities WHERE dataset_id=? AND id=?', facilityBinding.datasetId, 'future-card-facility')).toEqual([{ limit_minor_units: 1_000 }]);

    const policyBinding = clone();
    const policyCard = sql<{ id: string; account_id: string; currency: string }>(`SELECT c.id,c.account_id,a.currency FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
      WHERE c.dataset_id=? AND c.status='active' AND a.status='open' ORDER BY c.id LIMIT 1`, policyBinding.datasetId)[0];
    if (policyCard === undefined) throw new Error('Active policy-card fixture is missing.');
    withTrustedFixtureTransaction({ path, binding: policyBinding }, (database) => {
      database.prepare('DELETE FROM card_limits WHERE dataset_id=? AND card_id=?').run(policyBinding.datasetId, policyCard.id);
      database.prepare('DELETE FROM facility_limit_terms WHERE dataset_id=? AND facility_id IN (SELECT id FROM facilities WHERE dataset_id=? AND account_id=?)').run(policyBinding.datasetId, policyBinding.datasetId, policyCard.account_id);
      database.prepare('DELETE FROM facilities WHERE dataset_id=? AND account_id=?').run(policyBinding.datasetId, policyCard.account_id);
    });
    const policyCommand: FinanceCommand = {
      kind: 'card.limit.update', cardId: policyCard.id, expectedFingerprint: recordFingerprint(policyBinding, 'card', policyCard.id),
      limitKind: 'online', amount: { minorUnits: 2_000_000, currency: policyCard.currency }, effectiveAt: '2026-09-16T15:00:00.000Z', expiresAt: null,
      approvalId: 'test-approval-policy-card-limit',
    };
    const policy = commitApproved(policyBinding, policyCommand, 5, 'policy-card-limit', policyCommand.amount);
    expect(policy.result).toMatchObject({ cardId: policyCard.id, amount: policyCommand.amount });
    expect(sql('SELECT COUNT(*) AS count FROM facilities WHERE dataset_id=? AND account_id=?', policyBinding.datasetId, policyCard.account_id)).toEqual([{ count: 0 }]);
  });
});

describe('member and account financial controls', () => {
  it('applies an approved duplicate-member merge with the exact reviewed relationship set', () => {
    const binding = clone();
    const plan = sql<{ id: string; source_member_id: string; target_member_id: string; source_version: number; target_version: number }>(`SELECT p.id,p.source_member_id,p.target_member_id,s.version AS source_version,t.version AS target_version
      FROM member_merge_plans p JOIN members s ON s.dataset_id=p.dataset_id AND s.id=p.source_member_id
      JOIN members t ON t.dataset_id=p.dataset_id AND t.id=p.target_member_id WHERE p.dataset_id=? AND p.state='reviewed' LIMIT 1`, binding.datasetId)[0];
    if (plan === undefined) throw new Error('No reviewed merge plan exists.');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare('UPDATE member_merge_plans SET conflicts_json=? WHERE dataset_id=? AND id=?').run(JSON.stringify({ unresolved: [] }), binding.datasetId, plan.id);
    });
    const accountIds = sql<{ id: string }>('SELECT id FROM accounts WHERE dataset_id=? AND member_id=? ORDER BY id', binding.datasetId, plan.source_member_id).map((row) => row.id);
    const command: FinanceCommand = {
      kind: 'member.merge', mergePlanId: plan.id, sourceMemberId: plan.source_member_id, targetMemberId: plan.target_member_id,
      expectedSourceVersion: plan.source_version, expectedTargetVersion: plan.target_version, relationshipAccountIds: accountIds, expectedInventoryFingerprint: '', approvalId: 'test-approval-member-merge',
    };
    const activeRequests = sql<{ id: string; draft_json: string }>("SELECT id,draft_json FROM maintenance_requests WHERE dataset_id=? AND member_id=? AND state NOT IN ('applied','rejected','withdrawn','cancelled') ORDER BY id", binding.datasetId, plan.source_member_id);
    if (activeRequests.length > 0) {
      expect(executeCommand(store, context(binding, 5), command, 'member-merge-open-dependency')).toMatchObject({ kind: 'rejected', code: 'open_dependencies' });
      withTrustedFixtureTransaction({ path, binding }, (database) => {
        database.prepare("UPDATE maintenance_requests SET state='withdrawn',updated_at=? WHERE dataset_id=? AND member_id=? AND state NOT IN ('applied','rejected','withdrawn','cancelled')")
          .run('2026-09-14T15:00:00.000Z', binding.datasetId, plan.source_member_id);
      });
    }
    const preservedDocuments = sql<{ id: string; owner_party_id: string }>(`SELECT d.id,d.owner_party_id FROM documents d JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
      WHERE d.dataset_id=? AND m.id=? ORDER BY d.id`, binding.datasetId, plan.source_member_id);
    const inventory = queryMemberMergePlan(store, context(binding, 5), plan.id);
    if (inventory.kind !== 'found') throw new Error(JSON.stringify(inventory));
    command.expectedInventoryFingerprint = inventory.fingerprint;
    const receipt = commitApproved(binding, command, 5, 'member-merge-0001');
    expect(sql('SELECT status FROM members WHERE dataset_id=? AND id=?', binding.datasetId, plan.source_member_id)).toEqual([{ status: 'merged' }]);
    expect(sql('SELECT target_member_id FROM member_redirects WHERE dataset_id=? AND source_member_id=?', binding.datasetId, plan.source_member_id)).toEqual([{ target_member_id: plan.target_member_id }]);
    expect(sql<{ member_id: string }>('SELECT member_id FROM accounts WHERE dataset_id=? AND id IN (SELECT value FROM json_each(?))', binding.datasetId, JSON.stringify(accountIds)).every((row) => row.member_id === plan.target_member_id)).toBe(true);
    expect(sql('SELECT id,owner_party_id FROM documents WHERE dataset_id=? AND id IN (SELECT value FROM json_each(?)) ORDER BY id', binding.datasetId, JSON.stringify(preservedDocuments.map((document) => document.id)))).toEqual(preservedDocuments);
    expect(receipt.result).toMatchObject({ accounts: accountIds, sourceDocumentIds: preservedDocuments.map((document) => document.id) });
    for (const request of activeRequests) {
      expect(sql('SELECT member_id,draft_json FROM maintenance_requests WHERE dataset_id=? AND id=?', binding.datasetId, request.id)).toEqual([{ member_id: plan.source_member_id, draft_json: request.draft_json }]);
    }
  });

  it('records deceased status, complete beneficial ownership and prospective tax status from current evidence', () => {
    const deceasedBinding = clone();
    const person = sql<{ id: string; version: number; evidence_id: string }>(`SELECT m.id,m.version,e.id AS evidence_id FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
      JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id WHERE m.dataset_id=? AND m.status='active' AND p.kind='person' AND e.status='verified'
      AND (e.expires_at IS NULL OR e.expires_at>'2026-09-14T15:00:00.000Z') ORDER BY m.id LIMIT 1`, deceasedBinding.datasetId)[0];
    if (person === undefined) throw new Error('No evidenced person exists.');
    const deceasedCommand: FinanceCommand = { kind: 'member.deceased.record', memberId: person.id, expectedVersion: person.version, evidenceId: person.evidence_id, effectiveDate: '2026-09-14T15:00:00.000Z', approvalId: 'test-approval-deceased' };
    const deceasedReceipt = commitApproved(deceasedBinding, deceasedCommand, 5, 'member-deceased-0001');
    expect(sql('SELECT status FROM members WHERE dataset_id=? AND id=?', deceasedBinding.datasetId, person.id)).toEqual([{ status: 'deceased' }]);
    const estateCase = sql<{ id: string; case_number: string }>("SELECT id,case_number FROM cases WHERE dataset_id=? AND member_id=? AND category='estate-review'", deceasedBinding.datasetId, person.id)[0];
    if (estateCase === undefined) throw new Error('Deceased-member estate case was not created.');
    expect(estateCase.case_number).toMatch(/^DC\d{7}$/u);
    expect(sql('SELECT sequence,state,actor_id FROM case_events WHERE dataset_id=? AND case_id=?', deceasedBinding.datasetId, estateCase.id)).toEqual([{ sequence: 1, state: 'open', actor_id: `${deceasedBinding.institutionId}-actor-5` }]);
    expect(deceasedReceipt.affected.some((record) => record.kind === 'case' && record.id === estateCase.id)).toBe(true);
    expect(deceasedReceipt.affected.some((record) => record.kind === 'member' && record.id === person.id)).toBe(true);

    const ownershipBinding = clone();
    const organization = sql<{ id: string; version: number }>(`SELECT m.id,m.version FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
      WHERE m.dataset_id=? AND m.status='active' AND p.kind='organization' ORDER BY m.id LIMIT 1`, ownershipBinding.datasetId)[0];
    const owner = sql<{ id: string; evidence_id: string }>(`SELECT m.id,e.id AS evidence_id FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
      JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id WHERE m.dataset_id=? AND m.status='active' AND p.kind='person' AND e.status='verified'
      AND (e.expires_at IS NULL OR e.expires_at>'2026-09-14T15:00:00.000Z') ORDER BY m.id LIMIT 1`, ownershipBinding.datasetId)[0];
    if (organization === undefined || owner === undefined) throw new Error('Ownership fixtures are missing.');
    const ownershipCommand: FinanceCommand = { kind: 'member.beneficial_owners.update', organizationMemberId: organization.id, expectedVersion: organization.version, owners: [{ memberId: owner.id, ownershipBps: 10_000, isControlPerson: true, evidenceId: owner.evidence_id }], effectiveDate: '2026-09-14T15:00:00.000Z', approvalId: 'test-approval-owners' };
    commitApproved(ownershipBinding, ownershipCommand, 5, 'member-owners-0001');
    expect(sql('SELECT ownership_bps,is_control_person FROM organization_ownership WHERE dataset_id=? AND organization_party_id=(SELECT party_id FROM members WHERE dataset_id=? AND id=?) AND ends_at IS NULL', ownershipBinding.datasetId, ownershipBinding.datasetId, organization.id)).toEqual([{ ownership_bps: 10_000, is_control_person: 1 }]);

    const taxBinding = clone();
    const taxMember = sql<{ id: string; version: number; tax_classification: string; evidence_id: string }>(`SELECT m.id,m.version,m.tax_classification,e.id AS evidence_id FROM members m JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id
      WHERE m.dataset_id=? AND m.status='active' AND e.status='verified' AND (e.expires_at IS NULL OR e.expires_at>'2026-09-14T15:00:00.000Z') ORDER BY m.id LIMIT 1`, taxBinding.datasetId)[0];
    if (taxMember === undefined) throw new Error('Tax member fixture is missing.');
    const classification = taxMember.tax_classification === 'nonresident' ? 'individual' : 'nonresident';
    const taxCommand: FinanceCommand = { kind: 'member.tax_classification.update', memberId: taxMember.id, expectedVersion: taxMember.version, classification, effectiveYear: 2026, evidenceId: taxMember.evidence_id, approvalId: 'test-approval-tax' };
    commitApproved(taxBinding, taxCommand, 5, 'member-tax-0001');
    expect(sql('SELECT tax_classification FROM members WHERE dataset_id=? AND id=?', taxBinding.datasetId, taxMember.id)).toEqual([{ tax_classification: taxMember.tax_classification }]);
    expect(sql('SELECT classification,valid_from FROM tax_status_history WHERE dataset_id=? AND member_id=? AND valid_to IS NULL', taxBinding.datasetId, taxMember.id)).toEqual([{ classification, valid_from: '2026-01-01' }]);
  });

  it('converts a product, adds an owner, removes a signer and establishes an overdraft facility', () => {
    const convertBinding = clone();
    const convertible = sql<{ id: string; version: number; currency: string; product_id: string; target_id: string }>(`SELECT a.id,a.version,a.currency,a.product_id,p.id AS target_id FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id
      AND p.family='deposit' AND p.currency=a.currency AND p.status='active' AND p.id<>a.product_id WHERE a.dataset_id=? AND a.status='open' ORDER BY a.id,p.id LIMIT 1`, convertBinding.datasetId)[0];
    if (convertible === undefined) throw new Error('No convertible account exists.');
    const convertCommand: FinanceCommand = { kind: 'account.product.convert', accountId: convertible.id, expectedVersion: convertible.version, targetProductId: convertible.target_id, effectiveDate: '2026-09-14', feeDisclosureAccepted: true, approvalId: 'test-approval-product' };
    commitApproved(convertBinding, convertCommand, 5, 'account-product-0001');
    expect(sql('SELECT product_id FROM accounts WHERE dataset_id=? AND id=?', convertBinding.datasetId, convertible.id)).toEqual([{ product_id: convertible.product_id }]);
    expect(sql('SELECT product_id,effective_at FROM account_product_history WHERE dataset_id=? AND account_id=?', convertBinding.datasetId, convertible.id)).toEqual([{ product_id: convertible.target_id, effective_at: '2026-09-14T05:00:00.000Z' }]);

    const ownerBinding = clone();
    const ownershipCandidate = sql<{ account_id: string; version: number; member_id: string; party_id: string; evidence_id: string }>(`SELECT a.id AS account_id,a.version,m.id AS member_id,m.party_id,e.id AS evidence_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.status='active' AND m.id<>a.member_id
      JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id AND e.status='verified' AND e.issued_at<='2026-09-15T05:00:00.000Z' AND (e.expires_at IS NULL OR e.expires_at>'2026-09-15T05:00:00.000Z')
      WHERE a.dataset_id=? AND a.status='open' AND NOT EXISTS (SELECT 1 FROM account_parties ap WHERE ap.dataset_id=a.dataset_id AND ap.account_id=a.id AND ap.party_id=m.party_id AND ap.role='joint-owner' AND ap.ends_at IS NULL)
      ORDER BY a.id,m.id LIMIT 1`, ownerBinding.datasetId)[0];
    if (ownershipCandidate === undefined) throw new Error('No account owner candidate exists.');
    const disclosureBlob = sql<{ digest: string; media_type: string }>('SELECT digest,media_type FROM document_blobs WHERE dataset_id=? ORDER BY digest LIMIT 1', ownerBinding.datasetId)[0];
    if (disclosureBlob === undefined) throw new Error('No document blob exists for the ownership consent fixture.');
    withTrustedFixtureTransaction({ path, binding: ownerBinding }, (database) => {
      database.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
        VALUES (?,?,?,?,?,?,?,?)`).run(ownerBinding.datasetId, 'owner-add-disclosure', ownershipCandidate.party_id, ownershipCandidate.account_id, 'account-ownership-disclosure', 'Account ownership disclosure', 'account-lifecycle', '2026-09-14T15:00:00.000Z');
      database.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
        VALUES (?,?,?,?,?,?,?,NULL,NULL,NULL,'current')`).run(ownerBinding.datasetId, 'owner-add-disclosure-v1', 'owner-add-disclosure', 1, disclosureBlob.digest, disclosureBlob.media_type, '2026-09-14T15:00:00.000Z');
      database.prepare(`INSERT INTO consents (dataset_id,id,party_id,account_id,purpose,channel,disclosure_version_id,state,effective_at)
        VALUES (?,?,?,?,?,?,?,'granted',?)`).run(ownerBinding.datasetId, 'owner-add-consent', ownershipCandidate.party_id, ownershipCandidate.account_id, 'account-ownership', 'recorded', 'owner-add-disclosure-v1', '2026-09-14T15:00:00.000Z');
    });
    const ownerCommand: FinanceCommand = { kind: 'account.owner.add', accountId: ownershipCandidate.account_id, expectedVersion: ownershipCandidate.version, memberId: ownershipCandidate.member_id, role: 'joint-owner', effectiveDate: '2026-09-15', identityEvidenceId: ownershipCandidate.evidence_id, consentId: 'owner-add-consent', approvalId: 'test-approval-owner-add' };
    commitApproved(ownerBinding, ownerCommand, 5, 'account-owner-0001');
    expect(sql('SELECT COUNT(*) AS count FROM account_parties WHERE dataset_id=? AND account_id=? AND party_id=(SELECT party_id FROM members WHERE dataset_id=? AND id=?) AND role=? AND ends_at IS NULL', ownerBinding.datasetId, ownershipCandidate.account_id, ownerBinding.datasetId, ownershipCandidate.member_id, 'joint-owner')).toEqual([{ count: 1 }]);

    const signerBinding = clone();
    const signer = sql<{ account_id: string; version: number; member_id: string }>(`SELECT a.id AS account_id,a.version,m.id AS member_id FROM accounts a JOIN account_parties ap ON ap.dataset_id=a.dataset_id AND ap.account_id=a.id AND ap.role='signer' AND ap.ends_at IS NULL
      JOIN members m ON m.dataset_id=ap.dataset_id AND m.party_id=ap.party_id WHERE a.dataset_id=? ORDER BY a.id LIMIT 1`, signerBinding.datasetId)[0];
    if (signer === undefined) throw new Error('No active signer exists.');
    const signerCommand: FinanceCommand = { kind: 'account.signer.remove', accountId: signer.account_id, expectedVersion: signer.version, signerMemberId: signer.member_id, effectiveAt: '2026-09-15T15:00:00.000Z', approvalId: 'test-approval-signer-remove' };
    commitApproved(signerBinding, signerCommand, 5, 'account-signer-0001');
    expect(sql('SELECT ends_at FROM account_parties WHERE dataset_id=? AND account_id=? AND party_id=(SELECT party_id FROM members WHERE dataset_id=? AND id=?) AND role=?', signerBinding.datasetId, signer.account_id, signerBinding.datasetId, signer.member_id, 'signer')).toEqual([{ ends_at: '2026-09-15T15:00:00.000Z' }]);

    const overdraftBinding = clone();
    const overdraft = sql<{ id: string; version: number; currency: string }>(`SELECT a.id,a.version,a.currency FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id
      WHERE a.dataset_id=? AND a.status='open' AND p.family='deposit' AND NOT EXISTS (SELECT 1 FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id AND f.kind='overdraft') ORDER BY a.id LIMIT 1`, overdraftBinding.datasetId)[0];
    if (overdraft === undefined) throw new Error('No overdraft candidate exists.');
    const limit = { minorUnits: 25_000, currency: overdraft.currency };
    const overdraftCommand: FinanceCommand = { kind: 'account.overdraft_limit.update', accountId: overdraft.id, expectedVersion: overdraft.version, expectedFacilityFingerprint: null, limit, effectiveDate: '2026-09-14', expiresAt: null, approvalId: 'test-approval-overdraft' };
    commitApproved(overdraftBinding, overdraftCommand, 5, 'account-overdraft-0001', limit);
    expect(sql('SELECT limit_minor_units,status FROM facilities WHERE dataset_id=? AND account_id=? AND kind=?', overdraftBinding.datasetId, overdraft.id, 'overdraft')).toEqual([{ limit_minor_units: 0, status: 'active' }]);
    expect(sql(`SELECT t.limit_minor_units,t.effective_at,t.expires_at FROM facility_limit_terms t JOIN facilities f
      ON f.dataset_id=t.dataset_id AND f.id=t.facility_id WHERE f.dataset_id=? AND f.account_id=? AND f.kind=?`, overdraftBinding.datasetId, overdraft.id, 'overdraft')).toEqual([
      { limit_minor_units: 25_000, effective_at: '2026-09-14T05:00:00.000Z', expires_at: null },
    ]);
  });

  it('keeps future tax, product and overdraft decisions dormant until their effective times', () => {
    const taxBinding = clone();
    const taxMember = sql<{ id: string; version: number; tax_classification: string; evidence_id: string }>(`SELECT m.id,m.version,m.tax_classification,e.id AS evidence_id
      FROM members m JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id
      WHERE m.dataset_id=? AND m.status='active' AND e.status='verified' AND (e.expires_at IS NULL OR e.expires_at>'2026-09-14T15:00:00.000Z')
      ORDER BY m.id LIMIT 1`, taxBinding.datasetId)[0];
    if (taxMember === undefined) throw new Error('Future tax fixture is missing.');
    const classification = taxMember.tax_classification === 'tax-exempt' ? 'nonresident' : 'tax-exempt';
    const taxCommand: FinanceCommand = { kind: 'member.tax_classification.update', memberId: taxMember.id, expectedVersion: taxMember.version, classification, effectiveYear: 2027, evidenceId: taxMember.evidence_id, approvalId: 'test-approval-future-tax' };
    commitApproved(taxBinding, taxCommand, 5, 'future-tax-0001');
    using taxDatabase = openTrustedReadOnly(path);
    expect(memberDetail(taxDatabase, taxBinding.datasetId, taxMember.id, { institutionId: taxBinding.institutionId, actorId: `${taxBinding.institutionId}-actor-2`, now: '2026-12-31T18:00:00.000Z' })?.member.taxClassification).toBe(taxMember.tax_classification);
    expect(memberDetail(taxDatabase, taxBinding.datasetId, taxMember.id, { institutionId: taxBinding.institutionId, actorId: `${taxBinding.institutionId}-actor-2`, now: '2027-01-01T18:00:00.000Z' })?.member.taxClassification).toBe(classification);

    const productBinding = clone();
    const account = sql<{ id: string; version: number; product_id: string; target_id: string }>(`SELECT a.id,a.version,a.product_id,p.id AS target_id FROM accounts a JOIN products p
      ON p.dataset_id=a.dataset_id AND p.family='deposit' AND p.currency=a.currency AND p.status='active' AND p.id<>a.product_id
      WHERE a.dataset_id=? AND a.status='open' ORDER BY a.id,p.id LIMIT 1`, productBinding.datasetId)[0];
    if (account === undefined) throw new Error('Future product fixture is missing.');
    const productCommand: FinanceCommand = { kind: 'account.product.convert', accountId: account.id, expectedVersion: account.version, targetProductId: account.target_id, effectiveDate: '2026-10-01', feeDisclosureAccepted: true, approvalId: 'test-approval-future-product' };
    commitApproved(productBinding, productCommand, 5, 'future-product-0001');
    using productDatabase = openTrustedReadOnly(path);
    expect(accountDetail(productDatabase, productBinding.datasetId, account.id, '2026-09-30T12:00:00.000Z')?.account.productId).toBe(account.product_id);
    expect(accountDetail(productDatabase, productBinding.datasetId, account.id, '2026-10-01T12:00:00.000Z')?.account.productId).toBe(account.target_id);

    const facilityBinding = clone();
    const facilityAccount = sql<{ id: string; version: number; currency: string }>(`SELECT a.id,a.version,a.currency FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id
      WHERE a.dataset_id=? AND a.status='open' AND p.family='deposit' AND NOT EXISTS
        (SELECT 1 FROM facilities f WHERE f.dataset_id=a.dataset_id AND f.account_id=a.id AND f.kind='overdraft')
      ORDER BY a.id LIMIT 1`, facilityBinding.datasetId)[0];
    if (facilityAccount === undefined) throw new Error('Future facility fixture is missing.');
    const futureLimit = { minorUnits: 15_000, currency: facilityAccount.currency };
    const facilityCommand: FinanceCommand = { kind: 'account.overdraft_limit.update', accountId: facilityAccount.id, expectedVersion: facilityAccount.version, expectedFacilityFingerprint: null, limit: futureLimit, effectiveDate: '2026-10-01', expiresAt: '2026-10-03T05:00:00.000Z', approvalId: 'test-approval-future-overdraft' };
    commitApproved(facilityBinding, facilityCommand, 5, 'future-overdraft-0001', futureLimit);
    using facilityDatabase = openTrustedReadOnly(path);
    const before = accountDetail(facilityDatabase, facilityBinding.datasetId, facilityAccount.id, '2026-09-30T12:00:00.000Z')?.account.availableMinorUnits;
    const active = accountDetail(facilityDatabase, facilityBinding.datasetId, facilityAccount.id, '2026-10-01T12:00:00.000Z')?.account.availableMinorUnits;
    const expired = accountDetail(facilityDatabase, facilityBinding.datasetId, facilityAccount.id, '2026-10-03T12:00:00.000Z')?.account.availableMinorUnits;
    expect(active).toBe((before ?? 0) + futureLimit.minorUnits);
    expect(expired).toBe(before);
  });

  it('applies and independently releases one named restriction while preserving other restrictions', () => {
    const binding = clone();
    const target = sql<{ account_id: string; version: number; case_id: string; owner_party_id: string }>(`SELECT a.id AS account_id,a.version,c.id AS case_id,m.party_id AS owner_party_id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN cases c ON c.dataset_id=a.dataset_id AND c.member_id=a.member_id AND c.state<>'closed'
      WHERE a.dataset_id=? AND a.status='open' AND NOT EXISTS (SELECT 1 FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.kind='legal-hold' AND r.status='active')
      ORDER BY a.id,c.id LIMIT 1`, binding.datasetId)[0];
    if (target === undefined) throw new Error('No restriction candidate exists.');
    const applyCommand: FinanceCommand = { kind: 'account.restriction.apply', accountId: target.account_id, expectedVersion: target.version, restrictionType: 'legal-hold', reason: 'Court order received', authority: 'legal-operations', caseId: target.case_id, approvalId: 'test-approval-restriction-apply' };
    const applied = commitApproved(binding, applyCommand, 5, 'restriction-apply-0001');
    const restrictionId = applied.affected.find((record) => record.kind === 'restriction')?.id ?? '';
    const evidenceId = addVerifiedIdentityEvidence(binding, 'restriction-clearance-evidence', target.owner_party_id);
    const releaseCommand: FinanceCommand = { kind: 'account.restriction.release', restrictionId, expectedFingerprint: recordFingerprint(binding, 'restriction', restrictionId), clearanceEvidenceId: evidenceId, approvalId: 'test-approval-restriction-release' };
    commitApproved(binding, releaseCommand, 5, 'restriction-release-0001');
    expect(sql('SELECT status,released_at FROM restrictions WHERE dataset_id=? AND id=?', binding.datasetId, restrictionId)).toEqual([expect.objectContaining({ status: 'released', released_at: '2026-09-14T15:00:00.000Z' })]);
  });
});

describe('deposit maturity instructions', () => {
  it('uses the public authoritative term for cutoff and proceeds preview without moving funds', () => {
    const binding = clone();
    const candidate = sql<{ id: string; version: number; instruction_id: string; maturity_date: string; cutoff_at: string; projected_proceeds_minor_units: number; currency: string }>(`SELECT a.id,a.version,i.id AS instruction_id,c.maturity_date,c.cutoff_at,c.projected_proceeds_minor_units,c.currency
      FROM accounts a JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id
      JOIN deposit_maturity_terms c ON c.dataset_id=a.dataset_id AND c.account_id=a.id
      JOIN maturity_instructions i ON i.dataset_id=a.dataset_id AND i.account_id=a.id
      WHERE a.dataset_id=? AND p.family='deposit' AND lower(p.code) LIKE '%term%' AND a.status IN ('open','matured') AND c.cutoff_at>'2026-09-14T15:00:00.000Z'
      ORDER BY c.maturity_date,a.id LIMIT 1`, binding.datasetId)[0];
    if (candidate === undefined) throw new Error('No authoritative term-deposit maturity fixture exists.');
    using detailDatabase = openTrustedReadOnly(path);
    const detail = accountDetail(detailDatabase, binding.datasetId, candidate.id);
    const publicTerm = detail?.maturityTerms.find((term) => term.maturityDate === candidate.maturity_date);
    expect(publicTerm).toMatchObject({ cutoffAt: candidate.cutoff_at, projectedProceedsMinorUnits: candidate.projected_proceeds_minor_units, currency: candidate.currency });
    expect(detail?.maturityInstructions.some((instruction) => instruction.id === candidate.instruction_id)).toBe(true);
    const before = sql('SELECT * FROM account_balances WHERE dataset_id=? AND account_id=?', binding.datasetId, candidate.id);
    const command: FinanceCommand = {
      kind: 'account.maturity.instruct', accountId: candidate.id, expectedVersion: candidate.version,
      expectedInstructionFingerprint: recordFingerprint(binding, 'maturity-instruction', candidate.instruction_id), disposition: 'hold',
      destinationAccountId: null, termMonths: null, approvedAnnualRateBps: null, approvalId: 'test-approval-maturity',
    };
    const receipt = commitApproved(binding, command, 5, 'maturity-instruct-authoritative');
    expect(receipt.result).toMatchObject({
      maturityDate: candidate.maturity_date,
      projectedProceeds: { minorUnits: candidate.projected_proceeds_minor_units, currency: candidate.currency },
      destinationAccountId: null,
      execution: 'at-maturity',
      fundsMoved: false,
    });
    expect(receipt.journals).toEqual([]);
    expect(sql('SELECT cutoff_at FROM maturity_instructions WHERE dataset_id=? AND id=?', binding.datasetId, candidate.instruction_id)).toEqual([{ cutoff_at: candidate.cutoff_at }]);
    expect(sql('SELECT * FROM account_balances WHERE dataset_id=? AND account_id=?', binding.datasetId, candidate.id)).toEqual(before);
    expect(bindingAuditFailures(binding)).toEqual([]);
  });

  it('rejects an instruction when the account has no authoritative maturity term and records no operation', () => {
    const binding = clone();
    const candidate = sql<{ id: string; version: number; instruction_id: string }>(`SELECT a.id,a.version,i.id AS instruction_id FROM accounts a
      JOIN products p ON p.dataset_id=a.dataset_id AND p.id=a.product_id JOIN maturity_instructions i ON i.dataset_id=a.dataset_id AND i.account_id=a.id
      WHERE a.dataset_id=? AND p.family='deposit' AND lower(p.code) LIKE '%term%' ORDER BY a.id LIMIT 1`, binding.datasetId)[0];
    if (candidate === undefined) throw new Error('No term account exists for missing-contract verification.');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      database.prepare('DELETE FROM deposit_maturity_terms WHERE dataset_id=? AND account_id=?').run(binding.datasetId, candidate.id);
    });
    const before = sql('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId);
    const outcome = executeCommand(store, context(binding, 5), {
      kind: 'account.maturity.instruct', accountId: candidate.id, expectedVersion: candidate.version,
      expectedInstructionFingerprint: recordFingerprint(binding, 'maturity-instruction', candidate.instruction_id), disposition: 'hold',
      destinationAccountId: null, termMonths: null, approvedAnnualRateBps: null, approvalId: 'unused-maturity-approval',
    }, 'maturity-instruct-missing-contract');
    if (outcome.kind !== 'rejected') throw new Error(`Expected missing maturity contract rejection, received ${JSON.stringify(outcome)}`);
    expect(outcome.code).toBe('ineligible');
    expect(outcome.message).toContain('authoritative maturity term');
    expect(sql('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId)).toEqual(before);
  });
});

describe('fees and accounting corrections', () => {
  it('assesses, waives and refunds fees with linked balanced journals and exact limits', () => {
    const assessBinding = clone();
    withTrustedFixtureTransaction({ path, binding: assessBinding }, (database) => {
      database.prepare('INSERT INTO policy_versions (dataset_id,id,name,version,effective_at,rules_json) VALUES (?,?,?,?,?,?)').run(
        assessBinding.datasetId, 'test-fee-policy', 'Test fee schedule', '1', '2026-01-01T00:00:00.000Z',
        JSON.stringify({ fees: [{ code: 'test-document-copy', currency: 'USD', maximumMinorUnits: 750 }] }),
      );
    });
    const account = sql<{ id: string; version: number }>(`SELECT a.id,a.version FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
      WHERE a.dataset_id=? AND a.status='open' AND a.currency='USD' AND b.available_balance_minor_units>10000 ORDER BY a.id LIMIT 1`, assessBinding.datasetId)[0];
    if (account === undefined) throw new Error('Fee assessment fixtures are missing.');
    const assessed = committed(executeCommand(store, context(assessBinding, 3), { kind: 'fee.assess', accountId: account.id, expectedVersion: account.version, feeCode: 'test-document-copy', amount: { minorUnits: 625, currency: 'USD' }, basis: 'Approved document-copy policy', policyVersionId: 'test-fee-policy' }, 'fee-assess-0001'));
    const feeId = assessed.affected.find((record) => record.kind === 'fee')?.id ?? '';
    expect(assessed.journals[0]?.lines.reduce((net, line) => net + line.debitMinorUnits - line.creditMinorUnits, 0)).toBe(0);
    expect(sql('SELECT original_amount_minor_units,status FROM fees WHERE dataset_id=? AND id=?', assessBinding.datasetId, feeId)).toEqual([{ original_amount_minor_units: 625, status: 'assessed' }]);

    const waiverBinding = clone();
    const waiverAccount = sql<{ id: string; currency: string }>("SELECT id,currency FROM accounts WHERE dataset_id=? AND status='open' ORDER BY id LIMIT 1", waiverBinding.datasetId)[0];
    if (waiverAccount === undefined) throw new Error('Fee waiver account is missing.');
    const waiverLimit = { minorUnits: 2_000, currency: waiverAccount.currency };
    const waiverCommand: FinanceCommand = { kind: 'fee.waiver.create', accountId: waiverAccount.id, feeCode: 'test-prospective-waiver', validFrom: '2026-09-15', validThrough: '2026-12-31', amountLimit: waiverLimit, maxOccurrences: 3, reason: 'Relationship retention', approvalId: 'test-approval-fee-waiver' };
    commitApproved(waiverBinding, waiverCommand, 5, 'fee-waiver-0001', waiverLimit);
    expect(sql('SELECT amount_limit_minor_units,max_occurrences,state FROM fee_waivers WHERE dataset_id=? AND account_id=? AND fee_code=?', waiverBinding.datasetId, waiverAccount.id, 'test-prospective-waiver')).toEqual([{ amount_limit_minor_units: 2_000, max_occurrences: 3, state: 'approved' }]);

    const refundBinding = clone();
    const fee = sql<{ id: string; original_amount_minor_units: number; currency: string }>(`SELECT f.id,f.original_amount_minor_units,f.currency FROM fees f WHERE f.dataset_id=?
      AND NOT EXISTS (SELECT 1 FROM fee_refunds r WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id) ORDER BY f.id LIMIT 1`, refundBinding.datasetId)[0];
    if (fee === undefined) throw new Error('Refundable fee is missing.');
    const refundAmount = Math.min(100, fee.original_amount_minor_units);
    const refunded = committed(executeCommand(store, context(refundBinding, 3), { kind: 'fee.refund', feeId: fee.id, expectedFingerprint: recordFingerprint(refundBinding, 'fee', fee.id), amount: { minorUnits: refundAmount, currency: fee.currency }, reason: 'Duplicate service charge' }, 'fee-refund-0001'));
    expect(refunded.journals[0]?.lines.reduce((net, line) => net + line.debitMinorUnits - line.creditMinorUnits, 0)).toBe(0);
    expect(sql('SELECT amount_minor_units FROM fee_refunds WHERE dataset_id=? AND fee_id=?', refundBinding.datasetId, fee.id)).toEqual([{ amount_minor_units: refundAmount }]);
    expect(executeCommand(store, context(refundBinding, 3), { kind: 'fee.refund', feeId: fee.id, expectedFingerprint: recordFingerprint(refundBinding, 'fee', fee.id), amount: { minorUnits: fee.original_amount_minor_units, currency: fee.currency }, reason: 'Too much' }, 'fee-refund-0002')).toMatchObject({ kind: 'rejected', code: 'limit_exceeded' });
  });

  it('rejects a posting that would make an aggregate ledger balance inexact', () => {
    const binding = clone();
    const fee = sql<{ id: string; account_id: string; original_amount_minor_units: number; currency: string }>(`SELECT f.id,f.account_id,f.original_amount_minor_units,f.currency FROM fees f WHERE f.dataset_id=?
      AND f.original_amount_minor_units>=100 AND NOT EXISTS (SELECT 1 FROM fee_refunds r WHERE r.dataset_id=f.dataset_id AND r.fee_id=f.id) ORDER BY f.id LIMIT 1`, binding.datasetId)[0];
    if (fee === undefined) throw new Error('Refundable fee is missing.');
    withTrustedFixtureTransaction({ path, binding }, (database) => {
      const ledgers = database.prepare(`SELECT customer.id AS customer_id,income.id AS income_id,b.posted_balance_minor_units AS customer_balance
        FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
        JOIN ledger_accounts customer ON customer.dataset_id=a.dataset_id AND customer.customer_account_id=a.id
        JOIN ledger_accounts income ON income.dataset_id=a.dataset_id AND income.kind='fee-income' AND income.currency=a.currency
        WHERE a.dataset_id=? AND a.id=? ORDER BY customer.id,income.id LIMIT 1`).get(binding.datasetId, fee.account_id);
      if (ledgers === undefined || typeof ledgers.customer_id !== 'string' || typeof ledgers.income_id !== 'string' || typeof ledgers.customer_balance !== 'number') throw new Error('Fee posting ledgers are missing.');
      const amount = Number.MAX_SAFE_INTEGER - 50 - ledgers.customer_balance;
      if (!Number.isSafeInteger(amount) || amount <= 0) throw new Error('Could not establish a safe-integer ledger boundary.');
      database.prepare("INSERT INTO journals (dataset_id,id,reference,operation_id,status,posted_at,effective_date,description,reversal_of_id) VALUES (?,?,'SAFE-HEADROOM',NULL,'posted','2026-09-14T14:00:00.000Z','2026-09-14','Safe integer boundary',NULL)").run(binding.datasetId, 'safe-ledger-headroom');
      const insert = database.prepare('INSERT INTO journal_lines (dataset_id,journal_id,line_number,ledger_account_id,currency,debit_minor_units,credit_minor_units,memo) VALUES (?,?,?,?,?,?,?,?)');
      insert.run(binding.datasetId, 'safe-ledger-headroom', 1, ledgers.income_id, fee.currency, amount, 0, 'Safe integer boundary');
      insert.run(binding.datasetId, 'safe-ledger-headroom', 2, ledgers.customer_id, fee.currency, 0, amount, 'Safe integer boundary');
    });
    const before = sql('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId);
    const outcome = executeCommand(store, context(binding, 3), {
      kind: 'fee.refund', feeId: fee.id, expectedFingerprint: recordFingerprint(binding, 'fee', fee.id),
      amount: { minorUnits: 100, currency: fee.currency }, reason: 'Safe-integer boundary regression',
    }, 'fee-refund-safe-integer');
    expect(outcome).toMatchObject({ kind: 'rejected', code: 'limit_exceeded' });
    expect(sql('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', binding.datasetId)).toEqual(before);
    expect(sql("SELECT COUNT(*) AS count FROM journals WHERE dataset_id=? AND description LIKE 'Refund of fee %Safe-integer boundary regression'", binding.datasetId)).toEqual([{ count: 0 }]);
  });

  it('posts exact full cash reversals and one bounded internal-transfer reversal', () => {
    for (const specification of [
      { operationKind: 'cash.deposit', commandKind: 'cash.deposit.reverse', key: 'cash-deposit-reverse-0001' },
      { operationKind: 'cash.withdraw', commandKind: 'cash.withdrawal.reverse', key: 'cash-withdraw-reverse-0001' },
    ] as const) {
      const binding = clone();
      const account = sql<{ id: string; version: number; currency: string; available: number; owner_party_id: string }>(`SELECT a.id,a.version,a.currency,b.available_balance_minor_units AS available,m.party_id AS owner_party_id FROM accounts a
        JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id WHERE a.dataset_id=? AND a.status='open' AND b.available_balance_minor_units>1000
        AND NOT EXISTS (SELECT 1 FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active' AND r.kind IN ('debit-block','fraud-review','legal-hold'))
        ORDER BY a.id LIMIT 1`, binding.datasetId)[0];
      if (account === undefined) throw new Error('No account can create a reversible cash posting.');
      const amount = specification.operationKind === 'cash.deposit' ? 321 : Math.min(321, account.available);
      const created = committed(executeCommand(store, context(binding, 2), {
        kind: specification.operationKind, accountId: account.id, expectedVersion: account.version,
        amount: { minorUnits: amount, currency: account.currency }, description: `Create ${specification.operationKind} reversal source`,
      }, `${specification.key}-source`));
      const original = { id: created.journals[0]?.id ?? '', amount, currency: account.currency };
      if (original.id === '') throw new Error(`Created ${specification.operationKind} has no journal.`);
      const approvalId = `test-approval-${specification.commandKind}`;
      if (specification.commandKind === 'cash.deposit.reverse') addVerifiedIdentityEvidence(binding, 'verified-cash-correction', account.owner_party_id);
      const command: FinanceCommand = specification.commandKind === 'cash.deposit.reverse'
        ? { kind: specification.commandKind, journalId: original.id, expectedFingerprint: recordFingerprint(binding, 'journal', original.id), correctionEvidenceId: 'verified-cash-correction', approvalId }
        : { kind: specification.commandKind, journalId: original.id, expectedFingerprint: recordFingerprint(binding, 'journal', original.id), reason: 'Teller correction', approvalId };
      const receipt = commitApproved(binding, command, 4, specification.key, { minorUnits: original.amount, currency: original.currency });
      expect(receipt.journals).toHaveLength(1);
      expect(receipt.journals[0]?.lines.reduce((net, line) => net + line.debitMinorUnits - line.creditMinorUnits, 0)).toBe(0);
      expect(sql('SELECT amount_minor_units,kind FROM correction_links WHERE dataset_id=? AND original_journal_id=? AND correction_journal_id=?', binding.datasetId, original.id, receipt.journals[0]?.id ?? '')).toEqual([{ amount_minor_units: original.amount, kind: 'reversal' }]);
    }

    const transferBinding = clone();
    const accounts = sql<{ id: string; member_id: string; version: number; currency: string; available: number }>(`SELECT a.id,a.member_id,a.version,a.currency,b.available_balance_minor_units AS available FROM accounts a
      JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.status='open' AND b.available_balance_minor_units>1000
      AND NOT EXISTS (SELECT 1 FROM restrictions r WHERE r.dataset_id=a.dataset_id AND r.account_id=a.id AND r.status='active' AND r.kind IN ('debit-block','fraud-review','legal-hold'))
      ORDER BY a.currency,a.id`, transferBinding.datasetId);
    const source = accounts.find((account) => accounts.some((other) => other.id !== account.id && other.member_id === account.member_id && other.currency === account.currency));
    const destination = source === undefined ? undefined : accounts.find((account) => account.id !== source.id && account.member_id === source.member_id && account.currency === source.currency);
    if (source === undefined || destination === undefined) throw new Error('No eligible transfer pair exists.');
    const transferReceipt = committed(executeCommand(store, context(transferBinding, 3), { kind: 'transfer.internal', sourceAccountId: source.id, destinationAccountId: destination.id,
      expectedSourceVersion: source.version, expectedDestinationVersion: destination.version, amount: { minorUnits: 500, currency: source.currency }, description: 'Create reversal source' }, 'transfer-reverse-source'));
    const transfer = { id: transferReceipt.journals[0]?.id ?? '', amount: 500, currency: source.currency };
    if (transfer.id === '') throw new Error('Created transfer has no journal.');
    const reversal = { minorUnits: 100, currency: transfer.currency };
    const transferCommand: FinanceCommand = { kind: 'transfer.internal.reverse', transferJournalId: transfer.id, expectedFingerprint: recordFingerprint(transferBinding, 'journal', transfer.id), amount: reversal, reason: 'Duplicate transfer', approvalId: 'test-approval-transfer-reverse' };
    const receipt = commitApproved(transferBinding, transferCommand, 3, 'transfer-reverse-0001', reversal, 2);
    expect(receipt.journals[0]?.lines.reduce((net, line) => net + line.debitMinorUnits - line.creditMinorUnits, 0)).toBe(0);
    expect(sql('SELECT amount_minor_units FROM correction_links WHERE dataset_id=? AND original_journal_id=?', transferBinding.datasetId, transfer.id)).toEqual([{ amount_minor_units: reversal.minorUnits }]);
  });

  it('posts the signed stored interest delta and appends an effective-date correction without rewriting the journal', () => {
    const interestBinding = clone();
    const calculation = sql<{ id: string; account_id: string; delta_minor_units: number; currency: string }>(`SELECT c.id,c.account_id,c.delta_minor_units,a.currency FROM interest_calculations c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id
      WHERE c.dataset_id=? AND c.delta_minor_units<>0 AND c.adjustment_journal_id IS NULL ORDER BY c.id LIMIT 1`, interestBinding.datasetId)[0];
    if (calculation === undefined) throw new Error('No unposted interest delta exists.');
    const interestCommand: FinanceCommand = { kind: 'interest.adjust', accountId: calculation.account_id, calculationId: calculation.id, expectedFingerprint: recordFingerprint(interestBinding, 'interest-calculation', calculation.id), approvedDelta: { minorUnits: calculation.delta_minor_units, currency: calculation.currency }, approvalId: 'test-approval-interest' };
    const interestReceipt = commitApproved(interestBinding, interestCommand, 3, 'interest-adjust-0001', { minorUnits: Math.abs(calculation.delta_minor_units), currency: calculation.currency }, 2);
    expect(interestReceipt.journals[0]?.lines.reduce((net, line) => net + line.debitMinorUnits - line.creditMinorUnits, 0)).toBe(0);
    expect(sql('SELECT state,adjustment_journal_id FROM interest_calculations WHERE dataset_id=? AND id=?', interestBinding.datasetId, calculation.id)).toEqual([expect.objectContaining({ state: 'posted', adjustment_journal_id: interestReceipt.journals[0]?.id })]);

    const dateBinding = clone();
    const candidate = sql<{ journal_id: string; effective_date: string; policy_id: string }>(`SELECT j.id AS journal_id,j.effective_date,p.id AS policy_id FROM journals j JOIN policy_versions p ON p.dataset_id=j.dataset_id
      WHERE j.dataset_id=? AND json_extract(p.rules_json,'$.correctionPeriodStatus')='open' AND j.effective_date>=json_extract(p.rules_json,'$.periodStartInclusive')
      AND j.effective_date<json_extract(p.rules_json,'$.periodEndExclusive') ORDER BY j.id LIMIT 1`, dateBinding.datasetId)[0];
    if (candidate === undefined) throw new Error('No journal exists in an open correction period.');
    const correctedDate = candidate.effective_date === '2026-07-02' ? '2026-07-03' : '2026-07-02';
    const dateCommand: FinanceCommand = { kind: 'transaction.effective_date.correct', journalId: candidate.journal_id, expectedFingerprint: recordFingerprint(dateBinding, 'journal', candidate.journal_id), correctedDate, policyVersionId: candidate.policy_id, reason: 'Customer-provided effective date', approvalId: 'test-approval-effective-date' };
    commitApproved(dateBinding, dateCommand, 3, 'effective-date-0001', null, 2);
    expect(sql('SELECT effective_date FROM journals WHERE dataset_id=? AND id=?', dateBinding.datasetId, candidate.journal_id)).toEqual([{ effective_date: candidate.effective_date }]);
    expect(sql('SELECT old_effective_date,new_effective_date FROM effective_date_corrections WHERE dataset_id=? AND journal_id=? AND new_effective_date=?', dateBinding.datasetId, candidate.journal_id, correctedDate)).toEqual([{ old_effective_date: candidate.effective_date, new_effective_date: correctedDate }]);
  });
});
