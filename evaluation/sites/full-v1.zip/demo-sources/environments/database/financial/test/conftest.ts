import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export interface TestDatabasePath {
  path: string;
  cleanup(): void;
}

export function createTestDatabasePath(): TestDatabasePath {
  const directory = mkdtempSync(join(tmpdir(), 'financial-database-'));
  return {
    path: join(directory, 'financial.sqlite'),
    cleanup(): void {
      rmSync(directory, { recursive: true, force: true });
    },
  };
}

import { DatabaseSync } from 'node:sqlite';
import { createSchema } from '../src/schema.js';
import { createSeedRandom } from '../src/seed/random.js';
import type { DatasetId, InstitutionId } from '../src/model.js';
import type { SeedContext } from '../src/seed/contract.js';

export function createCoreSeedFixture(path = ':memory:'): SeedContext {
  const database = new DatabaseSync(path);
  createSchema(database);
  database.prepare('INSERT INTO institutions VALUES (?,?,?,?,?,?)').run('northstar','Northstar Cooperative','Northstar','US','America/Chicago','USD');
  database.prepare('INSERT INTO datasets VALUES (?,?,?,?,?,?,?,?,?)').run('domain-test','northstar','domain-test',42,'small','2026-09-14T15:00:00.000Z','1',1,0);
  return { database, binding:{institutionId:'northstar' as InstitutionId,datasetId:'domain-test' as DatasetId},
    institution:{id:'northstar',legalName:'Northstar Cooperative',displayName:'Northstar',timeZone:'America/Chicago',defaultCurrency:'USD'},
    scale:'small',profile:{membersPerInstitution:48,organizationsPerInstitution:4,historyMonths:18,ordinaryJournalTransactionsPerAccount:20},
    seed:42,asOf:'2026-09-14T15:00:00.000Z',random:createSeedRandom(42),id:(kind,ordinal)=>`${kind}-${ordinal}`,
    businessNumber:(prefix,ordinal,width=6)=>`${prefix}-${String(ordinal).padStart(width,'0')}` };
}
