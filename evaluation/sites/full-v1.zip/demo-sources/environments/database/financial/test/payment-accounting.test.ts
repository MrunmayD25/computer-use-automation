import { expect, it } from 'vitest';
import { seedCore } from '../src/seed/core.js';
import { seedFinancialDomains } from '../src/seed/financial.js';
import { seedPaymentAccounting } from '../src/seed/payment-accounting.js';
import { createCoreSeedFixture } from './conftest.js';
import { findAuditViolations } from '../src/verification/independent-audit.js';

it('settled and returned instructions have exact attributed financial effects and independent release approval', () => {
  const context=createCoreSeedFixture();
  using database=context.database;
  const refs=seedCore(context);
  seedFinancialDomains(context,refs);
  seedPaymentAccounting(context,refs);
  const payments=database.prepare('SELECT * FROM payments').all();
  expect(payments.some(row=>row.state==='returned')).toBe(true);
  for (const payment of payments) {
    const postings=database.prepare(`SELECT p.kind,l.debit_minor_units,l.credit_minor_units,j.posted_at,r.id AS receipt_id
      FROM payment_postings p JOIN journals j ON j.dataset_id=p.dataset_id AND j.id=p.journal_id
      JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id
      JOIN ledger_accounts a ON a.dataset_id=l.dataset_id AND a.id=l.ledger_account_id
      JOIN operation_receipts r ON r.dataset_id=j.dataset_id AND r.operation_id=j.operation_id
      WHERE p.payment_id=? AND a.customer_account_id=? ORDER BY p.kind`).all(payment.id ?? null,payment.source_account_id ?? null);
    expect(postings.length).toBe(payment.state==='returned' ? 2 : payment.state==='settled' ? 1 : 0);
    for (const posting of postings) {
      expect(posting.kind==='settlement' ? posting.debit_minor_units : posting.credit_minor_units).toBe(payment.amount_minor_units);
      expect(typeof posting.receipt_id).toBe('string');
    }
  }
  expect(database.prepare(`SELECT count(*) AS n FROM payments p JOIN payment_events e ON e.payment_id=p.id AND e.state='released'
    WHERE NOT EXISTS(SELECT 1 FROM business_approvals a WHERE json_extract(a.scope_json,'$.paymentId')=p.id AND a.maker_actor_id<>a.checker_actor_id AND a.status='consumed')`).get()?.n).toBe(0);
  expect(database.prepare('SELECT journal_id FROM journal_lines GROUP BY journal_id HAVING sum(debit_minor_units-credit_minor_units)<>0').all()).toEqual([]);
  expect(database.prepare('PRAGMA foreign_key_check').all()).toEqual([]);
  expect(findAuditViolations(database).some(failure=>failure.name==='payment ledger evidence')).toBe(false);
  database.exec("UPDATE payments SET amount_minor_units=amount_minor_units+1 WHERE id=(SELECT id FROM payments WHERE state='settled' LIMIT 1)");
  expect(findAuditViolations(database).some(failure=>failure.name==='payment ledger evidence')).toBe(true);
});
