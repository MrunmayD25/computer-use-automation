import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { assertRunEvidence, checkEvidenceReconstruction, closeRunEvidence, createEvidenceSlice, createRun, loadRunEvidence, replaySnapshot, selectSnapshotRows } from '../src/verification.js';
import type { VerificationRun } from '../src/verification.js';
import { createCoreSeedFixture, createTestDatabasePath } from './conftest.js';
import { digest } from '../src/verification/run-storage.js';

describe('SQLite-backed verification evidence', () => {
  let target: ReturnType<typeof createTestDatabasePath>;
  let fixture: ReturnType<typeof createCoreSeedFixture>;
  let run: VerificationRun;
  beforeEach(async () => {
    target = createTestDatabasePath();
    fixture = createCoreSeedFixture(target.path);
    fixture.database.exec(`CREATE TABLE probe (scope TEXT,id TEXT,value TEXT,bytes BLOB,amount INTEGER,PRIMARY KEY(scope,id));
      INSERT INTO probe VALUES ('a','same','before',x'616263',9007199254740993),('b','same','other',x'646566',-9007199254740993);`);
    run = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'v2' });
  });
  afterEach(() => { run.close(); fixture.database.close(); target.cleanup(); });

  it('retains a small metadata manifest and immutable baseline with authentic reopened readers', () => {
    const before = run.begin();
    run.write({ kind: 'automation', reference: 'first' }, (db) => db.exec("UPDATE probe SET value='after',bytes=x'78797a' WHERE scope='a'"));
    const evidence = run.finish();
    expect(evidence.version).toBe(2);
    expect(evidence.after.tables.probe?.rowCount).toBe(2);
    expect(evidence.after.tables.probe).not.toHaveProperty('rows');
    expect([...selectSnapshotRows(before, 'probe', { scope: 'a' })][0]?.value).toBe('before');
    expect([...selectSnapshotRows(evidence.after, 'probe', { scope: 'a' })][0]?.value).toBe('after');
    expect(checkEvidenceReconstruction(evidence)).toEqual([]);
    const reopened = loadRunEvidence(evidence.descriptor.evidencePath);
    expect(reopened).toEqual(evidence);
    expect(() => assertRunEvidence(reopened)).not.toThrow();
    expect(() => assertRunEvidence({ ...evidence })).toThrow(/authentic|registered/i);
    closeRunEvidence(reopened);
    expect(() => [...selectSnapshotRows(reopened.after, 'probe')]).toThrow(/closed/i);
  });

  it('replays PK moves and transient changes, removes stale filter matches and authenticates child slices', () => {
    const before = run.begin();
    run.write({ kind: 'automation', reference: 'first' }, (db) => db.exec("UPDATE probe SET id='moved',value='intermediate' WHERE scope='a'"));
    run.write({ kind: 'peer', reference: 'second' }, (db) => db.exec("UPDATE probe SET value='before' WHERE scope='a'"));
    const evidence = run.finish();
    const point = replaySnapshot(before, evidence.transactions.slice(0, 1), 'point');
    expect([...selectSnapshotRows(point, 'probe', { id: 'same' })].map((row) => row.scope)).toEqual(['b']);
    expect([...selectSnapshotRows(point, 'probe', { value: 'before' })]).toEqual([]);
    expect([...selectSnapshotRows(point, 'probe', { id: 'moved' })][0]?.value).toBe('intermediate');
    const slice = createEvidenceSlice(evidence, before, point, evidence.transactions.slice(0, 1));
    expect(() => assertRunEvidence(slice)).not.toThrow();
    expect(checkEvidenceReconstruction(slice)).toEqual([]);
    closeRunEvidence(evidence);
    expect(() => assertRunEvidence(slice)).toThrow(/closed/i);
  });

  it('rejects a changed baseline and preserves the disposable clone', () => {
    run.begin(); const evidence = run.finish();
    const path = join(dirname(evidence.descriptor.evidencePath), 'baseline.sqlite');
    using corrupt = new DatabaseSync(path);
    expect(() => corrupt.exec("UPDATE probe SET value='corrupt' WHERE scope='a'")).toThrow(/locked/);
    closeRunEvidence(evidence);
    corrupt.exec("UPDATE probe SET value='corrupt' WHERE scope='a'");
    expect(() => loadRunEvidence(evidence.descriptor.evidencePath)).toThrow(/baseline|digest/i);
    const reportPath = join(dirname(target.path), 'report.json');
    writeFileSync(reportPath, JSON.stringify({ runId: evidence.descriptor.runId, contractDigest: 'v2' }));
    expect(() => run.dispose({ reportPath })).toThrow(/baseline|digest/i);
    expect(readFileSync(evidence.descriptor.databasePath).length).toBeGreaterThan(0);
  });

  it('preserves unique nullable composite keys and rejects duplicates at capture', () => {
    run.prepare((db) => db.exec("INSERT INTO probe VALUES (NULL,'nullable','valid',x'',1)"));
    const before = run.begin();
    expect([...selectSnapshotRows(before, 'probe', { scope: null })]).toHaveLength(1);
    expect(() => run.write({ kind: 'automation', reference: 'duplicate' }, (db) => db.exec("INSERT INTO probe VALUES (NULL,'nullable','duplicate',x'',1)"))).toThrow(/duplicate.*key/i);
    expect(run.finish().transactions).toHaveLength(0);
  });
  it('bounds no-op transactions and rolls back rejected transaction contexts', async () => {
    run.close();
    run = await createRun({ root: join(dirname(target.path), 'runs'), sourcePath: target.path, bindings: [fixture.binding], contractDigest: 'bounded', limits: { maxChanges: 1 } });
    run.begin();
    expect(() => run.write({ kind: 'automation', reference: 'rolled-back' }, () => { throw new Error('rollback'); })).toThrow('rollback');
    run.write({ kind: 'automation', reference: 'committed' }, () => undefined);
    expect(() => run.write({ kind: 'automation', reference: 'excess' }, () => undefined)).toThrow(/transaction.*limit/i);
    const evidence = run.finish();
    expect(evidence.transactions.map((transaction) => transaction.context.reference)).toEqual(['committed']);
    expect(evidence.after.sequence).toBe(0);
  });
  it('rejects a rehashed insert event whose recorded primary key differs from its row image', () => {
    run.begin();
    run.write({ kind: 'automation', reference: 'insert' }, (db) => db.exec("INSERT INTO probe VALUES ('a','inserted','new',x'',1)"));
    const evidence = run.finish();
    closeRunEvidence(evidence);
    const path = evidence.descriptor.evidencePath;
    const manifest = JSON.parse(readFileSync(path, 'utf8')) as { digest?: string; transactions: { changes: { key: { id: string } }[] }[] };
    const key = manifest.transactions[0]?.changes[0]?.key;
    if (key === undefined) throw new Error('Missing inserted key.');
    key.id = 'not-the-inserted-row';
    delete manifest.digest;
    writeFileSync(path, JSON.stringify({ ...manifest, digest: digest(manifest) }));
    expect(() => { const loaded = loadRunEvidence(path); closeRunEvidence(loaded); }).toThrow(/key/i);
  });
  it('rejects an observation slice derived from forged row images at a real transaction boundary', () => {
    const before = run.begin();
    run.write({ kind: 'automation', reference: 'real' }, (db) => db.exec("UPDATE probe SET value='real' WHERE scope='a'"));
    const evidence = run.finish();
    const forged = structuredClone(evidence.transactions);
    const transaction = forged[0];
    const change = transaction?.changes[0];
    if (transaction === undefined || change === undefined || change.after === null) throw new Error('Missing fixture change.');
    const fake = { ...transaction, changes: [{ ...change, after: { ...change.after, value: 'fabricated' } }] };
    const fabricated = replaySnapshot(before, [fake], 'fabricated');
    expect(fabricated.sequence).toBe(evidence.after.sequence);
    expect(() => createEvidenceSlice(evidence, fabricated, fabricated, [])).toThrow(/history|parent|boundary/i);
  });
  it('still authenticates retained artifacts after successful reconstruction has been reused', () => {
    run.begin(); const evidence = run.finish();
    expect(checkEvidenceReconstruction(evidence)).toEqual([]);
    expect(checkEvidenceReconstruction(evidence)).toEqual([]);
    const path = evidence.descriptor.evidencePath;
    const original = readFileSync(path, 'utf8');
    writeFileSync(path, original.replace('"contractDigest":"v2"', '"contractDigest":"changed"'));
    expect(() => assertRunEvidence(evidence)).toThrow(/digest/i);
    writeFileSync(path, original);
    expect(() => assertRunEvidence(evidence)).not.toThrow();
  });
  it.each(['transaction', 'row'] as const)('owns immutable replay data from a caller-shallow-frozen %s', (outer) => {
    const before = run.begin();
    run.write({ kind: 'automation', reference: 'real' }, (db) => db.exec("UPDATE probe SET value='real',bytes=x'78797a' WHERE scope='a'"));
    const evidence = run.finish();
    const transaction = structuredClone(evidence.transactions[0]);
    const after = transaction?.changes[0]?.after;
    const blob = after?.bytes;
    if (transaction === undefined || after === null || after === undefined || blob === null || typeof blob !== 'object' || blob.kind !== 'blob') throw new Error('Missing fixture row image.');
    Object.freeze(outer === 'transaction' ? transaction : after);
    expect(Object.isFrozen(blob)).toBe(false);
    const point = replaySnapshot(before, [transaction], 'point');
    const slice = createEvidenceSlice(evidence, point, point, []);
    expect(checkEvidenceReconstruction(slice)).toEqual([]);
    const selected = [...selectSnapshotRows(slice.after, 'probe', { scope: 'a' })][0];
    const selectedBlob = selected?.bytes;
    if (selected === undefined || selectedBlob === null || typeof selectedBlob !== 'object') throw new Error('Missing owned replay row.');
    expect(Object.isFrozen(selected)).toBe(true);
    expect(Object.isFrozen(selectedBlob)).toBe(true);
    Reflect.set(after, 'value', 'fabricated');
    Reflect.set(blob, 'digest', '0'.repeat(64));
    expect(Reflect.set(selected, 'value', 'fabricated')).toBe(false);
    expect(Reflect.set(selectedBlob, 'digest', '0'.repeat(64))).toBe(false);
    expect(selected.value).toBe('real');
    expect(selectedBlob).not.toEqual(blob);
    expect(checkEvidenceReconstruction(slice)).toEqual([]);
  });
  it('owns getter-backed replay images so their caller cannot change authenticated query results', () => {
    const before = run.begin();
    run.write({ kind: 'automation', reference: 'real' }, (db) => db.exec("UPDATE probe SET value='real' WHERE scope='a'"));
    const evidence = run.finish();
    const transaction = evidence.transactions[0];
    const change = transaction?.changes[0];
    if (transaction === undefined || change?.after === null || change?.after === undefined) throw new Error('Missing fixture row image.');
    let suppliedValue = 'real';
    const after = { ...change.after };
    Object.defineProperty(after, 'value', { enumerable: true, get: () => suppliedValue });
    const point = replaySnapshot(before, [{ ...transaction, changes: [{ ...change, after }] }], 'point');
    const slice = createEvidenceSlice(evidence, point, point, []);
    expect(checkEvidenceReconstruction(slice)).toEqual([]);
    suppliedValue = 'fabricated';
    expect([...selectSnapshotRows(slice.after, 'probe', { scope: 'a' })][0]?.value).toBe('real');
  });
  it.each([1, 2])('revokes a paused reader between overlay and baseline rows (%i additions)', (additions) => {
    run.begin();
    run.write({ kind: 'automation', reference: 'insert' }, (db) => {
      db.exec("INSERT INTO probe VALUES ('a','a','new',x'',1)");
      if (additions === 2) db.exec("INSERT INTO probe VALUES ('a','b','new',x'',1)");
    });
    const evidence = run.finish();
    const iterator = selectSnapshotRows(evidence.after, 'probe');
    const first = iterator.next();
    if (first.done) throw new Error('Missing first overlay row.');
    expect(first.value.id).toBe('a');
    closeRunEvidence(evidence);
    expect(() => iterator.next()).toThrow();
  });
});
