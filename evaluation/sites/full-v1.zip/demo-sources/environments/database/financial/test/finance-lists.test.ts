import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import type { DatasetBinding } from '../src/model.js';
import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '../src/public.js';
import { listFinanceRecords, openFinancialStore, queryFinance, type FinancialStore, type ServiceContext } from '../src/services.js';

let directory: string;
let path: string;
let binding: DatasetBinding;
let store: FinancialStore;

beforeAll(async () => {
  directory = mkdtempSync(join(tmpdir(), 'finance-lists-'));
  path = join(directory, 'financial.sqlite');
  using database = openFinancialDatabase({ path });
  const seeded = await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: 'finance-lists-test', scale: 'small' });
  const found = seeded.bindings.find((candidate) => candidate.institutionId === 'northstar');
  if (found === undefined) throw new Error('Northstar seed binding is missing.');
  binding = found;
  store = openFinancialStore({ path });
});

afterAll(() => {
  store.close();
  rmSync(directory, { recursive: true, force: true });
});

function context(actorNumber = 'OP0002'): ServiceContext {
  return { binding, actorId: `northstar-actor-${actorNumber.slice(-1)}`, reference: 'finance-lists-test' };
}

function sql<T = Record<string, unknown>>(query: string, ...parameters: (string | number | null)[]): T[] {
  using database = new DatabaseSync(path, { readOnly: true });
  return database.prepare(query).all(...parameters) as T[];
}

describe('finance record lists', () => {
  it('lists payments with business labels and scopes them to member and account', () => {
    const member = sql<{ id: string }>('SELECT a.member_id AS id FROM payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE p.dataset_id=? ORDER BY a.member_id LIMIT 1', binding.datasetId)[0];
    if (member === undefined) throw new Error('Missing member fixture.');
    const all = listFinanceRecords(store, context(), { resource: 'payment', memberId: member.id, limit: 500, offset: 0 });
    if (all.kind !== 'listed') throw new Error(JSON.stringify(all));
    const expected = sql<{ count: number }>('SELECT COUNT(*) AS count FROM payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE p.dataset_id=? AND a.member_id=?', binding.datasetId, member.id)[0]?.count;
    expect(all.total).toBe(expected);
    const first = all.items[0];
    expect(first?.label.startsWith('PM')).toBe(true);
    expect(typeof first?.status).toBe('string');
    const accountId = String(all.items[0]?.fields.accountId ?? '');
    const memberId = String(all.items[0]?.fields.memberId ?? '');
    const scoped = listFinanceRecords(store, context(), { resource: 'payment', accountId, limit: 500, offset: 0 });
    if (scoped.kind !== 'listed') throw new Error(JSON.stringify(scoped));
    expect(scoped.total).toBe(sql('SELECT COUNT(*) AS count FROM payments WHERE dataset_id=? AND source_account_id=?', binding.datasetId, accountId)[0]?.count);
    const memberScoped = listFinanceRecords(store, context(), { resource: 'payment', memberId, limit: 500, offset: 0 });
    if (memberScoped.kind !== 'listed') throw new Error(JSON.stringify(memberScoped));
    expect(memberScoped.total).toBe(sql('SELECT COUNT(*) AS count FROM payments p JOIN accounts a ON a.id=p.source_account_id WHERE p.dataset_id=? AND a.member_id=?', binding.datasetId, memberId)[0]?.count);
  });

  it('pages deterministically and filters by state and identifier fragment', () => {
    const open = listFinanceRecords(store, context(), { resource: 'suspense-item', state: 'open', limit: 500, offset: 0 });
    if (open.kind !== 'listed') throw new Error(JSON.stringify(open));
    expect(open.items.every((item) => item.status === 'open')).toBe(true);
    const member = sql<{ id: string }>('SELECT a.member_id AS id FROM payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE p.dataset_id=? ORDER BY a.member_id LIMIT 1', binding.datasetId)[0];
    if (member === undefined) throw new Error('Missing member fixture.');
    const first = listFinanceRecords(store, context(), { resource: 'payment', memberId: member.id, limit: 10, offset: 0 });
    const second = listFinanceRecords(store, context(), { resource: 'payment', memberId: member.id, limit: 10, offset: 10 });
    if (first.kind !== 'listed' || second.kind !== 'listed') throw new Error('List page rejected.');
    expect([...first.items, ...second.items].map((item) => item.id)).toEqual(
      listFinanceRecords(store, context(), { resource: 'payment', memberId: member.id, limit: 20, offset: 0 }).kind === 'listed'
        ? sql<{ id: string }>('SELECT p.id FROM payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE p.dataset_id=? AND a.member_id=? ORDER BY p.id LIMIT 20', binding.datasetId, member.id).map((row) => row.id) : []);
    const reference = String(first.items[0]?.fields.reference ?? '');
    const found = listFinanceRecords(store, context(), { resource: 'payment', memberId: member.id, query: reference, limit: 10, offset: 0 });
    if (found.kind !== 'listed') throw new Error(JSON.stringify(found));
    expect(found.items.map((item) => item.id)).toEqual([first.items[0]?.id]);
  });

  it('lists parent-scoped children and bounded calendar days', () => {
    const card = sql<{ id: string }>('SELECT id FROM cards WHERE dataset_id=? LIMIT 1', binding.datasetId)[0];
    const transactions = listFinanceRecords(store, context(), { resource: 'card-transaction', parentId: card?.id ?? '', limit: 500, offset: 0 });
    if (transactions.kind !== 'listed') throw new Error(JSON.stringify(transactions));
    expect(transactions.total).toBe(sql('SELECT COUNT(*) AS count FROM card_transactions WHERE dataset_id=? AND card_id=?', binding.datasetId, card?.id ?? '')[0]?.count);
    const days = listFinanceRecords(store, context(), { resource: 'calendar-day', dateFrom: '2026-09-14', dateThrough: '2026-09-21', limit: 20, offset: 0 });
    if (days.kind !== 'listed') throw new Error(JSON.stringify(days));
    expect(days.items.every((item) => String(item.fields.localDate) >= '2026-09-14' && String(item.fields.localDate) <= '2026-09-21')).toBe(true);
    expect(days.items.some((item) => item.fields.isBusinessDay === 1)).toBe(true);
  });

  it('maps transport scope names to the canonical parent and date filters', () => {
    const batch = sql<{ id: string }>('SELECT id FROM batches WHERE dataset_id=? ORDER BY id LIMIT 1', binding.datasetId)[0];
    if (batch === undefined) throw new Error('Missing batch fixture.');
    const items = queryFinance(store, context(), { kind: 'finance.records', resource: 'batch-item', scope: { batchId: batch.id }, limit: 50 });
    if (items.kind !== 'listed') throw new Error(JSON.stringify(items));
    expect(items.items.every((item) => item.fields.batchId === batch.id)).toBe(true);
    const sessions = queryFinance(store, context(), { kind: 'finance.records', resource: 'cash-session', scope: { businessDate: '2026-09-14' }, limit: 50 });
    if (sessions.kind !== 'listed') throw new Error(JSON.stringify(sessions));
    expect(sessions.items.every((item) => item.fields.businessDate === '2026-09-14')).toBe(true);
  });

  it('keeps direct lists bounded while the transport enforces scope policy, and rejects unknown resources and unchecked bounds', () => {
    expect(listFinanceRecords(store, context(), { resource: 'nonsense', limit: 1, offset: 0 })).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(listFinanceRecords(store, context(), { resource: 'settlement-batch', memberId: 'northstar-member-1', limit: 1, offset: 0 })).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(listFinanceRecords(store, context(), { resource: 'payment', limit: 1, offset: 0 })).toMatchObject({ kind: 'listed', limit: 1 });
    expect(queryFinance(store, context(), { kind: 'finance.records', resource: 'payment', scope: {}, limit: 1 })).toMatchObject({ kind: 'rejected', code: 'validation', field: 'scope' });
    expect(listFinanceRecords(store, context(), { resource: 'payment', limit: 501, offset: 0 })).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(listFinanceRecords(store, context(), { resource: 'payment', limit: 1, offset: -1 })).toMatchObject({ kind: 'rejected', code: 'validation' });
    expect(listFinanceRecords(store, context(), { resource: 'calendar-day', dateFrom: '2026-09-21', dateThrough: '2026-09-14', limit: 5, offset: 0 })).toMatchObject({ kind: 'rejected', code: 'validation' });
  });

  it('refuses actors without a read grant and never crosses the institution boundary', () => {
    const denied = listFinanceRecords(store, { binding, actorId: 'northstar-actor-8', reference: 'finance-lists-test' }, { resource: 'payment', limit: 1, offset: 0 });
    expect(denied.kind).toBe('rejected');
    const riverton = sql<{ id: string }>("SELECT id FROM payments WHERE dataset_id=(SELECT dataset_id FROM world_datasets WHERE institution_id='riverton') LIMIT 1")[0];
    const member = sql<{ id: string }>("SELECT id FROM members WHERE dataset_id=? AND status<>'merged' ORDER BY id LIMIT 1", binding.datasetId)[0];
    if (member === undefined) throw new Error('Missing member fixture.');
    const leaked = listFinanceRecords(store, context(), { resource: 'payment', memberId: member.id, query: riverton?.id ?? '', limit: 10, offset: 0 });
    expect(leaked.kind).toBe('listed');
    if (leaked.kind === 'listed') expect(leaked.items).toHaveLength(0);
  });
});
