import { accountTransactions, memberDetail, searchAccounts } from '@computer-use/financial-database/services';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { bindingOf, institutionNumber, startTestHost, Terminal, type TestHost } from './support.js';

/**
 * Terminal behavior for realistic data that exceeds a single field or screen: organization members,
 * restricted notes, notes longer than one editor page, values wider than their field and exact
 * reference search. Each case checks the stored effect, not only the screen.
 */
let fixture: TestHost;
let northstar: number;
let datasetId: string;

beforeEach(() => {
  fixture = startTestHost(['OP0002', 'OP0003', 'OP0001', 'OP0005']);
  northstar = institutionNumber(fixture, 'northstar');
  datasetId = bindingOf(fixture.bindings, 'northstar').datasetId;
});
afterEach(() => { fixture.close(); });

const sql = (query: string, ...params: string[]) => fixture.store.read((database) => database.prepare(query).get(datasetId, ...params));
const operationCount = (): number => fixture.store.read((database) => database.prepare('SELECT COUNT(*) AS count FROM operations').get()?.count) as number;
const fieldAt = (terminal: Terminal, row: number, column: number) => terminal.screen.fields.find((field) => field.row === row && field.column === column);

async function signedOn(operator = 'OP0002'): Promise<Terminal> {
  const terminal = await Terminal.open(fixture.host);
  await terminal.signOn(northstar, operator);
  return terminal;
}

async function openMember(terminal: Terminal, memberNumber: string): Promise<void> {
  await terminal.send('enter', [[19, 15, '1']]);
  await terminal.send('enter', [[3, 11, memberNumber]]);
  await terminal.send('enter', [[7 + terminal.listIndex(memberNumber), 1, 'S']]);
  expect(terminal.screen.screenId).toBe('THMB02');
}

function memberId(memberNumber: string): string {
  const row = sql('SELECT id FROM members WHERE dataset_id=? AND member_number=?', memberNumber);
  return typeof row?.id === 'string' ? row.id : '';
}

describe('organization members', () => {
  it('creates an organization member whose legal name is wider than its field', async () => {
    const terminal = await signedOn();
    await terminal.send('enter', [[19, 15, '2']]);
    await terminal.send('enter', [[3, 21, 'O']]);
    expect([terminal.screen.screenId, terminal.screen.cursor]).toEqual(['THMB03', { row: 5, column: 21 }]);
    const legalName = 'Harbor Light Community Kitchen Cooperative Association of Greater Lakeside';
    await terminal.send('enter', [[5, 21, legalName], [6, 21, 'NFP-20260912'], [7, 21, 'N'], [10, 21, 'office@harborlight.test']]);
    expect(terminal.screen.screenId).toBe('THMB04');
    expect(terminal.text).toContain('ORGANIZATION');
    expect(terminal.text).toMatch(/Association of Greater +\n +Lakeside/u);
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.screen.screenId).toBe('THRC01');
    expect(sql(`SELECT o.legal_name, o.organization_type, m.tax_classification FROM organizations o
      JOIN members m ON m.dataset_id=o.dataset_id AND m.party_id=o.party_id WHERE o.dataset_id=? AND o.registration_number=?`, 'NFP-20260912'))
      .toEqual({ legal_name: legalName, organization_type: 'nonprofit', tax_classification: 'tax-exempt' });
  });

  it('refuses an unknown organization type and a registration number already on file', async () => {
    const terminal = await signedOn();
    const existing = sql('SELECT registration_number FROM organizations WHERE dataset_id=? ORDER BY registration_number LIMIT 1')?.registration_number;
    const operations = operationCount();
    await terminal.send('enter', [[19, 15, '2']]);
    await terminal.send('enter', [[3, 21, 'O']]);
    await terminal.send('enter', [[5, 21, 'Duplicate Holdings'], [6, 21, 'ABC-123'], [7, 21, 'X']]);
    expect([terminal.screen.screenId, terminal.message, terminal.screen.cursor]).toEqual(['THMB03', 'ORGANIZATION TYPE MUST BE C (CORPORATION) OR N (NONPROFIT).', { row: 7, column: 21 }]);
    await terminal.send('enter', [[6, 21, typeof existing === 'string' ? existing.toLowerCase() : ''], [7, 21, 'C']]);
    expect([terminal.screen.screenId, terminal.screen.cursor]).toEqual(['THMB03', { row: 6, column: 21 }]);
    expect(fieldAt(terminal, 5, 21)?.value).toBe('Duplicate Holdings');
    expect(operationCount()).toBe(operations);
  });
});

describe('restricted notes', () => {
  it('withholds restricted notes from a viewer and shows them to case and supervisory staff', async () => {
    const servicer = await signedOn('OP0002');
    await openMember(servicer, 'NM000003');
    await servicer.send('pf5');
    await servicer.send('pf6');
    await servicer.send('enter', [[4, 21, 'R'], [6, 1, 'Fraud call-back verified with the member.']]);
    expect(servicer.screen.screenId).toBe('THMB10');
    await servicer.send('enter', [[19, 34, 'Y']]);
    expect(servicer.screen.screenId).toBe('THRC01');
    expect(sql('SELECT visibility FROM member_notes WHERE dataset_id=? AND member_id=? ORDER BY created_at DESC LIMIT 1', memberId('NM000003'))).toEqual({ visibility: 'restricted' });

    const viewer = await signedOn('OP0001');
    await openMember(viewer, 'NM000003');
    await viewer.send('pf5');
    expect(viewer.screen.screenId).toBe('THMB07');
    expect(viewer.text).not.toContain('Fraud call-back');
    expect(viewer.text).toMatch(/[1-9]\d* RESTRICTED NOTE\(S\) WITHHELD/u);

    const supervisor = await signedOn('OP0005');
    await openMember(supervisor, 'NM000003');
    await supervisor.send('pf5');
    expect(supervisor.text).toContain('Fraud call-back');
    expect(supervisor.text).not.toContain('WITHHELD');
  });
});

describe('long notes', () => {
  const sentence = 'Member explained the disputed September card charges in detail. ';

  async function noteEditor(): Promise<Terminal> {
    const terminal = await signedOn();
    await openMember(terminal, 'NM000003');
    await terminal.send('pf5');
    await terminal.send('pf6');
    expect(terminal.screen.screenId).toBe('THMB08');
    return terminal;
  }

  it('stores a note continued on a second editor page and pages the review', async () => {
    const terminal = await noteEditor();
    const first = sentence.repeat(15).trim();
    const second = sentence.repeat(13).trim();
    await terminal.send('pf8', [[6, 1, first]]);
    expect([terminal.screen.screenId, terminal.text.includes('PAGE 2 OF 2'), fieldAt(terminal, 6, 1)?.value]).toEqual(['THMB08', true, '']);
    await terminal.send('enter', [[6, 1, second]]);
    expect(terminal.screen.screenId).toBe('THMB10');
    expect(terminal.text).toMatch(/PAGE 1 OF \d/u);
    await terminal.send('pf8');
    expect(terminal.screen.screenId).toBe('THMB10');
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.screen.screenId).toBe('THRC01');
    const stored = sql('SELECT text FROM member_notes WHERE dataset_id=? AND member_id=? ORDER BY created_at DESC LIMIT 1', memberId('NM000003'));
    expect(stored).toEqual({ text: `${first} ${second}` });
    expect(`${first} ${second}`.length).toBeGreaterThan(1500);
  });

  it('continues a completely full page directly and refuses text beyond the shared limit', async () => {
    const terminal = await noteEditor();
    const full = 'a'.repeat(1119);
    await terminal.send('pf8', [[6, 1, full]]);
    await terminal.send('enter', [[6, 1, 'bc']]);
    expect(terminal.screen.screenId).toBe('THMB10');
    expect(terminal.text).toContain('1121');
    await terminal.send('pf12');
    const operations = operationCount();
    const editor = await noteEditor();
    await editor.send('pf8', [[6, 1, full]]);
    await editor.send('enter', [[6, 1, 'b'.repeat(900)]]);
    expect(editor.screen.screenId).toBe('THMB08');
    expect(editor.message).toMatch(/2000|2,000/u);
    expect(operationCount()).toBe(operations);
  });
});

describe('values wider than their field', () => {
  it('edits and stores an address line longer than the displayed field', async () => {
    const terminal = await signedOn();
    await openMember(terminal, 'NM000003');
    await terminal.send('pf4');
    expect(terminal.screen.screenId).toBe('THMB05');
    expect(fieldAt(terminal, 10, 17)).toMatchObject({ length: 40, capacity: 80 });
    const line = '1200 North Lakeshore Drive, Harbor Point Towers, Suite 4100 East';
    await expect(terminal.send('enter', [[10, 17, line.padEnd(81, 'x')]])).rejects.toMatchObject({ status: 400, code: 'invalid_field_data' });
    await terminal.send('enter', [[10, 17, line]]);
    expect(terminal.screen.screenId).toBe('THMB06');
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.screen.screenId).toBe('THRC01');
    const id = memberId('NM000003');
    const detail = fixture.store.read((database) => memberDetail(database, datasetId, id));
    expect(JSON.stringify(detail?.address)).toContain(line);
    await terminal.send('pf3');
    await terminal.send('pf4');
    expect(fieldAt(terminal, 10, 17)?.value).toBe(line);
  });
});

describe('exact reference search', () => {
  it('lists only the entry whose whole reference matches, regardless of letter case', async () => {
    const terminal = await signedOn();
    const reference = fixture.store.read((database) => {
      const account = searchAccounts(database, datasetId, { query: 'AC0000001', limit: 5, offset: 0 }).items.find((item) => item.accountNumber === 'AC0000001');
      if (account === undefined) throw new Error('No AC0000001.');
      return accountTransactions(database, datasetId, account.id, { limit: 1, offset: 0 }).items[0]?.reference ?? '';
    });
    expect(reference.length).toBeGreaterThan(3);
    await terminal.account('AC0000001', 'S');
    await terminal.send('pf5');
    expect(terminal.screen.screenId).toBe('THHI01');
    await terminal.send('enter', [[5, 67, reference.toLowerCase()]]);
    expect(terminal.message).toBe('FILTER APPLIED.');
    expect([terminal.listIndex(reference.slice(0, 14)), terminal.text]).toEqual([0, expect.stringContaining('ROWS 1-1 OF 1')]);
    await terminal.send('enter', [[5, 67, reference.slice(0, -1)]]);
    expect(terminal.text).toContain('NO ENTRIES MATCH');
  });
});
