import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore, type FinancialStore } from '@computer-use/financial-database/services';
import { inject } from 'vitest';

import { TerminalHost, type HostOptions } from '../src/server/host/host.js';
import { COLUMNS, ROWS, type Aid, type ScreenPayload } from '../src/shared/protocol.js';

export interface TestHost {
  host: TerminalHost;
  store: FinancialStore;
  bindings: readonly DatasetBinding[];
  close: () => void;
}

/** A host over a private copy of the cached template, so each test owns disposable data. */
export function startTestHost(operators: readonly string[] = ['OP0002', 'OP0003', 'OP0001']): TestHost {
  const directory = mkdtempSync(join(tmpdir(), 'terminal-host-'));
  const path = join(directory, 'financial.sqlite');
  copyFileSync(inject('templatePath'), path);
  const bindings = inject('templateBindings');
  const store = openFinancialStore({ path });
  const host = new TerminalHost({ store, bindings, operator: { actorNumbers: operators, fixed: false } });
  return { host, store, bindings, close: () => { store.close(); rmSync(directory, { recursive: true, force: true }); } };
}

export function bindingOf(bindings: readonly DatasetBinding[], institutionId: string): DatasetBinding {
  const binding = bindings.find((item) => item.institutionId === institutionId);
  if (binding === undefined) throw new Error(`No ${institutionId} binding.`);
  return binding;
}

/** Row text of a screen as the operator sees it, one string per row. */
export function rows(screen: ScreenPayload): string[] {
  const lines = Array.from({ length: ROWS }, () => '');
  for (const field of [...screen.fields].sort((a, b) => a.address - b.address)) {
    const line = lines[field.row] ?? '';
    lines[field.row] = `${line.padEnd(field.column)}${field.value}`;
  }
  return lines.map((line) => line.padEnd(COLUMNS));
}

export const textOf = (screen: ScreenPayload): string => rows(screen).join('\n');

/**
 * Drives one terminal session the way the browser does: it answers the latest screen by its
 * sequence and sends only the fields typed, addressed by row and column.
 */
export class Terminal {
  private constructor(readonly host: TerminalHost, readonly sessionId: string, public screen: ScreenPayload) {}

  static async open(host: TerminalHost): Promise<Terminal> {
    const opened = await host.open();
    return new Terminal(host, opened.sessionId, opened.screen);
  }

  get text(): string {
    return textOf(this.screen);
  }

  get message(): string {
    return this.screen.message?.text ?? '';
  }

  /** Sends an attention key with typed fields as `[row, column, value]`. */
  async send(aid: Aid, typed: readonly (readonly [number, number, string])[] = [], cursor = this.screen.cursor): Promise<ScreenPayload> {
    this.screen = await this.host.input(this.sessionId, this.message_(aid, typed, cursor));
    return this.screen;
  }

  /** Builds a transmission for the current screen without sending it. */
  message_(aid: Aid, typed: readonly (readonly [number, number, string])[], cursor = this.screen.cursor) {
    return { sequence: this.screen.sequence, aid, cursor, fields: typed.map(([row, column, value]) => ({ address: row * COLUMNS + column, value })) };
  }

  async signOn(institutionNumber: number, operator: string): Promise<void> {
    await this.send('enter', [[13, 28, String(institutionNumber)], [14, 28, operator]]);
    if (this.screen.screenId !== 'THMENU') throw new Error(`Sign-on failed: ${this.message}`);
  }

  /** Index of the list row (from row 7) whose text contains `needle`. */
  listIndex(needle: string): number {
    const index = rows(this.screen).slice(7, 19).findIndex((line) => line.includes(needle));
    if (index < 0) throw new Error(`${needle} is not listed on ${this.screen.screenId}:\n${this.text}`);
    return index;
  }

  /** Menu option 3, search one account number and act on it with a selection code. */
  async account(accountNumber: string, code: string): Promise<void> {
    await this.send('enter', [[19, 15, '3']]);
    await this.send('enter', [[4, 11, accountNumber]]);
    await this.send('enter', [[7 + this.listIndex(accountNumber), 1, code]]);
  }
}

export function institutionNumber(options: Pick<HostOptions, 'bindings'>, institutionId: string): number {
  return options.bindings.findIndex((binding) => binding.institutionId === institutionId) + 1;
}
