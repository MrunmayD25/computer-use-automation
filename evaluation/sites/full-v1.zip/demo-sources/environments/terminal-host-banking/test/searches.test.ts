import { searchCases } from '@computer-use/financial-database/services';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { bindingOf, institutionNumber, startTestHost, Terminal, type TestHost } from './support.js';

/**
 * Saved searches through the terminal: create, run, modify, share authority, privacy, stale
 * revisions and deletion, each checked against the stored definition.
 */
let fixture: TestHost;
let northstar: number;
let datasetId: string;

beforeEach(() => {
  fixture = startTestHost(['OP0002', 'OP0003', 'OP0001', 'OP0005']);
  northstar = institutionNumber(fixture, 'northstar');
  datasetId = bindingOf(fixture.bindings, 'northstar').datasetId;
});
afterEach(() => { fixture.close(); });

const sql = (query: string, ...params: string[]) => fixture.store.read((database) => database.prepare(query).get(datasetId, ...params));
const stored = (name: string) => sql('SELECT s.visibility, s.definition_json, a.actor_number FROM saved_searches s JOIN actors a ON a.dataset_id=s.dataset_id AND a.id=s.actor_id WHERE s.dataset_id=? AND s.name=?', name);
const text = (value: unknown): string => typeof value === 'string' ? value : '';

async function signedOn(operator: string): Promise<Terminal> {
  const terminal = await Terminal.open(fixture.host);
  await terminal.signOn(northstar, operator);
  await terminal.send('enter', [[19, 15, '10']]);
  expect(terminal.screen.screenId).toBe('THSS01');
  return terminal;
}

async function confirm(terminal: Terminal): Promise<void> {
  await terminal.send('enter', [[19, 34, 'Y']]);
  expect([terminal.screen.screenId, terminal.message]).toEqual(['THRC01', expect.stringContaining('PROCESSED')]);
}

const NAME = 'Open restricted work';

/** A viewer's private case search: open or waiting cases in RESTRICTED, latest due first, five at most. */
async function createSearch(terminal: Terminal): Promise<void> {
  await terminal.send('pf6');
  expect(terminal.screen.screenId).toBe('THSS03');
  await terminal.send('enter', [[3, 21, NAME], [4, 58, '5'], [8, 21, 'O W'], [9, 21, 'RESTRICTED'], [13, 21, 'due_at'], [13, 61, 'D'], [16, 21, 'case_number state queue_code summary']]);
  expect(terminal.screen.screenId).toBe('THSS04');
  await confirm(terminal);
  await terminal.send('pf3');
  expect(terminal.screen.screenId).toBe('THSS01');
}

describe('saved searches', () => {
  it('stores a private case search from terminal codes and runs it like the shared query', async () => {
    const terminal = await signedOn('OP0001');
    await createSearch(terminal);
    const restricted = text(sql("SELECT id FROM queues WHERE dataset_id=? AND code='RESTRICTED'")?.id);
    const row = stored(NAME);
    expect(row).toMatchObject({ visibility: 'private', actor_number: 'OP0001' });
    expect(JSON.parse(text(row?.definition_json))).toEqual({
      entity: 'cases', filters: { states: ['open', 'pending-customer'], queueIds: [restricted] }, sort: [{ field: 'due_at', direction: 'desc' }],
      columns: ['case_number', 'state', 'queue_code', 'summary'], maxResults: 5,
    });

    await terminal.send('enter', [[7 + terminal.listIndex(NAME), 1, 'R']]);
    expect(terminal.screen.screenId).toBe('THSS02');
    const expected = fixture.store.read((database) => searchCases(database, datasetId, { states: ['open', 'pending-customer'], queueIds: [restricted], sort: 'due', direction: 'desc', limit: 5, offset: 0 }));
    const listed = terminal.text.split('\n').slice(7, 19).map((line) => line.slice(3, 11).trim()).filter((value) => value !== '');
    expect(listed).toEqual(expected.items.map((item) => item.caseNumber));
    expect(terminal.text).toContain(`OF ${Math.min(5, expected.total)} (LIMIT 5)`);
    await terminal.send('enter', [[7, 1, 'S']]);
    expect(terminal.screen.screenId).toBe('THCS02');
  });

  it('refuses sharing without case or supervisory authority and keeps private searches private', async () => {
    const viewer = await signedOn('OP0001');
    await createSearch(viewer);
    const before = stored(NAME);
    await viewer.send('enter', [[7 + viewer.listIndex(NAME), 1, 'M']]);
    expect(viewer.screen.screenId).toBe('THSS03');
    await viewer.send('enter', [[4, 21, 'S']]);
    expect([viewer.screen.screenId, viewer.message, viewer.screen.cursor]).toEqual(['THSS03', expect.stringContaining('CASE.MANAGE OR SUPERVISE'), { row: 4, column: 21 }]);
    expect(stored(NAME)).toEqual(before);

    const servicer = await signedOn('OP0002');
    expect(servicer.text).not.toContain(NAME);
  });

  it('renames a search without rewriting its stored filters, refuses a stale revision and deletes it', async () => {
    const terminal = await signedOn('OP0001');
    await createSearch(terminal);
    const definition = text(stored(NAME)?.definition_json);
    const other = await signedOn('OP0001');
    await other.send('enter', [[7 + other.listIndex(NAME), 1, 'M']]);
    expect(other.screen.screenId).toBe('THSS03');

    await terminal.send('enter', [[7 + terminal.listIndex(NAME), 1, 'M']]);
    expect(terminal.screen.fields.find((field) => field.row === 8 && field.column === 21)?.value).toBe('O W');
    await terminal.send('enter', [[3, 21, 'Restricted queue, waiting or open']]);
    expect(terminal.screen.screenId).toBe('THSS04');
    await confirm(terminal);
    expect(stored('Restricted queue, waiting or open')).toMatchObject({ definition_json: definition });

    await other.send('enter', [[3, 21, 'Stale rename']]);
    expect([other.screen.screenId, other.message]).toEqual(['THSS03', expect.stringContaining('RECORD CHANGED BY ANOTHER USER')]);
    expect(stored('Stale rename')).toBeUndefined();

    await terminal.send('pf3');
    await terminal.send('enter', [[7 + terminal.listIndex('Restricted queue, waiting or open'), 1, 'D']]);
    expect(terminal.screen.screenId).toBe('THSS05');
    await confirm(terminal);
    expect(stored('Restricted queue, waiting or open')).toBeUndefined();
  });
});
