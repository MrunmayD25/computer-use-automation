import { describe, expect, it } from 'vitest';

import { fitCells, graphemes, graphemeWidth, hasForbiddenCharacter, padCells, textWidth } from '../src/shared/cells.js';

const ZWJ = String.fromCodePoint(0x200d);
const DEVELOPER = `\u{1F469}${ZWJ}\u{1F4BB}`;

describe('character cells', () => {
  it('segments user-perceived characters, including combining sequences and emoji joins', () => {
    expect(graphemes('Zoë')).toEqual(['Z', 'o', 'ë']);
    expect(graphemes(`${DEVELOPER}!`)).toEqual([DEVELOPER, '!']);
    expect(graphemes('')).toEqual([]);
  });

  it('gives East Asian wide, fullwidth and emoji-presentation characters two cells', () => {
    expect(graphemeWidth('A')).toBe(1);
    expect(graphemeWidth('é')).toBe(1);
    expect(graphemeWidth('ë')).toBe(1);
    expect(graphemeWidth('©')).toBe(1);
    expect(graphemeWidth(`©${String.fromCodePoint(0xfe0f)}`)).toBe(2);
    expect(graphemeWidth('李')).toBe(2);
    expect(graphemeWidth('한')).toBe(2);
    expect(graphemeWidth('Ａ')).toBe(2);
    expect(graphemeWidth(DEVELOPER)).toBe(2);
    expect(graphemeWidth('\u{1F1FA}\u{1F1F8}')).toBe(2);
    expect(textWidth("José O'Connor-李")).toBe(16);
  });

  it('fits text into a cell budget with a visible truncation marker and never splits a wide character', () => {
    expect(fitCells('Cameron Díaz', 20)).toEqual({ text: 'Cameron Díaz', truncated: false });
    expect(fitCells('Alexandria Montgomery-Smith', 10)).toEqual({ text: 'Alexandri>', truncated: true });
    expect(fitCells('李小龍', 5)).toEqual({ text: '李小>', truncated: true });
    expect(fitCells('李小龍', 4)).toEqual({ text: '李>', truncated: true });
    expect(padCells('李a', 6)).toBe('李a   ');
  });

  it('rejects control, bidirectional override and zero-width formatting characters', () => {
    expect(hasForbiddenCharacter('plain text')).toBe(false);
    expect(hasForbiddenCharacter('tab\there')).toBe(true);
    expect(hasForbiddenCharacter('line\nbreak')).toBe(true);
    expect(hasForbiddenCharacter(`${String.fromCodePoint(0x202e)}evil`)).toBe(true);
    expect(hasForbiddenCharacter(`zero${String.fromCodePoint(0x200b)}width`)).toBe(true);
    expect(hasForbiddenCharacter('Zoë')).toBe(false);
  });
});
