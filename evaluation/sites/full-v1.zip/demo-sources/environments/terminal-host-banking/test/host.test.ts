import { createHash } from 'node:crypto';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { accountDetail, listActivity, searchAccounts, verificationRunStore } from '@computer-use/financial-database/services';
import { createRun } from '@computer-use/financial-database/verification';
import { afterEach, beforeEach, describe, expect, inject, it } from 'vitest';

import { TerminalHost } from '../src/server/host/host.js';
import { bindingOf, institutionNumber, startTestHost, Terminal, type TestHost } from './support.js';

let fixture: TestHost;
let northstar: number;

beforeEach(() => {
  fixture = startTestHost();
  northstar = institutionNumber(fixture, 'northstar');
});
afterEach(() => { fixture.close(); });

function account(institutionId: string, accountNumber: string) {
  const binding = bindingOf(fixture.bindings, institutionId);
  return fixture.store.read((database) => {
    const row = searchAccounts(database, binding.datasetId, { query: accountNumber, limit: 5, offset: 0 }).items.find((item) => item.accountNumber === accountNumber);
    if (row === undefined) throw new Error(`No ${accountNumber} at ${institutionId}.`);
    const detail = accountDetail(database, binding.datasetId, row.id);
    if (detail === undefined) throw new Error('Account vanished.');
    return detail.account;
  });
}

function operationCount(): number {
  return fixture.store.read((database) => database.prepare('SELECT COUNT(*) AS count FROM operations').get()?.count) as number;
}

async function signedOn(operator = 'OP0002', institution = northstar): Promise<Terminal> {
  const terminal = await Terminal.open(fixture.host);
  await terminal.signOn(institution, operator);
  return terminal;
}

describe('sign-on and navigation', () => {
  it('signs on with a configured operator, marks ungranted functions and refuses unknown operators', async () => {
    const terminal = await Terminal.open(fixture.host);
    expect(terminal.screen.screenId).toBe('THSIGN');
    await terminal.send('enter', [[13, 28, String(northstar)], [14, 28, 'OP0008']]);
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THSIGN', 'OPERATOR OP0008 IS NOT CONFIGURED FOR THIS TERMINAL.']);
    expect(terminal.screen.fields.find((field) => field.row === 14 && field.column === 28)?.value).toBe('OP0008');
    await terminal.signOn(northstar, 'OP0001');
    expect(terminal.text).toMatch(/TX01 +CASH DEPOSIT +\* NOT GRANTED/u);
    expect(terminal.screen.operator).toBe('OP0001 Jordan Lee');
  });

  it('restores search criteria and page after returning from an inquiry', async () => {
    const terminal = await signedOn();
    await terminal.send('enter', [[19, 15, '1']]);
    await terminal.send('enter', [[3, 11, 'a']]);
    expect(terminal.text).toContain('PAGE 1 OF');
    await terminal.send('pf8');
    expect(terminal.text).toContain('PAGE 2 OF');
    const listed = terminal.text.split('\n')[7]?.slice(3, 11) ?? '';
    await terminal.send('enter', [[7, 1, 's']]);
    expect(terminal.screen.screenId).toBe('THMB02');
    expect(terminal.text).toContain(listed);
    await terminal.send('pf3');
    expect(terminal.screen.screenId).toBe('THMB01');
    expect(terminal.text).toContain('PAGE 2 OF');
    expect(terminal.screen.fields.find((field) => field.row === 3 && field.column === 11)?.value).toBe('a');
    expect(terminal.screen.fields.find((field) => field.row === 7 && field.column === 1)?.value).toBe('');
  });

  it('asks before discarding unsent entries and keeps them when the operator continues', async () => {
    const terminal = await signedOn();
    await terminal.account('AC0000001', 'D');
    await terminal.send('pf3', [[8, 21, '12.00']]);
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THTX01', 'CHANGES NOT APPLIED. PRESS F3 AGAIN TO DISCARD THEM, OR ENTER TO CONTINUE.']);
    expect(terminal.screen.fields.find((field) => field.row === 8 && field.column === 21)?.value).toBe('12.00');
    await terminal.send('pf3');
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THAC01', 'CHANGES DISCARDED. NOTHING WAS UPDATED.']);
  });

  it('discards a maintenance edit so that reopening the record shows the stored values', async () => {
    const terminal = await signedOn();
    const before = account('northstar', 'AC0000002');
    const operations = operationCount();
    await terminal.account('AC0000002', 'M');
    await terminal.send('pf3', [[7, 21, 'Never applied']]);
    await terminal.send('pf3');
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THAC01', 'CHANGES DISCARDED. NOTHING WAS UPDATED.']);
    await terminal.send('enter', [[7 + terminal.listIndex('AC0000002'), 1, 'M']]);
    expect(terminal.screen.screenId).toBe('THAC05');
    expect(terminal.screen.fields.find((field) => field.row === 7 && field.column === 21)?.value).toBe(before.nickname);
    expect([account('northstar', 'AC0000002'), operationCount()]).toEqual([before, operations]);
  });
});

describe('input ownership', () => {
  it('ignores input that answers an earlier screen', async () => {
    const terminal = await signedOn();
    const stale = terminal.message_('enter', [[19, 15, '4']]);
    await terminal.send('enter', [[19, 15, '3']]);
    expect(terminal.screen.screenId).toBe('THAC01');
    const answer = await fixture.host.input(terminal.sessionId, stale);
    expect([answer.screenId, answer.message?.severity]).toEqual(['THAC01', 'warning']);
    expect(answer.message?.text).toContain('INPUT IGNORED');
  });

  it('commits once when the process key is sent twice while the host is responding', async () => {
    const terminal = await signedOn();
    const before = account('northstar', 'AC0000001');
    await terminal.account('AC0000001', 'D');
    await terminal.send('enter', [[8, 21, '25.10'], [9, 21, 'Branch cash']]);
    expect(terminal.screen.screenId).toBe('THTX04');
    expect(terminal.text).toContain('REVIEW. NOTHING HAS BEEN POSTED OR CHANGED YET.');
    const operations = operationCount();
    const confirm = terminal.message_('enter', [[19, 34, 'Y']]);
    const [first, second] = await Promise.all([fixture.host.input(terminal.sessionId, confirm), fixture.host.input(terminal.sessionId, confirm)]);
    expect(first.screenId).toBe('THRC01');
    expect([second.screenId, second.message?.text.startsWith('INPUT IGNORED')]).toEqual(['THRC01', true]);
    expect(operationCount()).toBe(operations + 1);
    const after = account('northstar', 'AC0000001');
    expect(after.postedMinorUnits - before.postedMinorUnits).toBe(2510);
    const receipt = /RCP\d{8}/u.exec(first.message?.text ?? '')?.[0];
    expect(receipt).toBeDefined();
    const binding = bindingOf(fixture.bindings, 'northstar');
    const events = fixture.store.read((database) => listActivity(database, binding.datasetId, { accountId: after.id, limit: 5, offset: 0 }).items);
    const receipted = events.filter((event) => event.receiptNumber === receipt);
    expect(new Set(receipted.map((event) => event.operationId)).size).toBe(1);
    expect(new Set(receipted.map((event) => `${event.kind} ${event.actor?.actorNumber ?? ''}`))).toEqual(new Set(['cash.deposit OP0002']));
  });
});

describe('validation and rejection', () => {
  it('keeps entries, explains the problem and places the cursor on the field', async () => {
    const terminal = await signedOn();
    await terminal.account('AC0000001', 'W');
    await terminal.send('enter', [[8, 21, '1.234'], [9, 21, 'Too precise']]);
    expect([terminal.screen.screenId, terminal.screen.cursor]).toEqual(['THTX02', { row: 8, column: 21 }]);
    expect(terminal.message).toMatch(/DECIMAL/u);
    expect(terminal.screen.fields.find((field) => field.row === 9 && field.column === 21)?.value).toBe('Too precise');
    const operations = operationCount();
    await terminal.send('enter', [[8, 21, '20000.00']]);
    expect(terminal.screen.screenId).toBe('THTX02');
    expect(terminal.message).toMatch(/INSUFFICIENT|AVAILABLE/u);
    expect(terminal.screen.cursor).toEqual({ row: 8, column: 21 });
    expect(operationCount()).toBe(operations);
  });

  it('refuses field data that does not fit the field definition', async () => {
    const terminal = await signedOn();
    await terminal.account('AC0000001', 'D');
    await expect(terminal.send('enter', [[8, 21, 'ten dollars']])).rejects.toMatchObject({ status: 400, code: 'invalid_field_data' });
    await expect(terminal.send('enter', [[2, 0, 'x']])).rejects.toMatchObject({ status: 400, code: 'invalid_field' });
  });

  it('keeps none of a transmission when one of its fields is refused', async () => {
    const terminal = await signedOn();
    await terminal.account('AC0000001', 'D');
    await expect(terminal.send('enter', [[9, 21, 'Kept?'], [8, 21, 'ten dollars']])).rejects.toMatchObject({ code: 'invalid_field_data' });
    await terminal.send('pf3');
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THAC01', '']);
  });
});

describe('version conflicts', () => {
  it('shows current values after another operator commits and keeps the unsent draft', async () => {
    const first = await signedOn();
    const second = await signedOn();
    const original = account('northstar', 'AC0000002');
    await first.account('AC0000002', 'M');
    await second.account('AC0000002', 'M');
    const other = original.statementDelivery === 'paper' ? 'E' : 'P';
    await second.send('enter', [[9, 21, other]]);
    await second.send('enter', [[19, 34, 'Y']]);
    expect(second.screen.screenId).toBe('THRC01');

    await first.send('enter', [[7, 21, 'Rainy day']]);
    expect([first.screen.screenId, first.message]).toEqual(['THAC05', 'RECORD CHANGED BY ANOTHER USER. CURRENT VALUES SHOWN; YOUR ENTRIES ARE KEPT.']);
    expect(first.screen.fields.find((field) => field.row === 7 && field.column === 21)?.value).toBe('Rainy day');
    expect(first.screen.fields.find((field) => field.row === 9 && field.column === 21)?.value).toBe(other);
    expect(first.text).toContain(`NOW: ${original.nickname}`);
    await first.send('enter');
    expect(first.screen.screenId).toBe('THAC06');
    await first.send('enter', [[19, 34, 'Y']]);
    expect(first.screen.screenId).toBe('THRC01');
    const after = account('northstar', 'AC0000002');
    expect([after.nickname, after.statementDelivery, after.version]).toEqual(['Rainy day', other === 'P' ? 'paper' : 'electronic', original.version + 2]);
  });
});

describe('institution isolation', () => {
  it('resolves duplicate business numbers only within the signed-on institution', async () => {
    const riverton = institutionNumber(fixture, 'riverton');
    const theirs = account('riverton', 'AC0000001');
    const ours = account('northstar', 'AC0000001');
    expect(theirs.id).not.toBe(ours.id);
    const terminal = await signedOn('OP0002', riverton);
    await terminal.account('AC0000001', 'S');
    expect(terminal.screen.screenId).toBe('THAC02');
    expect(terminal.text).toContain(theirs.ownerName);
    expect(terminal.text).toContain(theirs.memberNumber);
    expect(terminal.screen.institution).not.toBe(null);
    await terminal.send('pf10');
    await terminal.send('enter', [[8, 21, '1.00'], [9, 21, 'Riverton only']]);
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.screen.screenId).toBe('THRC01');
    expect(account('northstar', 'AC0000001')).toEqual(ours);
    expect(account('riverton', 'AC0000001').postedMinorUnits).toBe(theirs.postedMinorUnits + 100);
  });
});

describe('statements and exports', () => {
  it('offers stored document bytes with their recorded digest and a generated CSV', async () => {
    const terminal = await signedOn();
    await terminal.account('AC0000001', 'T');
    expect(terminal.screen.screenId).toBe('THST01');
    const index = terminal.listIndex('STORED');
    await terminal.send('enter', [[7 + index, 1, 'D']]);
    const offer = terminal.screen.transfer;
    expect(offer).not.toBe(null);
    if (offer === null) return;
    const file = fixture.host.transfer(terminal.sessionId, offer.url.split('/').at(-1) ?? '');
    expect(file).toBeDefined();
    if (file === undefined) return;
    expect(createHash('sha256').update(file.bytes).digest('hex')).toBe(offer.digest);
    expect(offer.fileName).toMatch(/^northstar-.*-v\d+\.(pdf|csv)$/u);
    expect(file.bytes.byteLength).toBe(offer.byteLength);

    await terminal.send('pf5');
    expect(terminal.screen.screenId).toBe('THEX01');
    await terminal.send('enter', [[5, 21, '2026-08-01'], [6, 21, '2026-09-01']]);
    const csvOffer = terminal.screen.transfer;
    if (csvOffer === null) throw new Error(`No CSV offered: ${terminal.message}`);
    const csv = fixture.host.transfer(terminal.sessionId, csvOffer.url.split('/').at(-1) ?? '');
    const text = new TextDecoder().decode(csv?.bytes);
    expect(text.split('\n')[0]).toContain('member_number,account_number,currency,effective_date');
    expect(text).toContain('AC0000001');
    expect(csvOffer.fileName).toBe('northstar-AC0000001-transactions-2026-08-01_2026-09-01.csv');
  });

  it('generates a ledger period PDF from the statement view', async () => {
    const terminal = await signedOn();
    await terminal.account('AC0000001', 'T');
    await terminal.send('enter', [[7 + terminal.listIndex('LEDGER'), 1, 'V']]);
    expect(terminal.screen.screenId).toBe('THST02');
    await terminal.send('pf9');
    const offer = terminal.screen.transfer;
    if (offer === null) throw new Error(terminal.message);
    const file = fixture.host.transfer(terminal.sessionId, offer.url.split('/').at(-1) ?? '');
    expect(new TextDecoder().decode(file?.bytes.slice(0, 5))).toBe('%PDF-');
  });
});

describe('evaluator-owned verification runs', () => {
  it('writes through the run with the backend operator and leaves the run open after the session closes', async () => {
    const root = mkdtempSync(join(tmpdir(), 'terminal-host-run-'));
    const binding = bindingOf(fixture.bindings, 'northstar');
    const run = await createRun({ root, sourcePath: inject('templatePath'), bindings: [binding], contractDigest: 'b'.repeat(64) });
    try {
      run.begin();
      const host = new TerminalHost({ store: verificationRunStore(run), bindings: [binding], operator: { actorNumbers: ['OP0002'], fixed: true }, principalKind: 'automation' });
      const terminal = await Terminal.open(host);
      expect(terminal.screen.fields.some((field) => field.row === 14 && field.column === 28 && !field.protected)).toBe(false);
      await terminal.send('enter');
      expect([terminal.screen.screenId, terminal.screen.operator]).toEqual(['THMENU', 'OP0002 Casey Patel']);
      await terminal.account('AC0000001', 'M');
      await terminal.send('enter', [[7, 21, 'Evaluator nickname']]);
      await terminal.send('enter', [[19, 34, 'Y']]);
      expect(terminal.screen.screenId).toBe('THRC01');
      expect(host.close(terminal.sessionId)).toBe(true);

      expect(run.read((database) => database.prepare("SELECT nickname FROM accounts WHERE dataset_id=? AND account_number='AC0000001'").get(binding.datasetId))).toEqual({ nickname: 'Evaluator nickname' });
      const evidence = run.finish();
      expect(evidence.transactions.map((transaction) => [transaction.context.kind, transaction.context.actorId, transaction.changes.map((change) => `${change.operation}:${change.table}`)])).toEqual([
        ['automation', 'northstar-actor-2', ['insert:operations', 'insert:operation_receipts', 'update:accounts', 'insert:business_events']],
      ]);
    } finally {
      run.close();
      rmSync(root, { recursive: true, force: true });
    }
  });
});
