import { memberDetail } from '@computer-use/financial-database/services';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { bindingOf, institutionNumber, startTestHost, Terminal, type TestHost } from './support.js';

/**
 * Visits every screen with real data and commits the member and account maintenance functions.
 * Rendering is where layout faults surface, so every screen code and help topic must render here.
 */
const ALL_SCREENS = [
  'THSIGN', 'THMENU', 'THHELP', 'THMB01', 'THMB02', 'THMB03', 'THMB04', 'THMB05', 'THMB06', 'THMB07', 'THMB08', 'THMB09', 'THMB10',
  'THAC01', 'THAC02', 'THAC03', 'THAC04', 'THAC05', 'THAC06', 'THAC07', 'THAC08', 'THTX01', 'THTX02', 'THTX03', 'THTX04',
  'THRC01', 'THRC02', 'THHI01', 'THHI02', 'THST01', 'THST02', 'THEX01', 'THAV01', 'THAV02',
  'THCS01', 'THCS02', 'THCS03', 'THCS04', 'THCS05', 'THCS07', 'THCS09', 'THCS11', 'THCS12', 'THCS13', 'THCS14',
];

let fixture: TestHost;
beforeEach(() => { fixture = startTestHost(); });
afterEach(() => { fixture.close(); });

class Tour {
  readonly visited = new Set<string>();

  constructor(readonly terminal: Terminal) {
    this.visited.add(terminal.screen.screenId);
  }

  /** Sends a key, expects a screen, and checks that screen's help renders and returns to it. */
  async go(aid: Parameters<Terminal['send']>[0], typed: Parameters<Terminal['send']>[1], screenId: string): Promise<void> {
    await this.terminal.send(aid, typed);
    expect(this.terminal.screen.screenId, `${screenId}: ${this.terminal.message}`).toBe(screenId);
    if (this.visited.has(screenId)) return;
    this.visited.add(screenId);
    const sequence = this.terminal.screen.sequence;
    await this.terminal.send('pf1');
    expect(this.terminal.screen.screenId).toBe('THHELP');
    this.visited.add('THHELP');
    await this.terminal.send('pf8');
    await this.terminal.send('pf3');
    expect(this.terminal.screen.screenId).toBe(screenId);
    expect(this.terminal.screen.sequence).toBeGreaterThan(sequence);
  }

  async toMenu(): Promise<void> {
    for (let step = 0; step < 12 && this.terminal.screen.screenId !== 'THMENU'; step += 1) await this.terminal.send('pf3');
    expect(this.terminal.screen.screenId).toBe('THMENU');
  }

  row(needle: string): number {
    return 7 + this.terminal.listIndex(needle);
  }
}

describe('screen tour', () => {
  it('renders every screen and commits member and account maintenance', async () => {
    const datasetId = bindingOf(fixture.bindings, 'northstar').datasetId;
    const sql = (query: string, ...params: (string | number)[]) => fixture.store.read((database) => database.prepare(query).get(datasetId, ...params));
    const text = (value: unknown): string => typeof value === 'string' ? value : '';
    const terminal = await Terminal.open(fixture.host);
    const tour = new Tour(terminal);
    await tour.go('enter', [[13, 28, String(institutionNumber(fixture, 'northstar'))], [14, 28, 'OP0002']], 'THMENU');

    // T002 contact maintenance and T003 notes, from a member inquiry.
    await tour.go('enter', [[19, 15, '1']], 'THMB01');
    await tour.go('enter', [[3, 11, 'NM000003']], 'THMB01');
    await tour.go('enter', [[tour.row('NM000003'), 1, 'S']], 'THMB02');
    await tour.go('pf8', [], 'THMB02');
    await tour.go('pf4', [], 'THMB05');
    await tour.go('enter', [[8, 17, '+13125550199']], 'THMB06');
    await tour.go('enter', [[19, 34, 'Y']], 'THRC01');
    await tour.go('pf3', [], 'THMB02');
    await tour.go('pf5', [], 'THMB07');
    await tour.go('pf6', [], 'THMB08');
    await tour.go('enter', [[6, 1, 'Called about the September statement. Mailed a copy.']], 'THMB10');
    await tour.go('enter', [[19, 34, 'Y']], 'THRC01');
    await tour.go('pf3', [], 'THMB07');
    await tour.go('enter', [[tour.row('Called about'), 1, 'S']], 'THMB09');
    expect(terminal.text).toContain('Mailed a copy.');
    await tour.go('pf3', [], 'THMB07');
    const memberId = text(sql("SELECT id FROM members WHERE dataset_id=? AND member_number='NM000003'")?.id);
    expect(fixture.store.read((database) => memberDetail(database, datasetId, memberId)?.phone?.value)).toBe('+13125550199');
    expect(sql('SELECT text FROM member_notes WHERE dataset_id=? AND member_id=? ORDER BY created_at DESC LIMIT 1', memberId)).toEqual({ text: 'Called about the September statement. Mailed a copy.' });

    // T004 account opening from the member's account list.
    await tour.go('pf3', [], 'THMB02');
    await tour.go('pf6', [], 'THAC01');
    await tour.go('pf10', [], 'THAC03');
    await tour.go('enter', [[17, 21, '1'], [18, 21, 'Tour savings'], [19, 21, 'E']], 'THAC03');
    expect(terminal.message).toContain('CONSENT');
    await tour.go('enter', [[19, 21, 'P']], 'THAC04');
    await tour.go('enter', [[19, 34, 'Y']], 'THRC01');
    expect(sql("SELECT status, nickname FROM accounts WHERE dataset_id=? AND nickname='Tour savings'")).toEqual({ status: 'open', nickname: 'Tour savings' });

    // T001 member creation, then opening the new record from its receipt.
    await tour.toMenu();
    await tour.go('enter', [[19, 15, '2']], 'THMB03');
    await tour.go('enter', [[5, 21, 'Ada'], [6, 21, 'Lovelace'], [8, 21, '1990-12-10'], [10, 21, 'ada@example.test']], 'THMB04');
    await tour.go('enter', [[19, 34, 'Y']], 'THRC01');
    await tour.go('enter', [[9, 1, 'S']], 'THMB02');
    expect(terminal.text).toContain('Ada Lovelace');

    // T005 nickname maintenance and T007 closure of an eligible zero-balance account.
    await tour.toMenu();
    await tour.go('enter', [[19, 15, '3']], 'THAC01');
    await tour.go('enter', [[4, 11, 'AC0000002']], 'THAC01');
    await tour.go('enter', [[tour.row('AC0000002'), 1, 'M']], 'THAC05');
    await tour.go('enter', [[7, 21, 'Household bills']], 'THAC06');
    await tour.go('enter', [[19, 34, 'Y']], 'THRC01');
    await tour.toMenu();
    await tour.go('enter', [[19, 15, '3']], 'THAC01');
    await tour.go('enter', [[4, 11, 'AC0000158']], 'THAC01');
    await tour.go('enter', [[tour.row('AC0000158'), 1, 'C']], 'THAC07');
    await tour.go('enter', [[16, 21, 'Customer request']], 'THAC08');
    await tour.go('enter', [[19, 34, 'Y']], 'THRC01');
    expect(sql("SELECT status FROM accounts WHERE dataset_id=? AND account_number='AC0000158'")).toEqual({ status: 'closed' });

    // Inquiry, history, statements, export and activity.
    await tour.toMenu();
    await terminal.account('AC0000001', 'S');
    await tour.go('pf8', [], 'THAC02');
    await tour.go('pf5', [], 'THHI01');
    await tour.go('enter', [[7, 1, 'S']], 'THHI02');
    await tour.go('pf3', [], 'THHI01');
    await tour.go('enter', [[4, 77, 'X']], 'THHI01');
    expect([terminal.message, terminal.screen.cursor]).toEqual(['STATUS MUST BE P (POSTED), R (REVERSED) OR BLANK.', { row: 4, column: 77 }]);
    await tour.go('enter', [[4, 7, '2026-08-01'], [4, 30, '2026-09-01'], [4, 51, 'D'], [4, 77, 'P']], 'THHI01');
    expect(terminal.message).toBe('FILTER APPLIED.');
    expect(terminal.text).not.toContain('NO ENTRIES MATCH');
    await tour.go('pf6', [], 'THST01');
    await tour.go('enter', [[tour.row('LEDGER'), 1, 'V']], 'THST02');
    await tour.go('pf3', [], 'THST01');
    await tour.go('pf5', [], 'THEX01');
    await tour.go('enter', [], 'THEX01');
    expect(terminal.screen.transfer?.fileName).toBe('northstar-AC0000001-transactions-start_now.csv');
    await tour.toMenu();
    await tour.go('enter', [[19, 15, '7']], 'THAV01');
    await tour.go('enter', [[4, 13, 'account.close']], 'THAV01');
    await tour.go('enter', [[7, 1, 'E']], 'THAV02');
    expect(terminal.text).toContain('account.close');
    await tour.go('pf6', [], 'THAC02');
    expect(terminal.text).toContain('AC0000158');

    // Money entry screens and receipt lookup render without committing anything.
    await tour.toMenu();
    await tour.go('enter', [[19, 15, '4']], 'THTX01');
    await tour.go('pf3', [], 'THMENU');
    await tour.go('enter', [[19, 15, '5']], 'THTX02');
    await tour.go('pf3', [], 'THMENU');
    await tour.go('enter', [[19, 15, '6']], 'THTX03');
    await tour.go('enter', [[3, 21, 'AC0000001'], [7, 21, 'AC0000002'], [11, 21, '1.00'], [12, 21, 'Tour transfer']], 'THTX04');
    await tour.go('enter', [[19, 34, 'Y']], 'THTX03');
    expect(terminal.message).toBe('THE OPERATOR LACKS THE TRANSFER.INTERNAL PERMISSION REQUIRED FOR THIS ACTION.');
    await tour.go('pf12', [], 'THTX03');
    await tour.go('pf12', [], 'THMENU');
    await tour.go('enter', [[19, 15, '5']], 'THTX02');
    await tour.go('enter', [[3, 21, 'AC0000001'], [8, 21, '2.00'], [9, 21, 'Tour withdrawal']], 'THTX04');
    await tour.go('enter', [[19, 34, 'N']], 'THTX02');
    await tour.go('pf3', [], 'THTX02');
    await tour.go('pf3', [], 'THMENU');
    const receiptNumber = text(sql('SELECT receipt_number FROM operation_receipts WHERE dataset_id=? ORDER BY committed_at DESC, receipt_number DESC LIMIT 1')?.receipt_number);
    await tour.go('enter', [[19, 15, '8']], 'THRC02');
    await tour.go('enter', [[3, 21, receiptNumber]], 'THRC01');

    // Case work: the queue, inquiry pages, case notes and each maintenance screen.
    await tour.toMenu();
    await tour.go('enter', [[19, 15, '9']], 'THCS01');
    await tour.go('enter', [[3, 9, 'CS000003']], 'THCS01');
    await tour.go('enter', [[tour.row('CS000003'), 1, 'S']], 'THCS02');
    await tour.go('pf8', [], 'THCS02');
    expect(terminal.text).toContain('TIMELINE');
    await tour.go('pf5', [], 'THCS11');
    await tour.go('pf6', [], 'THCS12');
    await tour.go('enter', [[6, 1, 'Tour case note.']], 'THCS14');
    await tour.go('enter', [[19, 34, 'Y']], 'THRC01');
    await tour.go('pf3', [], 'THCS11');
    await tour.go('enter', [[tour.row('Tour case note.'), 1, 'S']], 'THCS13');
    await tour.go('pf3', [], 'THCS11');
    await tour.go('pf3', [], 'THCS02');
    await tour.go('pf4', [], 'THCS05');
    await tour.go('pf3', [], 'THCS02');
    await tour.go('pf6', [], 'THCS07');
    await tour.go('pf3', [], 'THCS02');
    await tour.go('pf9', [], 'THCS09');
    await tour.go('pf3', [], 'THCS02');
    await tour.go('pf3', [], 'THCS01');
    await tour.go('pf6', [], 'THCS03');
    await tour.go('enter', [[3, 21, 'NM000009'], [6, 21, 'GENERAL'], [8, 21, 'complaint'], [10, 21, '2026-09-30'], [13, 1, 'Tour case']], 'THCS04');
    await tour.go('enter', [[19, 34, 'N']], 'THCS03');

    expect(ALL_SCREENS.filter((screenId) => !tour.visited.has(screenId))).toEqual([]);
  });
});
