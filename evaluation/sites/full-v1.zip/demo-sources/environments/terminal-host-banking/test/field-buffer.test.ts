import { describe, expect, it } from 'vitest';

import { FieldBuffer } from '../src/client/field-buffer.js';
import { COLUMNS, type ScreenPayload, type WireField } from '../src/shared/protocol.js';

interface Spec { row: number; column: number; length: number; capacity?: number; value?: string; protected?: boolean; numeric?: boolean }

function screen(specs: readonly Spec[], cursor = { row: 2, column: 10 }): ScreenPayload {
  const fields: WireField[] = specs.map((spec) => ({
    address: spec.row * COLUMNS + spec.column, row: spec.row, column: spec.column, length: spec.length, capacity: spec.capacity ?? spec.length,
    protected: spec.protected ?? false, numeric: spec.numeric ?? false, tone: spec.protected === true ? 'label' : 'input', value: spec.value ?? '',
  }));
  return { sequence: 1, screenId: 'TEST', title: 'Test', fields, cursor, message: null, institution: null, operator: null, transfer: null };
}

/** Label at 2:0, name input at 2:10 (8 cells), amount at 3:10 (6 numeric), code at 4:10 (3). */
function form(values: { name?: string; amount?: string; code?: string } = {}): FieldBuffer {
  const buffer = new FieldBuffer();
  buffer.load(screen([
    { row: 2, column: 0, length: 6, value: 'Name', protected: true },
    { row: 2, column: 10, length: 8, value: values.name ?? '' },
    { row: 3, column: 10, length: 6, value: values.amount ?? '', numeric: true },
    { row: 4, column: 10, length: 3, value: values.code ?? '' },
  ]));
  return buffer;
}

const at = (row: number, column: number): number => row * COLUMNS + column;
const text = (buffer: FieldBuffer, row: number, column: number): string => buffer.fieldAt(at(row, column))?.value.join('') ?? '';

describe('field buffer editing', () => {
  it('overwrites by default, inserts in insert mode and sends only modified fields without trailing blanks', () => {
    const buffer = form({ name: 'ABCD', code: 'XYZ' });
    buffer.type('ab');
    expect(text(buffer, 2, 10)).toBe('abCD');
    buffer.toggleInsert();
    buffer.type('Q');
    expect(text(buffer, 2, 10)).toBe('abQCD');
    expect(buffer.cursor).toBe(at(2, 13));
    expect(buffer.modifiedFields()).toEqual([{ address: at(2, 10), value: 'abQCD' }]);
  });

  it('pads with blanks when typing beyond the content and trims trailing blanks on send', () => {
    const buffer = form();
    buffer.moveTo(2, 13);
    buffer.type('Z');
    expect(text(buffer, 2, 10)).toBe('   Z');
    buffer.type(' ');
    expect(buffer.modifiedFields()).toEqual([{ address: at(2, 10), value: '   Z' }]);
  });

  it('locks on typing into a protected area until Reset, then accepts input again', () => {
    const buffer = form();
    buffer.moveTo(2, 2);
    buffer.type('x');
    expect(buffer.lock).toBe('protected');
    expect(text(buffer, 2, 0)).toBe('Name');
    buffer.tab();
    buffer.type('y');
    expect(buffer.cursor).toBe(at(2, 2));
    buffer.reset();
    expect(buffer.lock).toBeNull();
    buffer.tab();
    buffer.type('y');
    expect(text(buffer, 2, 10)).toBe('y');
  });

  it('rejects non-numeric characters in numeric fields with a numeric lock', () => {
    const buffer = form();
    buffer.tab();
    buffer.type('12.5');
    buffer.type('x');
    expect(buffer.lock).toBe('numeric');
    expect(text(buffer, 3, 10)).toBe('12.5');
  });

  it('auto-skips to the next input field when a field fills, but never into protected text', () => {
    const buffer = form();
    buffer.type('ABCDEFGH');
    expect(buffer.cursor).toBe(at(3, 10));
    buffer.moveTo(4, 10);
    buffer.type('XYZ');
    expect(buffer.cursor).toBe(at(2, 10));
  });

  it('refuses to insert into a full field with an overflow lock and leaves the value unchanged', () => {
    const buffer = form({ code: 'ABC' });
    buffer.moveTo(4, 11);
    buffer.toggleInsert();
    buffer.type('Q');
    expect(buffer.lock).toBe('overflow');
    expect(text(buffer, 4, 10)).toBe('ABC');
    buffer.reset();
    expect(buffer.insert).toBe(false);
  });

  it('moves between input fields with Tab and Back Tab, wrapping at the ends', () => {
    const buffer = form({ name: 'Jo' });
    buffer.moveTo(2, 12);
    buffer.backTab();
    expect(buffer.cursor).toBe(at(2, 10));
    buffer.backTab();
    expect(buffer.cursor).toBe(at(4, 10));
    buffer.tab();
    expect(buffer.cursor).toBe(at(2, 10));
    buffer.tab();
    expect(buffer.cursor).toBe(at(3, 10));
    buffer.home();
    expect(buffer.cursor).toBe(at(2, 10));
    buffer.end();
    expect(buffer.cursor).toBe(at(2, 12));
  });

  it('erases left, deletes under the cursor, erases to end of field and erases all input', () => {
    const buffer = form({ name: 'ABCDEF', amount: '100' });
    buffer.moveTo(2, 13);
    buffer.eraseLeft();
    expect(text(buffer, 2, 10)).toBe('ABDEF');
    expect(buffer.cursor).toBe(at(2, 12));
    buffer.deleteCharacter();
    expect(text(buffer, 2, 10)).toBe('ABEF');
    buffer.eraseToEnd();
    expect(text(buffer, 2, 10)).toBe('AB');
    buffer.eraseInput();
    expect([text(buffer, 2, 10), text(buffer, 3, 10), text(buffer, 4, 10)]).toEqual(['', '', '']);
    expect(buffer.modifiedFields()).toEqual([{ address: at(2, 10), value: '' }, { address: at(3, 10), value: '' }]);
    expect(buffer.cursor).toBe(at(2, 10));
  });

  it('keeps pastes inside the current field and rejects line breaks, overflow and non-numeric text whole', () => {
    const buffer = form();
    expect(buffer.paste('two\nlines')).toMatchObject({ accepted: false });
    expect(buffer.paste('far too long for it')).toMatchObject({ accepted: false });
    expect(text(buffer, 2, 10)).toBe('');
    expect(buffer.paste('ABCDEFGH')).toEqual({ accepted: true, reason: null });
    expect(text(buffer, 2, 10)).toBe('ABCDEFGH');
    expect(buffer.cursor).toBe(at(2, 17));
    expect(text(buffer, 3, 10)).toBe('');
    buffer.tab();
    expect(buffer.paste('12a')).toMatchObject({ accepted: false });
    expect(buffer.paste('125.40')).toEqual({ accepted: true, reason: null });
    buffer.moveTo(0, 0);
    expect(buffer.paste('x')).toMatchObject({ accepted: false, reason: 'Paste needs the cursor in an input field.' });
  });

  it('measures wide characters in cells, counts them against the capacity and keeps the cursor off their second cell', () => {
    const buffer = new FieldBuffer();
    buffer.load(screen([{ row: 5, column: 0, length: 5, capacity: 2, value: '' }], { row: 5, column: 0 }));
    buffer.type('李');
    expect(buffer.cursor).toBe(at(5, 2));
    buffer.type('小');
    expect(buffer.cursor).toBe(at(5, 0));
    buffer.toggleInsert();
    buffer.type('龍');
    expect(buffer.lock).toBe('overflow');
    buffer.reset();
    buffer.moveTo(5, 1);
    expect(buffer.cursor).toBe(at(5, 0));
    buffer.move('right');
    expect(buffer.cursor).toBe(at(5, 2));
    expect(buffer.cells().slice(at(5, 0), at(5, 5))).toEqual(['李', '', '小', '', ' ']);
  });

  it('pastes up to the field capacity, not merely its window, and rejects anything longer whole', () => {
    const buffer = new FieldBuffer();
    buffer.load(screen([{ row: 5, column: 10, length: 5, capacity: 12 }], { row: 5, column: 10 }));
    expect(buffer.paste('ABCDEFGHIJ')).toEqual({ accepted: true, reason: null });
    expect(buffer.modifiedFields()).toEqual([{ address: at(5, 10), value: 'ABCDEFGHIJ' }]);
    expect(buffer.paste('KLM')).toEqual({ accepted: false, reason: 'Paste rejected: the result would exceed this field\'s 12-character limit.' });
    expect(buffer.fieldAt(at(5, 10))?.value.join('')).toBe('ABCDEFGHIJ');
  });

  it('inhibits all keys while the host owns the screen and releases them on the next screen only', () => {
    const buffer = form();
    buffer.beginTransmit();
    buffer.type('late');
    buffer.tab();
    buffer.reset();
    expect(buffer.lock).toBe('system');
    expect(text(buffer, 2, 10)).toBe('');
    buffer.load(screen([{ row: 2, column: 10, length: 8 }]));
    expect(buffer.lock).toBeNull();
    expect(buffer.modifiedFields()).toEqual([]);
  });
});

describe('scrolling fields', () => {
  /** A 5-cell window onto a value of up to 12 characters at 2:10, followed by a 3-cell field at 3:10. */
  function scrolling(value = ''): FieldBuffer {
    const buffer = new FieldBuffer();
    buffer.load(screen([{ row: 2, column: 10, length: 5, capacity: 12, value }, { row: 3, column: 10, length: 3 }]));
    return buffer;
  }
  const window = (buffer: FieldBuffer): string => buffer.cells().slice(at(2, 10), at(2, 15)).join('');

  it('keeps typing past the window, scrolling so the cursor stays visible, and sends the whole value', () => {
    const buffer = scrolling();
    buffer.type('ABCDEFGH');
    expect(window(buffer)).toBe('EFGH ');
    expect(buffer.cursor).toBe(at(2, 14));
    expect(buffer.position()).toEqual({ character: 9, used: 8, capacity: 12, hiddenLeft: true, hiddenRight: false });
    expect(buffer.modifiedFields()).toEqual([{ address: at(2, 10), value: 'ABCDEFGH' }]);
  });

  it('scrolls back when the cursor moves left past the window edge and forward again on the right', () => {
    const buffer = scrolling();
    buffer.type('ABCDEFGH');
    for (let step = 0; step < 5; step += 1) buffer.move('left');
    expect([window(buffer), buffer.cursor]).toEqual(['DEFGH', at(2, 10)]);
    expect(buffer.position()).toMatchObject({ character: 4, hiddenLeft: true, hiddenRight: false });
    buffer.move('left');
    buffer.move('left');
    buffer.move('left');
    expect([window(buffer), buffer.cursor]).toEqual(['ABCDE', at(2, 10)]);
    expect(buffer.position()).toMatchObject({ character: 1, hiddenLeft: false, hiddenRight: true });
    buffer.end();
    expect([window(buffer), buffer.cursor]).toEqual(['EFGH ', at(2, 14)]);
  });

  it('opens with the start of a stored value that is longer than the window and edits it without truncation', () => {
    const buffer = scrolling('Lakeside Dr');
    expect(window(buffer)).toBe('Lakes');
    expect(buffer.position()).toMatchObject({ used: 11, capacity: 12, hiddenRight: true });
    buffer.moveTo(2, 10);
    buffer.eraseToEnd();
    buffer.type('Pier Road');
    expect(buffer.modifiedFields()).toEqual([{ address: at(2, 10), value: 'Pier Road' }]);
  });

  it('auto-skips only when the capacity is reached and locks on overflow in insert mode', () => {
    const buffer = scrolling();
    buffer.type('ABCDEFGHIJKL');
    expect(buffer.cursor).toBe(at(3, 10));
    buffer.backTab();
    expect(window(buffer)).toBe('ABCDE');
    buffer.toggleInsert();
    buffer.type('Z');
    expect(buffer.lock).toBe('overflow');
    expect(buffer.modifiedFields()).toEqual([{ address: at(2, 10), value: 'ABCDEFGHIJKL' }]);
  });

  it('wraps a field across rows, addressing its cells continuously', () => {
    const buffer = new FieldBuffer();
    buffer.load(screen([{ row: 6, column: 1, length: 158, capacity: 158 }], { row: 6, column: 1 }));
    buffer.type('x'.repeat(79));
    expect(buffer.cursor).toBe(at(7, 0));
    buffer.type('yz');
    expect(buffer.cells().slice(at(7, 0), at(7, 3))).toEqual(['y', 'z', ' ']);
    buffer.move('up');
    expect(buffer.cursor).toBe(at(6, 2));
    buffer.toggleInsert();
    buffer.type('!');
    expect(buffer.modifiedFields()).toEqual([{ address: at(6, 1), value: `x!${'x'.repeat(78)}yz` }]);
  });
});
