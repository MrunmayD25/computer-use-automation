import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { executeCommand, listApprovals, type ServiceCommand, type ServiceContext } from '@computer-use/financial-database/services';

import { bindingOf, institutionNumber, startTestHost, Terminal, type TestHost } from './support.js';

/**
 * Case work through the terminal: opening, routing, status changes, subject correction and case notes.
 * Each case checks the stored effect and that refused operations change nothing.
 */
let fixture: TestHost;
let northstar: number;
let datasetId: string;

beforeEach(() => {
  fixture = startTestHost(['OP0002', 'OP0003', 'OP0001', 'OP0005']);
  northstar = institutionNumber(fixture, 'northstar');
  datasetId = bindingOf(fixture.bindings, 'northstar').datasetId;
});
afterEach(() => { fixture.close(); });

const sql = (query: string, ...params: string[]) => fixture.store.read((database) => database.prepare(query).get(datasetId, ...params));
const operationCount = (): number => fixture.store.read((database) => database.prepare('SELECT COUNT(*) AS count FROM operations').get()?.count) as number;
const stored = (caseNumber: string) => sql(`SELECT c.id,c.state, q.code AS queue, a.account_number AS account, c.version FROM cases c JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id
  LEFT JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? AND c.case_number=?`, caseNumber);

async function signedOn(operator = 'OP0002'): Promise<Terminal> {
  const terminal = await Terminal.open(fixture.host);
  await terminal.signOn(northstar, operator);
  return terminal;
}

/** Menu option 9, filter on one case number and act on it with a selection code. */
async function onCase(terminal: Terminal, caseNumber: string, code: string, screenId: string): Promise<void> {
  await terminal.send('enter', [[19, 15, '9']]);
  expect(terminal.screen.screenId).toBe('THCS01');
  await terminal.send('enter', [[3, 9, caseNumber]]);
  await terminal.send('enter', [[7 + terminal.listIndex(caseNumber), 1, code]]);
  expect([terminal.screen.screenId, terminal.message]).toEqual([screenId, terminal.message]);
}

async function confirm(terminal: Terminal): Promise<void> {
  await terminal.send('enter', [[19, 34, 'Y']]);
  expect([terminal.screen.screenId, terminal.message]).toEqual(['THRC01', expect.stringContaining('PROCESSED')]);
}

describe('opening cases', () => {
  it('opens a case for a member with a full summary and refuses a duplicate open case', async () => {
    const terminal = await signedOn();
    await terminal.send('enter', [[19, 15, '1']]);
    await terminal.send('enter', [[3, 11, 'NM000003']]);
    await terminal.send('enter', [[7 + terminal.listIndex('NM000003'), 1, 'C']]);
    expect(terminal.screen.screenId).toBe('THCS01');
    await terminal.send('pf6');
    expect([terminal.screen.screenId, terminal.screen.fields.find((field) => field.row === 3 && field.column === 21)?.value]).toEqual(['THCS03', 'NM000003']);
    const summary = 'Member asks for a refund of three monthly maintenance fees charged after the fee waiver letter of August; copy of the letter received at the branch today.';
    const typed = [[6, 21, 'GENERAL'], [8, 21, 'fee-inquiry'], [9, 21, 'H'], [10, 21, '2026-09-30'], [13, 1, summary]] as const;
    await terminal.send('enter', typed);
    expect(terminal.screen.screenId).toBe('THCS04');
    await confirm(terminal);
    const opened = sql("SELECT case_number, category, priority, summary FROM cases WHERE dataset_id=? AND category='fee-inquiry' ORDER BY case_number DESC LIMIT 1");
    expect(opened).toMatchObject({ category: 'fee-inquiry', priority: 'high', summary });
    await terminal.send('enter', [[9, 1, 'S']]);
    expect([terminal.screen.screenId, terminal.text.includes(typeof opened?.case_number === 'string' ? opened.case_number : '?')]).toEqual(['THCS02', true]);

    const operations = operationCount();
    await terminal.send('pf3');
    await terminal.send('pf3');
    await terminal.send('pf6');
    await terminal.send('enter', typed);
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THCS03', expect.stringMatching(/ALREADY OPEN/u)]);
    expect(operationCount()).toBe(operations);
  });

  it('allows read-only review but refuses a viewer commit', async () => {
    const terminal = await signedOn('OP0001');
    const operations = operationCount();
    await onCase(terminal, 'CS000003', 'S', 'THCS02');
    await terminal.send('pf3');
    await terminal.send('pf6');
    await terminal.send('enter', [[3, 21, 'NM000003'], [6, 21, 'GENERAL'], [8, 21, 'complaint'], [10, 21, '2026-09-30'], [13, 1, 'Viewer attempt']]);
    expect(terminal.screen.screenId).toBe('THCS04');
    expect(operationCount()).toBe(operations);
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THCS03', expect.stringMatching(/CASE\.MANAGE|NOT AUTHORIZED|LACKS/u)]);
    expect(operationCount()).toBe(operations);
  });
});

describe('routing', () => {
  it('refuses a servicer widening a restricted case and lets a supervisor route it', async () => {
    const before = stored('CS000008');
    expect(before).toMatchObject({ queue: 'RESTRICTED' });
    const servicer = await signedOn('OP0002');
    await onCase(servicer, 'CS000008', 'R', 'THCS05');
    await servicer.send('enter', [[7, 21, 'GENERAL'], [13, 1, 'Customer asked for general servicing follow-up']]);
    expect([servicer.screen.screenId, servicer.message, servicer.screen.cursor]).toEqual(['THCS05', expect.stringContaining('REQUIRES THE SUPERVISE PERMISSION'), { row: 7, column: 21 }]);
    expect(servicer.text.split('\n')[21]).toMatch(/^MOVING A CASE FROM RESTRICTED .*\(F1 MORE\)$/u);
    await servicer.send('pf1');
    expect(servicer.text.replace(/\s+/gu, ' ')).toContain('WIDENS WHO WORKS IT AND REQUIRES THE SUPERVISE PERMISSION.');
    await servicer.send('pf3');
    expect([servicer.screen.screenId, servicer.screen.fields.find((field) => field.row === 7 && field.column === 21)?.value]).toEqual(['THCS05', 'GENERAL']);
    expect(stored('CS000008')).toEqual(before);

    const supervisor = await signedOn('OP0005');
    await onCase(supervisor, 'CS000008', 'R', 'THCS05');
    await supervisor.send('enter', [[7, 21, 'GENERAL'], [13, 1, 'Evidence review finished; general team completes the follow-up']]);
    expect(supervisor.screen.screenId).toBe('THCS06');
    await confirm(supervisor);
    expect(stored('CS000008')).toMatchObject({ queue: 'GENERAL', version: Number(before?.version) + 1 });
  });
});

describe('status changes', () => {
  it('resolves, refuses closure while a work item is open, and reopens a closed case with its history kept', async () => {
    const terminal = await signedOn();
    await onCase(terminal, 'CS000001', 'T', 'THCS07');
    await terminal.send('enter', [[7, 21, 'R'], [13, 1, 'Statement copy mailed to the member']]);
    expect(terminal.screen.screenId).toBe('THCS08');
    await confirm(terminal);
    expect(stored('CS000001')).toMatchObject({ state: 'resolved' });

    const operations = operationCount();
    await terminal.send('pf3');
    await terminal.send('enter', [[7, 1, 'T']]);
    await terminal.send('enter', [[7, 21, 'C'], [13, 1, 'Done']]);
    expect([terminal.screen.screenId, terminal.message]).toEqual(['THCS07', expect.stringContaining('OPEN DEPENDENCIES')]);
    expect([stored('CS000001'), operationCount()]).toEqual([expect.objectContaining({ state: 'resolved' }), operations]);

    const events = (): number => Number(sql('SELECT COUNT(*) AS count FROM case_events e JOIN cases c ON c.dataset_id=e.dataset_id AND c.id=e.case_id WHERE e.dataset_id=? AND c.case_number=?', 'CS000005')?.count);
    const earlier = events();
    const document = sql("SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id JOIN cases c ON c.dataset_id=m.dataset_id AND c.member_id=m.id WHERE c.dataset_id=? AND c.case_number=? AND v.status IN ('current','signed') LIMIT 1", 'CS000005');
    if (typeof document?.id !== 'string') throw new Error('Closed case requires retained member evidence.');
    const reopen = await signedOn();
    await onCase(reopen, 'CS000005', 'T', 'THCS07');
    await reopen.send('enter', [[7, 21, 'E'], [10, 21, document.id], [13, 1, 'Member disputes the closing letter; retained document requires renewed review']]);
    await confirm(reopen);
    expect(stored('CS000005')).toMatchObject({ state: 'reopened' });
    expect(events()).toBe(earlier + 1);
    expect(sql("SELECT d.kind,d.reference_id,d.state FROM case_dependencies d JOIN cases c ON c.dataset_id=d.dataset_id AND c.id=d.case_id WHERE d.dataset_id=? AND c.case_number=? AND d.kind='new-evidence'", 'CS000005')).toMatchObject({ kind: 'new-evidence', reference_id: document.id, state: 'open' });
  });
});

describe('case subject correction', () => {
  it('requires current evidence and an exact A3 approval before correcting the member and account', async () => {
    const before = stored('CS000003');
    const target = sql(`SELECT m.id AS member_id,m.member_number,a.id AS account_id,a.account_number FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
      JOIN cases c ON c.dataset_id=m.dataset_id WHERE m.dataset_id=? AND c.case_number='CS000003' AND m.id<>c.member_id AND m.status<>'merged' ORDER BY m.member_number,a.account_number LIMIT 1`);
    if (typeof target?.member_id !== 'string' || typeof target.member_number !== 'string' || typeof target.account_id !== 'string' || typeof target.account_number !== 'string') throw new Error('Case correction target is missing.');
    const evidence = sql(`SELECT v.id FROM members m JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
      JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id WHERE m.dataset_id=? AND m.id=? AND v.status IN ('current','signed') ORDER BY v.issued_at,v.id LIMIT 1`, target.member_id);
    const policy = sql('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id DESC LIMIT 1', '2026-09-14T15:00:00.000Z');
    if (typeof evidence?.id !== 'string' || typeof policy?.id !== 'string') throw new Error('Case correction prerequisites are missing.');
    const binding = bindingOf(fixture.bindings, 'northstar');
    const serviceContext = (ordinal: number): ServiceContext => ({ binding, actorId: `northstar-actor-${String(ordinal)}`, reference: 'terminal-case-subject-test' });
    if (typeof before?.id !== 'string') throw new Error('Case CS000003 is missing.');
    const command: Extract<ServiceCommand, { kind: 'case.subject.correct' }> = { kind: 'case.subject.correct', caseId: before.id, expectedVersion: Number(before.version), correctMemberId: target.member_id, correctAccountId: target.account_id, evidenceVersionId: evidence.id, approvalId: 'pending-approval' };
    const requested = executeCommand(fixture.store, serviceContext(2), { kind: 'approval.request', target: command, checkerActorId: 'northstar-actor-5', policyVersionId: policy.id, expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: null }, 'terminal-subject-request');
    if (requested.kind !== 'committed') throw new Error(JSON.stringify(requested));
    const approvalId = requested.receipt.affected.find((item) => item.kind === 'approval')?.id;
    if (approvalId === undefined) throw new Error('Approval request omitted its ID.');
    const listed = listApprovals(fixture.store, serviceContext(5));
    if (listed.kind !== 'found') throw new Error(JSON.stringify(listed));
    const approval = listed.approvals.find((item) => item.id === approvalId);
    if (approval === undefined) throw new Error('Checker cannot see the pending approval.');
    const decided = executeCommand(fixture.store, serviceContext(5), { kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Exact case, subjects, and evidence reviewed.' }, 'terminal-subject-approve');
    expect(decided.kind).toBe('committed');
    const terminal = await signedOn('OP0005');
    await onCase(terminal, 'CS000003', 'C', 'THCS09');
    expect(terminal.text).toContain('A3: POLICY');
    await terminal.send('enter', [[5, 21, target.member_number], [6, 21, target.account_number]]);
    expect([terminal.screen.screenId, terminal.message, terminal.text]).toEqual(['THCS09', expect.stringContaining('CURRENT VERSIONED EVIDENCE IS REQUIRED'), expect.stringContaining(evidence.id)]);
    await terminal.send('enter', [[7, 21, 'missing-version'], [8, 21, approvalId]]);
    expect([terminal.screen.screenId, terminal.message, terminal.screen.cursor]).toEqual(['THCS09', expect.stringContaining('OUTSIDE BOTH SUBJECT SCOPES'), { row: 5, column: 21 }]);
    expect(stored('CS000003')).toEqual(before);
    await terminal.send('enter', [[7, 21, evidence.id]]);
    expect(terminal.screen.screenId).toBe('THCS10');
    await confirm(terminal);
    expect(stored('CS000003')).toMatchObject({ account: target.account_number, version: Number(before.version) + 1 });
    expect(sql("SELECT m.member_number,q.visibility FROM cases c JOIN members m ON m.dataset_id=c.dataset_id AND m.id=c.member_id JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id WHERE c.dataset_id=? AND c.case_number='CS000003'"))
      .toMatchObject({ member_number: target.member_number, visibility: 'restricted' });
  });
});

describe('case notes', () => {
  it('adds a restricted case note that a viewer sees only as withheld', async () => {
    const servicer = await signedOn();
    await onCase(servicer, 'CS000003', 'N', 'THCS11');
    await servicer.send('pf6');
    expect(servicer.screen.screenId).toBe('THCS12');
    await servicer.send('enter', [[4, 21, 'R'], [6, 1, 'Identity documents held in the restricted evidence file.']]);
    expect(servicer.screen.screenId).toBe('THCS14');
    await confirm(servicer);
    expect(sql("SELECT n.visibility FROM case_notes n JOIN cases c ON c.dataset_id=n.dataset_id AND c.id=n.case_id WHERE n.dataset_id=? AND c.case_number=? ORDER BY n.created_at DESC LIMIT 1", 'CS000003'))
      .toEqual({ visibility: 'restricted' });

    const viewer = await signedOn('OP0001');
    await onCase(viewer, 'CS000003', 'N', 'THCS11');
    expect(viewer.text).not.toContain('Identity documents');
    expect(viewer.text).toMatch(/[1-9]\d* RESTRICTED NOTE\(S\) WITHHELD/u);
  });
});
