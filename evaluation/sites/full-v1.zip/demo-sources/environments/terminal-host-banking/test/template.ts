import { financialSeedCacheKey } from '@computer-use/financial-database/testing';
import { existsSync, mkdirSync, renameSync, rmSync } from 'node:fs';
import { join, resolve } from 'node:path';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase, type DatasetBinding } from '@computer-use/financial-database';

export const TEST_WORLD = 'terminal-host-banking-test';

/**
 * Seeds a small disposable world once under .runtime and returns it. Tests and browser
 * verification copy this file; the shared canonical database is never opened or changed.
 */
export async function ensureTemplate(): Promise<{ path: string; bindings: readonly DatasetBinding[] }> {
  const directory = resolve(import.meta.dirname, '..', '.runtime');
  const path = join(directory, `test-template-${financialSeedCacheKey()}.sqlite`);
  if (!existsSync(path)) {
    mkdirSync(directory, { recursive: true });
    const pending = join(directory, `test-template-${String(process.pid)}.sqlite`);
    rmSync(pending, { force: true });
    {
      using database = openFinancialDatabase({ path: pending });
      await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: TEST_WORLD, scale: 'small' });
    }
    renameSync(pending, path);
  }
  using database = openFinancialDatabase({ path });
  return { path, bindings: database.getNamedWorld(TEST_WORLD) };
}
