import { describe, expect, it } from 'vitest';

import { keyAction, type KeyStroke } from '../src/client/keymap.js';

const stroke = (key: string, options: Partial<KeyStroke> = {}): KeyStroke => ({ key, code: options.code ?? '', altKey: false, shiftKey: false, ctrlKey: false, metaKey: false, ...options });

describe('key map', () => {
  it('maps function keys and their browser-safe Alt alternatives to the same PF keys', () => {
    expect(keyAction(stroke('F3'))).toEqual({ kind: 'aid', aid: 'pf3' });
    expect(keyAction(stroke('F1', { shiftKey: true }))).toEqual({ kind: 'aid', aid: 'pf13' });
    expect(keyAction(stroke('F14'))).toEqual({ kind: 'aid', aid: 'pf14' });
    expect(keyAction(stroke('3', { code: 'Digit3', altKey: true }))).toEqual({ kind: 'aid', aid: 'pf3' });
    expect(keyAction(stroke('£', { code: 'Digit3', altKey: true }))).toEqual({ kind: 'aid', aid: 'pf3' });
    expect(keyAction(stroke('=', { code: 'Equal', altKey: true }))).toEqual({ kind: 'aid', aid: 'pf12' });
    expect(keyAction(stroke('!', { code: 'Digit1', altKey: true, shiftKey: true }))).toEqual({ kind: 'aid', aid: 'pf13' });
    expect(keyAction(stroke('PageDown'))).toEqual({ kind: 'aid', aid: 'pf8' });
  });

  it('maps editing, reset, clear and download keys', () => {
    expect(keyAction(stroke('Tab', { shiftKey: true }))).toEqual({ kind: 'edit', command: 'backtab' });
    expect(keyAction(stroke('Escape'))).toEqual({ kind: 'edit', command: 'reset' });
    expect(keyAction(stroke('r', { code: 'KeyR', altKey: true }))).toEqual({ kind: 'edit', command: 'reset' });
    expect(keyAction(stroke('Delete', { ctrlKey: true }))).toEqual({ kind: 'edit', command: 'erase-eof' });
    expect(keyAction(stroke('Delete', { code: 'Delete', altKey: true }))).toEqual({ kind: 'edit', command: 'erase-input' });
    expect(keyAction(stroke('Pause'))).toEqual({ kind: 'aid', aid: 'clear' });
    expect(keyAction(stroke('d', { code: 'KeyD', altKey: true }))).toEqual({ kind: 'download' });
  });

  it('leaves text, clipboard and platform shortcuts to the browser', () => {
    expect(keyAction(stroke('a'))).toBe(null);
    expect(keyAction(stroke('v', { ctrlKey: true }))).toBe(null);
    expect(keyAction(stroke('r', { metaKey: true }))).toBe(null);
    expect(keyAction(stroke('F5', { metaKey: true }))).toBe(null);
  });
});
