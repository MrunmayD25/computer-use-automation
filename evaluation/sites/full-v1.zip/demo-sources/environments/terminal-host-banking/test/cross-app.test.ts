import { execFileSync, spawn, type ChildProcess } from 'node:child_process';
import { copyFileSync, existsSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

import { openFinancialStore, searchMembers, type FinancialStore } from '@computer-use/financial-database/services';
import { afterEach, beforeEach, describe, expect, it, inject } from 'vitest';

import { TerminalHost } from '../src/server/host/host.js';
import { bindingOf, institutionNumber, Terminal } from './support.js';

/**
 * Cross-application evidence: the desktop MDI console runs as a separate OS process
 * on the same disposable database file (WAL mode) and shares every record the
 * terminal writes through the trusted services.
 */
const DESKTOP_MAIN = resolve(import.meta.dirname, '../../desktop-mdi-console/dist/server/main.js');
const DESKTOP_WORLD = 'terminal-host-banking-test';

let host: TerminalHost;
let store: FinancialStore;
let peer: ChildProcess;
let origin: string;
let databasePath: string;
let workdir: string;
let northstar: number;
let cookie: string;

beforeEach(async () => {
  if (!existsSync(DESKTOP_MAIN)) {
    execFileSync('npx', ['tsc', '-p', 'tsconfig.server.json'], { cwd: resolve(DESKTOP_MAIN, '../../../..') });
  }
  workdir = mkdtempSync(join(tmpdir(), 'terminal-cross-app-'));
  databasePath = join(workdir, 'financial.sqlite');
  copyFileSync(inject('templatePath'), databasePath);
  const bindings = inject('templateBindings');
  store = openFinancialStore({ path: databasePath });
  host = new TerminalHost({ store, bindings, operator: { actorNumbers: ['OP0001', 'OP0002', 'OP0003', 'OP0005'], fixed: false } });
  northstar = institutionNumber({ bindings }, 'northstar');
  peer = spawn('node', [DESKTOP_MAIN, '--database', databasePath, '--world', DESKTOP_WORLD, '--operators', 'OP0002', '--port', '0'], { stdio: ['ignore', 'pipe', 'pipe'] });
  origin = await new Promise<string>((resolvePromise, reject) => {
    peer.stdout?.on('data', (chunk: Buffer) => {
      const match = /listening on (http:\/\/[^\s(]+)/u.exec(chunk.toString());
      if (match !== null) resolvePromise(match[1] ?? '');
    });
    peer.once('exit', () => reject(new Error('The desktop console exited before listening.')));
    setTimeout(() => reject(new Error('The desktop console did not start within 20 seconds.')), 20_000);
  });
  const session = await fetch(`${origin}/api/session`);
  cookie = session.headers.get('set-cookie')?.split(';')[0] ?? '';
  await fetch(`${origin}/api/session/operator`, {
    method: 'POST', headers: { 'content-type': 'application/json', cookie }, body: JSON.stringify({ actorNumber: 'OP0002' }),
  });
});
afterEach(async () => {
  await new Promise<void>((done) => {
    peer.once('exit', () => done());
    peer.kill('SIGTERM');
    setTimeout(() => { peer.kill('SIGKILL'); done(); }, 5_000);
  });
  store.close();
  rmSync(workdir, { recursive: true, force: true });
});

function memberId(memberNumber: string): string {
  const binding = bindingOf(inject('templateBindings'), 'northstar');
  const hit = store.read((database) => searchMembers(database, binding.datasetId, { query: memberNumber, limit: 10, offset: 0 }).items.find((row) => row.memberNumber === memberNumber));
  if (hit === undefined) throw new Error(`No member ${memberNumber}.`);
  return hit.id;
}

describe('shared records across applications', () => {
  it('a name committed through the terminal is read by the desktop console', async () => {
    const terminal = await Terminal.open(host);
    await terminal.signOn(northstar, 'OP0002');
    await terminal.send('enter', [[19, 15, 'SV00']]);
    await terminal.send('enter', [[19, 15, 'NM02']]);
    await terminal.send('enter', [[4, 21, 'NM000002'], [5, 21, 'Peerseen'], [6, 21, 'S']]);
    expect(terminal.text).toContain('REVIEW');
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.text).toContain('RECEIPT');

    const response = await fetch(`${origin}/api/i/northstar/members/${memberId('NM000002')}`, { headers: { cookie } });
    expect(response.status).toBe(200);
    const detail = await response.json() as { person?: { preferredName: string | null } };
    expect(detail.person?.preferredName).toBe('Peerseen');
  });

  it('a note executed through the desktop console appears on the terminal', async () => {
    const id = memberId('NM000002');
    const response = await fetch(`${origin}/api/i/northstar/commands`, {
      method: 'POST', headers: { 'content-type': 'application/json', cookie },
      body: JSON.stringify({
        command: { kind: 'member.note.add', memberId: id, visibility: 'general', text: 'Cross-application note from the desktop console.' },
        idempotencyKey: 'peer-note-0000000001',
      }),
    });
    expect(response.status).toBe(200);
    const outcome = await response.json() as { kind: string };
    expect(outcome.kind).toBe('committed');

    const terminal = await Terminal.open(host);
    await terminal.signOn(northstar, 'OP0002');
    await terminal.send('enter', [[19, 15, '1']]);
    await terminal.send('enter', [[3, 11, 'NM000002']]);
    await terminal.send('enter', [[7 + terminal.listIndex('NM000002'), 1, 'S']]);
    expect(terminal.screen.screenId).toBe('THMB02');
    await terminal.send('pf5');
    expect(terminal.text).toContain('Cross-application note from the desktop console.');
  });
});
