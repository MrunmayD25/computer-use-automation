import { searchMembers, memberDetail } from '@computer-use/financial-database/services';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { bindingOf, institutionNumber, startTestHost, Terminal, type TestHost } from './support.js';

let fixture: TestHost;
let northstar: number;

beforeEach(() => {
  fixture = startTestHost(['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005']);
  northstar = institutionNumber(fixture, 'northstar');
});
afterEach(() => { fixture.close(); });

function member(institutionId: string): { memberNumber: string; id: string; displayName: string } {
  const binding = bindingOf(fixture.bindings, institutionId);
  const hit = fixture.store.read((database) => searchMembers(database, binding.datasetId, { query: '', limit: 5, offset: 0 }).items[0]);
  if (hit === undefined) throw new Error('No members seeded.');
  return { memberNumber: hit.memberNumber, id: hit.id, displayName: hit.displayName };
}

/** A member whose identity evidence is in `verified` status, as legal-name changes require. */
function verifiedMember(): { memberNumber: string; id: string } {
  const binding = bindingOf(fixture.bindings, 'northstar');
  const row = fixture.store.read((database) => database.prepare(
    "SELECT m.id,m.member_number FROM members m JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id WHERE m.dataset_id=? AND e.status='verified' AND m.status='active' ORDER BY m.member_number LIMIT 1",
  ).get(binding.datasetId) as { id?: string; member_number?: string } | undefined);
  if (row === undefined) throw new Error('No member with verified evidence.');
  return { memberNumber: String(row.member_number), id: String(row.id) };
}

async function signedOn(operator = 'OP0002'): Promise<Terminal> {
  const terminal = await Terminal.open(fixture.host);
  await terminal.signOn(northstar, operator);
  return terminal;
}

/** Opens the servicing menu section from the main menu (option 11 is on page 1). */
async function serviceMenu(terminal: Terminal): Promise<void> {
  await terminal.send('enter', [[19, 15, 'SV00']]);
}

/** Types `mark` into the single-cell selection input on the row whose text contains `needle`. */
async function mark(terminal: Terminal, needle: string, mark = 'S'): Promise<void> {
  const input = terminal.screen.fields.find((field) => !field.protected && field.column === 1
    && terminal.screen.fields.some((cell) => cell.protected && cell.row === field.row && cell.value.includes(needle)));
  if (input === undefined) throw new Error(`${needle} is not selectable on ${terminal.screen.screenId}:\n${terminal.text}`);
  await terminal.send('enter', [[input.row, 1, mark]]);
}

describe('menus and generic screens', () => {
  it('pages the main menu and opens a servicing operation form', async () => {
    const terminal = await signedOn();
    expect(terminal.text).toContain('PAGE 1 OF 2');
    await terminal.send('pf8');
    expect(terminal.text).toContain('AP01');
    await terminal.send('pf7');
    await serviceMenu(terminal);
    expect(terminal.text).toContain('SERVICING OPERATIONS');
    await terminal.send('enter', [[19, 15, 'NM02']]);
    expect(terminal.screen.screenId).toBe('THID04');
    expect(terminal.text).toContain('PREFERRED NAME');
  });

  it('lists approvals, journals and suspense through the generic directory', async () => {
    const terminal = await signedOn();
    await terminal.send('enter', [[19, 15, 'RC00']]);
    await terminal.send('enter', [[19, 15, 'DJ01']]);
    expect(terminal.text).toContain('REFERENCE');
    await terminal.send('pf3');
    await terminal.send('enter', [[19, 15, 'DJ03']]);
    expect(terminal.text).toContain('SUSPENSE');
    await terminal.send('pf3');
    await terminal.send('pf3');
    await terminal.send('pf8');
    await terminal.send('enter', [[19, 15, '15']]);
    expect(terminal.text).toContain('APPROVALS');
  });
});

describe('operation forms', () => {
  it('picks a member from a directory and commits a preferred name update', async () => {
    const target = member('northstar');
    const terminal = await signedOn();
    await serviceMenu(terminal);
    await terminal.send('enter', [[19, 15, 'NM02']]);
    expect(terminal.screen.screenId).toBe('THID04');
    // F4 on the member field opens the member directory in pick mode.
    await terminal.send('pf4', [], { row: 4, column: 21 });
    expect(terminal.text).toContain('MEMBER DIRECTORY');
    await mark(terminal, target.memberNumber);
    expect(terminal.screen.screenId).toBe('THID04');
    // Fill the rest of the form and review.
    await terminal.send('enter', [[5, 21, 'Casey'], [6, 21, 'S']]);
    expect(terminal.text).toContain('REVIEW');
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.text).toContain('RECEIPT');
    const detail = fixture.store.read((database) => {
      const binding = bindingOf(fixture.bindings, 'northstar');
      return memberDetail(database, binding.datasetId, target.id);
    });
    expect(detail?.person?.preferredName).toBe('Casey');
  });

  it('refuses a missing member and keeps the entered values', async () => {
    const terminal = await signedOn();
    await serviceMenu(terminal);
    await terminal.send('enter', [[19, 15, 'NM02']]);
    await terminal.send('enter', [[4, 21, 'ZZZZZZ'], [5, 21, 'Casey'], [6, 21, 'S']]);
    expect(terminal.screen.screenId).toBe('THID04');
    expect(terminal.message).toContain('MEMBER NOT FOUND');
    const nameField = terminal.screen.fields.find((field) => field.row === 5 && field.column === 21);
    expect(nameField?.value).toContain('Casey');
  });
});

describe('maintenance requests', () => {
  it('saves a draft, submits it and reviews it through the terminal', async () => {
    const target = member('northstar');
    const terminal = await signedOn();
    await terminal.send('pf8');
    await terminal.send('enter', [[19, 15, 'MN01']]);
    expect(terminal.screen.screenId).toBe('THMN01');
    await terminal.send('enter', [[3, 21, target.memberNumber], [4, 21, 'profile'], [4, 49, 'N'], [5, 21, 'Terminal note draft']]);
    // The kind field was only just processed: the note input appears on the redisplayed form.
    await terminal.send('enter', [[7, 21, 'A note through maintenance.']]);
    expect(terminal.text).toContain('REVIEW');
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.text).toContain('RECEIPT');
    await terminal.send('pf3');
    // The request now exists in the maintenance-requests directory.
    await serviceMenu(terminal);
    await terminal.send('pf8');
    await terminal.send('enter', [[19, 15, 'MN02']]);
    expect(terminal.text).toContain('MAINTENANCE REQUESTS');
    await terminal.send('enter', [[3, 21, target.memberNumber]]);
    expect(terminal.text).toContain('Terminal note draft');
  });
});

describe('approval flow', () => {
  it('requests, decides and executes a supervised command through the approval screens', async () => {
    const target = verifiedMember();
    const terminal = await signedOn('OP0002');
    await serviceMenu(terminal);
    await terminal.send('enter', [[19, 15, 'NM01']]);
    expect(terminal.screen.screenId).toBe('THID03');
    // member row4, given row5, family row6, evidence row7 (F4 pick), approval row8
    await terminal.send('enter', [[4, 21, target.memberNumber], [5, 21, 'Alexandra'], [6, 21, 'Reyes']]);
    expect(terminal.screen.screenId).toBe('THID03');
    expect(terminal.message).toContain('EVIDENCE');
    // Pick identity evidence for the member.
    await terminal.send('pf4', [], { row: 7, column: 21 });
    expect(terminal.text).toContain('IDENTITY EVIDENCE');
    await mark(terminal, 'evidence-');
    expect(terminal.screen.screenId).toBe('THID03');
    await terminal.send('enter');
    // The command has an empty approvalId, so the approval-request screen opens.
    expect(terminal.screen.screenId).toBe('THAP03');
    await terminal.send('enter', [[12, 21, 'OP0005']]);
    // Policy version comes from the policy directory pick.
    await terminal.send('pf4', [], { row: 14, column: 21 });
    expect(terminal.text).toContain('POLICY VERSIONS');
    await mark(terminal, '2026');
    expect(terminal.screen.screenId).toBe('THAP03');
    await terminal.send('enter');
    expect(terminal.text).toContain('REVIEW');
    await terminal.send('enter', [[19, 34, 'Y']]);
    expect(terminal.text).toContain('RECEIPT');
    // Checker OP0005 sees the approval in their inbox and approves it.
    const checker = await signedOn('OP0005');
    await checker.send('pf8');
    await checker.send('enter', [[19, 15, '15']]);
    expect(checker.text).toContain('APPROVALS');
    await checker.send('enter', [[7 + checker.listIndex('pending'), 1, 'S']]);
    expect(checker.screen.screenId).toBe('THAP02');
    await checker.send('enter', [[19, 26, 'A'], [20, 13, 'Identity verified at branch.']]);
    expect(checker.text).toContain('REVIEW');
    await checker.send('enter', [[19, 34, 'Y']]);
    expect(checker.text).toContain('RECEIPT');
    // Back at the inbox; reopen the approved legal-name approval and F9 executes it as checker.
    await checker.send('pf3');
    await mark(checker, 'member.legal_name.update');
    expect(checker.screen.screenId).toBe('THAP02');
    await checker.send('pf9');
    expect(checker.text).toContain('REVIEW');
    await checker.send('enter', [[19, 34, 'Y']]);
    expect(checker.text).toContain('RECEIPT');
    const detail = fixture.store.read((database) => {
      const binding = bindingOf(fixture.bindings, 'northstar');
      return memberDetail(database, binding.datasetId, target.id);
    });
    expect(detail?.person?.legalGiven ?? detail?.member.displayName).toContain('Alexandra');
  });
});

describe('reconciliation screens', () => {
  it('previews a seeded batch and opens the batch detail', async () => {
    const terminal = await signedOn('OP0003');
    await terminal.send('enter', [[19, 15, 'RC00']]);
    await terminal.send('pf8');
    await terminal.send('enter', [[19, 15, 'DJ10']]);
    expect(terminal.text).toContain('WORK BATCHES');
    await mark(terminal, 'BT0000');
    expect(terminal.screen.screenId).toBe('THBT01');
    expect(terminal.text).toContain('Fingerprint');
    await terminal.send('pf5');
    expect(terminal.text).toMatch(/PREVIEW|ITEM|VALID/u);
  });

  it('runs the identity resolution inquiry', async () => {
    const target = member('northstar');
    const terminal = await signedOn('OP0005');
    await serviceMenu(terminal);
    await terminal.send('enter', [[19, 15, 'ID03']]);
    expect(terminal.screen.screenId).toBe('THIR10');
    await terminal.send('enter', [[4, 21, target.memberNumber]]);
    expect(terminal.text).toContain('IDENTITY RESOLUTION');
  });
});
