/**
 * Wire contract between the browser terminal and the host.
 *
 * The host sends a complete formatted screen. The browser owns only the field buffer: it edits
 * unprotected fields and returns the modified ones by buffer address when the operator presses an
 * attention key. Addresses are screen coordinates, not business identifiers; the host resolves
 * them against the screen it actually sent, identified by `sequence`.
 */

export const ROWS = 24;
export const COLUMNS = 80;

export const PF_KEYS = ['pf1', 'pf2', 'pf3', 'pf4', 'pf5', 'pf6', 'pf7', 'pf8', 'pf9', 'pf10', 'pf11', 'pf12',
  'pf13', 'pf14', 'pf15', 'pf16', 'pf17', 'pf18', 'pf19', 'pf20', 'pf21', 'pf22', 'pf23', 'pf24'] as const;
export type PfKey = typeof PF_KEYS[number];

/** Attention identifiers: the keys that transmit the screen to the host. */
export const AIDS = ['enter', 'clear', ...PF_KEYS] as const;
export type Aid = typeof AIDS[number];

/** Presentation role of a field; the browser maps it to a colour and emphasis. */
export type Tone = 'label' | 'data' | 'input' | 'title' | 'emphasis' | 'error' | 'success' | 'warning' | 'legend';

export interface WireField {
  /** Buffer address of the first cell: row * COLUMNS + column, zero-based. */
  address: number;
  row: number;
  column: number;
  /**
   * Cells the field occupies. Protected fields stay on one row. An input field may continue onto
   * the following rows, as a 3270 field does, and its cells are addressed continuously.
   */
  length: number;
  /**
   * Most characters (UTF-16 code units, the unit of the shared business limits) an input field
   * holds. Content wider than the field's cells scrolls within them.
   */
  capacity: number;
  protected: boolean;
  /** Numeric fields accept digits, a decimal point and a minus sign. */
  numeric: boolean;
  tone: Tone;
  value: string;
}

export type Severity = 'info' | 'success' | 'warning' | 'error';

export interface TransferOffer {
  /** Session-scoped download URL; valid while the terminal session exists. */
  url: string;
  fileName: string;
  mediaType: string;
  byteLength: number;
  digest: string;
}

export interface ScreenPayload {
  sequence: number;
  screenId: string;
  title: string;
  fields: WireField[];
  cursor: { row: number; column: number };
  message: { text: string; severity: Severity } | null;
  /** Institution and operator shown in the operator information area. */
  institution: string | null;
  operator: string | null;
  transfer: TransferOffer | null;
}

export interface InputMessage {
  sequence: number;
  aid: Aid;
  cursor: { row: number; column: number };
  /** Modified unprotected fields only; trailing blanks are removed by the terminal. */
  fields: { address: number; value: string }[];
}

export interface SessionOpened {
  sessionId: string;
  screen: ScreenPayload;
}

export function addressOf(row: number, column: number): number {
  return row * COLUMNS + column;
}
