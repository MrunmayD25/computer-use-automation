/**
 * Character-cell measurement shared by the host screen builder and the browser field buffer.
 *
 * A terminal cell holds one user-perceived character (grapheme cluster). East Asian wide and
 * fullwidth characters and emoji with emoji presentation occupy two cells; combining marks stay
 * inside the grapheme they modify. Both sides use the same rules, so a value that fits a field in
 * the browser also fits when the host validates it.
 */

const segmenter = new Intl.Segmenter('en', { granularity: 'grapheme' });

/** Code point ranges with East Asian Width W or F that are not covered by the emoji test. */
const WIDE_RANGES: readonly (readonly [number, number])[] = [
  [0x1100, 0x115f], [0x2e80, 0x303e], [0x3041, 0x33ff], [0x3400, 0x4dbf], [0x4e00, 0x9fff], [0xa000, 0xa4cf],
  [0xa960, 0xa97f], [0xac00, 0xd7a3], [0xf900, 0xfaff], [0xfe10, 0xfe19], [0xfe30, 0xfe6f], [0xff00, 0xff60],
  [0xffe0, 0xffe6], [0x17000, 0x18aff], [0x1b000, 0x1b2ff], [0x20000, 0x2fffd], [0x30000, 0x3fffd],
];

/** Controls, bidirectional embeddings and isolates, and invisible zero-width formatting characters. */
const FORBIDDEN_RANGES: readonly (readonly [number, number])[] = [
  [0x0000, 0x001f], [0x007f, 0x009f], [0x200b, 0x200f], [0x202a, 0x202e], [0x2060, 0x2064], [0x2066, 0x2069], [0xfeff, 0xfeff],
];

const VARIATION_SELECTOR_EMOJI = String.fromCodePoint(0xfe0f);

export function graphemes(text: string): string[] {
  return Array.from(segmenter.segment(text), (part) => part.segment);
}

/** Cells occupied by one grapheme: 1 or 2. Forbidden characters are rejected before measurement. */
export function graphemeWidth(grapheme: string): 1 | 2 {
  if (/\p{Emoji_Presentation}/u.test(grapheme) || (/\p{Extended_Pictographic}/u.test(grapheme) && grapheme.includes(VARIATION_SELECTOR_EMOJI))) return 2;
  const code = grapheme.codePointAt(0) ?? 0;
  return WIDE_RANGES.some(([low, high]) => code >= low && code <= high) ? 2 : 1;
}

export function textWidth(text: string): number {
  return graphemes(text).reduce((total, grapheme) => total + graphemeWidth(grapheme), 0);
}

/**
 * True for characters a terminal field never accepts: C0/C1 controls (including tab and newline),
 * bidirectional embedding and isolate controls, and invisible zero-width formatting characters.
 * They could move text between fields, reorder what an operator sees, or hide content.
 */
export function hasForbiddenCharacter(text: string): boolean {
  for (const character of text) {
    const code = character.codePointAt(0) ?? 0;
    if (FORBIDDEN_RANGES.some(([low, high]) => code >= low && code <= high)) return true;
  }
  return false;
}

/**
 * Shortens text to at most `cells` cells. A shortened value ends with `>` so a reader can tell the
 * display is incomplete; a wide character is never split across the boundary.
 */
export function fitCells(text: string, cells: number): { text: string; truncated: boolean } {
  if (textWidth(text) <= cells) return { text, truncated: false };
  let used = 0;
  let result = '';
  for (const grapheme of graphemes(text)) {
    const width = graphemeWidth(grapheme);
    if (used + width > cells - 1) break;
    result += grapheme;
    used += width;
  }
  return { text: `${result}>`, truncated: true };
}

export function padCells(text: string, cells: number): string {
  const width = textWidth(text);
  return width >= cells ? text : `${text}${' '.repeat(cells - width)}`;
}
