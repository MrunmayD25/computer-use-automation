import { LIMITS, type MemberDetail, type ServiceCommand } from '@computer-use/financial-database/services';

import { textWidth } from '../../shared/cells.js';
import { COLUMNS } from '../../shared/protocol.js';
import { failure, info, type FrameOf, type NoteSubject } from '../host/frames.js';
import { localDateTime, upper, wrap } from '../host/format.js';
import type { HostContext, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  anyEntered, badSelection, beginReview, clampOffset, inactiveKey, label, LIST_ROWS, LIST_TOP, page, pageLabel, readCase, readMember, rowsLabel, selection, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';

type Note = MemberDetail['notes'][number];

/** Screen identities of each note subject. Member and case notes share these screens and rules. */
const SUBJECTS = {
  member: { label: 'Member', list: 'THMB07', add: 'THMB08', view: 'THMB09', review: 'THMB10' },
  case: { label: 'Case', list: 'THCS11', add: 'THCS12', view: 'THCS13', review: 'THCS14' },
} as const;

interface SubjectNotes {
  number: string;
  name: string;
  /** Newest first, already limited to what the signed-on operator may read. */
  notes: Note[];
  withheld: number;
}

function readNotes(context: HostContext, subject: NoteSubject): SubjectNotes {
  if (subject.kind === 'member') {
    const detail = readMember(context, subject.id);
    return { number: detail.member.memberNumber, name: detail.member.displayName, notes: detail.notes, withheld: detail.restrictedNotesWithheld };
  }
  const detail = readCase(context, subject.id);
  return { number: detail.case.caseNumber, name: `${detail.case.memberNumber} ${detail.case.memberName}`, notes: detail.notes, withheld: detail.restrictedNotesWithheld };
}

function subjectLine(builder: ScreenBuilder, subject: NoteSubject, notes: SubjectNotes): ScreenBuilder {
  return label(builder, 3, 1, SUBJECTS[subject.kind].label, 10).data(3, 11, 8, notes.number).data(3, 21, 58, notes.name, 'emphasis');
}

export const notesFrame = (subject: NoteSubject): FrameOf<'notes'> => ({ kind: 'notes', values: {}, subject, offset: 0, total: 0, rows: [] });

export const notesScreen: ScreenModule<FrameOf<'notes'>> = {
  render(context, frame) {
    const notes = readNotes(context, frame.subject);
    const { timeZone } = context.session().institution;
    const names = SUBJECTS[frame.subject.kind];
    frame.offset = clampOffset(frame.offset, LIST_ROWS, notes.notes.length);
    const shown = notes.notes.slice(frame.offset, frame.offset + LIST_ROWS);
    frame.rows = shown.map((note) => note.id);
    frame.total = notes.notes.length;
    const builder = new ScreenBuilder(names.list, `${names.label} notes`);
    builder.page = pageLabel(frame.offset, LIST_ROWS, notes.notes.length);
    subjectLine(builder, frame.subject, notes);
    builder.text(4, 1, 'NEWEST FIRST. RST = RESTRICTED NOTE.', 'label');
    if (notes.withheld > 0) builder.data(5, 1, 78, `${notes.withheld} RESTRICTED NOTE(S) WITHHELD: YOUR ROLE MAY NOT READ RESTRICTED NOTES.`, 'warning');
    for (const [at, text] of [[1, 'S'], [3, 'DATE/TIME'], [20, 'VIS'], [24, 'OPR'], [31, 'TEXT']] as const) builder.text(6, at, text, 'label');
    shown.forEach((note, index) => {
      const row = LIST_TOP + index;
      const restricted = note.visibility === 'restricted';
      builder.input(`sel.${index}`, row, 1, 1, value(frame, `sel.${index}`));
      builder.data(row, 3, 16, localDateTime(note.createdAt, timeZone)).data(row, 20, 3, restricted ? 'RST' : 'GEN', restricted ? 'warning' : 'label')
        .data(row, 24, 6, note.actor?.actorNumber ?? '').data(row, 31, 48, note.text.split(/\r?\n/u)[0] ?? '');
    });
    if (notes.notes.length === 0) builder.text(LIST_TOP, 3, `NO NOTES FOR THIS ${upper(names.label)}.`, 'warning');
    builder.text(19, 1, 'SEL: S=VIEW FULL NOTE', 'label');
    builder.data(20, 1, 40, rowsLabel(frame.offset, shown.length, notes.notes.length), 'label');
    return builder.legend('ENTER=Select  F1=Help  F3=Return  F6=Add note  F7=Up  F8=Down');
  },
  input(_context, frame, event) {
    if (event.aid === 'pf6') return { kind: 'push', frame: { kind: 'note-add', values: {}, subject: frame.subject, page: 1 } };
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE S BESIDE A NOTE TO READ IT, OR F6 TO ADD ONE.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const noteId = frame.rows[picked.index];
    if (picked.code !== 'S' || noteId === undefined) return badSelection(picked.code, 'S', picked.index);
    frame.cursor = `sel.${picked.index}`;
    return { kind: 'push', frame: { kind: 'note', values: {}, subject: frame.subject, noteId, page: 1 } };
  },
  help: HELP_TOPICS.notes,
};

const NOTE_PAGE_ROWS = 13;

export const noteScreen: ScreenModule<FrameOf<'note'>> = {
  render(context, frame) {
    const notes = readNotes(context, frame.subject);
    const note = notes.notes.find((candidate) => candidate.id === frame.noteId);
    const builder = new ScreenBuilder(SUBJECTS[frame.subject.kind].view, `${SUBJECTS[frame.subject.kind].label} note`);
    subjectLine(builder, frame.subject, notes);
    if (note === undefined) {
      builder.text(5, 1, 'THIS NOTE IS NO LONGER IN THE NOTE LIST.', 'warning');
      return builder.legend('F1=Help  F3=Return');
    }
    const lines = wrap(note.text, 76);
    const pages = Math.max(1, Math.ceil(lines.length / NOTE_PAGE_ROWS));
    frame.page = Math.min(frame.page, pages);
    builder.page = `PAGE ${frame.page} OF ${pages}`;
    label(builder, 4, 1, 'Created', 10).data(4, 11, 16, localDateTime(note.createdAt, context.session().institution.timeZone))
      .text(4, 30, 'BY', 'label').data(4, 33, 30, note.actor === null ? 'UNKNOWN' : `${note.actor.actorNumber} ${note.actor.displayName}`)
      .data(4, 65, 14, note.visibility === 'restricted' ? 'RESTRICTED' : 'GENERAL', note.visibility === 'restricted' ? 'warning' : 'label');
    lines.slice((frame.page - 1) * NOTE_PAGE_ROWS, frame.page * NOTE_PAGE_ROWS).forEach((line, index) => {
      if (line !== '') builder.data(6 + index, 2, 76, line);
    });
    return builder.legend('F1=Help  F3=Return  F7=Up  F8=Down');
  },
  input(context, frame, event) {
    const note = readNotes(context, frame.subject).notes.find((candidate) => candidate.id === frame.noteId);
    const holder = { offset: (frame.page - 1) * NOTE_PAGE_ROWS };
    const paged = page(holder, event.aid, NOTE_PAGE_ROWS, note === undefined ? 0 : wrap(note.text, 76).length);
    if (paged === null) return inactiveKey();
    frame.page = holder.offset / NOTE_PAGE_ROWS + 1;
    return paged;
  },
  help: HELP_TOPICS.note,
};

const NOTE_TOP = 6;
/** Each editor page is one input running from row 6, column 1 to the end of row 19, as a 3270 field wraps. */
const NOTE_PAGE_CELLS = 14 * COLUMNS - 1;
const NOTE_PAGES = Math.ceil(LIMITS.noteLength / NOTE_PAGE_CELLS);
const NOTE_FIELDS = Array.from({ length: NOTE_PAGES }, (_, index) => `text.${index}`);

/**
 * The note as one flowing text. The terminal does not send trailing blanks, so a page whose text
 * stops short of its last cell ended at a word break and is joined to the next page with a space;
 * a completely full page continues directly, even mid-word.
 */
function noteText(frame: FrameOf<'note-add'>): string {
  let text = '';
  let previousFull = false;
  for (const name of NOTE_FIELDS) {
    const part = value(frame, name);
    if (part === '') continue;
    text += text === '' || previousFull ? part : ` ${part}`;
    previousFull = textWidth(part) >= NOTE_PAGE_CELLS;
  }
  return text.trim();
}

export const noteAddScreen: ScreenModule<FrameOf<'note-add'>> = {
  render(context, frame) {
    const notes = readNotes(context, frame.subject);
    const names = SUBJECTS[frame.subject.kind];
    const builder = new ScreenBuilder(names.add, `Add ${names.label.toLowerCase()} note`);
    builder.page = `PAGE ${frame.page} OF ${NOTE_PAGES}`;
    subjectLine(builder, frame.subject, notes);
    label(builder, 4, 1, 'Visibility (G/R)', 20).input('visibility', 4, 21, 1, value(frame, 'visibility', 'G')).text(4, 24, 'G GENERAL. R RESTRICTED: CASE OR SUPERVISORY STAFF ONLY.', 'label');
    builder.text(5, 1, 'NOTE TEXT. IT FLOWS FROM LINE TO LINE; F8 CONTINUES ON THE NEXT PAGE.', 'label');
    const name = NOTE_FIELDS[frame.page - 1] ?? 'text.0';
    builder.input(name, NOTE_TOP, 1, NOTE_PAGE_CELLS, value(frame, name));
    builder.data(20, 1, 60, `${noteText(frame).length} OF ${LIMITS.noteLength} CHARACTERS RECEIVED FROM ALL PAGES`, 'label');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F7=Previous page  F8=Next page  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid === 'pf7' || event.aid === 'pf8') {
      const next = frame.page + (event.aid === 'pf8' ? 1 : -1);
      if (next < 1) return { kind: 'stay', message: info('ALREADY ON THE FIRST PAGE.') };
      if (next > NOTE_PAGES) return { kind: 'stay', message: info('ALREADY ON THE LAST PAGE.') };
      frame.page = next;
      return { kind: 'stay', message: info(`PAGE ${next} OF ${NOTE_PAGES}. TEXT ON THE OTHER PAGE IS KEPT.`) };
    }
    if (event.aid !== 'enter') return inactiveKey();
    const code = upper(value(frame, 'visibility', 'G').trim());
    const visibility = code === 'G' ? 'general' : code === 'R' ? 'restricted' : null;
    if (visibility === null) return { kind: 'stay', message: failure('VISIBILITY MUST BE G OR R.'), error: 'visibility' };
    const text = noteText(frame);
    const { subject } = frame;
    const command: ServiceCommand = subject.kind === 'member'
      ? { kind: 'member.note.add', memberId: subject.id, visibility, text }
      : { kind: 'case.note.add', caseId: subject.id, visibility, text };
    const names = SUBJECTS[subject.kind];
    return beginReview(context, frame, {
      command, screenId: names.review, title: 'Review new note',
      lines: [{ label: names.label, before: '', after: readNotes(context, subject).number }, { label: 'Visibility', before: '', after: upper(visibility) }, { label: 'Characters', before: '', after: String(text.length) }],
      fields: { visibility: 'visibility', text: 'text.0' },
      body: text,
    });
  },
  dirty: (frame) => anyEntered(frame, NOTE_FIELDS),
  help: HELP_TOPICS['note-add'],
};
