import { FINANCE_OPS } from './ops-finance.js';
import { PAYMENT_OPS } from './ops-payments.js';
import { QUERY_OPS } from './ops-queries.js';
import { SERVICING_OPS } from './ops-servicing.js';
import type { OpSpec } from './ops.js';

/** Every registered operation and query form, keyed by its menu option code. */
export const OPS: Record<string, OpSpec> = {
  ...SERVICING_OPS,
  ...FINANCE_OPS,
  ...PAYMENT_OPS,
  ...QUERY_OPS,
};
