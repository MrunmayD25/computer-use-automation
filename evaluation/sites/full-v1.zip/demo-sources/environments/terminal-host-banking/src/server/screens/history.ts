import { accountTransactions, receiptByNumber, type TransactionSearch } from '@computer-use/financial-database/services';

import { failure, info, type FrameOf, type HistoryCriteria } from '../host/frames.js';
import { amount, column, isIsoDate, localDateTime, parseAmount, upper } from '../host/format.js';
import type { Outcome, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  badSelection, clampOffset, exportFrame, forget, inactiveKey, label, LIST_ROWS, LIST_TOP, page, pageLabel, readAccount, rowsLabel, selection, statementsFrame, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';

const CRITERIA = ['from', 'to', 'direction', 'minimum', 'maximum', 'text', 'reference', 'order', 'status'] as const;
const REFERENCE_CAPACITY = 64;
const TEXT_CAPACITY = 60;
const CRITERIA_NAMES: ReadonlySet<string> = new Set(CRITERIA);

function heading(builder: ScreenBuilder, row: number, columns: readonly (readonly [number, string])[]): void {
  for (const [at, text] of columns) builder.text(row, at, text, 'label');
}

/** Criteria are validated when entered, so conversion here only maps codes to the shared search. */
function toSearch(criteria: HistoryCriteria, exponent: number): Omit<TransactionSearch, 'limit' | 'offset'> {
  const bound = (text: string): number | undefined => {
    if (text === '') return undefined;
    const parsed = parseAmount(text, exponent);
    return 'minorUnits' in parsed ? parsed.minorUnits : undefined;
  };
  const minimum = bound(criteria.minimum);
  const maximum = bound(criteria.maximum);
  return {
    ...(criteria.from === '' ? {} : { startDate: criteria.from }),
    ...(criteria.to === '' ? {} : { endDate: criteria.to }),
    ...(criteria.direction === 'C' ? { direction: 'credit' as const } : criteria.direction === 'D' ? { direction: 'debit' as const } : {}),
    ...(minimum === undefined ? {} : { minMinorUnits: minimum }),
    ...(maximum === undefined ? {} : { maxMinorUnits: maximum }),
    ...(criteria.text === '' ? {} : { text: criteria.text }),
    ...(criteria.reference === '' ? {} : { reference: criteria.reference }),
    ...(criteria.status === 'P' ? { status: 'posted' as const } : criteria.status === 'R' ? { status: 'reversed' as const } : {}),
    order: criteria.order === 'O' ? 'oldest' : 'newest',
  };
}

function validate(frame: FrameOf<'history'>, exponent: number): { criteria: HistoryCriteria } | Outcome {
  const read = (name: typeof CRITERIA[number]): string => upper(value(frame, name, frame.criteria[name]).trim());
  const criteria: HistoryCriteria = {
    from: read('from'), to: read('to'), direction: read('direction'), minimum: read('minimum'), maximum: read('maximum'), text: value(frame, 'text', frame.criteria.text).trim(),
    reference: value(frame, 'reference', frame.criteria.reference).trim(), order: read('order') || 'N', status: read('status'),
  };
  const stay = (message: string, error: string): Outcome => ({ kind: 'stay', message: failure(message), error });
  if (criteria.from !== '' && !isIsoDate(criteria.from)) return stay('FROM DATE MUST BE A VALID YYYY-MM-DD DATE.', 'from');
  if (criteria.to !== '' && !isIsoDate(criteria.to)) return stay('TO DATE MUST BE A VALID YYYY-MM-DD DATE.', 'to');
  if (criteria.from !== '' && criteria.to !== '' && criteria.from >= criteria.to) return stay('THE TO DATE IS EXCLUSIVE AND MUST BE AFTER THE FROM DATE.', 'to');
  if (!['', 'C', 'D'].includes(criteria.direction)) return stay('DIRECTION MUST BE C, D OR BLANK.', 'direction');
  if (!['', 'P', 'R'].includes(criteria.status)) return stay('STATUS MUST BE P (POSTED), R (REVERSED) OR BLANK.', 'status');
  if (!['N', 'O'].includes(criteria.order)) return stay('ORDER MUST BE N (NEWEST) OR O (OLDEST).', 'order');
  for (const name of ['minimum', 'maximum'] as const) {
    if (criteria[name] === '') continue;
    const parsed = parseAmount(criteria[name], exponent);
    if ('problem' in parsed) return stay(parsed.problem, name);
  }
  const search = toSearch(criteria, exponent);
  if (search.minMinorUnits !== undefined && search.maxMinorUnits !== undefined && search.minMinorUnits > search.maxMinorUnits) return stay('THE MINIMUM AMOUNT EXCEEDS THE MAXIMUM.', 'maximum');
  return { criteria };
}

export const historyScreen: ScreenModule<FrameOf<'history'>> = {
  render(context, frame) {
    const { account } = readAccount(context, frame.accountId);
    const search = toSearch(frame.criteria, account.exponent);
    const query = (offset: number) => context.read((database, datasetId) => accountTransactions(database, datasetId, frame.accountId, { ...search, limit: LIST_ROWS, offset }));
    let result = query(frame.offset);
    const clamped = clampOffset(frame.offset, LIST_ROWS, result.total);
    if (clamped !== frame.offset) {
      frame.offset = clamped;
      result = query(clamped);
    }
    frame.rows = result.items.map((row) => ({ journalId: row.journalId, lineNumber: row.lineNumber, reference: row.reference, receiptNumber: row.receiptNumber }));
    frame.total = result.total;
    const builder = new ScreenBuilder('THHI01', 'Transaction history');
    builder.page = pageLabel(frame.offset, LIST_ROWS, result.total);
    label(builder, 3, 1, 'Account', 9).data(3, 10, 10, account.accountNumber).data(3, 21, 30, account.ownerName, 'emphasis')
      .data(3, 52, 27, `POSTED ${amount(account.postedMinorUnits, account.currency, account.exponent)} ${account.currency}`);
    const criterion = (name: typeof CRITERIA[number]): string => value(frame, name, frame.criteria[name]);
    label(builder, 4, 1, 'From', 6).input('from', 4, 7, 10, criterion('from'));
    label(builder, 4, 19, 'To (excl)', 11).input('to', 4, 30, 10, criterion('to'));
    label(builder, 4, 42, 'Dir C/D', 9).input('direction', 4, 51, 1, criterion('direction'));
    label(builder, 4, 54, 'Order N/O', 11).input('order', 4, 65, 1, criterion('order'));
    label(builder, 4, 67, 'Stat P/R', 10).input('status', 4, 77, 1, criterion('status'));
    label(builder, 5, 1, 'Min', 6).input('minimum', 5, 7, 14, criterion('minimum'), { numeric: true });
    label(builder, 5, 22, 'Max', 5).input('maximum', 5, 27, 14, criterion('maximum'), { numeric: true });
    label(builder, 5, 43, 'Text', 6).input('text', 5, 49, 12, criterion('text'), { capacity: TEXT_CAPACITY });
    label(builder, 5, 62, 'Ref', 5).input('reference', 5, 67, 12, criterion('reference'), { capacity: REFERENCE_CAPACITY });
    heading(builder, 6, [[1, 'S'], [3, 'DATE'], [14, 'REFERENCE'], [30, 'DESCRIPTION'], [50, 'AMOUNT'.padStart(14)], [65, 'BALANCE'.padStart(14)]]);
    result.items.forEach((row, index) => {
      const line = LIST_TOP + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 10, row.effectiveDate).data(line, 14, 15, row.reference).data(line, 30, 19, row.description)
        .data(line, 50, 14, column(row.amountMinorUnits, account.currency, account.exponent, 14), row.amountMinorUnits < 0 ? 'warning' : 'data')
        .data(line, 65, 14, column(row.runningBalanceMinorUnits, account.currency, account.exponent, 14), 'label');
      if (row.status !== 'posted') builder.text(line, 79, 'R', 'warning');
    });
    if (result.total === 0) builder.text(LIST_TOP, 3, 'NO ENTRIES MATCH THE FILTER.', 'warning');
    builder.text(19, 1, 'SEL: S=DETAIL  R=RECEIPT.  R IN THE LAST COLUMN = NOT POSTED (REVERSED).', 'label');
    builder.data(20, 1, 40, rowsLabel(frame.offset, result.items.length, result.total), 'label').text(20, 44, 'DATES ARE EFFECTIVE DATES.', 'label');
    return builder.legend('ENTER=Filter/Select  F1=Help  F3=Return  F7=Up  F8=Down', 'F5=Export CSV  F6=Statements');
  },
  input(context, frame, event) {
    if (event.aid === 'pf5') return { kind: 'push', frame: { ...exportFrame(frame.accountId), values: { from: frame.criteria.from, to: frame.criteria.to } } };
    if (event.aid === 'pf6') return { kind: 'push', frame: statementsFrame(frame.accountId) };
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    if (CRITERIA.some((name) => event.modified.has(name))) {
      const checked = validate(frame, readAccount(context, frame.accountId).account.exponent);
      if (!('criteria' in checked)) return checked;
      frame.criteria = checked.criteria;
      frame.offset = 0;
      forget(frame, (name) => CRITERIA_NAMES.has(name));
      selection(frame, frame.rows.length);
      return { kind: 'stay', message: info('FILTER APPLIED.') };
    }
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE S OR R BESIDE AN ENTRY, OR CHANGE THE FILTER.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const row = frame.rows[picked.index];
    if (row === undefined) return badSelection(picked.code, 'A LISTED ROW', picked.index);
    frame.cursor = `sel.${picked.index}`;
    if (picked.code === 'S') return { kind: 'push', frame: { kind: 'entry', values: {}, accountId: frame.accountId, row } };
    if (picked.code === 'R') {
      if (row.receiptNumber === null) return { kind: 'stay', message: failure('NO RECEIPT IS RECORDED FOR THIS ENTRY.'), error: `sel.${picked.index}` };
      return { kind: 'push', frame: { kind: 'receipt', values: {}, receiptNumber: row.receiptNumber, offset: 0, replayed: false } };
    }
    return badSelection(picked.code, 'S OR R', picked.index);
  },
  help: HELP_TOPICS.history,
};

export const entryScreen: ScreenModule<FrameOf<'entry'>> = {
  render(context, frame) {
    const { account } = readAccount(context, frame.accountId);
    const { timeZone } = context.session().institution;
    const entry = context.read((database, datasetId) => accountTransactions(database, datasetId, frame.accountId, { reference: frame.row.reference, limit: 200, offset: 0 })
      .items.find((item) => item.journalId === frame.row.journalId && item.lineNumber === frame.row.lineNumber));
    const builder = new ScreenBuilder('THHI02', 'Entry detail');
    label(builder, 3, 1, 'Account', 18).data(3, 19, 10, account.accountNumber).data(3, 31, 48, account.ownerName, 'emphasis');
    if (entry === undefined) {
      builder.text(5, 1, 'THIS ENTRY IS NO LONGER LISTED FOR THE ACCOUNT.', 'warning');
      return builder.legend('F1=Help  F3=Return');
    }
    const money = (minorUnits: number): string => `${amount(minorUnits, account.currency, account.exponent)} ${account.currency}`;
    label(builder, 5, 1, 'Reference', 18).data(5, 19, 30, entry.reference, 'emphasis');
    label(builder, 6, 1, 'Effective date', 18).data(6, 19, 10, entry.effectiveDate);
    label(builder, 7, 1, 'Posted at', 18).data(7, 19, 16, localDateTime(entry.postedAt, timeZone));
    label(builder, 8, 1, 'Description', 18).data(8, 19, 60, entry.description);
    label(builder, 9, 1, 'Status', 18).data(9, 19, 12, upper(entry.status), entry.status === 'posted' ? 'success' : 'warning');
    label(builder, 10, 1, 'Amount', 18).data(10, 19, 30, `${entry.amountMinorUnits < 0 ? 'DEBIT' : 'CREDIT'} ${money(Math.abs(entry.amountMinorUnits))}`, 'emphasis');
    label(builder, 11, 1, 'Running balance', 18).data(11, 19, 30, money(entry.runningBalanceMinorUnits));
    label(builder, 12, 1, 'Counterparty', 18).data(12, 19, 60, entry.counterparty ?? '');
    label(builder, 13, 1, 'Operation', 18).data(13, 19, 30, entry.operationKind ?? 'NONE RECORDED');
    label(builder, 14, 1, 'Receipt', 18).data(14, 19, 12, entry.receiptNumber ?? 'NONE');
    if (entry.receiptNumber !== null) {
      const receiptNumber = entry.receiptNumber;
      const journal = context.read((database, datasetId) => receiptByNumber(database, datasetId, receiptNumber))?.journals.find((candidate) => candidate.id === entry.journalId);
      builder.text(16, 1, 'JOURNAL LINES', 'emphasis');
      journal?.lines.slice(0, 3).forEach((line, index) => {
        builder.data(17 + index, 3, 2, String(line.lineNumber)).data(17 + index, 6, 16, line.accountNumber ?? line.ledgerCode)
          .data(17 + index, 24, 20, line.debitMinorUnits === 0 ? '' : `DR ${amount(line.debitMinorUnits, line.currency, account.exponent)}`)
          .data(17 + index, 46, 20, line.creditMinorUnits === 0 ? '' : `CR ${amount(line.creditMinorUnits, line.currency, account.exponent)}`).data(17 + index, 68, 3, line.currency);
      });
    }
    return builder.legend('F1=Help  F3=Return  F5=Receipt');
  },
  input(context, frame, event) {
    if (event.aid !== 'pf5') return inactiveKey();
    const entry = context.read((database, datasetId) => accountTransactions(database, datasetId, frame.accountId, { reference: frame.row.reference, limit: 200, offset: 0 })
      .items.find((item) => item.journalId === frame.row.journalId && item.lineNumber === frame.row.lineNumber));
    if (entry?.receiptNumber == null) return { kind: 'stay', message: failure('NO RECEIPT IS RECORDED FOR THIS ENTRY.') };
    return { kind: 'push', frame: { kind: 'receipt', values: {}, receiptNumber: entry.receiptNumber, offset: 0, replayed: false } };
  },
  help: HELP_TOPICS.entry,
};
