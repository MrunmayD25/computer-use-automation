import type { SQLOutputValue } from 'node:sqlite';
import { createHash } from 'node:crypto';

import type { FinanceCommand, SqlDatabase } from '@computer-use/financial-database/services';
import { queryFinance } from '@computer-use/financial-database/services';

import { failure, info, type FrameOf } from '../host/frames.js';
import { upper, wrap } from '../host/format.js';
import type { HostContext, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { beginReview, inactiveKey, label, page, rowsLabel, value } from './common.js';
import { directoryFrame } from './dirs.js';
import { HELP_TOPICS } from './help-text.js';

type Row = Record<string, SQLOutputValue>;

const canonicalJson = (value: unknown): string => {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  const entries = Object.entries(value).filter(([, item]) => item !== undefined).sort(([a], [b]) => a.localeCompare(b));
  return `{${entries.map(([key, item]) => `${JSON.stringify(key)}:${canonicalJson(item)}`).join(',')}}`;
};
const sha = (value: string | Uint8Array): string => createHash('sha256').update(value).digest('hex');

const BATCH_COLUMNS = ['id', 'batch_number', 'kind', 'input_document_version_id', 'input_digest', 'state', 'approved_total_limit_minor_units', 'currency', 'created_at', 'items'] as const;

interface BatchView {
  row: Row;
  fingerprint: string;
  items: Row[];
  total: number;
}

function loadBatch(context: HostContext, batchId: string): BatchView | null {
  return context.read((database: SqlDatabase, datasetId: string) => {
    const row = database.prepare('SELECT id,batch_number,kind,input_document_version_id,input_digest,state,approved_total_limit_minor_units,currency,created_at FROM batches WHERE dataset_id=? AND id=?').get(datasetId, batchId) as Row | undefined;
    if (row === undefined) return null;
    const items = database.prepare('SELECT id,ordinal,source_key,item_json,state,receipt_id,amount_minor_units,failure_code FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal,id').all(datasetId, batchId) as Row[];
    const snapshot: Row = { ...row, items: canonicalJson(items) };
    const fingerprint = sha(canonicalJson(Object.fromEntries(BATCH_COLUMNS.map((column) => [column, snapshot[column] ?? null]))));
    return { row: snapshot, fingerprint, items, total: items.length };
  });
}

const PAGE_ITEMS = 10;

function conflictPolicyOf(frame: FrameOf<'batch'>): 'skip-stale' | 'reject-all' {
  return upper(value(frame, 'policy').trim()) === 'R' ? 'reject-all' : 'skip-stale';
}

function applyCommand(batch: BatchView, frame: FrameOf<'batch'>, item: Row): FinanceCommand {
  if (String(batch.row.kind) === 'contact-update') {
    return {
      kind: 'batch.contacts.apply', batchId: String(batch.row.id), itemId: String(item.id), expectedFingerprint: batch.fingerprint,
      conflictPolicy: conflictPolicyOf(frame), approvalId: value(frame, 'approval').trim(),
    };
  }
  return {
    kind: 'batch.fee_refunds.apply', batchId: String(batch.row.id), itemId: String(item.id), expectedFingerprint: batch.fingerprint,
    approvalId: value(frame, 'approval').trim(),
  };
}

export const batchScreen: ScreenModule<FrameOf<'batch'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THBT01', 'Batch');
    const batch = loadBatch(context, frame.batchId);
    if (batch === null) {
      builder.text(4, 1, 'BATCH NOT FOUND.', 'warning');
      return builder.legend('F3=Return  F12=Cancel');
    }
    const batchRow = batch.row;
    label(builder, 3, 1, 'Batch', 16).data(3, 17, 14, String(batchRow.batch_number), 'emphasis').text(3, 32, 'KIND', 'label').data(3, 37, 14, String(batchRow.kind)).text(3, 52, 'STATE', 'label').data(3, 58, 22, upper(String(batchRow.state)));
    label(builder, 4, 1, 'Input digest', 16).data(4, 17, 62, String(batchRow.input_digest), 'label');
    if (batchRow.approved_total_limit_minor_units !== null && batchRow.approved_total_limit_minor_units !== undefined) {
      label(builder, 5, 1, 'Refund limit', 16).data(5, 17, 26, `${String(batchRow.approved_total_limit_minor_units)} ${String(batchRow.currency)}`);
    }
    label(builder, 6, 1, 'Fingerprint', 11).data(6, 13, 64, batch.fingerprint, 'label');
    label(builder, 7, 1, 'Approval', 16).input('approval', 7, 17, 40, value(frame, 'approval')).text(7, 58, 'F4=PICK APPROVAL', 'label');
    label(builder, 8, 1, 'Conflict policy', 16).input('policy', 8, 17, 1, value(frame, 'policy')).text(8, 19, 'S SKIP  R REJECT-ALL', 'label');
    builder.text(10, 1, `${pad('SEL', 4)}${pad('ORD', 5)}${pad('SOURCE KEY', 16)}${pad('STATE', 14)}${pad('AMOUNT', 12)}${pad('FAILURE', 20)}`, 'label');
    const offset = Math.min(frame.offset, Math.max(0, batch.items.length - PAGE_ITEMS));
    batch.items.slice(offset, offset + PAGE_ITEMS).forEach((item, index) => {
      builder.input(`sel.${index}`, 11 + index, 1, 1, value(frame, `sel.${index}`));
      builder.data(11 + index, 4, 4, String(item.ordinal)).data(11 + index, 9, 15, String(item.source_key).slice(0, 15))
        .data(11 + index, 25, 13, String(item.state)).data(11 + index, 39, 11, item.amount_minor_units === null || item.amount_minor_units === undefined ? '' : String(item.amount_minor_units))
        .data(11 + index, 51, 18, String(item.failure_code ?? ''));
    });
    builder.page = rowsLabel(offset, Math.min(PAGE_ITEMS, batch.items.length - offset), batch.items.length);
    return builder.legend('A=Apply item  F5=Preview  F6=Approval req  F4=Pick approval', 'F7=Up  F8=Down  F1=Help  F3=Return');
  },
  input(context, frame, event) {
    const batch = loadBatch(context, frame.batchId);
    if (batch === null) return { kind: 'pop', message: failure('THE BATCH WAS REMOVED.') };
    const paged = page(frame, event.aid, PAGE_ITEMS, batch.items.length);
    if (paged !== null) return paged;
    if (event.aid === 'pf4') {
      if (event.cursorField === 'approval') return { kind: 'push', frame: directoryFrame('approvals', {}, 'approval') };
      return inactiveKey();
    }
    if (event.aid === 'pf5') {
      const result = context.svc((store, ctx) => queryFinance(store, ctx, {
        kind: 'batch.preview', batchId: String(batch.row.id), expectedFingerprint: batch.fingerprint,
        inputDigest: String(batch.row.input_digest), schemaVersion: '1', allowedMemberIds: [], allowedAccountIds: [],
      }));
      if (result.kind === 'rejected') return { kind: 'stay', message: failure(upper(result.message)) };
      if (result.kind !== 'previewed') return inactiveKey();
      const lines = wrap(JSON.stringify(result.data, null, 1), 76);
      return { kind: 'push', frame: { kind: 'qresult', values: {}, title: `Preview ${String(batch.row.batch_number)}`, lines, page: 1 } };
    }
    if (event.aid === 'pf6') {
      const pending = batch.items.find((item) => ['valid', 'pending'].includes(String(item.state)));
      if (pending === undefined) return { kind: 'stay', message: info('NO UNFINISHED ITEMS; NOTHING TO APPROVE.') };
      const target = applyCommand(batch, frame, pending) as FinanceCommand & { approvalId: string };
      target.approvalId = '';
      return { kind: 'push', frame: { kind: 'approval-request', values: {}, command: target, lines: [{ label: 'Batch', before: '', after: `${String(batch.row.batch_number)} (${String(batch.row.kind)})` }] } };
    }
    if (event.aid !== 'enter') return inactiveKey();
    for (let index = 0; index < PAGE_ITEMS; index += 1) {
      const mark = upper(value(frame, `sel.${index}`).trim());
      if (mark === '') continue;
      const item = batch.items[frame.offset + index];
      if (item === undefined) return { kind: 'stay', message: failure(`NO ITEM AT ROW ${index + 1}.`), error: `sel.${index}` };
      Reflect.deleteProperty(frame.values, `sel.${index}`);
      if (mark !== 'A') return { kind: 'stay', message: failure('TYPE A TO APPLY AN ITEM.'), error: `sel.${index}` };
      const command = applyCommand(batch, frame, item);
      return beginReview(context, frame, {
        command, screenId: 'THBT02', title: `Apply ${String(batch.row.batch_number)}:${String(item.ordinal)}`,
        lines: [{ label: 'Item', before: '', after: `${String(item.ordinal)} ${String(item.source_key)}` }, { label: 'Policy', before: '', after: conflictPolicyOf(frame) }],
        fields: { approvalId: 'approval', conflictPolicy: 'policy' },
      });
    }
    return inactiveKey();
  },
  dirty: (frame) => value(frame, 'approval').trim() !== '' || value(frame, 'policy').trim() !== '',
  help: HELP_TOPICS.batch,
};

const pad = (text: string, cells: number): string => text.length <= cells ? text.padEnd(cells) : text.slice(0, cells);
