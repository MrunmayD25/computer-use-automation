import { fitCells, hasForbiddenCharacter, padCells, textWidth } from '../../shared/cells.js';
import { COLUMNS, ROWS, addressOf, type Tone, type WireField } from '../../shared/protocol.js';

/** How the host interprets an unprotected field it sent. */
export interface InputBinding {
  name: string;
  length: number;
  /** Most UTF-16 code units the operator may send for this input. */
  capacity: number;
  numeric: boolean;
}

export interface BuiltScreen {
  screenId: string;
  title: string;
  fields: WireField[];
  cursor: { row: number; column: number };
  /** Unprotected fields by buffer address, for resolving the operator's reply. */
  inputs: Map<number, InputBinding>;
}

export interface InputOptions {
  numeric?: boolean;
  /** Presents the field as the subject of a validation error. */
  error?: boolean;
  /**
   * Most characters the field accepts, normally the shared business limit for the value. Content
   * wider than the field's cells scrolls within them. Defaults to the field's width.
   */
  capacity?: number;
}

/**
 * Formats one 24x80 screen. Protected fields lie within one row; an input field may run on across
 * rows. No two fields share a cell; violating either rule is a programming error, so the builder
 * throws rather than drawing over data.
 */
export class ScreenBuilder {
  private readonly occupied = new Uint8Array(ROWS * COLUMNS);
  private readonly fields: WireField[] = [];
  private readonly inputs = new Map<number, InputBinding>();
  private readonly addresses = new Map<string, number>();
  private cursorAddress: number | null = null;
  /** Page indicator drawn in the header, such as `PAGE 2 OF 5`. */
  page: string | null = null;

  constructor(readonly screenId: string, readonly title: string) {}

  /** The two key-legend rows at the bottom of the screen. */
  legend(first: string, second = ''): this {
    this.text(ROWS - 2, 0, first, 'legend');
    return second === '' ? this : this.text(ROWS - 1, 0, second, 'legend');
  }

  private claim(row: number, column: number, length: number, wraps = false): number {
    const address = addressOf(row, column);
    const fits = wraps ? address + length <= ROWS * COLUMNS : column + length <= COLUMNS;
    if (!Number.isInteger(row) || row < 0 || row >= ROWS || column < 0 || column >= COLUMNS || length < 1 || !fits) {
      throw new Error(`${this.screenId}: field at ${row}:${column} length ${length} leaves the screen.`);
    }
    for (let cell = address; cell < address + length; cell += 1) {
      if (this.occupied[cell] === 1) throw new Error(`${this.screenId}: field at ${row}:${column} overlaps another field.`);
      this.occupied[cell] = 1;
    }
    return address;
  }

  /** Protected literal text. It must fit; labels are written by the application, not by users. */
  text(row: number, column: number, value: string, tone: Tone = 'label'): this {
    const length = textWidth(value);
    if (length === 0) return this;
    const address = this.claim(row, column, length);
    this.fields.push({ address, row, column, length, capacity: length, protected: true, numeric: false, tone, value });
    return this;
  }

  /** Protected data in a fixed number of cells, shortened with a visible marker when it does not fit. */
  data(row: number, column: number, cells: number, value: string, tone: Tone = 'data'): this {
    const address = this.claim(row, column, cells);
    const safe = hasForbiddenCharacter(value) ? value.replaceAll(/\p{Cc}|\p{Cf}/gu, '?') : value;
    this.fields.push({ address, row, column, length: cells, capacity: cells, protected: true, numeric: false, tone, value: padCells(fitCells(safe, cells).text, cells).trimEnd() });
    return this;
  }

  /**
   * An unprotected input field of `length` cells, continuing onto following rows when it is wider
   * than the rest of its row. It holds the whole current value however wide: content beyond the
   * cells scrolls, so a value is never shortened or locked merely because the display is narrow.
   * A value holding control characters (a line break, say) cannot be keyed and is shown protected.
   */
  input(name: string, row: number, column: number, length: number, value: string, options: InputOptions = {}): this {
    if (this.addresses.has(name)) throw new Error(`${this.screenId}: duplicate input ${name}.`);
    if (hasForbiddenCharacter(value)) return this.data(row, column, Math.min(length, COLUMNS - column), value, 'warning');
    const address = this.claim(row, column, length, true);
    const capacity = Math.max(options.capacity ?? length, value.length);
    const numeric = options.numeric === true;
    this.fields.push({ address, row, column, length, capacity, protected: false, numeric, tone: options.error === true ? 'error' : 'input', value });
    this.inputs.set(address, { name, length, capacity, numeric });
    this.addresses.set(name, address);
    return this;
  }

  hasInput(name: string): boolean {
    return this.addresses.has(name);
  }

  /** Presents a named input as the subject of a validation error. */
  markError(name: string | undefined): this {
    const address = name === undefined ? undefined : this.addresses.get(name);
    const field = address === undefined ? undefined : this.fields.find((candidate) => candidate.address === address);
    if (field !== undefined) field.tone = 'error';
    return this;
  }

  /** Places the cursor at the start of a named input; ignored when the input is not on this screen. */
  cursor(name: string | undefined): this {
    const address = name === undefined ? undefined : this.addresses.get(name);
    if (address !== undefined) this.cursorAddress = address;
    return this;
  }

  cursorAt(row: number, column: number): this {
    this.cursorAddress = addressOf(row, column);
    return this;
  }

  build(): BuiltScreen {
    const first = [...this.inputs.keys()].sort((a, b) => a - b)[0];
    const cursor = this.cursorAddress ?? first ?? addressOf(ROWS - 3, 0);
    return {
      screenId: this.screenId, title: this.title,
      fields: [...this.fields].sort((a, b) => a.address - b.address),
      cursor: { row: Math.floor(cursor / COLUMNS), column: cursor % COLUMNS },
      inputs: this.inputs,
    };
  }
}
