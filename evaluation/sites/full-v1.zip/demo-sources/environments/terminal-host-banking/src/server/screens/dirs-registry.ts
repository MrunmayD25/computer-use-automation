import type { SQLOutputValue } from 'node:sqlite';
import {
  CAPABILITY_GRANTS, listApprovals, listDocumentAnnotations, listDocumentSignatures, listMemberAddressDestinations,
  listMemberAddresses, listMemberCommunicationJobs, listMemberCommunicationPreferences, listMemberConsents, listMemberDocumentVersions,
  listMemberIdentityEvidence, listMemberMaintenanceRequests, listMemberRetentionHolds,
  searchAccounts, searchCases, searchMembers,
  type FinanceRecordKind, type SqlDatabase,
} from '@computer-use/financial-database/services';

import { failure, type DirectoryRow, type Frame } from '../host/frames.js';
import { amount, localDate, upper } from '../host/format.js';
import type { HostContext, Outcome } from '../host/module.js';
import { caseFrame, findAccount, findMember, memberFrame, serviceContext } from './common.js';
import type { DirectorySpec, ScopeField } from './dirs.js';

type Row = Record<string, SQLOutputValue>;

const rows = (database: SqlDatabase, sql: string, ...parameters: (string | number | null)[]): Row[] =>
  database.prepare(sql).all(...parameters);
const row = (database: SqlDatabase, sql: string, ...parameters: (string | number | null)[]): Row | undefined =>
  database.prepare(sql).get(...parameters);
const s = (r: Row, column: string): string => String(r[column] as string | number | null ?? '');
const opt = (r: Row, column: string): string | null => r[column] === null || r[column] === undefined ? null : String(r[column]);

const trunc = (text: string, cells: number): string => text.length <= cells ? text : `${text.slice(0, Math.max(1, cells - 1))}~`;
const pad = (text: string, cells: number): string => trunc(text, cells).padEnd(cells);
const right = (text: string, cells: number): string => text.length >= cells ? text.slice(text.length - cells) : text.padStart(cells);

const noHelp = { title: 'Directory', lines: ['DIRECTORY', 'Type S beside a row and press Enter. F7/F8 page.'] };

/* Scope resolvers. Each accepts a business number, reference or an opaque id already picked. */

function found(id: string, label: string): { id: string; label: string } {
  return { id, label };
}

function missing(what: string, text: string): Outcome {
  return { kind: 'stay', message: failure(`${what} ${upper(text).slice(0, 16)} NOT FOUND.`) };
}

function byId(table: string, label: (r: Row) => string, what: string): ScopeField['resolve'] {
  return (context, text) => {
    const hit = context.read((database, datasetId) => row(database, `SELECT * FROM ${table} WHERE dataset_id=? AND id=?`, datasetId, text.trim()));
    return hit === undefined ? missing(what, text) : found(s(hit, 'id'), label(hit));
  };
}

const resolveMember: ScopeField['resolve'] = (context, text) => {
  const member = findMember(context, text);
  if (member !== undefined) return found(member.id, `${member.memberNumber} ${member.displayName}`);
  const byRow = context.read((database, datasetId) => row(database,
    'SELECT m.id,m.member_number,p.display_name FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE m.dataset_id=? AND m.id=?', datasetId, text.trim()));
  return byRow === undefined ? missing('MEMBER', text) : found(s(byRow, 'id'), `${s(byRow, 'member_number')} ${s(byRow, 'display_name')}`);
};

const resolveAccount: ScopeField['resolve'] = (context, text) => {
  const account = findAccount(context, text);
  if (account !== undefined) return found(account.id, `${account.accountNumber} ${account.ownerName}`);
  const byRow = context.read((database, datasetId) => row(database, 'SELECT id,account_number FROM accounts WHERE dataset_id=? AND id=?', datasetId, text.trim()));
  return byRow === undefined ? missing('ACCOUNT', text) : found(s(byRow, 'id'), s(byRow, 'account_number'));
};


const memberScope: ScopeField = { name: 'memberId', label: 'Member number', width: 10, resolve: resolveMember };
const optMemberScope: ScopeField = { ...memberScope, optional: true };
const accountScope: ScopeField = { name: 'accountId', label: 'Account number', width: 10, resolve: resolveAccount };
const optAccountScope: ScopeField = { ...accountScope, optional: true };

function recordFrame(kind: FinanceRecordKind, id: string): Frame {
  return { kind: 'record', values: {}, resource: kind, id, offset: 0 };
}

/** Lists a table's ids matching scope, formatting each row. */
function tableDirectory(
  id: string, screenId: string, title: string, heading: string,
  scope: readonly ScopeField[],
  list: (database: SqlDatabase, datasetId: string, scope: Record<string, string>, offset: number, limit: number, now: string) => { rows: DirectoryRow[]; total: number },
  open?: (row: DirectoryRow) => Frame | null,
): DirectorySpec {
  return {
    id, screenId, title, scope, filters: [], heading,
    list: (context, scopeValues, _filters, offset, limit) => context.read((database, datasetId) => list(database, datasetId, scopeValues, offset, limit, context.session().institution.asOf)),
    ...(open === undefined ? {} : { open: (_context, dirRow) => open(dirRow) }),
    help: noHelp,
  };
}

const memberNumber = (database: SqlDatabase, datasetId: string, memberId: string): string =>
  s(row(database, 'SELECT member_number FROM members WHERE dataset_id=? AND id=?', datasetId, memberId) ?? {}, 'member_number');
const accountNumber = (database: SqlDatabase, datasetId: string, accountId: string | null): string =>
  accountId === null ? '' : s(row(database, 'SELECT account_number FROM accounts WHERE dataset_id=? AND id=?', datasetId, accountId) ?? {}, 'account_number');

/* Member-facing servicing directories use the bounded member-scoped shared queries. */

function servicingList<T>(run: (database: SqlDatabase, datasetId: string) => { kind: string; value?: T[] } | { kind: 'rejected'; message: string }, toRow: (item: T) => DirectoryRow): DirectorySpec['list'] {
  return (context, _scope, _filters, offset, limit) => {
    const result = context.read((database, datasetId) => run(database, datasetId));
    if (result.kind !== 'authorized') {
      const message = 'message' in result ? result.message : 'Not authorized.';
      return failure(upper(message));
    }
    const items = (result as { value: T[] }).value;
    return { rows: items.slice(offset, offset + limit).map(toRow), total: items.length };
  };
}

const svc = (context: HostContext) => serviceContext(context, 'directory');

const idTail = (id: string): string => id.length <= 24 ? id : `~${id.slice(-23)}`;

export const DIRECTORIES: Record<string, DirectorySpec> = {

  members: tableDirectory('members', 'THDI01', 'Member directory', 'MBR NUMBER  NAME' + ' '.repeat(30) + 'STATUS', [], (database, datasetId, _scope, offset, limit) => {
    const result = searchMembers(database, datasetId, { limit: limit + 1, offset });
    return { total: result.total, rows: result.items.slice(0, limit).map((item) => ({ id: item.id, label: `${item.memberNumber} ${item.displayName}`, line: `${pad(item.memberNumber, 11)}${pad(item.displayName, 44)}${item.status}` })) };
  }, (r) => memberFrame(r.id)),

  accounts: tableDirectory('accounts', 'THDI02', 'Account directory', 'ACCOUNT    MEMBER      PRODUCT     STATUS    AVAILABLE', [optMemberScope], (database, datasetId, scope, offset, limit) => {
    const result = searchAccounts(database, datasetId, { ...(scope.memberId === undefined ? {} : { memberId: scope.memberId }), limit: limit + 1, offset });
    return {
      total: result.total, rows: result.items.slice(0, limit).map((item) => ({
        id: item.id, label: item.accountNumber,
        line: `${pad(item.accountNumber, 11)}${pad(item.memberNumber, 12)}${pad(item.productCode, 12)}${pad(item.status, 10)}${right(`${amount(item.availableMinorUnits, item.currency, item.exponent)} ${item.currency}`, 20)}`,
      })),
    };
  }, (r) => ({ kind: 'account', values: {}, accountId: r.id, page: 1 })),

  cases: tableDirectory('cases', 'THDI03', 'Case directory', 'CASE       STATE       QUEUE       SUMMARY', [optMemberScope], (database, datasetId, scope, offset, limit, now) => {
    const result = searchCases(database, datasetId, { ...(scope.memberId === undefined ? {} : { memberId: scope.memberId }), limit: limit + 1, offset }, now);
    return { total: result.total, rows: result.items.slice(0, limit).map((item) => ({ id: item.id, label: item.caseNumber, line: `${pad(item.caseNumber, 11)}${pad(item.state, 12)}${pad(item.queueCode, 12)}${trunc(item.summary, 40)}` })) };
  }, (r) => caseFrame(r.id)),

  documents: {
    id: 'documents', screenId: 'THDI04', title: 'Member documents', scope: [memberScope],
    filters: [{ name: 'type', label: 'Type', width: 20, hint: 'document type' }],
    heading: 'VERSION                   TYPE                 NAME                          ',
    list: (context, scope, filters, offset, limit) => servicingList(
      (database) => listMemberDocumentVersions(database, svc(context), scope.memberId ?? '', filters.type === '' ? undefined : filters.type, 200),
      (v) => ({ id: v.versionId, label: `${v.displayName} v${v.version}`, line: `${pad(idTail(v.versionId), 26)}${pad(v.documentType, 21)}${pad(v.displayName, 34)}${v.status}`, extra: { documentId: v.documentId, media: v.mediaType } }),
    )(context, { ...scope }, filters, offset, limit),
    open: (_context, r) => ({ kind: 'docview', values: {}, versionId: r.id, offset: 0 }),
    help: noHelp,
  },

  'identity-evidence': {
    id: 'identity-evidence', screenId: 'THDI05', title: 'Identity evidence', scope: [memberScope], filters: [],
    heading: 'EVIDENCE ID                KIND           STATUS       ISSUED     EXPIRES    ',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberIdentityEvidence(database, svc(context), scope.memberId ?? ''),
      (v) => ({ id: v.id, label: `${v.kind} ${v.status}`, line: `${pad(idTail(v.id), 27)}${pad(v.kind, 15)}${pad(v.status, 13)}${pad(localDate(v.issuedAt, 'UTC'), 11)}${pad(v.expiresAt === null ? '' : localDate(v.expiresAt, 'UTC'), 11)}${trunc(v.sourceReference, 12)}` }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  addresses: {
    id: 'addresses', screenId: 'THDI06', title: 'Member addresses', scope: [memberScope], filters: [],
    heading: 'PARTY-ADDRESS ID           PURPOSE   FROM        ADDRESS',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberAddresses(database, svc(context), scope.memberId ?? ''),
      (v) => ({
        id: v.partyAddressId, label: `${v.purpose} ${v.line1}`,
        line: `${pad(idTail(v.partyAddressId), 27)}${pad(v.purpose, 10)}${pad(v.validFrom, 12)}${trunc(`${v.line1}, ${v.city} ${v.region} ${v.postalCode} ${v.country}`, 28)}`,
        extra: { addressId: v.addressId, evidenceVersionId: v.evidenceVersionId ?? '' },
      }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  'address-destinations': {
    id: 'address-destinations', screenId: 'THDI07', title: 'Address destinations', scope: [memberScope], filters: [],
    heading: 'DESTINATION ID             CONTEXT            EFFECTIVE   ADDRESS',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberAddressDestinations(database, svc(context), scope.memberId ?? ''),
      (v) => ({
        id: v.id, label: `${v.context} ${v.address.line1}`,
        line: `${pad(idTail(v.id), 27)}${pad(v.context, 19)}${pad(localDate(v.effectiveAt, 'UTC'), 12)}${trunc(`${v.address.line1}, ${v.address.city}`, 20)}`,
        extra: { consentId: v.consentId ?? '', targetId: v.targetId, context: v.context },
      }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  consents: {
    id: 'consents', screenId: 'THDI08', title: 'Member consents', scope: [memberScope], filters: [],
    heading: 'CONSENT ID                 PURPOSE              CHANNEL     STATE      EFFECT',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberConsents(database, svc(context), scope.memberId ?? ''),
      (v) => ({ id: v.id, label: `${v.purpose} ${v.channel} ${v.state}`, line: `${pad(idTail(v.id), 27)}${pad(v.purpose, 21)}${pad(v.channel, 12)}${pad(v.state, 11)}${localDate(v.effectiveAt, 'UTC')}` }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  'comm-preferences': {
    id: 'comm-preferences', screenId: 'THDI09', title: 'Communication preferences', scope: [memberScope], filters: [],
    heading: 'PREFERENCE ID              PURPOSE              CHANNEL     STATE',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberCommunicationPreferences(database, svc(context), scope.memberId ?? ''),
      (v) => ({ id: v.id, label: `${v.purpose} ${v.channel} ${v.state}`, line: `${pad(idTail(v.id), 27)}${pad(v.purpose, 21)}${pad(v.channel, 12)}${v.state}` }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  'comm-jobs': {
    id: 'comm-jobs', screenId: 'THDI10', title: 'Communication jobs', scope: [memberScope], filters: [],
    heading: 'JOB ID                     CHANNEL     STATE      PURPOSE              DESTIN',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberCommunicationJobs(database, svc(context), scope.memberId ?? ''),
      (v) => ({ id: v.id, label: `${v.channel} ${v.state}`, line: `${pad(idTail(v.id), 27)}${pad(v.channel, 12)}${pad(v.state, 11)}${pad(v.purpose, 21)}${trunc(v.destination, 10)}` }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  'retention-holds': {
    id: 'retention-holds', screenId: 'THDI11', title: 'Retention holds', scope: [memberScope], filters: [],
    heading: 'HOLD ID                    STATE      REVIEW AT   REASON',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberRetentionHolds(database, svc(context), scope.memberId ?? ''),
      (v) => ({ id: v.id, label: `${v.state} ${v.reason}`, line: `${pad(idTail(v.id), 27)}${pad(v.state, 11)}${pad(localDate(v.reviewAt, 'UTC'), 12)}${trunc(v.reason, 26)}` }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  'maintenance-requests': {
    id: 'maintenance-requests', screenId: 'THDI12', title: 'Maintenance requests', scope: [memberScope], filters: [],
    heading: 'REQUEST   STATE      UPDATED     SUBJECT',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listMemberMaintenanceRequests(database, svc(context), scope.memberId ?? ''),
      (v) => ({ id: v.id, label: `${v.requestNumber} ${v.state}`, line: `${pad(v.requestNumber, 10)}${pad(v.state, 11)}${pad(localDate(v.updatedAt, 'UTC'), 12)}${trunc(v.subject, 44)}`, extra: { requestNumber: v.requestNumber, state: v.state } }),
    )(context, scope, _f, offset, limit),
    open: (_context, r) => ({ kind: 'maintenance', values: {}, memberId: null, requestId: r.id, expectedUpdatedAt: null }),
    help: noHelp,
  },

  annotations: {
    id: 'annotations', screenId: 'THDI13', title: 'Document annotations', scope: [{ name: 'versionId', label: 'Document version id', width: 40, resolve: (context, text) => {
      const hit = context.read((database, datasetId) => row(database, 'SELECT id FROM document_versions WHERE dataset_id=? AND id=?', datasetId, text.trim()));
      return hit === undefined ? missing('VERSION', text) : found(text.trim(), s(hit, 'id'));
    } }], filters: [],
    heading: 'ANNOTATION ID              PG  STATUS    TEXT',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listDocumentAnnotations(database, svc(context), scope.versionId ?? ''),
      (v) => ({ id: v.id, label: `p${v.pageNumber} ${v.status}`, line: `${pad(idTail(v.id), 27)}${right(String(v.pageNumber), 3)} ${pad(v.status, 9)}${trunc(v.text, 36)}`, extra: { fp: v.fingerprint, text: v.text } }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  signatures: {
    id: 'signatures', screenId: 'THDI14', title: 'Signature requests', scope: [{ name: 'versionId', label: 'Document version id', width: 40, resolve: (context, text) => {
      const hit = context.read((database, datasetId) => row(database, 'SELECT id FROM document_versions WHERE dataset_id=? AND id=?', datasetId, text.trim()));
      return hit === undefined ? missing('VERSION', text) : found(text.trim(), s(hit, 'id'));
    } }], filters: [],
    heading: 'SIGNATURE ID               SIGNER PARTY ID          STATUS     REQUESTED',
    list: (context, scope, _f, offset, limit) => servicingList(
      (database) => listDocumentSignatures(database, svc(context), scope.versionId ?? ''),
      (v) => ({ id: v.id, label: `${v.status} ${idTail(v.signerPartyId)}`, line: `${pad(idTail(v.id), 27)}${pad(idTail(v.signerPartyId), 23)}${pad(v.status, 11)}${localDate(v.requestedAt, 'UTC')}`, extra: { signerPartyId: v.signerPartyId } }),
    )(context, scope, _f, offset, limit),
    help: noHelp,
  },

  policies: tableDirectory('policies', 'THDI15', 'Policy versions', 'POLICY ID                  NAME                         VERSION   EFFECTIVE', [], (database, datasetId, _s, offset, limit) => {
    const all = rows(database, 'SELECT id,name,version,effective_at FROM policy_versions WHERE dataset_id=? ORDER BY effective_at DESC,id', datasetId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'name')} v${s(r, 'version')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'name'), 29)}${pad(s(r, 'version'), 10)}${s(r, 'effective_at').slice(0, 10)}` })) };
  }),

  queues: tableDirectory('queues', 'THDI16', 'Servicing queues', 'QUEUE ID                   CODE     NAME                              VISIBIL', [], (database, datasetId, _s, offset, limit) => {
    const all = rows(database, 'SELECT id,code,name,visibility FROM queues WHERE dataset_id=? ORDER BY code', datasetId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'code')} ${s(r, 'name')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'code'), 9)}${pad(s(r, 'name'), 34)}${s(r, 'visibility')}` })) };
  }),

  checkers: {
    id: 'checkers', screenId: 'THDI17', title: 'Approval checkers', scope: [{ name: 'kind', label: 'Command kind', width: 40, resolve: (_c, text) => text.trim() === '' ? { kind: 'stay', message: failure('ENTER A COMMAND KIND.') } : found(text.trim(), text.trim()) }], filters: [],
    heading: 'OPERATOR  NAME',
    list: (context, scope, _f, offset, limit) => {
      const kind = scope.kind ?? '';
      const grants = CAPABILITY_GRANTS[kind as keyof typeof CAPABILITY_GRANTS] as readonly string[] | undefined;
      if (grants === undefined) return failure(`COMMAND ${upper(kind).slice(0, 40)} IS NOT A KNOWN APPROVABLE KIND.`);
      const now = context.session().institution.asOf;
      const { institutionId } = context.session().institution;
      return context.read((database, datasetId) => {
        const actors = rows(database, "SELECT id,actor_number,display_name FROM actors WHERE dataset_id=? AND status='active' ORDER BY actor_number,id", datasetId);
        const self = context.session().operator.actorId;
        const items = actors.filter((actor) => s(actor, 'id') !== self).filter((actor) => {
          const granted = new Set(rows(database, `SELECT p.permission,p.scope_json FROM actor_roles ar JOIN role_permissions p ON p.dataset_id=ar.dataset_id AND p.role_id=ar.role_id
            WHERE ar.dataset_id=? AND ar.actor_id=? AND ar.starts_at<=? AND (ar.ends_at IS NULL OR ar.ends_at>?)`, datasetId, s(actor, 'id'), now, now).filter((r) => {
            try {
              const scopeJson: unknown = JSON.parse(s(r, 'scope_json'));
              return scopeJson !== null && typeof scopeJson === 'object' && !Array.isArray(scopeJson)
                && Object.keys(scopeJson).every((key) => key === 'institutionId')
                && (scopeJson as { institutionId?: string }).institutionId === institutionId;
            } catch { return false; }
          }).map((r) => s(r, 'permission')));
          return grants.some((grant) => granted.has(grant));
        });
        return { total: items.length, rows: items.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'actor_number')} ${s(r, 'display_name')}`, line: `${pad(s(r, 'actor_number'), 10)}${pad(s(r, 'display_name'), 40)}${idTail(s(r, 'id'))}` })) };
      });
    },
    help: noHelp,
  },

  approvals: {
    id: 'approvals', screenId: 'THDI18', title: 'Approvals', scope: [{ name: 'kind', label: 'Command kind', width: 40, optional: true, resolve: (_c, text) => found(text.trim(), text.trim()) }], filters: [{ name: 'status', label: 'Status', width: 10 }],
    heading: 'APPROVAL ID                STATUS     TARGET                           EXPIRE',
    list: (context, scope, filters, offset, limit) => {
      const result = context.svc((store, ctx) => listApprovals(store, ctx, 200));
      if (result.kind !== 'found') return failure(upper(result.message));
      let items = result.approvals;
      if (scope.kind !== undefined && scope.kind !== '') {
        items = items.filter((a) => (a.target as { kind?: string }).kind === scope.kind);
      }
      const status = filters.status ?? '';
      if (status !== '') items = items.filter((a) => a.status === status.toLowerCase());
      return {
        total: items.length,
        rows: items.slice(offset, offset + limit).map((a) => ({
          id: a.id, label: `${a.status} ${(a.target as { kind?: string }).kind ?? ''}`,
          line: `${pad(idTail(a.id), 27)}${pad(a.status, 11)}${pad((a.target as { kind?: string }).kind ?? '', 36)}${a.expiresAt.slice(0, 10)}`,
          extra: { fp: a.fingerprint, status: a.status },
        })),
      };
    },
    open: (_context, r) => ({ kind: 'approval', values: {}, approvalId: r.id, offset: 0 }),
    help: noHelp,
  },

  'merge-plans': tableDirectory('merge-plans', 'THDI19', 'Member merge plans', 'PLAN ID                    STATE      SOURCE      SURVIVOR', [], (database, datasetId, _s, offset, limit) => {
    const all = rows(database, 'SELECT p.id,p.state,p.source_member_id,p.target_member_id FROM member_merge_plans p WHERE p.dataset_id=? ORDER BY p.created_at DESC,p.id', datasetId);
    return {
      total: all.length,
      rows: all.slice(offset, offset + limit).map((r) => ({
        id: s(r, 'id'), label: `${s(r, 'id')} ${s(r, 'state')}`,
        line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 11)}${pad(memberNumber(database, datasetId, s(r, 'source_member_id')), 12)}${memberNumber(database, datasetId, s(r, 'target_member_id'))}`,
        extra: { source: s(r, 'source_member_id'), target: s(r, 'target_member_id'), state: s(r, 'state') },
      })),
    };
  }),

  /* Finance record directories: exact rows, never guessed. */

  payments: tableDirectory('payments', 'THDI20', 'Payments', 'REFERENCE   STATE       AMOUNT            DATE        ROUTE', [optAccountScope], (database, datasetId, scope, offset, limit) => {
    const where = scope.accountId === undefined ? '' : ' AND p.source_account_id=?';
    const params = scope.accountId === undefined ? [datasetId] : [datasetId, scope.accountId];
    const all = rows(database, `SELECT p.id,p.reference,p.state,p.amount_minor_units,p.currency,p.requested_date,p.beneficiary_route_id FROM payments p WHERE p.dataset_id=?${where} ORDER BY p.requested_date DESC,p.id`, ...params);
    return {
      total: all.length,
      rows: all.slice(offset, offset + limit).map((r) => ({
        id: s(r, 'id'), label: `${s(r, 'reference')} ${s(r, 'state')}`,
        line: `${pad(s(r, 'reference'), 12)}${pad(s(r, 'state'), 12)}${right(`${s(r, 'amount_minor_units')} ${s(r, 'currency')}`, 18)}${pad(s(r, 'requested_date'), 12)}${idTail(s(r, 'beneficiary_route_id'))}`,
        extra: { routeId: s(r, 'beneficiary_route_id') },
      })),
    };
  }, (r) => recordFrame('payment', r.id)),

  beneficiaries: tableDirectory('beneficiaries', 'THDI21', 'Beneficiaries', 'BENEFICIARY ID             NAME                              STATUS', [memberScope], (database, datasetId, scope, offset, limit) => {
    const partyId = s(row(database, 'SELECT party_id FROM members WHERE dataset_id=? AND id=?', datasetId, scope.memberId ?? '') ?? {}, 'party_id');
    const all = rows(database, 'SELECT id,display_name,status FROM beneficiaries WHERE dataset_id=? AND owner_party_id=? ORDER BY display_name,id', datasetId, partyId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: s(r, 'display_name'), line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'display_name'), 34)}${s(r, 'status')}` })) };
  }, (r) => recordFrame('beneficiary', r.id)),

  'beneficiary-routes': tableDirectory('beneficiary-routes', 'THDI22', 'Beneficiary routes', 'ROUTE ID                   VER  KIND              DESTINATION           STATU', [
    { name: 'beneficiaryId', label: 'Beneficiary id', width: 40, resolve: byId('beneficiaries', (r) => s(r, 'display_name'), 'BENEFICIARY') },
  ], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,version,routing_kind,masked_destination,status FROM beneficiary_routes WHERE dataset_id=? AND beneficiary_id=? ORDER BY version DESC,id', datasetId, scope.beneficiaryId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `v${s(r, 'version')} ${s(r, 'masked_destination')}`, line: `${pad(idTail(s(r, 'id')), 27)}${right(s(r, 'version'), 3)} ${pad(s(r, 'routing_kind'), 18)}${pad(s(r, 'masked_destination'), 22)}${s(r, 'status')}` })) };
  }),

  schedules: tableDirectory('schedules', 'THDI23', 'Payment schedules', 'SCHEDULE ID                STATE      START       END', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,state,start_date,end_date FROM payment_schedules WHERE dataset_id=? AND source_account_id=? ORDER BY start_date,id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'state')} ${s(r, 'start_date')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 11)}${pad(s(r, 'start_date'), 12)}${s(r, 'end_date')}` })) };
  }, (r) => recordFrame('payment-schedule', r.id)),

  occurrences: tableDirectory('occurrences', 'THDI24', 'Schedule occurrences', 'OCCURRENCE ID              DATE        STATE         PAYMENT', [
    { name: 'scheduleId', label: 'Schedule id', width: 40, resolve: byId('payment_schedules', (r) => s(r, 'id'), 'SCHEDULE') },
  ], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,local_date,state,payment_id FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? ORDER BY local_date,id', datasetId, scope.scheduleId ?? '');
    return {
      total: all.length,
      rows: all.slice(offset, offset + limit).map((r) => ({
        id: s(r, 'id'), label: `${s(r, 'local_date')} ${s(r, 'state')}`,
        line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'local_date'), 12)}${pad(s(r, 'state'), 14)}${idTail(opt(r, 'payment_id') ?? '')}`,
        extra: { paymentId: opt(r, 'payment_id') ?? '' },
      })),
    };
  }),

  returns: tableDirectory('returns', 'THDI25', 'Payment returns', 'RETURN ID                  CODE        AMOUNT            SETTLEMENT REF', [optAccountScope], (database, datasetId, scope, offset, limit) => {
    const where = scope.accountId === undefined ? '' : ' AND p.source_account_id=?';
    const params = scope.accountId === undefined ? [datasetId] : [datasetId, scope.accountId];
    const all = rows(database, `SELECT r.id,r.return_code,r.amount_minor_units,r.settlement_reference,r.payment_id,p.currency FROM payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id WHERE r.dataset_id=?${where} ORDER BY r.occurred_at DESC,r.id`, ...params);
    return {
      total: all.length,
      rows: all.slice(offset, offset + limit).map((r) => ({
        id: s(r, 'id'), label: `${s(r, 'return_code')} ${s(r, 'payment_id')}`,
        line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'return_code'), 12)}${right(`${s(r, 'amount_minor_units')} ${s(r, 'currency')}`, 18)}${s(r, 'settlement_reference')}`,
        extra: { paymentId: s(r, 'payment_id') },
      })),
    };
  }),

  cards: tableDirectory('cards', 'THDI26', 'Cards', 'CARD ID                    LAST4   EXPIRY    STATUS', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,last_four,expiry_month,expiry_year,status FROM cards WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `****${s(r, 'last_four')} ${s(r, 'status')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(`****${s(r, 'last_four')}`, 8)}${pad(`${s(r, 'expiry_month')}/${s(r, 'expiry_year')}`, 10)}${s(r, 'status')}` })) };
  }, (r) => recordFrame('card', r.id)),

  'card-transactions': tableDirectory('card-transactions', 'THDI27', 'Card transactions', 'TRANSACTION ID             MERCHANT              AMOUNT            STATE', [
    { name: 'cardId', label: 'Card id', width: 40, resolve: byId('cards', (r) => `****${s(r, 'last_four')}`, 'CARD') },
  ], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,merchant,amount_minor_units,currency,state FROM card_transactions WHERE dataset_id=? AND card_id=? ORDER BY occurred_at DESC,id', datasetId, scope.cardId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'merchant')} ${s(r, 'state')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'merchant'), 22)}${right(`${s(r, 'amount_minor_units')} ${s(r, 'currency')}`, 18)}${s(r, 'state')}` })) };
  }),

  disputes: tableDirectory('disputes', 'THDI28', 'Disputes', 'CASE        STATE         CLAIMED           DEADLINE', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,case_number,state,claimed_amount_minor_units,currency,deadline FROM disputes WHERE dataset_id=? AND account_id=? ORDER BY deadline,id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'case_number')} ${s(r, 'state')}`, line: `${pad(s(r, 'case_number'), 12)}${pad(s(r, 'state'), 14)}${right(`${s(r, 'claimed_amount_minor_units')} ${s(r, 'currency')}`, 18)}${s(r, 'deadline')}` })) };
  }, (r) => recordFrame('dispute', r.id)),

  loans: tableDirectory('loans', 'THDI29', 'Loans', 'LOAN ID                    STATE       PRINCIPAL         RATE', [optAccountScope], (database, datasetId, scope, offset, limit) => {
    const where = scope.accountId === undefined ? '' : ' AND l.account_id=?';
    const params = scope.accountId === undefined ? [datasetId] : [datasetId, scope.accountId];
    const all = rows(database, `SELECT l.id,l.state,l.principal_minor_units,l.currency,l.annual_rate_bps,l.account_id FROM loans l WHERE l.dataset_id=?${where} ORDER BY l.id`, ...params);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'state')} ${accountNumber(database, datasetId, s(r, 'account_id'))}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 12)}${right(`${s(r, 'principal_minor_units')} ${s(r, 'currency')}`, 18)}${s(r, 'annual_rate_bps')}bps` })) };
  }, (r) => recordFrame('loan', r.id)),

  'loan-applications': tableDirectory('loan-applications', 'THDI30', 'Loan applications', 'APPLICATION ID             STATE       REQUESTED         MEMBER', [memberScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,state,requested_amount_minor_units,currency FROM loan_applications WHERE dataset_id=? AND member_id=? ORDER BY id', datasetId, scope.memberId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: s(r, 'state'), line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 12)}${right(`${s(r, 'requested_amount_minor_units')} ${s(r, 'currency')}`, 18)}` })) };
  }),

  fees: tableDirectory('fees', 'THDI31', 'Fees', 'FEE ID                     STATUS       ORIGINAL          POLICY', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,status,original_amount_minor_units,currency,policy_version_id FROM fees WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'status')} ${s(r, 'original_amount_minor_units')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'status'), 13)}${right(`${s(r, 'original_amount_minor_units')} ${s(r, 'currency')}`, 18)}${idTail(s(r, 'policy_version_id'))}` })) };
  }),

  'fee-waivers': tableDirectory('fee-waivers', 'THDI32', 'Fee waivers', 'WAIVER ID                  STATE      FEE CODE    LIMIT             THROUGH', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,state,fee_code,amount_limit_minor_units,currency,valid_through FROM fee_waivers WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'fee_code')} ${s(r, 'state')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 11)}${pad(s(r, 'fee_code'), 12)}${right(`${s(r, 'amount_limit_minor_units')} ${s(r, 'currency')}`, 18)}${s(r, 'valid_through')}` })) };
  }),

  holds: tableDirectory('holds', 'THDI33', 'Holds', 'HOLD ID                    STATUS     AMOUNT            REASON', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,status,amount_minor_units,reason FROM holds WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'status')} ${s(r, 'amount_minor_units')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'status'), 11)}${right(s(r, 'amount_minor_units'), 18)}${trunc(s(r, 'reason'), 20)}` })) };
  }),

  restrictions: tableDirectory('restrictions', 'THDI34', 'Restrictions', 'RESTRICTION ID             KIND           STATUS     AUTHORITY', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,kind,status,authority FROM restrictions WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'kind')} ${s(r, 'status')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'kind'), 15)}${pad(s(r, 'status'), 11)}${trunc(s(r, 'authority'), 20)}` })) };
  }),

  facilities: tableDirectory('facilities', 'THDI35', 'Facilities', 'FACILITY ID                KIND         LIMIT             USED              S', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,kind,limit_minor_units,used_minor_units,status FROM facilities WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'kind')} ${s(r, 'status')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'kind'), 13)}${right(s(r, 'limit_minor_units'), 18)}${right(s(r, 'used_minor_units'), 18)}${s(r, 'status')}` })) };
  }),

  maturity: tableDirectory('maturity', 'THDI36', 'Maturity instructions', 'INSTRUCTION ID             STATE      DISPOSITION   CUTOFF', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,state,disposition,cutoff_at FROM maturity_instructions WHERE dataset_id=? AND account_id=? ORDER BY id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'disposition')} ${s(r, 'state')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 11)}${pad(s(r, 'disposition'), 14)}${s(r, 'cutoff_at')}` })) };
  }),

  'received-funds': {
    id: 'received-funds', screenId: 'THDI37', title: 'Received funds', scope: [memberScope], filters: [],
    heading: 'REFERENCE   STATE       AMOUNT            RECEIVED',
    list: (context, scope, _f, offset, limit) => context.read((database, datasetId) => {
      const all = rows(database, 'SELECT id,reference,state,amount_minor_units,currency,received_at FROM received_funds WHERE dataset_id=? AND member_id=? ORDER BY received_at DESC,id', datasetId, scope.memberId ?? '');
      // Picks need the business reference, not the opaque id.
      return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'reference'), label: s(r, 'reference'), line: `${pad(s(r, 'reference'), 12)}${pad(s(r, 'state'), 12)}${right(`${s(r, 'amount_minor_units')} ${s(r, 'currency')}`, 18)}${s(r, 'received_at').slice(0, 10)}`, extra: { id: s(r, 'id') } })) };
    }),
    help: noHelp,
  },

  'loan-closures': tableDirectory('loan-closures', 'THDI45', 'Loan closures', 'CLOSURE ID                 LOAN                    CLOSED      DOCUMENT', [
    { name: 'loanId', label: 'Loan id', width: 40, resolve: byId('loans', (r) => s(r, 'id'), 'LOAN') },
  ], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,loan_id,closed_at,closure_document_version_id FROM loan_closures WHERE dataset_id=? AND loan_id=? ORDER BY id', datasetId, scope.loanId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: s(r, 'closed_at').slice(0, 10), line: `${pad(idTail(s(r, 'id')), 27)}${pad(idTail(s(r, 'loan_id')), 24)}${pad(s(r, 'closed_at').slice(0, 10), 12)}${idTail(s(r, 'closure_document_version_id'))}` })) };
  }),

  'interest-calcs': tableDirectory('interest-calcs', 'THDI38', 'Interest calculations', 'CALCULATION ID             STATE     PERIOD              CALCULATED        BO', [accountScope], (database, datasetId, scope, offset, limit) => {
    const all = rows(database, 'SELECT id,state,period_start,period_end,calculated_interest_minor_units,booked_interest_minor_units,currency FROM interest_calculations WHERE dataset_id=? AND account_id=? ORDER BY period_start DESC,id', datasetId, scope.accountId ?? '');
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'period_start')} ${s(r, 'state')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 10)}${pad(`${s(r, 'period_start')}..${s(r, 'period_end')}`, 20)}${right(s(r, 'calculated_interest_minor_units'), 17)}${right(s(r, 'booked_interest_minor_units'), 16)}` })) };
  }),

  journals: tableDirectory('journals', 'THDI39', 'Journals', 'REFERENCE   STATUS    POSTED      EFFECTIVE   DESCRIPTION', [optAccountScope], (database, datasetId, scope, offset, limit) => {
    const where = scope.accountId === undefined ? '' : ' AND EXISTS (SELECT 1 FROM journal_lines jl JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id WHERE jl.dataset_id=j.dataset_id AND jl.journal_id=j.id AND la.customer_account_id=?)';
    const params = scope.accountId === undefined ? [datasetId] : [datasetId, scope.accountId];
    const all = rows(database, `SELECT j.id,j.reference,j.status,j.posted_at,j.effective_date,j.description FROM journals j WHERE j.dataset_id=?${where} ORDER BY j.posted_at DESC,j.id`, ...params);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: s(r, 'reference'), line: `${pad(s(r, 'reference'), 12)}${pad(s(r, 'status'), 10)}${pad(s(r, 'posted_at').slice(0, 10), 12)}${pad(s(r, 'effective_date'), 12)}${trunc(s(r, 'description'), 32)}` })) };
  }),

  'settlement-batches': tableDirectory('settlement-batches', 'THDI40', 'Settlement batches', 'BATCH ID                   REFERENCE          STATE       TOTAL', [], (database, datasetId, _scope, offset, limit) => {
    const all = rows(database, 'SELECT id,reference,state,declared_total_minor_units,currency FROM settlement_batches WHERE dataset_id=? ORDER BY id', datasetId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'reference')} ${s(r, 'state')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'reference'), 19)}${pad(s(r, 'state'), 12)}${right(`${s(r, 'declared_total_minor_units')} ${s(r, 'currency')}`, 18)}` })) };
  }),

  suspense: tableDirectory('suspense', 'THDI41', 'Suspense items', 'ITEM ID                    STATE               REMAINING         JOURNAL', [], (database, datasetId, _scope, offset, limit) => {
    const all = rows(database, 'SELECT id,state,remaining_amount_minor_units,currency,journal_id FROM suspense_items WHERE dataset_id=? ORDER BY id', datasetId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: s(r, 'state'), line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'state'), 20)}${right(`${s(r, 'remaining_amount_minor_units')} ${s(r, 'currency')}`, 18)}${idTail(s(r, 'journal_id'))}` })) };
  }),

  batches: tableDirectory('batches', 'THDI42', 'Work batches', 'BATCH       KIND            STATE                   ITEMS', [], (database, datasetId, _scope, offset, limit) => {
    const all = rows(database, `SELECT b.id,b.batch_number,b.kind,b.state,(SELECT COUNT(*) FROM batch_items i WHERE i.dataset_id=b.dataset_id AND i.batch_id=b.id) AS items FROM batches b WHERE b.dataset_id=? ORDER BY b.batch_number`, datasetId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'batch_number')} ${s(r, 'state')}`, line: `${pad(s(r, 'batch_number'), 12)}${pad(s(r, 'kind'), 16)}${pad(s(r, 'state'), 24)}${s(r, 'items')}` })) };
  }, (r) => ({ kind: 'batch', values: {}, batchId: r.id, offset: 0, total: 0 })),

  'cash-sessions': tableDirectory('cash-sessions', 'THDI43', 'Cash sessions', 'SESSION ID                 DATE        STATE      BRANCH', [], (database, datasetId, _scope, offset, limit) => {
    const all = rows(database, 'SELECT id,business_date,state,branch_id FROM cash_sessions WHERE dataset_id=? ORDER BY business_date DESC,id', datasetId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'business_date')} ${s(r, 'state')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'business_date'), 12)}${pad(s(r, 'state'), 11)}${idTail(s(r, 'branch_id'))}` })) };
  }),

  products: tableDirectory('products', 'THDI44', 'Products', 'PRODUCT ID                 CODE       NAME                              CUR  ', [], (database, datasetId, _scope, offset, limit) => {
    const all = rows(database, "SELECT id,code,name,currency,family,status FROM products WHERE dataset_id=? ORDER BY family,code", datasetId);
    return { total: all.length, rows: all.slice(offset, offset + limit).map((r) => ({ id: s(r, 'id'), label: `${s(r, 'code')} ${s(r, 'name')}`, line: `${pad(idTail(s(r, 'id')), 27)}${pad(s(r, 'code'), 11)}${pad(s(r, 'name'), 34)}${pad(s(r, 'currency'), 6)}${s(r, 'family')}/${s(r, 'status')}` })) };
  }),
};
