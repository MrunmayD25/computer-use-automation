import { upper } from '../host/format.js';
import { cell, isOutcome } from './common.js';
import { HELP_TOPICS } from './help-text.js';
import { code, date, entered, fieldProblem, idList, instant, money, num, required, type OpSpec } from './ops.js';
import {
  ACCOUNT, APPROVAL, approvalId, accountRef, codeField, dateField, instantField, memberRef, MEMBER, moneyField, numField,
  OPT_ACCOUNT, optAccountRef, POLICY, recordRef, REASON, textField, type OpField,
} from './ops-common.js';

const help = HELP_TOPICS.opform;

const ROUTE_FIELD: OpField = { name: 'route', label: 'BENEFICIARY ROUTE', width: 40, pick: { dir: 'beneficiary-routes', scope: { beneficiaryId: 'beneficiary' } }, hint: 'F4=PICK ROUTE' };
const PAYMENT_FIELD: OpField = { name: 'payment', label: 'PAYMENT', width: 40, pick: { dir: 'payments', scope: { accountId: 'account' } }, hint: 'F4=PICK PAYMENT' };

export const PAYMENT_OPS: Record<string, OpSpec> = {

  'beneficiary.create': {
    id: 'beneficiary.create', screenId: 'THBN01', title: 'Create beneficiary', command: 'beneficiary.create',
    fields: [
      MEMBER,
      textField('name', 'DISPLAY NAME', 40, { capacity: 200 }),
      textField('routing', 'ROUTING KIND', 20, { capacity: 40 }),
      textField('destination', 'MASKED DESTINATION', 30, { capacity: 80 }),
      textField('token', 'SIMULATED TOKEN', 30, { capacity: 80 }),
      textField('rails', 'ALLOWED RAILS', 40, { kind: 'idlist', hint: 'SPACE-SEPARATED RAIL CODES' }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const name = required(frame, 'name', 'DISPLAY NAME'); if (isOutcome(name)) return name;
      const routing = required(frame, 'routing', 'ROUTING KIND'); if (isOutcome(routing)) return routing;
      const destination = required(frame, 'destination', 'MASKED DESTINATION'); if (isOutcome(destination)) return destination;
      const token = required(frame, 'token', 'SIMULATED TOKEN'); if (isOutcome(token)) return token;
      const rails = idList(frame, 'rails', 'ALLOWED RAILS', { required: true }); if (!Array.isArray(rails)) return rails;
      return {
        command: { kind: 'beneficiary.create', memberId: member.memberId, expectedMemberVersion: member.version, displayName: name, routingKind: routing, maskedDestination: destination, simulatedToken: token, allowedRails: rails },
        lines: [{ label: 'Beneficiary', before: '', after: `${name} via ${routing}` }],
      };
    },
    help,
  },

  'beneficiary.verify': {
    id: 'beneficiary.verify', screenId: 'THBN02', title: 'Verify beneficiary', command: 'beneficiary.verify',
    fields: [
      MEMBER,
      { name: 'beneficiary', label: 'BENEFICIARY', width: 40, pick: { dir: 'beneficiaries', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      ROUTE_FIELD,
      { name: 'evidence', label: 'EVIDENCE', width: 40, pick: { dir: 'identity-evidence', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const beneficiary = recordRef(context, frame, 'beneficiary', 'beneficiary'); if (isOutcome(beneficiary)) return beneficiary;
      const route = recordRef(context, frame, 'route', 'beneficiary-route'); if (isOutcome(route)) return route;
      const evidence = required(frame, 'evidence', 'EVIDENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'beneficiary.verify', beneficiaryId: beneficiary.id, routeId: route.id, expectedFingerprint: route.fingerprint, evidenceId: evidence, approvalId: approvalId(frame) },
        lines: [{ label: 'Verify', before: '', after: `${beneficiary.id.slice(-16)} route ${route.id.slice(-16)}` }],
      };
    },
    help,
  },

  'beneficiary.routing.update': {
    id: 'beneficiary.routing.update', screenId: 'THBN03', title: 'Update beneficiary routing', command: 'beneficiary.routing.update',
    fields: [
      MEMBER,
      { name: 'beneficiary', label: 'BENEFICIARY', width: 40, pick: { dir: 'beneficiaries', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      ROUTE_FIELD,
      textField('routing', 'NEW ROUTING KIND', 20, { capacity: 40 }),
      textField('destination', 'MASKED DESTINATION', 30, { capacity: 80 }),
      textField('token', 'SIMULATED TOKEN', 30, { capacity: 80 }),
      dateField('effective', 'EFFECTIVE DATE'),
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const beneficiary = recordRef(context, frame, 'beneficiary', 'beneficiary'); if (isOutcome(beneficiary)) return beneficiary;
      const route = recordRef(context, frame, 'route', 'beneficiary-route'); if (isOutcome(route)) return route;
      const routing = required(frame, 'routing', 'NEW ROUTING KIND'); if (isOutcome(routing)) return routing;
      const destination = required(frame, 'destination', 'MASKED DESTINATION'); if (isOutcome(destination)) return destination;
      const token = required(frame, 'token', 'SIMULATED TOKEN'); if (isOutcome(token)) return token;
      const effective = date(frame, 'effective', 'EFFECTIVE DATE'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE DATE.');
      return {
        command: { kind: 'beneficiary.routing.update', beneficiaryId: beneficiary.id, expectedRouteFingerprint: route.fingerprint, routingKind: routing, maskedDestination: destination, simulatedToken: token, effectiveDate: effective, approvalId: approvalId(frame) },
        lines: [{ label: 'Routing', before: '', after: `${routing} ${destination}` }],
      };
    },
    help,
  },

  'beneficiary.retire': {
    id: 'beneficiary.retire', screenId: 'THBN04', title: 'Retire beneficiary', command: 'beneficiary.retire',
    fields: [
      MEMBER,
      { name: 'beneficiary', label: 'BENEFICIARY', width: 40, pick: { dir: 'beneficiaries', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      codeField('disposition', 'DEPENDENTS', { R: 'reject-if-active', C: 'cancel-drafts' }),
      REASON,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const beneficiary = recordRef(context, frame, 'beneficiary', 'beneficiary'); if (isOutcome(beneficiary)) return beneficiary;
      const disposition = code(frame, 'disposition', { R: 'reject-if-active', C: 'cancel-drafts' }, 'DEPENDENTS'); if (isOutcome(disposition)) return disposition;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      return {
        command: { kind: 'beneficiary.retire', beneficiaryId: beneficiary.id, expectedFingerprint: beneficiary.fingerprint, dependentDisposition: disposition as 'reject-if-active', reason },
        lines: [{ label: 'Retire', before: 'active', after: 'retired' }],
      };
    },
    help,
  },

  'payment.create': {
    id: 'payment.create', screenId: 'THPM01', title: 'Create payment', command: 'payment.create',
    fields: [
      ACCOUNT,
      { name: 'beneficiary', label: 'BENEFICIARY', width: 40, pick: { dir: 'beneficiaries' }, hint: 'F4=PICK' },
      ROUTE_FIELD,
      moneyField('amount', 'AMOUNT'),
      textField('rail', 'RAIL', 16, { capacity: 40 }),
      dateField('requested', 'REQUESTED DATE'),
      textField('calendar', 'CALENDAR VERSION', 16, { capacity: 40 }),
      instantField('cutoff', 'CUTOFF AT'),
      textField('reference', 'REFERENCE', 30, { capacity: 80 }),
      codeField('target', 'TARGET STATE', { D: 'draft', P: 'pending-approval' }),
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const route = recordRef(context, frame, 'route', 'beneficiary-route'); if (isOutcome(route)) return route;
      const amount = money(context, frame, 'amount', 'AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const rail = required(frame, 'rail', 'RAIL'); if (isOutcome(rail)) return rail;
      const requested = date(frame, 'requested', 'REQUESTED DATE'); if (isOutcome(requested) || requested === null) return requested ?? fieldProblem('requested', 'ENTER REQUESTED DATE.');
      const calendar = required(frame, 'calendar', 'CALENDAR VERSION'); if (isOutcome(calendar)) return calendar;
      const cutoff = instant(frame, 'cutoff', 'CUTOFF AT'); if (isOutcome(cutoff) || cutoff === null) return cutoff ?? fieldProblem('cutoff', 'ENTER CUTOFF AT.');
      const reference = required(frame, 'reference', 'REFERENCE'); if (isOutcome(reference)) return reference;
      const target = code(frame, 'target', { D: 'draft', P: 'pending-approval' }, 'TARGET STATE'); if (isOutcome(target)) return target;
      return {
        command: { kind: 'payment.create', sourceAccountId: account.accountId, expectedSourceVersion: account.version, beneficiaryRouteId: route.id, expectedRouteFingerprint: route.fingerprint, amount, rail, requestedDate: requested, calendarVersion: calendar, cutoffAt: cutoff, reference, targetState: target as 'draft' },
        lines: [{ label: 'Payment', before: '', after: `${amount.minorUnits} ${amount.currency} ${reference}` }],
      };
    },
    help,
  },

  'payment.submit': {
    id: 'payment.submit', screenId: 'THPM02', title: 'Submit payment', command: 'payment.submit',
    fields: [ACCOUNT, PAYMENT_FIELD],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const payment = recordRef(context, frame, 'payment', 'payment'); if (isOutcome(payment)) return payment;
      return {
        command: { kind: 'payment.submit', paymentId: payment.id, expectedVersion: Number(payment.record.version ?? 0) },
        lines: [{ label: 'Payment', before: 'draft', after: 'submitted' }],
      };
    },
    help,
  },

  'payment.approve_release': {
    id: 'payment.approve_release', screenId: 'THPM03', title: 'Approve and release payment', command: 'payment.approve_release',
    fields: [
      ACCOUNT, PAYMENT_FIELD,
      dateField('requested', 'REQUESTED DATE'), textField('calendar', 'CALENDAR VERSION', 16, { capacity: 40 }), instantField('cutoff', 'CUTOFF AT'),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const payment = recordRef(context, frame, 'payment', 'payment'); if (isOutcome(payment)) return payment;
      const requested = date(frame, 'requested', 'REQUESTED DATE'); if (isOutcome(requested) || requested === null) return requested ?? fieldProblem('requested', 'ENTER REQUESTED DATE.');
      const calendar = required(frame, 'calendar', 'CALENDAR VERSION'); if (isOutcome(calendar)) return calendar;
      const cutoff = instant(frame, 'cutoff', 'CUTOFF AT'); if (isOutcome(cutoff) || cutoff === null) return cutoff ?? fieldProblem('cutoff', 'ENTER CUTOFF AT.');
      return {
        command: { kind: 'payment.approve_release', paymentId: payment.id, expectedVersion: Number(payment.record.version ?? 0), requestedDate: requested, calendarVersion: calendar, cutoffAt: cutoff, approvalId: approvalId(frame) },
        lines: [{ label: 'Payment', before: 'pending-approval', after: 'released' }],
      };
    },
    help,
  },

  'payment.settle': {
    id: 'payment.settle', screenId: 'THPM04', title: 'Settle payment', command: 'payment.settle',
    fields: [ACCOUNT, PAYMENT_FIELD, textField('settlement', 'SETTLEMENT REFERENCE', 30, { capacity: 80 })],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const payment = recordRef(context, frame, 'payment', 'payment'); if (isOutcome(payment)) return payment;
      const settlement = required(frame, 'settlement', 'SETTLEMENT REFERENCE'); if (isOutcome(settlement)) return settlement;
      return {
        command: { kind: 'payment.settle', paymentId: payment.id, expectedVersion: Number(payment.record.version ?? 0), settlementReference: settlement },
        lines: [{ label: 'Payment', before: 'released', after: 'settled' }],
      };
    },
    help,
  },

  'payment.schedule.create': {
    id: 'payment.schedule.create', screenId: 'THSC01', title: 'Create payment schedule', command: 'payment.schedule.create',
    fields: [
      ACCOUNT,
      { name: 'beneficiary', label: 'BENEFICIARY', width: 40, pick: { dir: 'beneficiaries' }, hint: 'F4=PICK' },
      ROUTE_FIELD,
      moneyField('amount', 'AMOUNT'),
      codeField('frequency', 'FREQUENCY', { D: 'daily', W: 'weekly', M: 'monthly' }),
      numField('interval', 'INTERVAL'),
      dateField('start', 'START DATE'), dateField('end', 'END DATE'),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const route = recordRef(context, frame, 'route', 'beneficiary-route'); if (isOutcome(route)) return route;
      const amount = money(context, frame, 'amount', 'AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const frequency = code(frame, 'frequency', { D: 'daily', W: 'weekly', M: 'monthly' }, 'FREQUENCY'); if (isOutcome(frequency)) return frequency;
      const interval = num(frame, 'interval', 'INTERVAL', { min: 1 }); if (isOutcome(interval)) return interval;
      const start = date(frame, 'start', 'START DATE'); if (isOutcome(start) || start === null) return start ?? fieldProblem('start', 'ENTER START DATE.');
      const end = date(frame, 'end', 'END DATE'); if (isOutcome(end) || end === null) return end ?? fieldProblem('end', 'ENTER END DATE.');
      return {
        command: { kind: 'payment.schedule.create', sourceAccountId: account.accountId, expectedSourceVersion: account.version, beneficiaryRouteId: route.id, expectedRouteFingerprint: route.fingerprint, amount, frequency: frequency as 'daily', interval, startDate: start, endDate: end, approvalId: approvalId(frame) },
        lines: [{ label: 'Schedule', before: '', after: `${amount.minorUnits} ${amount.currency} ${frequency} x${interval}` }],
      };
    },
    help,
  },

  'payment.schedule.materialize': {
    id: 'payment.schedule.materialize', screenId: 'THSC02', title: 'Materialize occurrence', command: 'payment.schedule.materialize',
    fields: [
      OPT_ACCOUNT,
      { name: 'schedule', label: 'SCHEDULE', width: 40, pick: { dir: 'schedules', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      { name: 'occurrence', label: 'OCCURRENCE', width: 40, pick: { dir: 'occurrences', scope: { scheduleId: 'schedule' } }, hint: 'F4=PICK' },
    ],
    build(context, frame) {
      const occurrence = recordRef(context, frame, 'occurrence', 'schedule-occurrence'); if (isOutcome(occurrence)) return occurrence;
      return {
        command: { kind: 'payment.schedule.materialize', occurrenceId: occurrence.id, expectedFingerprint: occurrence.fingerprint },
        lines: [{ label: 'Occurrence', before: '', after: `${occurrence.id.slice(-20)} materializes` }],
      };
    },
    help,
  },

  'payment.occurrence.amend': {
    id: 'payment.occurrence.amend', screenId: 'THSC03', title: 'Amend occurrence', command: 'payment.occurrence.amend',
    fields: [
      { name: 'schedule', label: 'SCHEDULE', width: 40, pick: { dir: 'schedules', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      { name: 'occurrence', label: 'OCCURRENCE', width: 40, pick: { dir: 'occurrences', scope: { scheduleId: 'schedule' } }, hint: 'F4=PICK' },
      moneyField('amount', 'NEW AMOUNT'),
      dateField('date', 'NEW DATE'),
      OPT_ACCOUNT,
    ],
    build(context, frame) {
      const occurrence = recordRef(context, frame, 'occurrence', 'schedule-occurrence'); if (isOutcome(occurrence)) return occurrence;
      const amount = money(context, frame, 'amount', 'NEW AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const when = date(frame, 'date', 'NEW DATE'); if (isOutcome(when) || when === null) return when ?? fieldProblem('date', 'ENTER NEW DATE.');
      return {
        command: { kind: 'payment.occurrence.amend', occurrenceId: occurrence.id, expectedFingerprint: occurrence.fingerprint, newAmount: amount, newDate: when },
        lines: [{ label: 'Occurrence', before: '', after: `${amount.minorUnits} ${amount.currency} on ${when}` }],
      };
    },
    help,
  },

  'payment.schedule.end': {
    id: 'payment.schedule.end', screenId: 'THSC04', title: 'End schedule', command: 'payment.schedule.end',
    fields: [
      { name: 'schedule', label: 'SCHEDULE', width: 40, pick: { dir: 'schedules', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      dateField('from', 'END FROM DATE'),
      codeField('pending', 'PENDING', { C: 'cancel-planned', R: 'retain-released' }),
      APPROVAL,
      OPT_ACCOUNT,
    ],
    build(context, frame) {
      const schedule = recordRef(context, frame, 'schedule', 'payment-schedule'); if (isOutcome(schedule)) return schedule;
      const from = date(frame, 'from', 'END FROM DATE'); if (isOutcome(from) || from === null) return from ?? fieldProblem('from', 'ENTER END FROM DATE.');
      const pending = code(frame, 'pending', { C: 'cancel-planned', R: 'retain-released' }, 'PENDING'); if (isOutcome(pending)) return pending;
      return {
        command: { kind: 'payment.schedule.end', scheduleId: schedule.id, expectedFingerprint: schedule.fingerprint, endFromDate: from, pendingDisposition: pending as 'cancel-planned', approvalId: approvalId(frame) },
        lines: [{ label: 'Schedule', before: 'active', after: `ends ${from}` }],
      };
    },
    help,
  },

  'payment.cancel': {
    id: 'payment.cancel', screenId: 'THPM05', title: 'Cancel payment', command: 'payment.cancel',
    fields: [ACCOUNT, PAYMENT_FIELD, REASON],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const payment = recordRef(context, frame, 'payment', 'payment'); if (isOutcome(payment)) return payment;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      return {
        command: { kind: 'payment.cancel', paymentId: payment.id, expectedVersion: Number(payment.record.version ?? 0), reason },
        lines: [{ label: 'Payment', before: '', after: 'cancel requested' }],
      };
    },
    help,
  },

  'payment.return.resolve': {
    id: 'payment.return.resolve', screenId: 'THRT01', title: 'Resolve payment return', command: 'payment.return.resolve',
    fields: [
      ACCOUNT,
      { name: 'return', label: 'RETURN', width: 40, pick: { dir: 'returns', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      codeField('disposition', 'DISPOSITION', { C: 'credit-source', I: 'investigate' }),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const ret = recordRef(context, frame, 'return', 'payment-return'); if (isOutcome(ret)) return ret;
      const paymentId = cell(ret.record.payment_id);
      if (paymentId === '') return fieldProblem('return', 'RETURN HAS NO PAYMENT.');
      const disposition = code(frame, 'disposition', { C: 'credit-source', I: 'investigate' }, 'DISPOSITION'); if (isOutcome(disposition)) return disposition;
      return {
        command: { kind: 'payment.return.resolve', returnId: ret.id, expectedFingerprint: ret.fingerprint, paymentId, disposition: disposition as 'credit-source', approvalId: approvalId(frame) },
        lines: [{ label: 'Return', before: '', after: disposition }],
      };
    },
    help,
  },

  'card.replace': {
    id: 'card.replace', screenId: 'THCD01', title: 'Replace card', command: 'card.replace',
    fields: [
      ACCOUNT,
      { name: 'card', label: 'CARD', width: 40, pick: { dir: 'cards', scope: { accountId: 'account' } }, hint: 'F4=PICK CARD' },
      REASON,
      { name: 'identity', label: 'IDENTITY EVIDENCE', width: 40, pick: { dir: 'identity-evidence' }, hint: 'F4=PICK' },
      { name: 'destination', label: 'DELIVERY DESTINATION', width: 40, pick: { dir: 'address-destinations' }, hint: 'F4=PICK' },
      { name: 'address', label: 'DELIVERY ADDRESS', width: 40, pick: { dir: 'addresses' }, hint: 'F4=PICK' },
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const card = recordRef(context, frame, 'card', 'card'); if (isOutcome(card)) return card;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      const identity = required(frame, 'identity', 'IDENTITY EVIDENCE'); if (isOutcome(identity)) return identity;
      const destination = required(frame, 'destination', 'DELIVERY DESTINATION'); if (isOutcome(destination)) return destination;
      const address = required(frame, 'address', 'DELIVERY ADDRESS'); if (isOutcome(address)) return address;
      return {
        command: { kind: 'card.replace', cardId: card.id, expectedFingerprint: card.fingerprint, reason, identityEvidenceId: identity, deliveryDestinationId: destination, deliveryAddressId: address },
        lines: [{ label: 'Card', before: `****${cell(card.record.last_four)}`, after: 'replaced' }],
      };
    },
    help,
  },

  'card.lock.update': {
    id: 'card.lock.update', screenId: 'THCD02', title: 'Card lock update', command: 'card.lock.update',
    fields: [
      ACCOUNT,
      { name: 'card', label: 'CARD', width: 40, pick: { dir: 'cards', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      codeField('state', 'STATE', { L: 'locked', U: 'unlocked' }),
      textField('authority', 'AUTHORITY', 30, { capacity: 80 }),
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const card = recordRef(context, frame, 'card', 'card'); if (isOutcome(card)) return card;
      const state = code(frame, 'state', { L: 'locked', U: 'unlocked' }, 'STATE'); if (isOutcome(state)) return state;
      const authority = required(frame, 'authority', 'AUTHORITY'); if (isOutcome(authority)) return authority;
      return {
        command: { kind: 'card.lock.update', cardId: card.id, expectedFingerprint: card.fingerprint, requestedState: state as 'locked', authority },
        lines: [{ label: 'Card', before: '', after: state }],
      };
    },
    help,
  },

  'card.limit.update': {
    id: 'card.limit.update', screenId: 'THCD03', title: 'Update card limit', command: 'card.limit.update',
    fields: [
      ACCOUNT,
      { name: 'card', label: 'CARD', width: 40, pick: { dir: 'cards', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      codeField('kind', 'LIMIT KIND', { D: 'daily-purchase', C: 'cash', O: 'online' }),
      moneyField('amount', 'AMOUNT'),
      instantField('effective', 'EFFECTIVE AT'),
      instantField('expires', 'EXPIRES AT', false),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const card = recordRef(context, frame, 'card', 'card'); if (isOutcome(card)) return card;
      const kind = code(frame, 'kind', { D: 'daily-purchase', C: 'cash', O: 'online' }, 'LIMIT KIND'); if (isOutcome(kind)) return kind;
      const amount = money(context, frame, 'amount', 'AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const effective = instant(frame, 'effective', 'EFFECTIVE AT'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE AT.');
      const expires = instant(frame, 'expires', 'EXPIRES AT'); if (isOutcome(expires)) return expires;
      return {
        command: { kind: 'card.limit.update', cardId: card.id, expectedFingerprint: card.fingerprint, limitKind: kind as 'daily-purchase', amount, effectiveAt: effective, expiresAt: expires, approvalId: approvalId(frame) },
        lines: [{ label: 'Limit', before: '', after: `${kind} ${amount.minorUnits} ${amount.currency}` }],
      };
    },
    help,
  },

  'dispute.open': {
    id: 'dispute.open', screenId: 'THDP01', title: 'Open dispute', command: 'dispute.open',
    fields: [
      ACCOUNT,
      { name: 'card', label: 'CARD', width: 40, pick: { dir: 'cards', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      { name: 'txn', label: 'CARD TRANSACTION', width: 40, pick: { dir: 'card-transactions', scope: { cardId: 'card' } }, hint: 'F4=PICK' },
      REASON,
      moneyField('amount', 'ASSERTED AMOUNT'),
      textField('evidence', 'EVIDENCE IDS', 58, { kind: 'idlist', hint: 'SPACE-SEPARATED EVIDENCE IDS' }),
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const txn = recordRef(context, frame, 'txn', 'card-transaction'); if (isOutcome(txn)) return txn;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      const amount = money(context, frame, 'amount', 'ASSERTED AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const evidence = idList(frame, 'evidence', 'EVIDENCE IDS', { required: true }); if (!Array.isArray(evidence)) return evidence;
      return {
        command: { kind: 'dispute.open', cardTransactionId: txn.id, expectedFingerprint: txn.fingerprint, reason, assertedAmount: amount, evidenceIds: evidence },
        lines: [{ label: 'Dispute', before: '', after: `${amount.minorUnits} ${amount.currency}` }],
      };
    },
    help,
  },

  'dispute.provisional_credit.issue': {
    id: 'dispute.provisional_credit.issue', screenId: 'THDP02', title: 'Issue provisional credit', command: 'dispute.provisional_credit.issue',
    fields: [
      ACCOUNT,
      { name: 'dispute', label: 'DISPUTE', width: 40, pick: { dir: 'disputes', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      moneyField('amount', 'CREDIT AMOUNT'),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const dispute = recordRef(context, frame, 'dispute', 'dispute'); if (isOutcome(dispute)) return dispute;
      const amount = money(context, frame, 'amount', 'CREDIT AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      return {
        command: { kind: 'dispute.provisional_credit.issue', disputeId: dispute.id, expectedFingerprint: dispute.fingerprint, amount, approvalId: approvalId(frame) },
        lines: [{ label: 'Credit', before: '', after: `${amount.minorUnits} ${amount.currency}` }],
      };
    },
    help,
  },

  'dispute.evidence.submit': {
    id: 'dispute.evidence.submit', screenId: 'THDP03', title: 'Submit dispute evidence', command: 'dispute.evidence.submit',
    fields: [
      ACCOUNT,
      { name: 'dispute', label: 'DISPUTE', width: 40, pick: { dir: 'disputes', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      textField('versions', 'DOCUMENT VERSION IDS', 58, { kind: 'idlist', hint: 'SPACE-SEPARATED' }),
      instantField('deadline', 'DEADLINE'),
      textField('recipient', 'RECIPIENT', 30, { capacity: 80 }),
      textField('channel', 'CHANNEL', 16, { capacity: 40 }),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const dispute = recordRef(context, frame, 'dispute', 'dispute'); if (isOutcome(dispute)) return dispute;
      const versions = idList(frame, 'versions', 'DOCUMENT VERSION IDS', { required: true }); if (!Array.isArray(versions)) return versions;
      const deadline = instant(frame, 'deadline', 'DEADLINE'); if (isOutcome(deadline) || deadline === null) return deadline ?? fieldProblem('deadline', 'ENTER DEADLINE.');
      const recipient = required(frame, 'recipient', 'RECIPIENT'); if (isOutcome(recipient)) return recipient;
      const channel = required(frame, 'channel', 'CHANNEL'); if (isOutcome(channel)) return channel;
      return {
        command: { kind: 'dispute.evidence.submit', disputeId: dispute.id, expectedFingerprint: dispute.fingerprint, documentVersionIds: versions, deadline, recipient, channel, approvalId: approvalId(frame) },
        lines: [{ label: 'Evidence', before: '', after: `${versions.length} version(s) to ${recipient}` }],
      };
    },
    help,
  },

  'dispute.settle': {
    id: 'dispute.settle', screenId: 'THDP04', title: 'Settle dispute', command: 'dispute.settle',
    fields: [
      ACCOUNT,
      { name: 'dispute', label: 'DISPUTE', width: 40, pick: { dir: 'disputes', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      codeField('decision', 'DECISION', { A: 'approved', D: 'denied' }),
      moneyField('amount', 'FINAL AMOUNT'),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const dispute = recordRef(context, frame, 'dispute', 'dispute'); if (isOutcome(dispute)) return dispute;
      const decision = code(frame, 'decision', { A: 'approved', D: 'denied' }, 'DECISION'); if (isOutcome(decision)) return decision;
      const amount = money(context, frame, 'amount', 'FINAL AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      return {
        command: { kind: 'dispute.settle', disputeId: dispute.id, expectedFingerprint: dispute.fingerprint, decision: decision as 'approved', finalAmount: amount, approvalId: approvalId(frame) },
        lines: [{ label: 'Settle', before: '', after: `${decision} ${amount.minorUnits} ${amount.currency}` }],
      };
    },
    help,
  },

  'loan.application.prepare': {
    id: 'loan.application.prepare', screenId: 'THLN01', title: 'Prepare loan application', command: 'loan.application.prepare',
    fields: [
      MEMBER,
      { name: 'product', label: 'LOAN PRODUCT', width: 40, pick: { dir: 'products' }, hint: 'F4=PICK' },
      moneyField('amount', 'REQUESTED AMOUNT'),
      numField('term', 'TERM MONTHS'),
      textField('purpose', 'PURPOSE', 50, { capacity: 200 }),
      textField('evidence', 'EVIDENCE IDS', 58, { kind: 'idlist', hint: 'SPACE-SEPARATED' }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const product = required(frame, 'product', 'LOAN PRODUCT'); if (isOutcome(product)) return product;
      const amount = money(context, frame, 'amount', 'REQUESTED AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const term = num(frame, 'term', 'TERM MONTHS', { min: 1 }); if (isOutcome(term)) return term;
      const purpose = required(frame, 'purpose', 'PURPOSE'); if (isOutcome(purpose)) return purpose;
      const evidence = idList(frame, 'evidence', 'EVIDENCE IDS', { required: true }); if (!Array.isArray(evidence)) return evidence;
      return {
        command: { kind: 'loan.application.prepare', memberId: member.memberId, expectedMemberVersion: member.version, productId: product, requestedAmount: amount, termMonths: term, purpose, evidenceIds: evidence },
        lines: [{ label: 'Application', before: '', after: `${amount.minorUnits} ${amount.currency} over ${term}m` }],
      };
    },
    help,
  },

  'loan.payment.allocate': {
    id: 'loan.payment.allocate', screenId: 'THLN02', title: 'Allocate loan payment', command: 'loan.payment.allocate',
    fields: [
      { name: 'loan', label: 'LOAN', width: 40, pick: { dir: 'loans', scope: { accountId: 'account' } }, hint: 'F4=PICK LOAN' },
      { name: 'funds', label: 'RECEIVED FUNDS REF', width: 40, pick: { dir: 'received-funds' }, hint: 'F4=PICK' },
      moneyField('amount', 'AMOUNT'),
      codeField('policy', 'ALLOCATION', { S: 'fees-interest-principal', H: 'fees-interest-principal-hold-remainder' }),
      OPT_ACCOUNT,
    ],
    build(context, frame) {
      const loan = recordRef(context, frame, 'loan', 'loan'); if (isOutcome(loan)) return loan;
      const funds = required(frame, 'funds', 'RECEIVED FUNDS REF'); if (isOutcome(funds)) return funds;
      const amount = money(context, frame, 'amount', 'AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const policy = code(frame, 'policy', { S: 'fees-interest-principal', H: 'fees-interest-principal-hold-remainder' }, 'ALLOCATION'); if (isOutcome(policy)) return policy;
      return {
        command: { kind: 'loan.payment.allocate', loanId: loan.id, expectedFingerprint: loan.fingerprint, receivedFundsReference: funds, amount, allocationPolicy: policy as 'fees-interest-principal' },
        lines: [{ label: 'Allocate', before: '', after: `${amount.minorUnits} ${amount.currency}` }],
      };
    },
    help,
  },

  'loan.payoff.quote': {
    id: 'loan.payoff.quote', screenId: 'THLN03', title: 'Loan payoff quote', command: 'loan.payoff.quote',
    fields: [
      { name: 'loan', label: 'LOAN', width: 40, pick: { dir: 'loans', scope: { accountId: 'account' } }, hint: 'F4=PICK LOAN' },
      dateField('payoff', 'PAYOFF DATE'),
      POLICY,
      OPT_ACCOUNT,
    ],
    build(context, frame) {
      const loan = recordRef(context, frame, 'loan', 'loan'); if (isOutcome(loan)) return loan;
      const payoff = date(frame, 'payoff', 'PAYOFF DATE'); if (isOutcome(payoff) || payoff === null) return payoff ?? fieldProblem('payoff', 'ENTER PAYOFF DATE.');
      const policy = required(frame, 'policy', 'POLICY VERSION'); if (isOutcome(policy)) return policy;
      return {
        command: { kind: 'loan.payoff.quote', loanId: loan.id, expectedFingerprint: loan.fingerprint, payoffDate: payoff, policyVersionId: policy },
        lines: [{ label: 'Quote', before: '', after: `payoff at ${payoff}` }],
      };
    },
    help,
  },

  'reconciliation.suspense.investigate': {
    id: 'reconciliation.suspense.investigate', screenId: 'THSU01', title: 'Investigate suspense', command: 'reconciliation.suspense.investigate',
    fields: [
      { name: 'suspense', label: 'SUSPENSE ITEM', width: 40, pick: { dir: 'suspense' }, hint: 'F4=PICK' },
      textField('evidence', 'EVIDENCE REFERENCES', 58, { kind: 'idlist', hint: 'SPACE-SEPARATED' }),
      { name: 'account', label: 'PROPOSED ACCOUNT', width: 10, required: false, pick: { dir: 'accounts' }, hint: 'OPTIONAL' },
    ],
    build(context, frame) {
      const suspense = recordRef(context, frame, 'suspense', 'suspense-item'); if (isOutcome(suspense)) return suspense;
      const evidence = idList(frame, 'evidence', 'EVIDENCE REFERENCES', { required: true }); if (!Array.isArray(evidence)) return evidence;
      const account = optAccountRef(context, frame); if (isOutcome(account)) return account;
      return {
        command: { kind: 'reconciliation.suspense.investigate', suspenseId: suspense.id, expectedFingerprint: suspense.fingerprint, evidenceReferences: evidence, proposedAccountId: account?.accountId ?? null },
        lines: [{ label: 'Suspense', before: 'open', after: 'investigated' }],
      };
    },
    help,
  },

  'reconciliation.suspense.clear': {
    id: 'reconciliation.suspense.clear', screenId: 'THSU02', title: 'Clear suspense', command: 'reconciliation.suspense.clear',
    fields: [
      { name: 'suspense', label: 'SUSPENSE ITEM', width: 40, pick: { dir: 'suspense' }, hint: 'F4=PICK' },
      { name: 'account', label: 'DESTINATION ACCOUNT', width: 10, pick: { dir: 'accounts' }, hint: 'F4=PICK' },
      moneyField('amount', 'AMOUNT'),
      textField('evidence', 'EVIDENCE REFERENCE', 40, { capacity: 200 }),
      APPROVAL,
    ],
    build(context, frame) {
      const suspense = recordRef(context, frame, 'suspense', 'suspense-item'); if (isOutcome(suspense)) return suspense;
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const amount = money(context, frame, 'amount', 'AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const evidence = required(frame, 'evidence', 'EVIDENCE REFERENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'reconciliation.suspense.clear', suspenseId: suspense.id, expectedFingerprint: suspense.fingerprint, destinationAccountId: account.accountId, amount, evidenceReference: evidence, approvalId: approvalId(frame) },
        lines: [{ label: 'Clear', before: '', after: `${amount.minorUnits} ${amount.currency} to ${account.number}` }],
      };
    },
    help,
  },

  'batch.import': {
    id: 'batch.import', screenId: 'THBI01', title: 'Import batch', command: 'batch.import',
    fields: [
      { name: 'version', label: 'INPUT VERSION', width: 40, pick: { dir: 'documents' }, hint: 'F4=PICK INPUT DOCUMENT' },
      textField('digest', 'INPUT DIGEST', 64, { capacity: 64 }),
      textField('number', 'BATCH NUMBER', 12, { capacity: 40 }),
      codeField('kind', 'KIND', { C: 'contact-update', F: 'fee-refund' }),
      textField('currency', 'CURRENCY', 3, { required: false, capacity: 3, hint: 'FOR REFUND BATCHES' }),
    ],
    build(_context, frame) {
      const version = required(frame, 'version', 'INPUT VERSION'); if (isOutcome(version)) return version;
      const digest = required(frame, 'digest', 'INPUT DIGEST'); if (isOutcome(digest)) return digest;
      const number = required(frame, 'number', 'BATCH NUMBER'); if (isOutcome(number)) return number;
      const kind = code(frame, 'kind', { C: 'contact-update', F: 'fee-refund' }, 'KIND'); if (isOutcome(kind)) return kind;
      const currency = upper(entered(frame, 'currency'));
      return {
        command: { kind: 'batch.import', documentVersionId: version, inputDigest: digest, batchNumber: number, batchKind: kind as 'contact-update', currency: currency === '' ? null : currency },
        lines: [{ label: 'Batch', before: '', after: `${number} (${kind})` }],
      };
    },
    help,
  },

  'loan.close': {
    id: 'loan.close', screenId: 'THLN04', title: 'Close loan', command: 'loan.close',
    fields: [
      { name: 'loan', label: 'LOAN', width: 40, pick: { dir: 'loans', scope: { accountId: 'account' } }, hint: 'F4=PICK LOAN' },
      { name: 'evidence', label: 'PAYOFF EVIDENCE', width: 40, pick: { dir: 'identity-evidence' }, hint: 'F4=PICK' },
      APPROVAL,
      OPT_ACCOUNT,
    ],
    build(context, frame) {
      const loan = recordRef(context, frame, 'loan', 'loan'); if (isOutcome(loan)) return loan;
      const evidence = required(frame, 'evidence', 'PAYOFF EVIDENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'loan.close', loanId: loan.id, expectedFingerprint: loan.fingerprint, payoffEvidenceId: evidence, approvalId: approvalId(frame) },
        lines: [{ label: 'Loan', before: 'open', after: 'closed' }],
      };
    },
    help,
  },

  'document.loan_closure.issue': {
    id: 'document.loan_closure.issue', screenId: 'THLN05', title: 'Issue loan closure document', command: 'document.loan_closure.issue',
    fields: [
      { name: 'loan', label: 'LOAN', width: 40, pick: { dir: 'loans' }, hint: 'F4=PICK LOAN' },
      { name: 'closure', label: 'CLOSURE RECORD', width: 40, pick: { dir: 'loan-closures', scope: { loanId: 'loan' } }, hint: 'F4=PICK CLOSURE' },
      { name: 'template', label: 'TEMPLATE VERSION', width: 40, pick: { dir: 'documents' }, hint: 'F4=PICK TEMPLATE' },
      textField('recipient', 'RECIPIENT PARTY ID', 40),
      codeField('doctype', 'DOCUMENT TYPE', { C: 'loan-closure-confirmation', L: 'simulated-lien-release' }),
      APPROVAL,
    ],
    build(context, frame) {
      const loan = recordRef(context, frame, 'loan', 'loan'); if (isOutcome(loan)) return loan;
      const closure = recordRef(context, frame, 'closure', 'loan-closure'); if (isOutcome(closure)) return closure;
      const template = required(frame, 'template', 'TEMPLATE VERSION'); if (isOutcome(template)) return template;
      const recipient = required(frame, 'recipient', 'RECIPIENT PARTY ID'); if (isOutcome(recipient)) return recipient;
      const doctype = code(frame, 'doctype', { C: 'loan-closure-confirmation', L: 'simulated-lien-release' }, 'DOCUMENT TYPE'); if (isOutcome(doctype)) return doctype;
      return {
        command: { kind: 'document.loan_closure.issue', loanId: loan.id, expectedClosureFingerprint: closure.fingerprint, templateVersionId: template, recipientPartyId: recipient, documentType: doctype as 'loan-closure-confirmation', approvalId: approvalId(frame) },
        lines: [{ label: 'Issue', before: '', after: `${doctype} to ${recipient}` }],
      };
    },
    help,
  },
};
