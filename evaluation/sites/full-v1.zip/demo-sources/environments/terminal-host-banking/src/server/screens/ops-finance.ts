import {
  ORGANIZATION_TAX_CLASSIFICATIONS, queryMemberMergePlan,
} from '@computer-use/financial-database/services';

import { failure } from '../host/frames.js';
import { upper } from '../host/format.js';
import { cell, findMember, isOutcome, readMember } from './common.js';
import { HELP_TOPICS } from './help-text.js';
import { code, date, entered, fieldProblem, groupRows, instant, money, num, required, type OpSpec } from './ops.js';
import {
  ACCOUNT, APPROVAL, approvalId, accountRef, caseRef, codeField, dateField, flagField, instantField, memberRef, MEMBER, moneyField, numField,
  POLICY, recordRef, REASON, textField,
} from './ops-common.js';

const help = HELP_TOPICS.opform;

const TAX_CODES: Record<string, string> = Object.fromEntries([...new Set(Object.values(ORGANIZATION_TAX_CLASSIFICATIONS))].map((name, index) => [String.fromCharCode(65 + index), name]));

export const FINANCE_OPS: Record<string, OpSpec> = {

  'member.merge': {
    id: 'member.merge', screenId: 'THMG01', title: 'Apply member merge', command: 'member.merge',
    fields: [
      { name: 'plan', label: 'MERGE PLAN', width: 40, pick: { dir: 'merge-plans' }, hint: 'F4=PICK REVIEWED PLAN' },
      APPROVAL,
    ],
    build(context, frame) {
      const planId = required(frame, 'plan', 'MERGE PLAN'); if (isOutcome(planId)) return planId;
      const plan = context.read((database, datasetId) => database.prepare('SELECT state,source_member_id,target_member_id FROM member_merge_plans WHERE dataset_id=? AND id=?').get(datasetId, planId) as Record<string, unknown> | undefined);
      if (plan === undefined) return fieldProblem('plan', 'MERGE PLAN NOT FOUND.');
      const state = String(plan.state);
      const sourceId = String(plan.source_member_id);
      const targetId = String(plan.target_member_id);
      const inventory = context.svc((store, ctx) => queryMemberMergePlan(store, ctx, planId));
      if (inventory.kind !== 'found') return { kind: 'stay', message: failure(upper(inventory.message)), error: 'plan' };
      const relationshipAccountIds = (inventory.tables.find((table) => table.table === 'accounts')?.records ?? []).map((record) => String(record.key.id));
      return {
        command: {
          kind: 'member.merge', mergePlanId: planId, sourceMemberId: sourceId, targetMemberId: targetId,
          expectedSourceVersion: readMember(context, sourceId).member.version, expectedTargetVersion: readMember(context, targetId).member.version,
          relationshipAccountIds, expectedInventoryFingerprint: inventory.fingerprint, approvalId: approvalId(frame),
        },
        lines: [
          { label: 'Plan', before: '', after: `${planId} (${state})` },
          { label: 'Merge', before: inventory.sourceMemberId, after: inventory.targetMemberId },
          { label: 'Inventory', before: '', after: `${inventory.rowCount} rows, ${relationshipAccountIds.length} accounts, fp ${inventory.fingerprint.slice(0, 16)}...` },
        ],
      };
    },
    help,
  },

  'member.deceased.record': {
    id: 'member.deceased.record', screenId: 'THDC10', title: 'Record member deceased', command: 'member.deceased.record',
    fields: [
      MEMBER,
      { name: 'evidence', label: 'EVIDENCE', width: 40, pick: { dir: 'identity-evidence', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      dateField('effective', 'EFFECTIVE DATE'),
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const evidence = required(frame, 'evidence', 'EVIDENCE'); if (isOutcome(evidence)) return evidence;
      const effective = date(frame, 'effective', 'EFFECTIVE DATE'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE DATE.');
      return {
        command: { kind: 'member.deceased.record', memberId: member.memberId, expectedVersion: member.version, evidenceId: evidence, effectiveDate: effective, approvalId: approvalId(frame) },
        lines: [{ label: 'Member', before: 'active', after: 'deceased' }],
      };
    },
    help,
  },

  'member.beneficial_owners.update': {
    id: 'member.beneficial_owners.update', screenId: 'THBO01', title: 'Update beneficial owners', command: 'member.beneficial_owners.update',
    fields: [
      MEMBER,
      {
        name: 'owners', label: 'OWNERS', width: 0, kind: 'group', rows: 4,
        columns: [
          { name: 'member', label: 'OWNER MEMBER', width: 10, pick: { dir: 'members' } },
          { name: 'bps', label: 'BPS', width: 6, kind: 'num' },
          { name: 'control', label: 'CTL', width: 1, kind: 'flag' },
          { name: 'evidence', label: 'EVIDENCE', width: 26, pick: { dir: 'identity-evidence', scope: { memberId: 'member' } } },
        ],
      },
      dateField('effective', 'EFFECTIVE DATE'),
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const owners = groupRows(frame, 'owners', 4, (_index, v) => {
        const ownerMember = v('member');
        if (ownerMember === '' && v('bps') === '') return null;
        const found = findMember(context, ownerMember);
        if (found === undefined) return fieldProblem('owners', `OWNER MEMBER ${upper(ownerMember)} NOT FOUND.`);
        const bps = /^\d+$/u.test(v('bps')) ? Number(v('bps')) : NaN;
        if (!Number.isSafeInteger(bps) || bps < 0) return fieldProblem('owners', 'ENTER OWNERSHIP BPS AS WHOLE DIGITS.');
        return { memberId: found.id, ownershipBps: bps, isControlPerson: upper(v('control')) === 'Y', evidenceId: v('evidence') };
      });
      if (isOutcome(owners)) return owners;
      const effective = date(frame, 'effective', 'EFFECTIVE DATE'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE DATE.');
      return {
        command: { kind: 'member.beneficial_owners.update', organizationMemberId: member.memberId, expectedVersion: member.version, owners, effectiveDate: effective, approvalId: approvalId(frame) },
        lines: [{ label: 'Owners', before: '', after: `${owners.length} owner(s)` }],
      };
    },
    help,
  },

  'member.tax_classification.update': {
    id: 'member.tax_classification.update', screenId: 'THTX01', title: 'Update tax classification', command: 'member.tax_classification.update',
    fields: [
      MEMBER,
      codeField('classification', 'CLASSIFICATION', TAX_CODES),
      numField('year', 'EFFECTIVE YEAR'),
      { name: 'evidence', label: 'EVIDENCE', width: 40, pick: { dir: 'identity-evidence', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const classification = code(frame, 'classification', TAX_CODES, 'CLASSIFICATION'); if (isOutcome(classification)) return classification;
      const year = num(frame, 'year', 'EFFECTIVE YEAR', { min: 1900, max: 9999 }); if (isOutcome(year)) return year;
      const evidence = required(frame, 'evidence', 'EVIDENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'member.tax_classification.update', memberId: member.memberId, expectedVersion: member.version, classification, effectiveYear: year, evidenceId: evidence, approvalId: approvalId(frame) },
        lines: [{ label: 'Classification', before: '', after: `${classification} from ${year}` }],
      };
    },
    help,
  },

  'account.product.convert': {
    id: 'account.product.convert', screenId: 'THPC01', title: 'Convert account product', command: 'account.product.convert',
    fields: [
      ACCOUNT,
      { name: 'product', label: 'TARGET PRODUCT', width: 40, pick: { dir: 'products' }, hint: 'F4=PICK' },
      dateField('effective', 'EFFECTIVE DATE'),
      flagField('disclosure', 'FEE DISCLOSURE ACCEPTED', true),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const product = required(frame, 'product', 'TARGET PRODUCT'); if (isOutcome(product)) return product;
      const effective = date(frame, 'effective', 'EFFECTIVE DATE'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE DATE.');
      const disclosure = code(frame, 'disclosure', { Y: 'true', N: 'false' }, 'FEE DISCLOSURE'); if (isOutcome(disclosure)) return disclosure;
      return {
        command: { kind: 'account.product.convert', accountId: account.accountId, expectedVersion: account.version, targetProductId: product, effectiveDate: effective, feeDisclosureAccepted: disclosure === 'true', approvalId: approvalId(frame) },
        lines: [{ label: 'Account', before: '', after: account.number }, { label: 'Product', before: '', after: product }],
      };
    },
    help,
  },

  'account.owner.add': {
    id: 'account.owner.add', screenId: 'THOA01', title: 'Add account owner', command: 'account.owner.add',
    fields: [
      ACCOUNT,
      { name: 'newmember', label: 'NEW MEMBER', width: 10, pick: { dir: 'members' }, hint: 'NUMBER OR F4' },
      codeField('role', 'ROLE', { O: 'owner', J: 'joint-owner' }),
      dateField('effective', 'EFFECTIVE DATE'),
      { name: 'identity', label: 'IDENTITY EVIDENCE', width: 40, pick: { dir: 'identity-evidence', scope: { memberId: 'newmember' } }, hint: 'F4=PICK' },
      { name: 'consent', label: 'CONSENT', width: 40, pick: { dir: 'consents', scope: { memberId: 'newmember' } }, hint: 'F4=PICK' },
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const added = memberRef(context, frame, 'newmember'); if (isOutcome(added)) return added;
      const role = code(frame, 'role', { O: 'owner', J: 'joint-owner' }, 'ROLE'); if (isOutcome(role)) return role;
      const effective = date(frame, 'effective', 'EFFECTIVE DATE'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE DATE.');
      const identity = required(frame, 'identity', 'IDENTITY EVIDENCE'); if (isOutcome(identity)) return identity;
      const consent = required(frame, 'consent', 'CONSENT'); if (isOutcome(consent)) return consent;
      return {
        command: { kind: 'account.owner.add', accountId: account.accountId, expectedVersion: account.version, memberId: added.memberId, role: role as 'owner', effectiveDate: effective, identityEvidenceId: identity, consentId: consent, approvalId: approvalId(frame) },
        lines: [{ label: 'Add', before: '', after: `${added.number} as ${role}` }],
      };
    },
    help,
  },

  'account.signer.remove': {
    id: 'account.signer.remove', screenId: 'THSR01', title: 'Remove account signer', command: 'account.signer.remove',
    fields: [
      ACCOUNT,
      { name: 'signer', label: 'SIGNER MEMBER', width: 10, pick: { dir: 'members' }, hint: 'NUMBER OR F4' },
      instantField('when', 'EFFECTIVE AT'),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const signer = memberRef(context, frame, 'signer'); if (isOutcome(signer)) return signer;
      const when = instant(frame, 'when', 'EFFECTIVE AT'); if (isOutcome(when) || when === null) return when ?? fieldProblem('when', 'ENTER EFFECTIVE AT.');
      return {
        command: { kind: 'account.signer.remove', accountId: account.accountId, expectedVersion: account.version, signerMemberId: signer.memberId, effectiveAt: when, approvalId: approvalId(frame) },
        lines: [{ label: 'Remove', before: '', after: `signer ${signer.number}` }],
      };
    },
    help,
  },

  'account.overdraft_limit.update': {
    id: 'account.overdraft_limit.update', screenId: 'THOD01', title: 'Update overdraft limit', command: 'account.overdraft_limit.update',
    fields: [
      ACCOUNT,
      { name: 'facility', label: 'FACILITY', width: 40, required: false, pick: { dir: 'facilities', scope: { accountId: 'account' } }, hint: 'BLANK=NONE, F4=PICK' },
      moneyField('limit', 'NEW LIMIT'),
      dateField('effective', 'EFFECTIVE DATE'),
      instantField('expires', 'EXPIRES AT', false),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const facilityId = entered(frame, 'facility');
      let facilityFingerprint: string | null = null;
      if (facilityId !== '') {
        const found = recordRef(context, frame, 'facility', 'facility'); if (isOutcome(found)) return found;
        facilityFingerprint = found.fingerprint;
      }
      const limit = money(context, frame, 'limit', 'NEW LIMIT'); if (isOutcome(limit) || limit === null) return limit ?? fieldProblem('limit', 'ENTER THE LIMIT.');
      const effective = date(frame, 'effective', 'EFFECTIVE DATE'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE DATE.');
      const expires = instant(frame, 'expires', 'EXPIRES AT'); if (isOutcome(expires)) return expires;
      return {
        command: { kind: 'account.overdraft_limit.update', accountId: account.accountId, expectedVersion: account.version, expectedFacilityFingerprint: facilityFingerprint, limit, effectiveDate: effective, expiresAt: expires, approvalId: approvalId(frame) },
        lines: [{ label: 'Limit', before: '', after: `${limit.minorUnits} ${limit.currency}` }],
      };
    },
    help,
  },

  'account.hold.place': {
    id: 'account.hold.place', screenId: 'THHL01', title: 'Place hold', command: 'account.hold.place',
    fields: [ACCOUNT, moneyField('amount', 'HOLD AMOUNT'), REASON, instantField('expires', 'EXPIRES AT'), textField('authority', 'RELEASE AUTHORITY', 30, { capacity: 80 })],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const amount = money(context, frame, 'amount', 'HOLD AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      const expires = instant(frame, 'expires', 'EXPIRES AT'); if (isOutcome(expires) || expires === null) return expires ?? fieldProblem('expires', 'ENTER EXPIRES AT.');
      const authority = required(frame, 'authority', 'RELEASE AUTHORITY'); if (isOutcome(authority)) return authority;
      return {
        command: { kind: 'account.hold.place', accountId: account.accountId, expectedVersion: account.version, amount, reason, expiresAt: expires, releaseAuthority: authority },
        lines: [{ label: 'Hold', before: '', after: `${amount.minorUnits} ${amount.currency} on ${account.number}` }],
      };
    },
    help,
  },

  'account.hold.release': {
    id: 'account.hold.release', screenId: 'THHL02', title: 'Release hold', command: 'account.hold.release',
    fields: [
      ACCOUNT,
      { name: 'hold', label: 'HOLD', width: 40, pick: { dir: 'holds', scope: { accountId: 'account' } }, hint: 'F4=PICK HOLD' },
      numField('amount', 'AMOUNT MINOR UNITS'),
      textField('authority', 'RELEASE AUTHORITY', 30, { capacity: 80 }),
      textField('evidence', 'EVIDENCE REFERENCE', 40, { capacity: 200 }),
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const hold = recordRef(context, frame, 'hold', 'hold'); if (isOutcome(hold)) return hold;
      const amount = num(frame, 'amount', 'AMOUNT MINOR UNITS', { min: 1 }); if (isOutcome(amount)) return amount;
      const authority = required(frame, 'authority', 'RELEASE AUTHORITY'); if (isOutcome(authority)) return authority;
      const evidence = required(frame, 'evidence', 'EVIDENCE REFERENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'account.hold.release', holdId: hold.id, expectedFingerprint: hold.fingerprint, amountMinorUnits: amount, releaseAuthority: authority, evidenceReference: evidence },
        lines: [{ label: 'Release', before: '', after: `hold ${hold.id.slice(-20)}` }],
      };
    },
    help,
  },

  'account.restriction.apply': {
    id: 'account.restriction.apply', screenId: 'THRS01', title: 'Apply restriction', command: 'account.restriction.apply',
    fields: [
      ACCOUNT,
      codeField('rtype', 'KIND', { D: 'debit-block', C: 'credit-block', X: 'closure-block', F: 'fraud-review', L: 'legal-hold' }),
      REASON,
      textField('authority', 'AUTHORITY', 30, { capacity: 80 }),
      { name: 'case', label: 'CASE', width: 10, pick: { dir: 'cases' }, hint: 'NUMBER OR F4' },
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const rtype = code(frame, 'rtype', { D: 'debit-block', C: 'credit-block', X: 'closure-block', F: 'fraud-review', L: 'legal-hold' }, 'KIND'); if (isOutcome(rtype)) return rtype;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      const authority = required(frame, 'authority', 'AUTHORITY'); if (isOutcome(authority)) return authority;
      const caseHit = caseRef(context, frame, 'case'); if (isOutcome(caseHit)) return caseHit;
      return {
        command: { kind: 'account.restriction.apply', accountId: account.accountId, expectedVersion: account.version, restrictionType: rtype as 'debit-block', reason, authority, caseId: caseHit.caseId, approvalId: approvalId(frame) },
        lines: [{ label: 'Restriction', before: '', after: `${rtype} on ${account.number}` }],
      };
    },
    help,
  },

  'account.restriction.release': {
    id: 'account.restriction.release', screenId: 'THRS02', title: 'Release restriction', command: 'account.restriction.release',
    fields: [
      ACCOUNT,
      { name: 'restriction', label: 'RESTRICTION', width: 40, pick: { dir: 'restrictions', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      { name: 'clearance', label: 'CLEARANCE EVIDENCE', width: 40, pick: { dir: 'identity-evidence' }, hint: 'F4=PICK' },
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const restriction = recordRef(context, frame, 'restriction', 'restriction'); if (isOutcome(restriction)) return restriction;
      const clearance = required(frame, 'clearance', 'CLEARANCE EVIDENCE'); if (isOutcome(clearance)) return clearance;
      return {
        command: { kind: 'account.restriction.release', restrictionId: restriction.id, expectedFingerprint: restriction.fingerprint, clearanceEvidenceId: clearance, approvalId: approvalId(frame) },
        lines: [{ label: 'Release', before: 'active', after: 'released' }],
      };
    },
    help,
  },

  'fee.assess': {
    id: 'fee.assess', screenId: 'THFE01', title: 'Assess fee', command: 'fee.assess',
    fields: [ACCOUNT, textField('feecode', 'FEE CODE', 16, { capacity: 40 }), moneyField('amount', 'AMOUNT'), textField('basis', 'BASIS', 40, { capacity: 120 }), POLICY],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const feeCode = required(frame, 'feecode', 'FEE CODE'); if (isOutcome(feeCode)) return feeCode;
      const amount = money(context, frame, 'amount', 'AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const basis = required(frame, 'basis', 'BASIS'); if (isOutcome(basis)) return basis;
      const policy = required(frame, 'policy', 'POLICY VERSION'); if (isOutcome(policy)) return policy;
      return {
        command: { kind: 'fee.assess', accountId: account.accountId, expectedVersion: account.version, feeCode, amount, basis, policyVersionId: policy },
        lines: [{ label: 'Fee', before: '', after: `${feeCode} ${amount.minorUnits} ${amount.currency}` }],
      };
    },
    help,
  },

  'fee.waiver.create': {
    id: 'fee.waiver.create', screenId: 'THFE02', title: 'Create fee waiver', command: 'fee.waiver.create',
    fields: [
      ACCOUNT, textField('feecode', 'FEE CODE', 16, { capacity: 40 }),
      dateField('from', 'VALID FROM'), dateField('through', 'VALID THROUGH'),
      moneyField('limit', 'AMOUNT LIMIT'), numField('max', 'MAX OCCURRENCES'),
      REASON, APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const feeCode = required(frame, 'feecode', 'FEE CODE'); if (isOutcome(feeCode)) return feeCode;
      const from = date(frame, 'from', 'VALID FROM'); if (isOutcome(from) || from === null) return from ?? fieldProblem('from', 'ENTER VALID FROM.');
      const through = date(frame, 'through', 'VALID THROUGH'); if (isOutcome(through) || through === null) return through ?? fieldProblem('through', 'ENTER VALID THROUGH.');
      const limit = money(context, frame, 'limit', 'AMOUNT LIMIT'); if (isOutcome(limit) || limit === null) return limit ?? fieldProblem('limit', 'ENTER THE LIMIT.');
      const max = num(frame, 'max', 'MAX OCCURRENCES', { min: 1 }); if (isOutcome(max)) return max;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      return {
        command: { kind: 'fee.waiver.create', accountId: account.accountId, feeCode, validFrom: from, validThrough: through, amountLimit: limit, maxOccurrences: max, reason, approvalId: approvalId(frame) },
        lines: [{ label: 'Waiver', before: '', after: `${feeCode} up to ${limit.minorUnits} ${limit.currency}` }],
      };
    },
    help,
  },

  'fee.refund': {
    id: 'fee.refund', screenId: 'THFE03', title: 'Refund fee', command: 'fee.refund',
    fields: [
      ACCOUNT,
      { name: 'fee', label: 'FEE', width: 40, pick: { dir: 'fees', scope: { accountId: 'account' } }, hint: 'F4=PICK FEE' },
      moneyField('amount', 'REFUND AMOUNT'),
      REASON,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const fee = recordRef(context, frame, 'fee', 'fee'); if (isOutcome(fee)) return fee;
      const amount = money(context, frame, 'amount', 'REFUND AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      return {
        command: { kind: 'fee.refund', feeId: fee.id, expectedFingerprint: fee.fingerprint, amount, reason },
        lines: [{ label: 'Refund', before: '', after: `${amount.minorUnits} ${amount.currency}` }],
      };
    },
    help,
  },

  'cash.deposit.reverse': {
    id: 'cash.deposit.reverse', screenId: 'THRV10', title: 'Reverse deposit', command: 'cash.deposit.reverse',
    fields: [
      ACCOUNT,
      { name: 'journal', label: 'JOURNAL', width: 40, pick: { dir: 'journals', scope: { accountId: 'account' } }, hint: 'F4=PICK DEPOSIT JOURNAL' },
      { name: 'evidence', label: 'CORRECTION EVIDENCE', width: 40, pick: { dir: 'identity-evidence' }, hint: 'F4=PICK' },
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const journal = recordRef(context, frame, 'journal', 'journal'); if (isOutcome(journal)) return journal;
      const evidence = required(frame, 'evidence', 'CORRECTION EVIDENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'cash.deposit.reverse', journalId: journal.id, expectedFingerprint: journal.fingerprint, correctionEvidenceId: evidence, approvalId: approvalId(frame) },
        lines: [{ label: 'Reverse', before: '', after: `deposit journal ${journal.id.slice(-16)}` }],
      };
    },
    help,
  },

  'cash.withdrawal.reverse': {
    id: 'cash.withdrawal.reverse', screenId: 'THRV11', title: 'Reverse withdrawal', command: 'cash.withdrawal.reverse',
    fields: [
      ACCOUNT,
      { name: 'journal', label: 'JOURNAL', width: 40, pick: { dir: 'journals', scope: { accountId: 'account' } }, hint: 'F4=PICK WITHDRAWAL JOURNAL' },
      REASON,
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const journal = recordRef(context, frame, 'journal', 'journal'); if (isOutcome(journal)) return journal;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      return {
        command: { kind: 'cash.withdrawal.reverse', journalId: journal.id, expectedFingerprint: journal.fingerprint, reason, approvalId: approvalId(frame) },
        lines: [{ label: 'Reverse', before: '', after: `withdrawal journal ${journal.id.slice(-16)}` }],
      };
    },
    help,
  },

  'transfer.internal.reverse': {
    id: 'transfer.internal.reverse', screenId: 'THRV12', title: 'Reverse transfer', command: 'transfer.internal.reverse',
    fields: [
      ACCOUNT,
      { name: 'journal', label: 'TRANSFER JOURNAL', width: 40, pick: { dir: 'journals', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      moneyField('amount', 'AMOUNT'),
      REASON,
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const journal = recordRef(context, frame, 'journal', 'transfer'); if (isOutcome(journal)) return journal;
      const amount = money(context, frame, 'amount', 'AMOUNT'); if (isOutcome(amount) || amount === null) return amount ?? fieldProblem('amount', 'ENTER THE AMOUNT.');
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      return {
        command: { kind: 'transfer.internal.reverse', transferJournalId: journal.id, expectedFingerprint: journal.fingerprint, amount, reason, approvalId: approvalId(frame) },
        lines: [{ label: 'Reverse', before: '', after: `transfer ${journal.id.slice(-16)}` }],
      };
    },
    help,
  },

  'interest.adjust': {
    id: 'interest.adjust', screenId: 'THIN01', title: 'Adjust interest', command: 'interest.adjust',
    fields: [
      ACCOUNT,
      { name: 'calculation', label: 'CALCULATION', width: 40, pick: { dir: 'interest-calcs', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      moneyField('delta', 'APPROVED DELTA', { signed: true }),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const calc = recordRef(context, frame, 'calculation', 'interest-calculation'); if (isOutcome(calc)) return calc;
      const delta = money(context, frame, 'delta', 'APPROVED DELTA', { signed: true }); if (isOutcome(delta) || delta === null) return delta ?? fieldProblem('delta', 'ENTER THE DELTA.');
      return {
        command: { kind: 'interest.adjust', accountId: account.accountId, calculationId: calc.id, expectedFingerprint: calc.fingerprint, approvedDelta: delta, approvalId: approvalId(frame) },
        lines: [{ label: 'Delta', before: '', after: `${delta.minorUnits} ${delta.currency}` }],
      };
    },
    help,
  },

  'transaction.effective_date.correct': {
    id: 'transaction.effective_date.correct', screenId: 'THED01', title: 'Correct effective date', command: 'transaction.effective_date.correct',
    fields: [
      ACCOUNT,
      { name: 'journal', label: 'JOURNAL', width: 40, pick: { dir: 'journals', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      dateField('corrected', 'CORRECTED DATE'),
      POLICY,
      REASON,
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const journal = recordRef(context, frame, 'journal', 'journal'); if (isOutcome(journal)) return journal;
      const corrected = date(frame, 'corrected', 'CORRECTED DATE'); if (isOutcome(corrected) || corrected === null) return corrected ?? fieldProblem('corrected', 'ENTER CORRECTED DATE.');
      const policy = required(frame, 'policy', 'POLICY VERSION'); if (isOutcome(policy)) return policy;
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      return {
        command: { kind: 'transaction.effective_date.correct', journalId: journal.id, expectedFingerprint: journal.fingerprint, correctedDate: corrected, policyVersionId: policy, reason, approvalId: approvalId(frame) },
        lines: [{ label: 'Date', before: '', after: corrected }],
      };
    },
    help,
  },

  'transaction.description.update': {
    id: 'transaction.description.update', screenId: 'THDS01', title: 'Update journal description', command: 'transaction.description.update',
    fields: [
      ACCOUNT,
      { name: 'journal', label: 'JOURNAL', width: 40, pick: { dir: 'journals', scope: { accountId: 'account' } }, hint: 'F4=PICK' },
      textField('description', 'DESCRIPTION', 58, { capacity: 200 }),
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const journal = recordRef(context, frame, 'journal', 'journal'); if (isOutcome(journal)) return journal;
      const description = required(frame, 'description', 'DESCRIPTION'); if (isOutcome(description)) return description;
      return {
        command: { kind: 'transaction.description.update', journalId: journal.id, expectedFingerprint: journal.fingerprint, description },
        lines: [{ label: 'Description', before: cell(journal.record.description), after: description }],
      };
    },
    help,
  },

  'account.maturity.instruct': {
    id: 'account.maturity.instruct', screenId: 'THMI01', title: 'Maturity instruction', command: 'account.maturity.instruct',
    fields: [
      ACCOUNT,
      { name: 'instruction', label: 'EXISTING INSTRUCTION', width: 40, required: false, pick: { dir: 'maturity', scope: { accountId: 'account' } }, hint: 'BLANK=NONE' },
      codeField('disposition', 'DISPOSITION', { R: 'renew', T: 'transfer', H: 'hold' }),
      { name: 'destination', label: 'DESTINATION ACCT', width: 10, required: false, pick: { dir: 'accounts' }, hint: 'FOR TRANSFER' },
      numField('term', 'TERM MONTHS', false),
      numField('rate', 'APPROVED RATE BPS', false),
      APPROVAL,
    ],
    build(context, frame) {
      const account = accountRef(context, frame); if (isOutcome(account)) return account;
      const instructionId = entered(frame, 'instruction');
      let instructionFingerprint: string | null = null;
      if (instructionId !== '') {
        const found = recordRef(context, frame, 'instruction', 'maturity-instruction'); if (isOutcome(found)) return found;
        instructionFingerprint = found.fingerprint;
      }
      const disposition = code(frame, 'disposition', { R: 'renew', T: 'transfer', H: 'hold' }, 'DISPOSITION'); if (isOutcome(disposition)) return disposition;
      let destinationAccountId: string | null = null;
      if (entered(frame, 'destination') !== '') {
        const destination = accountRef(context, frame, 'destination'); if (isOutcome(destination)) return destination;
        destinationAccountId = destination.accountId;
      }
      const term = num(frame, 'term', 'TERM MONTHS', { required: false, min: 1 }); if (isOutcome(term)) return term;
      const rate = num(frame, 'rate', 'APPROVED RATE BPS', { required: false }); if (isOutcome(rate)) return rate;
      return {
        command: {
          kind: 'account.maturity.instruct', accountId: account.accountId, expectedVersion: account.version, expectedInstructionFingerprint: instructionFingerprint,
          disposition: disposition as 'renew', destinationAccountId, termMonths: entered(frame, 'term') === '' ? null : term, approvedAnnualRateBps: entered(frame, 'rate') === '' ? null : rate, approvalId: approvalId(frame),
        },
        lines: [{ label: 'Disposition', before: '', after: disposition }],
      };
    },
    help,
  },
};
