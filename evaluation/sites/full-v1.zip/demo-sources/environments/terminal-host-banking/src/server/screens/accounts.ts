import { LIMITS, referenceData, searchAccounts, type ServiceCommand } from '@computer-use/financial-database/services';

import { failure, info, type FrameOf } from '../host/frames.js';
import { amount, column, localDate, upper } from '../host/format.js';
import type { ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  accountFrame, accountOpenFrame, activityFrame, anyEntered, badSelection, beginReview, cashFrame, clampOffset, closeFrame, deliveryCode, deliveryWord,
  differs, findAccount, historyFrame, inactiveKey, label, LIST_ROWS, LIST_TOP, notFound, page, pageLabel, profileFrame, profileValues, readAccount, readMember,
  rowsLabel, selection, statementsFrame, transferFrame, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';

const STATUS_CODES: Readonly<Record<string, string>> = { O: 'open', R: 'restricted', D: 'dormant', C: 'closed', M: 'matured' };

function heading(builder: ScreenBuilder, row: number, columns: readonly (readonly [number, string])[]): void {
  for (const [at, text] of columns) builder.text(row, at, text, 'label');
}

export const accountListScreen: ScreenModule<FrameOf<'account-list'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THAC01', frame.memberId === null ? 'Account search' : 'Member accounts');
    if (frame.memberId !== null) {
      const { member } = readMember(context, frame.memberId);
      label(builder, 3, 1, 'Member', 10).data(3, 11, 8, member.memberNumber).data(3, 21, 50, member.displayName, 'emphasis');
    }
    const status = STATUS_CODES[frame.criteria.status];
    const search = (offset: number) => context.read((database, datasetId) => searchAccounts(database, datasetId, {
      ...(frame.memberId === null ? {} : { memberId: frame.memberId }), query: frame.criteria.query, ...(status === undefined ? {} : { status }), limit: LIST_ROWS, offset,
    }));
    let result = search(frame.offset);
    const clamped = clampOffset(frame.offset, LIST_ROWS, result.total);
    if (clamped !== frame.offset) {
      frame.offset = clamped;
      result = search(clamped);
    }
    frame.rows = result.items.map((row) => row.id);
    frame.total = result.total;
    builder.page = pageLabel(frame.offset, LIST_ROWS, result.total);
    label(builder, 4, 1, 'Search', 10).input('query', 4, 11, 30, value(frame, 'query', frame.criteria.query));
    label(builder, 4, 44, 'Status', 9).input('status', 4, 53, 1, value(frame, 'status', frame.criteria.status));
    builder.text(5, 1, 'ACCOUNT NO., MEMBER NO. PREFIX, NICKNAME OR OWNER. STATUS O/R/D/C/M OR BLANK.', 'label');
    heading(builder, 6, [[1, 'S'], [3, 'ACCOUNT'], [14, 'PRODUCT'], [28, 'CUR'], [32, 'STATUS'], [43, 'NICKNAME'], [66, 'POSTED BALANCE']]);
    result.items.forEach((row, index) => {
      const line = LIST_TOP + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 10, row.accountNumber).data(line, 14, 13, row.productCode).data(line, 28, 3, row.currency)
        .data(line, 32, 10, upper(row.status), row.status === 'open' ? 'data' : 'warning').data(line, 43, 16, row.nickname)
        .data(line, 60, 20, column(row.postedMinorUnits, row.currency, row.exponent, 20));
    });
    if (result.total === 0) builder.text(LIST_TOP, 3, 'NO ACCOUNTS MATCH.', 'warning');
    builder.text(19, 1, 'SEL: S=INQUIRY  H=HISTORY  T=STATEMENTS  M=MAINTAIN  C=CLOSE  V=ACTIVITY', 'label');
    builder.text(20, 1, 'D=DEPOSIT  W=WITHDRAW  X=TRANSFER FROM', 'label').data(20, 44, 35, rowsLabel(frame.offset, result.items.length, result.total), 'label');
    return builder.legend(`ENTER=Search/Select  F1=Help  F3=Return  F7=Up  F8=Down${frame.memberId === null ? '' : '  F10=Open account'}`);
  },
  input(context, frame, event) {
    if (event.aid === 'pf10' && frame.memberId !== null) return { kind: 'push', frame: accountOpenFrame(frame.memberId) };
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    if (event.modified.has('query') || event.modified.has('status')) {
      const status = upper(value(frame, 'status', frame.criteria.status).trim());
      if (status !== '' && !(status in STATUS_CODES)) return { kind: 'stay', message: failure('STATUS MUST BE O, R, D, C, M OR BLANK.'), error: 'status' };
      frame.criteria = { query: value(frame, 'query', frame.criteria.query).trim(), status };
      frame.offset = 0;
      delete frame.values.query;
      delete frame.values.status;
      selection(frame, frame.rows.length);
      return { kind: 'stay', message: info('SEARCH COMPLETE. TYPE A SELECTION CODE BESIDE AN ACCOUNT.') };
    }
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE A SELECTION CODE BESIDE AN ACCOUNT, OR CHANGE THE SEARCH.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const accountId = frame.rows[picked.index];
    if (accountId === undefined) return badSelection(picked.code, 'A LISTED ROW', picked.index);
    frame.cursor = `sel.${picked.index}`;
    switch (picked.code) {
      case 'S': return { kind: 'push', frame: accountFrame(accountId) };
      case 'H': return { kind: 'push', frame: historyFrame(accountId) };
      case 'T': return { kind: 'push', frame: statementsFrame(accountId) };
      case 'V': return { kind: 'push', frame: activityFrame({ accountId }) };
      case 'M': return { kind: 'push', frame: profileFrame(readAccount(context, accountId)) };
      case 'C': return { kind: 'push', frame: closeFrame(readAccount(context, accountId)) };
      case 'D': return { kind: 'push', frame: cashFrame('deposit', readAccount(context, accountId).account.accountNumber) };
      case 'W': return { kind: 'push', frame: cashFrame('withdraw', readAccount(context, accountId).account.accountNumber) };
      case 'X': return { kind: 'push', frame: transferFrame(readAccount(context, accountId).account.accountNumber) };
      default: return badSelection(picked.code, 'S H T M C V D W X', picked.index);
    }
  },
  help: HELP_TOPICS['account-list'],
};

function eligibilityText(eligibility: { eligible: boolean; reasons: readonly string[] }, allowed: string): string {
  return eligibility.eligible ? allowed : upper(eligibility.reasons[0] ?? 'NOT ALLOWED');
}

export const accountScreen: ScreenModule<FrameOf<'account'>> = {
  render(context, frame) {
    const detail = readAccount(context, frame.accountId);
    const { account } = detail;
    const { timeZone } = context.session().institution;
    const money = (minorUnits: number): string => `${amount(minorUnits, account.currency, account.exponent)} ${account.currency}`;
    const builder = new ScreenBuilder('THAC02', 'Account inquiry');
    builder.page = `PAGE ${frame.page} OF 2`;
    label(builder, 3, 1, 'Account number', 18).input('account', 3, 19, 10, value(frame, 'account', account.accountNumber));
    builder.text(3, 40, 'STATUS', 'label').data(3, 47, 12, upper(account.status), account.status === 'open' ? 'success' : 'warning');
    label(builder, 4, 1, 'Member', 18).data(4, 19, 8, account.memberNumber).data(4, 29, 50, account.ownerName, 'emphasis');
    if (frame.page === 1) {
      const held = detail.holds.filter((hold) => hold.status === 'active');
      const facility = detail.facilities.find((candidate) => candidate.status === 'active');
      label(builder, 5, 1, 'Product', 18).data(5, 19, 38, `${account.productCode} ${account.productName}`);
      label(builder, 5, 60, 'Currency', 10).data(5, 70, 3, account.currency, 'emphasis');
      label(builder, 6, 1, 'Nickname', 18).data(6, 19, 40, account.nickname);
      label(builder, 7, 1, 'Statement delivery', 18).data(7, 19, 12, deliveryWord(account.statementDelivery));
      label(builder, 8, 1, 'Opened', 18).data(8, 19, 10, localDate(account.openedAt, timeZone));
      label(builder, 8, 40, 'Closed', 8).data(8, 48, 10, account.closedAt === null ? '' : localDate(account.closedAt, timeZone));
      label(builder, 10, 1, 'Posted balance', 18).data(10, 19, 30, money(account.postedMinorUnits), 'emphasis');
      label(builder, 11, 1, 'Available balance', 18).data(11, 19, 30, money(account.availableMinorUnits), 'emphasis');
      label(builder, 12, 1, 'Active holds', 18).data(12, 19, 40, `${money(held.reduce((total, hold) => total + hold.amountMinorUnits, 0))} (${held.length})`);
      label(builder, 13, 1, 'Facility', 18).data(13, 19, 58, facility === undefined ? 'NONE' : `${upper(facility.kind)} LIMIT ${money(facility.limitMinorUnits)} USED ${money(facility.usedMinorUnits)}`);
      label(builder, 15, 1, 'Debits', 18).data(15, 19, 60, eligibilityText(detail.eligibility.debit, 'ALLOWED'), detail.eligibility.debit.eligible ? 'success' : 'warning');
      label(builder, 16, 1, 'Credits', 18).data(16, 19, 60, eligibilityText(detail.eligibility.credit, 'ALLOWED'), detail.eligibility.credit.eligible ? 'success' : 'warning');
      label(builder, 17, 1, 'Closure', 18).data(17, 19, 60, eligibilityText(detail.eligibility.closure, 'ELIGIBLE'), detail.eligibility.closure.eligible ? 'success' : 'label');
      label(builder, 18, 1, 'Record version', 18).data(18, 19, 6, String(account.version));
    } else {
      builder.text(5, 1, 'HOLDS', 'emphasis');
      detail.holds.slice(0, 3).forEach((hold, index) => {
        builder.data(6 + index, 3, 24, money(hold.amountMinorUnits)).data(6 + index, 28, 10, upper(hold.status), 'label').data(6 + index, 39, 40, hold.reason);
      });
      if (detail.holds.length === 0) builder.text(6, 3, 'NONE', 'label');
      builder.text(9, 1, 'RESTRICTIONS', 'emphasis');
      detail.restrictions.slice(0, 2).forEach((restriction, index) => {
        builder.data(10 + index, 3, 20, upper(restriction.kind)).data(10 + index, 24, 10, upper(restriction.status), 'label').data(10 + index, 35, 44, restriction.authority);
      });
      if (detail.restrictions.length === 0) builder.text(10, 3, 'NONE', 'label');
      builder.text(12, 1, 'PARTIES', 'emphasis');
      detail.parties.slice(0, 2).forEach((party, index) => builder.data(13 + index, 3, 16, upper(party.role), 'label').data(13 + index, 20, 58, party.displayName));
      builder.text(15, 1, 'ELIGIBILITY REASONS (SHARED RULES)', 'emphasis');
      const reasons = [
        ...detail.eligibility.debit.reasons.map((reason) => `DEBIT: ${reason}`),
        ...detail.eligibility.credit.reasons.map((reason) => `CREDIT: ${reason}`),
        ...detail.eligibility.closure.reasons.map((reason) => `CLOSURE: ${reason}`),
      ];
      reasons.slice(0, 4).forEach((reason, index) => builder.data(16 + index, 3, 76, upper(reason), 'warning'));
      if (reasons.length === 0) builder.text(16, 3, 'NONE: DEBITS, CREDITS AND CLOSURE ARE ALLOWED.', 'success');
    }
    return builder.legend('ENTER=Switch account  F1=Help  F3=Return  F4=Maintain  F5=History  F6=Statements', 'F7/F8=Page  F9=Activity  F10=Deposit  F11=Withdraw  F13=Transfer  F14=Close');
  },
  input(context, frame, event) {
    const number = (): string => readAccount(context, frame.accountId).account.accountNumber;
    switch (event.aid) {
      case 'enter': {
        if (!event.modified.has('account')) return { kind: 'stay', message: info('SCREEN REFRESHED WITH CURRENT DATA.') };
        const entered = value(frame, 'account');
        const found = findAccount(context, entered);
        if (found === undefined) return { kind: 'stay', message: notFound('ACCOUNT', entered, context), error: 'account' };
        delete frame.values.account;
        return { kind: 'replace', frame: accountFrame(found.id), message: info(`NOW SHOWING ACCOUNT ${found.accountNumber}.`) };
      }
      case 'pf7': frame.page = 1; return { kind: 'stay' };
      case 'pf8': frame.page = 2; return { kind: 'stay' };
      case 'pf4': return { kind: 'push', frame: profileFrame(readAccount(context, frame.accountId)) };
      case 'pf5': return { kind: 'push', frame: historyFrame(frame.accountId) };
      case 'pf6': return { kind: 'push', frame: statementsFrame(frame.accountId) };
      case 'pf9': return { kind: 'push', frame: activityFrame({ accountId: frame.accountId }) };
      case 'pf10': return { kind: 'push', frame: cashFrame('deposit', number()) };
      case 'pf11': return { kind: 'push', frame: cashFrame('withdraw', number()) };
      case 'pf13': return { kind: 'push', frame: transferFrame(number()) };
      case 'pf14': return { kind: 'push', frame: closeFrame(readAccount(context, frame.accountId)) };
      default: return inactiveKey();
    }
  },
  help: HELP_TOPICS.account,
};

export const accountOpenScreen: ScreenModule<FrameOf<'account-open'>> = {
  render(context, frame) {
    const { member } = readMember(context, frame.memberId);
    const products = context.read((database, datasetId) => referenceData(database, datasetId, context.session().institution.institutionId).products).slice(0, 10);
    frame.products = products.map((product) => product.id);
    const builder = new ScreenBuilder('THAC03', 'Open account');
    label(builder, 3, 1, 'Member', 10).data(3, 11, 8, member.memberNumber).data(3, 21, 50, member.displayName, 'emphasis');
    heading(builder, 5, [[3, 'NO'], [7, 'PRODUCT'], [22, 'CUR'], [27, 'NAME']]);
    products.forEach((product, index) => {
      builder.data(6 + index, 3, 2, String(index + 1).padStart(2)).data(6 + index, 7, 14, product.code).data(6 + index, 22, 3, product.currency).data(6 + index, 27, 40, product.name);
    });
    label(builder, 17, 1, 'Product number', 20).input('product', 17, 21, 2, value(frame, 'product'), { numeric: true });
    label(builder, 18, 1, 'Nickname', 20).input('nickname', 18, 21, 40, value(frame, 'nickname'));
    label(builder, 19, 1, 'Delivery (P/E)', 20).input('delivery', 19, 21, 1, value(frame, 'delivery', 'E'));
    builder.text(20, 1, 'P = PAPER, E = ELECTRONIC. NEW ACCOUNTS OPEN WITH A ZERO BALANCE.', 'label');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const number = Number(value(frame, 'product').trim());
    const productId = Number.isInteger(number) && number > 0 ? frame.products[number - 1] : undefined;
    if (productId === undefined) return { kind: 'stay', message: failure('ENTER A PRODUCT NUMBER FROM THE LIST.'), error: 'product' };
    const statementDelivery = deliveryCode(value(frame, 'delivery', 'E'));
    if (statementDelivery === null) return { kind: 'stay', message: failure('DELIVERY MUST BE P OR E.'), error: 'delivery' };
    const product = context.read((database, datasetId) => referenceData(database, datasetId, context.session().institution.institutionId).products.find((candidate) => candidate.id === productId));
    const { member } = readMember(context, frame.memberId);
    const nickname = value(frame, 'nickname').trim();
    return beginReview(context, frame, {
      command: { kind: 'account.open', memberId: frame.memberId, productId, nickname, statementDelivery },
      screenId: 'THAC04', title: 'Review new account',
      lines: [
        { label: 'Member', before: '', after: `${member.memberNumber} ${member.displayName}` },
        { label: 'Product', before: '', after: product === undefined ? productId : `${product.code} ${product.name}` },
        { label: 'Nickname', before: '', after: nickname },
        { label: 'Delivery', before: '', after: deliveryWord(statementDelivery) },
        { label: 'Opening balance', before: '', after: `0 ${product?.currency ?? ''}` },
      ],
      fields: { productId: 'product', nickname: 'nickname', statementDelivery: 'delivery', memberId: 'product' },
    });
  },
  dirty: (frame) => anyEntered(frame, ['product', 'nickname']),
  help: HELP_TOPICS['account-open'],
};

export const accountProfileScreen: ScreenModule<FrameOf<'account-profile'>> = {
  render(context, frame) {
    const detail = readAccount(context, frame.accountId);
    const current = profileValues(detail);
    if (frame.conflict === true) {
      frame.version = detail.account.version;
      frame.baseline = current;
    }
    const builder = new ScreenBuilder('THAC05', 'Account maintenance');
    label(builder, 3, 1, 'Account', 20).data(3, 21, 10, detail.account.accountNumber).data(3, 33, 46, detail.account.ownerName, 'emphasis');
    label(builder, 4, 1, 'Product', 20).data(4, 21, 40, `${detail.account.productCode} ${detail.account.productName}`);
    label(builder, 5, 1, 'Record version', 20).data(5, 21, 6, String(frame.version));
    const draft = (name: string): string => value(frame, name, frame.baseline[name] ?? '');
    label(builder, 7, 1, 'Nickname', 20).input('nickname', 7, 21, 40, draft('nickname'));
    label(builder, 9, 1, 'Delivery (P/E)', 20).input('delivery', 9, 21, 1, draft('delivery'));
    if (frame.conflict === true) {
      if ('nickname' in frame.values && draft('nickname').trim() !== current.nickname) builder.data(8, 21, 58, `NOW: ${current.nickname ?? ''}`, 'warning');
      if ('delivery' in frame.values && upper(draft('delivery').trim()) !== current.delivery) builder.data(10, 21, 30, `NOW: ${current.delivery ?? ''}`, 'warning');
    }
    builder.text(12, 1, 'CHANGE THE NICKNAME OR THE DELIVERY. EACH IS A SEPARATE TRANSACTION.', 'label');
    builder.text(13, 1, 'P = PAPER, E = ELECTRONIC.', 'label');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const nickname = value(frame, 'nickname', frame.baseline.nickname ?? '').trim();
    const deliveryEntry = upper(value(frame, 'delivery', frame.baseline.delivery ?? '').trim());
    const nicknameChanged = nickname !== (frame.baseline.nickname ?? '').trim();
    const deliveryChanged = deliveryEntry !== frame.baseline.delivery;
    if (nicknameChanged && deliveryChanged) return { kind: 'stay', message: failure('CHANGE THE NICKNAME OR THE DELIVERY, NOT BOTH, IN ONE TRANSACTION.'), error: 'delivery' };
    if (!nicknameChanged && !deliveryChanged) return { kind: 'stay', message: info('NO CHANGES ENTERED.') };
    const detail = readAccount(context, frame.accountId);
    if (nicknameChanged) {
      return beginReview(context, frame, {
        command: { kind: 'account.nickname.update', accountId: frame.accountId, expectedVersion: frame.version, nickname },
        screenId: 'THAC06', title: 'Review nickname change',
        lines: [{ label: 'Account', before: '', after: detail.account.accountNumber }, { label: 'Nickname', before: frame.baseline.nickname ?? '', after: nickname }],
        fields: { nickname: 'nickname', accountId: 'nickname' },
      });
    }
    const statementDelivery = deliveryCode(deliveryEntry);
    if (statementDelivery === null) return { kind: 'stay', message: failure('DELIVERY MUST BE P OR E.'), error: 'delivery' };
    const command: ServiceCommand = { kind: 'account.statement_delivery.update', accountId: frame.accountId, expectedVersion: frame.version, statementDelivery };
    return beginReview(context, frame, {
      command, screenId: 'THAC06', title: 'Review delivery change',
      lines: [{ label: 'Account', before: '', after: detail.account.accountNumber }, { label: 'Delivery', before: deliveryWord(detail.account.statementDelivery), after: deliveryWord(statementDelivery) }],
      fields: { statementDelivery: 'delivery', accountId: 'delivery' },
    });
  },
  dirty: (frame) => differs(frame, frame.baseline, ['nickname', 'delivery']),
  help: HELP_TOPICS['account-profile'],
};

export const accountCloseScreen: ScreenModule<FrameOf<'account-close'>> = {
  render(context, frame) {
    const detail = readAccount(context, frame.accountId);
    const { account } = detail;
    if (frame.conflict === true) frame.version = account.version;
    const money = (minorUnits: number): string => `${amount(minorUnits, account.currency, account.exponent)} ${account.currency}`;
    const builder = new ScreenBuilder('THAC07', 'Close account');
    label(builder, 3, 1, 'Account', 20).data(3, 21, 10, account.accountNumber).data(3, 33, 46, account.ownerName, 'emphasis');
    label(builder, 4, 1, 'Product', 20).data(4, 21, 40, `${account.productCode} ${account.productName}`);
    label(builder, 5, 1, 'Status', 20).data(5, 21, 12, upper(account.status));
    label(builder, 6, 1, 'Posted balance', 20).data(6, 21, 30, money(account.postedMinorUnits));
    label(builder, 7, 1, 'Available balance', 20).data(7, 21, 30, money(account.availableMinorUnits));
    builder.text(9, 1, 'CLOSURE ELIGIBILITY (SHARED RULES)', 'emphasis');
    if (detail.eligibility.closure.eligible) builder.text(10, 3, 'ELIGIBLE TO CLOSE.', 'success');
    detail.eligibility.closure.reasons.slice(0, 5).forEach((reason, index) => builder.data(10 + index, 3, 76, upper(reason), 'warning'));
    label(builder, 16, 1, 'Closure reason', 20).input('reason', 16, 21, 138, value(frame, 'reason'), { capacity: LIMITS.reasonLength });
    builder.text(18, 1, 'CLOSING POSTS NOTHING AND CANNOT BE UNDONE FROM THIS TERMINAL.', 'label');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const { account } = readAccount(context, frame.accountId);
    const reason = value(frame, 'reason').trim();
    return beginReview(context, frame, {
      command: { kind: 'account.close', accountId: frame.accountId, expectedVersion: frame.version, reason },
      screenId: 'THAC08', title: 'Review account closure',
      lines: [{ label: 'Account', before: account.accountNumber, after: account.accountNumber }, { label: 'Status', before: upper(account.status), after: 'CLOSED' }, { label: 'Reason', before: '', after: reason }],
      fields: { reason: 'reason', accountId: 'reason' },
    });
  },
  dirty: (frame) => anyEntered(frame, ['reason']),
  help: HELP_TOPICS['account-close'],
};
