import { formatMinorUnits } from '@computer-use/financial-database/services';

import { graphemes, textWidth } from '../../shared/cells.js';

/**
 * Grouped amount with the currency's fixed decimals and no currency code, for example `6,091.54`.
 * Screens place the code in their own column, so the code the shared formatter appends is removed.
 */
export function amount(minorUnits: number, currency: string, exponent: number): string {
  const formatted = formatMinorUnits(minorUnits, currency, exponent);
  const suffix = ` ${currency}`;
  if (!formatted.endsWith(suffix)) throw new Error(`The shared money format no longer ends with the currency code: ${formatted}`);
  return formatted.slice(0, -suffix.length);
}

/** Right-aligned amount in a fixed number of cells, with a trailing minus for debits as on host reports. */
export function column(minorUnits: number, currency: string, exponent: number, cells: number): string {
  const text = `${amount(Math.abs(minorUnits), currency, exponent)}${minorUnits < 0 ? '-' : ' '}`;
  return text.length >= cells ? text : `${' '.repeat(cells - text.length)}${text}`;
}

/**
 * Converts operator-entered decimal text to exact minor units. Grouping separators, signs and more
 * decimals than the currency allows are rejected rather than rounded or guessed.
 */
export function parseAmount(text: string, exponent: number): { minorUnits: number } | { problem: string } {
  const value = text.trim();
  const match = /^(\d{1,13})(?:\.(\d*))?$/u.exec(value);
  if (match === null) return { problem: 'ENTER THE AMOUNT AS DIGITS WITH AN OPTIONAL DECIMAL POINT.' };
  const fraction = match[2] ?? '';
  if (fraction.length > exponent) return { problem: exponent === 0 ? 'THIS CURRENCY HAS NO DECIMAL PLACES.' : `THIS CURRENCY ALLOWS AT MOST ${exponent} DECIMAL PLACES.` };
  const minorUnits = Number(match[1] ?? '0') * 10 ** exponent + Number(fraction.padEnd(exponent, '0') || '0');
  if (!Number.isSafeInteger(minorUnits)) return { problem: 'THE AMOUNT IS TOO LARGE.' };
  if (minorUnits <= 0) return { problem: 'THE AMOUNT MUST BE GREATER THAN ZERO.' };
  return { minorUnits };
}

function parts(instant: string, timeZone: string): Record<string, string> {
  return Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })
    .formatToParts(new Date(instant)).map((part) => [part.type, part.value]));
}

/** Institution-local `YYYY-MM-DD HH:MM`. */
export function localDateTime(instant: string, timeZone: string): string {
  const value = parts(instant, timeZone);
  return `${value.year ?? ''}-${value.month ?? ''}-${value.day ?? ''} ${value.hour ?? ''}:${value.minute ?? ''}`;
}

export function localDate(instant: string, timeZone: string): string {
  return localDateTime(instant, timeZone).slice(0, 10);
}

export function upper(value: string): string {
  return value.toLocaleUpperCase('en-US');
}

export function isIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/u.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

/** Breaks text into lines of at most `cells` cells, at spaces where possible, keeping explicit line breaks. */
export function wrap(text: string, cells: number): string[] {
  const lines: string[] = [];
  for (const paragraph of text.split(/\r?\n/u)) {
    let line = '';
    for (const word of paragraph.split(' ')) {
      const candidate = line === '' ? word : `${line} ${word}`;
      if (textWidth(candidate) <= cells) { line = candidate; continue; }
      if (line !== '') lines.push(line);
      let rest = word;
      while (textWidth(rest) > cells) {
        let chunk = '';
        for (const grapheme of graphemes(rest)) {
          if (textWidth(chunk + grapheme) > cells) break;
          chunk += grapheme;
        }
        lines.push(chunk);
        rest = rest.slice(chunk.length);
      }
      line = rest;
    }
    lines.push(line);
  }
  return lines;
}
