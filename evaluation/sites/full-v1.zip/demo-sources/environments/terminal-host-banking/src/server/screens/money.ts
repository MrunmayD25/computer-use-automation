import { LIMITS, receiptByNumber, type AccountRow, type ServiceCommand } from '@computer-use/financial-database/services';

import type { Tone } from '../../shared/protocol.js';
import { failure, info, success, warning, type FrameOf } from '../host/frames.js';
import { amount, column, localDateTime, parseAmount, upper, wrap } from '../host/format.js';
import type { HostContext, Outcome, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  accountFrame, anyEntered, badSelection, beginReview, caseFrame, clampOffset, CONFLICT_MESSAGE, currencyExponent, findAccount, inactiveKey, label, memberFrame, notFound, page, pageLabel,
  rejectionMessage, selection, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';

function heading(builder: ScreenBuilder, row: number, columns: readonly (readonly [number, string])[]): void {
  for (const [at, text] of columns) builder.text(row, at, text, 'label');
}

function accountSummary(builder: ScreenBuilder, row: number, account: AccountRow): void {
  const money = (minorUnits: number): string => `${amount(minorUnits, account.currency, account.exponent)} ${account.currency}`;
  builder.data(row, 21, 8, account.memberNumber).data(row, 31, 48, account.ownerName, 'emphasis');
  builder.data(row + 1, 21, 58, `${account.productCode}  ${upper(account.status)}  AVAILABLE ${money(account.availableMinorUnits)}`, account.status === 'open' ? 'data' : 'warning');
}

/** Money fields shared by cash and transfer entry: amount in the chosen currency's exact minor units. */
function money(context: HostContext, frame: FrameOf<'cash'> | FrameOf<'transfer'>, defaultCurrency: string): { minorUnits: number; currency: string } | Outcome {
  const currency = upper(value(frame, 'currency', defaultCurrency).trim());
  if (currency === '') return { kind: 'stay', message: failure('ENTER THE CURRENCY CODE.'), error: 'currency' };
  const exponent = currencyExponent(context, currency);
  if (exponent === undefined) return { kind: 'stay', message: failure(`CURRENCY ${currency.slice(0, 3)} IS NOT SUPPORTED.`), error: 'currency' };
  const parsed = parseAmount(value(frame, 'amount'), exponent);
  if ('problem' in parsed) return { kind: 'stay', message: failure(parsed.problem), error: 'amount' };
  return { minorUnits: parsed.minorUnits, currency };
}

export const cashScreen: ScreenModule<FrameOf<'cash'>> = {
  render(context, frame) {
    const deposit = frame.direction === 'deposit';
    const builder = new ScreenBuilder(deposit ? 'THTX01' : 'THTX02', deposit ? 'Cash deposit' : 'Cash withdrawal');
    const account = findAccount(context, value(frame, 'account'));
    label(builder, 3, 1, 'Account number', 20).input('account', 3, 21, 10, value(frame, 'account'));
    if (account !== undefined) accountSummary(builder, 4, account);
    else if (value(frame, 'account').trim() !== '') builder.text(4, 21, 'ACCOUNT NOT FOUND', 'warning');
    if (account !== undefined) {
      label(builder, 6, 1, 'Posted balance', 20).data(6, 21, 30, `${amount(account.postedMinorUnits, account.currency, account.exponent)} ${account.currency}`);
    }
    label(builder, 8, 1, 'Amount', 20).input('amount', 8, 21, 16, value(frame, 'amount'), { numeric: true });
    label(builder, 8, 40, 'Currency', 10).input('currency', 8, 50, 3, value(frame, 'currency', account?.currency ?? ''));
    label(builder, 9, 1, 'Description', 20).input('description', 9, 21, 56, value(frame, 'description'), { capacity: LIMITS.descriptionLength });
    builder.text(11, 1, 'AMOUNTS ARE IN THE CURRENCY SHOWN. NO CONVERSION IS PERFORMED.', 'label');
    builder.text(12, 1, 'THE SHARED RULES CHECK STATUS, RESTRICTIONS AND FUNDS AT REVIEW AND AT POSTING.', 'label');
    if (account === undefined) builder.cursor('account');
    else if (value(frame, 'amount').trim() === '') builder.cursor('amount');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const number = value(frame, 'account');
    if (number.trim() === '') return { kind: 'stay', message: failure('ENTER THE ACCOUNT NUMBER.'), error: 'account' };
    const account = findAccount(context, number);
    if (account === undefined) return { kind: 'stay', message: notFound('ACCOUNT', number, context), error: 'account' };
    if (event.modified.has('account') && value(frame, 'amount').trim() === '') return { kind: 'stay', message: info('ACCOUNT FOUND. ENTER THE AMOUNT, CURRENCY AND DESCRIPTION.'), cursor: 'amount' };
    const entered = money(context, frame, account.currency);
    if ('kind' in entered) return entered;
    const terms = { accountId: account.id, expectedVersion: account.version, amount: entered, description: value(frame, 'description').trim() };
    const command: ServiceCommand = frame.direction === 'deposit' ? { kind: 'cash.deposit', ...terms } : { kind: 'cash.withdraw', ...terms };
    return beginReview(context, frame, {
      command, screenId: 'THTX04', title: frame.direction === 'deposit' ? 'Review cash deposit' : 'Review cash withdrawal', lines: [],
      fields: { amount: 'amount', description: 'description', accountId: 'account', currency: 'currency' },
    });
  },
  dirty: (frame) => anyEntered(frame, ['amount', 'description']),
  help: HELP_TOPICS.cash,
};

export const transferScreen: ScreenModule<FrameOf<'transfer'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THTX03', 'Internal transfer');
    const source = findAccount(context, value(frame, 'from'));
    const destination = findAccount(context, value(frame, 'to'));
    label(builder, 3, 1, 'From account', 20).input('from', 3, 21, 10, value(frame, 'from'));
    if (source !== undefined) accountSummary(builder, 4, source);
    else if (value(frame, 'from').trim() !== '') builder.text(4, 21, 'ACCOUNT NOT FOUND', 'warning');
    label(builder, 7, 1, 'To account', 20).input('to', 7, 21, 10, value(frame, 'to'));
    if (destination !== undefined) accountSummary(builder, 8, destination);
    else if (value(frame, 'to').trim() !== '') builder.text(8, 21, 'ACCOUNT NOT FOUND', 'warning');
    label(builder, 11, 1, 'Amount', 20).input('amount', 11, 21, 16, value(frame, 'amount'), { numeric: true });
    label(builder, 11, 40, 'Currency', 10).input('currency', 11, 50, 3, value(frame, 'currency', source?.currency ?? ''));
    label(builder, 12, 1, 'Description', 20).input('description', 12, 21, 56, value(frame, 'description'), { capacity: LIMITS.descriptionLength });
    builder.text(14, 1, 'THE SHARED RULES CHECK OWNERSHIP, CURRENCY AND FUNDS AT REVIEW AND AT POSTING.', 'label');
    if (source === undefined) builder.cursor('from');
    else if (destination === undefined) builder.cursor('to');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    for (const name of ['from', 'to'] as const) {
      if (value(frame, name).trim() === '') return { kind: 'stay', message: failure(`ENTER THE ${name === 'from' ? 'SOURCE' : 'DESTINATION'} ACCOUNT NUMBER.`), error: name };
    }
    const source = findAccount(context, value(frame, 'from'));
    if (source === undefined) return { kind: 'stay', message: notFound('ACCOUNT', value(frame, 'from'), context), error: 'from' };
    const destination = findAccount(context, value(frame, 'to'));
    if (destination === undefined) return { kind: 'stay', message: notFound('ACCOUNT', value(frame, 'to'), context), error: 'to' };
    if ((event.modified.has('from') || event.modified.has('to')) && value(frame, 'amount').trim() === '') return { kind: 'stay', message: info('ACCOUNTS FOUND. ENTER THE AMOUNT, CURRENCY AND DESCRIPTION.'), cursor: 'amount' };
    const entered = money(context, frame, source.currency);
    if ('kind' in entered) return entered;
    return beginReview(context, frame, {
      command: {
        kind: 'transfer.internal', sourceAccountId: source.id, destinationAccountId: destination.id, expectedSourceVersion: source.version,
        expectedDestinationVersion: destination.version, amount: entered, description: value(frame, 'description').trim(),
      },
      screenId: 'THTX04', title: 'Review internal transfer', lines: [],
      fields: { sourceAccountId: 'from', destinationAccountId: 'to', amount: 'amount', description: 'description', currency: 'currency' },
    });
  },
  dirty: (frame) => anyEntered(frame, ['amount', 'description']),
  help: HELP_TOPICS.transfer,
};

const NOT_PROCESSED = 'NOT PROCESSED. YOUR ENTRIES ARE KEPT.';
/** Rows 7 to 16 show review rows; row 17 stays blank above the request reference. */
const REVIEW_ROWS = 10;

type ReviewRow = { kind: 'item'; label: string; before: string; after: string } | { kind: 'text'; text: string; tone: Tone };

const monetary = (frame: FrameOf<'review'>): boolean => frame.review.amount !== null && frame.review.exponent !== null;

/**
 * Every review row of a non-monetary operation: each item, with values longer than their column
 * continued on following rows, then any stored text in full, then the shared service's consequences.
 * Nothing is shortened, so the operator confirms exactly what will be stored.
 */
function reviewRows(frame: FrameOf<'review'>): ReviewRow[] {
  const text = (value: string, tone: Tone): ReviewRow => ({ kind: 'text', text: value, tone });
  const items = frame.lines.flatMap((line) => {
    const before = wrap(line.before, 29);
    const after = wrap(line.after, 29);
    return Array.from({ length: Math.max(before.length, after.length) }, (_, index): ReviewRow => ({ kind: 'item', label: index === 0 ? line.label : '', before: before[index] ?? '', after: after[index] ?? '' }));
  });
  const body = frame.body === undefined ? [] : [text('TEXT AS IT WILL BE STORED:', 'label'), ...wrap(frame.body, 76).map((line) => text(line, 'data'))];
  const consequences = frame.review.consequences.flatMap((consequence) => wrap(consequence, 76)).map((line) => text(line, 'label'));
  return [...items, ...body, text('', 'label'), ...consequences];
}

export const reviewScreen: ScreenModule<FrameOf<'review'>> = {
  render(_context, frame) {
    const { review } = frame;
    const builder = new ScreenBuilder(frame.screenId, frame.title);
    builder.text(3, 1, 'REVIEW. NOTHING HAS BEEN POSTED OR CHANGED YET.', 'emphasis');
    label(builder, 4, 1, 'Operation', 12).data(4, 13, 34, review.commandKind).text(4, 48, 'INSTITUTION', 'label').data(4, 60, 20, upper(review.institutionName));
    let row: number;
    if (review.amount !== null && review.exponent !== null) {
      label(builder, 6, 1, 'Amount', 12).data(6, 13, 30, `${amount(review.amount.minorUnits, review.amount.currency, review.exponent)} ${review.amount.currency}`, 'emphasis');
      label(builder, 7, 1, 'Description', 12).data(7, 13, 66, review.description ?? '');
      heading(builder, 9, [[1, 'ACCOUNT'], [12, 'OWNER'], [36, 'BALANCE'], [46, 'BEFORE'.padStart(16)], [63, 'AFTER'.padStart(16)]]);
      row = 10;
      for (const account of review.accounts) {
        const cell = (minorUnits: number): string => column(minorUnits, account.currency, account.exponent, 16);
        builder.data(row, 1, 10, account.accountNumber).data(row, 12, 23, account.ownerName).text(row, 36, 'POSTED', 'label')
          .data(row, 46, 16, cell(account.postedBeforeMinorUnits)).data(row, 63, 16, cell(account.postedAfterMinorUnits), 'emphasis');
        builder.data(row + 1, 12, 23, `${account.memberNumber} ${account.currency}`, 'label').text(row + 1, 36, 'AVAILABLE', 'label')
          .data(row + 1, 46, 16, cell(account.availableBeforeMinorUnits)).data(row + 1, 63, 16, cell(account.availableAfterMinorUnits), 'emphasis');
        row += 2;
      }
      const consequences = review.consequences.flatMap((consequence) => wrap(consequence, 76));
      consequences.slice(0, Math.max(0, 17 - row)).forEach((line, index) => builder.data(row + 1 + index, 2, 76, line, 'label'));
    } else {
      heading(builder, 6, [[1, 'ITEM'], [20, 'BEFORE'], [50, 'AFTER']]);
      const rows = reviewRows(frame);
      frame.offset = clampOffset(frame.offset, REVIEW_ROWS, rows.length);
      if (rows.length > REVIEW_ROWS) builder.page = pageLabel(frame.offset, REVIEW_ROWS, rows.length);
      rows.slice(frame.offset, frame.offset + REVIEW_ROWS).forEach((entry, index) => {
        if (entry.kind === 'item') builder.data(7 + index, 1, 18, entry.label, 'label').data(7 + index, 20, 29, entry.before).data(7 + index, 50, 29, entry.after, 'emphasis');
        else if (entry.text !== '') builder.data(7 + index, 2, 76, entry.text, entry.tone);
      });
    }
    label(builder, 18, 1, 'Request reference', 19).data(18, 20, 40, frame.idempotencyKey, 'label');
    label(builder, 19, 1, 'TYPE Y TO PROCESS, N TO RETURN', 33).input('confirm', 19, 34, 1, value(frame, 'confirm'));
    builder.cursor('confirm');
    const paging = !monetary(frame) && reviewRows(frame).length > REVIEW_ROWS;
    return builder.legend('ENTER=Process  F1=Help  F3=Return, not processed  F12=Cancel', paging ? 'F7=Up  F8=Down  (MORE REVIEW ROWS)' : '');
  },
  input(context, frame, event) {
    if (!monetary(frame)) {
      const paged = page(frame, event.aid, REVIEW_ROWS, reviewRows(frame).length);
      if (paged !== null) return paged;
    }
    if (event.aid !== 'enter') return inactiveKey();
    const answer = upper(value(frame, 'confirm').trim());
    delete frame.values.confirm;
    if (answer === 'N') return { kind: 'pop', message: info(NOT_PROCESSED) };
    if (answer !== 'Y') return { kind: 'stay', message: failure('TYPE Y AND PRESS ENTER TO PROCESS, OR N TO RETURN.'), error: 'confirm' };
    const outcome = context.execute(frame.command, frame.idempotencyKey);
    switch (outcome.kind) {
      case 'committed':
      case 'duplicate':
        return {
          kind: 'pop', count: 2,
          push: { kind: 'receipt', values: {}, receiptNumber: outcome.receipt.receiptNumber, offset: 0, replayed: outcome.kind === 'duplicate' },
          message: outcome.kind === 'duplicate'
            ? warning('ALREADY PROCESSED EARLIER. ORIGINAL RECEIPT SHOWN; NOTHING WAS POSTED AGAIN.')
            : success(`PROCESSED. RECEIPT ${outcome.receipt.receiptNumber}. F3 RETURNS TO WHERE YOU STARTED.`),
        };
      case 'unchanged':
        return { kind: 'pop', message: info(upper(outcome.message)) };
      case 'rejected': {
        if (outcome.code === 'stale_version') return { kind: 'pop', markConflict: true, message: failure(CONFLICT_MESSAGE) };
        const { message, error } = rejectionMessage(outcome, frame.fields);
        return { kind: 'pop', message, ...(error === undefined ? {} : { error }) };
      }
    }
  },
  exit() {
    return { kind: 'pop', message: info(NOT_PROCESSED) };
  },
  help: HELP_TOPICS.review,
};

const RECEIPT_LINES = 6;

function readReceipt(context: HostContext, receiptNumber: string) {
  const receipt = context.read((database, datasetId) => receiptByNumber(database, datasetId, receiptNumber));
  if (receipt === undefined) throw new Error(`Receipt ${receiptNumber} is not in the signed-on dataset.`);
  return receipt;
}

export const receiptScreen: ScreenModule<FrameOf<'receipt'>> = {
  render(context, frame) {
    const receipt = readReceipt(context, frame.receiptNumber);
    const { timeZone } = context.session().institution;
    const builder = new ScreenBuilder('THRC01', 'Receipt');
    label(builder, 3, 1, 'Receipt number', 16).data(3, 17, 12, receipt.receiptNumber, 'emphasis');
    if (frame.replayed) builder.text(3, 34, 'ORIGINAL RECEIPT FOR A REPEATED REQUEST', 'warning');
    label(builder, 4, 1, 'Operation', 16).data(4, 17, 30, receipt.operationKind).text(4, 50, 'STATUS', 'label').data(4, 57, 12, upper(receipt.status), 'success');
    label(builder, 5, 1, 'Reference', 16).data(5, 17, 20, receipt.businessReference).text(5, 40, 'COMMITTED', 'label').data(5, 50, 16, localDateTime(receipt.committedAt, timeZone));
    label(builder, 6, 1, 'Operator', 16).data(6, 17, 50, `${receipt.actor.actorNumber} ${receipt.actor.displayName}`);
    heading(builder, 8, [[1, 'S'], [3, 'AFFECTED'], [16, 'RECORD']]);
    receipt.affected.slice(0, 4).forEach((record, index) => {
      builder.input(`sel.${index}`, 9 + index, 1, 1, value(frame, `sel.${index}`)).data(9 + index, 3, 12, upper(record.kind)).data(9 + index, 16, 40, record.label);
    });
    if (receipt.affected.length > 4) builder.text(12, 58, `+${receipt.affected.length - 4} MORE`, 'warning');
    const lines = receipt.journals.flatMap((journal) => journal.lines.map((line) => ({ journal, line })));
    heading(builder, 13, [[1, 'JOURNAL'], [18, 'LN'], [21, 'LEDGER/ACCOUNT'], [38, 'DEBIT'.padStart(14)], [53, 'CREDIT'.padStart(14)], [68, 'CUR'], [72, 'MEMO']]);
    frame.offset = Math.min(frame.offset, Math.max(0, Math.floor((lines.length - 1) / RECEIPT_LINES) * RECEIPT_LINES));
    lines.slice(frame.offset, frame.offset + RECEIPT_LINES).forEach(({ journal, line }, index) => {
      const exponent = currencyExponent(context, line.currency);
      if (exponent === undefined) throw new Error(`Receipt ${receipt.receiptNumber} posts ${line.currency}, which the institution does not define.`);
      const cell = (minorUnits: number): string => minorUnits === 0 ? '' : column(minorUnits, line.currency, exponent, 14);
      builder.data(14 + index, 1, 16, journal.reference).data(14 + index, 18, 2, String(line.lineNumber).padStart(2)).data(14 + index, 21, 16, line.accountNumber ?? line.ledgerCode)
        .data(14 + index, 38, 14, cell(line.debitMinorUnits)).data(14 + index, 53, 14, cell(line.creditMinorUnits)).data(14 + index, 68, 3, line.currency).data(14 + index, 72, 8, line.memo, 'label');
    });
    if (lines.length === 0) builder.text(14, 1, 'NO JOURNAL ENTRIES: THIS OPERATION DID NOT MOVE MONEY.', 'label');
    builder.page = lines.length > RECEIPT_LINES ? `LINES ${pageLabel(frame.offset, RECEIPT_LINES, lines.length)}` : null;
    builder.text(20, 1, 'SEL: S=OPEN AFFECTED RECORD', 'label');
    return builder.legend('ENTER=Select  F1=Help  F3=Return  F7=Up  F8=Down');
  },
  input(context, frame, event) {
    const receipt = readReceipt(context, frame.receiptNumber);
    const paged = page(frame, event.aid, RECEIPT_LINES, receipt.journals.reduce((total, journal) => total + journal.lines.length, 0));
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    const picked = selection(frame, Math.min(4, receipt.affected.length));
    if (picked === null) return { kind: 'stay', message: info('TYPE S BESIDE AN AFFECTED RECORD TO OPEN IT.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const record = receipt.affected[picked.index];
    if (picked.code !== 'S' || record === undefined) return badSelection(picked.code, 'S', picked.index);
    if (record.kind === 'member') return { kind: 'push', frame: memberFrame(record.id) };
    if (record.kind === 'account') return { kind: 'push', frame: accountFrame(record.id) };
    if (record.kind === 'case') return { kind: 'push', frame: caseFrame(record.id) };
    return { kind: 'stay', message: failure(`NO INQUIRY SCREEN FOR A ${upper(record.kind)} RECORD. OPEN ITS MEMBER, ACCOUNT OR CASE.`), error: `sel.${picked.index}` };
  },
  help: HELP_TOPICS.receipt,
};

export const receiptLookupScreen: ScreenModule<FrameOf<'receipt-lookup'>> = {
  render(_context, frame) {
    const builder = new ScreenBuilder('THRC02', 'Receipt inquiry');
    label(builder, 3, 1, 'Receipt number', 20).input('receipt', 3, 21, 11, value(frame, 'receipt'));
    builder.text(5, 1, 'TYPE A RECEIPT NUMBER SUCH AS RCP00000012 AND PRESS ENTER.', 'label');
    return builder.legend('ENTER=Show receipt  F1=Help  F3=Return');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const number = upper(value(frame, 'receipt').trim());
    if (number === '') return { kind: 'stay', message: failure('ENTER A RECEIPT NUMBER.'), error: 'receipt' };
    const receipt = context.read((database, datasetId) => receiptByNumber(database, datasetId, number));
    if (receipt === undefined) return { kind: 'stay', message: failure(`RECEIPT ${number.slice(0, 12)} NOT FOUND AT ${upper(context.session().institution.displayName)}.`), error: 'receipt' };
    return { kind: 'push', frame: { kind: 'receipt', values: {}, receiptNumber: receipt.receiptNumber, offset: 0, replayed: false } };
  },
  help: HELP_TOPICS['receipt-lookup'],
};
