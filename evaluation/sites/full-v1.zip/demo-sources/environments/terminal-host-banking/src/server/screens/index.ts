import type { Frame, FrameKind, FrameOf } from '../host/frames.js';
import type { ScreenModule } from '../host/module.js';
import { accountCloseScreen, accountListScreen, accountOpenScreen, accountProfileScreen, accountScreen } from './accounts.js';
import { activityScreen, eventScreen } from './activity.js';
import { caseListScreen, caseOpenScreen, caseRouteScreen, caseScreen, caseStatusScreen, caseSubjectCorrectScreen } from './cases.js';
import { entryScreen, historyScreen } from './history.js';
import { contactScreen, memberCreateScreen, memberListScreen, memberScreen } from './members.js';
import { cashScreen, receiptLookupScreen, receiptScreen, reviewScreen, transferScreen } from './money.js';
import { noteAddScreen, noteScreen, notesScreen } from './notes.js';
import { searchEditScreen, searchesScreen, searchResultsScreen } from './searches.js';
import { helpScreen, menuScreen, signOnScreen } from './session.js';
import { exportScreen, statementScreen, statementsScreen } from './statements.js';
import { approvalRequestScreen, approvalScreen } from './approvals.js';
import { batchScreen } from './batches.js';
import { directoryScreen } from './dirs.js';
import { docViewScreen, stmtExportScreen } from './docs.js';
import { maintenanceScreen } from './maintenance.js';
import { opFormScreen } from './ops.js';
import { qresultScreen, recordScreen } from './records.js';

type Modules = { [K in FrameKind]: ScreenModule<FrameOf<K>> };

const MODULES: Modules = {
  signon: signOnScreen, menu: menuScreen, help: helpScreen,
  'member-list': memberListScreen, member: memberScreen, 'member-create': memberCreateScreen, contact: contactScreen,
  notes: notesScreen, 'note-add': noteAddScreen, note: noteScreen,
  'account-list': accountListScreen, account: accountScreen, 'account-open': accountOpenScreen, 'account-profile': accountProfileScreen, 'account-close': accountCloseScreen,
  cash: cashScreen, transfer: transferScreen, review: reviewScreen, receipt: receiptScreen, 'receipt-lookup': receiptLookupScreen,
  history: historyScreen, entry: entryScreen, statements: statementsScreen, statement: statementScreen, export: exportScreen,
  activity: activityScreen, event: eventScreen,
  'case-list': caseListScreen, case: caseScreen, 'case-open': caseOpenScreen, 'case-route': caseRouteScreen, 'case-status': caseStatusScreen, 'case-subject-correct': caseSubjectCorrectScreen,
  searches: searchesScreen, 'search-results': searchResultsScreen, 'search-edit': searchEditScreen,
  directory: directoryScreen, record: recordScreen, opform: opFormScreen,
  approval: approvalScreen, 'approval-request': approvalRequestScreen,
  qresult: qresultScreen, docview: docViewScreen, maintenance: maintenanceScreen, batch: batchScreen, 'stmt-export': stmtExportScreen,
};

/** The module for a frame. The mapped type ties each kind to its module, so a module only receives its own frames. */
export function moduleFor(frame: Frame): ScreenModule<Frame> {
  return MODULES[frame.kind];
}
