import { createHash } from 'node:crypto';

import {
  accountDocuments, accountTransactions, documentContent, renderGeneratedStatement, statementData, statementPeriods, transactionsCsv,
  type AccountRow, type TransactionRow,
} from '@computer-use/financial-database/services';

import { failure, info, success, type FrameOf, type StatementRow } from '../host/frames.js';
import { amount, column, isIsoDate, localDateTime, upper } from '../host/format.js';
import type { DownloadFile, HostContext, Outcome, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  accountFrame, badSelection, clampOffset, exportFrame, inactiveKey, label, LIST_ROWS, LIST_TOP, memberFrame, page, pageLabel, readAccount, rowsLabel, selection, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';

/** Exports larger than this are refused so an operator never receives a silently shortened file. */
export const MAX_EXPORT_ROWS = 10_000;
const EXPORT_PAGE = 200;
const STATEMENT_ENTRIES = 10;

function extension(mediaType: string): string {
  return mediaType === 'application/pdf' ? 'pdf' : mediaType === 'text/csv' ? 'csv' : mediaType === 'image/png' ? 'png' : 'bin';
}

function kilobytes(byteLength: number): string {
  return `${Math.max(1, Math.ceil(byteLength / 1024))}K`;
}

/** Stored document versions first within each month, then the ledger period that can be generated. */
function statementRows(context: HostContext, accountId: string): StatementRow[] {
  const { documents, periods } = context.read((database, datasetId) => ({
    documents: accountDocuments(database, datasetId, accountId, {institutionId:context.session().binding.institutionId,actorId:context.session().operator.actorId}), periods: statementPeriods(database, datasetId, accountId),
  }));
  const stored: StatementRow[] = documents.map((document) => ({
    kind: 'stored', versionId: document.versionId, period: document.periodStart?.slice(0, 7) ?? '', label: document.displayName, version: document.version,
    mediaType: document.mediaType, issuedAt: document.issuedAt, byteLength: document.byteLength,
  }));
  const generated: StatementRow[] = periods.map((period) => ({
    kind: 'period', versionId: null, period, label: `LEDGER PERIOD ${period}`, version: null, mediaType: 'application/pdf', issuedAt: null, byteLength: null,
  }));
  return [...stored, ...generated].sort((a, b) => b.period.localeCompare(a.period) || (a.kind === b.kind ? 0 : a.kind === 'stored' ? -1 : 1));
}

function offered(context: HostContext, frame: FrameOf<'statements'> | FrameOf<'statement'> | FrameOf<'export'>, file: DownloadFile): Outcome {
  frame.transfer = context.offer(file);
  return { kind: 'stay', message: success(`FILE READY: ${file.fileName.slice(0, 44)} (${kilobytes(file.bytes.byteLength)}). ALT+D OR THE LINK DOWNLOADS IT.`) };
}

/** Stored bytes are served only when they still match the digest recorded when the version was issued. */
function storedDownload(context: HostContext, accountId: string, versionId: string): DownloadFile | string {
  const document = context.read((database, datasetId) => documentContent(database, datasetId, versionId, {institutionId:context.session().binding.institutionId,actorId:context.session().operator.actorId}));
  if (document === undefined || document.accountId !== accountId) return 'THIS DOCUMENT VERSION IS NO LONGER LISTED FOR THE ACCOUNT.';
  const digest = createHash('sha256').update(document.bytes).digest('hex');
  if (digest !== document.digest) return 'STORED DOCUMENT FAILED ITS INTEGRITY CHECK AND WAS NOT OFFERED. REPORT IT.';
  const { institutionId } = context.session().institution;
  return {
    fileName: `${institutionId}-${document.displayName.replace(/\.[a-z]+$/iu, '')}-v${document.version}.${extension(document.mediaType)}`,
    mediaType: document.mediaType, bytes: document.bytes, digest,
  };
}

async function generatedDownload(context: HostContext, accountId: string, period: string): Promise<DownloadFile | string> {
  const statement = context.read((database, datasetId) => statementData(database, datasetId, accountId, period));
  if (statement === undefined) return `NO STATEMENT PERIOD ${period} FOR THIS ACCOUNT.`;
  const { institution } = context.session();
  const artifact = await renderGeneratedStatement(statement, institution.asOf);
  return { fileName: `${institution.institutionId}-${statement.account.accountNumber}-statement-${period}.pdf`, mediaType: artifact.mediaType, bytes: artifact.bytes, digest: artifact.digest };
}

function heading(builder: ScreenBuilder, row: number, columns: readonly (readonly [number, string])[]): void {
  for (const [at, text] of columns) builder.text(row, at, text, 'label');
}

function accountLine(builder: ScreenBuilder, account: AccountRow): void {
  label(builder, 3, 1, 'Account', 9).data(3, 10, 10, account.accountNumber).data(3, 21, 36, account.ownerName, 'emphasis').data(3, 58, 21, `${account.memberNumber} ${account.currency} ${upper(account.status)}`, 'label');
}

export const statementsScreen: ScreenModule<FrameOf<'statements'>> = {
  render(context, frame) {
    const { account } = readAccount(context, frame.accountId);
    const { timeZone } = context.session().institution;
    const rows = statementRows(context, frame.accountId);
    frame.offset = clampOffset(frame.offset, LIST_ROWS, rows.length);
    frame.total = rows.length;
    frame.rows = rows.slice(frame.offset, frame.offset + LIST_ROWS);
    const builder = new ScreenBuilder('THST01', 'Statements and documents');
    builder.page = pageLabel(frame.offset, LIST_ROWS, rows.length);
    accountLine(builder, account);
    builder.text(5, 1, 'STORED = ISSUED VERSION, FIXED BYTES.  LEDGER = GENERATED FROM POSTED ENTRIES.', 'label');
    heading(builder, 6, [[1, 'S'], [3, 'PERIOD'], [11, 'SOURCE'], [19, 'DOCUMENT'], [53, 'VER'], [57, 'ISSUED'], [74, 'SIZE']]);
    frame.rows.forEach((row, index) => {
      const line = LIST_TOP + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 7, row.period === '' ? '-' : row.period).data(line, 11, 7, row.kind === 'stored' ? 'STORED' : 'LEDGER', row.kind === 'stored' ? 'emphasis' : 'label')
        .data(line, 19, 33, row.label).data(line, 53, 3, row.version === null ? '' : String(row.version))
        .data(line, 57, 16, row.issuedAt === null ? '' : localDateTime(row.issuedAt, timeZone)).data(line, 74, 5, row.byteLength === null ? '' : kilobytes(row.byteLength));
    });
    if (rows.length === 0) builder.text(LIST_TOP, 3, 'NO DOCUMENTS OR LEDGER PERIODS FOR THIS ACCOUNT.', 'warning');
    builder.text(19, 1, 'SEL: V=VIEW LEDGER PERIOD  D=DOWNLOAD FILE', 'label');
    builder.data(20, 1, 40, rowsLabel(frame.offset, frame.rows.length, rows.length), 'label');
    return builder.legend('ENTER=Select  F1=Help  F3=Return  F7=Up  F8=Down', 'F5=Export CSV  F6=Account');
  },
  async input(context, frame, event) {
    if (event.aid === 'pf5') return { kind: 'push', frame: exportFrame(frame.accountId) };
    if (event.aid === 'pf6') return { kind: 'push', frame: accountFrame(frame.accountId) };
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE V OR D BESIDE A ROW AND PRESS ENTER.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const row = frame.rows[picked.index];
    if (row === undefined) return badSelection(picked.code, 'A LISTED ROW', picked.index);
    frame.cursor = `sel.${picked.index}`;
    if (picked.code === 'V') {
      if (row.kind === 'stored') return { kind: 'stay', message: failure('A STORED DOCUMENT IS NOT SHOWN ON THE TERMINAL. USE D TO DOWNLOAD IT.'), error: `sel.${picked.index}` };
      return { kind: 'push', frame: { kind: 'statement', values: {}, accountId: frame.accountId, period: row.period, offset: 0 } };
    }
    if (picked.code !== 'D') return badSelection(picked.code, 'V OR D', picked.index);
    const file = row.kind === 'stored' && row.versionId !== null ? storedDownload(context, frame.accountId, row.versionId) : await generatedDownload(context, frame.accountId, row.period);
    if (typeof file === 'string') return { kind: 'stay', message: failure(file), error: `sel.${picked.index}` };
    return offered(context, frame, file);
  },
  help: HELP_TOPICS.statements,
};

export const statementScreen: ScreenModule<FrameOf<'statement'>> = {
  render(context, frame) {
    const statement = context.read((database, datasetId) => statementData(database, datasetId, frame.accountId, frame.period));
    if (statement === undefined) throw new Error(`Statement period ${frame.period} is not valid for account ${frame.accountId}.`);
    const { account } = statement;
    const money = (minorUnits: number): string => column(minorUnits, account.currency, account.exponent, 18);
    const builder = new ScreenBuilder('THST02', `Statement ${frame.period}`);
    frame.offset = clampOffset(frame.offset, STATEMENT_ENTRIES, statement.entries.length);
    builder.page = pageLabel(frame.offset, STATEMENT_ENTRIES, statement.entries.length);
    accountLine(builder, account);
    label(builder, 4, 1, 'Period', 9).data(4, 10, 30, `${statement.periodStart} TO ${statement.periodEndExclusive} (EXCL)`).data(4, 44, 35, upper(statement.institutionName), 'label');
    label(builder, 5, 1, 'Opening', 12).data(5, 13, 18, money(statement.openingMinorUnits)).text(5, 40, 'CREDITS', 'label').data(5, 50, 18, money(statement.creditsMinorUnits));
    label(builder, 6, 1, 'Closing', 12).data(6, 13, 18, money(statement.closingMinorUnits), 'emphasis').text(6, 40, 'DEBITS', 'label').data(6, 50, 18, money(-statement.debitsMinorUnits));
    heading(builder, 8, [[1, 'DATE'], [12, 'REFERENCE'], [30, 'DESCRIPTION'], [58, 'AMOUNT'.padStart(18)]]);
    statement.entries.slice(frame.offset, frame.offset + STATEMENT_ENTRIES).forEach((entry, index) => {
      builder.data(9 + index, 1, 10, entry.date).data(9 + index, 12, 17, entry.reference).data(9 + index, 30, 27, entry.description)
        .data(9 + index, 58, 18, money(entry.amountMinorUnits), entry.amountMinorUnits < 0 ? 'warning' : 'data');
    });
    if (statement.entries.length === 0) builder.text(9, 1, 'NO POSTED ENTRIES IN THIS PERIOD.', 'label');
    builder.data(20, 1, 78, `POSTED ENTRIES ONLY. AMOUNTS IN ${account.currency}. ${amount(statement.closingMinorUnits, account.currency, account.exponent)} CLOSING.`, 'label');
    return builder.legend('F1=Help  F3=Return  F7=Up  F8=Down', 'F4=Member  F6=Account  F9=Prepare PDF');
  },
  async input(context, frame, event) {
    if (event.aid === 'pf4') return { kind: 'push', frame: memberFrame(readAccount(context, frame.accountId).account.memberId) };
    if (event.aid === 'pf6') return { kind: 'push', frame: accountFrame(frame.accountId) };
    if (event.aid === 'pf9') {
      const file = await generatedDownload(context, frame.accountId, frame.period);
      if (typeof file === 'string') return { kind: 'stay', message: failure(file) };
      return offered(context, frame, file);
    }
    const entries = context.read((database, datasetId) => statementData(database, datasetId, frame.accountId, frame.period))?.entries.length ?? 0;
    return page(frame, event.aid, STATEMENT_ENTRIES, entries) ?? inactiveKey();
  },
  help: HELP_TOPICS.statement,
};

/** Every matching ledger line in one read, oldest first, or null when the export would exceed the limit. */
function exportRows(context: HostContext, accountId: string, range: { startDate?: string; endDate?: string }): TransactionRow[] | null {
  return context.read((database, datasetId) => {
    const rows: TransactionRow[] = [];
    for (let offset = 0; ; offset += EXPORT_PAGE) {
      const result = accountTransactions(database, datasetId, accountId, { ...range, order: 'oldest', limit: EXPORT_PAGE, offset });
      if (result.total > MAX_EXPORT_ROWS) return null;
      rows.push(...result.items);
      if (offset + EXPORT_PAGE >= result.total) return rows;
    }
  });
}

export const exportScreen: ScreenModule<FrameOf<'export'>> = {
  render(context, frame) {
    const { account } = readAccount(context, frame.accountId);
    const builder = new ScreenBuilder('THEX01', 'Transaction export');
    accountLine(builder, account);
    label(builder, 5, 1, 'From date (incl)', 20).input('from', 5, 21, 10, value(frame, 'from'));
    label(builder, 6, 1, 'To date (excl)', 20).input('to', 6, 21, 10, value(frame, 'to'));
    builder.text(8, 1, 'BLANK DATES EXPORT THE WHOLE HISTORY. DATES ARE EFFECTIVE DATES, YYYY-MM-DD.', 'label');
    builder.text(9, 1, `CSV OF POSTED AND REVERSED LINES, OLDEST FIRST. OVER ${MAX_EXPORT_ROWS} ROWS IS REFUSED.`, 'label');
    if (frame.transfer !== undefined) {
      label(builder, 11, 1, 'Prepared file', 20).data(11, 21, 58, frame.transfer.fileName, 'emphasis');
      label(builder, 12, 1, 'SHA-256', 20).data(12, 21, 58, frame.transfer.digest, 'label');
    }
    return builder.legend('ENTER=Prepare CSV  F1=Help  F3=Return  ALT+D=Download');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const from = value(frame, 'from').trim();
    const to = value(frame, 'to').trim();
    if (from !== '' && !isIsoDate(from)) return { kind: 'stay', message: failure('FROM DATE MUST BE A VALID YYYY-MM-DD DATE.'), error: 'from' };
    if (to !== '' && !isIsoDate(to)) return { kind: 'stay', message: failure('TO DATE MUST BE A VALID YYYY-MM-DD DATE.'), error: 'to' };
    if (from !== '' && to !== '' && from >= to) return { kind: 'stay', message: failure('THE TO DATE IS EXCLUSIVE AND MUST BE AFTER THE FROM DATE.'), error: 'to' };
    const rows = exportRows(context, frame.accountId, { ...(from === '' ? {} : { startDate: from }), ...(to === '' ? {} : { endDate: to }) });
    if (rows === null) return { kind: 'stay', message: failure(`MORE THAN ${MAX_EXPORT_ROWS} ROWS MATCH. NARROW THE DATE RANGE.`), error: 'from' };
    const { account } = readAccount(context, frame.accountId);
    const artifact = transactionsCsv(account, rows);
    const { institutionId } = context.session().institution;
    const outcome = offered(context, frame, {
      fileName: `${institutionId}-${account.accountNumber}-transactions-${from || 'start'}_${to || 'now'}.csv`, mediaType: artifact.mediaType, bytes: artifact.bytes, digest: artifact.digest,
    });
    return rows.length === 0 ? { ...outcome, message: info('NO ENTRIES IN THAT RANGE. A CSV WITH ONLY THE HEADER ROW IS READY.') } : outcome;
  },
  help: HELP_TOPICS.export,
};
