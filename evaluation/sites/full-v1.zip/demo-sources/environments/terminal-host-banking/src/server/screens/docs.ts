import {
  documentContent, exportStatement, listDocumentAnnotations, listDocumentSignatures,
} from '@computer-use/financial-database/services';


import { failure, success, type FrameOf } from '../host/frames.js';
import { localDateTime, upper } from '../host/format.js';
import type { HostContext, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { inactiveKey, label, readAccount, serviceContext, value } from './common.js';
import { directoryFrame } from './dirs.js';
import { HELP_TOPICS } from './help-text.js';
import { opFrame } from './ops.js';

/** The document owner's reader identity, so the shared read policy applies to bytes too. */
function readerOf(context: HostContext) {
  const { institution, operator } = context.session();
  return { institutionId: institution.institutionId, actorId: operator.actorId };
}

function loadVersion(context: HostContext, versionId: string) {
  return context.read((database, datasetId) => database.prepare(
    `SELECT v.id AS version_id,v.document_id,v.version,v.media_type,v.digest,v.issued_at,v.period_start,v.period_end,v.page_count,v.status,
      d.document_type,d.display_name,d.retention_class,d.account_id,d.owner_party_id,d.created_at,
      m.member_number,p.display_name AS owner_name,a.account_number
     FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
     LEFT JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id
     LEFT JOIN parties p ON p.dataset_id=d.dataset_id AND p.id=d.owner_party_id
     LEFT JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id
     WHERE v.dataset_id=? AND v.id=?`,
  ).get(datasetId, versionId));
}

export const docViewScreen: ScreenModule<FrameOf<'docview'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THDC01', 'Document view');
    const hit = loadVersion(context, frame.versionId);
    if (hit === undefined) {
      builder.text(4, 1, 'DOCUMENT VERSION NOT FOUND OR NOT READABLE.', 'warning');
      return builder.legend('F3=Return  F12=Cancel');
    }
    const str = (key: string): string => String(hit[key] as string | number | null ?? '');
    const { timeZone } = context.session().institution;
    label(builder, 3, 1, 'Document', 16).data(3, 17, 40, `${str('display_name')}  V${str('version')}`, 'emphasis');
    label(builder, 4, 1, 'Type', 16).data(4, 17, 24, str('document_type')).text(4, 42, 'STATUS', 'label').data(4, 49, 10, upper(str('status')));
    label(builder, 5, 1, 'Owner', 16).data(5, 17, 40, `${str('member_number')} ${str('owner_name')}`).text(5, 58, 'ACCOUNT', 'label').data(5, 66, 12, str('account_number'));
    label(builder, 6, 1, 'Issued', 16).data(6, 17, 18, localDateTime(str('issued_at'), timeZone)).text(6, 36, 'RETENTION', 'label').data(6, 46, 16, str('retention_class'));
    if (str('period_start') !== '') label(builder, 7, 1, 'Period', 16).data(7, 17, 26, `${str('period_start')} .. ${str('period_end')}`);
    label(builder, 8, 1, 'Media', 16).data(8, 17, 24, str('media_type')).text(8, 42, 'PAGES', 'label').data(8, 48, 6, str('page_count'));
    label(builder, 9, 1, 'SHA-256', 16).data(9, 17, 64, str('digest'), 'label');
    label(builder, 10, 1, 'Version id', 16).data(10, 17, 62, str('version_id'), 'label');
    const signatures = context.read((database) => listDocumentSignatures(database, serviceContext(context, 'signatures'), frame.versionId));
    if (signatures.kind === 'authorized' && signatures.value.length > 0) {
      builder.text(12, 1, 'SIGNATURES:', 'label');
      signatures.value.slice(0, 3).forEach((sig, index) => builder.data(13 + index, 2, 76, `${sig.status}  signer ${sig.signerPartyId}  ${sig.signedAt ?? 'unsigned'}`));
    }
    const annotations = context.read((database) => listDocumentAnnotations(database, serviceContext(context, 'annotations'), frame.versionId));
    if (annotations.kind === 'authorized' && annotations.value.length > 0) {
      builder.text(17, 1, `${annotations.value.length} ANNOTATION(S). F6 OPENS THE ANNOTATION LIST.`, 'label');
    }
    if (frame.transfer !== undefined) builder.text(18, 1, `FILE READY: ${frame.transfer.fileName} (${frame.transfer.byteLength} B). ALT+D OR THE LINK DOWNLOADS IT.`, 'success');
    return builder.legend('F5=Download  F6=Annotations  F9=Signatures  F10=Annotate  F1=Help  F3=Return');
  },
  input(context, frame, event) {
    if (event.aid === 'pf5') {
      const hit = loadVersion(context, frame.versionId);
      if (hit === undefined) return { kind: 'stay', message: failure('DOCUMENT VERSION NOT FOUND.') };
      const content = context.read((database, datasetId) => documentContent(database, datasetId, frame.versionId, readerOf(context)));
      if (content === undefined) return { kind: 'stay', message: failure('THIS DOCUMENT IS NOT READABLE BY YOUR OPERATOR PROFILE.') };
      frame.transfer = context.offer({ fileName: content.displayName, mediaType: content.mediaType, bytes: content.bytes, digest: content.digest });
      return { kind: 'stay', message: success(`PREPARED ${upper(content.displayName)} SHA-256 ${content.digest.slice(0, 12)}... ALT+D OR THE LINK DOWNLOADS IT.`) };
    }
    if (event.aid === 'pf6') return { kind: 'push', frame: directoryFrame('annotations', { versionId: frame.versionId, 'versionId.label': String(loadVersion(context, frame.versionId)?.display_name ?? '') }) };
    if (event.aid === 'pf9') return { kind: 'push', frame: directoryFrame('signatures', { versionId: frame.versionId, 'versionId.label': String(loadVersion(context, frame.versionId)?.display_name ?? '') }) };
    if (event.aid === 'pf10') return { kind: 'push', frame: opFrame('document.annotation.update', { version: frame.versionId }) };
    return inactiveKey();
  },
  help: HELP_TOPICS.docview,
};

type ExportFormat = 'html' | 'csv' | 'pdf';

export const stmtExportScreen: ScreenModule<FrameOf<'stmt-export'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THEX02', 'Statement export');
    const account = readAccount(context, frame.accountId);
    label(builder, 3, 1, 'Account', 20).data(3, 21, 40, `${account.account.accountNumber}  ${account.account.ownerName}`, 'emphasis');
    label(builder, 5, 1, 'Period', 20).input('period', 5, 21, 7, value(frame, 'period')).text(5, 30, 'YYYY-MM', 'label');
    label(builder, 6, 1, 'Formats', 20).input('fmt.html', 6, 21, 1, value(frame, 'fmt.html')).text(6, 23, 'HTML', 'label').input('fmt.csv', 6, 28, 1, value(frame, 'fmt.csv')).text(6, 30, 'CSV', 'label').input('fmt.pdf', 6, 34, 1, value(frame, 'fmt.pdf')).text(6, 36, 'PDF  (Y SELECTS EACH)', 'label');
    label(builder, 7, 1, 'Destination', 20).data(7, 21, 30, 'TERMINAL DOWNLOAD', 'emphasis');
    builder.data(9, 1, 78, 'THE EXPORT IS A LEDGER-SNAPSHOT BUNDLE: EACH FILE IS GENERATED FROM POSTED ENTRIES', 'label');
    builder.data(10, 1, 78, 'AT THE OBSERVED TIME. ISSUED STATEMENT VERSIONS ARE NEVER REPLACED.', 'label');
    if (frame.artifacts.length > 0) {
      builder.text(12, 1, 'PREPARED FILES — TYPE D BESIDE ONE TO OFFER ITS DOWNLOAD:', 'emphasis');
      frame.artifacts.forEach((artifact, index) => {
        builder.input(`sel.${index}`, 13 + index, 1, 1, value(frame, `sel.${index}`));
        builder.data(13 + index, 3, 34, artifact.fileName).data(13 + index, 38, 10, `${artifact.byteLength}B`).data(13 + index, 49, 30, artifact.digest.slice(0, 30), 'label');
      });
    }
    if (frame.transfer !== undefined) builder.text(17, 1, `OFFERED: ${frame.transfer.fileName}. ALT+D OR THE LINK DOWNLOADS IT.`, 'success');
    return builder.legend('ENTER=Export  D=Offer file  F1=Help  F3=Return  F12=Cancel');
  },
  async input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    for (let index = 0; index < frame.artifacts.length; index += 1) {
      if (upper(value(frame, `sel.${index}`).trim()) === 'D') {
        Reflect.deleteProperty(frame.values, `sel.${index}`);
        const artifact = frame.artifacts[index];
        if (artifact === undefined) break;
        frame.transfer = artifact;
        return { kind: 'stay', message: success(`OFFERED ${upper(artifact.fileName)}.`) };
      }
    }
    const period = value(frame, 'period').trim();
    if (!/^\d{4}-(0[1-9]|1[0-2])$/u.test(period)) return { kind: 'stay', message: failure('ENTER THE PERIOD AS YYYY-MM.'), error: 'period' };
    const formats: ExportFormat[] = [];
    if (upper(value(frame, 'fmt.html').trim()) === 'Y') formats.push('html');
    if (upper(value(frame, 'fmt.csv').trim()) === 'Y') formats.push('csv');
    if (upper(value(frame, 'fmt.pdf').trim()) === 'Y') formats.push('pdf');
    if (formats.length === 0) return { kind: 'stay', message: failure('SELECT AT LEAST ONE FORMAT: Y UNDER HTML, CSV OR PDF.'), error: 'fmt.html' };
    const memberId = context.read((database, datasetId) => {
      const rowValue = database.prepare('SELECT member_id FROM accounts WHERE dataset_id=? AND id=?').get(datasetId, frame.accountId) as { member_id?: string } | undefined;
      return rowValue?.member_id ?? '';
    });
    const result = await context.svc((store, ctx) => exportStatement(store, ctx, {
      memberId, accountId: frame.accountId, period, formats, destinationId: 'terminal-download',
    }, ['terminal-download']));
    if (result.kind !== 'artifacts') return { kind: 'stay', message: failure(upper(result.message)), error: 'period' };
    frame.artifacts = result.artifacts.map((artifact) => context.offer({
      fileName: artifact.displayName, mediaType: artifact.mediaType, bytes: artifact.bytes,
      digest: artifact.digest,
    }));
    return { kind: 'stay', message: success(`EXPORTED ${frame.artifacts.length} FILE(S) FOR ${period} AT ${result.observedAt.slice(0, 10)}. TYPE D BESIDE ONE TO OFFER IT.`) };
  },
  dirty: (frame) => ['period', 'fmt.html', 'fmt.csv', 'fmt.pdf'].some((name) => value(frame, name).trim() !== ''),
  help: HELP_TOPICS['stmt-export'],
};
