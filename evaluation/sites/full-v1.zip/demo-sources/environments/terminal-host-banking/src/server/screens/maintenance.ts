import type { SQLOutputValue } from 'node:sqlite';
import type { CoreCommand, MaintenanceRequestedCommand } from '@computer-use/financial-database/services';

import { info, type Frame, type FrameOf } from '../host/frames.js';
import { localDateTime, upper } from '../host/format.js';
import type { HostContext, Outcome, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { beginReview, findAccount, findMember, inactiveKey, isOutcome, label, readAccount, readMember, value } from './common.js';
import { HELP_TOPICS } from './help-text.js';
import { code, entered, fieldProblem, idList } from './ops.js';

type Row = Record<string, SQLOutputValue>;

interface StoredRequest {
  id: string;
  requestNumber: string;
  memberId: string;
  accountId: string | null;
  category: string;
  reason: string | null;
  subject: string;
  draft: Record<string, unknown>;
  state: string;
  updatedAt: string;
  appliedReceiptId: string | null;
}

function loadRequest(context: HostContext, requestId: string): StoredRequest | null {
  const hit = context.read((database, datasetId) => database.prepare(
    'SELECT * FROM maintenance_requests WHERE dataset_id=? AND id=?',
  ).get(datasetId, requestId) as Row | undefined);
  if (hit === undefined) return null;
  let draft: Record<string, unknown> = {};
  try { const parsed: unknown = JSON.parse(String(hit.draft_json ?? '{}')); if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) draft = parsed as Record<string, unknown>; } catch { /* shown empty */ }
  return {
    id: String(hit.id), requestNumber: String(hit.request_number), memberId: String(hit.member_id), accountId: hit.account_id === null || hit.account_id === undefined ? null : String(hit.account_id),
    category: String(hit.category), reason: hit.reason === null || hit.reason === undefined ? null : String(hit.reason), subject: String(hit.subject), draft, state: String(hit.state),
    updatedAt: String(hit.updated_at), appliedReceiptId: hit.applied_receipt_id === null || hit.applied_receipt_id === undefined ? null : String(hit.applied_receipt_id),
  };
}

const KINDS: Record<string, { command: MaintenanceRequestedCommand['kind']; label: string }> = {
  C: { command: 'contact.update', label: 'CONTACT UPDATE' },
  N: { command: 'member.note.add', label: 'MEMBER NOTE' },
  K: { command: 'account.nickname.update', label: 'ACCOUNT NICKNAME' },
  D: { command: 'account.statement_delivery.update', label: 'STATEMENT DELIVERY' },
  X: { command: 'account.close', label: 'ACCOUNT CLOSE' },
};

function requestedKind(frame: FrameOf<'maintenance'>): string {
  const letter = upper(entered(frame, 'kind'));
  return KINDS[letter]?.command ?? '';
}

function buildRequested(context: HostContext, frame: FrameOf<'maintenance'>): MaintenanceRequestedCommand | Outcome {
  const kind = requestedKind(frame);
  if (kind === '') return fieldProblem('kind', 'ENTER THE REQUEST KIND: C, N, K, D OR X.');
  const member = findMember(context, entered(frame, 'member'));
  if (member === undefined) return fieldProblem('member', 'MEMBER NOT FOUND.');
  const memberDetail = readMember(context, member.id);
  const accountText = entered(frame, 'account');
  const account = accountText === '' ? undefined : findAccount(context, accountText);
  if (accountText !== '' && account === undefined) return fieldProblem('account', 'ACCOUNT NOT FOUND.');
  switch (kind) {
    case 'contact.update': {
      const address = ['line1', 'line2', 'city', 'region', 'postal', 'country'].some((name) => entered(frame, name) !== '')
        ? { line1: entered(frame, 'line1'), line2: entered(frame, 'line2'), city: entered(frame, 'city'), region: entered(frame, 'region'), postalCode: entered(frame, 'postal'), country: entered(frame, 'country') }
        : undefined;
      const email = entered(frame, 'email'); const phone = entered(frame, 'phone');
      const command: CoreCommand = {
        kind: 'contact.update', memberId: member.id, expectedVersion: memberDetail.member.version,
        ...(email !== '' ? { email } : {}), ...(phone !== '' ? { phone } : {}), ...(address === undefined ? {} : { address }),
      };
      return command;
    }
    case 'member.note.add': {
      const noteText = entered(frame, 'note');
      if (noteText === '') return fieldProblem('note', 'ENTER THE NOTE TEXT.');
      const restricted = upper(entered(frame, 'restricted')) === 'R';
      return { kind: 'member.note.add', memberId: member.id, visibility: restricted ? 'restricted' : 'general', text: noteText };
    }
    case 'account.nickname.update': {
      if (account === undefined) return fieldProblem('account', 'THE REQUESTED CHANGE NEEDS AN ACCOUNT.');
      const nickname = entered(frame, 'nickname');
      if (nickname === '') return fieldProblem('nickname', 'ENTER THE NEW NICKNAME.');
      return { kind: 'account.nickname.update', accountId: account.id, expectedVersion: readAccount(context, account.id).account.version, nickname };
    }
    case 'account.statement_delivery.update': {
      if (account === undefined) return fieldProblem('account', 'THE REQUESTED CHANGE NEEDS AN ACCOUNT.');
      const delivery = code(frame, 'delivery', { P: 'paper', E: 'electronic' }, 'STATEMENT DELIVERY');
      if (typeof delivery !== 'string') return delivery;
      return { kind: 'account.statement_delivery.update', accountId: account.id, expectedVersion: readAccount(context, account.id).account.version, statementDelivery: delivery as 'paper' | 'electronic' };
    }
    case 'account.close': {
      if (account === undefined) return fieldProblem('account', 'THE REQUESTED CHANGE NEEDS AN ACCOUNT.');
      const reason = entered(frame, 'reason');
      if (reason === '') return fieldProblem('reason', 'ENTER THE CLOSURE REASON.');
      return { kind: 'account.close', accountId: account.id, expectedVersion: readAccount(context, account.id).account.version, reason };
    }
    default: return fieldProblem('kind', 'UNKNOWN REQUEST KIND.');
  }
}

export const maintenanceScreen: ScreenModule<FrameOf<'maintenance'>> = {
  render(context, frame) {
    const stored = frame.requestId === null ? null : loadRequest(context, frame.requestId);
    const builder = new ScreenBuilder(stored === null ? 'THMN01' : 'THMN02', stored === null ? 'Maintenance draft' : `Maintenance request ${stored.requestNumber}`);
    if (frame.requestId !== null && stored === null) {
      builder.text(4, 1, 'REQUEST NOT FOUND.', 'warning');
      return builder.legend('F3=Return  F12=Cancel');
    }
    let row = 3;
    if (stored !== null) {
      label(builder, row, 1, 'Request', 20).data(row, 21, 14, stored.requestNumber, 'emphasis').text(row, 36, 'STATE', 'label').data(row, 42, 12, upper(stored.state)).text(row, 55, 'UPDATED', 'label').data(row, 63, 16, localDateTime(stored.updatedAt, context.session().institution.timeZone));
      row += 1;
      const requested = stored.draft.requestedCommand as { kind?: string } | undefined;
      builder.data(row, 2, 76, `STORED DRAFT: ${requested?.kind ?? 'NONE'} — ${stored.subject}`, 'label');
      row += 1;
    }
    label(builder, row, 1, 'Member number', 20).input('member', row, 21, 10, value(frame, 'member'));
    label(builder, row, 40, 'Account', 8).input('account', row, 48, 10, value(frame, 'account'));
    row += 1;
    label(builder, row, 1, 'Category', 20).input('category', row, 21, 20, value(frame, 'category', stored?.category ?? ''));
    label(builder, row, 44, 'Kind', 5).input('kind', row, 49, 1, value(frame, 'kind')).text(row, 51, 'C N K D X', 'label');
    row += 1;
    label(builder, row, 1, 'Subject', 20).input('subject', row, 21, 58, value(frame, 'subject', stored?.subject ?? ''), { capacity: 200 });
    row += 2;
    const kind = requestedKind(frame);
    if (kind === 'contact.update') {
      builder.text(row, 1, 'CONTACT UPDATE FIELDS:', 'label'); row += 1;
      label(builder, row, 1, 'Email', 20).input('email', row, 21, 40, value(frame, 'email')); row += 1;
      label(builder, row, 1, 'Phone', 20).input('phone', row, 21, 20, value(frame, 'phone')); row += 1;
      label(builder, row, 1, 'Address', 20).input('line1', row, 21, 40, value(frame, 'line1')).input('line2', row + 1, 21, 40, value(frame, 'line2'));
      label(builder, row + 2, 1, 'City/region', 20).input('city', row + 2, 21, 20, value(frame, 'city')).input('region', row + 2, 42, 10, value(frame, 'region'));
      label(builder, row + 3, 1, 'Postal/country', 20).input('postal', row + 3, 21, 12, value(frame, 'postal')).input('country', row + 3, 34, 2, value(frame, 'country'));
      row += 4;
    } else if (kind === 'member.note.add') {
      label(builder, row, 1, 'Note text', 20).input('note', row, 21, 58, value(frame, 'note'), { capacity: 2000 }); row += 1;
      label(builder, row, 1, 'Visibility', 20).input('restricted', row, 21, 1, value(frame, 'restricted')).text(row, 23, 'G GENERAL  R RESTRICTED', 'label'); row += 1;
    } else if (kind === 'account.nickname.update') {
      label(builder, row, 1, 'New nickname', 20).input('nickname', row, 21, 40, value(frame, 'nickname')); row += 1;
    } else if (kind === 'account.statement_delivery.update') {
      label(builder, row, 1, 'Delivery', 20).input('delivery', row, 21, 1, value(frame, 'delivery')).text(row, 23, 'P PAPER  E ELECTRONIC', 'label'); row += 1;
    } else if (kind === 'account.close') {
      label(builder, row, 1, 'Close reason', 20).input('reason', row, 21, 50, value(frame, 'reason')); row += 1;
    }
    label(builder, row, 1, 'Missing fields', 20).input('missing', row, 21, 58, value(frame, 'missing'), { capacity: 500 }).text(row + 1, 21, 'SPACE-SEPARATED FIELD NAMES', 'label');
    row += 2;
    label(builder, row, 1, 'Note', 20).input('draftnote', row, 21, 58, value(frame, 'draftnote'), { capacity: 500 });
    row += 1;
    if (stored !== null && stored.state === 'submitted') {
      builder.text(row + 1, 1, 'REVIEW ACTIONS (CHECKER):', 'emphasis');
      label(builder, row + 2, 1, 'Decision', 20).input('decision', row + 2, 21, 1, value(frame, 'decision')).text(row + 2, 23, 'A APPROVE  R REJECT  I RETURN FOR INFORMATION', 'label');
      label(builder, row + 3, 1, 'Reason', 20).input('reviewreason', row + 3, 21, 58, value(frame, 'reviewreason'), { capacity: 500 });
    }
    if (stored !== null && stored.state === 'approved') {
      builder.text(row + 1, 1, 'PROCESS ACTIONS:', 'emphasis');
      label(builder, row + 2, 1, 'Disposition', 20).input('disposition', row + 2, 21, 1, value(frame, 'disposition')).text(row + 2, 23, 'A APPLY  R REJECT', 'label');
      label(builder, row + 3, 1, 'Receipt', 20).input('receipt', row + 3, 21, 12, value(frame, 'receipt')).text(row + 3, 34, 'RECEIPT OF THE COMMITTED CHANGE', 'label');
      label(builder, row + 4, 1, 'Reason', 20).input('processreason', row + 4, 21, 58, value(frame, 'processreason'), { capacity: 500 });
    }
    return builder.legend(stored === null ? 'ENTER=Save draft  F1=Help  F3=Return  F12=Cancel'
      : stored.state === 'draft' ? 'ENTER=Amend  F6=Submit  F11=Withdraw  F1=Help  F3=Return'
      : stored.state === 'submitted' ? 'ENTER=Submit review  F1=Help  F3=Return'
      : stored.state === 'approved' ? 'ENTER=Process  F1=Help  F3=Return'
      : 'F1=Help  F3=Return');
  },
  input(context, frame, event) {
    const stored = frame.requestId === null ? null : loadRequest(context, frame.requestId);
    if (stored !== null && stored.state === 'draft' && event.aid === 'pf6') {
      return beginReview(context, frame, {
        command: { kind: 'maintenance.request.submit', requestId: stored.id, expectedUpdatedAt: stored.updatedAt, declaredState: 'submitted' },
        screenId: 'THMN05', title: 'Submit maintenance request', lines: [{ label: 'Request', before: 'draft', after: 'submitted' }], fields: {},
      });
    }
    if (stored !== null && stored.state === 'draft' && event.aid === 'pf11') {
      const reason = entered(frame, 'draftnote') || 'Withdrawn from the terminal.';
      return beginReview(context, frame, {
        command: { kind: 'maintenance.request.withdraw', requestId: stored.id, expectedUpdatedAt: stored.updatedAt, reason },
        screenId: 'THMN06', title: 'Withdraw maintenance request', lines: [{ label: 'Request', before: stored.state, after: 'withdrawn' }], fields: {},
      });
    }
    if (event.aid !== 'enter') return inactiveKey();
    if (stored === null) {
      const member = findMember(context, entered(frame, 'member'));
      if (member === undefined) return fieldProblem('member', 'MEMBER NOT FOUND.');
      const accountText = entered(frame, 'account');
      const account = accountText === '' ? undefined : findAccount(context, accountText);
      if (accountText !== '' && account === undefined) return fieldProblem('account', 'ACCOUNT NOT FOUND.');
      const category = entered(frame, 'category');
      if (category === '') return fieldProblem('category', 'ENTER THE CATEGORY.');
      const subject = entered(frame, 'subject');
      if (subject === '') return fieldProblem('subject', 'ENTER THE SUBJECT.');
      const requested = buildRequested(context, frame);
      if (isOutcome(requested)) return requested;
      const missing = idList(frame, 'missing', 'MISSING FIELDS', { max: 20 });
      if (!Array.isArray(missing)) return missing;
      const note = entered(frame, 'draftnote');
      return beginReview(context, frame, {
        command: {
          kind: 'maintenance.draft.save', memberId: member.id, accountId: account?.id ?? null, category, subject,
          requestedCommand: requested, missingFields: missing, ...(note === '' ? {} : { note }),
        },
        screenId: 'THMN03', title: 'Review maintenance draft', lines: [
          { label: 'Member', before: '', after: `${member.memberNumber} ${member.displayName}` },
          { label: 'Request', before: '', after: `${category} — ${subject}` },
          { label: 'Change', before: '', after: (requested as { kind: string }).kind },
        ],
        fields: { memberId: 'member', accountId: 'account', category: 'category', subject: 'subject', missingFields: 'missing' },
      });
    }
    if (stored.state === 'draft') {
      const subject = entered(frame, 'subject');
      const note = entered(frame, 'draftnote');
      const missing = idList(frame, 'missing', 'MISSING FIELDS', { max: 20 });
      if (!Array.isArray(missing)) return missing;
      const patch: Record<string, unknown> = {};
      if (subject !== '' && subject !== stored.subject) patch.subject = subject;
      if (note !== '') patch.note = note;
      if (missing.length > 0) patch.missingFields = missing;
      if (requestedKind(frame) !== '') {
        const requested = buildRequested(context, frame);
        if (isOutcome(requested)) return requested;
        patch.requestedCommand = requested;
      }
      if (Object.keys(patch).length === 0) return { kind: 'stay', message: info('NO CHANGES TO SAVE. EDIT FIELDS OR USE F6 TO SUBMIT.') };
      return beginReview(context, frame, {
        command: { kind: 'maintenance.draft.amend', requestId: stored.id, expectedUpdatedAt: stored.updatedAt, patch },
        screenId: 'THMN04', title: 'Amend maintenance draft', lines: [{ label: 'Request', before: '', after: `${stored.requestNumber} (draft)` }], fields: {},
      });
    }
    if (stored.state === 'submitted') {
      const decision = code(frame, 'decision', { A: 'approve', R: 'reject', I: 'return-for-information' }, 'DECISION');
      if (typeof decision !== 'string') return decision;
      const reason = entered(frame, 'reviewreason');
      if (reason === '') return fieldProblem('reviewreason', 'A REVIEW REASON IS REQUIRED.');
      const missing = idList(frame, 'missing', 'MISSING FIELDS', { max: 20 });
      if (!Array.isArray(missing)) return missing;
      return beginReview(context, frame, {
        command: {
          kind: 'maintenance.request.review', requestId: stored.id, expectedUpdatedAt: stored.updatedAt, decision: decision as 'approve' | 'reject' | 'return-for-information', reason,
          ...(decision === 'return-for-information' ? { missingFields: missing } : {}),
        },
        screenId: 'THMN07', title: 'Review maintenance request', lines: [{ label: 'Decision', before: '', after: decision }], fields: { reason: 'reviewreason', missingFields: 'missing' },
      });
    }
    if (stored.state === 'approved') {
      const disposition = code(frame, 'disposition', { A: 'apply', R: 'reject' }, 'DISPOSITION');
      if (typeof disposition !== 'string') return disposition;
      const reason = entered(frame, 'processreason');
      if (reason === '') return fieldProblem('processreason', 'A PROCESS REASON IS REQUIRED.');
      const receipt = entered(frame, 'receipt');
      if (disposition === 'apply' && receipt === '') return fieldProblem('receipt', 'APPLY REQUIRES THE RECEIPT OF THE COMMITTED CHANGE.');
      let appliedReceiptId: string | undefined;
      if (receipt !== '') {
        appliedReceiptId = context.read((database, datasetId) => {
          const hit = database.prepare('SELECT id FROM operation_receipts WHERE dataset_id=? AND receipt_number=?').get(datasetId, upper(receipt)) as { id?: string } | undefined;
          return hit?.id;
        });
        if (appliedReceiptId === undefined) return fieldProblem('receipt', `RECEIPT ${upper(receipt).slice(0, 12)} NOT FOUND.`);
      }
      return beginReview(context, frame, {
        command: {
          kind: 'maintenance.request.process', requestId: stored.id, expectedUpdatedAt: stored.updatedAt, disposition: disposition as 'apply' | 'reject', reason,
          ...(appliedReceiptId === undefined ? {} : { appliedReceiptId }),
        },
        screenId: 'THMN08', title: 'Process maintenance request', lines: [{ label: 'Disposition', before: '', after: disposition }], fields: { reason: 'processreason', appliedReceiptId: 'receipt' },
      });
    }
    return { kind: 'stay', message: info(`REQUEST ${stored.requestNumber} IS ${upper(stored.state)}; NO FURTHER ACTION HERE.`) };
  },
  dirty: (frame) => Object.keys(frame.values).some((name) => (frame.values[name] ?? '').trim() !== ''),
  help: HELP_TOPICS.maintenance,
};

/** A new maintenance draft frame, optionally prefilled for a member/account. */
export function maintenanceFrame(memberNumber = '', accountNumber = ''): Frame {
  return {
    kind: 'maintenance', values: {
      ...(memberNumber === '' ? {} : { member: memberNumber }),
      ...(accountNumber === '' ? {} : { account: accountNumber }),
    },
    memberId: null, requestId: null, expectedUpdatedAt: null,
  };
}
