import { LIMITS, searchMembers, type AddressInput, type OrganizationType, type ServiceCommand } from '@computer-use/financial-database/services';

import { failure, info, type FrameOf, type ReviewLine } from '../host/frames.js';
import { column, localDate, upper } from '../host/format.js';
import type { ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  accountListFrame, accountOpenFrame, activityFrame, anyEntered, badSelection, beginReview, caseListFrame, clampOffset, contactFrame, contactValues, differs,
  findMember, forget, inactiveKey, label, LIST_ROWS, LIST_TOP, memberFrame, notFound, page, pageLabel, readMember, rowsLabel, selection, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';
import { notesFrame } from './notes.js';

const STATUS_CODES: Readonly<Record<string, string>> = { A: 'active', I: 'inactive', D: 'deceased', M: 'merged' };

function heading(builder: ScreenBuilder, row: number, columns: readonly (readonly [number, string])[]): void {
  for (const [at, text] of columns) builder.text(row, at, text, 'label');
}

export const memberListScreen: ScreenModule<FrameOf<'member-list'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THMB01', 'Member search');
    const status = STATUS_CODES[frame.criteria.status];
    const search = (offset: number) => context.read((database, datasetId) => searchMembers(database, datasetId, { query: frame.criteria.query, ...(status === undefined ? {} : { status }), limit: LIST_ROWS, offset }));
    let result = search(frame.offset);
    const clamped = clampOffset(frame.offset, LIST_ROWS, result.total);
    if (clamped !== frame.offset) {
      frame.offset = clamped;
      result = search(clamped);
    }
    frame.rows = result.items.map((row) => row.id);
    frame.total = result.total;
    builder.page = pageLabel(frame.offset, LIST_ROWS, result.total);
    label(builder, 3, 1, 'Search', 10).input('query', 3, 11, 30, value(frame, 'query', frame.criteria.query));
    label(builder, 3, 44, 'Status', 9).input('status', 3, 53, 1, value(frame, 'status', frame.criteria.status));
    builder.text(4, 1, 'NAME, MEMBER NO., ACCOUNT NO. PREFIX, EMAIL OR PHONE. STATUS A/I/D/M OR BLANK.', 'label');
    heading(builder, 6, [[1, 'S'], [3, 'MEMBER'], [12, 'NAME'], [43, 'STATUS'], [52, 'ACCTS'], [58, 'CONTACT']]);
    result.items.forEach((row, index) => {
      const line = LIST_TOP + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 8, row.memberNumber).data(line, 12, 30, row.displayName).data(line, 43, 8, upper(row.status), 'label')
        .data(line, 52, 5, String(row.openAccounts).padStart(5)).data(line, 58, 22, row.email ?? row.phone ?? '', 'label');
    });
    if (result.total === 0) builder.text(LIST_TOP, 3, 'NO MEMBERS MATCH THE SEARCH.', 'warning');
    builder.text(19, 1, 'SEL: S=INQUIRY  A=ACCOUNTS  N=NOTES  C=CASES  V=ACTIVITY', 'label');
    builder.data(20, 1, 40, rowsLabel(frame.offset, result.items.length, result.total), 'label');
    return builder.legend('ENTER=Search/Select  F1=Help  F3=Return  F6=New member  F7=Up  F8=Down');
  },
  input(_context, frame, event) {
    if (event.aid === 'pf6') return { kind: 'push', frame: { kind: 'member-create', values: {}, party: 'person' } };
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    if (event.modified.has('query') || event.modified.has('status')) {
      const status = upper(value(frame, 'status', frame.criteria.status).trim());
      if (status !== '' && !(status in STATUS_CODES)) return { kind: 'stay', message: failure('STATUS MUST BE A, I, D, M OR BLANK.'), error: 'status' };
      frame.criteria = { query: value(frame, 'query', frame.criteria.query).trim(), status };
      frame.offset = 0;
      delete frame.values.query;
      delete frame.values.status;
      selection(frame, frame.rows.length);
      return { kind: 'stay', message: info('SEARCH COMPLETE. TYPE S, A, N, C OR V BESIDE A MEMBER.') };
    }
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE S, A, N, C OR V BESIDE A MEMBER, OR CHANGE THE SEARCH.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const memberId = frame.rows[picked.index];
    if (memberId === undefined) return badSelection(picked.code, 'A LISTED ROW', picked.index);
    frame.cursor = `sel.${picked.index}`;
    switch (picked.code) {
      case 'S': return { kind: 'push', frame: memberFrame(memberId) };
      case 'A': return { kind: 'push', frame: accountListFrame(memberId) };
      case 'N': return { kind: 'push', frame: notesFrame({ kind: 'member', id: memberId }) };
      case 'C': return { kind: 'push', frame: caseListFrame(memberId) };
      case 'V': return { kind: 'push', frame: activityFrame({ memberId }) };
      default: return badSelection(picked.code, 'S, A, N, C OR V', picked.index);
    }
  },
  help: HELP_TOPICS['member-list'],
};

export const memberScreen: ScreenModule<FrameOf<'member'>> = {
  render(context, frame) {
    const detail = readMember(context, frame.memberId);
    const { member } = detail;
    const { timeZone } = context.session().institution;
    const builder = new ScreenBuilder('THMB02', 'Member inquiry');
    builder.page = `PAGE ${frame.page} OF 2`;
    label(builder, 3, 1, 'Member number', 18).input('member', 3, 19, 8, value(frame, 'member', member.memberNumber));
    builder.text(3, 40, 'STATUS', 'label').data(3, 47, 12, upper(member.status), member.status === 'active' ? 'success' : 'warning');
    label(builder, 4, 1, 'Name', 18).data(4, 19, 60, member.displayName, 'emphasis');
    if (frame.page === 1) {
      label(builder, 5, 1, 'Kind', 18).data(5, 19, 14, upper(member.kind));
      label(builder, 5, 40, 'Joined', 12).data(5, 52, 10, localDate(member.joinedAt, timeZone));
      label(builder, 6, 1, 'Tax class', 18).data(6, 19, 30, member.taxClassification);
      if (detail.person !== null) {
        label(builder, 8, 1, 'Legal name', 18).data(8, 19, 60, `${detail.person.legalGiven} ${detail.person.legalFamily}`);
        label(builder, 9, 1, 'Preferred name', 18).data(9, 19, 40, detail.person.preferredName ?? '');
        label(builder, 10, 1, 'Birth date', 18).data(10, 19, 10, detail.person.birthDate);
        label(builder, 10, 40, 'Deceased', 12).data(10, 52, 10, detail.person.deceasedAt === null ? 'NO' : localDate(detail.person.deceasedAt, timeZone));
      } else if (detail.organization !== null) {
        label(builder, 8, 1, 'Legal name', 18).data(8, 19, 60, detail.organization.legalName);
        label(builder, 9, 1, 'Registration', 18).data(9, 19, 30, detail.organization.registrationNumber);
        label(builder, 10, 1, 'Organization type', 18).data(10, 19, 30, detail.organization.organizationType);
      }
      const verified = (contact: { verifiedAt: string | null } | null): string => contact === null ? '' : contact.verifiedAt === null ? 'UNVERIFIED' : 'VERIFIED';
      label(builder, 12, 1, 'Email', 18).data(12, 19, 44, detail.email?.value ?? 'NONE').data(12, 64, 15, verified(detail.email), 'label');
      label(builder, 13, 1, 'Phone', 18).data(13, 19, 24, detail.phone?.value ?? 'NONE').data(13, 64, 15, verified(detail.phone), 'label');
      label(builder, 14, 1, 'Mailing address', 18).data(14, 19, 60, detail.address?.line1 ?? 'NONE');
      if (detail.address !== null) {
        builder.data(15, 19, 60, detail.address.line2 ?? '');
        builder.data(16, 19, 60, `${detail.address.city}, ${detail.address.region} ${detail.address.postalCode} ${detail.address.country}`);
        label(builder, 17, 1, 'Address evidence', 18).data(17, 19, 20, upper(detail.address.evidenceStatus));
      }
      label(builder, 18, 1, 'Accounts', 18).data(18, 19, 18, `${member.openAccounts} OPEN OF ${detail.accounts.length}`);
      label(builder, 18, 40, 'Notes', 8).data(18, 48, 5, String(detail.notes.length));
      label(builder, 18, 56, 'Cases', 8).data(18, 64, 5, String(detail.cases.length));
      if (detail.redirectTo !== null) builder.data(19, 1, 78, `MERGED RECORD. THE CURRENT MEMBER IS ${detail.redirectTo.memberNumber}.`, 'warning');
    } else {
      heading(builder, 6, [[1, 'ACCOUNT'], [12, 'PRODUCT'], [26, 'CUR'], [30, 'STATUS'], [41, 'NICKNAME'], [66, 'POSTED BALANCE']]);
      detail.accounts.slice(0, 12).forEach((account, index) => {
        const row = 7 + index;
        builder.data(row, 1, 10, account.accountNumber).data(row, 12, 13, account.productCode).data(row, 26, 3, account.currency)
          .data(row, 30, 10, upper(account.status), account.status === 'open' ? 'data' : 'warning').data(row, 41, 18, account.nickname)
          .data(row, 60, 20, column(account.postedMinorUnits, account.currency, account.exponent, 20));
      });
      if (detail.accounts.length === 0) builder.text(7, 1, 'NO ACCOUNTS.', 'warning');
      if (detail.accounts.length > 12) builder.data(19, 1, 78, `${detail.accounts.length - 12} MORE ACCOUNTS: PRESS F6 FOR THE ACCOUNT LIST.`, 'warning');
    }
    return builder.legend('ENTER=Switch member  F1=Help  F3=Return  F4=Contact  F5=Notes  F6=Accounts', 'F7=Page 1  F8=Page 2  F9=Activity  F10=Open account  F11=Cases');
  },
  input(context, frame, event) {
    switch (event.aid) {
      case 'enter': {
        if (!event.modified.has('member')) return { kind: 'stay', message: info('SCREEN REFRESHED WITH CURRENT DATA.') };
        const number = value(frame, 'member');
        const found = findMember(context, number);
        if (found === undefined) return { kind: 'stay', message: notFound('MEMBER', number, context), error: 'member' };
        delete frame.values.member;
        return { kind: 'replace', frame: memberFrame(found.id), message: info(`NOW SHOWING MEMBER ${found.memberNumber}.`) };
      }
      case 'pf7': frame.page = 1; return { kind: 'stay' };
      case 'pf8': frame.page = 2; return { kind: 'stay' };
      case 'pf4': return { kind: 'push', frame: contactFrame(readMember(context, frame.memberId)) };
      case 'pf5': return { kind: 'push', frame: notesFrame({ kind: 'member', id: frame.memberId }) };
      case 'pf6': return { kind: 'push', frame: accountListFrame(frame.memberId) };
      case 'pf9': return { kind: 'push', frame: activityFrame({ memberId: frame.memberId }) };
      case 'pf10': return { kind: 'push', frame: accountOpenFrame(frame.memberId) };
      case 'pf11': return { kind: 'push', frame: caseListFrame(frame.memberId) };
      default: return inactiveKey();
    }
  },
  help: HELP_TOPICS.member,
};

const ADDRESS_FIELDS = ['line1', 'line2', 'city', 'region', 'postal', 'country'] as const;
const CONTACT_FIELDS = ['email', 'phone', ...ADDRESS_FIELDS] as const;
const CONTACT_LABELS: Readonly<Record<string, string>> = {
  email: 'Email', phone: 'Phone', line1: 'Address line 1', line2: 'Address line 2', city: 'City', region: 'Region', postal: 'Postal code', country: 'Country',
  legalGiven: 'Legal given name', legalFamily: 'Legal family name', preferredName: 'Preferred name', birthDate: 'Birth date',
  legalName: 'Legal name', registration: 'Registration no.',
};
const ADDRESS_SERVICE_FIELDS: Readonly<Record<string, string>> = {
  address: 'line1', 'address.line1': 'line1', 'address.line2': 'line2', 'address.city': 'city', 'address.region': 'region', 'address.postalCode': 'postal', 'address.country': 'country',
};

function addressInput(read: (name: string) => string): AddressInput {
  return { line1: read('line1'), line2: read('line2') === '' ? null : read('line2'), city: read('city'), region: read('region'), postalCode: read('postal'), country: upper(read('country')) };
}

export const contactScreen: ScreenModule<FrameOf<'contact'>> = {
  render(context, frame) {
    const detail = readMember(context, frame.memberId);
    const current = contactValues(detail);
    if (frame.conflict === true) {
      frame.version = detail.member.version;
      frame.baseline = current;
    }
    const builder = new ScreenBuilder('THMB05', 'Contact maintenance');
    label(builder, 3, 1, 'Member', 16).data(3, 17, 8, detail.member.memberNumber).data(3, 27, 50, detail.member.displayName, 'emphasis');
    label(builder, 4, 1, 'Record version', 16).data(4, 17, 6, String(frame.version));
    const draft = (name: string): string => value(frame, name, frame.baseline[name] ?? '');
    const now = (row: number, at: number, cells: number, name: string): void => {
      if (frame.conflict === true && name in frame.values && draft(name).trim() !== (current[name] ?? '').trim()) builder.data(row, at, cells, `NOW: ${current[name] === '' ? '(BLANK)' : current[name] ?? ''}`, 'warning');
    };
    label(builder, 6, 1, 'Email', 16).input('email', 6, 17, 60, draft('email'), { capacity: LIMITS.emailLength });
    now(7, 17, 62, 'email');
    label(builder, 8, 1, 'Phone', 16).input('phone', 8, 17, 20, draft('phone'));
    now(9, 17, 40, 'phone');
    label(builder, 10, 1, 'Address line 1', 16).input('line1', 10, 17, 40, draft('line1'), { capacity: LIMITS.addressLineLength });
    now(11, 17, 60, 'line1');
    label(builder, 12, 1, 'Address line 2', 16).input('line2', 12, 17, 40, draft('line2'), { capacity: LIMITS.addressLineLength });
    now(13, 17, 60, 'line2');
    label(builder, 14, 1, 'City', 16).input('city', 14, 17, 30, draft('city'), { capacity: LIMITS.cityLength });
    label(builder, 14, 50, 'Region', 8).input('region', 14, 58, 20, draft('region'), { capacity: LIMITS.regionLength });
    now(15, 17, 32, 'city');
    now(15, 58, 22, 'region');
    label(builder, 16, 1, 'Postal code', 16).input('postal', 16, 17, 10, draft('postal'), { capacity: LIMITS.postalCodeLength });
    label(builder, 16, 50, 'Country', 8).input('country', 16, 58, 2, draft('country'));
    now(17, 17, 32, 'postal');
    now(17, 58, 22, 'country');
    builder.text(19, 1, 'ERASE EMAIL OR PHONE (ALT+E) TO CLEAR IT. ADDRESS CHANGES REPLACE THE ADDRESS.', 'label');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const draft = (name: string): string => value(frame, name, frame.baseline[name] ?? '').trim();
    const changed = CONTACT_FIELDS.filter((name) => draft(name) !== (frame.baseline[name] ?? '').trim());
    if (changed.length === 0) return { kind: 'stay', message: info('NO CHANGES ENTERED.') };
    const addressChanged = ADDRESS_FIELDS.some((name) => changed.includes(name));
    const command: ServiceCommand = {
      kind: 'contact.update', memberId: frame.memberId, expectedVersion: frame.version,
      ...(changed.includes('email') ? { email: draft('email') === '' ? null : draft('email') } : {}),
      ...(changed.includes('phone') ? { phone: draft('phone') === '' ? null : draft('phone') } : {}),
      ...(addressChanged ? { address: addressInput(draft) } : {}),
    };
    const lines: ReviewLine[] = changed.map((name) => ({ label: CONTACT_LABELS[name] ?? name, before: frame.baseline[name] === '' ? '(BLANK)' : frame.baseline[name] ?? '', after: draft(name) === '' ? '(CLEARED)' : draft(name) }));
    return beginReview(context, frame, { command, screenId: 'THMB06', title: 'Review contact change', lines, fields: { email: 'email', phone: 'phone', ...ADDRESS_SERVICE_FIELDS } });
  },
  dirty: (frame) => differs(frame, frame.baseline, CONTACT_FIELDS),
  help: HELP_TOPICS.contact,
};

const PERSON_FIELDS = ['legalGiven', 'legalFamily', 'preferredName', 'birthDate'] as const;
const ORGANIZATION_FIELDS = ['legalName', 'registration', 'organizationType'] as const;
const NEW_CONTACT_FIELDS = ['email', 'phone', ...ADDRESS_FIELDS] as const;
const PARTY_CODES: Readonly<Record<string, 'person' | 'organization'>> = { P: 'person', O: 'organization' };
const ORGANIZATION_TYPES: Readonly<Record<string, OrganizationType>> = { C: 'corporation', N: 'nonprofit' };

export const memberCreateScreen: ScreenModule<FrameOf<'member-create'>> = {
  render(_context, frame) {
    const person = frame.party === 'person';
    const builder = new ScreenBuilder('THMB03', 'New member');
    label(builder, 3, 1, 'Member kind (P/O)', 20).input('party', 3, 21, 1, value(frame, 'party', person ? 'P' : 'O')).text(3, 24, 'P PERSON, O ORGANIZATION. ENTER SWITCHES THE FORM.', 'label');
    if (person) {
      label(builder, 5, 1, 'Legal given name', 20).input('legalGiven', 5, 21, 40, value(frame, 'legalGiven'), { capacity: LIMITS.nameLength });
      label(builder, 6, 1, 'Legal family name', 20).input('legalFamily', 6, 21, 40, value(frame, 'legalFamily'), { capacity: LIMITS.nameLength });
      label(builder, 7, 1, 'Preferred name', 20).input('preferredName', 7, 21, 40, value(frame, 'preferredName'), { capacity: LIMITS.nameLength });
      label(builder, 8, 1, 'Birth date', 20).input('birthDate', 8, 21, 10, value(frame, 'birthDate')).text(8, 33, '(YYYY-MM-DD)', 'label');
    } else {
      label(builder, 5, 1, 'Legal name', 20).input('legalName', 5, 21, 58, value(frame, 'legalName'), { capacity: LIMITS.organizationNameLength });
      label(builder, 6, 1, 'Registration no.', 20).input('registration', 6, 21, 30, value(frame, 'registration'));
      label(builder, 7, 1, 'Organization type', 20).input('organizationType', 7, 21, 1, value(frame, 'organizationType')).text(7, 24, 'C CORPORATION, N NONPROFIT', 'label');
    }
    label(builder, 10, 1, 'Email', 20).input('email', 10, 21, 56, value(frame, 'email'), { capacity: LIMITS.emailLength });
    label(builder, 11, 1, 'Phone', 20).input('phone', 11, 21, 20, value(frame, 'phone'));
    label(builder, 13, 1, 'Address line 1', 20).input('line1', 13, 21, 40, value(frame, 'line1'), { capacity: LIMITS.addressLineLength });
    label(builder, 14, 1, 'Address line 2', 20).input('line2', 14, 21, 40, value(frame, 'line2'), { capacity: LIMITS.addressLineLength });
    label(builder, 15, 1, 'City', 20).input('city', 15, 21, 30, value(frame, 'city'), { capacity: LIMITS.cityLength });
    label(builder, 15, 54, 'Region', 8).input('region', 15, 62, 16, value(frame, 'region'), { capacity: LIMITS.regionLength });
    label(builder, 16, 1, 'Postal code', 20).input('postal', 16, 21, 10, value(frame, 'postal'), { capacity: LIMITS.postalCodeLength });
    label(builder, 16, 54, 'Country', 8).input('country', 16, 62, 2, value(frame, 'country'));
    builder.text(18, 1, 'LEAVE EVERY ADDRESS FIELD BLANK TO CREATE A MEMBER WITHOUT A MAILING ADDRESS.', 'label');
    builder.text(19, 1, 'LONG VALUES SCROLL INSIDE THEIR FIELD. CH n/LIMIT ON THE STATUS LINE.', 'label');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    if (event.modified.has('party')) {
      const party = PARTY_CODES[upper(value(frame, 'party').trim())];
      delete frame.values.party;
      if (party === undefined) return { kind: 'stay', message: failure('MEMBER KIND MUST BE P (PERSON) OR O (ORGANIZATION).'), error: 'party' };
      if (party !== frame.party) {
        frame.party = party;
        const hidden: readonly string[] = party === 'person' ? ORGANIZATION_FIELDS : PERSON_FIELDS;
        forget(frame, (name) => hidden.includes(name));
        return party === 'person'
          ? { kind: 'stay', message: info('PERSON FORM. ENTER THE LEGAL NAMES AND BIRTH DATE.'), cursor: 'legalGiven' }
          : { kind: 'stay', message: info('ORGANIZATION FORM. ENTER THE LEGAL NAME, REGISTRATION NUMBER AND TYPE.'), cursor: 'legalName' };
      }
    }
    const read = (name: string): string => value(frame, name).trim();
    const optional = (name: string): string | null => read(name) === '' ? null : read(name);
    const contact = { email: optional('email'), phone: optional('phone'), address: ADDRESS_FIELDS.every((name) => read(name) === '') ? null : addressInput(read) };
    const entered = (names: readonly string[]): ReviewLine[] => names.filter((name) => read(name) !== '').map((name) => ({ label: CONTACT_LABELS[name] ?? name, before: '', after: read(name) }));
    const contactFields = { email: 'email', phone: 'phone', ...ADDRESS_SERVICE_FIELDS };
    if (frame.party === 'person') {
      const command: ServiceCommand = { kind: 'member.create', legalGiven: read('legalGiven'), legalFamily: read('legalFamily'), preferredName: optional('preferredName'), birthDate: read('birthDate'), ...contact };
      return beginReview(context, frame, {
        command, screenId: 'THMB04', title: 'Review new member', lines: [{ label: 'Member kind', before: '', after: 'PERSON' }, ...entered([...PERSON_FIELDS, ...NEW_CONTACT_FIELDS])],
        fields: { legalGiven: 'legalGiven', legalFamily: 'legalFamily', preferredName: 'preferredName', birthDate: 'birthDate', ...contactFields },
      });
    }
    const organizationType = ORGANIZATION_TYPES[upper(read('organizationType'))];
    if (organizationType === undefined) return { kind: 'stay', message: failure('ORGANIZATION TYPE MUST BE C (CORPORATION) OR N (NONPROFIT).'), error: 'organizationType' };
    const command: ServiceCommand = { kind: 'member.organization.create', legalName: read('legalName'), registrationNumber: read('registration'), organizationType, ...contact };
    return beginReview(context, frame, {
      command, screenId: 'THMB04', title: 'Review new member',
      lines: [{ label: 'Member kind', before: '', after: 'ORGANIZATION' }, ...entered(['legalName', 'registration']), { label: 'Organization type', before: '', after: upper(organizationType) }, ...entered(NEW_CONTACT_FIELDS)],
      fields: { legalName: 'legalName', registrationNumber: 'registration', organizationType: 'organizationType', ...contactFields },
    });
  },
  dirty: (frame) => anyEntered(frame, [...PERSON_FIELDS, ...ORGANIZATION_FIELDS, ...NEW_CONTACT_FIELDS]),
  help: HELP_TOPICS['member-create'],
};
