import { failure, info, type DirectoryRow, type Frame, type FrameOf, type Message } from '../host/frames.js';
import { upper } from '../host/format.js';
import type { HostContext, Outcome, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { badSelection, clampOffset, inactiveKey, label, LIST_ROWS, page, pageLabel, rowsLabel, selection, value } from './common.js';
import type { HelpTopic } from './help-text.js';
import { DIRECTORIES } from './dirs-registry.js';

/** A scope prompt resolved before a directory lists, such as the member whose documents are shown. */
export interface ScopeField {
  name: string;
  label: string;
  width: number;
  optional?: boolean;
  /** Resolves typed text to the scoped record's opaque id and a display label, or a refusal. */
  resolve(context: HostContext, text: string): { id: string; label: string } | Outcome;
}

export interface FilterField {
  name: string;
  label: string;
  width: number;
  hint?: string;
}

/** A registered record directory the terminal can browse or pick from. */
export interface DirectorySpec {
  id: string;
  screenId: string;
  title: string;
  scope: readonly ScopeField[];
  filters: readonly FilterField[];
  /** Column headers for the list body, drawn on the heading row. */
  heading: string;
  list(context: HostContext, scope: Record<string, string>, filters: Record<string, string>, offset: number, limit: number): { rows: DirectoryRow[]; total: number } | Message;
  /** What S opens in browse mode; unset or null keeps the row browse-only. */
  open?(context: HostContext, row: DirectoryRow, frame: FrameOf<'directory'>): Frame | Extract<Outcome, { kind: 'stay' }> | null;
  help: HelpTopic;
}

export function directorySpec(dir: string): DirectorySpec {
  const spec = DIRECTORIES[dir];
  if (spec === undefined) throw new Error(`No directory named ${dir}.`);
  return spec;
}

export function directoryFrame(dir: string, scope: Record<string, string> = {}, pick: string | null = null): FrameOf<'directory'> {
  return { kind: 'directory', values: {}, dir, scope, offset: 0, total: 0, rows: [], pick };
}

/** The resolved id under a scope name, or null when the scope is unset. */
export function scopeId(frame: FrameOf<'directory'>, name: string): string | null {
  return frame.scope[name] ?? null;
}

function filters(frame: Frame): Record<string, string> {
  const result: Record<string, string> = {};
  for (const [name, text] of Object.entries(frame.values)) if (name.startsWith('f.')) result[name.slice(2)] = text.trim();
  return result;
}

/** Reads the directory's current page through its spec, keeping the frame's row list current. */
function listPage(context: HostContext, frame: FrameOf<'directory'>, spec: DirectorySpec): { rows: DirectoryRow[]; total: number } | Message {
  const result = spec.list(context, frame.scope, filters(frame), frame.offset, LIST_ROWS);
  if ('text' in result) return result;
  const clamped = clampOffset(frame.offset, LIST_ROWS, result.total);
  if (clamped !== frame.offset) {
    frame.offset = clamped;
    const again = spec.list(context, frame.scope, filters(frame), clamped, LIST_ROWS);
    if ('text' in again) return again;
    frame.rows = again.rows;
    frame.total = again.total;
    return again;
  }
  frame.rows = result.rows;
  frame.total = result.total;
  return result;
}

export const directoryScreen: ScreenModule<FrameOf<'directory'>> = {
  render(context, frame) {
    const spec = directorySpec(frame.dir);
    const picking = frame.pick !== null;
    const builder = new ScreenBuilder(spec.screenId, picking ? `${spec.title} — select` : spec.title);
    let row = 3;
    for (const field of spec.scope) {
      const resolved = frame.scope[field.name];
      label(builder, row, 1, field.label, 20).input(`scope.${field.name}`, row, 21, field.width, value(frame, `scope.${field.name}`));
      if (resolved !== undefined) builder.data(row, 22 + field.width, 78 - 22 - field.width, frame.scope[`${field.name}.label`] ?? '', 'emphasis');
      else if (field.optional === true) builder.text(row, 22 + field.width, 'OPTIONAL', 'label');
      row += 1;
    }
    if (spec.filters.length > 0) {
      let column = 1;
      for (const field of spec.filters) {
        label(builder, row, column, field.label, field.label.length + 1).input(`f.${field.name}`, row, column + field.label.length + 1, field.width, value(frame, `f.${field.name}`));
        column += field.label.length + field.width + 2;
      }
      row += 1;
    }
    const unresolved = spec.scope.filter((field) => field.optional !== true && frame.scope[field.name] === undefined);
    if (unresolved.length > 0) {
      builder.text(row + 1, 1, `ENTER ${unresolved.map((field) => upper(field.label)).join(', ')} ABOVE, THEN PRESS ENTER TO LIST.`, 'warning');
      return builder.legend('ENTER=List  F1=Help  F3=Return  F12=Cancel');
    }
    const page_ = listPage(context, frame, spec);
    builder.page = 'text' in page_ ? null : pageLabel(frame.offset, LIST_ROWS, page_.total);
    builder.text(row, 1, 'S', 'label').text(row, 3, spec.heading, 'label');
    row += 1;
    if ('text' in page_) {
      builder.text(row + 1, 3, upper(page_.text), 'warning');
      return builder.legend('ENTER=Refresh  F1=Help  F3=Return  F12=Cancel');
    }
    frame.rows.forEach((entry, index) => {
      const line = row + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 77, entry.line);
    });
    if (page_.total === 0) builder.text(row, 3, 'NOTHING TO LIST HERE.', 'warning');
    const foot = row + LIST_ROWS;
    builder.data(foot, 1, 40, rowsLabel(frame.offset, frame.rows.length, page_.total), 'label');
    if (picking) builder.text(foot + 1, 1, 'SEL: S=PICK THIS RECORD FOR THE CALLING FORM', 'label');
    else builder.text(foot + 1, 1, 'SEL: S=OPEN', 'label');
    return builder.legend('ENTER=Select  F1=Help  F3=Return  F7=Up  F8=Down  F12=Cancel');
  },
  input(context, frame, event) {
    const spec = directorySpec(frame.dir);
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    const scopeTouched = spec.scope.some((field) => event.modified.has(`scope.${field.name}`));
    const filtersTouched = spec.filters.some((field) => event.modified.has(`f.${field.name}`));
    if (scopeTouched || filtersTouched || spec.scope.some((field) => field.optional !== true && frame.scope[field.name] === undefined)) {
      for (const field of spec.scope) {
        const typed = value(frame, `scope.${field.name}`).trim();
        if (!event.modified.has(`scope.${field.name}`) && frame.scope[field.name] !== undefined) continue;
        if (typed === '') {
          Reflect.deleteProperty(frame.scope, field.name);
          Reflect.deleteProperty(frame.scope, `${field.name}.label`);
          if (field.optional !== true) return { kind: 'stay', message: failure(`ENTER ${upper(field.label)}.`), error: `scope.${field.name}` };
          continue;
        }
        const resolved = field.resolve(context, typed);
        if ('kind' in resolved) {
          return resolved.kind === 'stay' ? { ...resolved, error: resolved.error ?? `scope.${field.name}` } : resolved;
        }
        frame.scope[field.name] = resolved.id;
        frame.scope[`${field.name}.label`] = resolved.label;
      }
      frame.offset = 0;
      selection(frame, frame.rows.length);
      const pending = spec.scope.filter((field) => field.optional !== true && frame.scope[field.name] === undefined);
      if (pending.length > 0) return { kind: 'stay', message: failure(`ENTER ${upper(pending[0]?.label ?? 'scope')}.`), error: `scope.${pending[0]?.name ?? ''}` };
      return { kind: 'stay', message: info('LIST APPLIED. TYPE S BESIDE A ROW.') };
    }
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE S BESIDE A ROW, OR CHANGE A FILTER.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const row = frame.rows[picked.index];
    if (row === undefined) return badSelection(picked.code, 'A LISTED ROW', picked.index);
    if (picked.code !== 'S') return badSelection(picked.code, 'S', picked.index);
    frame.cursor = `sel.${picked.index}`;
    if (frame.pick !== null) {
      const values: Record<string, string> = { [frame.pick]: row.id, [`${frame.pick}.label`]: row.label };
      for (const [key, extra] of Object.entries(row.extra ?? {})) values[`${frame.pick}.${key}`] = extra;
      return { kind: 'pop', values, message: info(`PICKED ${row.label.slice(0, 40)}.`) };
    }
    const opened = spec.open?.(context, row, frame) ?? null;
    if (opened === null) return { kind: 'stay', message: info('THIS LIST IS BROWSE ONLY.'), error: `sel.${picked.index}` };
    return 'values' in opened ? { kind: 'push', frame: opened } : opened;
  },
  dirty: (frame) => Object.keys(frame.values).some((name) => name.startsWith('f.') || name.startsWith('scope.')),
  help: { title: 'Directory', lines: ['DIRECTORY', 'Type S beside a row and press Enter. In pick mode the row fills the field on', 'the screen you came from. F7/F8 page. Scope and filter fields relist on Enter.'] },
};
