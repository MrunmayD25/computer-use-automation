import type { FrameKind } from '../host/frames.js';

export interface HelpTopic {
  title: string;
  lines: readonly string[];
}

/**
 * Operator help shown by F1. Uppercase lines are headings. The keyboard reference is appended to
 * every topic so the key alternatives are discoverable from any screen.
 */
export const HELP_TOPICS: Readonly<Record<FrameKind | 'keys', HelpTopic>> = {
  keys: {
    title: 'Keyboard',
    lines: [
      'KEYBOARD',
      'Enter sends the screen. F1 help. F3 exit. F12 cancel. F7/F8 or PgUp/PgDn page.',
      'Browser-safe alternatives: Alt+1..Alt+9 and Alt+0 = F1..F10, Alt+- = F11,',
      'Alt+= = F12. Alt+Shift+1..Alt+Shift+0 = F13..F22. Shift+F1..F12 = F13..F24.',
      'Tab and Shift+Tab move to the next and previous input field. Arrows move one cell.',
      'Home goes to the first input field; End goes after the last character in a field.',
      'Insert or Alt+I toggles insert mode (INS in the status line); overwrite is default.',
      'Backspace erases left. Delete erases at the cursor; the rest of the field shifts.',
      'Ctrl+Delete or Alt+E erases to the end of the field. Alt+Delete or Alt+X erases all',
      'input fields. Esc or Alt+R resets a locked keyboard. Pause or Alt+C clears (the host',
      'redisplays the screen). Alt+D downloads a prepared file. Clicking a cell moves the',
      'cursor. Paste goes into the current field only and never submits the screen.',
      'While X SYSTEM shows, the host owns the screen and keystrokes are not accepted.',
      'A value longer than its field scrolls inside it; the status line shows CH n/limit',
      'and < or > when text is hidden to the left or right.',
    ],
  },
  signon: { title: 'Sign on', lines: ['SIGN ON', 'Type the number of an institution from the list and an operator ID.', 'Only operators configured for this terminal can sign on; each institution keeps', 'its own members, accounts and numbers, even where numbers look the same.'] },
  menu: { title: 'Main menu', lines: ['MAIN MENU', 'Type an option number (1-8), a transaction code such as MB01 or TX02, or X, and', 'press Enter. Options marked NOT GRANTED can be viewed but their changes are', 'refused for this operator. F3 signs off without changing any business data.'] },
  help: { title: 'Help', lines: ['HELP', 'F7 and F8 page through help. F3 or F12 returns to the screen you were using,', 'with your entries intact.'] },
  'member-list': { title: 'Member search', lines: ['MEMBER SEARCH (THMB01)', 'Type a name, member number, account-number prefix, email or phone fragment, and', 'optionally a status code, then press Enter. An empty search lists every member.', 'Type S, A, N, C or V beside one member and press Enter: S inquiry, A accounts,', 'N notes, C cases, V activity. F7/F8 page. Returning restores the search, page', 'and row.'] },
  member: { title: 'Member inquiry', lines: ['MEMBER INQUIRY (THMB02)', 'Page 1 shows identity and contact details; F8 shows page 2 with accounts.', 'Type another member number over the key field and press Enter to switch records.', 'F4 contact maintenance, F5 notes, F6 accounts, F9 activity, F10 open account.'] },
  'member-create': {
    title: 'New member',
    lines: ['NEW MEMBER (THMB03)', 'Type P (person) or O (organization) in Member kind and press Enter to switch', 'the form. A person needs legal names and a birth date (YYYY-MM-DD). An', 'organization needs its legal name, registration number and type (C corporation,',
      'N nonprofit). Leave every address field blank for no mailing address. Enter', 'shows a review; nothing is created until you type Y on the review screen.'],
  },
  contact: { title: 'Contact maintenance', lines: ['CONTACT MAINTENANCE (THMB05)', 'Change email, phone or mailing address. Erase a field (Alt+E) to clear email or', 'phone. Only changed fields are sent. If another user changes the member first,', 'the screen shows the current values under yours; press Enter to review again.'] },
  notes: { title: 'Notes', lines: ['MEMBER NOTES (THMB07) AND CASE NOTES (THCS11)', 'Notes are listed newest first. Type S beside a note to read it in full.', 'F6 adds a note. RST marks a restricted note. Restricted notes are listed only', 'for case and supervisory staff; others see how many were withheld.'] },
  'note-add': {
    title: 'Add note',
    lines: ['ADD NOTE (THMB08)', 'Type G (general) or R (restricted). The text field flows across lines; F8', 'continues on page 2 and F7 returns, keeping both pages. A page that stops short',
      'of its last cell joins the next page with a space. Line breaks cannot be keyed', 'on this terminal. Enter reviews the whole text; the note is added only after Y.', 'Notes are never edited; add a further note to correct one.'],
  },
  note: { title: 'Note', lines: ['NOTE (THMB09)', 'The full note text. F7/F8 page through long notes.'] },
  'account-list': { title: 'Account search', lines: ['ACCOUNT SEARCH (THAC01)', 'Search by account number, member number prefix, nickname or owner name, with an', 'optional status code. Type one code beside an account: S inquiry, H history,', 'T statements, M maintain, C close, V activity, D deposit, W withdraw, X transfer.'] },
  account: { title: 'Account inquiry', lines: ['ACCOUNT INQUIRY (THAC02)', 'Page 1 shows balances, status and eligibility; F8 shows holds, restrictions,', 'parties and every eligibility reason. Type another account number over the key', 'field and press Enter to switch records. F4 maintain, F5 history, F6 statements,', 'F9 activity, F10 deposit, F11 withdraw, F13 transfer, F14 close.'] },
  'account-open': { title: 'Open account', lines: ['OPEN ACCOUNT (THAC03)', 'Choose a product number, a nickname and statement delivery (P paper,', 'E electronic). New accounts open with a zero balance.'] },
  'account-profile': { title: 'Account maintenance', lines: ['ACCOUNT MAINTENANCE (THAC05)', 'Change the nickname or the statement delivery. Each is its own transaction, so', 'change one of them at a time.'] },
  'account-close': { title: 'Close account', lines: ['CLOSE ACCOUNT (THAC07)', 'The screen shows whether the shared rules allow closure. Only open accounts with', 'a zero posted balance and no holds, restrictions or other obligations close.', 'Enter a reason and press Enter to review.'] },
  cash: { title: 'Cash', lines: ['CASH DEPOSIT (THTX01) AND WITHDRAWAL (THTX02)', 'Enter the account number and press Enter to see the account. Then enter the', 'amount with at most the currency\'s decimals, the currency and a description.', 'Enter shows the review; nothing posts until you type Y there.'] },
  transfer: { title: 'Internal transfer', lines: ['INTERNAL TRANSFER (THTX03)', 'Move money between two accounts of the same member in the same currency.', 'Enter shows the review with both balances before and after.'] },
  review: { title: 'Review', lines: ['REVIEW', 'Nothing has been posted or changed yet. Type Y and press Enter to process, or N,', 'F3 or F12 to return with your entries kept. Pressing Enter again while the host', 'is working does nothing; a repeated request returns the original receipt.', 'Long values continue on the next rows; F7/F8 page when the review is longer', 'than the screen. Nothing is shortened.'] },
  receipt: { title: 'Receipt', lines: ['RECEIPT (THRC01)', 'A durable record of a committed change, rebuilt from stored data. Type S beside', 'an affected record to open it. F7/F8 page through journal lines.'] },
  'receipt-lookup': { title: 'Receipt inquiry', lines: ['RECEIPT INQUIRY (THRC02)', 'Type a receipt number, such as RCP00000012, and press Enter.'] },
  history: {
    title: 'Transaction history',
    lines: ['TRANSACTION HISTORY (THHI01)', 'Filter by effective date (from inclusive, to exclusive), direction (C credit,', 'D debit), amount range, text anywhere in the reference or description, one exact',
      'reference (Ref; letter case is ignored), status (P posted, R reversed) and order', '(N newest, O oldest). Text and Ref scroll when longer than the field.',
      'S shows an entry; R opens its receipt. F5 exports CSV.'],
  },
  entry: { title: 'Entry detail', lines: ['ENTRY DETAIL (THHI02)', 'One ledger entry with its journal. F5 opens the receipt when there is one.'] },
  statements: { title: 'Statements', lines: ['STATEMENTS AND DOCUMENTS (THST01)', 'Stored documents are issued versions with fixed bytes. Ledger periods are', 'computed from posted entries. V views a period; D downloads the file.', 'F5 prepares a CSV export.'] },
  statement: { title: 'Statement', lines: ['STATEMENT VIEW (THST02)', 'Opening, credits, debits and closing for one month from posted entries.', 'F4 member, F6 account, F9 prepares the statement PDF for download.'] },
  export: { title: 'Export', lines: ['TRANSACTION EXPORT (THEX01)', 'Optional effective-date range; the end date is exclusive. Exports of more than', '10000 rows are refused rather than cut short. Download with Alt+D or the link.'] },
  activity: { title: 'Activity', lines: ['ACTIVITY INQUIRY (THAV01)', 'Committed business events, newest first. Filter by exact event kind such as', 'cash.deposit, or by text or receipt number. S opens the receipt or the event.'] },
  event: { title: 'Event', lines: ['EVENT DETAIL (THAV02)', 'One committed business event. F5 opens its receipt; F6 opens the affected', 'member or account.'] },
  'case-list': {
    title: 'Case work queue',
    lines: ['CASE WORK QUEUE (THCS01)', 'Cases due soonest first. Filter by text (case or member number prefix, summary or', 'member name), state code, queue code and Y in Mine for cases assigned to you.',
      'S inquiry, N notes, R route, T change status, C correct subject. F6 opens a', 'case; from a member (C on the member list or F11) the case is for that member.'],
  },
  case: {
    title: 'Case inquiry',
    lines: ['CASE INQUIRY (THCS02)', 'Page 1 shows the case. F8 continues with the summary, the timeline, work items,', 'service-level intervals and documents. F4 route, F5 notes, F6 status,',
      'F9 correct subject, F10 member, F11 linked account.'],
  },
  'case-open': {
    title: 'Open case',
    lines: ['OPEN CASE (THCS03)', 'Enter the member, an optional account of that member, a queue code, an optional', 'assignee who works cases, a category code, a priority and a due date. The',
      'summary holds up to 200 characters and wraps over three lines. A second open', 'case for the same member, category and account is refused.'],
  },
  'case-route': {
    title: 'Route case',
    lines: ['ROUTE CASE (THCS05)', 'Choose the queue and assignee and give the reason. Moving a case out of a', 'restricted or supervisor queue into a queue with other visibility widens who',
      'works it and needs supervisory authority. Closed cases must be reopened first.'],
  },
  'case-status': {
    title: 'Change case status',
    lines: ['CHANGE CASE STATUS (THCS07)', 'Type the code of an allowed move and the reason. A case closes only after it is', 'resolved and has no open work items. Reopening keeps the earlier resolution in',
      'the timeline and opens an evidence work item. C and E require the exact current', 'member document version in Evidence version. Use Reason for the closure code', 'or reopening basis. Reopening work is due in seven days.'],
  },
  searches: {
    title: 'Saved searches',
    lines: ['SAVED SEARCHES (THSS01)', 'Your searches, then searches other operators shared. R runs one, M modifies one', 'you own, D deletes one you own. F6 creates a search. Sharing with the team needs',
      'case or supervisory authority. Other operators\' private searches never appear.'],
  },
  'search-results': {
    title: 'Saved search results',
    lines: ['SAVED SEARCH RESULTS (THSS02)', 'The stored filters, sort, columns and result limit, run against current data.', 'F10 and F11 move across columns that do not fit; F7/F8 page. S opens a record.'],
  },
  'search-edit': {
    title: 'Saved search editor',
    lines: ['SAVED SEARCH EDITOR (THSS03)', 'Name it, choose P or S and the records it lists (M, A or C; fixed once saved).', 'Filters use terminal codes: case states O W I R C E, queue codes, priority',
      'L N H U and assignee operator numbers. Filters you do not change keep their', 'stored values. Sort by one listed field, A or D. Columns are listed names',
      'separated by spaces; blank uses the default set. Enter reviews the change.'],
  },
  'case-subject-correct': {
    title: 'Correct case subject',
    lines: ['CORRECT CASE SUBJECT (THCS09)', 'Correct a misfiled member and optional account using a current document version.', 'The exact proposal needs an effective policy and independent approved decision.',
      'After correction, history remains and evidence moves behind restricted review.'],
  },
  directory: {
    title: 'Directory',
    lines: ['DIRECTORY', 'A bounded list of business records. Type scope or filter values and press', 'Enter to list. S beside a row opens the record; on a pick directory it fills the',
      'calling field. F7/F8 page. "More" means further rows exist beyond the page.'],
  },
  record: {
    title: 'Record detail',
    lines: ['RECORD DETAIL', 'Every authorized field of one finance record with its fingerprint and read time.', 'F7/F8 page. Nothing here changes the record; use the matching operation form.'],
  },
  opform: {
    title: 'Operation',
    lines: ['OPERATION', 'Fill the marked fields and press Enter to review. Nothing is stored until the',
      'review screen is confirmed. F4 on a marked field opens a pick directory. F7/F8', 'page long forms. Money fields carry a currency code; dates are YYYY-MM-DD; instants',
      'are ISO UTC. A blank approval field starts a request to an independent checker.'],
  },
  approval: {
    title: 'Approval decision',
    lines: ['APPROVAL DECISION (THAP02)', 'The approval binds the exact reviewed terms shown. As the assigned checker,',
      'enter A or D and a reason; Enter submits the decision for review. On an approved',
      'approval, F9 executes the bound action as the checker. F7/F8 page the terms.'],
  },
  'approval-request': {
    title: 'Request approval',
    lines: ['REQUEST APPROVAL (THAP03)', 'The prepared action is bound exactly as shown. Pick the independent checker',
      '(F4 on Checker lists operators authorized for this command), the effective', 'policy version, an expiry within seven days, and optionally an exact amount',
      'limit. Enter submits the request for review; nothing runs until decided.'],
  },
  qresult: {
    title: 'Query result',
    lines: ['QUERY RESULT', 'A read-only answer computed by the shared service. F7/F8 page.', 'No record is changed by an inquiry.'],
  },
  docview: {
    title: 'Document view',
    lines: ['DOCUMENT VIEW (THDC01)', 'One stored document version: type, owner, media, pages and SHA-256 digest.',
      'F5 prepares the file for download (Alt+D or the link). F6 lists annotations,', 'F9 signatures, F10 opens the annotate form. Bytes are integrity-checked.'],
  },
  maintenance: {
    title: 'Maintenance',
    lines: ['MAINTENANCE (THMN01/02)', 'A maintenance draft records the member, the requested change kind and any', 'missing fields without applying business changes. Enter saves or amends;',
      'F6 submits a draft; F11 withdraws it. On a submitted request the reviewer', 'chooses approve, reject or return-for-information; an approved request is',
      'then processed by applying (with the committed receipt) or rejecting.'],
  },
  batch: {
    title: 'Batch',
    lines: ['BATCH (THBT01)', 'An imported batch lists its exact items. F5 previews the batch against the',
      'stored input digest; F6 starts the campaign approval binding every item.', 'Once approved, A beside an item applies it under the campaign approval; the',
      'approval is consumed at the terminal item. Conflict policy S skips stale', 'items, R rejects the whole batch.'],
  },
  'stmt-export': {
    title: 'Statement export',
    lines: ['STATEMENT EXPORT (THEX02)', 'Exports posted ledger entries for a period as HTML, CSV and/or PDF files',
      'generated from the ledger snapshot at export time. Type D beside a prepared', 'file to offer its download. Issued statement versions are never replaced.'],
  },
};
