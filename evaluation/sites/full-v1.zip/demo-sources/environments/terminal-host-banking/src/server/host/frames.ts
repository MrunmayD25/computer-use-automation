import type { FinanceCommand, FinanceRecordKind, OperationReview, SavedSearchDefinition, SavedSearchEntity, ServiceCommand, ServicingCommand } from '@computer-use/financial-database/services';

import type { Severity, TransferOffer } from '../../shared/protocol.js';

/**
 * Terminal navigation state. Frames belong to one terminal session and hold only presentation
 * state: which records are shown, criteria, page offsets, and the operator's unsent drafts. They
 * never hold an authoritative copy of business data; every render reads current records.
 */

/** Field values the operator has transmitted for this frame, by input name. */
export type Draft = Record<string, string>;

export interface Message {
  text: string;
  severity: Severity;
}

interface FrameBase {
  values: Draft;
  /** Input to highlight as the subject of the last validation error. */
  error?: string | undefined;
  /** Input that receives the cursor on the next render. */
  cursor?: string | undefined;
  /** Set after a first cancel request on a screen with unsent edits. */
  discardArmed?: boolean | undefined;
  /** The record changed after this edit began; show current values and adopt their version. */
  conflict?: boolean | undefined;
  transfer?: TransferOffer | undefined;
}

export interface ListCriteria {
  query: string;
  status: string;
}

export interface HistoryCriteria {
  from: string;
  to: string;
  direction: string;
  minimum: string;
  maximum: string;
  text: string;
  reference: string;
  order: string;
  status: string;
}

export interface ActivitySnapshot {
  sequence: number;
  occurredAt: string;
  kind: string;
  resourceKind: string;
  resourceId: string;
  summary: string;
  actor: string;
  operationId: string | null;
  operationStatus: string | null;
  receiptNumber: string | null;
}

export interface StatementRow {
  kind: 'stored' | 'period';
  versionId: string | null;
  period: string;
  label: string;
  version: number | null;
  mediaType: string;
  issuedAt: string | null;
  byteLength: number | null;
}

export interface HistoryRow {
  journalId: string;
  lineNumber: number;
  reference: string;
  receiptNumber: string | null;
}

/** The record a note list belongs to. Member and case notes share one set of note screens. */
export interface NoteSubject {
  kind: 'member' | 'case';
  id: string;
}

/** Case work-queue filters as typed: state and queue codes, and Y for the operator's own cases. */
export interface CaseCriteria {
  query: string;
  state: string;
  queue: string;
  mine: string;
}

/** A record listed by a saved search, opened with S. */
export interface SearchHit {
  kind: 'member' | 'account' | 'case';
  id: string;
}

/** One change shown on a review screen. */
export interface ReviewLine {
  label: string;
  before: string;
  after: string;
}

/** One row of a generic directory: an opaque record id and the line the operator sees. */
export interface DirectoryRow {
  id: string;
  line: string;
  /** Short text copied beside a form field when the row is picked. */
  label: string;
  /** Extra named values copied into the calling form on a pick, such as an address id or version. */
  extra?: Record<string, string>;
}



export type Frame =
  | FrameBase & { kind: 'signon' }
  | FrameBase & { kind: 'menu'; section?: string; page?: number }
  /** `message` holds the full text of a message too long for the message line when F1 was pressed. */
  | FrameBase & { kind: 'help'; topic: FrameKind; page: number; message?: string | undefined }
  | FrameBase & { kind: 'member-list'; criteria: ListCriteria; offset: number; total: number; rows: string[] }
  | FrameBase & { kind: 'member'; memberId: string; page: number }
  | FrameBase & { kind: 'member-create'; party: 'person' | 'organization' }
  | FrameBase & { kind: 'contact'; memberId: string; version: number; baseline: Draft }
  | FrameBase & { kind: 'notes'; subject: NoteSubject; offset: number; total: number; rows: string[] }
  /** The note text spans editor pages; each page is one wrapped input whose draft is kept here. */
  | FrameBase & { kind: 'note-add'; subject: NoteSubject; page: number }
  | FrameBase & { kind: 'note'; subject: NoteSubject; noteId: string; page: number }
  | FrameBase & { kind: 'case-list'; memberId: string | null; criteria: CaseCriteria; offset: number; total: number; rows: string[] }
  | FrameBase & { kind: 'case'; caseId: string; page: number }
  | FrameBase & { kind: 'case-open'; memberId: string | null }
  | FrameBase & { kind: 'case-route'; caseId: string; version: number }
  | FrameBase & { kind: 'case-status'; caseId: string; version: number }
  | FrameBase & { kind: 'case-subject-correct'; caseId: string; version: number }
  | FrameBase & { kind: 'searches'; offset: number; total: number; rows: string[] }
  | FrameBase & { kind: 'search-results'; searchId: string; offset: number; column: number; total: number; hits: SearchHit[] }
  /**
   * `original` is the stored definition when modifying; filters the operator leaves untouched keep
   * their stored values, so a search saved elsewhere is never rewritten by the terminal's notation.
   */
  | FrameBase & { kind: 'search-edit'; searchId: string | null; revision: string | null; entity: SavedSearchEntity; baseline: Draft; original: SavedSearchDefinition | null }
  | FrameBase & { kind: 'account-list'; memberId: string | null; criteria: ListCriteria; offset: number; total: number; rows: string[] }
  | FrameBase & { kind: 'account'; accountId: string; page: number }
  | FrameBase & { kind: 'account-open'; memberId: string; products: string[] }
  | FrameBase & { kind: 'account-profile'; accountId: string; version: number; baseline: Draft }
  | FrameBase & { kind: 'account-close'; accountId: string; version: number }
  | FrameBase & { kind: 'cash'; direction: 'deposit' | 'withdraw' }
  | FrameBase & { kind: 'transfer' }
  | FrameBase & {
    kind: 'review';
    screenId: string;
    title: string;
    command: ServiceCommand;
    review: OperationReview;
    lines: ReviewLine[];
    /** Maps a service input name to the entry screen's input, for placing the cursor after a rejection. */
    fields: Record<string, string>;
    idempotencyKey: string;
    /** Long text the operation stores, shown in full after the items. */
    body?: string | undefined;
    /** First review row shown; items, text and consequences page together with F7/F8. */
    offset: number;
  }
  | FrameBase & { kind: 'receipt'; receiptNumber: string; offset: number; replayed: boolean }
  | FrameBase & { kind: 'receipt-lookup' }
  | FrameBase & { kind: 'history'; accountId: string; criteria: HistoryCriteria; offset: number; total: number; rows: HistoryRow[] }
  | FrameBase & { kind: 'entry'; accountId: string; row: HistoryRow }
  | FrameBase & { kind: 'statements'; accountId: string; offset: number; total: number; rows: StatementRow[] }
  | FrameBase & { kind: 'statement'; accountId: string; period: string; offset: number }
  | FrameBase & { kind: 'export'; accountId: string }
  | FrameBase & { kind: 'activity'; memberId: string | null; accountId: string | null; criteria: { kind: string; query: string }; offset: number; total: number; rows: ActivitySnapshot[] }
  | FrameBase & { kind: 'event'; event: ActivitySnapshot }
  /**
   * A generic paged record directory. `dir` names a registered directory; `scope` holds resolved
   * scope values (record ids under `name`, display text under `name.label`); `pick` names the
   * calling frame's field that a selection fills instead of opening a detail.
   */
  | FrameBase & { kind: 'directory'; dir: string; scope: Record<string, string>; offset: number; total: number; rows: DirectoryRow[]; pick: string | null }
  /** A generic paged detail of one finance record read through `readFinanceRecord`. */
  | FrameBase & { kind: 'record'; resource: FinanceRecordKind; id: string; offset: number }
  /** A generic operation form driven by a registered operation spec; `page` pages its fields. */
  | FrameBase & { kind: 'opform'; op: string; page: number }
  /** One approval's exact reviewed terms, its decision, and the execute-approved action. */
  | FrameBase & { kind: 'approval'; approvalId: string; offset: number }
  /** Requests independent approval for a target command the maker prepared. */
  | FrameBase & { kind: 'approval-request'; command: ServicingCommand | FinanceCommand; lines: ReviewLine[] }
  /** A paged read-only result, such as an identity resolution or a reconciliation outcome. */
  | FrameBase & { kind: 'qresult'; title: string; lines: string[]; page: number }
  /** One stored document version: metadata, signatures, annotations and its file offer. */
  | FrameBase & { kind: 'docview'; versionId: string; offset: number }
  /** A maintenance draft being composed or amended; `reqKind` names the requested command kind. */
  | FrameBase & { kind: 'maintenance'; memberId: string | null; requestId: string | null; expectedUpdatedAt: string | null }
  /** A payment batch's items and their per-item application state. */
  | FrameBase & { kind: 'batch'; batchId: string; offset: number; total: number }
  /** A statement export request: period, formats and the offered artifact downloads. */
  | FrameBase & { kind: 'stmt-export'; accountId: string; artifacts: TransferOffer[] };

export type FrameKind = Frame['kind'];
export type FrameOf<K extends FrameKind> = Extract<Frame, { kind: K }>;

export const info = (text: string): Message => ({ text, severity: 'info' });
export const success = (text: string): Message => ({ text, severity: 'success' });
export const warning = (text: string): Message => ({ text, severity: 'warning' });
export const failure = (text: string): Message => ({ text, severity: 'error' });
