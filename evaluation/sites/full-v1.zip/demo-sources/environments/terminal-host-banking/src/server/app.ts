import { existsSync, readFileSync } from 'node:fs';
import { createServer, type Server } from 'node:http';
import { join } from 'node:path';

import express, { type NextFunction, type Request, type Response } from 'express';
import { z } from 'zod';

import { AIDS, COLUMNS, ROWS, type InputMessage } from '../shared/protocol.js';
import { HostError, TerminalHost, type HostOptions } from './host/host.js';

export const DEFAULT_PORT = 4340;
const MAX_FIELD_CELLS = 1920;

export interface TerminalHostOptions extends HostOptions {
  publicDirectory?: string;
  host?: string;
  port?: number;
  verbose?: boolean;
  /** Called after the listener stops; the shared CLI closes its store here, an evaluator keeps its run. */
  onClose?: () => void;
}

export interface TerminalHostHandle {
  origin: string;
  host: TerminalHost;
  close: () => Promise<void>;
}

/** The wire shape of one transmission. Field data is checked again against the screen's field table. */
const inputSchema = z.object({
  sequence: z.number().int().nonnegative(),
  aid: z.enum(AIDS),
  cursor: z.object({ row: z.number().int().min(0).max(ROWS - 1), column: z.number().int().min(0).max(COLUMNS - 1) }),
  fields: z.array(z.object({ address: z.number().int().min(0).max(ROWS * COLUMNS - 1), value: z.string().max(MAX_FIELD_CELLS) })).max(ROWS * COLUMNS),
}).strict() satisfies z.ZodType<InputMessage>;

function contentDisposition(fileName: string): string {
  return `attachment; filename="${fileName.replaceAll(/[^A-Za-z0-9._-]/gu, '_')}"`;
}

function parameter(request: Request, name: string): string {
  const found: unknown = request.params[name];
  if (typeof found !== 'string') throw new HostError(400, 'invalid_request', `Missing path parameter ${name}.`);
  return found;
}

/**
 * The terminal's HTTP surface. Browsers exchange whole screens and field data with the host; they
 * never name datasets, actors or business rules. Private evaluator material is never served.
 */
export function createTerminalApp(options: TerminalHostOptions, host: TerminalHost): express.Express {
  const app = express();
  app.disable('x-powered-by');
  if (options.verbose === true) {
    app.use((request, response, next) => {
      const started = process.hrtime.bigint();
      response.on('finish', () => { console.error(`${request.method} ${request.path} ${String(response.statusCode)} ${String(Number(process.hrtime.bigint() - started) / 1e6)}ms`); });
      next();
    });
  }
  app.use('/api', (request, response, next) => {
    response.setHeader('Cache-Control', 'no-store');
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      const origin = request.get('origin');
      if (origin !== undefined && origin !== `${request.protocol}://${request.get('host') ?? ''}`) { next(new HostError(403, 'cross_origin', 'Cross-origin requests are not accepted.')); return; }
    }
    next();
  });
  app.use('/api', express.json({ limit: '64kb' }));

  app.get('/healthz', (_request, response) => { response.json({ status: 'ok' }); });
  app.post('/api/sessions', async (_request, response) => { response.status(201).json(await host.open()); });
  app.get('/api/sessions/:sessionId/screen', async (request, response) => { response.json(await host.screen(parameter(request, 'sessionId'))); });
  app.post('/api/sessions/:sessionId/input', async (request, response) => {
    const parsed = inputSchema.safeParse(request.body);
    if (!parsed.success) throw new HostError(400, 'invalid_input', `The transmission is malformed: ${parsed.error.issues[0]?.message ?? 'unknown problem'}.`);
    response.json(await host.input(parameter(request, 'sessionId'), parsed.data));
  });
  app.get('/api/sessions/:sessionId/transfers/:token', (request, response) => {
    const file = host.transfer(parameter(request, 'sessionId'), parameter(request, 'token'));
    if (file === undefined) throw new HostError(404, 'unknown_transfer', 'The file is no longer offered. Prepare it again on the terminal.');
    response.setHeader('Content-Type', file.mediaType === 'text/csv' ? 'text/csv; charset=utf-8' : file.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(file.fileName));
    response.setHeader('X-Document-Digest', file.digest);
    response.end(Buffer.from(file.bytes));
  });
  app.delete('/api/sessions/:sessionId', (request, response) => {
    host.close(parameter(request, 'sessionId'));
    response.status(204).end();
  });
  app.use('/api', (_request, _response, next) => { next(new HostError(404, 'not_found', 'Unknown API route.')); });

  const publicDirectory = options.publicDirectory;
  if (publicDirectory !== undefined && existsSync(join(publicDirectory, 'index.html'))) {
    app.use(express.static(publicDirectory, { index: false, maxAge: '1h', setHeaders: (response, path) => { if (path.endsWith('.html')) response.setHeader('Cache-Control', 'no-store'); } }));
    // Send the entry point from the same validated directory used by the static
    // middleware. Reading it here avoids Express' asynchronous sendfile lookup
    // racing a disposable verification fixture's teardown.
    app.get('/', (_request, response) => {
      response.setHeader('Cache-Control', 'no-store');
      response.type('html').send(readFileSync(join(publicDirectory, 'index.html')));
    });
  } else {
    app.get('/', (_request, response) => { response.status(503).type('text/plain').send('The terminal client is not built. Run npm run build in environments/terminal-host-banking.'); });
  }

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    const failure = error instanceof HostError ? error
      : error instanceof SyntaxError ? new HostError(400, 'invalid_json', 'The request body is not valid JSON.')
        : new HostError(500, 'internal_error', 'The terminal host failed to complete the request.');
    if (failure.status === 500) console.error(error);
    response.status(failure.status).json({ error: { code: failure.code, message: failure.message } });
  });
  return app;
}

/**
 * Starts the terminal host on a listener. The caller owns the store: the CLI closes its shared
 * connection in `onClose`, while an evaluator keeps its verification run after the listener stops.
 */
export async function startTerminalHost(options: TerminalHostOptions): Promise<TerminalHostHandle> {
  const host = new TerminalHost(options);
  const listenAddress = options.host ?? '127.0.0.1';
  const server: Server = createServer(createTerminalApp(options, host));
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(options.port ?? DEFAULT_PORT, listenAddress, () => { server.off('error', reject); resolve(); });
  });
  const address = server.address();
  if (address === null || typeof address === 'string') throw new Error('Listener has no TCP address.');
  let closing: Promise<void> | undefined;
  return {
    origin: `http://${listenAddress}:${String(address.port)}`,
    host,
    close() {
      closing ??= new Promise<void>((resolve, reject) => {
        server.closeIdleConnections();
        const force = setTimeout(() => { server.closeAllConnections(); }, 2_000);
        server.close((error) => {
          clearTimeout(force);
          try { options.onClose?.(); } catch (closeError) { reject(closeError instanceof Error ? closeError : new Error(String(closeError))); return; }
          if (error === undefined) resolve(); else reject(error);
        });
      });
      return closing;
    },
  };
}
