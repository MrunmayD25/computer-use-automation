import { randomUUID } from 'node:crypto';

import {
  accountDetail, caseDetail, memberDetail, readFinanceRecord, referenceData, searchAccounts, searchCases, searchMembers,
  type AccountDetail, type AccountRow, type CaseDetail, type CommandOutcome, type FinanceRecordKind, type FinanceRecordSnapshot, type MemberDetail, type MemberRow, type NoteReader, type Receipt, type Rejection, type ServiceCommand, type ServiceContext,
} from '@computer-use/financial-database/services';

import { failure, info, type Frame, type FrameOf, type Message, type ReviewLine } from '../host/frames.js';
import { upper } from '../host/format.js';
import type { HostContext, Outcome } from '../host/module.js';
import type { ScreenBuilder } from '../host/screen.js';

export const LIST_TOP = 7;
export const LIST_ROWS = 12;

export const inactiveKey = (): Outcome => ({ kind: 'stay', message: failure('KEY NOT ACTIVE ON THIS SCREEN. SEE THE KEY LEGEND OR PRESS F1.') });

/** True for a host navigation outcome, never for a domain object with a `kind` field. */
export function isOutcome(value: unknown): value is Outcome {
  return value !== null && typeof value === 'object'
    && ['stay', 'push', 'replace', 'pop', 'reset'].includes(String(Reflect.get(value, 'kind')));
}

/** `PAGE 2 OF 5`, or `PAGE 1 OF 1` for an empty result. */
export function pageLabel(offset: number, limit: number, total: number): string {
  return `PAGE ${Math.floor(offset / limit) + 1} OF ${Math.max(1, Math.ceil(total / limit))}`;
}

export function rowsLabel(offset: number, shown: number, total: number): string {
  return total === 0 ? 'NO ROWS' : `ROWS ${offset + 1}-${offset + shown} OF ${total}`;
}

/** Keeps a stored offset on an existing page when the result set has shrunk since it was chosen. */
export function clampOffset(offset: number, limit: number, total: number): number {
  if (offset < total || total === 0) return total === 0 ? 0 : offset;
  return Math.floor((total - 1) / limit) * limit;
}

/** Offset after F7/F8, a message when the list is already at that end, or null for other keys. */
export function turnPage(aid: string, offset: number, limit: number, total: number): { offset: number } | { message: Message } | null {
  if (aid === 'pf7') return offset === 0 ? { message: info('ALREADY AT THE FIRST PAGE.') } : { offset: Math.max(0, offset - limit) };
  if (aid === 'pf8') return offset + limit >= total ? { message: info('ALREADY AT THE LAST PAGE.') } : { offset: offset + limit };
  return null;
}

/** Applies F7/F8 to a frame's offset, or returns null when the key is not a paging key. */
export function page(frame: { offset: number }, aid: string, limit: number, total: number): Outcome | null {
  const turned = turnPage(aid, frame.offset, limit, total);
  if (turned === null) return null;
  if ('message' in turned) return { kind: 'stay', message: turned.message };
  frame.offset = turned.offset;
  return { kind: 'stay' };
}

export function value(frame: Frame, name: string, fallback = ''): string {
  return frame.values[name] ?? fallback;
}

/** Drops the operator's drafts for the inputs that match, so the next render shows host values. */
export function forget(frame: Frame, matches: (name: string) => boolean): void {
  frame.values = Object.fromEntries(Object.entries(frame.values).filter(([name]) => !matches(name)));
}

/**
 * The single selection code typed beside a list row, with that row's index. Codes are cleared once
 * read so a code never acts again after the list is redisplayed.
 */
export function selection(frame: Frame, rowCount: number): { index: number; code: string } | { message: Message; error: string } | null {
  const picked: { index: number; code: string }[] = [];
  for (let index = 0; index < rowCount; index += 1) {
    const code = upper(value(frame, `sel.${index}`).trim());
    if (code !== '') picked.push({ index, code });
  }
  forget(frame, (name) => name.startsWith('sel.'));
  if (picked.length > 1) return { message: failure('SELECT ONE ROW AT A TIME.'), error: `sel.${String(picked[1]?.index ?? 0)}` };
  return picked[0] ?? null;
}

export function badSelection(code: string, allowed: string, index: number): Outcome {
  return { kind: 'stay', message: failure(`SELECTION CODE ${code.slice(0, 3)} IS NOT VALID HERE. USE ${allowed}.`), error: `sel.${index}` };
}

/** Exact business-number lookups; search results are filtered so a prefix never selects another record. */
/** Finds a member by its business number, or verifies an id a directory pick stored. */
export function findMember(context: HostContext, memberNumber: string): MemberRow | undefined {
  const wanted = upper(memberNumber.trim());
  if (wanted === '') return undefined;
  return context.read((database, datasetId) => {
    const byNumber = searchMembers(database, datasetId, { query: wanted, limit: 50, offset: 0 }).items.find((row) => row.memberNumber === wanted);
    if (byNumber !== undefined) return byNumber;
    return searchMembers(database, datasetId, { limit: 200, offset: 0 }).items.find((row) => row.id === memberNumber.trim());
  });
}

/** Finds an account by its business number, or verifies an id a directory pick stored. */
export function findAccount(context: HostContext, accountNumber: string): AccountRow | undefined {
  const wanted = upper(accountNumber.trim());
  if (wanted === '') return undefined;
  return context.read((database, datasetId) => {
    const byNumber = searchAccounts(database, datasetId, { query: wanted, limit: 50, offset: 0 }).items.find((row) => row.accountNumber === wanted);
    if (byNumber !== undefined) return byNumber;
    return searchAccounts(database, datasetId, { limit: 200, offset: 0 }).items.find((row) => row.id === accountNumber.trim());
  });
}

/** Safe cell text for an `unknown` record value; composite values render as JSON rather than `[object Object]`. */
export function cell(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'bigint' || typeof value === 'boolean') return String(value);
  return JSON.stringify(value);
}

/** Finds an actor at the signed-on institution by operator number or by id a pick stored. */
export function findActor(context: HostContext, actorNumber: string): { id: string; actorNumber: string; displayName: string } | undefined {
  const wanted = upper(actorNumber.trim());
  if (wanted === '') return undefined;
  return context.read((database, datasetId) => {
    const row = database.prepare('SELECT id,actor_number,display_name FROM actors WHERE dataset_id=? AND (actor_number=? OR id=?)').get(datasetId, wanted, actorNumber.trim()) as { id?: string; actor_number?: string; display_name?: string } | undefined;
    return row === undefined ? undefined : { id: String(row.id), actorNumber: String(row.actor_number), displayName: String(row.display_name) };
  });
}

/** The signed-on operator as a note reader, so restricted notes appear only when the shared rules allow. */
function noteReader(context: HostContext): NoteReader {
  const { institution, operator } = context.session();
  return { institutionId: institution.institutionId, actorId: operator.actorId };
}

/** A trusted service context for the signed-on operator inside a `context.read` callback. */
export function serviceContext(context: HostContext, use: string): ServiceContext {
  const { binding, operator } = context.session();
  return { binding, actorId: operator.actorId, reference: `terminal-host-banking:${use}` };
}

/** Reads one finance record snapshot through the authorized store. */
export function readRecord(context: HostContext, resource: FinanceRecordKind, id: string): FinanceRecordSnapshot | Rejection {
  const { binding, operator } = context.session();
  return context.svc((store) => {
    const result = readFinanceRecord(store, { binding, actorId: operator.actorId, reference: `terminal-host-banking:record-${resource}` }, resource, id);
    return result.kind === 'found' ? result.snapshot : result.kind === 'rejected' ? result : { kind: 'rejected' as const, code: 'not_found' as const, message: `The ${resource} record was not found.` };
  });
}

/** Frames only carry identifiers read from the signed-on dataset, so a missing record is a host fault. */
export function readMember(context: HostContext, memberId: string): MemberDetail {
  const reader = noteReader(context);
  const detail = context.read((database, datasetId) => memberDetail(database, datasetId, memberId, reader));
  if (detail === undefined) throw new Error(`Member ${memberId} is not in the signed-on dataset.`);
  return detail;
}

export function readCase(context: HostContext, caseId: string): CaseDetail {
  const reader = noteReader(context);
  const detail = context.read((database, datasetId) => caseDetail(database, datasetId, caseId, reader));
  if (detail === undefined) throw new Error(`Case ${caseId} is not in the signed-on dataset.`);
  return detail;
}

/** Finds a case by its business number, or verifies an id a directory pick stored. */
export function findCase(context: HostContext, caseNumber: string): { id: string; caseNumber: string } | undefined {
  const wanted = upper(caseNumber.trim());
  if (wanted === '') return undefined;
  return context.read((database, datasetId) => {
    const hit = searchCases(database, datasetId, { query: wanted, limit: 50, offset: 0 }, context.session().institution.asOf).items.find((row) => row.caseNumber === wanted);
    if (hit !== undefined) return hit;
    const byId = database.prepare('SELECT id,case_number FROM cases WHERE dataset_id=? AND id=?').get(datasetId, caseNumber.trim()) as { id: string; case_number: string } | undefined;
    return byId === undefined ? undefined : { id: byId.id, caseNumber: byId.case_number };
  });
}

export function readAccount(context: HostContext, accountId: string): AccountDetail {
  const detail = context.read((database, datasetId) => accountDetail(database, datasetId, accountId));
  if (detail === undefined) throw new Error(`Account ${accountId} is not in the signed-on dataset.`);
  return detail;
}

export function currencyExponent(context: HostContext, currency: string): number | undefined {
  const { institution } = context.session();
  return context.read((database, datasetId) => referenceData(database, datasetId, institution.institutionId).currencies.find((entry) => entry.code === currency)?.exponent);
}

export function notFound(kind: 'MEMBER' | 'ACCOUNT', number: string, context: HostContext): Message {
  return failure(`${kind} ${upper(number.trim()).slice(0, 12)} NOT FOUND AT ${upper(context.session().institution.displayName)}.`);
}

/** Draws `LABEL . . . .` leaders in a fixed width, as on host panels. */
export function label(builder: ScreenBuilder, row: number, column: number, text: string, width: number): ScreenBuilder {
  let leader = `${text} `;
  while (leader.length < width - 1) leader += leader.length % 2 === 0 ? ' ' : '.';
  return builder.text(row, column, leader.slice(0, width));
}

/** Uppercase host message for a shared-service rejection, with the input it concerns. */
export function rejectionMessage(rejection: Rejection, fields: Readonly<Record<string, string>> = {}): { message: Message; error: string | undefined } {
  const field = rejection.field === undefined ? undefined : fields[rejection.field] ?? rejection.field;
  return { message: failure(upper(rejection.message)), error: field };
}

export const CONFLICT_MESSAGE = 'RECORD CHANGED BY ANOTHER USER. CURRENT VALUES SHOWN; YOUR ENTRIES ARE KEPT.';

/**
 * Starts the review step for a command: the shared service validates it against current data and
 * returns its terms, which the review screen shows before anything is posted or changed.
 */
export function beginReview(
  context: HostContext, frame: Frame, input: { command: ServiceCommand; screenId: string; title: string; lines: ReviewLine[]; fields: Record<string, string>; body?: string },
): Outcome {
  const outcome = context.review(input.command);
  if (outcome.kind === 'rejected') {
    if (outcome.code === 'stale_version') {
      frame.conflict = true;
      return { kind: 'stay', message: failure(CONFLICT_MESSAGE) };
    }
    const { message, error } = rejectionMessage(outcome, input.fields);
    return { kind: 'stay', message, ...(error === undefined ? {} : { error }) };
  }
  if (outcome.kind === 'unchanged') return { kind: 'stay', message: info(upper(outcome.message)) };
  return {
    kind: 'push',
    frame: {
      kind: 'review', values: {}, screenId: input.screenId, title: input.title, command: input.command, review: outcome.review,
      lines: input.lines, fields: input.fields, idempotencyKey: `th-${randomUUID()}`, offset: 0, ...(input.body === undefined ? {} : { body: input.body }),
    },
  };
}

export function committedReceipt(outcome: CommandOutcome): { receipt: Receipt; replayed: boolean } | null {
  if (outcome.kind === 'committed') return { receipt: outcome.receipt, replayed: false };
  if (outcome.kind === 'duplicate') return { receipt: outcome.receipt, replayed: true };
  return null;
}

export function deliveryCode(code: string): 'paper' | 'electronic' | null {
  const normalized = upper(code.trim());
  return normalized === 'P' ? 'paper' : normalized === 'E' ? 'electronic' : null;
}

export function deliveryLetter(delivery: string): string {
  return delivery === 'paper' ? 'P' : 'E';
}

export function deliveryWord(delivery: string): string {
  return delivery === 'paper' ? 'PAPER' : 'ELECTRONIC';
}

/* Frame constructors shared by screens that open one another. */

export const memberFrame = (memberId: string): Frame => ({ kind: 'member', values: {}, memberId, page: 1 });
export const accountFrame = (accountId: string): Frame => ({ kind: 'account', values: {}, accountId, page: 1 });
export const caseFrame = (caseId: string): Frame => ({ kind: 'case', values: {}, caseId, page: 1 });
export const caseListFrame = (memberId: string | null): Frame => ({
  kind: 'case-list', values: {}, memberId, criteria: { query: '', state: '', queue: '', mine: '' }, offset: 0, total: 0, rows: [],
});
export const accountListFrame = (memberId: string | null): Frame => ({ kind: 'account-list', values: {}, memberId, criteria: { query: '', status: '' }, offset: 0, total: 0, rows: [] });
export const accountOpenFrame = (memberId: string): Frame => ({ kind: 'account-open', values: {}, memberId, products: [] });
export const historyFrame = (accountId: string): Frame => ({
  kind: 'history', values: {}, accountId, offset: 0, total: 0, rows: [], criteria: { from: '', to: '', direction: '', minimum: '', maximum: '', text: '', reference: '', order: 'N', status: '' },
});
export const statementsFrame = (accountId: string): Frame => ({ kind: 'statements', values: {}, accountId, offset: 0, total: 0, rows: [] });
export const exportFrame = (accountId: string): Frame => ({ kind: 'export', values: {}, accountId });
export const activityFrame = (scope: { memberId?: string; accountId?: string }): Frame => ({
  kind: 'activity', values: {}, memberId: scope.memberId ?? null, accountId: scope.accountId ?? null, criteria: { kind: '', query: '' }, offset: 0, total: 0, rows: [],
});
export const cashFrame = (direction: 'deposit' | 'withdraw', accountNumber = ''): Frame => ({ kind: 'cash', direction, values: accountNumber === '' ? {} : { account: accountNumber } });
export const transferFrame = (fromAccountNumber = ''): Frame => ({ kind: 'transfer', values: fromAccountNumber === '' ? {} : { from: fromAccountNumber } });

export function contactValues(detail: MemberDetail): Record<string, string> {
  return {
    email: detail.email?.value ?? '', phone: detail.phone?.value ?? '', line1: detail.address?.line1 ?? '', line2: detail.address?.line2 ?? '',
    city: detail.address?.city ?? '', region: detail.address?.region ?? '', postal: detail.address?.postalCode ?? '', country: detail.address?.country ?? '',
  };
}

export function contactFrame(detail: MemberDetail): FrameOf<'contact'> {
  return { kind: 'contact', values: {}, memberId: detail.member.id, version: detail.member.version, baseline: contactValues(detail) };
}

export function profileValues(detail: AccountDetail): Record<string, string> {
  return { nickname: detail.account.nickname, delivery: deliveryLetter(detail.account.statementDelivery) };
}

export function profileFrame(detail: AccountDetail): FrameOf<'account-profile'> {
  return { kind: 'account-profile', values: {}, accountId: detail.account.id, version: detail.account.version, baseline: profileValues(detail) };
}

export function closeFrame(detail: AccountDetail): FrameOf<'account-close'> {
  return { kind: 'account-close', values: {}, accountId: detail.account.id, version: detail.account.version };
}

/** True when any named draft differs from its baseline value. */
export function differs(frame: Frame, baseline: Readonly<Record<string, string>>, names: readonly string[]): boolean {
  return names.some((name) => name in frame.values && (frame.values[name] ?? '').trim() !== (baseline[name] ?? '').trim());
}

/** True when any input on the frame holds non-blank text. */
export function anyEntered(frame: Frame, names: readonly string[]): boolean {
  return names.some((name) => (frame.values[name] ?? '').trim() !== '');
}
