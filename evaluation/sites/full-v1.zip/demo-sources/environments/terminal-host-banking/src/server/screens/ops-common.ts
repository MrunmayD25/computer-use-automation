import type { FinanceRecordKind } from '@computer-use/financial-database/services';

import { type Frame } from '../host/frames.js';
import { upper } from '../host/format.js';
import type { HostContext, Outcome } from '../host/module.js';
import { findAccount, findCase, findMember, isOutcome, readAccount, readCase, readMember, readRecord } from './common.js';
import { entered, fieldProblem, type OpField } from './ops.js';

export type { OpField } from './ops.js';

/* Common form fields. */

export const MEMBER: OpField = { name: 'member', label: 'MEMBER', width: 10, pick: { dir: 'members' }, hint: 'NUMBER, F4=PICK' };
export const ACCOUNT: OpField = { name: 'account', label: 'ACCOUNT', width: 10, pick: { dir: 'accounts', scope: { memberId: 'member' } }, hint: 'NUMBER, F4=PICK' };
export const OPT_ACCOUNT: OpField = { ...ACCOUNT, required: false };
export const CASE_FIELD: OpField = { name: 'case', label: 'CASE', width: 10, pick: { dir: 'cases', scope: { memberId: 'member' } }, hint: 'NUMBER, F4=PICK' };
export const POLICY: OpField = { name: 'policy', label: 'POLICY VERSION', width: 40, pick: { dir: 'policies' }, hint: 'F4=PICK' };
export const REASON: OpField = { name: 'reason', label: 'REASON', width: 58, capacity: 500, kind: 'text' };
export const EFFECTIVE: OpField = { name: 'effective', label: 'EFFECTIVE DATE', width: 10, kind: 'date', hint: 'YYYY-MM-DD' };
export const DOC_VERSION: OpField = { name: 'version', label: 'DOCUMENT VERSION', width: 40, pick: { dir: 'documents', scope: { memberId: 'member' } }, hint: 'F4=PICK VERSION' };

export function dateField(name: string, labelText: string, required = true): OpField {
  return { name, label: labelText, width: 10, kind: 'date', required, hint: 'YYYY-MM-DD' };
}

export function instantField(name: string, labelText: string, required = true): OpField {
  return { name, label: labelText, width: 20, kind: 'instant', required, hint: 'ISO UTC INSTANT' };
}

export function moneyField(name: string, labelText: string, { signed = false, required = true }: { signed?: boolean; required?: boolean } = {}): OpField {
  return { name, label: labelText, width: 14, kind: signed ? 'smoney' : 'money', required };
}

export function textField(name: string, labelText: string, width: number, { capacity, required = true, hint, kind }: { capacity?: number; required?: boolean; hint?: string; kind?: OpField['kind'] } = {}): OpField {
  return { name, label: labelText, width, ...(capacity === undefined ? {} : { capacity }), required, ...(hint === undefined ? {} : { hint }), ...(kind === undefined ? {} : { kind }) };
}

export function codeField(name: string, labelText: string, codes: Record<string, string>, required = true): OpField {
  return { name, label: labelText, width: 1, kind: 'code', codes, required };
}

export function flagField(name: string, labelText: string, required = false): OpField {
  return { name, label: labelText, width: 1, kind: 'flag', required, hint: 'Y/N' };
}

export function numField(name: string, labelText: string, required = true): OpField {
  return { name, label: labelText, width: 10, kind: 'num', required, numeric: true };
}

/** The standard approval field: pick an existing approval or leave blank to request one. */
export const APPROVAL: OpField = {
  name: 'approvalId', label: 'APPROVAL', width: 40, required: false,
  pick: { dir: 'approvals', scope: { kind: '@op' } },
  hint: 'F4=PICK EXISTING, BLANK=REQUEST',
};

export const approvalId = (frame: Frame): string => entered(frame, 'approvalId');

/** Member number or picked id -> memberId plus the member's current version. */
export function memberRef(context: HostContext, frame: Frame, name = 'member'): { memberId: string; version: number; number: string } | Outcome {
  const found = findMember(context, entered(frame, name));
  if (found === undefined) return fieldProblem(name, 'MEMBER NOT FOUND. TYPE A NUMBER OR F4 TO PICK.');
  return { memberId: found.id, version: readMember(context, found.id).member.version, number: found.memberNumber };
}

/** Account number or picked id -> accountId, version and currency. */
export function accountRef(context: HostContext, frame: Frame, name = 'account'): { accountId: string; version: number; number: string; currency: string; memberId: string } | Outcome {
  const found = findAccount(context, entered(frame, name));
  if (found === undefined) return fieldProblem(name, 'ACCOUNT NOT FOUND. TYPE A NUMBER OR F4 TO PICK.');
  const detail = readAccount(context, found.id);
  return { accountId: found.id, version: detail.account.version, number: found.accountNumber, currency: found.currency, memberId: detail.account.memberId };
}

/** Optional account ref: blank resolves to null. */
export function optAccountRef(context: HostContext, frame: Frame, name = 'account'): { accountId: string; version: number; number: string; currency: string; memberId: string } | null | Outcome {
  if (entered(frame, name) === '') return null;
  return accountRef(context, frame, name);
}

/** Case number or picked id -> caseId plus current version. */
export function caseRef(context: HostContext, frame: Frame, name = 'case'): { caseId: string; version: number; number: string } | Outcome {
  const found = findCase(context, entered(frame, name));
  if (found === undefined) return fieldProblem(name, 'CASE NOT FOUND. TYPE A NUMBER OR F4 TO PICK.');
  return { caseId: found.id, version: readCase(context, found.id).case.version, number: found.caseNumber };
}

/** A bare record id field verified through the shared record reader. */
export function recordRef(context: HostContext, frame: Frame, name: string, resource: FinanceRecordKind): { id: string; fingerprint: string; record: Record<string, unknown> } | Outcome {
  const id = entered(frame, name);
  if (id === '') return fieldProblem(name, 'ENTER THE RECORD OR F4 TO PICK.');
  const result = readRecord(context, resource, id);
  if ('code' in result) return fieldProblem(name, upper(result.message));
  return { id: result.id, fingerprint: result.fingerprint, record: result.record };
}

/** An optional record ref: blank resolves to null. */
export function optRecordRef(context: HostContext, frame: Frame, name: string, resource: FinanceRecordKind): { id: string; fingerprint: string; record: Record<string, unknown> } | null | Outcome {
  if (entered(frame, name) === '') return null;
  return recordRef(context, frame, name, resource);
}

/** The member's party id, needed by consent, preference and communication commands. */
export function partyRef(context: HostContext, frame: Frame, name = 'member'): { partyId: string; memberId: string; number: string } | Outcome {
  const member = memberRef(context, frame, name);
  if (isOutcome(member)) return member;
  const detail = readMember(context, member.memberId);
  return { partyId: detail.member.partyId, memberId: member.memberId, number: member.number };
}

/** Builds an address from a prefix group of fields; returns null when every part is blank. */
export function addressInput(_context: HostContext, frame: Frame, prefix: string, { required = false }: { required?: boolean } = {}): { line1: string; line2: string; city: string; region: string; postalCode: string; country: string } | null | Outcome {
  const read = (part: string) => entered(frame, `${prefix}${part}`);
  const blank = ['line1', 'line2', 'city', 'region', 'postal', 'country'].every((part) => read(part) === '');
  if (blank) return required ? fieldProblem(`${prefix}line1`, 'ENTER THE ADDRESS.') : null;
  for (const [part, label] of [['line1', 'ADDRESS LINE'], ['city', 'CITY'], ['region', 'REGION'], ['postal', 'POSTAL'], ['country', 'COUNTRY']] as const) {
    if (read(part) === '') return fieldProblem(`${prefix}${part}`, `ENTER ${label}.`);
  }
  return { line1: read('line1'), line2: read('line2'), city: read('city'), region: read('region'), postalCode: read('postal'), country: upper(read('country')) };
}
