import { randomBytes } from 'node:crypto';

import type { DatasetBinding } from '@computer-use/financial-database';
import {
  authorizeQuery, CAPABILITY_GRANTS, executeCommand, institutionSummary, operatorProfile, reviewCommand,
  type CommandKind, type FinancialStore, type InstitutionSummary, type ServiceContext, type WritePrincipal,
} from '@computer-use/financial-database/services';

import { hasForbiddenCharacter } from '../../shared/cells.js';
import { COLUMNS, type InputMessage, type ScreenPayload, type SessionOpened, type Severity, type Tone, type TransferOffer } from '../../shared/protocol.js';
import { moduleFor } from '../screens/index.js';
import { localDateTime } from './format.js';
import { failure, info, warning, type Frame, type Message } from './frames.js';
import type { DownloadFile, HostContext, InputEvent, Outcome, SignOn } from './module.js';
import type { InputBinding, ScreenBuilder } from './screen.js';

export const APPLICATION_ID = 'terminal-host-banking';
export const APPLICATION_VERSION = '0.1.0';
const MAX_SESSIONS = 200;
const MAX_TRANSFERS = 6;
const NUMERIC_VALUE = /^[0-9. -]*$/u;

export interface HostOptions {
  store: FinancialStore;
  bindings: readonly DatasetBinding[];
  /** Operators allowed to sign on. With `fixed`, the backend names exactly one and the terminal cannot change it. */
  operator: { actorNumbers: readonly string[]; fixed: boolean };
  /** Principal kind recorded with each write; evaluator runs normally use `automation`. */
  principalKind?: WritePrincipal['kind'];
}

/** A request the host refuses before touching any screen, answered as an HTTP error. */
export class HostError extends Error {
  constructor(readonly status: number, readonly code: string, message: string) {
    super(message);
  }
}

interface Session {
  id: string;
  stack: Frame[];
  sequence: number;
  signOn: SignOn | null;
  /** Unprotected fields of the last screen sent, by buffer address. */
  inputs: Map<number, InputBinding>;
  payload: ScreenPayload | null;
  pending: Message | null;
  transfers: Map<string, DownloadFile>;
  queue: Promise<unknown>;
  lastSeen: number;
}

const MESSAGE_TONES: Readonly<Record<Severity, Tone>> = { info: 'emphasis', success: 'success', warning: 'warning', error: 'error' };
const MORE_MESSAGE = ' (F1 MORE)';

function isCommandKind(value: string): value is CommandKind {
  return value in CAPABILITY_GRANTS;
}

/**
 * The host side of every terminal session.
 *
 * Each session owns a stack of frames and the screen it last sent. Input is processed one message
 * at a time per session and only when it answers the current screen's sequence, so a repeated
 * attention key or a reply to a replaced screen can never act twice or act on the wrong record.
 * Sessions hold presentation state only; closing one never touches the store or its run.
 */
export class TerminalHost {
  private readonly sessions = new Map<string, Session>();
  private readonly institutions: readonly { binding: DatasetBinding; summary: InstitutionSummary }[];

  constructor(private readonly options: HostOptions) {
    if (options.operator.actorNumbers.length === 0) throw new Error('At least one operator actor number is required.');
    if (options.operator.fixed && options.operator.actorNumbers.length !== 1) throw new Error('A fixed operator configuration names exactly one operator.');
    this.institutions = options.store.read((database) => options.bindings.map((binding) => {
      const summary = institutionSummary(database, binding.datasetId);
      if (summary.institutionId !== binding.institutionId) throw new Error(`Dataset ${binding.datasetId} does not belong to ${binding.institutionId}.`);
      return { binding, summary };
    }));
    if (this.institutions.length === 0) throw new Error('At least one institution binding is required.');
  }

  async open(): Promise<SessionOpened> {
    this.evict();
    const session: Session = {
      id: randomBytes(18).toString('base64url'), stack: [{ kind: 'signon', values: {} }], sequence: 0, signOn: null,
      inputs: new Map(), payload: null, pending: null, transfers: new Map(), queue: Promise.resolve(), lastSeen: Date.now(),
    };
    this.sessions.set(session.id, session);
    const screen = await this.serial(session, () => this.render(session));
    return { sessionId: session.id, screen };
  }

  /** The screen last sent, for a terminal that reconnects to its session. */
  async screen(sessionId: string): Promise<ScreenPayload> {
    const session = this.get(sessionId);
    return this.serial(session, async () => session.payload ?? this.render(session));
  }

  async input(sessionId: string, message: InputMessage): Promise<ScreenPayload> {
    const session = this.get(sessionId);
    return this.serial(session, () => this.process(session, message));
  }

  transfer(sessionId: string, token: string): DownloadFile | undefined {
    return this.get(sessionId).transfers.get(token);
  }

  /** Ends a terminal session. Business data, the store and any evaluator run are unaffected. */
  close(sessionId: string): boolean {
    return this.sessions.delete(sessionId);
  }

  private get(sessionId: string): Session {
    const session = this.sessions.get(sessionId);
    if (session === undefined) throw new HostError(404, 'unknown_session', 'The terminal session has ended. Reload the page to sign on again.');
    session.lastSeen = Date.now();
    return session;
  }

  private evict(): void {
    while (this.sessions.size >= MAX_SESSIONS) {
      const oldest = [...this.sessions.values()].sort((a, b) => a.lastSeen - b.lastSeen)[0];
      if (oldest === undefined) return;
      this.sessions.delete(oldest.id);
    }
  }

  private serial<T>(session: Session, task: () => Promise<T>): Promise<T> {
    const next = session.queue.then(task);
    session.queue = next.catch(() => undefined);
    return next;
  }

  private top(session: Session): Frame {
    const frame = session.stack.at(-1);
    if (frame === undefined) throw new Error('A terminal session has no screen.');
    return frame;
  }

  private async process(session: Session, message: InputMessage): Promise<ScreenPayload> {
    const current = session.payload;
    if (current === null) return this.render(session);
    if (message.sequence !== session.sequence) {
      return { ...current, message: { text: 'INPUT IGNORED: THE SCREEN CHANGED BEFORE YOUR INPUT ARRIVED. CHECK IT, THEN RETRY.', severity: 'warning' } };
    }
    // A transmission applies completely or not at all: on any failure the session returns to the
    // state that matches the screen last sent, so later input is never read against another screen.
    const stack = structuredClone(session.stack);
    const signOn = session.signOn;
    try {
      return await this.respond(session, current, message);
    } catch (error) {
      session.stack = stack;
      session.signOn = signOn;
      session.pending = null;
      throw error;
    }
  }

  private async respond(session: Session, current: ScreenPayload, message: InputMessage): Promise<ScreenPayload> {
    const frame = this.top(session);
    const modified = new Set<string>();
    const seen = new Set<number>();
    for (const field of message.fields) {
      const binding = session.inputs.get(field.address);
      if (binding === undefined || seen.has(field.address)) throw new HostError(400, 'invalid_field', `Screen ${current.screenId} has no input field at address ${field.address}.`);
      seen.add(field.address);
      if (hasForbiddenCharacter(field.value) || field.value.length > binding.capacity || (binding.numeric && !NUMERIC_VALUE.test(field.value))) {
        throw new HostError(400, 'invalid_field_data', `Data for input ${binding.name} does not fit its field definition.`);
      }
      frame.values[binding.name] = field.value;
      modified.add(binding.name);
    }
    const cursorAddress = message.cursor.row * COLUMNS + message.cursor.column;
    let cursorField: string | null = null;
    for (const [address, binding] of session.inputs) {
      if (cursorAddress >= address && cursorAddress < address + binding.length) cursorField = binding.name;
    }
    const armed = frame.discardArmed === true;
    frame.discardArmed = false;
    frame.error = undefined;
    const outcome = await this.dispatch(session, frame, { aid: message.aid, cursorField, modified }, armed);
    this.apply(session, outcome);
    return this.render(session);
  }

  private async dispatch(session: Session, frame: Frame, event: InputEvent, armed: boolean): Promise<Outcome> {
    const module = moduleFor(frame);
    const context = this.context(session);
    if (event.aid === 'pf1' && frame.kind !== 'help') {
      const shown = session.payload?.message?.text ?? '';
      return { kind: 'push', frame: { kind: 'help', topic: frame.kind, page: 1, values: {}, ...(shown.length > COLUMNS ? { message: shown } : {}) } };
    }
    if (event.aid === 'clear') {
      frame.values = {};
      return { kind: 'stay', message: info('SCREEN REDISPLAYED. ENTRIES NOT YET PROCESSED BY THE HOST WERE CLEARED.') };
    }
    if (event.aid === 'pf3' || event.aid === 'pf12') {
      if (module.exit !== undefined) return module.exit(context, frame, event.aid, armed);
      if (module.dirty?.(frame) === true && !armed) {
        return { kind: 'stay', armDiscard: true, message: warning(`CHANGES NOT APPLIED. PRESS ${event.aid === 'pf3' ? 'F3' : 'F12'} AGAIN TO DISCARD THEM, OR ENTER TO CONTINUE.`) };
      }
      if (session.stack.length <= 1) return { kind: 'stay' };
      return { kind: 'pop', ...(module.dirty?.(frame) === true ? { message: info('CHANGES DISCARDED. NOTHING WAS UPDATED.') } : {}) };
    }
    return module.input(context, frame, event);
  }

  private apply(session: Session, outcome: Outcome): void {
    const frame = this.top(session);
    switch (outcome.kind) {
      case 'stay':
        frame.cursor = outcome.cursor ?? outcome.error;
        frame.error = outcome.error;
        if (outcome.armDiscard === true) frame.discardArmed = true;
        break;
      case 'push':
        session.stack.push(outcome.frame);
        break;
      case 'replace':
        session.stack[session.stack.length - 1] = outcome.frame;
        break;
      case 'pop': {
        const count = Math.min(outcome.count ?? 1, session.stack.length - 1);
        session.stack.splice(session.stack.length - count, count);
        const next = this.top(session);
        if (outcome.values !== undefined) Object.assign(next.values, outcome.values);
        if (outcome.markConflict === true) next.conflict = true;
        if (outcome.error !== undefined) next.error = outcome.error;
        const cursor = outcome.cursor ?? outcome.error;
        if (cursor !== undefined) next.cursor = cursor;
        if (outcome.push !== undefined) session.stack.push(outcome.push);
        break;
      }
      case 'reset':
        session.stack = [...outcome.frames];
        break;
    }
    session.pending = outcome.message ?? null;
  }

  private async render(session: Session): Promise<ScreenPayload> {
    const frame = this.top(session);
    const builder = await moduleFor(frame).render(this.context(session), frame);
    this.chrome(builder, session);
    builder.markError(frame.error).cursor(frame.cursor ?? frame.error);
    frame.cursor = undefined;
    const built = builder.build();
    session.sequence += 1;
    session.inputs = built.inputs;
    const signOn = session.signOn;
    const payload: ScreenPayload = {
      sequence: session.sequence, screenId: built.screenId, title: built.title, fields: built.fields, cursor: built.cursor, message: session.pending,
      institution: signOn?.institution.displayName ?? null,
      operator: signOn === null ? null : `${signOn.operator.actorNumber} ${signOn.operator.displayName}`,
      transfer: frame.transfer ?? null,
    };
    session.pending = null;
    session.payload = payload;
    return payload;
  }

  /**
   * Header rows 1-2 and the message line (row 22) shared by every screen. A message longer than the
   * line is marked, as ISPF does, and F1 shows it whole; the payload always carries the full text.
   */
  private chrome(builder: ScreenBuilder, session: Session): void {
    builder.text(0, 0, builder.screenId, 'title');
    builder.data(0, 10, 52, builder.title.toLocaleUpperCase('en-US'), 'title');
    const signOn = session.signOn;
    if (signOn !== null) {
      builder.data(0, 64, 16, localDateTime(signOn.institution.asOf, signOn.institution.timeZone), 'label');
      builder.data(1, 0, 30, signOn.institution.displayName.toLocaleUpperCase('en-US'), 'emphasis');
      builder.data(1, 31, 30, `OPR ${signOn.operator.actorNumber} ${signOn.operator.displayName}`, 'label');
    }
    if (builder.page !== null) builder.data(1, 62, 18, builder.page.padStart(18), 'emphasis');
    if (session.pending !== null) {
      const { text } = session.pending;
      builder.data(21, 0, COLUMNS, text.length > COLUMNS ? `${text.slice(0, COLUMNS - MORE_MESSAGE.length)}${MORE_MESSAGE}` : text, MESSAGE_TONES[session.pending.severity]);
    }
  }

  private serviceContext(session: Session): ServiceContext {
    const signOn = this.requireSignOn(session);
    return { binding: signOn.binding, actorId: signOn.operator.actorId, principalKind: this.options.principalKind ?? 'human', reference: `${APPLICATION_ID}:${session.id.slice(0, 12)}` };
  }

  private requireSignOn(session: Session): SignOn {
    if (session.signOn === null) throw new Error('This screen requires a signed-on operator.');
    return session.signOn;
  }

  private context(session: Session): HostContext {
    const { store } = this.options;
    return {
      signOn: session.signOn,
      institutions: this.institutions.map((entry) => entry.summary),
      operatorChoices: this.options.operator.actorNumbers,
      operatorFixed: this.options.operator.fixed,
      session: () => this.requireSignOn(session),
      read: (query) => {
        const { binding } = this.requireSignOn(session);
        return store.read((database) => {
          const denied = authorizeQuery(database, this.serviceContext(session));
          if (denied !== null) throw new Error(denied.message);
          return query(database, binding.datasetId);
        });
      },
      svc: (call) => call(store, this.serviceContext(session)),
      review: (command) => reviewCommand(store, this.serviceContext(session), command),
      execute: (command, key) => executeCommand(store, this.serviceContext(session), command, key),
      offer: (file) => this.offer(session, file),
      signOnAs: (institutionId, actorNumber) => this.signOnAs(session, institutionId, actorNumber),
      signOff: () => {
        session.signOn = null;
        session.transfers.clear();
      },
    };
  }

  private signOnAs(session: Session, institutionId: string, actorNumber: string): Message | null {
    const entry = this.institutions.find((candidate) => candidate.summary.institutionId === institutionId);
    if (entry === undefined) return failure('SELECT ONE OF THE LISTED INSTITUTIONS.');
    if (!this.options.operator.actorNumbers.includes(actorNumber)) return failure(`OPERATOR ${actorNumber} IS NOT CONFIGURED FOR THIS TERMINAL.`);
    const profile = this.options.store.read((database) => operatorProfile(database, entry.binding.datasetId, entry.binding.institutionId, actorNumber));
    if (profile === undefined) return failure(`OPERATOR ${actorNumber} IS NOT REGISTERED AT ${entry.summary.displayName.toLocaleUpperCase('en-US')}.`);
    if (profile.status !== 'active') return failure(`OPERATOR ${actorNumber} IS ${profile.status.toLocaleUpperCase('en-US')} AND CANNOT SIGN ON.`);
    const commands = new Set<CommandKind>();
    for (const [kind, grants] of Object.entries(CAPABILITY_GRANTS)) {
      if (isCommandKind(kind) && grants.some((grant) => profile.permissions.includes(grant))) commands.add(kind);
    }
    session.signOn = {
      binding: entry.binding, institution: entry.summary,
      operator: { actorId: profile.actor.id, actorNumber: profile.actor.actorNumber, displayName: profile.actor.displayName, roles: profile.roles, commands },
    };
    return null;
  }

  private offer(session: Session, file: DownloadFile): TransferOffer {
    const token = randomBytes(18).toString('base64url');
    session.transfers.set(token, file);
    for (const key of session.transfers.keys()) {
      if (session.transfers.size <= MAX_TRANSFERS) break;
      session.transfers.delete(key);
    }
    return { url: `/api/sessions/${session.id}/transfers/${token}`, fileName: file.fileName, mediaType: file.mediaType, byteLength: file.bytes.byteLength, digest: file.digest };
  }
}
