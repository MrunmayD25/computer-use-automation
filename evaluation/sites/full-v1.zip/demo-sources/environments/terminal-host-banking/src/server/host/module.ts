import type { DatasetBinding } from '@computer-use/financial-database';
import type {
  CommandKind, CommandOutcome, FinancialStore, InstitutionSummary, ReviewOutcome, ServiceCommand, ServiceContext, SqlDatabase,
} from '@computer-use/financial-database/services';

import type { Aid, TransferOffer } from '../../shared/protocol.js';
import type { Frame, Message } from './frames.js';
import type { ScreenBuilder } from './screen.js';

export interface Operator {
  actorId: string;
  actorNumber: string;
  displayName: string;
  roles: readonly string[];
  /** Commands the shared grant table allows this operator at the signed-on institution. */
  commands: ReadonlySet<CommandKind>;
}

export interface SignOn {
  binding: DatasetBinding;
  institution: InstitutionSummary;
  operator: Operator;
}

export interface InputEvent {
  aid: Aid;
  /** Input field under the cursor when the key was pressed. */
  cursorField: string | null;
  /** Inputs the operator changed in this transmission. */
  modified: ReadonlySet<string>;
}

export type Outcome =
  | { kind: 'stay'; message?: Message; cursor?: string; error?: string; armDiscard?: boolean }
  | { kind: 'push'; frame: Frame; message?: Message }
  | { kind: 'replace'; frame: Frame; message?: Message }
  /**
   * Leaves `count` frames. `error` highlights an input on the screen returned to, `markConflict`
   * tells it that its record changed, `push` opens a new frame on top, such as a receipt, and
   * `values` merges picked entries into the revealed frame's draft, as a directory pick does.
   */
  | { kind: 'pop'; count?: number; message?: Message; cursor?: string; error?: string; markConflict?: boolean; push?: Frame; values?: Record<string, string> }
  | { kind: 'reset'; frames: Frame[]; message?: Message };

export interface DownloadFile {
  fileName: string;
  mediaType: string;
  bytes: Uint8Array;
  digest: string;
}

/** What a screen module may do: read current data, review and execute shared commands, offer files. */
export interface HostContext {
  readonly signOn: SignOn | null;
  readonly institutions: readonly InstitutionSummary[];
  readonly operatorChoices: readonly string[];
  readonly operatorFixed: boolean;
  /** Signed-on institution and operator; screens after sign-on may rely on it. */
  session(): SignOn;
  read<T>(query: (database: SqlDatabase, datasetId: string) => T): T;
  /** Runs a store-level service call (record snapshots, approvals, finance queries) for this session. */
  svc<T>(call: (store: FinancialStore, context: ServiceContext) => T): T;
  review(command: ServiceCommand): ReviewOutcome;
  execute(command: ServiceCommand, idempotencyKey: string): CommandOutcome;
  offer(file: DownloadFile): TransferOffer;
  signOnAs(institutionId: string, actorNumber: string): Message | null;
  signOff(): void;
}

export interface ScreenModule<F extends Frame> {
  render(context: HostContext, frame: F): ScreenBuilder | Promise<ScreenBuilder>;
  /** Handles an attention key. The host has already stored the transmitted fields in `frame.values`. */
  input(context: HostContext, frame: F, event: InputEvent): Outcome | Promise<Outcome>;
  /** True when leaving would discard edits the operator has entered. */
  dirty?(frame: F): boolean;
  /** Replaces the host's generic F3/F12 handling. */
  exit?(context: HostContext, frame: F, aid: 'pf3' | 'pf12', armed: boolean): Outcome;
  help: { title: string; lines: readonly string[] };
}
