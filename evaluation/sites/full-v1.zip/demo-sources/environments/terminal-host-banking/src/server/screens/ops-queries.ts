import {
  listMemberIdentityEvidence, queryCore, queryFinance, queryMemberMergePlan, searchMembers,
  type InstitutionSummary, type OperatorProfile,
} from '@computer-use/financial-database/services';

import { failure } from '../host/frames.js';
import { upper, wrap } from '../host/format.js';
import { cell, isOutcome, serviceContext } from './common.js';
import { HELP_TOPICS } from './help-text.js';
import { date, entered, fieldProblem, idList, instant, money, required, type OpSpec } from './ops.js';
import { dateField, instantField, moneyField, recordRef, textField } from './ops-common.js';

const help = HELP_TOPICS.qresult;

const dataLines = (data: Record<string, unknown>): string[] => wrap(JSON.stringify(data, null, 1), 76);

export const QUERY_OPS: Record<string, OpSpec> = {

  'member.identity.resolve': {
    id: 'member.identity.resolve', screenId: 'THIR10', title: 'Resolve member identity', command: null,
    fields: [
      textField('query', 'NAME OR NUMBER', 40, { hint: 'CANDIDATE CRITERIA' }),
      textField('fact', 'APPROVED FACT', 40, { required: false, hint: 'DISAMBIGUATING REFERENCE' }),
    ],
    run(context, frame) {
      const query = entered(frame, 'query');
      if (query === '') return fieldProblem('query', 'ENTER THE CANDIDATE NAME OR NUMBER.');
      const fact = entered(frame, 'fact');
      return context.read((database, datasetId) => {
        const candidates = searchMembers(database, datasetId, { query, limit: 20, offset: 0 });
        if (candidates.items.length === 0) {
          return { title: 'Identity resolution', lines: [`NO MATCHING RECORD FOR "${upper(query)}".`, 'THE RESOLUTION FAILS EXPLICITLY; NO MEMBER IS CHOSEN BY NAME ALONE.'] };
        }
        const scored = candidates.items.map((candidate) => {
          const evidence = listMemberIdentityEvidence(database, serviceContext(context, 'identity-resolve'), candidate.id);
          const rows = evidence.kind === 'authorized' ? evidence.value : [];
          const matched = fact === '' ? false : rows.some((item) => upper(`${item.sourceReference} ${item.kind}`).includes(upper(fact)));
          return { candidate, rows, matched };
        });
        const lines: string[] = [`${scored.length} CANDIDATE(S) FOR "${upper(query)}".`];
        scored.forEach(({ candidate, rows, matched }) => {
          lines.push('');
          lines.push(`${candidate.memberNumber}  ${candidate.displayName}  ${candidate.status}`);
          if (rows.length === 0) lines.push('  NO IDENTITY EVIDENCE ON FILE.');
          rows.forEach((item) => lines.push(`  ${item.kind} ${item.status} issued ${item.issuedAt.slice(0, 10)} ref ${item.sourceReference}${matched && upper(`${item.sourceReference} ${item.kind}`).includes(upper(fact)) ? '  <= MATCHES FACT' : ''}`));
        });
        const resolved = scored.filter((item) => item.matched);
        lines.push('');
        if (resolved.length === 1) lines.push(`RESOLVED: ${resolved[0]?.candidate.memberNumber ?? ''} IS THE EVIDENCED IDENTITY.`);
        else if (resolved.length === 0 && fact !== '') lines.push('AMBIGUOUS: NO CANDIDATE EVIDENCE MATCHES THE APPROVED FACT.');
        else if (scored.length === 1 && fact === '') lines.push(`SINGLE CANDIDATE ${scored[0]?.candidate.memberNumber ?? ''}; VERIFY AGAINST AN APPROVED FACT.`);
        else lines.push('AMBIGUOUS: SUPPLY AN APPROVED DISAMBIGUATING FACT TO CHOOSE.');
        return { title: `Identity resolution: ${upper(query)}`, lines };
      });
    },
    help,
  },

  'reconciliation.transfer': {
    id: 'reconciliation.transfer', screenId: 'THRC01', title: 'Reconcile transfer', command: null,
    fields: [
      { name: 'journal', label: 'TRANSFER JOURNAL', width: 40, pick: { dir: 'journals' }, hint: 'F4=PICK' },
    ],
    run(context, frame) {
      const journal = recordRef(context, frame, 'journal', 'transfer'); if (isOutcome(journal)) return journal;
      const result = context.svc((store, ctx) => queryFinance(store, ctx, { kind: 'reconciliation.transfer', transferJournalId: journal.id, expectedFingerprint: journal.fingerprint }));
      if (result.kind === 'rejected') return { kind: 'stay', message: failure(upper(result.message)), error: 'journal' };
      if (result.kind !== 'reconciled') return { kind: 'stay', message: failure('UNEXPECTED RESULT.') };
      return { title: `Transfer ${journal.id.slice(-16)} reconciled`, lines: dataLines(result.data) };
    },
    help,
  },

  'reconciliation.settlement_batch': {
    id: 'reconciliation.settlement_batch', screenId: 'THRC02', title: 'Reconcile settlement batch', command: null,
    fields: [
      { name: 'batch', label: 'SETTLEMENT BATCH', width: 40, pick: { dir: 'settlement-batches' }, hint: 'F4=PICK' },
      textField('digest', 'SETTLEMENT FILE DIGEST', 64, { capacity: 64 }),
      instantField('cutoff', 'CUTOFF'),
    ],
    run(context, frame) {
      const batch = recordRef(context, frame, 'batch', 'settlement-batch'); if (isOutcome(batch)) return batch;
      const digest = required(frame, 'digest', 'SETTLEMENT FILE DIGEST'); if (isOutcome(digest)) return digest;
      const cutoff = instant(frame, 'cutoff', 'CUTOFF'); if (isOutcome(cutoff) || cutoff === null) return cutoff ?? fieldProblem('cutoff', 'ENTER CUTOFF.');
      const result = context.svc((store, ctx) => queryFinance(store, ctx, { kind: 'reconciliation.settlement_batch', settlementBatchId: batch.id, expectedFingerprint: batch.fingerprint, settlementFileDigest: digest, cutoff }));
      if (result.kind === 'rejected') return { kind: 'stay', message: failure(upper(result.message)), error: 'batch' };
      if (result.kind !== 'reconciled') return { kind: 'stay', message: failure('UNEXPECTED RESULT.') };
      return { title: `Settlement batch ${batch.id.slice(-16)}`, lines: dataLines(result.data) };
    },
    help,
  },

  'reconciliation.cash_day': {
    id: 'reconciliation.cash_day', screenId: 'THRC03', title: 'Reconcile cash day', command: null,
    fields: [
      dateField('date', 'BUSINESS DATE'),
      textField('sessions', 'CASH SESSION IDS', 58, { kind: 'idlist', hint: 'SPACE-SEPARATED OR BLANK=ALL' }),
      moneyField('total', 'DECLARED TOTAL', { required: false }),
    ],
    run(context, frame) {
      const day = date(frame, 'date', 'BUSINESS DATE'); if (isOutcome(day) || day === null) return day ?? fieldProblem('date', 'ENTER BUSINESS DATE.');
      const sessions = idList(frame, 'sessions', 'CASH SESSION IDS'); if (!Array.isArray(sessions)) return sessions;
      const total = money(context, frame, 'total', 'DECLARED TOTAL'); if (isOutcome(total)) return total;
      const sessionIds = sessions.length === 0
        ? context.read((database, datasetId) => (database.prepare('SELECT id FROM cash_sessions WHERE dataset_id=? AND business_date=? ORDER BY id').all(datasetId, day) as { id: string }[]).map((r) => cell(r.id)))
        : sessions;
      const declared = total ?? (() => {
        const summed = context.read((database, datasetId) => database.prepare('SELECT currency,COALESCE(SUM(declared_minor_units),0) AS total FROM cash_declarations WHERE dataset_id=? AND cash_session_id IN (SELECT id FROM cash_sessions WHERE dataset_id=? AND business_date=?) GROUP BY currency').all(datasetId, datasetId, day) as { currency: string; total: number }[]);
        const first = summed[0];
        return first === undefined ? { minorUnits: 0, currency: 'USD' } : { minorUnits: first.total, currency: first.currency };
      })();
      const result = context.svc((store, ctx) => queryFinance(store, ctx, { kind: 'reconciliation.cash_day', businessDate: day, cashSessionIds: sessionIds, declaredTotal: declared }));
      if (result.kind === 'rejected') return { kind: 'stay', message: failure(upper(result.message)) };
      if (result.kind !== 'reconciled') return { kind: 'stay', message: failure('UNEXPECTED RESULT.') };
      return { title: `Cash day ${day}`, lines: dataLines(result.data) };
    },
    help,
  },

  'batch.preview': {
    id: 'batch.preview', screenId: 'THRC04', title: 'Preview batch', command: null,
    fields: [
      { name: 'batch', label: 'BATCH', width: 40, pick: { dir: 'batches' }, hint: 'F4=PICK' },
    ],
    run(context, frame) {
      const batch = recordRef(context, frame, 'batch', 'batch'); if (isOutcome(batch)) return batch;
      const digest = cell(batch.record.input_digest);
      const result = context.svc((store, ctx) => queryFinance(store, ctx, {
        kind: 'batch.preview', batchId: batch.id, expectedFingerprint: batch.fingerprint,
        inputDigest: digest, schemaVersion: '1', allowedMemberIds: [], allowedAccountIds: [],
      }));
      if (result.kind === 'rejected') return { kind: 'stay', message: failure(upper(result.message)), error: 'batch' };
      if (result.kind !== 'previewed') return { kind: 'stay', message: failure('UNEXPECTED RESULT.') };
      return { title: `Batch ${batch.id.slice(-16)} preview`, lines: dataLines(result.data) };
    },
    help,
  },

  'institution.context.verify': {
    id: 'institution.context.verify', screenId: 'THRC06', title: 'Verify institution context', command: null,
    fields: [],
    run(context) {
      const result = context.svc((store, ctx) => queryCore(store, ctx, { kind: 'institution.context.verify' }));
      if (result.kind === 'rejected') return { kind: 'stay', message: failure(upper(result.message)) };
      const value = result.value as { institution: InstitutionSummary; operator: OperatorProfile | undefined };
      const lines: string[] = [
        `INSTITUTION ${value.institution.displayName}  (${value.institution.institutionId})`,
        `LEGAL NAME ${value.institution.legalName}`,
        `TIME ZONE ${value.institution.timeZone}  CURRENCY ${value.institution.defaultCurrency}  AS OF ${value.institution.asOf.slice(0, 10)}`,
        '',
      ];
      const operator = value.operator;
      if (operator === undefined) lines.push('THE SIGNED-ON OPERATOR IS NOT REGISTERED AT THIS INSTITUTION.');
      else lines.push(
        `OPERATOR ${operator.actor.actorNumber}  ${operator.actor.displayName}  ${operator.status}`,
        `ROLES ${operator.roles.join(', ')}`,
        `GRANTS ${operator.permissions.join(', ')}`,
      );
      return { title: `Institution context: ${value.institution.displayName}`, lines };
    },
    help,
  },

  'member.merge.plan.inspect': {
    id: 'member.merge.plan.inspect', screenId: 'THRC05', title: 'Inspect merge plan', command: null,
    fields: [
      { name: 'plan', label: 'MERGE PLAN', width: 40, pick: { dir: 'merge-plans' }, hint: 'F4=PICK' },
    ],
    run(context, frame) {
      const plan = required(frame, 'plan', 'MERGE PLAN'); if (isOutcome(plan)) return plan;
      const result = context.svc((store, ctx) => queryMemberMergePlan(store, ctx, plan));
      if (result.kind !== 'found') return { kind: 'stay', message: failure(upper(result.message)), error: 'plan' };
      const lines: string[] = [
        `PLAN ${result.mergePlanId}  STATE ${upper(result.planState)}`,
        `SOURCE ${result.sourceMemberId}  ->  SURVIVOR ${result.targetMemberId}`,
        `INVENTORY ${result.rowCount} ROWS ACROSS ${result.tables.length} TABLES. FINGERPRINT ${result.fingerprint.slice(0, 24)}...`,
        '',
        'TABLES:',
        ...result.tables.map((table) => `  ${table.table.padEnd(28)} ${String(table.count).padStart(6)} rows  fp ${table.fingerprint.slice(0, 16)}`),
      ];
      if (Object.keys(result.decisions).length > 0) lines.push('', 'DECISIONS:', ...dataLines(result.decisions));
      return { title: `Merge plan ${plan.slice(-16)}`, lines };
    },
    help,
  },
};
