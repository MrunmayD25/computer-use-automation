import {
  LIMITS, type CommandKind, type FinanceCommand, type ServiceCommand, type ServicingCommand,
} from '@computer-use/financial-database/services';

import { COLUMNS } from '../../shared/protocol.js';

import { failure, info, type Frame, type FrameOf, type ReviewLine } from '../host/frames.js';
import { amount, isIsoDate, parseAmount, upper } from '../host/format.js';
import type { HostContext, Outcome, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { anyEntered, beginReview, currencyExponent, inactiveKey, label, value } from './common.js';
import { directoryFrame, directorySpec } from './dirs.js';
import type { HelpTopic } from './help-text.js';
import { OPS } from './ops-registry.js';

export type FieldKind = 'text' | 'upper' | 'num' | 'money' | 'smoney' | 'date' | 'instant' | 'flag' | 'code' | 'idlist' | 'group' | 'paragraph';

export interface OpColumn {
  name: string;
  label: string;
  width: number;
  kind?: 'text' | 'upper' | 'num' | 'flag' | 'code';
  codes?: Record<string, string>;
  pick?: { dir: string; scope?: Record<string, string> };
  capacity?: number;
}

export interface OpPick {
  dir: string;
  /** Maps directory scope names to form field names, '@op' for the command kind, or a literal. */
  scope?: Record<string, string>;
  /** When set, an existing pickable value in this field is replaced instead of appended. */
  replace?: boolean;
}

export interface OpField {
  name: string;
  label: string;
  width: number;
  kind?: FieldKind;
  capacity?: number;
  required?: boolean;
  codes?: Record<string, string>;
  hint?: string;
  pick?: OpPick;
  /** 'group': a repeated row of columns named `name.index.column`. */
  columns?: readonly OpColumn[];
  rows?: number;
  numeric?: boolean;
  /** Rows 1+ extra vertical space under this field. */
  gap?: number;
}

export interface BuiltOperation {
  command: ServiceCommand;
  lines: ReviewLine[];
  /** Long text shown in full on the review screen, such as the body being stored. */
  body?: string;
  /** Set when the build wants a transfer offer attached to the entry frame afterwards. */
  title?: string;
  screenId?: string;
}

export interface QueryOutcome {
  title: string;
  lines: string[];
}

export interface OpSpec {
  id: string;
  screenId: string;
  title: string;
  /** The shared command kind the form prepares, or null for a query-only form. */
  command: CommandKind | null;
  /** Default input values, such as the subject number the operator arrived from. */
  values?: Record<string, string>;
  fields: readonly OpField[];
  build?(context: HostContext, frame: FrameOf<'opform'>): BuiltOperation | Outcome;
  run?(context: HostContext, frame: FrameOf<'opform'>): QueryOutcome | Outcome;
  help: HelpTopic;
}

export function opSpec(op: string): OpSpec {
  const spec = OPS[op];
  if (spec === undefined) throw new Error(`No operation named ${op}.`);
  return spec;
}

export function opFrame(op: string, values: Record<string, string> = {}): FrameOf<'opform'> {
  const spec = opSpec(op);
  return { kind: 'opform', values: { ...spec.values, ...values }, op, page: 1 };
}

/* Typed value readers used by operation builds. Each returns an Outcome to show on the form. */

export const entered = (frame: Frame, name: string): string => value(frame, name).trim();

export function fieldProblem(field: string, text: string): Outcome {
  return { kind: 'stay', message: failure(text), error: field };
}

export function required(frame: Frame, name: string, label: string): string | Outcome {
  const text = entered(frame, name);
  return text === '' ? fieldProblem(name, `ENTER ${upper(label)}.`) : text;
}

export function text(frame: Frame, name: string, label: string, maximum: number, { required: must = true }: { required?: boolean } = {}): string | Outcome {
  const text = entered(frame, name);
  if (text === '') return must ? fieldProblem(name, `ENTER ${upper(label)}.`) : '';
  return text.length > maximum ? fieldProblem(name, `${upper(label)} MUST BE AT MOST ${maximum} CHARACTERS.`) : text;
}

export function flag(frame: Frame, name: string, label: string): boolean | Outcome {
  const text = upper(entered(frame, name));
  if (text === 'Y') return true;
  if (text === 'N' || text === '') return false;
  return fieldProblem(name, `ENTER Y OR N FOR ${upper(label)}.`);
}

export function code(frame: Frame, name: string, codes: Record<string, string>, label: string): string | Outcome {
  const text = upper(entered(frame, name));
  const mapped = codes[text];
  return mapped === undefined ? fieldProblem(name, `ENTER ${Object.keys(codes).join(' OR ')} FOR ${upper(label)}.`) : mapped;
}

export function optionalCode(frame: Frame, name: string, codes: Record<string, string>, label: string): string | null | Outcome {
  const text = upper(entered(frame, name));
  if (text === '') return null;
  const mapped = codes[text];
  return mapped === undefined ? fieldProblem(name, `ENTER ${Object.keys(codes).join(' OR ')} FOR ${upper(label)}.`) : mapped;
}

export function num(frame: Frame, name: string, label: string, { required: must = true, min = 0, max = Number.MAX_SAFE_INTEGER }: { required?: boolean; min?: number; max?: number } = {}): number | Outcome {
  const text = entered(frame, name);
  if (text === '') return must ? fieldProblem(name, `ENTER ${upper(label)}.`) : 0;
  if (!/^\d+$/u.test(text)) return fieldProblem(name, `ENTER ${upper(label)} AS WHOLE DIGITS.`);
  const value = Number(text);
  if (value < min || value > max) return fieldProblem(name, `${upper(label)} MUST BE BETWEEN ${min} AND ${max}.`);
  return value;
}

export function date(frame: Frame, name: string, label: string, { required: must = true }: { required?: boolean } = {}): string | null | Outcome {
  const text = entered(frame, name);
  if (text === '') return must ? fieldProblem(name, `ENTER ${upper(label)} AS YYYY-MM-DD.`) : null;
  return isIsoDate(text) ? text : fieldProblem(name, `ENTER ${upper(label)} AS YYYY-MM-DD.`);
}

const ISO_INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/u;

export function instant(frame: Frame, name: string, label: string, { required: must = true }: { required?: boolean } = {}): string | null | Outcome {
  const text = entered(frame, name);
  if (text === '') return must ? fieldProblem(name, `ENTER ${upper(label)} AS AN ISO UTC INSTANT.`) : null;
  return ISO_INSTANT.test(text) && !Number.isNaN(Date.parse(text)) ? new Date(text).toISOString() : fieldProblem(name, `ENTER ${upper(label)} AS AN ISO UTC INSTANT SUCH AS 2026-09-30T00:00:00Z.`);
}

/** An amount entered in its own currency field pair: `name` is the figure, `name.ccy` the code. */
export function money(context: HostContext, frame: Frame, name: string, label: string, { signed = false, required: must = true, defaultCcy = '' }: { signed?: boolean; required?: boolean; defaultCcy?: string } = {}): { minorUnits: number; currency: string } | null | Outcome {
  const currency = upper(entered(frame, `${name}.ccy`) || defaultCcy);
  const text = entered(frame, name);
  if (text === '') return must ? fieldProblem(name, `ENTER ${upper(label)}.`) : null;
  if (currency === '') return fieldProblem(`${name}.ccy`, 'ENTER THE CURRENCY CODE.');
  const exponent = currencyExponent(context, currency);
  if (exponent === undefined) return fieldProblem(`${name}.ccy`, `CURRENCY ${currency.slice(0, 3)} IS NOT SUPPORTED.`);
  const parsed = parseAmount(text, exponent);
  if ('problem' in parsed) return fieldProblem(name, parsed.problem);
  if (!signed && parsed.minorUnits <= 0) return fieldProblem(name, `${upper(label)} MUST BE GREATER THAN ZERO.`);
  return { minorUnits: parsed.minorUnits, currency };
}

/** Space or comma separated record ids; never guesses or prefixes a partial id. */
export function idList(frame: Frame, name: string, label: string, { required: must = false, max = 100 }: { required?: boolean; max?: number } = {}): string[] | Outcome {
  const text = entered(frame, name);
  const items = text === '' ? [] : text.split(/[\s,]+/u).filter((item) => item !== '');
  if (must && items.length === 0) return fieldProblem(name, `ENTER ${upper(label)}.`);
  if (items.length > max) return fieldProblem(name, `${upper(label)} ACCEPTS AT MOST ${max} ENTRIES.`);
  return items;
}

/** Reads a repeated group: rows with all-blank columns are skipped. */
export function groupRows<T>(frame: Frame, name: string, rows: number, read: (index: number, value: (column: string) => string) => T | Outcome | null): T[] | Outcome {
  const result: T[] = [];
  for (let index = 0; index < rows; index += 1) {
    const readValue = (column: string): string => entered(frame, `${name}.${index}.${column}`);
    const item = read(index, readValue);
    if (item !== null && typeof item === 'object' && 'kind' in item) return item;
    if (item !== null) result.push(item);
  }
  return result;
}

/* The generic form. Fields pack top-down; a field that would cross row 19 starts a new page. */

const FORM_TOP = 4;
const FORM_BOTTOM = 19;

interface PlacedField { field: OpField; row: number; height: number }

function fieldHeight(field: OpField): number {
  if (field.kind === 'group') return 2 + (field.rows ?? 3);
  // Inputs begin at column 21. A wide field continues on the next terminal
  // row, so reserve those rows during layout or the following label can draw
  // over its wrapped cells (and the host correctly rejects the screen).
  const inputCells = field.kind === 'paragraph' ? 59 : field.width;
  const wrappedRows = Math.max(1, Math.ceil((21 + inputCells) / 80));
  return wrappedRows + (field.gap ?? 0);
}

function layout(spec: OpSpec): PlacedField[][] {
  const pages: PlacedField[][] = [[]];
  let row = FORM_TOP;
  for (const field of spec.fields) {
    const height = fieldHeight(field);
    const last = pages[pages.length - 1] ?? [];
    if (row + height > FORM_BOTTOM + 1 && last.length > 0) {
      pages.push([]);
      row = FORM_TOP;
    }
    (pages[pages.length - 1] ?? []).push({ field, row, height });
    row += height;
  }
  return pages;
}

function fieldNames(spec: OpSpec): string[] {
  return spec.fields.flatMap((field) => {
    if (field.kind === 'group') {
      return Array.from({ length: field.rows ?? 3 }, (_, index) => (field.columns ?? []).map((column) => `${field.name}.${index}.${column.name}`)).flat();
    }
    if (field.kind === 'money' || field.kind === 'smoney') return [field.name, `${field.name}.ccy`];
    return [field.name];
  });
}

function pickFor(spec: OpSpec, cursorField: string): { pick: OpPick } | null {
  for (const field of spec.fields) {
    if (field.kind === 'group') {
      for (const column of field.columns ?? []) {
        if (cursorField.startsWith(`${field.name}.`) && cursorField.endsWith(`.${column.name}`) && column.pick !== undefined) return { pick: column.pick };
      }
    } else if (field.name === cursorField && field.pick !== undefined) return { pick: field.pick };
  }
  return null;
}

function pickScope(spec: OpSpec, frame: FrameOf<'opform'>, pick: OpPick): Record<string, string> {
  const scope: Record<string, string> = {};
  for (const [name, source] of Object.entries(pick.scope ?? {})) {
    if (source === '@op') scope[name] = spec.command ?? '';
    else if (source.startsWith('@')) scope[name] = source.slice(1);
    else scope[name] = entered(frame, source);
  }
  return scope;
}

export const opFormScreen: ScreenModule<FrameOf<'opform'>> = {
  render(_context, frame) {
    const spec = opSpec(frame.op);
    const builder = new ScreenBuilder(spec.screenId, spec.title);
    const pages = layout(spec);
    if (pages.length > 1) builder.page = `PAGE ${frame.page} OF ${pages.length}`;
    builder.text(2, 1, spec.command === null ? 'INQUIRY. NO CHANGE IS STORED.' : `OPERATION ${spec.command}`, 'label');
    const placed = pages[Math.min(frame.page, pages.length) - 1] ?? [];
    for (const { field, row } of placed) {
      if (field.kind === 'group') {
        builder.text(row, 1, upper(field.label), 'emphasis');
        let column = 1;
        for (const cell of field.columns ?? []) {
          builder.text(row + 1, column, cell.label, 'label');
          for (let index = 0; index < (field.rows ?? 3); index += 1) {
            const name = `${field.name}.${index}.${cell.name}`;
            builder.input(name, row + 2 + index, column, cell.width, value(frame, name), { ...(cell.capacity === undefined ? {} : { capacity: cell.capacity }), numeric: cell.kind === 'num' });
          }
          column += cell.width + 2;
        }
        continue;
      }
      label(builder, row, 1, field.label, 19);
      if (field.kind === 'money' || field.kind === 'smoney') {
        builder.input(field.name, row, 21, field.width, value(frame, field.name), { numeric: true });
        builder.text(row, 21 + field.width + 1, 'CUR', 'label').input(`${field.name}.ccy`, row, 21 + field.width + 5, 3, value(frame, `${field.name}.ccy`));
      } else if (field.kind === 'paragraph') {
        builder.input(field.name, row, 21, 59, value(frame, field.name), { capacity: field.capacity ?? LIMITS.noteLength });
      } else {
        builder.input(field.name, row, 21, field.width, value(frame, field.name), { ...(field.capacity === undefined ? {} : { capacity: field.capacity }), numeric: field.kind === 'num' || field.numeric === true });
      }
      const picked = value(frame, `${field.name}.label`);
      const hintParts = [field.hint ?? '', field.pick !== undefined ? 'F4=PICK' : ''];
      const hintAt = 21 + (field.kind === 'money' || field.kind === 'smoney' ? field.width + 9 : field.width) + 1;
      const remaining = COLUMNS - hintAt;
      if (remaining > 0 && picked !== '') builder.data(row, hintAt, remaining, picked, 'emphasis');
      else if (remaining > 0 && hintParts.some((hint) => hint !== '')) builder.data(row, hintAt, remaining, hintParts.filter((hint) => hint !== '').join('  '), 'label');
      else if (remaining > 0 && field.codes !== undefined) builder.data(row, hintAt, remaining, Object.entries(field.codes).map(([letter, word]) => `${letter}=${upper(word)}`).join(' '), 'label');
    }
    if (frame.page < pages.length) builder.text(20, 1, 'F8 CONTINUES THIS FORM.', 'emphasis');
    return builder.legend('ENTER=Send  F1=Help  F3=Return  F7=Up  F8=Down  F12=Cancel');
  },
  input(context, frame, event) {
    const spec = opSpec(frame.op);
    const pages = layout(spec).length;
    if (event.aid === 'pf7') {
      if (frame.page <= 1) return { kind: 'stay', message: info('ALREADY AT THE FIRST PAGE.') };
      frame.page -= 1;
      return { kind: 'stay' };
    }
    if (event.aid === 'pf8') {
      if (frame.page >= pages) return { kind: 'stay', message: info('ALREADY AT THE LAST PAGE.') };
      frame.page += 1;
      return { kind: 'stay' };
    }
    if (event.aid === 'pf4') {
      const found = event.cursorField === null ? null : pickFor(spec, event.cursorField);
      if (found === null) return { kind: 'stay', message: failure('PUT THE CURSOR ON A FIELD WITH A PICK DIRECTORY (MARKED F4).') };
      const scope = pickScope(spec, frame, found.pick);
      const resolved: Record<string, string> = {};
      for (const field of directorySpec(found.pick.dir).scope) {
        const text = scope[field.name] ?? '';
        if (text === '') continue;
        const result = field.resolve(context, text);
        if ('kind' in result) {
          if (result.kind !== 'stay') return result;
          const error = result.error ?? event.cursorField;
          return error === null ? result : { ...result, error };
        }
        resolved[field.name] = result.id;
        resolved[`${field.name}.label`] = result.label;
      }
      return { kind: 'push', frame: directoryFrame(found.pick.dir, resolved, event.cursorField) };
    }
    if (event.aid !== 'enter') return inactiveKey();
    if (spec.run !== undefined) {
      const result = spec.run(context, frame);
      if ('kind' in result) return result;
      return { kind: 'push', frame: { kind: 'qresult', values: {}, title: result.title, lines: result.lines, page: 1 } };
    }
    if (spec.build === undefined) return inactiveKey();
    const built = spec.build(context, frame);
    if ('kind' in built) return built;
    const command = built.command;
    if ('approvalId' in command && command.approvalId === '') {
      const target = command as ServicingCommand | FinanceCommand;
      return { kind: 'push', frame: { kind: 'approval-request', values: {}, command: target, lines: built.lines } };
    }
    return beginReview(context, frame, {
      command, screenId: built.screenId ?? 'THRV01', title: built.title ?? `Review ${spec.title}`, lines: built.lines, fields: {}, ...(built.body === undefined ? {} : { body: built.body }),
    });
  },
  dirty: (frame) => anyEntered(frame, fieldNames(opSpec(frame.op))),
  help: { title: 'Operation', lines: ['OPERATION', 'Fill the fields and press Enter for a review; nothing changes until you confirm.', 'F4 on a marked field opens a directory to pick the record. F7/F8 page long forms.'] },
};

/* Shared message helpers for builds. */

export function moneyLabel(minorUnits: number, currency: string, exponent: number): string {
  return `${amount(minorUnits, currency, exponent)} ${currency}`;
}

export function lines(pairs: readonly (readonly [string, string])[]): ReviewLine[] {
  return pairs.map(([label, after]) => ({ label, before: '', after }));
}
