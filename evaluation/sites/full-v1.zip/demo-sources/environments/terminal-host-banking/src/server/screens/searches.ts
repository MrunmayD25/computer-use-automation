import {
  LIMITS, listSavedSearches, referenceData, SAVED_SEARCH_ENTITIES, savedSearchForActor, searchAccounts, searchCases, searchMembers,
  type AccountRow, type CaseRow, type MemberRow, type ReferenceData, type SavedSearchDefinition, type SavedSearchEntity, type SavedSearchFilterValue,
  type SavedSearchRow, type ServiceCommand,
} from '@computer-use/financial-database/services';

import { failure, info, type Draft, type Frame, type FrameOf, type ReviewLine, type SearchHit } from '../host/frames.js';
import { column, localDate, upper, wrap } from '../host/format.js';
import type { HostContext, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { PRIORITY_CODES, STATE_CODES, stateCode, stateLabel } from './cases.js';
import {
  accountFrame, badSelection, beginReview, caseFrame, clampOffset, differs, inactiveKey, label, LIST_ROWS, LIST_TOP, memberFrame, page, pageLabel, rowsLabel, selection, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';

const ENTITY_CODES: Readonly<Record<string, SavedSearchEntity>> = { M: 'members', A: 'accounts', C: 'cases' };
const entityCode = (entity: SavedSearchEntity): string => entity.charAt(0).toUpperCase();

function reference(context: HostContext): ReferenceData {
  const { institution } = context.session();
  return context.read((database, datasetId) => referenceData(database, datasetId, institution.institutionId));
}

function readSearch(context: HostContext, searchId: string): SavedSearchRow | undefined {
  const { operator } = context.session();
  return context.read((database, datasetId) => savedSearchForActor(database, datasetId, operator.actorId, searchId));
}

/* Result columns. Each stored column name of the shared vocabulary has a heading, width and cell. */

interface Column<R> {
  heading: string;
  width: number;
  cell: (row: R, timeZone: string) => string;
}

const MEMBER_COLUMNS: Readonly<Record<string, Column<MemberRow>>> = {
  member_number: { heading: 'MEMBER', width: 8, cell: (row) => row.memberNumber },
  display_name: { heading: 'NAME', width: 24, cell: (row) => row.displayName },
  kind: { heading: 'KIND', width: 12, cell: (row) => upper(row.kind) },
  status: { heading: 'STATUS', width: 8, cell: (row) => upper(row.status) },
  email: { heading: 'EMAIL', width: 26, cell: (row) => row.email ?? '' },
  phone: { heading: 'PHONE', width: 16, cell: (row) => row.phone ?? '' },
  open_accounts: { heading: 'OPEN', width: 4, cell: (row) => String(row.openAccounts).padStart(4) },
  joined_at: { heading: 'JOINED', width: 10, cell: (row, zone) => localDate(row.joinedAt, zone) },
  version: { heading: 'VER', width: 4, cell: (row) => String(row.version).padStart(4) },
};

const ACCOUNT_COLUMNS: Readonly<Record<string, Column<AccountRow>>> = {
  account_number: { heading: 'ACCOUNT', width: 10, cell: (row) => row.accountNumber },
  member_number: { heading: 'MEMBER', width: 8, cell: (row) => row.memberNumber },
  owner_name: { heading: 'OWNER', width: 22, cell: (row) => row.ownerName },
  product_code: { heading: 'PRODUCT', width: 13, cell: (row) => row.productCode },
  product_name: { heading: 'PRODUCT NAME', width: 22, cell: (row) => row.productName },
  currency: { heading: 'CUR', width: 3, cell: (row) => row.currency },
  status: { heading: 'STATUS', width: 8, cell: (row) => upper(row.status) },
  nickname: { heading: 'NICKNAME', width: 18, cell: (row) => row.nickname },
  statement_delivery: { heading: 'DELIVERY', width: 10, cell: (row) => upper(row.statementDelivery) },
  posted_minor_units: { heading: 'POSTED'.padStart(16), width: 16, cell: (row) => column(row.postedMinorUnits, row.currency, row.exponent, 16) },
  available_minor_units: { heading: 'AVAILABLE'.padStart(16), width: 16, cell: (row) => column(row.availableMinorUnits, row.currency, row.exponent, 16) },
  opened_at: { heading: 'OPENED', width: 10, cell: (row, zone) => localDate(row.openedAt, zone) },
  closed_at: { heading: 'CLOSED', width: 10, cell: (row, zone) => row.closedAt === null ? '' : localDate(row.closedAt, zone) },
  version: { heading: 'VER', width: 4, cell: (row) => String(row.version).padStart(4) },
};

const CASE_COLUMNS: Readonly<Record<string, Column<CaseRow>>> = {
  case_number: { heading: 'CASE', width: 8, cell: (row) => row.caseNumber },
  member_number: { heading: 'MEMBER', width: 8, cell: (row) => row.memberNumber },
  member_name: { heading: 'MEMBER NAME', width: 22, cell: (row) => row.memberName },
  account_number: { heading: 'ACCOUNT', width: 10, cell: (row) => row.accountNumber ?? '' },
  queue_code: { heading: 'QUEUE', width: 10, cell: (row) => row.queueCode },
  assigned_name: { heading: 'ASSIGNED', width: 18, cell: (row) => row.assignedName ?? '' },
  state: { heading: 'STATE', width: 9, cell: (row) => stateLabel(row.state) },
  priority: { heading: 'PRIORITY', width: 8, cell: (row) => upper(row.priority) },
  category: { heading: 'CATEGORY', width: 19, cell: (row) => row.category },
  summary: { heading: 'SUMMARY', width: 30, cell: (row) => row.summary },
  opened_at: { heading: 'OPENED', width: 10, cell: (row, zone) => localDate(row.openedAt, zone) },
  due_at: { heading: 'DUE', width: 10, cell: (row, zone) => localDate(row.dueAt, zone) },
  overdue: { heading: 'OVR', width: 3, cell: (row) => row.overdue ? 'YES' : '' },
  version: { heading: 'VER', width: 4, cell: (row) => String(row.version).padStart(4) },
};

const DEFAULT_COLUMNS: Readonly<Record<SavedSearchEntity, readonly string[]>> = {
  members: ['member_number', 'display_name', 'status', 'email'],
  accounts: ['account_number', 'owner_name', 'currency', 'status', 'posted_minor_units'],
  cases: ['case_number', 'member_number', 'queue_code', 'state', 'due_at', 'summary'],
};

interface ResultPage {
  total: number;
  headings: { heading: string; width: number }[];
  hits: SearchHit[];
  cells: string[][];
}

function tabulate<R extends { id: string }>(
  result: { items: readonly R[]; total: number }, kind: SearchHit['kind'], specs: Readonly<Record<string, Column<R>>>, columns: readonly string[], timeZone: string,
): ResultPage {
  const chosen = columns.flatMap((name) => { const spec = specs[name]; return spec === undefined ? [] : [spec]; });
  return {
    total: result.total, headings: chosen.map(({ heading, width }) => ({ heading, width })),
    hits: result.items.map((row) => ({ kind, id: row.id })), cells: result.items.map((row) => chosen.map((spec) => spec.cell(row, timeZone))),
  };
}

const text = (filters: SavedSearchDefinition['filters'], key: string): string | undefined => { const stored = filters[key]; return typeof stored === 'string' ? stored : undefined; };
const list = (filters: SavedSearchDefinition['filters'], key: string): readonly string[] | undefined => { const stored = filters[key]; return Array.isArray(stored) ? stored : undefined; };

/** Runs a stored definition through the shared list query of its entity, with its sort and columns. */
function runDefinition(context: HostContext, definition: SavedSearchDefinition, offset: number, limit: number): ResultPage {
  const { timeZone } = context.session().institution;
  const { filters } = definition;
  const [sort] = definition.sort;
  const key = sort === undefined ? undefined : SAVED_SEARCH_ENTITIES[definition.entity].sorts[sort.field];
  const order = sort === undefined || key === undefined ? {} : { sort: key, direction: sort.direction };
  const query = text(filters, 'query');
  const common = { ...(query === undefined ? {} : { query }), ...order, limit, offset };
  switch (definition.entity) {
    case 'members': {
      const status = text(filters, 'status');
      const result = context.read((database, datasetId) => searchMembers(database, datasetId, { ...common, ...(status === undefined ? {} : { status }) }));
      return tabulate(result, 'member', MEMBER_COLUMNS, definition.columns, timeZone);
    }
    case 'accounts': {
      const status = text(filters, 'status');
      const currency = text(filters, 'currency');
      const result = context.read((database, datasetId) => searchAccounts(database, datasetId, {
        ...common, ...(status === undefined ? {} : { status }), ...(currency === undefined ? {} : { currency }),
      }));
      return tabulate(result, 'account', ACCOUNT_COLUMNS, definition.columns, timeZone);
    }
    case 'cases': {
      const states = list(filters, 'states');
      const queueIds = list(filters, 'queueIds');
      const priority = text(filters, 'priority');
      const assignedActorId = text(filters, 'assignedActorId');
      const result = context.read((database, datasetId) => searchCases(database, datasetId, {
        ...common, ...(states === undefined ? {} : { states }), ...(queueIds === undefined ? {} : { queueIds }), ...(priority === undefined ? {} : { priority }),
        ...(assignedActorId === undefined ? {} : { assignedActorId }), ...(filters.overdue === true ? { overdue: true } : {}),
      }));
      return tabulate(result, 'case', CASE_COLUMNS, definition.columns, timeZone);
    }
  }
}

function describeFilters(definition: SavedSearchDefinition, data: ReferenceData): string {
  const parts = Object.entries(definition.filters).map(([key, stored]) => `${key}=${filterText(key, stored, data)}`);
  return parts.length === 0 ? 'NO FILTERS: EVERY RECORD' : parts.join('  ');
}

export const searchesFrame = (): Frame => ({ kind: 'searches', values: {}, offset: 0, total: 0, rows: [] });

export const searchesScreen: ScreenModule<FrameOf<'searches'>> = {
  render(context, frame) {
    const { operator } = context.session();
    const all = context.read((database, datasetId) => listSavedSearches(database, datasetId, operator.actorId));
    frame.offset = clampOffset(frame.offset, LIST_ROWS, all.length);
    const shown = all.slice(frame.offset, frame.offset + LIST_ROWS);
    frame.rows = shown.map((row) => row.id);
    frame.total = all.length;
    const builder = new ScreenBuilder('THSS01', 'Saved searches');
    builder.page = pageLabel(frame.offset, LIST_ROWS, all.length);
    builder.text(3, 1, 'YOUR SEARCHES FIRST, THEN SEARCHES OTHER OPERATORS SHARED.', 'label');
    for (const [at, heading] of [[1, 'S'], [3, 'NAME'], [40, 'RECORDS'], [49, 'VISIBILITY'], [60, 'OWNER'], [68, 'COLUMNS']] as const) builder.text(6, at, heading, 'label');
    shown.forEach((row, index) => {
      const line = LIST_TOP + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 36, row.name).data(line, 40, 8, upper(row.definition?.entity ?? 'INVALID'), row.definition === null ? 'warning' : 'data')
        .data(line, 49, 10, upper(row.visibility), 'label').data(line, 60, 7, row.mine ? 'YOU' : row.owner.actorNumber).data(line, 68, 11, String(row.definition?.columns.length ?? 0).padStart(3), 'label');
    });
    if (all.length === 0) builder.text(LIST_TOP, 3, 'NO SAVED SEARCHES. F6 CREATES ONE.', 'warning');
    builder.text(19, 1, 'SEL: R=RUN  M=MODIFY  D=DELETE', 'label');
    builder.data(20, 1, 40, rowsLabel(frame.offset, shown.length, all.length), 'label');
    return builder.legend('ENTER=Select  F1=Help  F3=Return  F6=New search  F7=Up  F8=Down');
  },
  input(context, frame, event) {
    if (event.aid === 'pf6') return { kind: 'push', frame: editFrame(context, null) };
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE R, M OR D BESIDE A SAVED SEARCH, OR F6 FOR A NEW ONE.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const searchId = frame.rows[picked.index];
    const row = searchId === undefined ? undefined : readSearch(context, searchId);
    if (row === undefined) return { kind: 'stay', message: failure('THAT SAVED SEARCH NO LONGER EXISTS OR IS NO LONGER SHARED.'), error: `sel.${picked.index}` };
    frame.cursor = `sel.${picked.index}`;
    switch (picked.code) {
      case 'R':
        if (row.definition === null) return { kind: 'stay', message: failure(`THIS SEARCH CANNOT RUN: ${upper(row.problem ?? 'INVALID DEFINITION')}`), error: `sel.${picked.index}` };
        return { kind: 'push', frame: { kind: 'search-results', values: {}, searchId: row.id, offset: 0, column: 0, total: 0, hits: [] } };
      case 'M':
        if (row.definition === null) return { kind: 'stay', message: failure('THIS SEARCH HAS AN INVALID DEFINITION; DELETE IT AND SAVE A NEW ONE.'), error: `sel.${picked.index}` };
        return { kind: 'push', frame: editFrame(context, row) };
      case 'D':
        return beginReview(context, frame, {
          command: { kind: 'search.saved.delete', searchId: row.id, expectedRevision: row.revision },
          screenId: 'THSS05', title: 'Review search deletion',
          lines: [{ label: 'Name', before: row.name, after: '(DELETED)' }, { label: 'Records', before: upper(row.definition?.entity ?? 'INVALID'), after: '' }, { label: 'Visibility', before: upper(row.visibility), after: '' }],
          fields: {},
        });
      default: return badSelection(picked.code, 'R, M OR D', picked.index);
    }
  },
  help: HELP_TOPICS.searches,
};

/** Columns from `start` that fit beside the selection column. */
function columnWindow(headings: ResultPage['headings'], start: number): number[] {
  const indexes: number[] = [];
  let used = 0;
  for (let index = start; index < headings.length; index += 1) {
    const width = headings[index]?.width ?? 0;
    if (indexes.length > 0 && used + width > 76) break;
    indexes.push(index);
    used += width + 1;
  }
  return indexes;
}

export const searchResultsScreen: ScreenModule<FrameOf<'search-results'>> = {
  render(context, frame) {
    const row = readSearch(context, frame.searchId);
    const builder = new ScreenBuilder('THSS02', 'Saved search results');
    if (row?.definition === undefined || row.definition === null) {
      frame.hits = [];
      builder.text(4, 1, 'THIS SAVED SEARCH NO LONGER EXISTS, IS NO LONGER SHARED, OR CANNOT RUN.', 'warning');
      return builder.legend('F1=Help  F3=Return');
    }
    const { definition } = row;
    const cap = definition.maxResults ?? Number.MAX_SAFE_INTEGER;
    let result = runDefinition(context, definition, frame.offset, Math.max(1, Math.min(LIST_ROWS, cap - frame.offset)));
    const total = Math.min(result.total, cap);
    const clamped = clampOffset(frame.offset, LIST_ROWS, total);
    if (clamped !== frame.offset) {
      frame.offset = clamped;
      result = runDefinition(context, definition, clamped, Math.max(1, Math.min(LIST_ROWS, cap - clamped)));
    }
    const count = Math.max(0, Math.min(result.hits.length, total - frame.offset));
    frame.hits = result.hits.slice(0, count);
    frame.total = total;
    frame.column = Math.min(frame.column, Math.max(0, result.headings.length - 1));
    builder.page = pageLabel(frame.offset, LIST_ROWS, total);
    label(builder, 3, 1, 'Search', 8).data(3, 9, 40, row.name, 'emphasis').data(3, 50, 29, `${upper(definition.entity)} ${upper(row.visibility)} ${row.mine ? 'YOURS' : row.owner.actorNumber}`, 'label');
    builder.data(4, 1, 78, describeFilters(definition, reference(context)), 'label');
    const shown = columnWindow(result.headings, frame.column);
    builder.text(6, 1, 'S', 'label');
    let at = 3;
    const positions = shown.map((index) => { const start = at; at += (result.headings[index]?.width ?? 0) + 1; return start; });
    shown.forEach((index, position) => { const heading = result.headings[index]; if (heading !== undefined) builder.data(6, positions[position] ?? 3, heading.width, heading.heading, 'label'); });
    frame.hits.forEach((_, line) => {
      builder.input(`sel.${line}`, LIST_TOP + line, 1, 1, value(frame, `sel.${line}`));
      shown.forEach((index, position) => builder.data(LIST_TOP + line, positions[position] ?? 3, result.headings[index]?.width ?? 1, result.cells[line]?.[index] ?? ''));
    });
    if (total === 0) builder.text(LIST_TOP, 3, 'NO RECORDS MATCH THIS SEARCH.', 'warning');
    builder.text(19, 1, 'SEL: S=OPEN RECORD', 'label');
    const first = shown[0] ?? 0;
    const last = shown.at(-1) ?? 0;
    builder.data(20, 1, 78, `${rowsLabel(frame.offset, frame.hits.length, total)}${definition.maxResults === undefined ? '' : ` (LIMIT ${definition.maxResults})`}   COLUMNS ${first + 1}-${last + 1} OF ${result.headings.length}`, 'label');
    return builder.legend('ENTER=Select  F1=Help  F3=Return  F7=Up  F8=Down  F10=Left  F11=Right');
  },
  input(_context, frame, event) {
    if (event.aid === 'pf10') {
      if (frame.column === 0) return { kind: 'stay', message: info('ALREADY AT THE FIRST COLUMN.') };
      frame.column -= 1;
      return { kind: 'stay' };
    }
    if (event.aid === 'pf11') {
      frame.column += 1;
      return { kind: 'stay' };
    }
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    const picked = selection(frame, frame.hits.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE S BESIDE A RECORD TO OPEN IT.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const hit = frame.hits[picked.index];
    if (picked.code !== 'S' || hit === undefined) return badSelection(picked.code, 'S', picked.index);
    frame.cursor = `sel.${picked.index}`;
    return { kind: 'push', frame: hit.kind === 'member' ? memberFrame(hit.id) : hit.kind === 'account' ? accountFrame(hit.id) : caseFrame(hit.id) };
  },
  help: HELP_TOPICS['search-results'],
};

/* The editor. Filters are typed in terminal notation: case states and priorities as codes, queues as codes, assignees as operator numbers. */

interface FilterField {
  name: string;
  filter: string;
  label: string;
  cells: number;
  capacity: number;
  hint: string;
}

const QUERY_FIELD: FilterField = { name: 'f.query', filter: 'query', label: 'Text', cells: 40, capacity: 200, hint: 'FRAGMENT OR NUMBER PREFIX' };
const FILTER_FIELDS: Readonly<Record<SavedSearchEntity, readonly FilterField[]>> = {
  members: [QUERY_FIELD, { name: 'f.status', filter: 'status', label: 'Status', cells: 12, capacity: 40, hint: 'ACTIVE INACTIVE DECEASED MERGED' }],
  accounts: [
    QUERY_FIELD, { name: 'f.status', filter: 'status', label: 'Status', cells: 12, capacity: 40, hint: 'STORED STATUS, E.G. OPEN OR CLOSED' },
    { name: 'f.currency', filter: 'currency', label: 'Currency', cells: 3, capacity: 3, hint: 'ISO CODE, E.G. USD' },
  ],
  cases: [
    QUERY_FIELD,
    { name: 'f.states', filter: 'states', label: 'States', cells: 20, capacity: 60, hint: 'CODES O W I R C E' },
    { name: 'f.queues', filter: 'queueIds', label: 'Queues', cells: 34, capacity: 200, hint: 'QUEUE CODES' },
    { name: 'f.priority', filter: 'priority', label: 'Priority', cells: 1, capacity: 1, hint: 'L N H U' },
    { name: 'f.assignee', filter: 'assignedActorId', label: 'Assignee', cells: 6, capacity: 6, hint: 'OPERATOR NUMBER' },
    { name: 'f.overdue', filter: 'overdue', label: 'Overdue only', cells: 1, capacity: 1, hint: 'Y' },
  ],
};

const PRIORITY_LETTERS: Readonly<Record<string, string>> = Object.fromEntries(Object.entries(PRIORITY_CODES).map(([letter, word]) => [word, letter]));

function filterText(filter: string, stored: SavedSearchFilterValue | undefined, data: ReferenceData): string {
  if (stored === undefined) return '';
  if (filter === 'overdue') return stored === true ? 'Y' : '';
  if (Array.isArray(stored)) {
    if (filter === 'states') return stored.map((state) => stateCode(state)).join(' ');
    if (filter === 'queueIds') return stored.map((id) => data.queues.find((queue) => queue.id === id)?.code ?? id).join(' ');
    return stored.join(' ');
  }
  if (typeof stored !== 'string') return '';
  if (filter === 'priority') return PRIORITY_LETTERS[stored] ?? stored;
  if (filter === 'assignedActorId') return data.caseWorkers.find((actor) => actor.id === stored)?.actorNumber ?? stored;
  return stored;
}

function parseFilter(filter: string, typed: string, data: ReferenceData): { value: SavedSearchFilterValue | undefined } | { problem: string } {
  const entry = typed.trim();
  if (entry === '') return { value: undefined };
  const tokens = upper(entry).split(/[\s,]+/u).filter((token) => token !== '');
  switch (filter) {
    case 'states': {
      const states = tokens.map((token) => STATE_CODES[token]);
      return states.every((state) => state !== undefined) ? { value: states } : { problem: 'STATES ARE CODES O, W, I, R, C OR E SEPARATED BY SPACES.' };
    }
    case 'queueIds': {
      const ids = tokens.map((token) => data.queues.find((queue) => queue.code === token)?.id);
      return ids.every((id) => id !== undefined) ? { value: ids } : { problem: `QUEUES ARE CODES: ${data.queues.map((queue) => queue.code).join(' ')}.` };
    }
    case 'priority': {
      const priority = PRIORITY_CODES[upper(entry)];
      return priority === undefined ? { problem: 'PRIORITY MUST BE L, N, H, U OR BLANK.' } : { value: priority };
    }
    case 'assignedActorId': {
      const worker = data.caseWorkers.find((actor) => actor.actorNumber === upper(entry));
      return worker === undefined ? { problem: `OPERATOR ${upper(entry).slice(0, 6)} DOES NOT WORK CASES AT THIS INSTITUTION.` } : { value: worker.id };
    }
    case 'overdue': return upper(entry) === 'Y' ? { value: true } : { problem: 'OVERDUE ONLY MUST BE Y OR BLANK.' };
    case 'status': return { value: entry.toLowerCase() };
    case 'currency': return { value: upper(entry) };
    default: return { value: entry };
  }
}

function editorValues(definition: SavedSearchDefinition, name: string, visibility: string, data: ReferenceData): Draft {
  const [sort] = definition.sort;
  return {
    name, visibility: visibility === 'shared' ? 'S' : 'P', entity: entityCode(definition.entity), max: definition.maxResults === undefined ? '' : String(definition.maxResults),
    sort: sort?.field ?? '', direction: sort === undefined ? '' : sort.direction === 'desc' ? 'D' : 'A', columns: definition.columns.join(' '),
    ...Object.fromEntries(FILTER_FIELDS[definition.entity].map((field) => [field.name, filterText(field.filter, definition.filters[field.filter], data)])),
  };
}

function editFrame(context: HostContext, row: SavedSearchRow | null): FrameOf<'search-edit'> {
  if (row?.definition === undefined || row.definition === null) {
    return { kind: 'search-edit', values: {}, searchId: null, revision: null, entity: 'cases', baseline: { visibility: 'P', entity: 'C', columns: DEFAULT_COLUMNS.cases.join(' ') }, original: null };
  }
  return {
    kind: 'search-edit', values: {}, searchId: row.id, revision: row.revision, entity: row.definition.entity,
    baseline: editorValues(row.definition, row.name, row.visibility, reference(context)), original: row.definition,
  };
}

const EDITOR_FIELDS = ['name', 'visibility', 'entity', 'max', 'sort', 'direction', 'columns', ...new Set(Object.values(FILTER_FIELDS).flat().map((field) => field.name))];

export const searchEditScreen: ScreenModule<FrameOf<'search-edit'>> = {
  render(context, frame) {
    if (frame.conflict === true && frame.searchId !== null) {
      const current = readSearch(context, frame.searchId);
      if (current?.definition !== undefined && current.definition !== null) {
        frame.revision = current.revision;
        frame.original = current.definition;
        frame.baseline = editorValues(current.definition, current.name, current.visibility, reference(context));
      }
    }
    const spec = SAVED_SEARCH_ENTITIES[frame.entity];
    const draft = (name: string): string => value(frame, name, frame.baseline[name] ?? '');
    const builder = new ScreenBuilder('THSS03', frame.searchId === null ? 'New saved search' : 'Modify saved search');
    label(builder, 3, 1, 'Name', 20).input('name', 3, 21, 50, draft('name'), { capacity: LIMITS.savedSearchNameLength });
    label(builder, 4, 1, 'Visibility (P/S)', 20).input('visibility', 4, 21, 1, draft('visibility'));
    label(builder, 4, 25, 'Records (M/A/C)', 16);
    if (frame.searchId === null) builder.input('entity', 4, 41, 1, draft('entity'));
    else builder.data(4, 41, 1, entityCode(frame.entity), 'emphasis');
    label(builder, 4, 45, 'Max results', 13).input('max', 4, 58, 5, draft('max'), { numeric: true });
    builder.data(5, 1, 78, `${upper(frame.entity)} FILTERS. P PRIVATE, S SHARED WITH THE TEAM. BLANK MAX = NO LIMIT.`, 'label');
    FILTER_FIELDS[frame.entity].forEach((field, index) => {
      label(builder, 7 + index, 1, field.label, 20).input(field.name, 7 + index, 21, field.cells, draft(field.name), { capacity: field.capacity });
      builder.data(7 + index, 23 + field.cells, 56 - field.cells, field.hint, 'label');
    });
    label(builder, 13, 1, 'Sort by', 20).input('sort', 13, 21, 22, draft('sort')).text(13, 45, 'DIRECTION (A/D)', 'label').input('direction', 13, 61, 1, draft('direction'));
    wrap(`SORT FIELDS: ${Object.keys(spec.sorts).join(' ')}`, 78).slice(0, 2).forEach((line, index) => builder.data(14 + index, 1, 78, line, 'label'));
    label(builder, 16, 1, 'Columns', 20).input('columns', 16, 21, 58, draft('columns'), { capacity: 400 });
    wrap(`COLUMNS: ${spec.columns.join(' ')}`, 78).slice(0, 3).forEach((line, index) => builder.data(17 + index, 1, 78, line, 'label'));
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const draft = (name: string): string => value(frame, name, frame.baseline[name] ?? '').trim();
    if (frame.searchId === null && event.modified.has('entity')) {
      const entity = ENTITY_CODES[upper(draft('entity'))];
      if (entity === undefined) return { kind: 'stay', message: failure('RECORDS MUST BE M (MEMBERS), A (ACCOUNTS) OR C (CASES).'), error: 'entity' };
      if (entity !== frame.entity) {
        frame.entity = entity;
        frame.baseline = { ...frame.baseline, entity: entityCode(entity), columns: DEFAULT_COLUMNS[entity].join(' ') };
        frame.values = Object.fromEntries(Object.entries(frame.values).filter(([name]) => !name.startsWith('f.') && name !== 'columns' && name !== 'sort'));
        return { kind: 'stay', message: info(`${upper(entity)} SEARCH. ENTER ITS FILTERS, SORT AND COLUMNS.`), cursor: 'f.query' };
      }
    }
    const data = reference(context);
    const filters: Record<string, SavedSearchFilterValue> = {};
    for (const field of FILTER_FIELDS[frame.entity]) {
      const untouched = frame.original !== null && draft(field.name) === (frame.baseline[field.name] ?? '');
      const stored = frame.original?.filters[field.filter];
      if (untouched) {
        if (stored !== undefined) filters[field.filter] = stored;
        continue;
      }
      const parsed = parseFilter(field.filter, draft(field.name), data);
      if ('problem' in parsed) return { kind: 'stay', message: failure(parsed.problem), error: field.name };
      if (parsed.value !== undefined) filters[field.filter] = parsed.value;
    }
    const visibility = upper(draft('visibility')) === 'S' ? 'shared' : upper(draft('visibility')) === 'P' ? 'private' : null;
    if (visibility === null) return { kind: 'stay', message: failure('VISIBILITY MUST BE P (PRIVATE) OR S (SHARED).'), error: 'visibility' };
    const direction = upper(draft('direction'));
    if (draft('sort') !== '' && direction !== 'A' && direction !== 'D') return { kind: 'stay', message: failure('DIRECTION MUST BE A (ASCENDING) OR D (DESCENDING).'), error: 'direction' };
    const max = draft('max');
    if (max !== '' && !/^\d+$/u.test(max)) return { kind: 'stay', message: failure('MAX RESULTS MUST BE A WHOLE NUMBER OR BLANK.'), error: 'max' };
    const columns = draft('columns').toLowerCase().split(/[\s,]+/u).filter((name) => name !== '');
    const definition: SavedSearchDefinition = {
      entity: frame.entity, filters,
      sort: draft('sort') === '' ? [] : [{ field: draft('sort').toLowerCase(), direction: direction === 'D' ? 'desc' : 'asc' }],
      columns: columns.length === 0 ? DEFAULT_COLUMNS[frame.entity] : columns,
      ...(max === '' ? {} : { maxResults: Number(max) }),
    };
    const name = draft('name');
    const command: ServiceCommand = frame.searchId === null || frame.revision === null
      ? { kind: 'search.saved.create', name, visibility, definition }
      : { kind: 'search.saved.update', searchId: frame.searchId, expectedRevision: frame.revision, name, visibility, definition };
    const shown = (field: string, typed: string): ReviewLine => ({ label: field, before: frame.searchId === null ? '' : frame.baseline[typed] ?? '', after: draft(typed) });
    const lines: ReviewLine[] = [
      shown('Name', 'name'), { label: 'Visibility', before: frame.searchId === null ? '' : upper(frame.baseline.visibility === 'S' ? 'shared' : 'private'), after: upper(visibility) },
      { label: 'Records', before: '', after: upper(frame.entity) },
      ...FILTER_FIELDS[frame.entity].filter((field) => draft(field.name) !== '' || (frame.baseline[field.name] ?? '') !== '').map((field) => shown(field.label, field.name)),
      shown('Sort by', 'sort'), shown('Direction', 'direction'), shown('Columns', 'columns'), shown('Max results', 'max'),
    ];
    const fields: Record<string, string> = {
      name: 'name', visibility: 'visibility', 'definition.sort': 'sort', 'definition.columns': 'columns', 'definition.maxResults': 'max',
      ...Object.fromEntries(FILTER_FIELDS[frame.entity].map((field) => [`definition.filters.${field.filter}`, field.name])),
    };
    return beginReview(context, frame, { command, screenId: 'THSS04', title: frame.searchId === null ? 'Review new search' : 'Review search change', lines, fields });
  },
  dirty: (frame) => differs(frame, frame.baseline, EDITOR_FIELDS),
  help: HELP_TOPICS['search-edit'],
};
