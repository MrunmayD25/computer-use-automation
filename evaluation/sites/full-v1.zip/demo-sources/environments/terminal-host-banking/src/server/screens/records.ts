import { info, type FrameOf } from '../host/frames.js';
import { upper } from '../host/format.js';
import type { ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { cell, inactiveKey, label, page, pageLabel, readRecord } from './common.js';
import { HELP_TOPICS } from './help-text.js';

const RESULT_ROWS = 16;

/** A paged read-only result: identity resolutions, reconciliation outcomes, previews. */
export const qresultScreen: ScreenModule<FrameOf<'qresult'>> = {
  render(_context, frame) {
    const builder = new ScreenBuilder('THQR01', frame.title);
    const pages = Math.max(1, Math.ceil(frame.lines.length / RESULT_ROWS));
    frame.page = Math.min(frame.page, pages);
    builder.page = `PAGE ${frame.page} OF ${pages}`;
    frame.lines.slice((frame.page - 1) * RESULT_ROWS, frame.page * RESULT_ROWS).forEach((line, index) => {
      if (line !== '') builder.data(3 + index, 1, 78, line, line === upper(line) ? 'emphasis' : 'data');
    });
    return builder.legend('F3=Return  F7=Up  F8=Down  F12=Return');
  },
  input(_context, frame, event) {
    const holder = { offset: (frame.page - 1) * RESULT_ROWS };
    const paged = page(holder, event.aid, RESULT_ROWS, frame.lines.length);
    if (paged === null) return inactiveKey();
    frame.page = holder.offset / RESULT_ROWS + 1;
    return paged;
  },
  help: HELP_TOPICS.qresult,
};

const RECORD_ROWS = 15;

function recordLines(record: Record<string, unknown>, indent = ''): string[] {
  const lines: string[] = [];
  for (const [key, value] of Object.entries(record)) {
    if (value === null) lines.push(`${indent}${key}: `);
    else if (typeof value === 'object' && !Array.isArray(value)) {
      lines.push(`${indent}${key}:`);
      lines.push(...recordLines(value as Record<string, unknown>, `${indent}  `));
    } else if (Array.isArray(value)) {
      lines.push(`${indent}${key}: [${value.length}]`);
      value.forEach((item, index) => {
        if (item !== null && typeof item === 'object') lines.push(...recordLines(item as Record<string, unknown>, `${indent}  ${index + 1}. `));
        else lines.push(`${indent}  ${index + 1}. ${String(item)}`);
      });
    } else lines.push(`${indent}${key}: ${cell(value)}`);
  }
  return lines;
}

/** One finance record's authorized fields and fingerprint, paged. */
export const recordScreen: ScreenModule<FrameOf<'record'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THFN01', `${frame.resource} record`);
    const result = readRecord(context, frame.resource, frame.id);
    if ('code' in result) {
      builder.text(4, 1, upper(result.message), 'warning');
      return builder.legend('F3=Return  F12=Cancel');
    }
    const snapshot = result;
    label(builder, 3, 1, 'Record', 12).data(3, 13, 30, `${snapshot.kind} ${snapshot.id}`, 'emphasis');
    label(builder, 3, 44, 'Observed', 12).data(3, 56, 22, snapshot.observedAt.slice(0, 16).replace('T', ' '));
    label(builder, 4, 1, 'Fingerprint', 12).data(4, 13, 64, snapshot.fingerprint, 'label');
    const lines = recordLines(snapshot.record);
    builder.page = pageLabel(frame.offset, RECORD_ROWS, lines.length);
    lines.slice(frame.offset, frame.offset + RECORD_ROWS).forEach((line, index) => builder.data(6 + index, 1, 78, line));
    return builder.legend('F1=Help  F3=Return  F7=Up  F8=Down');
  },
  input(context, frame, event) {
    const result = readRecord(context, frame.resource, frame.id);
    const lines = 'code' in result ? [] : recordLines(result.record);
    const paged = page(frame, event.aid, RECORD_ROWS, lines.length);
    return paged ?? { kind: 'stay', message: info('THIS IS AN INQUIRY. F3 RETURNS.') };
  },
  help: HELP_TOPICS.record,
};
