import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';

import { DEFAULT_PORT, startTerminalHost } from './app.js';

const here = dirname(fileURLToPath(import.meta.url));
const packageRoot = resolve(here, '..', '..');
const defaultDatabase = resolve(packageRoot, '..', 'database', 'financial', '.runtime', 'financial.sqlite');

const usage = `Usage: node dist/server/main.js [options]
  --port <n>          Listener port (default ${String(DEFAULT_PORT)}, or TERMINAL_HOST_PORT; 0 picks a free port)
  --host <address>    Listener address (default 127.0.0.1)
  --database <path>   Seeded financial SQLite file (default FINANCIAL_DATABASE_PATH or ${defaultDatabase})
  --world <name>      Named world to bind (default ${DEFAULT_SEED_MANIFEST.name})
  --operators <list>  Comma-separated operator actor numbers allowed to sign on (default OP0002,OP0003)
  --verbose           Log each request with status and latency`;

const { values } = parseArgs({
  options: {
    port: { type: 'string' }, host: { type: 'string' }, database: { type: 'string' }, world: { type: 'string' },
    operators: { type: 'string' }, verbose: { type: 'boolean', default: false }, help: { type: 'boolean', default: false },
  },
  strict: true,
});
if (values.help) { console.log(usage); process.exit(0); }

const port = Number(values.port ?? process.env.TERMINAL_HOST_PORT ?? DEFAULT_PORT);
if (!Number.isInteger(port) || port < 0 || port > 65_535) throw new Error(`Invalid port ${String(values.port ?? process.env.TERMINAL_HOST_PORT)}.\n${usage}`);
const databasePath = resolve(values.database ?? process.env.FINANCIAL_DATABASE_PATH ?? defaultDatabase);
if (!existsSync(databasePath)) {
  throw new Error(`Financial database ${databasePath} does not exist. Seed it once with:\n  npm --prefix environments/database/financial run seed -- --path ${databasePath}`);
}
const worldName = values.world ?? DEFAULT_SEED_MANIFEST.name;
const bindings = (() => {
  using database = openFinancialDatabase({ path: databasePath });
  return database.getNamedWorld(worldName);
})();
if (bindings.length === 0) throw new Error(`World ${worldName} is not seeded in ${databasePath}. The terminal never seeds shared data itself.`);
const actorNumbers = (values.operators ?? 'OP0002,OP0003').split(',').map((entry) => entry.trim().toUpperCase()).filter((entry) => entry.length > 0);

const store = openFinancialStore({ path: databasePath });
const handle = await startTerminalHost({
  store, bindings, operator: { actorNumbers, fixed: false },
  publicDirectory: join(packageRoot, 'dist', 'public'), host: values.host ?? '127.0.0.1', port, verbose: values.verbose,
  onClose: () => { store.close(); },
});
console.log(`Terminal host banking listening on ${handle.origin} (${bindings.map((binding) => binding.institutionId).join(', ')})`);

let stopping = false;
const stop = (signal: string): void => {
  if (stopping) return;
  stopping = true;
  if (values.verbose) console.error(`Received ${signal}; closing listener and database.`);
  handle.close().then(() => process.exit(0), (error: unknown) => { console.error(error); process.exit(1); });
};
process.once('SIGINT', () => { stop('SIGINT'); });
process.once('SIGTERM', () => { stop('SIGTERM'); });
