import {
  LIMITS, listCaseSubjectCorrectionEvidence, listEffectivePolicyVersions, listServicingApprovalCheckers, referenceData, searchCases,
  type CaseDetail, type CasePriority, type CaseRow, type CaseState, type ReferenceData, type ServiceCommand, type ServiceContext,
} from '@computer-use/financial-database/services';

import type { Tone } from '../../shared/protocol.js';
import { failure, info, type Frame, type FrameOf, type ReviewLine } from '../host/frames.js';
import { localDate, localDateTime, upper, wrap } from '../host/format.js';
import type { HostContext, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  accountFrame, anyEntered, badSelection, beginReview, caseFrame, clampOffset, findAccount, findMember, forget, inactiveKey, label, LIST_ROWS, LIST_TOP,
  memberFrame, notFound, page, pageLabel, readCase, readMember, rowsLabel, selection, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';
import { notesFrame } from './notes.js';

/** Single-letter state codes typed on case screens; A on the work queue selects every state still worked. */
export const STATE_CODES: Readonly<Record<string, CaseState>> = { O: 'open', W: 'pending-customer', I: 'pending-internal', R: 'resolved', C: 'closed', E: 'reopened' };
const ACTIVE_STATES: readonly CaseState[] = ['open', 'pending-customer', 'pending-internal', 'reopened'];
const STATE_LABELS: Readonly<Record<string, string>> = {
  open: 'OPEN', 'pending-customer': 'PEND-CUST', 'pending-internal': 'PEND-INT', resolved: 'RESOLVED', closed: 'CLOSED', reopened: 'REOPENED',
};
export const PRIORITY_CODES: Readonly<Record<string, CasePriority>> = { L: 'low', N: 'normal', H: 'high', U: 'urgent' };

export const stateLabel = (state: string): string => STATE_LABELS[state] ?? upper(state);
export const stateCode = (state: string): string => Object.entries(STATE_CODES).find(([, candidate]) => candidate === state)?.[0] ?? '?';

/** Reasons use the shared limit and are shown whole: 500 cells from row 13 wrap through row 19. */
const REASON_ROW = 13;

function reference(context: HostContext): ReferenceData {
  const { institution } = context.session();
  return context.read((database, datasetId) => referenceData(database, datasetId, institution.institutionId));
}

/** The case worker an operator number names; a blank entry means unassigned. */
function caseWorker(data: ReferenceData, number: string): { id: string | null; name: string } | undefined {
  const wanted = upper(number.trim());
  if (wanted === '') return { id: null, name: 'UNASSIGNED' };
  const worker = data.caseWorkers.find((actor) => actor.actorNumber === wanted);
  return worker === undefined ? undefined : { id: worker.id, name: `${worker.actorNumber} ${worker.displayName}` };
}

function currentAssignee(data: ReferenceData, record: CaseRow): string {
  return data.caseWorkers.find((actor) => actor.id === record.assignedActorId)?.actorNumber ?? '';
}

function caseHeader(builder: ScreenBuilder, record: CaseRow, version: number): void {
  label(builder, 3, 1, 'Case', 20).data(3, 21, 8, record.caseNumber, 'emphasis').text(3, 32, 'STATE', 'label').data(3, 38, 10, stateLabel(record.state))
    .text(3, 50, 'VERSION', 'label').data(3, 58, 6, String(version));
  label(builder, 4, 1, 'Member', 20).data(4, 21, 8, record.memberNumber).data(4, 31, 48, record.memberName, 'label');
}

function reasonInput(builder: ScreenBuilder, frame: Frame, prompt: string): void {
  builder.text(REASON_ROW - 1, 1, prompt, 'label');
  builder.input('reason', REASON_ROW, 1, LIMITS.reasonLength, value(frame, 'reason'));
}

function editFrame(code: 'R' | 'T' | 'C', record: CaseRow): Frame {
  if (code === 'R') return { kind: 'case-route', values: {}, caseId: record.id, version: record.version };
  if (code === 'T') return { kind: 'case-status', values: {}, caseId: record.id, version: record.version };
  return { kind: 'case-subject-correct', values: {}, caseId: record.id, version: record.version };
}

const FILTERS = ['query', 'state', 'queue', 'mine'] as const;

export const caseListScreen: ScreenModule<FrameOf<'case-list'>> = {
  render(context, frame) {
    const { operator, institution } = context.session();
    const data = reference(context);
    const { criteria } = frame;
    const queue = data.queues.find((candidate) => candidate.code === criteria.queue);
    const code = STATE_CODES[criteria.state];
    const states = criteria.state === 'A' ? ACTIVE_STATES : code === undefined ? undefined : [code];
    const search = (offset: number) => context.read((database, datasetId) => searchCases(database, datasetId, {
      query: criteria.query, ...(frame.memberId === null ? {} : { memberId: frame.memberId }), ...(states === undefined ? {} : { states }),
      ...(queue === undefined ? {} : { queueId: queue.id }), ...(criteria.mine === 'Y' ? { assignedActorId: operator.actorId } : {}),
      sort: 'due', direction: 'asc', limit: LIST_ROWS, offset,
    }));
    let result = search(frame.offset);
    const clamped = clampOffset(frame.offset, LIST_ROWS, result.total);
    if (clamped !== frame.offset) {
      frame.offset = clamped;
      result = search(clamped);
    }
    frame.rows = result.items.map((row) => row.id);
    frame.total = result.total;
    const builder = new ScreenBuilder('THCS01', 'Case work queue');
    builder.page = pageLabel(frame.offset, LIST_ROWS, result.total);
    label(builder, 3, 1, 'Search', 8).input('query', 3, 9, 24, value(frame, 'query', criteria.query), { capacity: 60 });
    label(builder, 3, 35, 'State', 6).input('state', 3, 41, 1, value(frame, 'state', criteria.state));
    label(builder, 3, 44, 'Queue', 6).input('queue', 3, 50, 10, value(frame, 'queue', criteria.queue));
    label(builder, 3, 62, 'Mine', 5).input('mine', 3, 67, 1, value(frame, 'mine', criteria.mine));
    builder.text(4, 1, 'STATE O=OPEN W=PEND-CUST I=PEND-INT R=RESOLVED C=CLOSED E=REOPENED A=ACTIVE', 'label');
    const scope = frame.memberId === null ? `QUEUES ${data.queues.map((candidate) => candidate.code).join(' ')}. MINE Y = ASSIGNED TO YOU.`
      : `CASES OF MEMBER ${readMember(context, frame.memberId).member.memberNumber}. QUEUES ${data.queues.map((candidate) => candidate.code).join(' ')}.`;
    builder.data(5, 1, 78, scope, 'label');
    for (const [at, text] of [[1, 'S'], [3, 'CASE'], [12, 'MEMBER'], [21, 'QUEUE'], [32, 'STATE'], [42, 'PRI'], [46, 'DUE'], [57, 'SUMMARY']] as const) builder.text(6, at, text, 'label');
    result.items.forEach((row, index) => {
      const line = LIST_TOP + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 8, row.caseNumber).data(line, 12, 8, row.memberNumber).data(line, 21, 10, row.queueCode).data(line, 32, 9, stateLabel(row.state), 'label')
        .data(line, 42, 3, upper(row.priority.slice(0, 3))).data(line, 46, 10, localDate(row.dueAt, institution.timeZone), row.overdue ? 'warning' : 'data').data(line, 57, 22, row.summary);
      if (row.overdue) builder.text(line, 56, '*', 'warning');
    });
    if (result.total === 0) builder.text(LIST_TOP, 3, 'NO CASES MATCH THE FILTERS.', 'warning');
    builder.text(19, 1, 'SEL: S=INQUIRY  N=NOTES  R=ROUTE  T=STATUS  C=CORRECT SUBJECT * = OVERDUE', 'label');
    builder.data(20, 1, 40, rowsLabel(frame.offset, result.items.length, result.total), 'label');
    return builder.legend('ENTER=Filter/Select  F1=Help  F3=Return  F6=Open case  F7=Up  F8=Down');
  },
  input(context, frame, event) {
    if (event.aid === 'pf6') return { kind: 'push', frame: { kind: 'case-open', values: {}, memberId: frame.memberId } };
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    if (FILTERS.some((name) => event.modified.has(name))) {
      const state = upper(value(frame, 'state', frame.criteria.state).trim());
      if (state !== '' && state !== 'A' && !(state in STATE_CODES)) return { kind: 'stay', message: failure('STATE MUST BE O, W, I, R, C, E, A OR BLANK.'), error: 'state' };
      const queue = upper(value(frame, 'queue', frame.criteria.queue).trim());
      if (queue !== '' && !reference(context).queues.some((candidate) => candidate.code === queue)) {
        return { kind: 'stay', message: failure(`QUEUE ${queue.slice(0, 10)} IS NOT DEFINED AT THIS INSTITUTION.`), error: 'queue' };
      }
      const mine = upper(value(frame, 'mine', frame.criteria.mine).trim());
      if (mine !== '' && mine !== 'Y') return { kind: 'stay', message: failure('MINE MUST BE Y OR BLANK.'), error: 'mine' };
      frame.criteria = { query: value(frame, 'query', frame.criteria.query).trim(), state, queue, mine };
      frame.offset = 0;
      forget(frame, (name) => (FILTERS as readonly string[]).includes(name));
      selection(frame, frame.rows.length);
      return { kind: 'stay', message: info('FILTER APPLIED. TYPE S, N, R, T OR C BESIDE A CASE.') };
    }
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE S, N, R, T OR C BESIDE A CASE, OR CHANGE THE FILTERS.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const caseId = frame.rows[picked.index];
    if (caseId === undefined) return badSelection(picked.code, 'A LISTED ROW', picked.index);
    frame.cursor = `sel.${picked.index}`;
    switch (picked.code) {
      case 'S': return { kind: 'push', frame: caseFrame(caseId) };
      case 'N': return { kind: 'push', frame: notesFrame({ kind: 'case', id: caseId }) };
      case 'R': case 'T': case 'C': return { kind: 'push', frame: editFrame(picked.code, readCase(context, caseId).case) };
      default: return badSelection(picked.code, 'S, N, R, T OR C', picked.index);
    }
  },
  help: HELP_TOPICS['case-list'],
};

const DETAIL_ROWS = 15;

/** The case's full record after page 1: summary, timeline, work items, service level and documents. */
function historyLines(detail: CaseDetail, timeZone: string): { text: string; tone: Tone }[] {
  const lines: { text: string; tone: Tone }[] = [];
  const section = (title: string): void => { lines.push({ text: title, tone: 'emphasis' }); };
  const hanging = (lead: string, text: string, tone: Tone = 'data'): void => {
    wrap(text, 77 - lead.length).forEach((part, index) => lines.push({ text: `${index === 0 ? lead : ' '.repeat(lead.length)}${part}`, tone }));
  };
  section('SUMMARY');
  hanging('', detail.case.summary);
  section('TIMELINE (OLDEST FIRST)');
  for (const event of detail.events) hanging(`${localDateTime(event.occurredAt, timeZone)} ${stateLabel(event.state).padEnd(9)} ${(event.actor?.actorNumber ?? 'SYSTEM').padEnd(6)} `, event.detail);
  section('WORK ITEMS');
  if (detail.dependencies.length === 0) lines.push({ text: 'NONE', tone: 'label' });
  for (const item of detail.dependencies) {
    hanging(`${upper(item.state).padEnd(9)} `, `${item.kind} ${item.referenceId}${item.dueAt === null ? '' : ` DUE ${localDate(item.dueAt, timeZone)}`}`, item.state === 'open' ? 'warning' : 'data');
  }
  section('SERVICE LEVEL');
  for (const interval of detail.sla) {
    hanging(`${upper(interval.state).padEnd(9)} `, `${localDateTime(interval.startsAt, timeZone)} TO ${interval.endsAt === null ? 'NOW' : localDateTime(interval.endsAt, timeZone)} ${interval.reason ?? ''}`);
  }
  section('DOCUMENTS');
  if (detail.documents.length === 0) lines.push({ text: 'NONE', tone: 'label' });
  for (const document of detail.documents) hanging(`${upper(document.visibility).padEnd(11)} `, document.purpose);
  return lines;
}

function detailPages(detail: CaseDetail, timeZone: string): number {
  return 1 + Math.max(1, Math.ceil(historyLines(detail, timeZone).length / DETAIL_ROWS));
}

export const caseScreen: ScreenModule<FrameOf<'case'>> = {
  render(context, frame) {
    const detail = readCase(context, frame.caseId);
    const record = detail.case;
    const { timeZone } = context.session().institution;
    const pages = detailPages(detail, timeZone);
    frame.page = Math.min(frame.page, pages);
    const builder = new ScreenBuilder('THCS02', 'Case inquiry');
    builder.page = `PAGE ${frame.page} OF ${pages}`;
    caseHeader(builder, record, record.version);
    if (frame.page === 1) {
      const queue = reference(context).queues.find((candidate) => candidate.id === record.queueId);
      label(builder, 6, 1, 'Member status', 20).data(6, 21, 12, upper(detail.memberStatus));
      label(builder, 7, 1, 'Account', 20).data(7, 21, 10, record.accountNumber ?? 'NONE');
      label(builder, 8, 1, 'Queue', 20).data(8, 21, 10, record.queueCode).data(8, 32, 26, record.queueName).data(8, 60, 19, `${upper(queue?.visibility ?? '')} ACCESS`, 'label');
      label(builder, 9, 1, 'Assigned to', 20).data(9, 21, 40, record.assignedName ?? 'UNASSIGNED');
      label(builder, 10, 1, 'Category', 20).data(10, 21, 28, record.categoryLabel).text(10, 50, 'PRIORITY', 'label').data(10, 59, 8, upper(record.priority));
      label(builder, 11, 1, 'Opened', 20).data(11, 21, 16, localDateTime(record.openedAt, timeZone)).text(11, 40, 'DUE', 'label').data(11, 44, 16, localDateTime(record.dueAt, timeZone));
      if (record.overdue) builder.text(11, 62, 'OVERDUE', 'warning');
      const summary = wrap(record.summary, 58);
      label(builder, 12, 1, 'Summary', 20);
      summary.slice(0, 4).forEach((line, index) => builder.data(12 + index, 21, 58, line));
      if (summary.length > 4) builder.text(16, 21, 'SUMMARY CONTINUES ON PAGE 2.', 'warning');
      const transitions = [...detail.allowedTransitions, ...(detail.case.state === 'resolved' ? ['closed' as const, 'reopened' as const] : detail.case.state === 'closed' ? ['reopened' as const] : [])];
    const next = transitions.map((state) => `${stateCode(state)}=${stateLabel(state)}`).join('  ');
      label(builder, 17, 1, 'Next states', 20).data(17, 21, 58, next === '' ? 'NONE' : next);
      const open = detail.dependencies.filter((item) => item.state === 'open').length;
      label(builder, 18, 1, 'Open work items', 20).data(18, 21, 4, String(open), open > 0 ? 'warning' : 'data').text(18, 27, 'NOTES', 'label').data(18, 33, 4, String(detail.notes.length));
      if (detail.restrictedNotesWithheld > 0) builder.data(18, 39, 40, `${detail.restrictedNotesWithheld} RESTRICTED NOTE(S) WITHHELD`, 'warning');
    } else {
      historyLines(detail, timeZone).slice((frame.page - 2) * DETAIL_ROWS, (frame.page - 1) * DETAIL_ROWS).forEach((line, index) => {
        if (line.text !== '') builder.data(5 + index, 1, 78, line.text, line.tone);
      });
    }
    return builder.legend('ENTER=Refresh  F1=Help  F3=Return  F4=Route  F5=Notes  F6=Status  F7=Up  F8=Down', 'F9=Correct subject  F10=Member  F11=Account');
  },
  input(context, frame, event) {
    const detail = readCase(context, frame.caseId);
    const record = detail.case;
    switch (event.aid) {
      case 'enter': return { kind: 'stay', message: info('SCREEN REFRESHED WITH CURRENT DATA.') };
      case 'pf7':
        if (frame.page === 1) return { kind: 'stay', message: info('ALREADY AT THE FIRST PAGE.') };
        frame.page -= 1;
        return { kind: 'stay' };
      case 'pf8':
        if (frame.page >= detailPages(detail, context.session().institution.timeZone)) return { kind: 'stay', message: info('ALREADY AT THE LAST PAGE.') };
        frame.page += 1;
        return { kind: 'stay' };
      case 'pf4': return { kind: 'push', frame: editFrame('R', record) };
      case 'pf5': return { kind: 'push', frame: notesFrame({ kind: 'case', id: record.id }) };
      case 'pf6': return { kind: 'push', frame: editFrame('T', record) };
      case 'pf9': return { kind: 'push', frame: editFrame('C', record) };
      case 'pf10': return { kind: 'push', frame: memberFrame(record.memberId) };
      case 'pf11': return record.accountId === null ? { kind: 'stay', message: failure('THIS CASE HAS NO LINKED ACCOUNT.') } : { kind: 'push', frame: accountFrame(record.accountId) };
      default: return inactiveKey();
    }
  },
  help: HELP_TOPICS.case,
};

const OPEN_FIELDS = ['account', 'queue', 'assignee', 'category', 'due', 'summary'] as const;

export const caseOpenScreen: ScreenModule<FrameOf<'case-open'>> = {
  render(context, frame) {
    const data = reference(context);
    const scoped = frame.memberId === null ? '' : readMember(context, frame.memberId).member.memberNumber;
    const builder = new ScreenBuilder('THCS03', 'Open case');
    label(builder, 3, 1, 'Member number', 20).input('member', 3, 21, 8, value(frame, 'member', scoped));
    label(builder, 4, 1, 'Account number', 20).input('account', 4, 21, 10, value(frame, 'account')).text(4, 34, 'OPTIONAL. MUST BELONG TO THE MEMBER.', 'label');
    label(builder, 6, 1, 'Queue', 20).input('queue', 6, 21, 10, value(frame, 'queue')).data(6, 34, 45, data.queues.map((queue) => queue.code).join(' '), 'label');
    label(builder, 7, 1, 'Assign to operator', 20).input('assignee', 7, 21, 6, value(frame, 'assignee'))
      .data(7, 34, 45, `BLANK=UNASSIGNED ${data.caseWorkers.map((actor) => actor.actorNumber).join(' ')}`, 'label');
    label(builder, 8, 1, 'Category', 20).input('category', 8, 21, 20, value(frame, 'category'));
    label(builder, 9, 1, 'Priority (L/N/H/U)', 20).input('priority', 9, 21, 1, value(frame, 'priority', 'N')).text(9, 34, 'LOW, NORMAL, HIGH, URGENT', 'label');
    label(builder, 10, 1, 'Due date', 20).input('due', 10, 21, 10, value(frame, 'due')).text(10, 34, '(YYYY-MM-DD)', 'label');
    builder.text(12, 1, 'SUMMARY: THE REQUESTED OUTCOME AND ITS SOURCE', 'label');
    builder.input('summary', 13, 1, LIMITS.summaryLength, value(frame, 'summary'));
    builder.text(17, 1, 'CATEGORIES', 'label');
    wrap(data.caseCategories.map((category) => category.code).join('  '), 66).slice(0, 3).forEach((line, index) => builder.data(17 + index, 13, 66, line, 'label'));
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const data = reference(context);
    const scoped = frame.memberId === null ? '' : readMember(context, frame.memberId).member.memberNumber;
    const read = (name: string, fallback = ''): string => value(frame, name, fallback).trim();
    const member = findMember(context, read('member', scoped));
    if (member === undefined) return { kind: 'stay', message: read('member', scoped) === '' ? failure('ENTER THE MEMBER NUMBER.') : notFound('MEMBER', read('member', scoped), context), error: 'member' };
    let accountId: string | null = null;
    if (read('account') !== '') {
      const account = findAccount(context, read('account'));
      if (account === undefined) return { kind: 'stay', message: notFound('ACCOUNT', read('account'), context), error: 'account' };
      accountId = account.id;
    }
    const queue = data.queues.find((candidate) => candidate.code === upper(read('queue')));
    if (queue === undefined) return { kind: 'stay', message: failure(`QUEUE MUST BE ONE OF ${data.queues.map((candidate) => candidate.code).join(', ')}.`), error: 'queue' };
    const assignee = caseWorker(data, read('assignee'));
    if (assignee === undefined) return { kind: 'stay', message: failure(`OPERATOR ${upper(read('assignee')).slice(0, 6)} DOES NOT WORK CASES AT THIS INSTITUTION.`), error: 'assignee' };
    const priority = PRIORITY_CODES[upper(read('priority', 'N'))];
    if (priority === undefined) return { kind: 'stay', message: failure('PRIORITY MUST BE L, N, H OR U.'), error: 'priority' };
    const category = read('category').toLowerCase();
    const command: ServiceCommand = {
      kind: 'case.open', memberId: member.id, accountId, queueId: queue.id, assignedActorId: assignee.id, category, priority, summary: read('summary'), dueDate: read('due'),
    };
    const lines: ReviewLine[] = [
      { label: 'Member', before: '', after: `${member.memberNumber} ${member.displayName}` },
      { label: 'Account', before: '', after: accountId === null ? 'NONE' : upper(read('account')) },
      { label: 'Queue', before: '', after: queue.code },
      { label: 'Assigned to', before: '', after: assignee.name },
      { label: 'Category', before: '', after: category },
      { label: 'Priority', before: '', after: upper(priority) },
      { label: 'Due date', before: '', after: read('due') },
      { label: 'Summary', before: '', after: read('summary') },
    ];
    return beginReview(context, frame, {
      command, screenId: 'THCS04', title: 'Review new case', lines,
      fields: { memberId: 'member', accountId: 'account', queueId: 'queue', assignedActorId: 'assignee', category: 'category', priority: 'priority', summary: 'summary', dueDate: 'due' },
    });
  },
  dirty: (frame) => anyEntered(frame, OPEN_FIELDS),
  help: HELP_TOPICS['case-open'],
};

/** Adopts the current version after another operator changed the case, as maintenance screens do. */
function editedCase(context: HostContext, frame: FrameOf<'case-route' | 'case-status' | 'case-subject-correct'>): CaseDetail {
  const detail = readCase(context, frame.caseId);
  if (frame.conflict === true) frame.version = detail.case.version;
  return detail;
}

export const caseRouteScreen: ScreenModule<FrameOf<'case-route'>> = {
  render(context, frame) {
    const { case: record } = editedCase(context, frame);
    const data = reference(context);
    const builder = new ScreenBuilder('THCS05', 'Route case');
    caseHeader(builder, record, frame.version);
    label(builder, 5, 1, 'Current queue', 20).data(5, 21, 10, record.queueCode).data(5, 32, 47, `ASSIGNED ${record.assignedName ?? 'UNASSIGNED'}`, 'label');
    label(builder, 7, 1, 'New queue', 20).input('queue', 7, 21, 10, value(frame, 'queue', record.queueCode));
    label(builder, 8, 1, 'Assign to operator', 20).input('assignee', 8, 21, 6, value(frame, 'assignee', currentAssignee(data, record)))
      .data(8, 34, 45, `BLANK=UNASSIGNED ${data.caseWorkers.map((actor) => actor.actorNumber).join(' ')}`, 'label');
    wrap(data.queues.map((queue) => `${queue.code}=${upper(queue.visibility)}`).join('  '), 78).slice(0, 2).forEach((line, index) => builder.data(9 + index, 1, 78, line, 'label'));
    builder.text(11, 1, 'MOVING OUT OF A RESTRICTED OR SUPERVISOR QUEUE NEEDS SUPERVISE AUTHORITY.', 'label');
    reasonInput(builder, frame, 'REASON FOR THE ROUTING (REQUIRED)');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const { case: record } = readCase(context, frame.caseId);
    const data = reference(context);
    const queue = data.queues.find((candidate) => candidate.code === upper(value(frame, 'queue', record.queueCode).trim()));
    if (queue === undefined) return { kind: 'stay', message: failure(`QUEUE MUST BE ONE OF ${data.queues.map((candidate) => candidate.code).join(', ')}.`), error: 'queue' };
    const assignee = caseWorker(data, value(frame, 'assignee', currentAssignee(data, record)));
    if (assignee === undefined) return { kind: 'stay', message: failure('THAT OPERATOR DOES NOT WORK CASES AT THIS INSTITUTION.'), error: 'assignee' };
    const reason = value(frame, 'reason').trim();
    return beginReview(context, frame, {
      command: { kind: 'case.assign', caseId: record.id, expectedVersion: frame.version, queueId: queue.id, assignedActorId: assignee.id, reason },
      screenId: 'THCS06', title: 'Review case routing',
      lines: [
        { label: 'Queue', before: record.queueCode, after: queue.code },
        { label: 'Assigned to', before: record.assignedName ?? 'UNASSIGNED', after: assignee.name },
        { label: 'Reason', before: '', after: reason },
      ],
      fields: { queueId: 'queue', assignedActorId: 'assignee', reason: 'reason' },
    });
  },
  dirty: (frame) => anyEntered(frame, ['queue', 'assignee', 'reason']),
  help: HELP_TOPICS['case-route'],
};

export const caseStatusScreen: ScreenModule<FrameOf<'case-status'>> = {
  render(context, frame) {
    const detail = editedCase(context, frame);
    const builder = new ScreenBuilder('THCS07', 'Change case status');
    caseHeader(builder, detail.case, frame.version);
    const transitions = [...detail.allowedTransitions, ...(detail.case.state === 'resolved' ? ['closed' as const, 'reopened' as const] : detail.case.state === 'closed' ? ['reopened' as const] : [])];
    const next = transitions.map((state) => `${stateCode(state)}=${stateLabel(state)}`).join('  ');
    label(builder, 6, 1, 'Allowed moves', 20).data(6, 21, 58, next === '' ? 'NONE' : next);
    label(builder, 7, 1, 'New state code', 20).input('to', 7, 21, 1, value(frame, 'to'));
    const open = detail.dependencies.filter((item) => item.state === 'open').length;
    label(builder, 8, 1, 'Open work items', 20).data(8, 21, 4, String(open), open > 0 ? 'warning' : 'data');
    builder.text(9, 1, 'C/E REQUIRE A CURRENT MEMBER DOCUMENT VERSION; C ALSO NEEDS NO OPEN WORK.', 'label');
    label(builder, 10, 1, 'Evidence version', 20).input('evidence', 10, 21, 58, value(frame, 'evidence'));
    reasonInput(builder, frame, 'REASON / CLOSURE RESOLUTION CODE / REOPENING BASIS (REQUIRED)');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const { case: record } = readCase(context, frame.caseId);
    const code = upper(value(frame, 'to').trim());
    const toState = STATE_CODES[code];
    if (toState === undefined) return { kind: 'stay', message: failure('NEW STATE MUST BE O, W, I, R, C OR E.'), error: 'to' };
    const reason = value(frame, 'reason').trim();
    return beginReview(context, frame, {
      command: toState === 'closed'
        ? { kind: 'case.close', caseId: record.id, expectedVersion: frame.version, resolutionCode: reason, effectEvidenceVersionId: value(frame, 'evidence').trim() }
        : toState === 'reopened'
          ? { kind: 'case.reopen', caseId: record.id, expectedVersion: frame.version, reopeningBasis: reason, evidenceVersionId: value(frame, 'evidence').trim() }
          : { kind: 'case.transition', caseId: record.id, expectedVersion: frame.version, toState, reason },
      screenId: 'THCS08', title: 'Review status change',
      lines: [{ label: 'State', before: stateLabel(record.state), after: stateLabel(toState) }, { label: 'Reason', before: '', after: reason }, ...(toState === 'closed' || toState === 'reopened' ? [{ label: 'Evidence version', before: '', after: value(frame, 'evidence').trim() }] : [])],
      fields: { toState: 'to', reason: 'reason', resolutionCode: 'reason', reopeningBasis: 'reason', effectEvidenceVersionId: 'evidence', evidenceVersionId: 'evidence' },
    });
  },
  dirty: (frame) => anyEntered(frame, ['to', 'reason', 'evidence']),
  help: HELP_TOPICS['case-status'],
};

export const caseSubjectCorrectScreen: ScreenModule<FrameOf<'case-subject-correct'>> = {
  render(context, frame) {
    const { case: record } = editedCase(context, frame);
    const { binding, operator } = context.session();
    const readContext: ServiceContext = { binding, actorId: operator.actorId, reference: 'terminal-host-banking:case-subject-correct' };
    const correctedNumber = upper(value(frame, 'member', record.memberNumber).trim());
    const correctedMember = findMember(context, correctedNumber);
    const evidenceResult = context.read((database) => listCaseSubjectCorrectionEvidence(database, readContext, record.memberId, correctedMember?.id ?? record.memberId));
    const checkerResult = context.read((database) => listServicingApprovalCheckers(database, readContext, 'case.subject.correct'));
    const policyResult = context.read((database) => listEffectivePolicyVersions(database, readContext));
    const documents = evidenceResult.kind === 'authorized' ? evidenceResult.value.evidenceDocuments : [];
    const identityEvidence = evidenceResult.kind === 'authorized' ? evidenceResult.value.identityEvidence.filter((item) => item.documentVersionId !== null) : [];
    const checkers = checkerResult.kind === 'authorized' ? checkerResult.value : [];
    const policies = policyResult.kind === 'authorized' ? policyResult.value : [];
    const builder = new ScreenBuilder('THCS09', 'Correct case subject');
    caseHeader(builder, record, frame.version);
    label(builder, 5, 1, 'Correct member', 20).input('member', 5, 21, 10, value(frame, 'member', record.memberNumber));
    label(builder, 6, 1, 'Correct account', 20).input('account', 6, 21, 10, value(frame, 'account', record.accountNumber ?? '')).text(6, 34, 'BLANK MEANS MEMBER ONLY.', 'label');
    label(builder, 7, 1, 'Evidence version', 20).input('evidence', 7, 21, 58, value(frame, 'evidence'));
    label(builder, 8, 1, 'Approved decision', 20).input('approval', 8, 21, 58, value(frame, 'approval'));
    if (evidenceResult.kind === 'rejected') {
      wrap(`EVIDENCE LIST REFUSED: ${evidenceResult.message}`, 78).slice(0, 2).forEach((line, index) => builder.data(10 + index, 1, 78, line, 'warning'));
    } else {
      const correctedDocuments = documents.filter((item) => item.memberId === correctedMember?.id);
      const originalDocuments = documents.filter((item) => item.memberId === record.memberId && item.memberId !== correctedMember?.id);
      const summary = (scope: string, items: typeof documents): string => `${scope} CURRENT (${String(items.length)}): ${items.length === 0 ? 'NONE' : items.map((item) => `${item.versionId} ${upper(item.documentType)}`).join('  ')}`;
      builder.data(10, 1, 78, wrap(summary(correctedMember?.id === record.memberId ? 'SUBJECT' : 'CORRECTED', correctedDocuments), 78)[0] ?? '', 'label');
      builder.data(11, 1, 78, wrap(summary('ORIGINAL', originalDocuments), 78)[0] ?? '', 'label');
    }
    if (identityEvidence.length > 0) builder.data(13, 1, 78, `IDENTITY BINDINGS: ${identityEvidence.map((item) => item.documentVersionId).join(' ')}`, 'label');
    const approvalPrerequisiteError = checkerResult.kind === 'rejected' ? checkerResult.message : policyResult.kind === 'rejected' ? policyResult.message : null;
    builder.data(12, 1, 78, approvalPrerequisiteError === null
      ? `A3: POLICY ${policies[0]?.version ?? 'NONE'}; ELIGIBLE CHECKER ${checkers.map((item) => item.actorNumber).join(' ') || 'NONE'}.`
      : `A3 PREREQUISITES REFUSED: ${approvalPrerequisiteError}`, approvalPrerequisiteError === null ? 'label' : 'warning');
    builder.text(14, 1, 'APPROVAL MUST BIND THIS EXACT CASE VERSION, MEMBER, ACCOUNT AND EVIDENCE.', 'warning');
    return builder.legend('ENTER=Review  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return inactiveKey();
    const { case: record } = readCase(context, frame.caseId);
    const memberNumber = upper(value(frame, 'member', record.memberNumber).trim());
    const member = findMember(context, memberNumber);
    if (member === undefined) return { kind: 'stay', message: notFound('MEMBER', memberNumber, context), error: 'member' };
    const typed = value(frame, 'account', record.accountNumber ?? '').trim();
    let accountId: string | null = null;
    if (typed !== '') {
      const account = findAccount(context, typed);
      if (account === undefined) return { kind: 'stay', message: notFound('ACCOUNT', typed, context), error: 'account' };
      accountId = account.id;
    }
    const evidenceVersionId = value(frame, 'evidence').trim();
    if (evidenceVersionId === '') return { kind: 'stay', message: failure('CURRENT VERSIONED EVIDENCE IS REQUIRED.'), error: 'evidence' };
    const approvalId = value(frame, 'approval').trim();
    if (approvalId === '') return { kind: 'stay', message: failure('AN APPROVED INDEPENDENT DECISION IS REQUIRED.'), error: 'approval' };
    return beginReview(context, frame, {
      command: { kind: 'case.subject.correct', caseId: record.id, expectedVersion: frame.version, correctMemberId: member.id, correctAccountId: accountId, evidenceVersionId, approvalId },
      screenId: 'THCS10', title: 'Review subject correction',
      lines: [{ label: 'Member', before: record.memberNumber, after: member.memberNumber }, { label: 'Account', before: record.accountNumber ?? 'NONE', after: typed === '' ? 'NONE' : upper(typed) }, { label: 'Evidence', before: '', after: evidenceVersionId }, { label: 'Approval', before: '', after: approvalId }],
      fields: { correctMemberId: 'member', correctAccountId: 'account', evidenceVersionId: 'evidence', approvalId: 'approval' },
    });
  },
  dirty: (frame) => anyEntered(frame, ['member', 'account', 'evidence', 'approval']),
  help: HELP_TOPICS['case-subject-correct'],
};
