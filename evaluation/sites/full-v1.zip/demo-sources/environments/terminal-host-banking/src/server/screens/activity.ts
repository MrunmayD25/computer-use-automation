import { listActivity, type ActivityRow } from '@computer-use/financial-database/services';

import { failure, info, type ActivitySnapshot, type FrameOf } from '../host/frames.js';
import { localDateTime, upper } from '../host/format.js';
import type { ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import {
  accountFrame, badSelection, clampOffset, inactiveKey, label, LIST_ROWS, LIST_TOP, memberFrame, page, pageLabel, readAccount, readMember, rowsLabel, selection, value,
} from './common.js';
import { HELP_TOPICS } from './help-text.js';

function snapshot(row: ActivityRow): ActivitySnapshot {
  return {
    sequence: row.sequence, occurredAt: row.occurredAt, kind: row.kind, resourceKind: row.resourceKind, resourceId: row.resourceId, summary: row.summary,
    actor: row.actor === null ? 'SYSTEM' : `${row.actor.actorNumber} ${row.actor.displayName}`, operationId: row.operationId, operationStatus: row.operationStatus, receiptNumber: row.receiptNumber,
  };
}

const receiptFrame = (receiptNumber: string) => ({ kind: 'receipt' as const, values: {}, receiptNumber, offset: 0, replayed: false });

export const activityScreen: ScreenModule<FrameOf<'activity'>> = {
  render(context, frame) {
    const { timeZone } = context.session().institution;
    const scope = { ...(frame.memberId === null ? {} : { memberId: frame.memberId }), ...(frame.accountId === null ? {} : { accountId: frame.accountId }) };
    const query = (offset: number) => context.read((database, datasetId) => listActivity(database, datasetId, { ...scope, kind: frame.criteria.kind, query: frame.criteria.query, limit: LIST_ROWS, offset }));
    let result = query(frame.offset);
    const clamped = clampOffset(frame.offset, LIST_ROWS, result.total);
    if (clamped !== frame.offset) {
      frame.offset = clamped;
      result = query(clamped);
    }
    frame.rows = result.items.map(snapshot);
    frame.total = result.total;
    const builder = new ScreenBuilder('THAV01', 'Activity inquiry');
    builder.page = pageLabel(frame.offset, LIST_ROWS, result.total);
    if (frame.accountId !== null) {
      const { account } = readAccount(context, frame.accountId);
      label(builder, 3, 1, 'Scope', 8).text(3, 9, 'ACCOUNT', 'label').data(3, 17, 10, account.accountNumber).data(3, 28, 50, account.ownerName, 'emphasis');
    } else if (frame.memberId !== null) {
      const { member } = readMember(context, frame.memberId);
      label(builder, 3, 1, 'Scope', 8).text(3, 9, 'MEMBER', 'label').data(3, 17, 10, member.memberNumber).data(3, 28, 50, member.displayName, 'emphasis');
    } else {
      label(builder, 3, 1, 'Scope', 8).text(3, 9, 'ALL ACTIVITY AT THIS INSTITUTION', 'label');
    }
    label(builder, 4, 1, 'Event kind', 12).input('kind', 4, 13, 30, value(frame, 'kind', frame.criteria.kind));
    label(builder, 4, 45, 'Text/receipt', 14).input('query', 4, 59, 20, value(frame, 'query', frame.criteria.query));
    for (const [at, text] of [[1, 'S'], [3, 'OCCURRED'], [20, 'EVENT KIND'], [39, 'SUMMARY'], [60, 'OPR'], [67, 'RECEIPT']] as const) builder.text(6, at, text, 'label');
    frame.rows.forEach((row, index) => {
      const line = LIST_TOP + index;
      builder.input(`sel.${index}`, line, 1, 1, value(frame, `sel.${index}`));
      builder.data(line, 3, 16, localDateTime(row.occurredAt, timeZone)).data(line, 20, 18, row.kind).data(line, 39, 20, row.summary)
        .data(line, 60, 6, row.actor === 'SYSTEM' ? 'SYSTEM' : row.actor.slice(0, 6), 'label').data(line, 67, 11, row.receiptNumber ?? '');
    });
    if (result.total === 0) builder.text(LIST_TOP, 3, 'NO COMMITTED EVENTS MATCH.', 'warning');
    builder.text(19, 1, 'SEL: S=RECEIPT, OR THE EVENT WHEN THERE IS NO RECEIPT  E=EVENT DETAIL', 'label');
    builder.data(20, 1, 40, rowsLabel(frame.offset, frame.rows.length, result.total), 'label').text(20, 44, 'NEWEST FIRST. KIND MATCHES EXACTLY.', 'label');
    return builder.legend('ENTER=Filter/Select  F1=Help  F3=Return  F7=Up  F8=Down');
  },
  input(_context, frame, event) {
    const paged = page(frame, event.aid, LIST_ROWS, frame.total);
    if (paged !== null) return paged;
    if (event.aid !== 'enter') return inactiveKey();
    if (event.modified.has('kind') || event.modified.has('query')) {
      frame.criteria = { kind: value(frame, 'kind', frame.criteria.kind).trim().toLowerCase(), query: value(frame, 'query', frame.criteria.query).trim() };
      frame.offset = 0;
      delete frame.values.kind;
      delete frame.values.query;
      selection(frame, frame.rows.length);
      return { kind: 'stay', message: info('FILTER APPLIED.') };
    }
    const picked = selection(frame, frame.rows.length);
    if (picked === null) return { kind: 'stay', message: info('TYPE S OR E BESIDE AN EVENT, OR CHANGE THE FILTER.') };
    if ('message' in picked) return { kind: 'stay', message: picked.message, error: picked.error };
    const row = frame.rows[picked.index];
    if (row === undefined) return badSelection(picked.code, 'A LISTED ROW', picked.index);
    frame.cursor = `sel.${picked.index}`;
    if (picked.code === 'S' && row.receiptNumber !== null) return { kind: 'push', frame: receiptFrame(row.receiptNumber) };
    if (picked.code === 'S' || picked.code === 'E') return { kind: 'push', frame: { kind: 'event', values: {}, event: row } };
    return badSelection(picked.code, 'S OR E', picked.index);
  },
  help: HELP_TOPICS.activity,
};

export const eventScreen: ScreenModule<FrameOf<'event'>> = {
  render(context, frame) {
    const { event } = frame;
    const { timeZone } = context.session().institution;
    const builder = new ScreenBuilder('THAV02', 'Event detail');
    label(builder, 3, 1, 'Sequence', 18).data(3, 19, 12, String(event.sequence), 'emphasis');
    label(builder, 4, 1, 'Occurred', 18).data(4, 19, 16, localDateTime(event.occurredAt, timeZone));
    label(builder, 5, 1, 'Event kind', 18).data(5, 19, 40, event.kind);
    label(builder, 6, 1, 'Record', 18).data(6, 19, 60, `${upper(event.resourceKind)} ${event.resourceId}`);
    label(builder, 7, 1, 'Operator', 18).data(7, 19, 60, event.actor);
    label(builder, 8, 1, 'Operation', 18).data(8, 19, 60, event.operationId === null ? 'NONE RECORDED' : `${event.operationId} ${upper(event.operationStatus ?? '')}`);
    label(builder, 9, 1, 'Receipt', 18).data(9, 19, 12, event.receiptNumber ?? 'NONE');
    label(builder, 11, 1, 'Summary', 18);
    builder.data(11, 19, 60, event.summary);
    return builder.legend('F1=Help  F3=Return  F5=Receipt  F6=Open record');
  },
  input(_context, frame, event) {
    const { receiptNumber, resourceKind, resourceId } = frame.event;
    if (event.aid === 'pf5') {
      if (receiptNumber === null) return { kind: 'stay', message: failure('NO RECEIPT IS RECORDED FOR THIS EVENT.') };
      return { kind: 'push', frame: receiptFrame(receiptNumber) };
    }
    if (event.aid === 'pf6') {
      if (resourceKind === 'member') return { kind: 'push', frame: memberFrame(resourceId) };
      if (resourceKind === 'account') return { kind: 'push', frame: accountFrame(resourceId) };
      return { kind: 'stay', message: failure(`NO INQUIRY SCREEN FOR A ${upper(resourceKind)} RECORD.${receiptNumber === null ? '' : ' F5 SHOWS ITS RECEIPT.'}`) };
    }
    return inactiveKey();
  },
  help: HELP_TOPICS.event,
};
