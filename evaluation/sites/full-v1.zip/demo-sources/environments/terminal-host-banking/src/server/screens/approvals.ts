import {
  listApprovals, type Money, type ServiceCommand,
} from '@computer-use/financial-database/services';

import { failure, info, type FrameOf, type Message } from '../host/frames.js';
import { localDateTime, upper, wrap } from '../host/format.js';
import type { HostContext, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { beginReview, cell, findActor, inactiveKey, label, page, pageLabel, value } from './common.js';
import { directoryFrame } from './dirs.js';
import { HELP_TOPICS } from './help-text.js';

interface ApprovalView {
  id: string;
  status: string;
  fingerprint: string;
  makerNumber: string;
  checkerNumber: string;
  makerActorId: string;
  checkerActorId: string;
  expiresAt: string;
  policyVersionId: string;
  amountLimit: Money | null;
  scope: Record<string, unknown>;
}

function loadApproval(context: HostContext, approvalId: string): ApprovalView | Message {
  const listed = context.svc((store, ctx) => listApprovals(store, ctx, 200));
  if (listed.kind !== 'found') return failure(upper(listed.message));
  const summary = listed.approvals.find((item) => item.id === approvalId);
  const row = context.read((database, datasetId) => database.prepare(
    'SELECT a.*,m.actor_number AS maker_number,c.actor_number AS checker_number FROM business_approvals a JOIN actors m ON m.dataset_id=a.dataset_id AND m.id=a.maker_actor_id JOIN actors c ON c.dataset_id=a.dataset_id AND c.id=a.checker_actor_id WHERE a.dataset_id=? AND a.id=?',
  ).get(datasetId, approvalId));
  if (row === undefined) return failure('THE APPROVAL IS ABSENT FROM THIS INSTITUTION.');
  const scope: unknown = JSON.parse(String(row.scope_json ?? '{}'));
  return {
    id: String(row.id), status: String(row.status), fingerprint: summary?.fingerprint ?? '', makerNumber: String(row.maker_number), checkerNumber: String(row.checker_number),
    makerActorId: String(row.maker_actor_id), checkerActorId: String(row.checker_actor_id), expiresAt: String(row.expires_at), policyVersionId: String(row.policy_version_id),
    amountLimit: row.currency === null || row.currency === undefined ? null : { currency: String(row.currency), minorUnits: Number(row.amount_limit_minor_units) },
    scope: scope !== null && typeof scope === 'object' && !Array.isArray(scope) ? scope as Record<string, unknown> : {},
  };
}

function scopeLines(scope: Record<string, unknown>): string[] {
  return Object.entries(scope).flatMap(([key, entry]) => {
    const text = typeof entry === 'string' ? entry : JSON.stringify(entry);
    return wrap(`${key} = ${text}`, 74).map((line, index) => index === 0 ? line : `    ${line}`);
  });
}

const SCOPE_ROWS = 8;

/** Whether this approval's scope is a complete target command the checker can execute directly. */
function executableScope(scope: Record<string, unknown>): boolean {
  return typeof scope.kind === 'string' && scope.kind !== 'batch.contacts.apply' && scope.kind !== 'batch.fee_refunds.apply';
}

export const approvalScreen: ScreenModule<FrameOf<'approval'>> = {
  render(context, frame) {
    const view = loadApproval(context, frame.approvalId);
    const builder = new ScreenBuilder('THAP02', 'Approval decision');
    if ('text' in view) {
      builder.text(4, 1, upper(view.text), 'warning');
      return builder.legend('F3=Return  F12=Cancel');
    }
    const { timeZone } = context.session().institution;
    label(builder, 3, 1, 'Approval', 12).data(3, 13, 40, view.id, 'emphasis');
    label(builder, 4, 1, 'Status', 12).data(4, 13, 12, upper(view.status), view.status === 'approved' ? 'success' : view.status === 'pending' ? 'warning' : 'label');
    label(builder, 4, 26, 'Expires', 9).data(4, 35, 16, localDateTime(view.expiresAt, timeZone));
    label(builder, 5, 1, 'Maker', 12).data(5, 13, 12, view.makerNumber).text(5, 26, 'CHECKER', 'label').data(5, 35, 12, view.checkerNumber);
    label(builder, 6, 1, 'Policy', 12).data(6, 13, 40, view.policyVersionId, 'label');
    if (view.amountLimit !== null) label(builder, 7, 1, 'Limit', 12).data(7, 13, 30, `${String(view.amountLimit.minorUnits)} ${view.amountLimit.currency}`);
    label(builder, 8, 1, 'Fingerprint', 12).data(8, 13, 64, view.fingerprint, 'label');
    builder.text(10, 1, 'REVIEWED TERMS THE APPROVAL BINDS:', 'label');
    const lines = scopeLines(view.scope);
    builder.page = pageLabel(frame.offset, SCOPE_ROWS, lines.length);
    lines.slice(frame.offset, frame.offset + SCOPE_ROWS).forEach((line, index) => builder.data(11 + index, 2, 76, line));
    const pending = view.status === 'pending' && view.checkerActorId === context.session().operator.actorId;
    if (pending) {
      label(builder, 19, 1, 'Decision A=APPROVE D=DENY', 25).input('decision', 19, 26, 1, value(frame, 'decision'));
      label(builder, 20, 1, 'Reason', 12).input('reason', 20, 13, 60, value(frame, 'reason'), { capacity: 500 });
      builder.cursor('decision');
      return builder.legend('ENTER=Submit decision  F1=Help  F3=Return  F7=Up  F8=Down');
    }
    if (view.status === 'approved' && executableScope(view.scope)) builder.text(19, 1, 'F9 EXECUTES THE APPROVED ACTION AS THE ASSIGNED CHECKER.', 'emphasis');
    else if (view.status === 'approved') builder.text(19, 1, 'APPLY EACH BATCH ITEM FROM THE BATCH SCREEN WITH THIS APPROVAL.', 'label');
    return builder.legend('ENTER=Refresh  F9=Execute approved  F1=Help  F3=Return  F7=Up  F8=Down');
  },
  input(context, frame, event) {
    const view = loadApproval(context, frame.approvalId);
    if ('text' in view) return { kind: 'pop', message: view };
    const paged = page(frame, event.aid, SCOPE_ROWS, scopeLines(view.scope).length);
    if (paged !== null) return paged;
    if (event.aid === 'pf9') {
      if (view.status !== 'approved') return { kind: 'stay', message: failure('ONLY AN APPROVED APPROVAL CAN EXECUTE.') };
      if (view.checkerActorId !== context.session().operator.actorId) return { kind: 'stay', message: failure('ONLY THE ASSIGNED CHECKER EXECUTES THIS APPROVAL.') };
      if (!executableScope(view.scope)) return { kind: 'stay', message: failure('CAMPAIGN APPROVALS APPLY PER BATCH ITEM. OPEN THE BATCH FROM THE BATCHES DIRECTORY.') };
      const command = { ...view.scope, approvalId: view.id } as ServiceCommand;
      return beginReview(context, frame, { command, screenId: 'THAP04', title: `Execute ${cell(view.scope.kind)}`, lines: [], fields: {} });
    }
    if (event.aid !== 'enter') return inactiveKey();
    if (view.status !== 'pending' || view.checkerActorId !== context.session().operator.actorId) {
      return { kind: 'stay', message: info('THIS APPROVAL IS NOT A PENDING DECISION FOR YOU.') };
    }
    const decision = upper(value(frame, 'decision').trim());
    if (decision !== 'A' && decision !== 'D') return { kind: 'stay', message: failure('ENTER A TO APPROVE OR D TO DENY.'), error: 'decision' };
    const reason = value(frame, 'reason').trim();
    if (reason === '') return { kind: 'stay', message: failure('A DECISION REASON IS REQUIRED.'), error: 'reason' };
    return beginReview(context, frame, {
      command: { kind: 'approval.decide', approvalId: view.id, expectedFingerprint: view.fingerprint, decision: decision === 'A' ? 'approve' : 'deny', reason },
      screenId: 'THAP05', title: `Review ${decision === 'A' ? 'approval' : 'denial'}`, lines: [], fields: { reason: 'reason' },
    });
  },
  help: HELP_TOPICS.approval,
};

/**
 * The maker's request form: an exact prepared target plus checker, policy, expiry and limit.
 * The target command carries `approvalId: ''`; the stored scope excludes it.
 */
export const approvalRequestScreen: ScreenModule<FrameOf<'approval-request'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THAP03', 'Request approval');
    const { institution } = context.session();
    builder.text(3, 1, 'REQUEST INDEPENDENT APPROVAL OF THE PREPARED ACTION BELOW.', 'emphasis');
    label(builder, 4, 1, 'Target', 20).data(4, 21, 40, frame.command.kind, 'emphasis');
    const shown = frame.lines.slice(0, 6);
    shown.forEach((line, index) => builder.data(5 + index, 2, 16, line.label, 'label').data(5 + index, 19, 60, line.after === '' ? line.before : line.after));
    if (frame.lines.length > shown.length) builder.text(11, 2, `+${frame.lines.length - shown.length} MORE TERMS ON THE ENTRY FORM.`, 'label');
    label(builder, 12, 1, 'Checker', 20).input('checker', 12, 21, 8, value(frame, 'checker')).text(12, 30, 'F4=PICK ELIGIBLE CHECKER', 'label');
    if (value(frame, 'checker.label') !== '') builder.data(13, 21, 50, value(frame, 'checker.label'), 'emphasis');
    label(builder, 14, 1, 'Policy version', 20).input('policy', 14, 21, 40, value(frame, 'policy')).text(14, 62, 'F4=PICK', 'label');
    label(builder, 15, 1, 'Expires at', 20).input('expiry', 15, 21, 20, value(frame, 'expiry', new Date(Date.parse(institution.asOf) + 3 * 86_400_000).toISOString())).text(15, 43, 'ISO UTC, WITHIN 7 DAYS', 'label');
    label(builder, 16, 1, 'Amount limit', 20).input('limit', 16, 21, 16, value(frame, 'limit'), { numeric: true }).text(16, 38, 'CUR', 'label').input('limit.ccy', 16, 42, 3, value(frame, 'limit.ccy')).text(16, 47, 'OPTIONAL', 'label');
    return builder.legend('ENTER=Review request  F1=Help  F3=Return  F12=Cancel');
  },
  input(context, frame, event) {
    if (event.aid === 'pf4') {
      if (event.cursorField === 'checker') return { kind: 'push', frame: directoryFrame('checkers', { kind: frame.command.kind }, 'checker') };
      if (event.cursorField === 'policy') return { kind: 'push', frame: directoryFrame('policies', {}, 'policy') };
      return { kind: 'stay', message: failure('PUT THE CURSOR ON CHECKER OR POLICY TO PICK.') };
    }
    if (event.aid !== 'enter') return inactiveKey();
    const checkerText = value(frame, 'checker').trim();
    if (checkerText === '') return { kind: 'stay', message: failure('PICK THE INDEPENDENT CHECKER.'), error: 'checker' };
    const checker = findActor(context, checkerText)?.id;
    if (checker === undefined) return { kind: 'stay', message: failure('THE OPERATOR IS NOT REGISTERED AT THIS INSTITUTION.'), error: 'checker' };
    const policy = value(frame, 'policy').trim();
    if (policy === '') return { kind: 'stay', message: failure('PICK THE APPROVAL POLICY VERSION.'), error: 'policy' };
    const { institution } = context.session();
    const expiryText = value(frame, 'expiry', new Date(Date.parse(institution.asOf) + 3 * 86_400_000).toISOString()).trim();
    const expiry = Date.parse(expiryText);
    if (!Number.isFinite(expiry)) return { kind: 'stay', message: failure('ENTER THE EXPIRY AS AN ISO UTC INSTANT.'), error: 'expiry' };
    const limitText = value(frame, 'limit').trim();
    let amountLimit: Money | null = null;
    if (limitText !== '') {
      const currency = upper(value(frame, 'limit.ccy').trim());
      const minorUnits = /^\d+$/u.test(limitText) ? Number(limitText) : NaN;
      if (!Number.isSafeInteger(minorUnits) || currency === '') return { kind: 'stay', message: failure('ENTER THE LIMIT AS WHOLE MINOR UNITS AND A CURRENCY CODE.'), error: 'limit' };
      amountLimit = { minorUnits, currency };
    }
    return beginReview(context, frame, {
      command: { kind: 'approval.request', target: frame.command, checkerActorId: checker, policyVersionId: policy, expiresAt: new Date(expiry).toISOString(), amountLimit },
      screenId: 'THAP06', title: `Review approval request for ${frame.command.kind}`,
      lines: [{ label: 'Target', before: '', after: frame.command.kind }, ...frame.lines],
      fields: { checkerActorId: 'checker', policyVersionId: 'policy', expiresAt: 'expiry', amountLimit: 'limit' },
    });
  },
  exit(_context) {
    return { kind: 'pop', message: info('APPROVAL REQUEST CANCELLED. THE ACTION WAS NOT REQUESTED OR APPLIED.') };
  },
  help: HELP_TOPICS['approval-request'],
};

/** The signed-on operator's approvals inbox is the `approvals` directory in browse mode. */
export function approvalsInboxFrame(): FrameOf<'directory'> {
  return directoryFrame('approvals', {}, null);
}
