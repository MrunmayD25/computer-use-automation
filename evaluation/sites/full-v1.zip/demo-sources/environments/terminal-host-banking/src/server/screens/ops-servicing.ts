import { listMemberDocumentVersions } from '@computer-use/financial-database/services';

import { failure } from '../host/frames.js';
import { cell, findCase, isOutcome, readMember, serviceContext } from './common.js';
import { HELP_TOPICS } from './help-text.js';
import { code, date, entered, fieldProblem, idList, instant, num, required, type OpSpec } from './ops.js';
import {
  APPROVAL, approvalId, addressInput, caseRef, CASE_FIELD, codeField, dateField, DOC_VERSION, instantField, memberRef, MEMBER,
  numField, OPT_ACCOUNT, optAccountRef, partyRef, REASON, textField,
} from './ops-common.js';

const help = HELP_TOPICS.opform;

const addressGroup = (prefix: string): OpSpec['fields'] => [
  textField(`${prefix}line1`, 'ADDRESS LINE 1', 40, { capacity: 80, required: false }),
  textField(`${prefix}line2`, 'LINE 2', 40, { capacity: 80, required: false }),
  textField(`${prefix}city`, 'CITY', 20, { capacity: 60, required: false }),
  textField(`${prefix}region`, 'REGION', 12, { capacity: 40, required: false }),
  textField(`${prefix}postal`, 'POSTAL CODE', 12, { capacity: 12, required: false }),
  textField(`${prefix}country`, 'COUNTRY', 2, { capacity: 2, required: false, hint: 'ISO CODE' }),
];

export const SERVICING_OPS: Record<string, OpSpec> = {

  'member.identity_evidence.register': {
    id: 'member.identity_evidence.register', screenId: 'THID01', title: 'Register identity evidence', command: 'member.identity_evidence.register',
    fields: [
      MEMBER, DOC_VERSION,
      codeField('evkind', 'EVIDENCE KIND', { P: 'passport', D: 'drivers-license', N: 'national-id', S: 'state-id' }),
      dateField('issued', 'ISSUED'), dateField('expires', 'EXPIRES'),
      textField('reference', 'REFERENCE', 40, { capacity: 200 }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const version = entered(frame, 'version');
      if (version === '') return fieldProblem('version', 'PICK THE SOURCE DOCUMENT VERSION.');
      const kind = code(frame, 'evkind', { P: 'passport', D: 'drivers-license', N: 'national-id', S: 'state-id' }, 'EVIDENCE KIND');
      if (isOutcome(kind)) return kind;
      const issued = date(frame, 'issued', 'ISSUED'); if (isOutcome(issued) || issued === null) return issued ?? fieldProblem('issued', 'ENTER ISSUED.');
      const expires = date(frame, 'expires', 'EXPIRES'); if (isOutcome(expires) || expires === null) return expires ?? fieldProblem('expires', 'ENTER EXPIRES.');
      const reference = required(frame, 'reference', 'REFERENCE'); if (isOutcome(reference)) return reference;
      return {
        command: { kind: 'member.identity_evidence.register', memberId: member.memberId, documentVersionId: version, evidenceKind: kind as 'passport', issuedAt: issued, expiresAt: expires, reference },
        lines: [{ label: 'Member', before: '', after: member.number }, { label: 'Kind', before: '', after: kind }, { label: 'Reference', before: '', after: reference }],
      };
    },
    help,
  },

  'member.identity.verify': {
    id: 'member.identity.verify', screenId: 'THID02', title: 'Verify identity', command: 'member.identity.verify',
    fields: [
      MEMBER,
      { name: 'evidence', label: 'EVIDENCE', width: 40, pick: { dir: 'identity-evidence', scope: { memberId: 'member' } }, hint: 'F4=PICK EVIDENCE' },
      textField('method', 'METHOD', 20, { hint: 'IN-PERSON, DOCUMENTARY...' }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const evidence = required(frame, 'evidence', 'EVIDENCE'); if (isOutcome(evidence)) return evidence;
      const method = required(frame, 'method', 'METHOD'); if (isOutcome(method)) return method;
      return {
        command: { kind: 'member.identity.verify', memberId: member.memberId, evidenceId: evidence, method },
        lines: [{ label: 'Member', before: '', after: member.number }, { label: 'Method', before: '', after: method }],
      };
    },
    help,
  },

  'member.legal_name.update': {
    id: 'member.legal_name.update', screenId: 'THID03', title: 'Update legal name', command: 'member.legal_name.update',
    fields: [
      MEMBER,
      textField('given', 'LEGAL GIVEN', 30, { capacity: 60 }), textField('family', 'LEGAL FAMILY', 30, { capacity: 60 }),
      { name: 'evidence', label: 'EVIDENCE', width: 40, pick: { dir: 'identity-evidence', scope: { memberId: 'member' } }, hint: 'F4=PICK VERIFIED EVIDENCE' },
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const given = required(frame, 'given', 'LEGAL GIVEN'); if (isOutcome(given)) return given;
      const family = required(frame, 'family', 'LEGAL FAMILY'); if (isOutcome(family)) return family;
      const evidence = required(frame, 'evidence', 'EVIDENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'member.legal_name.update', memberId: member.memberId, expectedVersion: member.version, legalGiven: given, legalFamily: family, evidenceId: evidence, approvalId: approvalId(frame) },
        lines: [{ label: 'Legal name', before: '', after: `${given} ${family}` }],
      };
    },
    help,
  },

  'member.preferred_name.update': {
    id: 'member.preferred_name.update', screenId: 'THID04', title: 'Update preferred name', command: 'member.preferred_name.update',
    fields: [
      MEMBER,
      textField('preferred', 'PREFERRED NAME', 40, { capacity: 60, required: false, hint: 'BLANK CLEARS' }),
      codeField('scope', 'COMM SCOPE', { S: 'servicing', C: 'communications', A: 'all' }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const preferred = entered(frame, 'preferred');
      const scope = code(frame, 'scope', { S: 'servicing', C: 'communications', A: 'all' }, 'COMMUNICATION SCOPE'); if (isOutcome(scope)) return scope;
      return {
        command: { kind: 'member.preferred_name.update', memberId: member.memberId, expectedVersion: member.version, preferredName: preferred === '' ? null : preferred, communicationScope: scope },
        lines: [{ label: 'Preferred', before: '', after: preferred === '' ? '(cleared)' : preferred }],
      };
    },
    help,
  },

  'document.index': {
    id: 'document.index', screenId: 'THDC02', title: 'Index document', command: 'document.index',
    fields: [
      MEMBER, OPT_ACCOUNT,
      textField('doctype', 'DOCUMENT TYPE', 24, { capacity: 60 }), textField('name', 'DISPLAY NAME', 40, { capacity: 200 }),
      textField('retention', 'RETENTION CLASS', 20, { capacity: 40 }),
      textField('content', 'CONTENT', 58, { capacity: 2000, kind: 'paragraph', hint: 'TEXT BODY INDEXED AS BYTES' }),
      textField('media', 'MEDIA TYPE', 20, { required: false, hint: 'DEFAULT TEXT/PLAIN' }),
      { name: 'attach', label: 'ATTACH TO DOC ID', width: 40, required: false, hint: 'BLANK = NEW DOCUMENT' },
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const account = optAccountRef(context, frame); if (isOutcome(account)) return account;
      const doctype = required(frame, 'doctype', 'DOCUMENT TYPE'); if (isOutcome(doctype)) return doctype;
      const name = required(frame, 'name', 'DISPLAY NAME'); if (isOutcome(name)) return name;
      const retention = required(frame, 'retention', 'RETENTION CLASS'); if (isOutcome(retention)) return retention;
      const content = required(frame, 'content', 'CONTENT'); if (isOutcome(content)) return content;
      const media = entered(frame, 'media');
      const attach = entered(frame, 'attach');
      return {
        command: {
          kind: 'document.index', memberId: member.memberId, ownerPartyId: readMember(context, member.memberId).member.partyId,
          accountId: account?.accountId ?? null, documentType: doctype, displayName: name, retentionClass: retention,
          bytes: new TextEncoder().encode(content), ...(media === '' ? {} : { mediaType: media }), ...(attach === '' ? {} : { documentId: attach }),
        },
        lines: [{ label: 'Document', before: '', after: `${name} (${doctype})` }, { label: 'Bytes', before: '', after: `${new TextEncoder().encode(content).byteLength}` }],
      };
    },
    help,
  },

  'document.bundle.redact': {
    id: 'document.bundle.redact', screenId: 'THDC03', title: 'Redact document bundle', command: 'document.bundle.redact',
    fields: [
      MEMBER,
      { name: 'sources', label: 'SOURCE VERSIONS', width: 58, kind: 'idlist', required: true, hint: 'SPACE-SEPARATED VERSION IDS' },
      textField('purpose', 'RECIPIENT PURPOSE', 40, { capacity: 200 }),
      { name: 'policy', label: 'REDACTION POLICY', width: 40, pick: { dir: 'policies' }, hint: 'F4=PICK' },
      textField('name', 'DISPLAY NAME', 40, { capacity: 200, required: false }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const sources = idList(frame, 'sources', 'SOURCE VERSIONS', { required: true }); if (!Array.isArray(sources)) return sources;
      const purpose = required(frame, 'purpose', 'RECIPIENT PURPOSE'); if (isOutcome(purpose)) return purpose;
      const policy = required(frame, 'policy', 'REDACTION POLICY'); if (isOutcome(policy)) return policy;
      const name = entered(frame, 'name');
      return {
        command: { kind: 'document.bundle.redact', memberId: member.memberId, sourceVersionIds: sources, recipientPurpose: purpose, redactionPolicyVersionId: policy, approvedExcerpts: [], ...(name === '' ? {} : { displayName: name }) },
        lines: [{ label: 'Sources', before: '', after: `${sources.length} version(s)` }, { label: 'Purpose', before: '', after: purpose }],
      };
    },
    help,
  },

  'document.signature.collect': {
    id: 'document.signature.collect', screenId: 'THDC04', title: 'Signature collect', command: 'document.signature.collect',
    fields: [
      MEMBER, DOC_VERSION,
      codeField('action', 'ACTION', { R: 'request', S: 'sign', D: 'decline', E: 'expire' }),
      textField('signers', 'SIGNER PARTY IDS', 58, { capacity: 500, kind: 'idlist', hint: 'SPACE-SEPARATED' }),
      textField('channel', 'CHANNEL', 16, { capacity: 40 }),
      textField('evidref', 'EVIDENCE REFERENCE', 40, { required: false, hint: 'REQUIRED FOR SIGN/DECLINE/EXPIRE' }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const version = required(frame, 'version', 'DOCUMENT VERSION'); if (isOutcome(version)) return version;
      const action = code(frame, 'action', { R: 'request', S: 'sign', D: 'decline', E: 'expire' }, 'ACTION');
      if (isOutcome(action)) return action;
      const signers = idList(frame, 'signers', 'SIGNER PARTY IDS', { required: true }); if (!Array.isArray(signers)) return signers;
      const channel = required(frame, 'channel', 'CHANNEL'); if (isOutcome(channel)) return channel;
      const evidref = entered(frame, 'evidref');
      return {
        command: { kind: 'document.signature.collect', action: action as 'request', documentVersionId: version, signerPartyIds: signers, channel, ...(evidref === '' ? {} : { evidenceReference: evidref }) },
        lines: [{ label: 'Action', before: '', after: action }, { label: 'Version', before: '', after: version }],
      };
    },
    help,
  },

  'consent.delivery.record': {
    id: 'consent.delivery.record', screenId: 'THCN01', title: 'Record consent delivery', command: 'consent.delivery.record',
    fields: [
      MEMBER, OPT_ACCOUNT,
      textField('purpose', 'PURPOSE', 24, { capacity: 60 }), textField('channel', 'CHANNEL', 16, { capacity: 40 }),
      { name: 'disclosure', label: 'DISCLOSURE VERSION', width: 40, pick: { dir: 'documents', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      textField('evidence', 'EVIDENCE', 50, { capacity: 200 }),
    ],
    build(context, frame) {
      const party = partyRef(context, frame); if (isOutcome(party)) return party;
      const account = optAccountRef(context, frame); if (isOutcome(account)) return account;
      const purpose = required(frame, 'purpose', 'PURPOSE'); if (isOutcome(purpose)) return purpose;
      const channel = required(frame, 'channel', 'CHANNEL'); if (isOutcome(channel)) return channel;
      const disclosure = required(frame, 'disclosure', 'DISCLOSURE VERSION'); if (isOutcome(disclosure)) return disclosure;
      const evidence = required(frame, 'evidence', 'EVIDENCE'); if (isOutcome(evidence)) return evidence;
      return {
        command: { kind: 'consent.delivery.record', partyId: party.partyId, accountId: account?.accountId ?? null, purpose, channel, disclosureVersionId: disclosure, evidence },
        lines: [{ label: 'Consent', before: '', after: `${purpose} via ${channel}` }],
      };
    },
    help,
  },

  'consent.withdraw': {
    id: 'consent.withdraw', screenId: 'THCN02', title: 'Withdraw consent', command: 'consent.withdraw',
    fields: [
      MEMBER,
      { name: 'consent', label: 'CONSENT', width: 40, pick: { dir: 'consents', scope: { memberId: 'member' } }, hint: 'F4=PICK CONSENT' },
      textField('channels', 'AFFECTED CHANNELS', 40, { capacity: 200, kind: 'idlist', hint: 'SPACE-SEPARATED' }),
      instantField('when', 'EFFECTIVE AT', false),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const consent = required(frame, 'consent', 'CONSENT'); if (isOutcome(consent)) return consent;
      const channels = idList(frame, 'channels', 'AFFECTED CHANNELS', { required: true }); if (!Array.isArray(channels)) return channels;
      const when = instant(frame, 'when', 'EFFECTIVE AT'); if (isOutcome(when)) return when;
      return {
        command: { kind: 'consent.withdraw', consentId: consent, affectedChannels: channels, ...(when === null ? {} : { effectiveAt: when }) },
        lines: [{ label: 'Consent', before: 'granted', after: 'withdrawn' }],
      };
    },
    help,
  },

  'document.customer_export.create': {
    id: 'document.customer_export.create', screenId: 'THEX01', title: 'Customer document export', command: 'document.customer_export.create',
    fields: [
      MEMBER,
      textField('categories', 'CATEGORIES', 50, { kind: 'idlist', hint: 'SPACE-SEPARATED EXPORT CATEGORIES' }),
      dateField('from', 'FROM', false), dateField('through', 'THROUGH', false),
      textField('destination', 'DESTINATION', 40, { hint: 'APPROVED DESTINATION ID' }),
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const categories = idList(frame, 'categories', 'CATEGORIES', { required: true }); if (!Array.isArray(categories)) return categories;
      const from = date(frame, 'from', 'FROM'); if (isOutcome(from)) return from;
      const through = date(frame, 'through', 'THROUGH'); if (isOutcome(through)) return through;
      const destination = required(frame, 'destination', 'DESTINATION'); if (isOutcome(destination)) return destination;
      const inventory = context.read((database) => {
        const result = listMemberDocumentVersions(database, serviceContext(context, 'export-preflight'), member.memberId, undefined, 500);
        return result.kind === 'authorized' ? result.value : [];
      });
      const documentVersionIds = inventory.map((version) => version.versionId);
      if (documentVersionIds.length === 0) return { kind: 'stay', message: failure('THE MEMBER HAS NO DOCUMENT VERSIONS TO EXPORT.') };
      return {
        command: { kind: 'document.customer_export.create', memberId: member.memberId, categories, from, through, destination, approvalId: approvalId(frame), documentVersionIds },
        lines: [{ label: 'Export', before: '', after: `${categories.join(', ')} (${documentVersionIds.length} versions)` }, { label: 'Destination', before: '', after: destination }],
      };
    },
    help,
  },

  'document.retention_hold.apply': {
    id: 'document.retention_hold.apply', screenId: 'THRH01', title: 'Apply retention hold', command: 'document.retention_hold.apply',
    fields: [
      MEMBER,
      { name: 'document', label: 'DOCUMENT ID', width: 40, required: false, pick: { dir: 'documents', scope: { memberId: 'member' } }, hint: 'F4=PICK VERSION; BLANK IF CASE' },
      { name: 'caseId', label: 'OR CASE', width: 10, required: false, pick: { dir: 'cases', scope: { memberId: 'member' } } },
      REASON,
      { name: 'review', label: 'REVIEW AT', width: 20, hint: 'YYYY-MM-DD OR ISO UTC INSTANT' },
      APPROVAL,
    ],
    build(context, frame) {
      const documentText = entered(frame, 'document');
      const caseText = entered(frame, 'caseId');
      if (documentText === '' && caseText === '') return fieldProblem('document', 'PICK A DOCUMENT VERSION OR A CASE.');
      const reason = required(frame, 'reason', 'REASON'); if (isOutcome(reason)) return reason;
      const reviewText = entered(frame, 'review');
      const review = /^\d{4}-\d{2}-\d{2}$/u.test(reviewText) ? reviewText : (() => { const parsed = instant(frame, 'review', 'REVIEW AT'); return isOutcome(parsed) ? null : parsed; })();
      if (review === null) return fieldProblem('review', 'ENTER REVIEW AT AS YYYY-MM-DD OR AN ISO UTC INSTANT.');
      let documentId: string | undefined;
      if (documentText !== '') {
        const hit = context.read((database, datasetId) => database.prepare('SELECT document_id FROM document_versions WHERE dataset_id=? AND id=?').get(datasetId, documentText) as { document_id?: string } | undefined);
        if (hit === undefined) return fieldProblem('document', 'DOCUMENT VERSION NOT FOUND.');
        documentId = String(hit.document_id);
      }
      let holdCaseId: string | undefined;
      if (documentText === '' && caseText !== '') {
        const found = findCase(context, caseText);
        if (found === undefined) return fieldProblem('caseId', 'CASE NOT FOUND.');
        holdCaseId = found.id;
      }
      return {
        command: { kind: 'document.retention_hold.apply', reason, reviewAt: review, approvalId: approvalId(frame), ...(documentId === undefined ? {} : { documentId }), ...(holdCaseId === undefined ? {} : { caseId: holdCaseId }) },
        lines: [{ label: 'Hold on', before: '', after: documentText === '' ? `case ${caseText}` : `document ${documentText.slice(-20)}` }],
      };
    },
    help,
  },

  'case.information.request': {
    id: 'case.information.request', screenId: 'THIR01', title: 'Request case information', command: 'case.information.request',
    fields: [
      CASE_FIELD,
      textField('fields', 'FIELDS', 58, { kind: 'idlist', hint: 'SPACE-SEPARATED FIELD NAMES' }),
      textField('recipient', 'RECIPIENT PARTY', 40),
      textField('channel', 'CHANNEL', 16, { capacity: 40 }),
      instantField('due', 'DUE AT'),
      textField('destination', 'DESTINATION', 40, { required: false }),
      { name: 'attach', label: 'ATTACHMENT VERSION', width: 40, required: false, hint: 'OPTIONAL' },
    ],
    build(context, frame) {
      const caseHit = caseRef(context, frame); if (isOutcome(caseHit)) return caseHit;
      const fields = idList(frame, 'fields', 'FIELDS', { required: true }); if (!Array.isArray(fields)) return fields;
      const recipient = required(frame, 'recipient', 'RECIPIENT PARTY'); if (isOutcome(recipient)) return recipient;
      const channel = required(frame, 'channel', 'CHANNEL'); if (isOutcome(channel)) return channel;
      const due = instant(frame, 'due', 'DUE AT'); if (isOutcome(due) || due === null) return due ?? fieldProblem('due', 'ENTER DUE AT.');
      const destination = entered(frame, 'destination');
      const attach = entered(frame, 'attach');
      return {
        command: { kind: 'case.information.request', caseId: caseHit.caseId, expectedVersion: caseHit.version, fields, recipientPartyId: recipient, channel, dueAt: due, ...(destination === '' ? {} : { destination }), ...(attach === '' ? {} : { documentVersionId: attach }) },
        lines: [{ label: 'Case', before: '', after: caseHit.number }, { label: 'Request', before: '', after: `${fields.length} field(s) via ${channel}` }],
      };
    },
    help,
  },

  'case.escalate': {
    id: 'case.escalate', screenId: 'THES01', title: 'Escalate case', command: 'case.escalate',
    fields: [CASE_FIELD, textField('rule', 'ESCALATION RULE', 30, { capacity: 80 })],
    build(context, frame) {
      const caseHit = caseRef(context, frame); if (isOutcome(caseHit)) return caseHit;
      const rule = required(frame, 'rule', 'ESCALATION RULE'); if (isOutcome(rule)) return rule;
      return {
        command: { kind: 'case.escalate', caseId: caseHit.caseId, expectedVersion: caseHit.version, escalationRule: rule },
        lines: [{ label: 'Case', before: '', after: caseHit.number }, { label: 'Rule', before: '', after: rule }],
      };
    },
    help,
  },

  'maintenance.address.reconcile': {
    id: 'maintenance.address.reconcile', screenId: 'THAR01', title: 'Reconcile address conflict', command: 'maintenance.address.reconcile',
    fields: [
      MEMBER,
      { name: 'conflict', label: 'CONFLICTING ADDRESS', width: 40, pick: { dir: 'addresses', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      { name: 'winversion', label: 'WINNING VERSION', width: 40, pick: { dir: 'documents', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      textField('windigest', 'WINNING DIGEST', 64, { capacity: 64 }),
      textField('precedence', 'PRECEDENCE', 20, { capacity: 40 }),
      ...addressGroup(''),
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const conflict = required(frame, 'conflict', 'CONFLICTING ADDRESS'); if (isOutcome(conflict)) return conflict;
      const winversion = required(frame, 'winversion', 'WINNING EVIDENCE VERSION'); if (isOutcome(winversion)) return winversion;
      const windigest = required(frame, 'windigest', 'WINNING EVIDENCE DIGEST'); if (isOutcome(windigest)) return windigest;
      const precedence = required(frame, 'precedence', 'PRECEDENCE'); if (isOutcome(precedence)) return precedence;
      const address = addressInput(context, frame, '', { required: true }); if (isOutcome(address) || address === null) return address ?? fieldProblem('line1', 'ENTER THE CANONICAL ADDRESS.');
      return {
        command: { kind: 'maintenance.address.reconcile', memberId: member.memberId, expectedMemberVersion: member.version, conflictingAddressId: conflict, winningEvidenceVersionId: winversion, winningEvidenceDigest: windigest, precedence, address, approvalId: approvalId(frame) },
        lines: [{ label: 'Member', before: '', after: member.number }, { label: 'Canonical', before: '', after: `${address.line1}, ${address.city}` }],
      };
    },
    help,
  },

  'maintenance.address.destination.update': {
    id: 'maintenance.address.destination.update', screenId: 'THAR02', title: 'Update address destination', command: 'maintenance.address.destination.update',
    fields: [
      MEMBER,
      codeField('context', 'CONTEXT', { M: 'member-mailing', S: 'account-statement', C: 'card-shipping', L: 'loan-notice' }),
      textField('target', 'TARGET ID', 40, { hint: 'MEMBER/ACCOUNT/CARD/LOAN ID' }),
      { name: 'address', label: 'PARTY ADDRESS', width: 40, pick: { dir: 'addresses', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      { name: 'evversion', label: 'EVIDENCE VERSION', width: 40, pick: { dir: 'documents', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      dateField('effective', 'EFFECTIVE DATE'),
      { name: 'current', label: 'CURRENT DESTINATION', width: 40, required: false, pick: { dir: 'address-destinations', scope: { memberId: 'member' } }, hint: 'F4=PICK OR BLANK=NONE' },
      { name: 'consent', label: 'CONSENT', width: 40, required: false, pick: { dir: 'consents', scope: { memberId: 'member' } }, hint: 'F4=PICK OR BLANK=NONE' },
      APPROVAL,
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const ctx = code(frame, 'context', { M: 'member-mailing', S: 'account-statement', C: 'card-shipping', L: 'loan-notice' }, 'CONTEXT');
      if (isOutcome(ctx)) return ctx;
      const target = required(frame, 'target', 'TARGET ID'); if (isOutcome(target)) return target;
      const address = required(frame, 'address', 'PARTY ADDRESS'); if (isOutcome(address)) return address;
      const evversion = required(frame, 'evversion', 'EVIDENCE VERSION'); if (isOutcome(evversion)) return evversion;
      const effective = date(frame, 'effective', 'EFFECTIVE DATE'); if (isOutcome(effective) || effective === null) return effective ?? fieldProblem('effective', 'ENTER EFFECTIVE DATE.');
      const current = entered(frame, 'current');
      const consent = entered(frame, 'consent');
      return {
        command: {
          kind: 'maintenance.address.destination.update', memberId: member.memberId, context: ctx as 'member-mailing', targetId: target, addressId: address,
          evidenceVersionId: evversion, effectiveDate: effective, expectedCurrentDestinationId: current === '' ? null : current, consentId: consent === '' ? null : consent, approvalId: approvalId(frame),
        },
        lines: [{ label: 'Destination', before: '', after: `${ctx} -> ${address.slice(-20)}` }],
      };
    },
    help,
  },

  'case.close': {
    id: 'case.close', screenId: 'THCC01', title: 'Close case', command: 'case.close',
    fields: [
      CASE_FIELD,
      textField('code', 'RESOLUTION CODE', 20, { capacity: 40 }),
      { name: 'effect', label: 'EFFECT EVIDENCE', width: 40, pick: { dir: 'documents' }, hint: 'F4=PICK VERSION' },
    ],
    build(context, frame) {
      const caseHit = caseRef(context, frame); if (isOutcome(caseHit)) return caseHit;
      const code = required(frame, 'code', 'RESOLUTION CODE'); if (isOutcome(code)) return code;
      const effect = required(frame, 'effect', 'EFFECT EVIDENCE'); if (isOutcome(effect)) return effect;
      return {
        command: { kind: 'case.close', caseId: caseHit.caseId, expectedVersion: caseHit.version, resolutionCode: code, effectEvidenceVersionId: effect },
        lines: [{ label: 'Case', before: '', after: caseHit.number }, { label: 'Resolution', before: '', after: code }],
      };
    },
    help,
  },

  'case.reopen': {
    id: 'case.reopen', screenId: 'THCC02', title: 'Reopen case', command: 'case.reopen',
    fields: [
      CASE_FIELD,
      { name: 'evidence', label: 'EVIDENCE VERSION', width: 40, pick: { dir: 'documents' }, hint: 'F4=PICK' },
      textField('basis', 'REOPENING BASIS', 50, { capacity: 200 }),
      instantField('due', 'DUE AT', false),
    ],
    build(context, frame) {
      const caseHit = caseRef(context, frame); if (isOutcome(caseHit)) return caseHit;
      const evidence = required(frame, 'evidence', 'EVIDENCE VERSION'); if (isOutcome(evidence)) return evidence;
      const basis = required(frame, 'basis', 'REOPENING BASIS'); if (isOutcome(basis)) return basis;
      const due = instant(frame, 'due', 'DUE AT'); if (isOutcome(due)) return due;
      return {
        command: { kind: 'case.reopen', caseId: caseHit.caseId, expectedVersion: caseHit.version, evidenceVersionId: evidence, reopeningBasis: basis, ...(due === null ? {} : { dueAt: due }) },
        lines: [{ label: 'Case', before: '', after: `${caseHit.number} reopens` }],
      };
    },
    help,
  },

  'document.annotation.update': {
    id: 'document.annotation.update', screenId: 'THAN01', title: 'Annotate document', command: 'document.annotation.update',
    fields: [
      { name: 'version', label: 'DOCUMENT VERSION', width: 40, pick: { dir: 'documents' }, hint: 'F4=PICK' },
      numField('page', 'PAGE'),
      numField('x', 'X MICROS'), numField('y', 'Y MICROS'), numField('w', 'W MICROS'), numField('h', 'H MICROS'),
      codeField('action', 'ACTION', { C: 'create', A: 'amend', R: 'remove' }),
      { name: 'annotation', label: 'ANNOTATION ID', width: 40, required: false, pick: { dir: 'annotations', scope: { versionId: 'version' } }, hint: 'FOR AMEND/REMOVE' },
      textField('note', 'TEXT', 58, { capacity: 2000, required: false }),
    ],
    build(_context, frame) {
      const version = required(frame, 'version', 'DOCUMENT VERSION'); if (isOutcome(version)) return version;
      const page = num(frame, 'page', 'PAGE', { min: 1 }); if (isOutcome(page)) return page;
      const x = num(frame, 'x', 'X MICROS'); if (isOutcome(x)) return x;
      const y = num(frame, 'y', 'Y MICROS'); if (isOutcome(y)) return y;
      const w = num(frame, 'w', 'W MICROS'); if (isOutcome(w)) return w;
      const h = num(frame, 'h', 'H MICROS'); if (isOutcome(h)) return h;
      const action = code(frame, 'action', { C: 'create', A: 'amend', R: 'remove' }, 'ACTION'); if (isOutcome(action)) return action;
      const annotation = entered(frame, 'annotation');
      const fp = entered(frame, 'annotation.fp');
      const note = entered(frame, 'note');
      return {
        command: {
          kind: 'document.annotation.update', documentVersionId: version, pageNumber: page, regionMicros: { x, y, width: w, height: h }, action: action as 'create',
          ...(annotation === '' ? {} : { annotationId: annotation, expectedAnnotationFingerprint: fp }), ...(note === '' ? {} : { text: note }),
        },
        lines: [{ label: 'Annotation', before: '', after: `${action} on page ${page}` }],
      };
    },
    help,
  },

  'document.metadata.update': {
    id: 'document.metadata.update', screenId: 'THMD01', title: 'Update document metadata', command: 'document.metadata.update',
    fields: [
      { name: 'document', label: 'DOCUMENT ID', width: 40, hint: 'F4=PICK FROM MEMBER DOCS' },
      textField('doctype', 'TYPE', 24, { capacity: 60 }), textField('name', 'DISPLAY NAME', 40, { capacity: 200 }),
      textField('retention', 'RETENTION CLASS', 20, { capacity: 40 }),
      textField('owner', 'OWNER PARTY ID', 40), { name: 'acct', label: 'ACCOUNT ID', width: 40, required: false },
      APPROVAL,
    ],
    build(context, frame) {
      const documentId = required(frame, 'document', 'DOCUMENT ID'); if (isOutcome(documentId)) return documentId;
      const stored = context.read((database, datasetId) => database.prepare('SELECT owner_party_id,account_id,document_type,display_name,retention_class FROM documents WHERE dataset_id=? AND id=?').get(datasetId, documentId) as Record<string, unknown> | undefined);
      if (stored === undefined) return fieldProblem('document', 'DOCUMENT NOT FOUND.');
      const doctype = required(frame, 'doctype', 'TYPE'); if (isOutcome(doctype)) return doctype;
      const name = required(frame, 'name', 'DISPLAY NAME'); if (isOutcome(name)) return name;
      const retention = required(frame, 'retention', 'RETENTION CLASS'); if (isOutcome(retention)) return retention;
      const owner = required(frame, 'owner', 'OWNER PARTY ID'); if (isOutcome(owner)) return owner;
      const acct = entered(frame, 'acct');
      const approval = entered(frame, 'approvalId');
      return {
        command: {
          kind: 'document.metadata.update', documentId,
          expectedMetadata: { ownerPartyId: String(stored.owner_party_id), accountId: stored.account_id === null ? null : cell(stored.account_id), documentType: String(stored.document_type), displayName: String(stored.display_name), retentionClass: String(stored.retention_class) },
          documentType: doctype, displayName: name, ownerPartyId: owner, accountId: acct === '' ? null : acct, retentionClass: retention,
          ...(approval === '' ? {} : { approvalId: approval }),
        },
        lines: [{ label: 'Document', before: String(stored.display_name), after: name }],
      };
    },
    help,
  },

  'communication.preference.update': {
    id: 'communication.preference.update', screenId: 'THCP01', title: 'Update communication preference', command: 'communication.preference.update',
    fields: [
      MEMBER,
      textField('purpose', 'PURPOSE', 24, { capacity: 60 }), textField('channel', 'CHANNEL', 16, { capacity: 40 }),
      codeField('state', 'STATE', { E: 'enabled', D: 'disabled' }),
    ],
    build(context, frame) {
      const party = partyRef(context, frame); if (isOutcome(party)) return party;
      const purpose = required(frame, 'purpose', 'PURPOSE'); if (isOutcome(purpose)) return purpose;
      const channel = required(frame, 'channel', 'CHANNEL'); if (isOutcome(channel)) return channel;
      const state = code(frame, 'state', { E: 'enabled', D: 'disabled' }, 'STATE'); if (isOutcome(state)) return state;
      return {
        command: { kind: 'communication.preference.update', partyId: party.partyId, purpose, channel, state: state as 'enabled' },
        lines: [{ label: 'Preference', before: '', after: `${purpose} ${channel} ${state}` }],
      };
    },
    help,
  },

  'communication.send': {
    id: 'communication.send', screenId: 'THCS01', title: 'Send communication', command: 'communication.send',
    fields: [
      MEMBER,
      codeField('channel', 'CHANNEL', { E: 'email', M: 'mail' }),
      textField('purpose', 'PURPOSE', 24, { capacity: 60 }),
      { name: 'version', label: 'DOCUMENT VERSION', width: 40, pick: { dir: 'documents', scope: { memberId: 'member' } }, hint: 'F4=PICK' },
      textField('destination', 'DESTINATION', 40, { required: false, hint: 'EMAIL ADDRESS FOR EMAIL' }),
      { name: 'destid', label: 'ADDRESS DESTINATION', width: 40, required: false, pick: { dir: 'address-destinations', scope: { memberId: 'member' } }, hint: 'FOR MAIL' },
    ],
    build(context, frame) {
      const party = partyRef(context, frame); if (isOutcome(party)) return party;
      const channel = code(frame, 'channel', { E: 'email', M: 'mail' }, 'CHANNEL'); if (isOutcome(channel)) return channel;
      const purpose = required(frame, 'purpose', 'PURPOSE'); if (isOutcome(purpose)) return purpose;
      const version = required(frame, 'version', 'DOCUMENT VERSION'); if (isOutcome(version)) return version;
      const destination = entered(frame, 'destination');
      const destid = entered(frame, 'destid');
      return {
        command: { kind: 'communication.send', partyId: party.partyId, channel, purpose, documentVersionId: version, ...(destination === '' ? {} : { destination }), ...(destid === '' ? {} : { addressDestinationId: destid }) },
        lines: [{ label: 'Send', before: '', after: `${channel} ${purpose}` }],
      };
    },
    help,
  },

  'communication.delivery.update': {
    id: 'communication.delivery.update', screenId: 'THCS02', title: 'Update delivery', command: 'communication.delivery.update',
    fields: [
      MEMBER,
      { name: 'job', label: 'JOB', width: 40, pick: { dir: 'comm-jobs', scope: { memberId: 'member' } }, hint: 'F4=PICK JOB' },
      codeField('expected', 'EXPECTED STATE', { Q: 'queued', A: 'accepted' }),
      codeField('action', 'ACTION', { A: 'accept', D: 'deliver', B: 'bounce', C: 'cancel' }),
      textField('detail', 'DETAIL', 50, { capacity: 200 }),
    ],
    build(context, frame) {
      const member = memberRef(context, frame); if (isOutcome(member)) return member;
      const job = required(frame, 'job', 'JOB'); if (isOutcome(job)) return job;
      const expected = code(frame, 'expected', { Q: 'queued', A: 'accepted' }, 'EXPECTED STATE'); if (isOutcome(expected)) return expected;
      const action = code(frame, 'action', { A: 'accept', D: 'deliver', B: 'bounce', C: 'cancel' }, 'ACTION'); if (isOutcome(action)) return action;
      const detail = required(frame, 'detail', 'DETAIL'); if (isOutcome(detail)) return detail;
      return {
        command: { kind: 'communication.delivery.update', jobId: job, expectedState: expected as 'queued', action: action as 'accept', detail },
        lines: [{ label: 'Delivery', before: expected, after: action }],
      };
    },
    help,
  },
};
