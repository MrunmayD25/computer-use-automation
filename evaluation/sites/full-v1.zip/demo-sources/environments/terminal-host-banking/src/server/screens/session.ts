import type { CommandKind } from '@computer-use/financial-database/services';

import { failure, info, success, type Frame, type FrameOf } from '../host/frames.js';
import { upper, wrap } from '../host/format.js';
import type { HostContext, Outcome, ScreenModule } from '../host/module.js';
import { ScreenBuilder } from '../host/screen.js';
import { accountListFrame, activityFrame, caseListFrame, cashFrame, inactiveKey, label, page, transferFrame, value } from './common.js';
import { directoryFrame } from './dirs.js';
import { HELP_TOPICS } from './help-text.js';
import { maintenanceFrame } from './maintenance.js';
import { opFrame } from './ops.js';
import { searchesFrame } from './searches.js';

/** Defaults shown on the sign-on screen; submitting an untouched field uses the value shown. */
const defaultInstitution = (context: HostContext): string => context.institutions.length === 1 ? '1' : '';
const defaultOperator = (context: HostContext): string => context.operatorChoices[0] ?? '';

export const signOnScreen: ScreenModule<FrameOf<'signon'>> = {
  render(context, frame) {
    const builder = new ScreenBuilder('THSIGN', 'Sign on');
    builder.text(3, 2, 'SELECT AN INSTITUTION AND AN OPERATOR, THEN PRESS ENTER.', 'emphasis');
    builder.text(5, 2, 'NO  INSTITUTION', 'label');
    context.institutions.forEach((institution, index) => {
      builder.text(6 + index, 2, String(index + 1).padStart(2), 'data');
      builder.data(6 + index, 6, 30, institution.displayName);
      builder.data(6 + index, 37, 40, `${institution.institutionId} / ${institution.timeZone}`, 'label');
    });
    label(builder, 13, 2, 'Institution number', 26).input('institution', 13, 28, 2, value(frame, 'institution', defaultInstitution(context)), { numeric: true });
    label(builder, 14, 2, 'Operator ID', 26);
    if (context.operatorFixed) builder.data(14, 28, 6, defaultOperator(context));
    else builder.input('operator', 14, 28, 6, value(frame, 'operator', defaultOperator(context)));
    builder.data(16, 2, 76, context.operatorFixed ? 'THE OPERATOR FOR THIS TERMINAL IS FIXED BY ITS HOST CONFIGURATION.' : `CONFIGURED OPERATORS: ${context.operatorChoices.join(' ')}`, 'label');
    builder.data(17, 2, 76, 'SIGN-ON SELECTS A HOST-CONFIGURED OPERATOR. THIS TERMINAL DOES NOT AUTHENTICATE.', 'label');
    return builder.legend('ENTER=Sign on  F1=Help');
  },
  input(context, frame, event) {
    if (event.aid !== 'enter') return { kind: 'stay', message: failure('KEY NOT ACTIVE ON THIS SCREEN. PRESS ENTER TO SIGN ON.') };
    const number = Number(value(frame, 'institution', defaultInstitution(context)).trim());
    const institution = Number.isInteger(number) && number > 0 ? context.institutions[number - 1] : undefined;
    if (institution === undefined) return { kind: 'stay', message: failure(`ENTER AN INSTITUTION NUMBER FROM 1 TO ${context.institutions.length}.`), error: 'institution' };
    const actorNumber = context.operatorFixed ? defaultOperator(context) : upper(value(frame, 'operator', defaultOperator(context)).trim());
    const problem = context.signOnAs(institution.institutionId, actorNumber);
    if (problem !== null) return { kind: 'stay', message: problem, error: context.operatorFixed ? 'institution' : 'operator' };
    return { kind: 'reset', frames: [{ kind: 'menu', values: {} }], message: success(`SIGNED ON TO ${upper(institution.displayName)} AS ${actorNumber}.`) };
  },
  exit() {
    return { kind: 'stay', message: info('PRESS ENTER TO SIGN ON.') };
  },
  help: HELP_TOPICS.signon,
};

interface MenuOption {
  number: string;
  code: string;
  title: string;
  /** Command the option leads to, for marking options the operator is not granted. */
  command: CommandKind | null;
  frame: () => Frame;
}

const menuFrame = (section: string): Frame => ({ kind: 'menu', values: {}, section, page: 0 });
const op = (id: string): (() => Frame) => () => opFrame(id);
const dir = (id: string, scope: Record<string, string> = {}): (() => Frame) => () => directoryFrame(id, scope, null);

/** Each menu section's options; sections beyond 'main' page with F7/F8. */
export const MENU: Record<string, readonly MenuOption[]> = {
  main: [
    { number: '1', code: 'MB01', title: 'Member search and inquiry', command: null, frame: () => ({ kind: 'member-list', values: {}, criteria: { query: '', status: '' }, offset: 0, total: 0, rows: [] }) },
    { number: '2', code: 'MB03', title: 'New member', command: 'member.create', frame: () => ({ kind: 'member-create', values: {}, party: 'person' }) },
    { number: '3', code: 'AC01', title: 'Account search and inquiry', command: null, frame: () => accountListFrame(null) },
    { number: '4', code: 'TX01', title: 'Cash deposit', command: 'cash.deposit', frame: () => cashFrame('deposit') },
    { number: '5', code: 'TX02', title: 'Cash withdrawal', command: 'cash.withdraw', frame: () => cashFrame('withdraw') },
    { number: '6', code: 'TX03', title: 'Internal transfer', command: 'transfer.internal', frame: () => transferFrame() },
    { number: '7', code: 'AV01', title: 'Activity inquiry', command: null, frame: () => activityFrame({}) },
    { number: '8', code: 'RC02', title: 'Receipt inquiry', command: null, frame: () => ({ kind: 'receipt-lookup', values: {} }) },
    { number: '9', code: 'CS01', title: 'Case work queue', command: null, frame: () => caseListFrame(null) },
    { number: '10', code: 'SS01', title: 'Saved searches', command: null, frame: () => searchesFrame() },
    { number: '11', code: 'SV00', title: 'Servicing operations', command: null, frame: () => menuFrame('service') },
    { number: '12', code: 'FN00', title: 'Finance operations', command: null, frame: () => menuFrame('finance') },
    { number: '13', code: 'PY00', title: 'Payments, cards and loans', command: null, frame: () => menuFrame('payments') },
    { number: '14', code: 'RC00', title: 'Reconciliation and directories', command: null, frame: () => menuFrame('recon') },
    { number: '15', code: 'AP01', title: 'Approvals inbox', command: null, frame: () => dir('approvals')() },
    { number: '16', code: 'MN01', title: 'Maintenance draft', command: 'maintenance.draft.save', frame: () => maintenanceFrame() },
  ],
  service: [
    { number: '1', code: 'ID01', title: 'Register identity evidence', command: 'member.identity_evidence.register', frame: op('member.identity_evidence.register') },
    { number: '2', code: 'ID02', title: 'Verify identity', command: 'member.identity.verify', frame: op('member.identity.verify') },
    { number: '3', code: 'ID03', title: 'Resolve member identity', command: null, frame: op('member.identity.resolve') },
    { number: '4', code: 'NM01', title: 'Update legal name', command: 'member.legal_name.update', frame: op('member.legal_name.update') },
    { number: '5', code: 'NM02', title: 'Update preferred name', command: 'member.preferred_name.update', frame: op('member.preferred_name.update') },
    { number: '6', code: 'DC01', title: 'Index document', command: 'document.index', frame: op('document.index') },
    { number: '7', code: 'DC02', title: 'Member documents', command: null, frame: dir('documents') },
    { number: '8', code: 'DC03', title: 'Redact document bundle', command: 'document.bundle.redact', frame: op('document.bundle.redact') },
    { number: '9', code: 'DC04', title: 'Signature collect', command: 'document.signature.collect', frame: op('document.signature.collect') },
    { number: '10', code: 'CN01', title: 'Record consent delivery', command: 'consent.delivery.record', frame: op('consent.delivery.record') },
    { number: '11', code: 'CN02', title: 'Withdraw consent', command: 'consent.withdraw', frame: op('consent.withdraw') },
    { number: '12', code: 'EX01', title: 'Customer document export', command: 'document.customer_export.create', frame: op('document.customer_export.create') },
    { number: '13', code: 'RH01', title: 'Apply retention hold', command: 'document.retention_hold.apply', frame: op('document.retention_hold.apply') },
    { number: '14', code: 'IR01', title: 'Request case information', command: 'case.information.request', frame: op('case.information.request') },
    { number: '15', code: 'ES01', title: 'Escalate case', command: 'case.escalate', frame: op('case.escalate') },
    { number: '16', code: 'AN01', title: 'Annotate document', command: 'document.annotation.update', frame: op('document.annotation.update') },
    { number: '17', code: 'MD01', title: 'Update document metadata', command: 'document.metadata.update', frame: op('document.metadata.update') },
    { number: '18', code: 'CP01', title: 'Communication preference', command: 'communication.preference.update', frame: op('communication.preference.update') },
    { number: '19', code: 'CM01', title: 'Send communication', command: 'communication.send', frame: op('communication.send') },
    { number: '20', code: 'CM02', title: 'Update delivery', command: 'communication.delivery.update', frame: op('communication.delivery.update') },
    { number: '21', code: 'AR01', title: 'Reconcile address', command: 'maintenance.address.reconcile', frame: op('maintenance.address.reconcile') },
    { number: '22', code: 'AR02', title: 'Address destination', command: 'maintenance.address.destination.update', frame: op('maintenance.address.destination.update') },
    { number: '23', code: 'MN02', title: 'Maintenance requests', command: null, frame: dir('maintenance-requests') },
    { number: '24', code: 'CC01', title: 'Close case', command: 'case.close', frame: op('case.close') },
    { number: '25', code: 'CC02', title: 'Reopen case', command: 'case.reopen', frame: op('case.reopen') },
  ],
  finance: [
    { number: '1', code: 'MG01', title: 'Apply member merge', command: 'member.merge', frame: op('member.merge') },
    { number: '2', code: 'MP01', title: 'Inspect merge plan', command: null, frame: op('member.merge.plan.inspect') },
    { number: '3', code: 'DC10', title: 'Record member deceased', command: 'member.deceased.record', frame: op('member.deceased.record') },
    { number: '4', code: 'BO01', title: 'Beneficial owners', command: 'member.beneficial_owners.update', frame: op('member.beneficial_owners.update') },
    { number: '5', code: 'TX10', title: 'Tax classification', command: 'member.tax_classification.update', frame: op('member.tax_classification.update') },
    { number: '6', code: 'PC01', title: 'Convert product', command: 'account.product.convert', frame: op('account.product.convert') },
    { number: '7', code: 'OA01', title: 'Add account owner', command: 'account.owner.add', frame: op('account.owner.add') },
    { number: '8', code: 'SR01', title: 'Remove signer', command: 'account.signer.remove', frame: op('account.signer.remove') },
    { number: '9', code: 'OD01', title: 'Overdraft limit', command: 'account.overdraft_limit.update', frame: op('account.overdraft_limit.update') },
    { number: '10', code: 'HL01', title: 'Place hold', command: 'account.hold.place', frame: op('account.hold.place') },
    { number: '11', code: 'HL02', title: 'Release hold', command: 'account.hold.release', frame: op('account.hold.release') },
    { number: '12', code: 'RS01', title: 'Apply restriction', command: 'account.restriction.apply', frame: op('account.restriction.apply') },
    { number: '13', code: 'RS02', title: 'Release restriction', command: 'account.restriction.release', frame: op('account.restriction.release') },
    { number: '14', code: 'FE01', title: 'Assess fee', command: 'fee.assess', frame: op('fee.assess') },
    { number: '15', code: 'FE02', title: 'Create fee waiver', command: 'fee.waiver.create', frame: op('fee.waiver.create') },
    { number: '16', code: 'FE03', title: 'Refund fee', command: 'fee.refund', frame: op('fee.refund') },
    { number: '17', code: 'RV10', title: 'Reverse deposit', command: 'cash.deposit.reverse', frame: op('cash.deposit.reverse') },
    { number: '18', code: 'RV11', title: 'Reverse withdrawal', command: 'cash.withdrawal.reverse', frame: op('cash.withdrawal.reverse') },
    { number: '19', code: 'RV12', title: 'Reverse transfer', command: 'transfer.internal.reverse', frame: op('transfer.internal.reverse') },
    { number: '20', code: 'IN01', title: 'Adjust interest', command: 'interest.adjust', frame: op('interest.adjust') },
    { number: '21', code: 'ED01', title: 'Correct effective date', command: 'transaction.effective_date.correct', frame: op('transaction.effective_date.correct') },
    { number: '22', code: 'DS01', title: 'Update journal description', command: 'transaction.description.update', frame: op('transaction.description.update') },
    { number: '23', code: 'MI01', title: 'Maturity instruction', command: 'account.maturity.instruct', frame: op('account.maturity.instruct') },
  ],
  payments: [
    { number: '1', code: 'BN01', title: 'Create beneficiary', command: 'beneficiary.create', frame: op('beneficiary.create') },
    { number: '2', code: 'BN02', title: 'Verify beneficiary', command: 'beneficiary.verify', frame: op('beneficiary.verify') },
    { number: '3', code: 'BN03', title: 'Update routing', command: 'beneficiary.routing.update', frame: op('beneficiary.routing.update') },
    { number: '4', code: 'BN04', title: 'Retire beneficiary', command: 'beneficiary.retire', frame: op('beneficiary.retire') },
    { number: '5', code: 'PM01', title: 'Create payment', command: 'payment.create', frame: op('payment.create') },
    { number: '6', code: 'PM02', title: 'Submit payment', command: 'payment.submit', frame: op('payment.submit') },
    { number: '7', code: 'PM03', title: 'Approve and release payment', command: 'payment.approve_release', frame: op('payment.approve_release') },
    { number: '8', code: 'PM04', title: 'Settle payment', command: 'payment.settle', frame: op('payment.settle') },
    { number: '9', code: 'PM05', title: 'Cancel payment', command: 'payment.cancel', frame: op('payment.cancel') },
    { number: '10', code: 'SC01', title: 'Create payment schedule', command: 'payment.schedule.create', frame: op('payment.schedule.create') },
    { number: '11', code: 'SC02', title: 'Materialize occurrence', command: 'payment.schedule.materialize', frame: op('payment.schedule.materialize') },
    { number: '12', code: 'SC03', title: 'Amend occurrence', command: 'payment.occurrence.amend', frame: op('payment.occurrence.amend') },
    { number: '13', code: 'SC04', title: 'End schedule', command: 'payment.schedule.end', frame: op('payment.schedule.end') },
    { number: '14', code: 'RT01', title: 'Resolve return', command: 'payment.return.resolve', frame: op('payment.return.resolve') },
    { number: '15', code: 'CD01', title: 'Replace card', command: 'card.replace', frame: op('card.replace') },
    { number: '16', code: 'CD02', title: 'Card lock update', command: 'card.lock.update', frame: op('card.lock.update') },
    { number: '17', code: 'CD03', title: 'Update card limit', command: 'card.limit.update', frame: op('card.limit.update') },
    { number: '18', code: 'DP01', title: 'Open dispute', command: 'dispute.open', frame: op('dispute.open') },
    { number: '19', code: 'DP02', title: 'Provisional credit', command: 'dispute.provisional_credit.issue', frame: op('dispute.provisional_credit.issue') },
    { number: '20', code: 'DP03', title: 'Submit dispute evidence', command: 'dispute.evidence.submit', frame: op('dispute.evidence.submit') },
    { number: '21', code: 'DP04', title: 'Settle dispute', command: 'dispute.settle', frame: op('dispute.settle') },
    { number: '22', code: 'LN01', title: 'Prepare loan application', command: 'loan.application.prepare', frame: op('loan.application.prepare') },
    { number: '23', code: 'LN02', title: 'Allocate loan payment', command: 'loan.payment.allocate', frame: op('loan.payment.allocate') },
    { number: '24', code: 'LN03', title: 'Payoff quote', command: 'loan.payoff.quote', frame: op('loan.payoff.quote') },
    { number: '25', code: 'LN04', title: 'Close loan', command: 'loan.close', frame: op('loan.close') },
    { number: '26', code: 'LN05', title: 'Issue closure document', command: 'document.loan_closure.issue', frame: op('document.loan_closure.issue') },
    { number: '27', code: 'SU01', title: 'Investigate suspense', command: 'reconciliation.suspense.investigate', frame: op('reconciliation.suspense.investigate') },
    { number: '28', code: 'SU02', title: 'Clear suspense', command: 'reconciliation.suspense.clear', frame: op('reconciliation.suspense.clear') },
    { number: '29', code: 'BI01', title: 'Import batch', command: 'batch.import', frame: op('batch.import') },
    { number: '30', code: 'BT01', title: 'Work batches', command: null, frame: dir('batches') },
  ],
  recon: [
    { number: '1', code: 'RT10', title: 'Reconcile transfer', command: null, frame: op('reconciliation.transfer') },
    { number: '2', code: 'RT11', title: 'Reconcile settlement batch', command: null, frame: op('reconciliation.settlement_batch') },
    { number: '3', code: 'RT12', title: 'Reconcile cash day', command: null, frame: op('reconciliation.cash_day') },
    { number: '4', code: 'RT13', title: 'Preview batch', command: null, frame: op('batch.preview') },
    { number: '5', code: 'DJ01', title: 'Journals', command: null, frame: dir('journals') },
    { number: '6', code: 'DJ02', title: 'Settlement batches', command: null, frame: dir('settlement-batches') },
    { number: '7', code: 'DJ03', title: 'Suspense items', command: null, frame: dir('suspense') },
    { number: '8', code: 'DJ04', title: 'Cash sessions', command: null, frame: dir('cash-sessions') },
    { number: '9', code: 'DJ05', title: 'Products', command: null, frame: dir('products') },
    { number: '10', code: 'DJ06', title: 'Merge plans', command: null, frame: dir('merge-plans') },
    { number: '11', code: 'DJ07', title: 'Retention holds', command: null, frame: dir('retention-holds') },
    { number: '12', code: 'DJ08', title: 'Policy versions', command: null, frame: dir('policies') },
    { number: '13', code: 'DJ09', title: 'Queues', command: null, frame: dir('queues') },
    { number: '14', code: 'DJ10', title: 'Work batches', command: null, frame: dir('batches') },
    { number: '15', code: 'IN01', title: 'Institution context', command: null, frame: () => opFrame('institution.context.verify') },
  ],
};

const MENU_PAGE = 12;
const SECTION_TITLES: Record<string, string> = { main: 'Main menu', service: 'Servicing operations', finance: 'Finance operations', payments: 'Payments, cards and loans', recon: 'Reconciliation and directories' };

function signOff(context: HostContext): Outcome {
  context.signOff();
  return { kind: 'reset', frames: [{ kind: 'signon', values: {} }], message: success('SIGNED OFF. SIGNING OFF DOES NOT CHANGE ANY BUSINESS DATA.') };
}

export const menuScreen: ScreenModule<FrameOf<'menu'>> = {
  render(context, frame) {
    const { operator } = context.session();
    const section = frame.section ?? 'main';
    const options = MENU[section] ?? MENU.main ?? [];
    const page = frame.page ?? 0;
    const pages = Math.max(1, Math.ceil((options.length + 1) / MENU_PAGE));
    const shown = options.slice(page * MENU_PAGE, (page + 1) * MENU_PAGE);
    const builder = new ScreenBuilder('THMENU', SECTION_TITLES[section] ?? 'Main menu');
    builder.text(3, 2, 'SELECT AN OPTION NUMBER OR TRANSACTION CODE AND PRESS ENTER.', 'emphasis');
    builder.text(5, 4, 'OPT  CODE    FUNCTION', 'label');
    shown.forEach((option, index) => {
      builder.text(6 + index, 5, option.number, 'data').text(6 + index, 9, option.code, 'data').data(6 + index, 17, 36, upper(option.title));
      if (option.command !== null && !operator.commands.has(option.command)) builder.text(6 + index, 54, '* NOT GRANTED', 'warning');
    });
    if (page === pages - 1) builder.text(6 + shown.length, 5, 'X', 'data').text(6 + shown.length, 9, 'SIGNOFF', 'data').text(6 + shown.length, 17, 'SIGN OFF', 'data');
    builder.page = `PAGE ${page + 1} OF ${pages}`;
    builder.data(18, 4, 74, `ROLES: ${operator.roles.join(', ') || 'NONE'}`, 'label');
    builder.data(20, 4, 74, '* THE SHARED GRANT TABLE DOES NOT LET THIS OPERATOR COMMIT THAT FUNCTION.', 'label');
    label(builder, 19, 2, 'OPTION ===>', 13).input('option', 19, 15, 8, value(frame, 'option'));
    return builder.legend(`ENTER=Select  ${pages > 1 ? 'F7=Up  F8=Down  ' : ''}F1=Help  ${section === 'main' ? 'F3=Sign off' : 'F3=Return'}`);
  },
  input(context, frame, event) {
    const section = frame.section ?? 'main';
    const options = MENU[section] ?? MENU.main ?? [];
    const pages = Math.max(1, Math.ceil((options.length + 1) / MENU_PAGE));
    if (event.aid === 'pf7' && (frame.page ?? 0) > 0) { frame.page = (frame.page ?? 0) - 1; return { kind: 'stay' }; }
    if (event.aid === 'pf8' && (frame.page ?? 0) < pages - 1) { frame.page = (frame.page ?? 0) + 1; return { kind: 'stay' }; }
    if (event.aid !== 'enter') return inactiveKey();
    const entered = upper(value(frame, 'option').trim()).replace(/^TH/u, '');
    delete frame.values.option;
    if (entered === 'X' || entered === 'SIGNOFF' || entered === 'LOGOFF') return signOff(context);
    const option = options.find((candidate) => candidate.number === entered || candidate.code === entered);
    if (option === undefined) return { kind: 'stay', message: failure(entered === '' ? 'ENTER AN OPTION NUMBER OR TRANSACTION CODE.' : `OPTION ${entered.slice(0, 20)} IS NOT RECOGNIZED.`), error: 'option' };
    return { kind: 'push', frame: option.frame() };
  },
  exit(context, frame) {
    if ((frame.section ?? 'main') !== 'main') return { kind: 'pop' };
    return signOff(context);
  },
  help: HELP_TOPICS.menu,
};

const HELP_ROWS = 16;

function helpLines(frame: FrameOf<'help'>): readonly string[] {
  const message = frame.message === undefined ? [] : ['MESSAGE', ...wrap(frame.message, 78), ''];
  return [...message, ...HELP_TOPICS[frame.topic].lines, '', ...HELP_TOPICS.keys.lines];
}

export const helpScreen: ScreenModule<FrameOf<'help'>> = {
  render(_context, frame) {
    const lines = helpLines(frame);
    const builder = new ScreenBuilder('THHELP', `Help: ${HELP_TOPICS[frame.topic].title}`);
    builder.page = `PAGE ${frame.page} OF ${Math.max(1, Math.ceil(lines.length / HELP_ROWS))}`;
    lines.slice((frame.page - 1) * HELP_ROWS, frame.page * HELP_ROWS).forEach((line, index) => {
      if (line !== '') builder.data(3 + index, 1, 78, line, line === upper(line) ? 'emphasis' : 'data');
    });
    return builder.legend('F3=Return  F7=Up  F8=Down  F12=Return');
  },
  input(_context, frame, event) {
    const holder = { offset: (frame.page - 1) * HELP_ROWS };
    const paged = page(holder, event.aid, HELP_ROWS, helpLines(frame).length);
    if (paged === null) return { kind: 'stay', message: info('F3 OR F12 RETURNS TO THE SCREEN YOU WERE USING.') };
    frame.page = holder.offset / HELP_ROWS + 1;
    return paged;
  },
  help: HELP_TOPICS.help,
};
