import { COLUMNS, PF_KEYS, ROWS, type Aid, type InputMessage, type ScreenPayload, type SessionOpened, type Tone, type TransferOffer } from '../shared/protocol.js';
import { FieldBuffer, type KeyboardLock } from './field-buffer.js';
import { ALT_PF_LABELS, keyAction, type EditCommand, type KeyAction } from './keymap.js';

const SESSION_KEY = 'terminal-host-banking.session';

const LOCK_TEXT: Readonly<Record<KeyboardLock, string>> = {
  system: 'X SYSTEM  WAITING FOR THE HOST. KEYS ARE IGNORED.',
  protected: 'X PROT  PROTECTED AREA. PRESS RESET (ESC OR ALT+R).',
  numeric: 'X NUM  DIGITS, POINT AND MINUS ONLY. PRESS RESET (ESC OR ALT+R).',
  overflow: 'X OVERFLOW  THE FIELD IS FULL. PRESS RESET (ESC OR ALT+R).',
};

const HINTS = 'Enter sends the screen. F1 to F12 are PF1 to PF12; Shift+F1 to F12 are PF13 to PF24. Browser-safe: Alt+1 to Alt+0, Alt+- and Alt+= are PF1 to PF12; '
  + 'add Shift for PF13 to PF24. PgUp/PgDn are PF7/PF8. Esc or Alt+R resets a locked keyboard. Insert or Alt+I toggles insert mode. Ctrl+Delete or Alt+E erases to the '
  + 'end of the field; Alt+Delete or Alt+X erases all input. Pause or Alt+C is Clear. Alt+D downloads an offered file.';

interface Notice {
  text: string;
  severity: 'info' | 'error';
}

interface KeypadKey {
  label: string;
  hint: string;
  action: KeyAction;
  wide?: boolean;
}

class RequestError extends Error {
  constructor(readonly status: number, readonly code: string, message: string) {
    super(message);
  }
}

function element<K extends keyof HTMLElementTagNameMap>(tag: K, className: string, text?: string): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (className !== '') node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

const KEYPAD: readonly KeypadKey[] = [
  ...PF_KEYS.slice(0, 12).map((aid, index) => ({ label: `PF${String(index + 1)}`, hint: `F${String(index + 1)} or Alt+${ALT_PF_LABELS[index] ?? ''}`, action: { kind: 'aid', aid } as const })),
  ...PF_KEYS.slice(12).map((aid, index) => ({ label: `PF${String(index + 13)}`, hint: `Shift+F${String(index + 1)} or Alt+Shift+${ALT_PF_LABELS[index] ?? ''}`, action: { kind: 'aid', aid } as const })),
  { label: 'Enter', hint: 'Enter', action: { kind: 'aid', aid: 'enter' }, wide: true },
  { label: 'Clear', hint: 'Pause or Alt+C', action: { kind: 'aid', aid: 'clear' } },
  { label: 'Reset', hint: 'Esc or Alt+R', action: { kind: 'edit', command: 'reset' } },
  { label: 'Ins', hint: 'Insert or Alt+I', action: { kind: 'edit', command: 'insert' } },
  { label: 'Erase EOF', hint: 'Ctrl+Delete or Alt+E', action: { kind: 'edit', command: 'erase-eof' }, wide: true },
  { label: 'Erase input', hint: 'Alt+Delete or Alt+X', action: { kind: 'edit', command: 'erase-input' }, wide: true },
  { label: 'Download', hint: 'Alt+D', action: { kind: 'download' }, wide: true },
];

/**
 * The browser terminal. It shows the host's formatted screen, edits unprotected fields locally and
 * transmits only on an attention key. While the host owns the screen the keyboard is locked and
 * keystrokes are discarded, so nothing typed ahead can act on the next screen.
 */
export class TerminalApp {
  private readonly buffer = new FieldBuffer();
  private screen: ScreenPayload | null = null;
  private sessionId: string | null = null;
  private composing = false;
  private notice: Notice | null = null;
  private readonly display = element('div', 'screen');
  private readonly rowElements = Array.from({ length: ROWS }, () => element('div', 'row'));
  private readonly keyboard = element('textarea', 'keyboard');
  private readonly status = element('div', 'oia');
  private readonly transferBar = element('div', 'transfer');
  private readonly live = element('div', 'visually-hidden');

  constructor(private readonly root: HTMLElement) {
    this.display.setAttribute('aria-label', 'Terminal screen, 24 rows by 80 columns');
    this.display.append(...this.rowElements);
    this.keyboard.setAttribute('aria-label', 'Terminal keyboard input');
    for (const [name, value] of [['autocapitalize', 'off'], ['autocomplete', 'off'], ['autocorrect', 'off'], ['spellcheck', 'false'], ['rows', '1']] as const) this.keyboard.setAttribute(name, value);
    const overlay = element('button', 'overlay', 'INPUT PAUSED. CLICK HERE OR ON THE SCREEN TO CONTINUE TYPING.');
    overlay.type = 'button';
    const frame = element('div', 'screen-frame');
    frame.append(this.display, this.keyboard, overlay);
    this.live.setAttribute('aria-live', 'polite');
    this.transferBar.hidden = true;
    root.append(frame, this.status, this.transferBar, this.keypad(), element('p', 'hints', HINTS), this.live);

    this.keyboard.addEventListener('keydown', (event) => { this.onKeyDown(event); });
    this.keyboard.addEventListener('input', () => { this.onInput(); });
    this.keyboard.addEventListener('compositionstart', () => { this.composing = true; });
    this.keyboard.addEventListener('compositionend', () => { this.composing = false; this.onInput(); });
    this.keyboard.addEventListener('paste', (event) => { this.onPaste(event); });
    this.keyboard.addEventListener('drop', (event) => { event.preventDefault(); });
    this.keyboard.addEventListener('focus', () => { root.classList.add('has-focus'); });
    this.keyboard.addEventListener('blur', () => { root.classList.remove('has-focus'); });
    overlay.addEventListener('click', () => { this.focus(); });
    this.display.addEventListener('mousedown', (event) => { this.onPointer(event); });
  }

  async start(): Promise<void> {
    const stored = sessionStorage.getItem(SESSION_KEY);
    if (stored !== null) {
      try {
        this.sessionId = stored;
        this.load(await this.request<ScreenPayload>(`/api/sessions/${encodeURIComponent(stored)}/screen`));
        this.focus();
        return;
      } catch (error) {
        if (!(error instanceof RequestError && error.code === 'unknown_session')) throw error;
        sessionStorage.removeItem(SESSION_KEY);
      }
    }
    await this.openSession();
    this.focus();
  }

  private async openSession(): Promise<void> {
    const opened = await this.request<SessionOpened>('/api/sessions', 'POST');
    this.sessionId = opened.sessionId;
    sessionStorage.setItem(SESSION_KEY, opened.sessionId);
    this.load(opened.screen);
  }

  private focus(): void {
    this.keyboard.focus({ preventScroll: true });
  }

  private keypad(): HTMLElement {
    const pad = element('div', 'keypad');
    pad.setAttribute('aria-label', 'Terminal keys');
    for (const key of KEYPAD) {
      const button = element('button', key.wide === true ? 'wide' : '', key.label);
      button.type = 'button';
      button.title = key.hint;
      button.setAttribute('aria-label', `${key.label} (${key.hint})`);
      button.addEventListener('mousedown', (event) => { event.preventDefault(); });
      button.addEventListener('click', () => { void this.perform(key.action); this.focus(); });
      pad.append(button);
    }
    return pad;
  }

  private onKeyDown(event: KeyboardEvent): void {
    if (this.composing || event.isComposing) return;
    const action = keyAction(event);
    if (action === null) return;
    event.preventDefault();
    void this.perform(action);
  }

  /** Text, including IME results, arrives here; it is typed into the buffer and the textarea is emptied. */
  private onInput(): void {
    if (this.composing) return;
    const text = this.keyboard.value;
    this.keyboard.value = '';
    if (text === '') return;
    this.buffer.type(text);
    this.render();
  }

  private onPaste(event: ClipboardEvent): void {
    event.preventDefault();
    const result = this.buffer.paste(event.clipboardData?.getData('text/plain') ?? '');
    this.notice = result.reason === null ? null : { text: result.reason.toUpperCase(), severity: 'error' };
    this.render();
  }

  private onPointer(event: MouseEvent): void {
    event.preventDefault();
    const target = event.target instanceof Element ? event.target.closest<HTMLElement>('[data-a]') : null;
    const address = Number(target?.dataset.a);
    if (Number.isInteger(address)) this.buffer.moveTo(Math.floor(address / COLUMNS), address % COLUMNS);
    this.focus();
    this.render();
  }

  private async perform(action: KeyAction): Promise<void> {
    switch (action.kind) {
      case 'aid':
        await this.transmit(action.aid);
        return;
      case 'download':
        this.download();
        break;
      case 'edit':
        this.edit(action.command);
        break;
    }
    this.render();
  }

  private edit(command: EditCommand): void {
    const buffer = this.buffer;
    switch (command) {
      case 'tab': buffer.tab(); break;
      case 'backtab': buffer.backTab(); break;
      case 'home': buffer.home(); break;
      case 'end': buffer.end(); break;
      case 'left': case 'right': case 'up': case 'down': buffer.move(command); break;
      case 'backspace': buffer.eraseLeft(); break;
      case 'delete': buffer.deleteCharacter(); break;
      case 'erase-eof': buffer.eraseToEnd(); break;
      case 'erase-input': buffer.eraseInput(); break;
      case 'insert': buffer.toggleInsert(); break;
      case 'reset': buffer.reset(); this.notice = null; break;
    }
  }

  private async transmit(aid: Aid): Promise<void> {
    const screen = this.screen;
    const sessionId = this.sessionId;
    // A locked keyboard ignores attention keys until Reset; the status line already shows why.
    if (screen === null || sessionId === null || this.buffer.lock !== null) return;
    const cursor = this.buffer.cursor;
    const message: InputMessage = {
      sequence: screen.sequence, aid, cursor: { row: Math.floor(cursor / COLUMNS), column: cursor % COLUMNS },
      fields: aid === 'clear' ? [] : this.buffer.modifiedFields(),
    };
    this.buffer.beginTransmit();
    this.notice = null;
    this.render();
    try {
      this.load(await this.request<ScreenPayload>(`/api/sessions/${encodeURIComponent(sessionId)}/input`, 'POST', message));
    } catch (error) {
      await this.recover(error);
    }
  }

  /**
   * After a failed transmission the terminal shows the host's current screen rather than retrying,
   * so an answer lost in transit can never cause the same request to be sent against a new screen.
   */
  private async recover(error: unknown): Promise<void> {
    if (error instanceof RequestError && error.code === 'unknown_session') {
      sessionStorage.removeItem(SESSION_KEY);
      await this.openSession();
      this.notice = { text: 'THE TERMINAL SESSION HAD ENDED. A NEW SESSION STARTED. SIGN ON AGAIN.', severity: 'error' };
    } else if (error instanceof RequestError && error.status === 400) {
      this.buffer.lock = null;
      this.notice = { text: `HOST REFUSED THE INPUT: ${error.message}`.toUpperCase(), severity: 'error' };
    } else {
      const cause = error instanceof RequestError ? `HOST ERROR ${String(error.status)}` : 'COMMUNICATION CHECK';
      try {
        this.load(await this.request<ScreenPayload>(`/api/sessions/${encodeURIComponent(this.sessionId ?? '')}/screen`));
        this.notice = { text: `${cause}. THIS IS THE HOST'S CURRENT SCREEN; CHECK RECEIPTS OR ACTIVITY BEFORE RETRYING.`, severity: 'error' };
      } catch {
        this.buffer.lock = null;
        this.notice = { text: 'COMMUNICATION CHECK. NO ANSWER FROM THE HOST. PRESS THE KEY AGAIN TO RETRY.', severity: 'error' };
      }
    }
    this.render();
  }

  private download(): void {
    const offer = this.screen?.transfer ?? null;
    if (offer === null) {
      this.notice = { text: 'NO FILE IS OFFERED ON THIS SCREEN.', severity: 'error' };
      return;
    }
    const link = element('a', '');
    link.href = offer.url;
    link.download = offer.fileName;
    link.click();
    this.notice = { text: `DOWNLOADING ${offer.fileName}`.toUpperCase().slice(0, 78), severity: 'info' };
  }

  private async request<T>(path: string, method: 'GET' | 'POST' = 'GET', body?: unknown): Promise<T> {
    const init: RequestInit = { method };
    if (body !== undefined) {
      init.headers = { 'content-type': 'application/json' };
      init.body = JSON.stringify(body);
    }
    const response = await fetch(path, init);
    if (!response.ok) {
      const failure = await response.json().catch(() => null) as { error?: { code?: string; message?: string } } | null;
      throw new RequestError(response.status, failure?.error?.code ?? 'http_error', failure?.error?.message ?? `HTTP ${String(response.status)}`);
    }
    return await response.json() as T;
  }

  private load(screen: ScreenPayload): void {
    this.screen = screen;
    this.buffer.load(screen);
    this.notice = null;
    document.title = `${screen.screenId} ${screen.title} - Terminal Host Banking`;
    this.live.textContent = screen.message?.text ?? '';
    this.renderTransfer(screen.transfer);
    this.render();
  }

  private renderTransfer(offer: TransferOffer | null): void {
    this.transferBar.hidden = offer === null;
    if (offer === null) { this.transferBar.replaceChildren(); return; }
    const link = element('a', 'download-link', `Download ${offer.fileName}`);
    link.href = offer.url;
    link.download = offer.fileName;
    const detail = element('span', 'transfer-detail', `${String(offer.byteLength)} bytes, ${offer.mediaType}, SHA-256 ${offer.digest}`);
    this.transferBar.replaceChildren(element('span', 'transfer-label', 'FILE READY (ALT+D):'), link, detail);
  }

  private render(): void {
    const screen = this.screen;
    if (screen === null) return;
    const cells = this.buffer.cells();
    const tones: (Tone | null)[] = Array.from({ length: ROWS * COLUMNS }, () => null);
    const inputs = new Uint8Array(ROWS * COLUMNS);
    for (const field of this.buffer.fields) {
      for (let offset = 0; offset < field.length; offset += 1) {
        tones[field.address + offset] = field.tone;
        if (!field.protected) inputs[field.address + offset] = 1;
      }
    }
    const cursor = this.buffer.cursor;
    let cursorCell: HTMLSpanElement | null = null;
    this.rowElements.forEach((rowElement, row) => {
      const spans: HTMLSpanElement[] = [];
      for (let column = 0; column < COLUMNS; column += 1) {
        const address = row * COLUMNS + column;
        const cell = cells[address] ?? ' ';
        if (cell === '' && column > 0) continue;
        // A wide character at the end of a row inside a wrapped field leaves its second cell at column 0.
        const grapheme = cell === '' ? ' ' : cell;
        const wide = column < COLUMNS - 1 && cells[address + 1] === '';
        const classes = ['c', `t-${tones[address] ?? 'data'}`];
        if (inputs[address] === 1) classes.push('in');
        if (wide) classes.push('w');
        if (address === cursor) classes.push('cur');
        const span = element('span', classes.join(' '), grapheme);
        span.dataset.a = String(address);
        if (address === cursor) cursorCell = span;
        spans.push(span);
      }
      rowElement.replaceChildren(...spans);
    });
    this.placeKeyboard(cursorCell);
    this.renderStatus(screen);
    this.root.dataset.screenId = screen.screenId;
    this.root.dataset.sequence = String(screen.sequence);
    this.root.dataset.lock = this.buffer.lock ?? 'none';
    this.root.classList.toggle('insert', this.buffer.insert);
  }

  /** Keeps the hidden input at the cursor so IME candidate windows appear beside it. */
  private placeKeyboard(cell: HTMLSpanElement | null): void {
    if (cell === null) return;
    this.keyboard.style.left = `${String(cell.offsetLeft)}px`;
    this.keyboard.style.top = `${String(cell.offsetTop)}px`;
  }

  private renderStatus(screen: ScreenPayload): void {
    const lock = this.buffer.lock;
    const left = element('span', lock !== null || this.notice?.severity === 'error' ? 'oia-left alert' : 'oia-left', lock === null ? this.notice?.text ?? 'READY' : LOCK_TEXT[lock]);
    const cursor = this.buffer.cursor;
    const position = `${String(Math.floor(cursor / COLUMNS) + 1).padStart(2, '0')}/${String((cursor % COLUMNS) + 1).padStart(3, '0')}`;
    const field = this.buffer.position();
    // Character position and capacity of the current input; < and > mark text scrolled out of view.
    const inField = field === null ? '' : `  ${field.hiddenLeft ? '<' : ' '}CH ${String(field.character)}/${String(field.capacity)}${field.hiddenRight ? '>' : ' '}`;
    const right = element('span', 'oia-right', `${this.buffer.insert ? 'INS' : 'OVR'}  ${screen.screenId}  ${position}${inField}`);
    this.status.replaceChildren(left, right);
  }
}
