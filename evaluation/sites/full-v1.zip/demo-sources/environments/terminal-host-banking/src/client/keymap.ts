import { PF_KEYS, type Aid } from '../shared/protocol.js';

export type EditCommand =
  | 'tab' | 'backtab' | 'home' | 'end' | 'left' | 'right' | 'up' | 'down'
  | 'backspace' | 'delete' | 'erase-eof' | 'erase-input' | 'insert' | 'reset';

export type KeyAction =
  | { kind: 'aid'; aid: Aid }
  | { kind: 'edit'; command: EditCommand }
  | { kind: 'download' };

/** The parts of a keyboard event the terminal reads; `code` is layout independent. */
export interface KeyStroke {
  key: string;
  code: string;
  altKey: boolean;
  shiftKey: boolean;
  ctrlKey: boolean;
  metaKey: boolean;
}

/** Physical keys used with Alt as browser-safe PF keys: Alt+1 is PF1, Alt+= is PF12; Shift adds 12. */
export const ALT_PF_CODES = ['Digit1', 'Digit2', 'Digit3', 'Digit4', 'Digit5', 'Digit6', 'Digit7', 'Digit8', 'Digit9', 'Digit0', 'Minus', 'Equal'] as const;
export const ALT_PF_LABELS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '='] as const;

const ALT_EDITS: Readonly<Record<string, KeyAction>> = {
  KeyR: { kind: 'edit', command: 'reset' },
  KeyI: { kind: 'edit', command: 'insert' },
  KeyE: { kind: 'edit', command: 'erase-eof' },
  KeyX: { kind: 'edit', command: 'erase-input' },
  KeyC: { kind: 'aid', aid: 'clear' },
  KeyD: { kind: 'download' },
  Delete: { kind: 'edit', command: 'erase-input' },
};

const PLAIN_EDITS: Readonly<Record<string, EditCommand>> = {
  ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down', Home: 'home', End: 'end',
  Backspace: 'backspace', Delete: 'delete', Insert: 'insert', Escape: 'reset',
};

function pf(index: number): KeyAction | null {
  const aid = PF_KEYS[index];
  return aid === undefined ? null : { kind: 'aid', aid };
}

/**
 * Maps a key press to a terminal action, or null when the key is ordinary text or belongs to the
 * browser (Cmd shortcuts, Ctrl+C/V). Text arrives through the input event so IME composition works.
 */
export function keyAction(stroke: KeyStroke): KeyAction | null {
  if (stroke.metaKey) return null;
  const functionKey = /^F([1-9]|1\d|2[0-4])$/u.exec(stroke.key);
  if (functionKey !== null && !stroke.altKey && !stroke.ctrlKey) {
    const number = Number(functionKey[1]);
    return pf(number - 1 + (stroke.shiftKey && number <= 12 ? 12 : 0));
  }
  if (stroke.altKey && !stroke.ctrlKey) {
    const index = ALT_PF_CODES.findIndex((code) => code === stroke.code);
    if (index >= 0) return pf(index + (stroke.shiftKey ? 12 : 0));
    return stroke.shiftKey ? null : ALT_EDITS[stroke.code] ?? null;
  }
  if (stroke.ctrlKey) {
    if (stroke.key === 'Delete') return { kind: 'edit', command: 'erase-eof' };
    if (stroke.key === 'Home') return { kind: 'edit', command: 'home' };
    return null;
  }
  switch (stroke.key) {
    case 'Enter': return { kind: 'aid', aid: 'enter' };
    case 'Tab': return { kind: 'edit', command: stroke.shiftKey ? 'backtab' : 'tab' };
    case 'PageUp': return { kind: 'aid', aid: 'pf7' };
    case 'PageDown': return { kind: 'aid', aid: 'pf8' };
    case 'Pause': return { kind: 'aid', aid: 'clear' };
    default: {
      const command = PLAIN_EDITS[stroke.key];
      return command === undefined ? null : { kind: 'edit', command };
    }
  }
}
