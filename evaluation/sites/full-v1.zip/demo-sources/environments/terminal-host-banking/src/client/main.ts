import { TerminalApp } from './terminal.js';

const root = document.getElementById('terminal');
if (root === null) throw new Error('The page has no #terminal element.');
new TerminalApp(root).start().catch((error: unknown) => {
  root.textContent = `The terminal could not connect to its host: ${error instanceof Error ? error.message : String(error)}. Reload the page to retry.`;
});
