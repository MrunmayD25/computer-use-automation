import { graphemes, graphemeWidth, hasForbiddenCharacter } from '../shared/cells.js';
import { COLUMNS, ROWS, type ScreenPayload, type Tone } from '../shared/protocol.js';

/**
 * Keyboard inhibit states, as shown in the operator information area.
 *
 * `system` lasts from transmission until the host answers. The others follow an operator error and
 * last until Reset, so a mistaken keystroke cannot silently land somewhere else.
 */
export type KeyboardLock = 'system' | 'protected' | 'numeric' | 'overflow';

export interface BufferField {
  address: number;
  row: number;
  column: number;
  /** Cells on screen; an input field may run on across rows. */
  length: number;
  /** Most UTF-16 code units the field holds. */
  capacity: number;
  protected: boolean;
  numeric: boolean;
  tone: Tone;
  /** Grapheme clusters; each occupies one or two cells. */
  value: string[];
  /** Content cells scrolled off the left of the field's window. */
  offset: number;
  /** Modified data tag: set when the operator changes the field; only tagged fields are sent. */
  modified: boolean;
}

export interface PasteResult {
  accepted: boolean;
  reason: string | null;
}

/** Where the cursor is inside the current input field, for the operator information area. */
export interface FieldPosition {
  /** One-based character position of the cursor. */
  character: number;
  used: number;
  capacity: number;
  hiddenLeft: boolean;
  hiddenRight: boolean;
}

const SCREEN_CELLS = ROWS * COLUMNS;
const NUMERIC = /^[0-9.-]$/u;

function widthOf(value: readonly string[]): number {
  return value.reduce((total, grapheme) => total + graphemeWidth(grapheme), 0);
}

function unitsOf(value: readonly string[]): number {
  return value.join('').length;
}

/**
 * The terminal's local field buffer. It edits unprotected fields within their capacity, scrolling a
 * field's window when its content is wider than its cells, and never transmits anything itself;
 * callers send `modifiedFields()` when an attention key is used.
 *
 * Positions inside a field are content cells counted from the start of its value ("logical"
 * cells); the screen cursor is the logical cell minus the field's scroll offset.
 */
export class FieldBuffer {
  fields: BufferField[] = [];
  cursor = 0;
  insert = false;
  lock: KeyboardLock | null = null;

  load(screen: ScreenPayload): void {
    this.fields = screen.fields
      .map((field) => ({ ...field, value: graphemes(field.value), offset: 0, modified: false }))
      .sort((a, b) => a.address - b.address);
    this.cursor = this.snap(screen.cursor.row * COLUMNS + screen.cursor.column, 'left');
    this.lock = null;
  }

  get inputFields(): BufferField[] {
    return this.fields.filter((field) => !field.protected);
  }

  fieldAt(address: number): BufferField | undefined {
    return this.fields.find((field) => address >= field.address && address < field.address + field.length);
  }

  /** The unprotected field under the cursor, if any. */
  currentInput(): BufferField | undefined {
    const field = this.fieldAt(this.cursor);
    return field?.protected === false ? field : undefined;
  }

  modifiedFields(): { address: number; value: string }[] {
    return this.inputFields.filter((field) => field.modified).map((field) => ({ address: field.address, value: field.value.join('').replace(/ +$/u, '') }));
  }

  position(): FieldPosition | null {
    const field = this.currentInput();
    if (field === undefined) return null;
    const logical = this.logical(field);
    const content = widthOf(field.value);
    return {
      character: this.locate(field, logical).index + 1 + Math.max(0, logical - content),
      used: unitsOf(field.value), capacity: field.capacity,
      hiddenLeft: field.offset > 0, hiddenRight: content > field.offset + field.length,
    };
  }

  /** Locks the keyboard while the host owns the screen. */
  beginTransmit(): void {
    this.lock = 'system';
  }

  /** Clears an operator-error lock and leaves insert mode; the system lock is released only by the host. */
  reset(): void {
    if (this.lock !== 'system') this.lock = null;
    this.insert = false;
  }

  toggleInsert(): void {
    if (this.lock === null) this.insert = !this.insert;
  }

  type(text: string): void {
    for (const grapheme of graphemes(text)) {
      if (!this.typeOne(grapheme)) return;
    }
  }

  private typeOne(grapheme: string): boolean {
    if (this.lock !== null || hasForbiddenCharacter(grapheme)) return false;
    const field = this.currentInput();
    if (field === undefined) { this.lock = 'protected'; return false; }
    if (field.numeric && !NUMERIC.test(grapheme)) { this.lock = 'numeric'; return false; }
    const placed = this.place(field, [grapheme]);
    if (placed === null) { this.lock = 'overflow'; return false; }
    field.value = placed.value;
    field.modified = true;
    if (unitsOf(field.value) >= field.capacity && placed.end >= widthOf(field.value)) this.enter(this.nextInputAfter(field.address));
    else this.reveal(field, placed.end);
    return true;
  }

  private logical(field: BufferField): number {
    return this.cursor - field.address + field.offset;
  }

  /** Scrolls the field so the grapheme starting at a logical cell is visible and puts the cursor on it. */
  private reveal(field: BufferField, logical: number): void {
    const { index, start } = this.locate(field, logical);
    const width = start === logical && index < field.value.length ? graphemeWidth(field.value[index] ?? ' ') : 1;
    if (logical < field.offset) field.offset = logical;
    else if (logical + width > field.offset + field.length) field.offset = this.boundaryAtOrAfter(field, logical + width - field.length);
    this.cursor = field.address + logical - field.offset;
  }

  /** The first grapheme boundary at or after a logical cell, so the window never shows half a wide character. */
  private boundaryAtOrAfter(field: BufferField, cell: number): number {
    let start = 0;
    for (const grapheme of field.value) {
      if (start >= cell) return start;
      start += graphemeWidth(grapheme);
    }
    return Math.max(cell, start);
  }

  /** Puts the cursor at the start of an input field, showing the beginning of its value. */
  private enter(field: BufferField | undefined): void {
    if (field === undefined) return;
    field.offset = 0;
    this.cursor = field.address;
  }

  /**
   * Places graphemes at the cursor using the current insert/overwrite mode. Cells between the end of
   * the content and the cursor become blanks. Returns null when the result would exceed the capacity.
   */
  private place(field: BufferField, incoming: readonly string[]): { value: string[]; end: number } | null {
    const { index, start } = this.locate(field, this.logical(field));
    const value = [...field.value];
    const content = widthOf(value);
    let at = index;
    if (start > content) {
      value.push(...Array.from({ length: start - content }, () => ' '));
      at = value.length;
    }
    if (this.insert || at >= value.length) value.splice(at, 0, ...incoming);
    else value.splice(at, Math.min(incoming.length, value.length - at), ...incoming);
    if (unitsOf(value) > field.capacity) return null;
    return { value, end: start + widthOf(incoming) };
  }

  /** Grapheme index and its starting cell for a logical cell; cells past the content map to the end. */
  private locate(field: BufferField, offset: number): { index: number; start: number } {
    let start = 0;
    for (const [index, grapheme] of field.value.entries()) {
      const width = graphemeWidth(grapheme);
      if (offset < start + width) return { index, start };
      start += width;
    }
    return { index: field.value.length, start: Math.max(offset, start) };
  }

  /** Deletes the character before the cursor and moves left (Backspace). */
  eraseLeft(): void {
    if (this.lock !== null) return;
    const field = this.currentInput();
    if (field === undefined) { this.lock = 'protected'; return; }
    const logical = this.logical(field);
    if (logical === 0) return;
    const { index, start } = this.locate(field, logical);
    if (start > widthOf(field.value) || index === 0) {
      this.reveal(field, logical - 1);
      return;
    }
    const removed = field.value[index - 1] ?? ' ';
    field.value = field.value.filter((_, position) => position !== index - 1);
    field.modified = true;
    this.reveal(field, start - graphemeWidth(removed));
  }

  /** Deletes the character under the cursor; the rest of the field shifts left (Delete). */
  deleteCharacter(): void {
    if (this.lock !== null) return;
    const field = this.currentInput();
    if (field === undefined) { this.lock = 'protected'; return; }
    const { index, start } = this.locate(field, this.logical(field));
    if (index >= field.value.length) return;
    field.value = field.value.filter((_, position) => position !== index);
    field.modified = true;
    this.reveal(field, start);
  }

  /** Clears from the cursor to the end of the current field (Erase EOF). */
  eraseToEnd(): void {
    if (this.lock !== null) return;
    const field = this.currentInput();
    if (field === undefined) { this.lock = 'protected'; return; }
    const { index, start } = this.locate(field, this.logical(field));
    if (index < field.value.length) {
      field.value = field.value.slice(0, index);
      field.modified = true;
    }
    this.reveal(field, start);
  }

  /** Clears every input field on the screen and moves to the first one (Erase Input). */
  eraseInput(): void {
    if (this.lock !== null) return;
    for (const field of this.inputFields) {
      if (field.value.length > 0) {
        field.value = [];
        field.modified = true;
      }
      field.offset = 0;
    }
    this.home();
  }

  tab(): void {
    if (this.lock !== null) return;
    this.enter(this.nextInputAfter(this.cursor));
  }

  backTab(): void {
    if (this.lock !== null) return;
    const current = this.currentInput();
    if (current !== undefined && (this.cursor > current.address || current.offset > 0)) { this.enter(current); return; }
    const inputs = this.inputFields;
    this.enter([...inputs].reverse().find((field) => field.address < this.cursor) ?? inputs.at(-1));
  }

  home(): void {
    if (this.lock !== null) return;
    this.enter(this.inputFields[0]);
  }

  /** Moves after the last character of the current field, or onto the last character when the field is full. */
  end(): void {
    if (this.lock !== null) return;
    const field = this.currentInput();
    if (field === undefined) return;
    const content = widthOf(field.value);
    const last = field.value.at(-1);
    this.reveal(field, unitsOf(field.value) >= field.capacity && last !== undefined ? content - graphemeWidth(last) : content);
  }

  move(direction: 'left' | 'right' | 'up' | 'down'): void {
    if (this.lock !== null) return;
    if (this.scrollWithin(direction)) return;
    const step = { left: -1, right: 1, up: -COLUMNS, down: COLUMNS }[direction];
    const target = (this.cursor + step + SCREEN_CELLS) % SCREEN_CELLS;
    this.cursor = this.snap(target, direction === 'right' ? 'right' : 'left');
  }

  /** Scrolls the current field's window when the cursor would otherwise leave it with content beyond. */
  private scrollWithin(direction: 'left' | 'right' | 'up' | 'down'): boolean {
    const field = this.currentInput();
    if (field === undefined) return false;
    const logical = this.logical(field);
    if (direction === 'left' && logical === field.offset && field.offset > 0) {
      const { start } = this.locate(field, logical - 1);
      this.reveal(field, start);
      return true;
    }
    if (direction === 'right') {
      const { index, start } = this.locate(field, logical);
      const next = start + (index < field.value.length ? graphemeWidth(field.value[index] ?? ' ') : 1);
      if (next >= field.offset + field.length && next <= widthOf(field.value)) {
        this.reveal(field, next);
        return true;
      }
    }
    return false;
  }

  /** Positions the cursor at a cell, as a pointer click does. */
  moveTo(row: number, column: number): void {
    if (this.lock !== null) return;
    if (row < 0 || row >= ROWS || column < 0 || column >= COLUMNS) return;
    this.cursor = this.snap(row * COLUMNS + column, 'left');
  }

  /**
   * Pastes into the current field only. Text with line breaks, tabs or controls, text that would
   * exceed the capacity, and non-numeric text in a numeric field are rejected whole; a paste never submits.
   */
  paste(text: string): PasteResult {
    if (this.lock !== null) return { accepted: false, reason: 'The keyboard is locked. Press Reset (Esc) first.' };
    const field = this.currentInput();
    if (field === undefined) return { accepted: false, reason: 'Paste needs the cursor in an input field.' };
    if (/[\r\n\t]/u.test(text)) return { accepted: false, reason: 'Paste rejected: it contains line breaks or tabs. Paste one field at a time.' };
    if (hasForbiddenCharacter(text)) return { accepted: false, reason: 'Paste rejected: it contains control or invisible formatting characters.' };
    const incoming = graphemes(text);
    if (incoming.length === 0) return { accepted: true, reason: null };
    if (field.numeric && !incoming.every((grapheme) => NUMERIC.test(grapheme))) return { accepted: false, reason: 'Paste rejected: this field accepts only digits, a decimal point and a minus sign.' };
    const placed = this.place(field, incoming);
    if (placed === null) return { accepted: false, reason: `Paste rejected: the result would exceed this field's ${field.capacity}-character limit.` };
    field.value = placed.value;
    field.modified = true;
    const last = field.value.at(-1);
    const full = unitsOf(field.value) >= field.capacity && placed.end >= widthOf(field.value) && last !== undefined;
    this.reveal(field, full ? placed.end - graphemeWidth(last) : placed.end);
    return { accepted: true, reason: null };
  }

  /**
   * Cell contents for rendering. Each entry is the grapheme starting at that cell, '' for the second
   * cell of a wide grapheme, or ' ' for a blank. Only the scrolled window of each field is drawn.
   */
  cells(): string[] {
    const cells = Array.from({ length: SCREEN_CELLS }, () => ' ');
    for (const field of this.fields) {
      let start = 0;
      for (const grapheme of field.value) {
        const width = graphemeWidth(grapheme);
        if (start + width > field.offset + field.length) break;
        if (start >= field.offset) {
          const cell = field.address + start - field.offset;
          cells[cell] = grapheme;
          if (width === 2) cells[cell + 1] = '';
        }
        start += width;
      }
    }
    return cells;
  }

  private nextInputAfter(address: number): BufferField | undefined {
    const inputs = this.inputFields;
    return inputs.find((field) => field.address > address) ?? inputs[0];
  }

  /** Keeps the cursor off the second cell of a wide grapheme, moving in the given direction. */
  private snap(address: number, direction: 'left' | 'right'): number {
    const field = this.fieldAt(address);
    if (field === undefined) return address;
    let start = 0;
    for (const grapheme of field.value) {
      const width = graphemeWidth(grapheme);
      const cell = field.address + start - field.offset;
      if (address > cell && address < cell + width) return direction === 'right' ? (cell + width) % SCREEN_CELLS : cell;
      start += width;
    }
    return address;
  }
}
