import { copyFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore, type FinancialStore } from '@computer-use/financial-database/services';
import { test as base, expect, type Locator, type Page, type TestInfo } from '@playwright/test';

import { startTerminalHost } from '../src/server/app.js';
import { COLUMNS } from '../src/shared/protocol.js';
import { ensureTemplate } from '../test/template.js';

export const PUBLIC_DIRECTORY = resolve(import.meta.dirname, '..', 'dist', 'public');

export interface LaunchedTerminal {
  origin: string;
  store: FinancialStore;
  bindings: readonly DatasetBinding[];
  /** Number typed on the sign-on screen for an institution. */
  institutionNumber: (institutionId: string) => number;
  datasetId: (institutionId: string) => string;
  /** Read-only query against this test's disposable copy of the template world. */
  query: <T>(sql: string, ...params: SQLInputValue[]) => T[];
}

/** Browser observations and database observations are recorded separately and written per test. */
export interface EvidenceLog {
  browser: (label: string, detail: unknown) => void;
  database: (label: string, detail: unknown) => void;
}

interface Fixtures {
  terminal: LaunchedTerminal;
  evidence: EvidenceLog;
  /** Uncaught exceptions and console errors, excluding the browser's own log line for an expected 4xx response. */
  pageErrors: string[];
}

export function bindingFor(bindings: readonly DatasetBinding[], institutionId: string): DatasetBinding {
  const binding = bindings.find((item) => item.institutionId === institutionId);
  if (binding === undefined) throw new Error(`The template world has no ${institutionId} dataset.`);
  return binding;
}

export const test = base.extend<Fixtures>({
  terminal: async ({ browserName: _browserName }, use) => {
    const template = await ensureTemplate();
    const directory = mkdtempSync(join(tmpdir(), 'terminal-host-verify-'));
    const path = join(directory, 'financial.sqlite');
    let handle: Awaited<ReturnType<typeof startTerminalHost>> | undefined;
    try {
      copyFileSync(template.path, path);
      const store = openFinancialStore({ path });
      handle = await startTerminalHost({
        store, bindings: template.bindings, operator: { actorNumbers: ['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005'], fixed: false },
        port: 0, publicDirectory: PUBLIC_DIRECTORY, onClose: () => { store.close(); },
      });
      await use({
        origin: handle.origin,
        store,
        bindings: template.bindings,
        institutionNumber: (institutionId) => template.bindings.indexOf(bindingFor(template.bindings, institutionId)) + 1,
        datasetId: (institutionId) => bindingFor(template.bindings, institutionId).datasetId,
        query<T>(sql: string, ...params: SQLInputValue[]): T[] {
          using database = new DatabaseSync(path, { readOnly: true });
          return database.prepare(sql).all(...params) as T[];
        },
      });
    } finally {
      await handle?.close();
      rmSync(directory, { recursive: true, force: true });
    }
  },
  evidence: async ({ browserName: _browserName }, use, info) => {
    const browser: { label: string; detail: unknown }[] = [];
    const database: { label: string; detail: unknown }[] = [];
    await use({ browser: (label, detail) => { browser.push({ label, detail }); }, database: (label, detail) => { database.push({ label, detail }); } });
    const path = info.outputPath('evidence.json');
    writeFileSync(path, `${JSON.stringify({ test: info.titlePath.slice(1), status: info.status, browser, database }, null, 2)}\n`);
    await info.attach('evidence', { path, contentType: 'application/json' });
  },
  pageErrors: async ({ page }, use) => {
    const errors: string[] = [];
    page.on('pageerror', (error) => { errors.push(error.message); });
    page.on('console', (message) => { if (message.type() === 'error' && !message.text().startsWith('Failed to load resource')) errors.push(message.text()); });
    await use(errors);
  },
});

export { expect };

export async function shot(page: Page, info: TestInfo, name: string): Promise<void> {
  const path = info.outputPath(`${name}.png`);
  await page.screenshot({ path });
  await info.attach(name, { path, contentType: 'image/png' });
}

export const terminalRoot = (page: Page): Locator => page.locator('#terminal');
export const oia = (page: Page): Locator => page.locator('.oia');
export const cellAt = (page: Page, row: number, column: number): Locator => page.locator(`.screen [data-a="${String(row * COLUMNS + column)}"]`);

/** Screen rows as displayed, one string per row. A wide character is one string element spanning two cells. */
export async function rows(page: Page): Promise<string[]> {
  return page.locator('.screen .row').allTextContents();
}

/** Text of a field by its row, column and width on a row without wide characters. */
export async function fieldText(page: Page, row: number, column: number, length: number): Promise<string> {
  return ((await rows(page))[row] ?? '').slice(column, column + length).trimEnd();
}

export async function listIndex(page: Page, needle: string): Promise<number> {
  const index = (await rows(page)).slice(7, 19).findIndex((line) => line.includes(needle));
  if (index < 0) throw new Error(`${needle} is not listed:\n${(await rows(page)).join('\n')}`);
  return index;
}

export async function waitScreen(page: Page, screenId: string): Promise<void> {
  await expect(terminalRoot(page)).toHaveAttribute('data-screen-id', screenId);
  await expect(terminalRoot(page)).toHaveAttribute('data-lock', 'none');
}

/** Performs an action that transmits the screen and waits for the host's answer, a new screen sequence. */
export async function transmit(page: Page, action: () => Promise<void>): Promise<void> {
  const before = await terminalRoot(page).getAttribute('data-sequence') ?? '';
  await action();
  await expect(terminalRoot(page)).not.toHaveAttribute('data-sequence', before);
  await expect(terminalRoot(page)).toHaveAttribute('data-lock', 'none');
}

export const attention = (page: Page, key: string): Promise<void> => transmit(page, () => page.keyboard.press(key));

/** Clicks a cell, as an operator positions the cursor, and types there. */
export async function typeAt(page: Page, row: number, column: number, text: string): Promise<void> {
  await cellAt(page, row, column).click();
  await page.keyboard.type(text);
}

export async function openTerminal(page: Page, origin: string): Promise<void> {
  await page.goto(origin);
  await waitScreen(page, 'THSIGN');
  await expect(terminalRoot(page)).toHaveClass(/has-focus/u);
}

export async function signOn(page: Page, institutionNumber: number, operator: string): Promise<void> {
  await typeAt(page, 13, 28, String(institutionNumber));
  await typeAt(page, 14, 28, operator);
  await attention(page, 'Enter');
  await waitScreen(page, 'THMENU');
}

export async function menu(page: Page, option: string): Promise<void> {
  await typeAt(page, 19, 15, option);
  await attention(page, 'Enter');
}

/** Main menu option 3: search one account number and act on its row with a selection code. */
export async function accountAction(page: Page, accountNumber: string, code: string): Promise<void> {
  await menu(page, '3');
  await waitScreen(page, 'THAC01');
  await typeAt(page, 4, 11, accountNumber);
  await attention(page, 'Enter');
  await typeAt(page, 7 + await listIndex(page, accountNumber), 1, code);
  await attention(page, 'Enter');
}

/** Parses a rendered amount such as "5,925.89 USD" into exact minor units. */
export function displayedMoney(text: string): { minorUnits: number; currency: string } {
  const match = /^(-?)([\d,]+)(?:\.(\d+))?\s+([A-Z]{3})$/u.exec(text.trim());
  if (match === null) throw new Error(`Not a rendered amount: ${text}`);
  const [, sign = '', whole = '0', fraction = '', currency = ''] = match;
  const minorUnits = Number(`${whole.replaceAll(',', '')}${fraction}`);
  return { minorUnits: sign === '-' ? -minorUnits : minorUnits, currency };
}
