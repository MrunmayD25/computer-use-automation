import { join } from 'node:path';

import { verificationRunStore } from '@computer-use/financial-database/services';

import { startTerminalHost } from '../src/server/app.js';
import { ensureTemplate } from '../test/template.js';
import { loadVerifier } from './evaluator.js';
import {
  accountAction, attention, bindingFor, cellAt, displayedMoney, expect, fieldText, PUBLIC_DIRECTORY, rows, shot, terminalRoot, test, typeAt, waitScreen,
} from './fixtures.js';

test('an app-driven withdrawal inside an isolated verification run passes the database verifier', async ({ page, evidence, pageErrors }, info) => {
  const { startTaskRun, terminalWithdrawalContract, terminalWithdrawalCase: facts } = await loadVerifier();
  const template = await ensureTemplate();
  const binding = bindingFor(template.bindings, 'northstar');
  const root = info.outputPath('evaluator');
  const session = await startTaskRun({ root, sourcePath: template.path, contract: terminalWithdrawalContract(binding) });
  const handle = await startTerminalHost({
    store: verificationRunStore(session), bindings: [binding], operator: { actorNumbers: ['OP0002'], fixed: true }, principalKind: 'automation',
    port: 0, publicDirectory: PUBLIC_DIRECTORY,
  });
  let outputs: Record<string, unknown>;
  let requestKey: string;
  try {
    await page.goto(handle.origin);
    await waitScreen(page, 'THSIGN');
    expect(await fieldText(page, 13, 28, 2)).toBe('1');
    expect(await fieldText(page, 14, 28, 6)).toBe('OP0002');
    await expect(cellAt(page, 14, 28)).not.toHaveClass(/\bin\b/u);
    await attention(page, 'Enter');
    await waitScreen(page, 'THMENU');
    expect((await rows(page))[1]).toContain('OPR OP0002 Casey Patel');

    await accountAction(page, facts.accountNumber, 'S');
    await waitScreen(page, 'THAC02');
    const before = displayedMoney(await fieldText(page, 10, 19, 30));
    expect(before).toEqual({ minorUnits: facts.balanceBefore, currency: 'USD' });
    evidence.browser('ui-target', { screen: 'THAC02', account: await fieldText(page, 3, 19, 10), postedBalance: before });
    await shot(page, info, 'evaluator-1-target');

    await attention(page, 'F11');
    await waitScreen(page, 'THTX02');
    expect(await fieldText(page, 3, 21, 10)).toBe(facts.accountNumber);
    await page.keyboard.type('40.25');
    await typeAt(page, 9, 21, facts.description);
    await attention(page, 'Enter');
    await waitScreen(page, 'THTX04');
    expect(await fieldText(page, 6, 13, 30)).toBe('40.25 USD');
    expect((await rows(page)).slice(10, 12).join('\n')).toContain(facts.accountNumber);
    requestKey = await fieldText(page, 18, 20, 40);
    expect(requestKey).toMatch(/^th-[0-9a-f-]{36}$/u);
    await shot(page, info, 'evaluator-2-review');
    await page.keyboard.type('Y');
    await page.keyboard.press('Enter');
    await page.keyboard.press('Enter');
    await waitScreen(page, 'THRC01');

    const receiptNumber = await fieldText(page, 3, 17, 12);
    expect(receiptNumber).toMatch(/^RCP\d{8}$/u);
    expect(await fieldText(page, 4, 17, 30)).toBe('cash.withdraw');
    evidence.browser('ui-receipt', { receiptNumber, requestKey, message: await fieldText(page, 21, 0, 80) });

    await attention(page, 'F3');
    await waitScreen(page, 'THAC02');
    expect(await fieldText(page, 3, 19, 10)).toBe(facts.accountNumber);
    const after = displayedMoney(await fieldText(page, 10, 19, 30));
    expect(after).toEqual({ minorUnits: facts.balanceBefore - facts.amountMinorUnits, currency: 'USD' });
    evidence.browser('ui-outcome', { postedBalance: after, available: await fieldText(page, 11, 19, 30) });
    await shot(page, info, 'evaluator-3-outcome');
    outputs = { accountNumber: facts.accountNumber, amountMinorUnits: facts.amountMinorUnits, currency: after.currency, postedMinorUnits: after.minorUnits, receiptNumber };
    await expect(terminalRoot(page)).toHaveAttribute('data-lock', 'none');
    expect(pageErrors).toEqual([]);
  } finally {
    await handle.close();
  }

  const operations = session.read((database) => database.prepare('SELECT actor_id, operation_kind, status FROM operations WHERE dataset_id=? AND idempotency_key=?').all(binding.datasetId, requestKey));
  expect(operations).toEqual([{ actor_id: facts.actorId, operation_kind: 'cash.withdraw', status: 'committed' }]);
  evidence.database('run still readable after the terminal host closed', { requestKey, operations });

  const reportPath = join(root, 'report.json');
  const report = await session.verify({ disposition: 'completed', outputs }, { reportPath, dispose: true });
  session.close();
  const failing = report.checks.filter((check) => check.status !== 'pass');
  evidence.database('verifier report', { reportPath, databaseVerdict: report.databaseVerdict, checks: report.checks.length, failing, capturedBindings: report.capturedBindings });
  await info.attach('verifier-report', { path: reportPath, contentType: 'application/json' });
  expect(failing).toEqual([]);
  expect(report.databaseVerdict).toBe('pass');
});
