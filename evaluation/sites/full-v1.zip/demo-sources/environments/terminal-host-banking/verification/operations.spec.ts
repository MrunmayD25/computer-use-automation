import type { Page } from '@playwright/test';

import { attention, cellAt, expect, fieldText, menu, openTerminal, rows, signOn, test, typeAt, waitScreen } from './fixtures.js';

async function confirm(page: Page): Promise<void> {
  await typeAt(page, 19, 34, 'Y');
  await attention(page, 'Enter');
  await waitScreen(page, 'THRC01');
}

/** Types `mark` into the single-cell selection input on the rendered row containing `needle`. */
async function markRow(page: Page, needle: string, mark = 'S'): Promise<void> {
  const lines = await rows(page);
  const index = lines.findIndex((line, row) => row >= 4 && line.includes(needle));
  if (index < 0) throw new Error(`${needle} is not listed:\n${lines.join('\n')}`);
  await typeAt(page, index, 1, mark);
  await attention(page, 'Enter');
}

test('a servicing form fills its member from the pick directory and posts a preferred name', async ({ page, terminal, evidence, pageErrors }) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await menu(page, '11');
  await waitScreen(page, 'THMENU');
  await menu(page, 'NM02');
  await waitScreen(page, 'THID04');
  // The member field's F4 directory opens and the pick returns to this form.
  await cellAt(page, 4, 21).click();
  await attention(page, 'F4');
  await waitScreen(page, 'THDI01');
  await markRow(page, 'NM000001');
  await waitScreen(page, 'THID04');
  const memberField = await fieldText(page, 4, 21, 40);
  expect(memberField.length).toBeGreaterThan(0);
  evidence.browser('the member directory pick merged its value back into the calling form', { memberField });
  await typeAt(page, 5, 21, 'Casey');
  await typeAt(page, 6, 21, 'S');
  await attention(page, 'Enter');
  await waitScreen(page, 'THRV01');
  await confirm(page);
  const stored = terminal.query<{ preferred_name: string }>(
    'SELECT p.preferred_name FROM people p JOIN members m ON m.dataset_id=p.dataset_id AND m.party_id=p.party_id WHERE m.dataset_id=? AND m.member_number=?',
    terminal.datasetId('northstar'), 'NM000001');
  expect(stored).toEqual([{ preferred_name: 'Casey' }]);
  evidence.database('the preferred name is stored on the shared record', stored);
  expect(pageErrors).toEqual([]);
});

test('a supervised command completes maker request, checker decision and checker execution in the browser', async ({ page, terminal, evidence, pageErrors }) => {
  const verified = terminal.query<{ member_number: string }>(
    "SELECT m.member_number FROM members m JOIN identity_evidence e ON e.dataset_id=m.dataset_id AND e.party_id=m.party_id WHERE m.dataset_id=? AND e.status='verified' AND m.status='active' ORDER BY m.member_number LIMIT 1",
    terminal.datasetId('northstar'))[0];
  if (verified === undefined) throw new Error('No member with verified evidence in the seeded world.');

  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await menu(page, '11');
  await menu(page, 'NM01');
  await waitScreen(page, 'THID03');
  await typeAt(page, 4, 21, verified.member_number);
  await typeAt(page, 5, 21, 'Alexandra');
  await typeAt(page, 6, 21, 'Reyes');
  await attention(page, 'Enter');
  // The evidence picker lists only this member's identity evidence.
  await cellAt(page, 7, 21).click();
  await attention(page, 'F4');
  await waitScreen(page, 'THDI05');
  await markRow(page, 'evidence-');
  await waitScreen(page, 'THID03');
  await attention(page, 'Enter');
  // The command has an empty approvalId: the approval-request screen opens instead of a review.
  await waitScreen(page, 'THAP03');
  await typeAt(page, 12, 21, 'OP0005');
  await cellAt(page, 14, 21).click();
  await attention(page, 'F4');
  await waitScreen(page, 'THDI15');
  await markRow(page, 'policy-');
  await waitScreen(page, 'THAP03');
  await attention(page, 'Enter');
  await confirm(page);
  evidence.browser('the maker requested independent approval of the exact prepared command', {});

  // The named checker signs on in a second session and decides from the approvals inbox.
  const checkerPage = await page.context().newPage();
  await openTerminal(checkerPage, terminal.origin);
  await signOn(checkerPage, terminal.institutionNumber('northstar'), 'OP0005');
  await attention(checkerPage, 'F8');
  await menu(checkerPage, '15');
  await waitScreen(checkerPage, 'THDI18');
  await markRow(checkerPage, 'member.legal_name.update');
  await waitScreen(checkerPage, 'THAP02');
  await typeAt(checkerPage, 19, 26, 'A');
  await typeAt(checkerPage, 20, 13, 'Identity verified at branch.');
  await attention(checkerPage, 'Enter');
  await waitScreen(checkerPage, 'THAP05');
  await typeAt(checkerPage, 19, 34, 'Y');
  await attention(checkerPage, 'Enter');
  await waitScreen(checkerPage, 'THRC01');

  // Reopen the approved request; F9 executes the bound target as the checker.
  await attention(checkerPage, 'F3');
  await waitScreen(checkerPage, 'THDI18');
  await markRow(checkerPage, 'member.legal_name.update');
  await waitScreen(checkerPage, 'THAP02');
  await attention(checkerPage, 'F9');
  await waitScreen(checkerPage, 'THAP04');
  await typeAt(checkerPage, 19, 34, 'Y');
  await attention(checkerPage, 'Enter');
  await waitScreen(checkerPage, 'THRC01');
  evidence.browser('the checker decided and executed the approved target from the terminal', {});

  const person = terminal.query<{ legal_given: string; legal_family: string }>(
    'SELECT p.legal_given,p.legal_family FROM people p JOIN members m ON m.dataset_id=p.dataset_id AND m.party_id=p.party_id WHERE m.dataset_id=? AND m.member_number=?',
    terminal.datasetId('northstar'), verified.member_number);
  expect(person).toEqual([{ legal_given: 'Alexandra', legal_family: 'Reyes' }]);
  evidence.database('the approved command changed the shared record exactly once', person);
  await checkerPage.close();
  expect(pageErrors).toEqual([]);
});
