import type { Page } from '@playwright/test';
import { executeCommand, listApprovals, type ServiceCommand, type ServiceContext } from '@computer-use/financial-database/services';

import { attention, bindingFor, cellAt, expect, fieldText, listIndex, menu, oia, openTerminal, rows, signOn, test, typeAt, waitScreen } from './fixtures.js';

async function paste(page: Page, text: string): Promise<void> {
  // The expression runs in the page; the Node typings used for specs have no DOM declarations.
  await page.evaluate(`navigator.clipboard.writeText(${JSON.stringify(text)})`);
  await page.keyboard.press('ControlOrMeta+KeyV');
}

async function openMember(page: Page, memberNumber: string): Promise<void> {
  await menu(page, '1');
  await waitScreen(page, 'THMB01');
  await typeAt(page, 3, 11, memberNumber);
  await attention(page, 'Enter');
  await typeAt(page, 7 + await listIndex(page, memberNumber), 1, 'S');
  await attention(page, 'Enter');
  await waitScreen(page, 'THMB02');
}

async function confirm(page: Page): Promise<void> {
  await typeAt(page, 19, 34, 'Y');
  await attention(page, 'Enter');
  await waitScreen(page, 'THRC01');
}

test('a value longer than its field scrolls while typed and is stored whole', async ({ page, terminal, evidence, pageErrors }) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await openMember(page, 'NM000003');
  await attention(page, 'F4');
  await waitScreen(page, 'THMB05');
  const line = '1200 North Lakeshore Drive, Harbor Point Towers, Suite 4100 East';
  await cellAt(page, 10, 17).click();
  await page.keyboard.press('Alt+KeyE');
  await page.keyboard.type(line);
  const visible = await fieldText(page, 10, 17, 40);
  expect(visible.length).toBeGreaterThan(30);
  expect(line.endsWith(visible.trimEnd())).toBe(true);
  await expect(oia(page)).toContainText('/80');
  evidence.browser('typing past the 40-cell field scrolls it; the status line counts characters against the 80-character limit', { visible, oia: await oia(page).textContent() });
  await attention(page, 'Enter');
  await waitScreen(page, 'THMB06');
  expect((await rows(page)).join(' ').replace(/\s+/gu, ' ')).toContain('Harbor Point Towers, Suite 4100');
  await confirm(page);
  const stored = terminal.query<{ line1: string }>('SELECT line1 FROM addresses WHERE dataset_id=? AND line1=?', terminal.datasetId('northstar'), line);
  expect(stored).toEqual([{ line1: line }]);
  evidence.database('the full address line is stored', stored);
  expect(pageErrors).toEqual([]);
});

test('a note longer than one screen continues on a second editor page', async ({ page, terminal, evidence, pageErrors }) => {
  await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await openMember(page, 'NM000003');
  await attention(page, 'F5');
  await waitScreen(page, 'THMB07');
  await attention(page, 'F6');
  await waitScreen(page, 'THMB08');
  const sentence = 'Member explained the disputed September card charges in detail. ';
  const first = sentence.repeat(15).trim();
  const second = sentence.repeat(11).trim();
  await cellAt(page, 6, 1).click();
  await paste(page, first);
  expect((await rows(page)).slice(6, 20).join('')).toContain(first.slice(900, 960));
  await attention(page, 'F8');
  await expect(page.locator('.screen')).toContainText('PAGE 2 OF 2');
  await cellAt(page, 6, 1).click();
  await paste(page, second);
  evidence.browser('the second page holds the continuation', { page: ((await rows(page))[1] ?? '').trim() });
  await attention(page, 'Enter');
  await waitScreen(page, 'THMB10');
  await confirm(page);
  const [note] = terminal.query<{ text: string }>(`SELECT n.text FROM member_notes n JOIN members m ON m.dataset_id=n.dataset_id AND m.id=n.member_id
    WHERE n.dataset_id=? AND m.member_number='NM000003' ORDER BY n.created_at DESC LIMIT 1`, terminal.datasetId('northstar'));
  expect(note?.text).toBe(`${first} ${second}`);
  evidence.database('the stored note joins both pages', { length: note?.text.length });
  expect(pageErrors).toEqual([]);
});

test('an organization member is onboarded from the switched form', async ({ page, terminal, evidence, pageErrors }) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await menu(page, '2');
  await waitScreen(page, 'THMB03');
  await typeAt(page, 3, 21, 'O');
  await attention(page, 'Enter');
  await expect(page.locator('.screen')).toContainText('ORGANIZATION FORM');
  const legalName = 'Harbor Light Community Kitchen Cooperative Association of Greater Lakeside';
  await typeAt(page, 5, 21, legalName);
  await typeAt(page, 6, 21, 'NFP-20260913');
  await typeAt(page, 7, 21, 'N');
  await attention(page, 'Enter');
  await waitScreen(page, 'THMB04');
  await confirm(page);
  const stored = terminal.query<{ legal_name: string; organization_type: string }>('SELECT legal_name, organization_type FROM organizations WHERE dataset_id=? AND registration_number=?',
    terminal.datasetId('northstar'), 'NFP-20260913');
  expect(stored).toEqual([{ legal_name: legalName, organization_type: 'nonprofit' }]);
  evidence.database('organization stored with its full legal name', stored);
  expect(pageErrors).toEqual([]);
});

test('a case resolves and its closure is refused while a work item is open', async ({ page, terminal, evidence, pageErrors }) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await menu(page, '9');
  await waitScreen(page, 'THCS01');
  await typeAt(page, 3, 9, 'CS000001');
  await attention(page, 'Enter');
  await typeAt(page, 7 + await listIndex(page, 'CS000001'), 1, 'T');
  await attention(page, 'Enter');
  await waitScreen(page, 'THCS07');
  await typeAt(page, 7, 21, 'R');
  await typeAt(page, 13, 1, 'Statement copy mailed to the member');
  await attention(page, 'Enter');
  await waitScreen(page, 'THCS08');
  await confirm(page);
  await attention(page, 'F3');
  await typeAt(page, 7, 1, 'T');
  await attention(page, 'Enter');
  await waitScreen(page, 'THCS07');
  await typeAt(page, 7, 21, 'C');
  await typeAt(page, 13, 1, 'Closing');
  await attention(page, 'Enter');
  await waitScreen(page, 'THCS07');
  await expect(page.locator('.screen')).toContainText('OPEN DEPENDENCIES');
  const [record] = terminal.query<{ state: string }>("SELECT state FROM cases WHERE dataset_id=? AND case_number='CS000001'", terminal.datasetId('northstar'));
  expect(record).toEqual({ state: 'resolved' });
  evidence.browser('closure refusal names the open work item', { message: await fieldText(page, 21, 0, 80) });
  evidence.database('the case stays resolved', record);
  expect(pageErrors).toEqual([]);
});

test('case subject correction uses displayed evidence and the exact independently approved proposal', async ({ page, terminal, evidence, pageErrors }) => {
  const datasetId = terminal.datasetId('northstar');
  const [source] = terminal.query<{ id: string; member_id: string; version: number }>("SELECT id,member_id,version FROM cases WHERE dataset_id=? AND case_number='CS000003'", datasetId);
  const [target] = terminal.query<{ member_id: string; member_number: string; account_id: string; account_number: string }>(`SELECT m.id AS member_id,m.member_number,a.id AS account_id,a.account_number FROM members m JOIN accounts a ON a.dataset_id=m.dataset_id AND a.member_id=m.id
    JOIN cases c ON c.dataset_id=m.dataset_id WHERE m.dataset_id=? AND c.case_number='CS000003' AND m.id<>c.member_id AND m.status<>'merged' ORDER BY m.member_number,a.account_number LIMIT 1`, datasetId);
  if (source === undefined || target === undefined) throw new Error('Case correction subjects are missing.');
  const [document] = terminal.query<{ id: string }>(`SELECT v.id FROM members m JOIN documents d ON d.dataset_id=m.dataset_id AND d.owner_party_id=m.party_id
    JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id WHERE m.dataset_id=? AND m.id=? AND v.status IN ('current','signed') ORDER BY v.issued_at,v.id LIMIT 1`, datasetId, target.member_id);
  const [policy] = terminal.query<{ id: string }>('SELECT id FROM policy_versions WHERE dataset_id=? AND effective_at<=? ORDER BY effective_at DESC,id DESC LIMIT 1', datasetId, '2026-09-14T15:00:00.000Z');
  if (document === undefined || policy === undefined) throw new Error('Case correction prerequisites are missing.');
  const binding = bindingFor(terminal.bindings, 'northstar');
  const serviceContext = (ordinal: number): ServiceContext => ({ binding, actorId: `northstar-actor-${String(ordinal)}`, reference: 'terminal-browser-case-subject' });
  const proposal: Extract<ServiceCommand, { kind: 'case.subject.correct' }> = { kind: 'case.subject.correct', caseId: source.id, expectedVersion: source.version, correctMemberId: target.member_id, correctAccountId: target.account_id, evidenceVersionId: document.id, approvalId: 'pending-approval' };
  const requested = executeCommand(terminal.store, serviceContext(2), { kind: 'approval.request', target: proposal, checkerActorId: 'northstar-actor-5', policyVersionId: policy.id, expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: null }, 'terminal-browser-subject-request');
  if (requested.kind !== 'committed') throw new Error(JSON.stringify(requested));
  const approvalId = requested.receipt.affected.find((item) => item.kind === 'approval')?.id;
  const approvals = listApprovals(terminal.store, serviceContext(5));
  if (approvalId === undefined || approvals.kind !== 'found') throw new Error('Approval prerequisite is missing.');
  const approval = approvals.approvals.find((item) => item.id === approvalId);
  if (approval === undefined) throw new Error('Checker cannot see the approval.');
  const decided = executeCommand(terminal.store, serviceContext(5), { kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Exact case subject and evidence reviewed.' }, 'terminal-browser-subject-approve');
  if (decided.kind !== 'committed') throw new Error(JSON.stringify(decided));
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0005');
  await menu(page, '9');
  await waitScreen(page, 'THCS01');
  await typeAt(page, 3, 9, 'CS000003');
  await attention(page, 'Enter');
  await typeAt(page, 7 + await listIndex(page, 'CS000003'), 1, 'C');
  await attention(page, 'Enter');
  await waitScreen(page, 'THCS09');
  await typeAt(page, 5, 21, target.member_number);
  await typeAt(page, 6, 21, target.account_number);
  await attention(page, 'Enter');
  await waitScreen(page, 'THCS09');
  expect((await rows(page)).join(' ')).toContain(document.id);
  await typeAt(page, 7, 21, document.id);
  await typeAt(page, 8, 21, approvalId);
  await attention(page, 'Enter');
  await waitScreen(page, 'THCS10');
  await confirm(page);
  const stored = terminal.query('SELECT c.member_id,c.account_id,q.visibility FROM cases c JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id WHERE c.dataset_id=? AND c.id=?', datasetId, source.id);
  expect(stored).toEqual([{ member_id: target.member_id, account_id: target.account_id, visibility: 'restricted' }]);
  evidence.browser('THCS09 displayed the evidence and reviewed the approved subject', { documentVersionId: document.id, approvalId });
  evidence.database('case subject corrected and restricted', stored);
  expect(pageErrors).toEqual([]);
});

test('case subject correction reports an evidence directory beyond its explicit bound', async ({ page, terminal, evidence, pageErrors }) => {
  const datasetId = terminal.datasetId('northstar');
  const [source] = terminal.query<{ member_id: string }>("SELECT member_id FROM cases WHERE dataset_id=? AND case_number='CS000003'", datasetId);
  const [target] = terminal.query<{ member_id: string; member_number: string; party_id: string }>(`SELECT m.id AS member_id,m.member_number,m.party_id FROM members m
    WHERE m.dataset_id=? AND m.id<>? AND m.status<>'merged' ORDER BY m.member_number LIMIT 1`, datasetId, source?.member_id ?? '');
  if (source === undefined || target === undefined) throw new Error('Case correction evidence-bound subjects are missing.');
  const [artifact] = terminal.query<{ digest: string; media_type: string; page_count: number | null }>(`SELECT v.digest,v.media_type,v.page_count FROM documents d
    JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id WHERE d.dataset_id=? AND d.owner_party_id=? LIMIT 1`, datasetId, target.party_id);
  const [total] = terminal.query<{ count: number }>(`SELECT COUNT(*) AS count FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id
    WHERE d.dataset_id=? AND d.owner_party_id=?`, datasetId, target.party_id);
  if (artifact === undefined || total === undefined) throw new Error('Case correction evidence-bound artifact is missing.');
  terminal.store.write({ kind: 'system', actorId: 'northstar-actor-5', reference: 'terminal-browser-correction-evidence-bound' }, (database) => {
    for (let index = total.count; index < 501; index += 1) {
      const suffix = String(index).padStart(3, '0');
      const documentId = `terminal-correction-bound-${suffix}`;
      database.prepare(`INSERT INTO documents (dataset_id,id,owner_party_id,account_id,document_type,display_name,retention_class,created_at)
        VALUES (?,?,?,?,?,?,?,'2026-09-14T15:00:00.000Z')`).run(datasetId, documentId, target.party_id, null, 'correction-boundary', `boundary-${suffix}.pdf`, 'servicing-evidence');
      database.prepare(`INSERT INTO document_versions (dataset_id,id,document_id,version,digest,media_type,issued_at,period_start,period_end,page_count,status)
        VALUES (?,?,?,1,?,?,'2026-09-14T15:00:00.000Z',NULL,NULL,?,'superseded')`).run(datasetId, `${documentId}-v1`, documentId, artifact.digest, artifact.media_type, artifact.page_count);
    }
  });

  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0005');
  await menu(page, '9'); await waitScreen(page, 'THCS01');
  await typeAt(page, 3, 9, 'CS000003'); await attention(page, 'Enter');
  await typeAt(page, 7 + await listIndex(page, 'CS000003'), 1, 'C'); await attention(page, 'Enter');
  await waitScreen(page, 'THCS09');
  await typeAt(page, 5, 21, target.member_number); await attention(page, 'Enter');
  await waitScreen(page, 'THCS09');
  await expect(page.locator('.screen')).toContainText('EVIDENCE LIST REFUSED: More than 500 document versions');
  evidence.browser('THCS09 reports explicit prerequisite exhaustion after corrected-member selection', { correctedMember: target.member_number, bound: 500 });
  expect(pageErrors).toEqual([]);
});

test('a closed case reopens with a retained document and a new evidence work item', async ({ page, terminal, evidence, pageErrors }) => {
  const datasetId = terminal.datasetId('northstar');
  const [document] = terminal.query<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
    JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id JOIN cases c ON c.dataset_id=m.dataset_id AND c.member_id=m.id
    WHERE c.dataset_id=? AND c.case_number='CS000005' AND v.status IN ('current','signed') LIMIT 1`, datasetId);
  if (document === undefined) throw new Error('Case evidence fixture is missing.');
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await menu(page, '9'); await waitScreen(page, 'THCS01');
  await typeAt(page, 3, 9, 'CS000005'); await attention(page, 'Enter');
  await typeAt(page, 7 + await listIndex(page, 'CS000005'), 1, 'T'); await attention(page, 'Enter');
  await waitScreen(page, 'THCS07');
  await typeAt(page, 7, 21, 'E'); await typeAt(page, 10, 21, 'missing-document-version');
  await typeAt(page, 13, 1, 'Member requests renewed review of retained statement.');
  await attention(page, 'Enter'); await waitScreen(page, 'THCS07');
  await expect(page.locator('.screen')).toContainText('EVIDENCE IS OUTSIDE THE CASE MEMBER SCOPE');
  expect(terminal.query("SELECT state FROM cases WHERE dataset_id=? AND case_number='CS000005'", datasetId)).toEqual([{ state: 'closed' }]);
  await typeAt(page, 10, 21, document.id); await attention(page, 'Enter');
  await waitScreen(page, 'THCS08'); await confirm(page);
  const effects = terminal.query(`SELECT c.state,d.reference_id,d.state AS dependency_state FROM cases c JOIN case_dependencies d ON d.dataset_id=c.dataset_id AND d.case_id=c.id
    WHERE c.dataset_id=? AND c.case_number='CS000005' AND d.kind='new-evidence'`, datasetId);
  expect(effects).toEqual([{ state: 'reopened', reference_id: document.id, dependency_state: 'open' }]);
  evidence.database('exact retained evidence and reopening dependency', effects);
  evidence.browser('missing document refused before review; valid evidence confirmed', document);
  expect(pageErrors).toEqual([]);
});
