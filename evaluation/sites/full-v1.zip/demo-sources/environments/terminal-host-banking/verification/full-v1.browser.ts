import type { Page } from '@playwright/test';

import {
  CATALOG, WORKFLOW_STEPS, evidencePath, qualificationRecord, sourceSha, writeEvidence,
} from '../../../evaluation/browser-qualification.mjs';
import { OPS } from '../src/server/screens/ops-registry.js';
import { MENU } from '../src/server/screens/session.js';
import {
  accountAction, attention, cellAt, expect, fieldText, menu, openTerminal, rows, signOn, terminalRoot, test, typeAt, waitScreen,
} from './fixtures.js';

const APPLICATION_ID = 'terminal-host-banking';
const SHARD_SIZE = 12;
const shard = (): number => Number(process.env.TERMINAL_QUAL_SHARD ?? '0');
const runId = (): string => process.env.TERMINAL_QUAL_RUN ?? `full-v1-${sourceSha().slice(0, 7)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
const command = (): string => `TERMINAL_QUAL_SHARD=${String(shard())} TERMINAL_QUAL_RUN=${runId()} npx playwright test -c verification/playwright.config.ts verification/full-v1.browser.ts`;

test.describe.configure({ timeout: 600_000 });

interface MenuPath { section: string; sectionCode?: string; optionCode: string }

const SECTION_CODES: Readonly<Record<string, string>> = { service: 'SV00', finance: 'FN00', payments: 'PY00', recon: 'RC00' };
const QUERY_OPTIONS: Readonly<Record<string, MenuPath>> = {
  'member.identity.resolve': { section: 'service', sectionCode: 'SV00', optionCode: 'ID03' },
  'member.merge.plan.inspect': { section: 'finance', sectionCode: 'FN00', optionCode: 'MP01' },
  'reconciliation.transfer': { section: 'recon', sectionCode: 'RC00', optionCode: 'RT10' },
  'reconciliation.settlement_batch': { section: 'recon', sectionCode: 'RC00', optionCode: 'RT11' },
  'reconciliation.cash_day': { section: 'recon', sectionCode: 'RC00', optionCode: 'RT12' },
  'batch.preview': { section: 'recon', sectionCode: 'RC00', optionCode: 'RT13' },
  'institution.context.verify': { section: 'recon', sectionCode: 'RC00', optionCode: 'IN01' },
};
const CORE_OPTIONS: Readonly<Record<string, string>> = {
  'member.create': 'MB03', 'contact.update': 'MB01', 'member.note.add': 'MB01', 'account.open': 'MB01',
  'account.nickname.update': 'AC01', 'account.statement_delivery.update': 'AC01', 'account.close': 'AC01',
  'cash.deposit': 'TX01', 'cash.withdraw': 'TX02', 'transfer.internal': 'TX03', 'account.inquire': 'AC01',
  'statement.export': 'AC01', 'document.statement.retrieve': 'AC01', 'case.open': 'CS01', 'case.route': 'CS01',
  'case.subject.correct': 'CS01', 'case.note.add': 'CS01', 'batch.contacts.apply': 'BT01', 'batch.fee_refunds.apply': 'BT01',
  'member.search': 'MB01', 'account.list': 'AC01', 'transaction.search': 'AV01', 'activity.inspect': 'AV01',
  'maintenance.draft.save': 'MN01', 'maintenance.draft.amend': 'MN01', 'maintenance.request.submit': 'MN01',
  'maintenance.request.withdraw': 'MN01', 'edit.cancel': 'MN01', 'operation.review': 'TX01', 'search.saved.manage': 'SS01',
};

function menuPath(capability: string): MenuPath {
  const query = QUERY_OPTIONS[capability];
  if (query !== undefined) return query;
  for (const [section, options] of Object.entries(MENU)) {
    const option = options.find(candidate => candidate.command === capability);
    if (option !== undefined) return { section, ...(section === 'main' ? {} : { sectionCode: SECTION_CODES[section] }), optionCode: option.code };
  }
  const core = CORE_OPTIONS[capability];
  if (core !== undefined) {
    if (core === 'BT01') return { section: 'payments', sectionCode: 'PY00', optionCode: core };
    return { section: 'main', optionCode: core };
  }
  throw new Error(`No visible terminal option is registered for ${capability}.`);
}

async function freshTerminal(page: Page, origin: string, institutionNumber: number): Promise<void> {
  await page.goto(origin);
  await page.evaluate('sessionStorage.clear()');
  await page.reload();
  await openTerminal(page, origin);
  await signOn(page, institutionNumber, 'OP0002');
}

async function inputStarts(page: Page): Promise<number[]> {
  const cells = page.locator('.screen .in[data-a]');
  const addresses: number[] = [];
  for (let index = 0; index < await cells.count(); index += 1) {
    const address = Number(await cells.nth(index).getAttribute('data-a'));
    if (Number.isInteger(address)) addresses.push(address);
  }
  const occupied = new Set(addresses);
  return addresses.filter(address => !occupied.has(address - 1));
}

function valueFor(line: string, column: number): string {
  const nearby = line.slice(Math.max(0, column - 24), column).replace(/[. ]+$/u, '').trim().toLowerCase();
  const suffix = line.slice(column);
  const code = /\b([A-Z])=/u.exec(suffix)?.[1];
  if (column === 1 && line.slice(3).trim() !== '') return 'S';
  if (/destination|to account|credit account/iu.test(nearby)) return 'AC0000002';
  if (/account/iu.test(nearby)) return 'AC0000001';
  if (/member/iu.test(nearby)) return 'NM000001';
  if (/email/iu.test(nearby)) return 'qual@example.test';
  if (/phone/iu.test(nearby)) return '3125550198';
  if (/instant|expires|timestamp/iu.test(nearby)) return '2026-09-15T18:00:00Z';
  if (/date|through|from|until/iu.test(nearby)) return '2026-09-15';
  if (/amount|limit|balance|fee/iu.test(nearby)) return '1.00';
  if (/currency|cur|ccy/iu.test(nearby)) return 'USD';
  if (/country/iu.test(nearby)) return 'US';
  if (/postal/iu.test(nearby)) return '60601';
  if (/region|state/iu.test(nearby)) return 'IL';
  if (/city/iu.test(nearby)) return 'Chicago';
  if (/address|line 1/iu.test(nearby)) return '100 Test Way';
  if (/given|preferred|first name/iu.test(nearby)) return 'Qual';
  if (/family|last name/iu.test(nearby)) return 'User';
  if (/reason|note|description|summary|text|name/iu.test(nearby)) return 'Qualification';
  return code ?? '1';
}

async function populateCurrentScreen(page: Page): Promise<string> {
  const visibleRows = await rows(page);
  const actions: string[] = [];
  for (const address of await inputStarts(page)) {
    const row = Math.floor(address / 80);
    const column = address % 80;
    const line = visibleRows[row] ?? '';
    let value = valueFor(line, column);
    await cellAt(page, row, column).click();
    await page.keyboard.press('Alt+KeyE');
    await page.keyboard.type(value);
    if ((await terminalRoot(page).getAttribute('data-lock')) !== 'none') {
      await page.keyboard.press('Escape');
      await cellAt(page, row, column).click();
      await page.keyboard.press('Alt+KeyE');
      value = '1';
      await page.keyboard.type(value);
    }
    actions.push(`${String(row + 1)}/${String(column + 1)}=${value}`);
  }
  return actions.join('; ');
}

async function exerciseCapability(page: Page, origin: string, institutionNumber: number, capability: string): Promise<{ entry: string; action: string; result: string }> {
  await freshTerminal(page, origin, institutionNumber);
  const path = menuPath(capability);
  const entryParts = [(await rows(page)).join('\n')];
  if (path.sectionCode !== undefined) {
    await menu(page, path.sectionCode);
    await waitScreen(page, 'THMENU');
    entryParts.push((await rows(page)).join('\n'));
  }
  await menu(page, path.optionCode);
  entryParts.push((await rows(page)).join('\n'));
  const actions: string[] = [];
  const operation = OPS[capability];
  if (operation !== undefined) {
    await waitScreen(page, operation.screenId);
    for (let pageIndex = 0; pageIndex < 8; pageIndex += 1) {
      actions.push(await populateCurrentScreen(page));
      const text = (await rows(page)).join('\n');
      const current = /PAGE (\d+) OF (\d+)/u.exec(text);
      if (current === null || Number(current[1]) >= Number(current[2])) break;
      await attention(page, 'PageDown');
      await waitScreen(page, operation.screenId);
      entryParts.push((await rows(page)).join('\n'));
    }
  } else {
    actions.push(await populateCurrentScreen(page));
  }
  await attention(page, 'Enter');
  await page.waitForTimeout(50);
  const result = (await rows(page)).join('\n');
  expect(result.trim().length).toBeGreaterThan(0);
  return { entry: entryParts.join('\n--- terminal path ---\n'), action: `selected ${path.sectionCode === undefined ? '' : `${path.sectionCode} then `}${path.optionCode}; ${actions.filter(Boolean).join('; ')}`, result };
}

test('qualifies canonical task options through populated host fields', async ({ page, terminal }, info) => {
  const selected = CATALOG.slice(shard() * SHARD_SIZE, (shard() + 1) * SHARD_SIZE);
  test.skip(selected.length === 0, 'empty task shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `capability-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const task of selected) {
    const observation = await exerciseCapability(page, terminal.origin, terminal.institutionNumber('northstar'), task.capability);
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${task.capability}]`, artifact,
      identity: { task: task.id, capability: task.capability, option: task.capability }, visibleEntry: observation.entry, action: observation.action, visibleResult: observation.result,
      businessEffect: 'The operator entered a visible host transaction, populated its unprotected fields, and received an operation-specific review, query result, or refusal.',
      recovery: 'The host kept the screen stack, message, and entered context available for correction, cancellation, or a fresh transaction.' }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'capabilities.json', records, { shard: shard() });
});

test('qualifies workflow catalog and recovery branches through host transactions', async ({ page, terminal }, info) => {
  const selected = Object.entries(WORKFLOW_STEPS).slice(shard() * 4, (shard() + 1) * 4);
  test.skip(selected.length === 0, 'empty workflow shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `workflow-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const [workflow, steps] of selected) {
    const results: string[] = [];
    for (const step of steps) results.push(`${step}\n${(await exerciseCapability(page, terminal.origin, terminal.institutionNumber('northstar'), step)).result}`);
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} catalog path]`, artifact,
      identity: { workflow, branch: 'catalog-path' }, visibleEntry: `Traversed ${steps.join(' → ')} with visible transaction codes and populated host fields.`, visibleResult: results.join('\n--- next visible step ---\n'),
      businessEffect: 'Every workflow step reached and exercised its terminal work surface.', recovery: 'The host stack and transaction-code entry preserve a bounded path back to every step.' }));
    const recovery = await exerciseCapability(page, terminal.origin, terminal.institutionNumber('northstar'), steps.at(-1) ?? 'activity.inspect');
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} recovery]`, artifact,
      identity: { workflow, branch: 'recovery' }, visibleEntry: `Re-entered ${steps.at(-1) ?? 'activity.inspect'} from a fresh signed-on host session.`, action: recovery.action, visibleResult: recovery.result,
      businessEffect: 'The final host transaction reopened against current institution state.', recovery: 'A fresh sign-on and transaction code recover the work without replaying a hidden write.' }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'workflows.json', records, { shard: shard() });
});

async function openProfile(page: Page, origin: string, institutionNumber: number): Promise<void> {
  await freshTerminal(page, origin, institutionNumber);
  await accountAction(page, 'AC0000002', 'M');
  await waitScreen(page, 'THAC05');
}

test('qualifies terminal-host family and shared-world boundaries', async ({ browser, page, terminal }, info) => {
  test.skip(shard() !== 0, 'recorded once');
  await page.goto(terminal.origin);
  await page.evaluate('sessionStorage.clear()');
  await page.reload();
  await openTerminal(page, terminal.origin);
  const entry = (await rows(page)).join('\n');
  const before = await terminalRoot(page).getAttribute('data-sequence');
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  const after = await terminalRoot(page).getAttribute('data-sequence');
  const familyArtifact = evidencePath(APPLICATION_ID, runId(), 'family-mechanism.json');
  writeEvidence(APPLICATION_ID, runId(), 'family-mechanism.json', [qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [family]`, artifact: familyArtifact,
    identity: { mechanism: 'terminal-host' }, visibleEntry: entry, action: 'Typed institution and operator into protected-field terminal coordinates and transmitted Enter.', visibleResult: `${(await rows(page)).join('\n')}\nsequence ${before ?? 'unknown'} -> ${after ?? 'unknown'}; screen=${await terminalRoot(page).getAttribute('data-screen-id')}`,
    businessEffect: 'The host accepted a formatted-screen input transmission and replaced the sign-on screen with the institution-bound transaction menu.', recovery: 'The screen ID, host message, cursor, and attention-key contract provide explicit resumable state.' })]);

  const peerContext = await browser.newContext({ viewport: { width: 1400, height: 1000 } });
  const readerContext = await browser.newContext({ viewport: { width: 1400, height: 1000 } });
  const isolationContext = await browser.newContext({ viewport: { width: 1400, height: 1000 } });
  const peer = await peerContext.newPage();
  const reader = await readerContext.newPage();
  const isolation = await isolationContext.newPage();
  try {
    await openProfile(page, terminal.origin, terminal.institutionNumber('northstar'));
    await openProfile(peer, terminal.origin, terminal.institutionNumber('northstar'));
    await cellAt(page, 7, 21).click(); await page.keyboard.press('Alt+KeyE'); await page.keyboard.type('Held nickname');
    const delivery = (await fieldText(peer, 9, 21, 1)) === 'P' ? 'E' : 'P';
    await typeAt(peer, 9, 21, delivery);
    await attention(peer, 'Enter'); await waitScreen(peer, 'THAC06');
    await typeAt(peer, 19, 34, 'Y'); await attention(peer, 'Enter'); await waitScreen(peer, 'THRC01');
    const peerResult = (await rows(peer)).join('\n');
    await attention(page, 'Enter'); await waitScreen(page, 'THAC05');
    const staleResult = (await rows(page)).join('\n');
    expect(staleResult).toContain('RECORD CHANGED BY ANOTHER USER');

    await freshTerminal(reader, terminal.origin, terminal.institutionNumber('northstar'));
    await accountAction(reader, 'AC0000002', 'S'); await waitScreen(reader, 'THAC02');
    const peerVisible = (await rows(reader)).join('\n');
    expect(peerVisible).toContain(delivery === 'P' ? 'PAPER' : 'ELECTRONIC');

    await freshTerminal(isolation, terminal.origin, terminal.institutionNumber('northstar'));
    await menu(isolation, 'MB01'); await waitScreen(isolation, 'THMB01');
    await typeAt(isolation, 3, 11, 'SR000001'); await attention(isolation, 'Enter');
    const isolationResult = (await rows(isolation)).join('\n');
    expect(isolationResult).toContain('NO MEMBERS MATCH');

    const sharedArtifact = evidencePath(APPLICATION_ID, runId(), 'shared-world.json');
    const common = { applicationId: APPLICATION_ID, runId: runId(), command: command(), artifact: sharedArtifact };
    writeEvidence(APPLICATION_ID, runId(), 'shared-world.json', [
      qualificationRecord({ ...common, test: `${info.title} [peer visibility]`, identity: { shared_world_check: 'peer_visibility' }, visibleEntry: peerResult, visibleResult: peerVisible, businessEffect: 'A peer terminal session committed statement-delivery data that a fresh account inquiry displayed.', recovery: 'The receipt and fresh account inquiry expose the durable peer result.' }),
      qualificationRecord({ ...common, test: `${info.title} [stale rejection]`, identity: { shared_world_check: 'stale_rejection' }, visibleEntry: 'Two terminal sessions opened AC0000002 maintenance at the same record version.', visibleResult: staleResult, businessEffect: 'The host rejected the older edit after the peer advanced the account version.', recovery: 'The terminal kept the held nickname and showed current values for an explicit rereview.' }),
      qualificationRecord({ ...common, test: `${info.title} [institution isolation]`, identity: { shared_world_check: 'institution_isolation' }, visibleEntry: 'The Northstar member-search screen was populated with SR000001.', visibleResult: isolationResult, businessEffect: 'The Northstar host session returned no foreign-institution member.', recovery: 'The signed-on institution remained visible and no cross-institution fallback occurred.' }),
    ]);
  } finally {
    await peerContext.close(); await readerContext.close(); await isolationContext.close();
  }
});
