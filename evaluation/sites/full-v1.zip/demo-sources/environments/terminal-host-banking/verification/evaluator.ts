import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

import type { DatasetBinding } from '@computer-use/financial-database';
import type { VerificationRun } from '@computer-use/financial-database/verification';

/** The evaluator owns grading definitions; this module only types the parts browser verification calls. */
const VERIFIER_DIRECTORY = resolve(import.meta.dirname, '..', '..', '..', 'evaluation', 'verifier');

export interface VerifierCheck { id: string; status: string; requirementId?: string; message?: string; actual?: unknown; expected?: unknown }

export interface VerifierReport {
  runId: string;
  databaseVerdict: string;
  overallTaskVerdict: string;
  checks: VerifierCheck[];
  externalRequirements: unknown[];
  capturedBindings?: Record<string, unknown>;
}

export interface TaskRunSession extends Pick<VerificationRun, 'read' | 'write'> {
  descriptor: () => { runId: string; databasePath: string; evidencePath: string };
  verify: (submission: unknown, options: { reportPath: string; dispose: boolean }) => Promise<VerifierReport>;
  dispose: (options: { reportPath: string }) => void;
  close: () => void;
}

export interface WithdrawalCase {
  accountId: string;
  accountNumber: string;
  memberNumber: string;
  amountMinorUnits: number;
  currency: string;
  description: string;
  actorId: string;
  balanceBefore: number;
}

interface Verifier {
  startTaskRun: (options: { root: string; sourcePath: string; contract: unknown }) => Promise<TaskRunSession>;
}

interface WithdrawalQualification {
  terminalWithdrawalCase: WithdrawalCase;
  terminalWithdrawalContract: (binding: DatasetBinding) => unknown;
}

export async function loadVerifier(): Promise<Verifier & WithdrawalQualification> {
  const verifier = await import(pathToFileURL(join(VERIFIER_DIRECTORY, 'index.mjs')).href) as Verifier;
  const withdrawal = await import(pathToFileURL(join(VERIFIER_DIRECTORY, 'app-qualification', 'terminal-host-banking-withdrawal.mjs')).href) as WithdrawalQualification;
  return { startTaskRun: verifier.startTaskRun, terminalWithdrawalCase: withdrawal.terminalWithdrawalCase, terminalWithdrawalContract: withdrawal.terminalWithdrawalContract };
}
