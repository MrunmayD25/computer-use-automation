import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

import type { Page } from '@playwright/test';

import {
  accountAction, attention, cellAt, expect, fieldText, listIndex, menu, oia, openTerminal, rows, shot, signOn, terminalRoot, test, transmit, typeAt, waitScreen,
  type LaunchedTerminal,
} from './fixtures.js';

interface Balance { account_number: string; posted_balance_minor_units: number; available_balance_minor_units: number }

function balances(terminal: LaunchedTerminal, institutionId: string, ...accountNumbers: string[]): Record<string, number> {
  const found = terminal.query<Balance>(`SELECT a.account_number, b.posted_balance_minor_units, b.available_balance_minor_units FROM accounts a
    JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? AND a.account_number IN (${accountNumbers.map(() => '?').join(',')})`,
  terminal.datasetId(institutionId), ...accountNumbers);
  return Object.fromEntries(found.map((row) => [row.account_number, row.posted_balance_minor_units]));
}

function operationCount(terminal: LaunchedTerminal): number {
  return terminal.query<{ count: number }>('SELECT COUNT(*) AS count FROM operations')[0]?.count ?? 0;
}

async function paste(page: Page, text: string): Promise<void> {
  // The expression runs in the page; the Node typings used for specs have no DOM declarations.
  await page.evaluate(`navigator.clipboard.writeText(${JSON.stringify(text)})`);
  await page.keyboard.press('ControlOrMeta+KeyV');
}

const pageIndicator = async (page: Page): Promise<string> => ((await rows(page))[1] ?? '').slice(62).trim();
const messageLine = async (page: Page): Promise<string> => fieldText(page, 21, 0, 80);

test('fields are edited only within their definitions and a paste stays inside one field', async ({ page, terminal, evidence, pageErrors }, info) => {
  await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  const root = terminalRoot(page);
  const menuSequence = await root.getAttribute('data-sequence') ?? '';

  await cellAt(page, 3, 2).click();
  await page.keyboard.type('x');
  await expect(root).toHaveAttribute('data-lock', 'protected');
  await expect(oia(page)).toContainText('X PROT');
  await page.keyboard.press('Enter');
  await expect(oia(page)).toContainText('X PROT');
  await expect(root).toHaveAttribute('data-sequence', menuSequence);
  await page.keyboard.press('Escape');
  await expect(root).toHaveAttribute('data-lock', 'none');
  evidence.browser('protected area locks the keyboard until Reset; Enter is not sent', { sequence: menuSequence });

  await accountAction(page, 'AC0000001', 'W');
  await waitScreen(page, 'THTX02');
  await expect(oia(page)).toContainText('09/022');
  await page.keyboard.type('a');
  await expect(root).toHaveAttribute('data-lock', 'numeric');
  await page.keyboard.press('Alt+KeyR');
  await expect(root).toHaveAttribute('data-lock', 'none');
  await page.keyboard.type('1234567890123456');
  expect(await fieldText(page, 8, 21, 16)).toBe('1234567890123456');
  await expect(oia(page)).toContainText('09/051');
  await cellAt(page, 8, 21).click();
  await page.keyboard.press('Insert');
  await expect(root).toHaveClass(/insert/u);
  await page.keyboard.type('9');
  await expect(root).toHaveAttribute('data-lock', 'overflow');
  await page.keyboard.press('Escape');
  await expect(root).not.toHaveClass(/insert/u);
  await page.keyboard.press('Alt+KeyE');
  expect(await fieldText(page, 8, 21, 16)).toBe('');
  await page.keyboard.type('12.50');
  evidence.browser('numeric, length and insert overflow limits', { amount: await fieldText(page, 8, 21, 16), oia: await oia(page).textContent() });

  const sequence = await root.getAttribute('data-sequence') ?? '';
  await cellAt(page, 9, 21).click();
  await paste(page, 'Line one\nLine two');
  await expect(oia(page)).toContainText('PASTE REJECTED');
  expect(await fieldText(page, 9, 21, 56)).toBe('');
  await paste(page, 'Counter withdrawal');
  expect(await fieldText(page, 9, 21, 56)).toBe('Counter withdrawal');
  await cellAt(page, 8, 50).click();
  await paste(page, 'USDX');
  await expect(oia(page)).toContainText('EXCEED THIS FIELD\'S 3-CHARACTER LIMIT');
  expect(await fieldText(page, 8, 50, 3)).toBe('USD');
  await expect(root).toHaveAttribute('data-sequence', sequence);
  evidence.browser('paste stays in one field and never transmits', { description: await fieldText(page, 9, 21, 56), currency: await fieldText(page, 8, 50, 3), sequence });
  await shot(page, info, 'editing-1-drafted');

  await attention(page, 'F3');
  expect(await messageLine(page)).toContain('CHANGES NOT APPLIED. PRESS F3 AGAIN TO DISCARD THEM');
  expect(await fieldText(page, 8, 21, 16)).toBe('12.50');
  await attention(page, 'F3');
  await waitScreen(page, 'THAC01');
  expect(await messageLine(page)).toContain('CHANGES DISCARDED. NOTHING WAS UPDATED.');
  expect(pageErrors).toEqual([]);
});

test('function keys, their browser-safe alternatives and the keypad reach the same host functions', async ({ page, terminal, evidence, pageErrors }, info) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await accountAction(page, 'AC0000001', 'S');
  await waitScreen(page, 'THAC02');
  expect(await pageIndicator(page)).toBe('PAGE 1 OF 2');
  await attention(page, 'F8');
  expect(await pageIndicator(page)).toBe('PAGE 2 OF 2');
  await attention(page, 'Alt+Digit7');
  expect(await pageIndicator(page)).toBe('PAGE 1 OF 2');
  await attention(page, 'PageDown');
  expect(await pageIndicator(page)).toBe('PAGE 2 OF 2');
  await transmit(page, () => page.getByRole('button', { name: /^PF7 / }).click());
  expect(await pageIndicator(page)).toBe('PAGE 1 OF 2');
  await expect(terminalRoot(page)).toHaveClass(/has-focus/u);

  await attention(page, 'F1');
  await waitScreen(page, 'THHELP');
  expect((await rows(page)).join('\n')).toContain('ACCOUNT INQUIRY');
  await shot(page, info, 'keys-1-help');
  await attention(page, 'Alt+Equal');
  await waitScreen(page, 'THAC02');
  await attention(page, 'Shift+F1');
  await waitScreen(page, 'THTX03');
  expect(await fieldText(page, 3, 21, 10)).toBe('AC0000001');
  await attention(page, 'F12');
  await waitScreen(page, 'THAC02');
  await attention(page, 'Alt+Shift+Digit1');
  await waitScreen(page, 'THTX03');
  await attention(page, 'Alt+Equal');
  await waitScreen(page, 'THAC02');
  await attention(page, 'Alt+Minus');
  await waitScreen(page, 'THTX02');
  await attention(page, 'F12');
  await waitScreen(page, 'THAC02');
  await attention(page, 'Alt+Digit3');
  await waitScreen(page, 'THAC01');
  evidence.browser('F8, Alt+7, PageDown, keypad PF7, F1, Alt+=, Shift+F1 (PF13), F12, Alt+Shift+1 (PF13), Alt+- (PF11) and Alt+3 each reached their host function', { screen: 'THAC01' });
  expect(pageErrors).toEqual([]);
});

test('screens reuse coordinates for different records without keeping stale context', async ({ page, terminal, evidence }, info) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await accountAction(page, 'AC0000001', 'S');
  await waitScreen(page, 'THAC02');
  await cellAt(page, 3, 19).click();
  await page.keyboard.press('Alt+KeyE');
  await page.keyboard.type('AC0000004');
  await attention(page, 'Enter');
  await waitScreen(page, 'THAC02');
  expect(await fieldText(page, 3, 19, 10)).toBe('AC0000004');
  expect(await messageLine(page)).toContain('NOW SHOWING ACCOUNT AC0000004.');
  expect(await fieldText(page, 10, 19, 30)).toBe('7,026.62 USD');
  expect(await fieldText(page, 11, 19, 30)).toBe('6,751.62 USD');
  await attention(page, 'F10');
  await waitScreen(page, 'THTX01');
  expect(await fieldText(page, 3, 21, 10)).toBe('AC0000004');
  await attention(page, 'F3');
  await waitScreen(page, 'THAC02');
  expect(await fieldText(page, 3, 19, 10)).toBe('AC0000004');

  await attention(page, 'F3');
  await attention(page, 'F3');
  await waitScreen(page, 'THMENU');
  await menu(page, '1');
  await typeAt(page, 3, 11, 'Alex Morgan');
  await attention(page, 'Enter');
  const listed = (await rows(page)).slice(7, 9).map((line) => line.slice(3, 42).trim());
  expect(listed).toEqual(['NM000001 Alex Morgan', 'NM000002 Alex Morgan']);
  await shot(page, info, 'coordinates-1-same-names');
  for (const [index, number] of [[1, 'NM000002'], [0, 'NM000001']] as const) {
    await typeAt(page, 7 + index, 1, 's');
    await attention(page, 'Enter');
    await waitScreen(page, 'THMB02');
    expect(await fieldText(page, 3, 19, 8)).toBe(number);
    await attention(page, 'F3');
    await waitScreen(page, 'THMB01');
  }
  evidence.browser('record switching and same-name rows resolved by row identity', { listed });
});

test('paging, search restoration, validation and draft preservation', async ({ page, terminal, evidence }) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await menu(page, '1');
  await typeAt(page, 3, 11, 'a');
  await attention(page, 'Enter');
  expect(await pageIndicator(page)).toMatch(/^PAGE 1 OF [2-9]/u);
  await attention(page, 'F8');
  expect(await pageIndicator(page)).toMatch(/^PAGE 2 OF /u);
  const memberNumber = ((await rows(page))[7] ?? '').slice(3, 11);
  await typeAt(page, 7, 1, 's');
  await attention(page, 'Enter');
  await waitScreen(page, 'THMB02');
  expect(await fieldText(page, 3, 19, 8)).toBe(memberNumber);
  await attention(page, 'F3');
  await waitScreen(page, 'THMB01');
  expect(await pageIndicator(page)).toMatch(/^PAGE 2 OF /u);
  expect(await fieldText(page, 3, 11, 30)).toBe('a');
  expect(await fieldText(page, 7, 1, 1)).toBe('');
  evidence.browser('search criteria and page restored after inquiry', { memberNumber, page: await pageIndicator(page) });

  await attention(page, 'F3');
  await accountAction(page, 'AC0000001', 'W');
  await waitScreen(page, 'THTX02');
  const operations = operationCount(terminal);
  await typeAt(page, 8, 21, '1.234');
  await typeAt(page, 9, 21, 'Too precise');
  await attention(page, 'Enter');
  await waitScreen(page, 'THTX02');
  expect(await messageLine(page)).toContain('THIS CURRENCY ALLOWS AT MOST 2 DECIMAL PLACES.');
  await expect(oia(page)).toContainText('09/022');
  expect(await fieldText(page, 8, 21, 16)).toBe('1.234');
  expect(await fieldText(page, 9, 21, 56)).toBe('Too precise');
  expect(operationCount(terminal)).toBe(operations);
  evidence.browser('validation kept entries and placed the cursor on the amount', { message: await messageLine(page) });
  evidence.database('no operation recorded for the invalid amount', { operations });
});

test('a repeated confirm while the host responds posts once, with receipt, audit trail and rejection handling', async ({ page, terminal, evidence }, info) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0003');
  const before = balances(terminal, 'northstar', 'AC0000001', 'AC0000002');
  await menu(page, '6');
  await waitScreen(page, 'THTX03');
  await typeAt(page, 3, 21, 'AC0000001');
  await typeAt(page, 7, 21, 'AC0000002');
  await typeAt(page, 11, 21, '15.00');
  await typeAt(page, 12, 21, 'Move to household');
  await attention(page, 'Enter');
  await waitScreen(page, 'THTX04');
  const requestKey = await fieldText(page, 18, 20, 40);
  await shot(page, info, 'money-1-review');
  await typeAt(page, 19, 34, 'Y');
  await page.keyboard.press('Enter');
  await page.keyboard.press('Enter');
  await waitScreen(page, 'THRC01');
  const receiptNumber = await fieldText(page, 3, 17, 12);
  expect(receiptNumber).toMatch(/^RCP\d{8}$/u);
  await shot(page, info, 'money-2-receipt');
  evidence.browser('receipt after a double Enter', { requestKey, receiptNumber, operation: await fieldText(page, 4, 17, 30) });

  const operations = terminal.query<{ operation_kind: string; status: string; actor_id: string }>('SELECT operation_kind, status, actor_id FROM operations WHERE idempotency_key=?', requestKey);
  expect(operations).toEqual([{ operation_kind: 'transfer.internal', status: 'committed', actor_id: 'northstar-actor-3' }]);
  const after = balances(terminal, 'northstar', 'AC0000001', 'AC0000002');
  expect([(before.AC0000001 ?? 0) - (after.AC0000001 ?? 0), (after.AC0000002 ?? 0) - (before.AC0000002 ?? 0)]).toEqual([1500, 1500]);
  const events = terminal.query<{ kind: string; resource_kind: string }>(`SELECT e.kind, e.resource_kind FROM business_events e JOIN operation_receipts r ON r.dataset_id=e.dataset_id AND r.operation_id=e.operation_id
    WHERE r.receipt_number=? AND e.dataset_id=? ORDER BY e.sequence`, receiptNumber, terminal.datasetId('northstar'));
  expect(events.length).toBeGreaterThan(0);
  expect(new Set(events.map((event) => event.kind))).toEqual(new Set(['transfer.internal']));
  evidence.database('one committed transfer for the request key, balances moved once, events recorded', { operations, before, after, events });

  await attention(page, 'F3');
  await waitScreen(page, 'THMENU');
  await menu(page, '7');
  await waitScreen(page, 'THAV01');
  await typeAt(page, 4, 59, receiptNumber);
  await attention(page, 'Enter');
  const activity = (await rows(page)).slice(7, 19).filter((line) => line.includes(receiptNumber));
  expect(activity.length).toBe(events.length);
  expect(activity.every((line) => line.includes('transfer.internal') && line.includes('OP0003'))).toBe(true);
  await shot(page, info, 'money-3-activity');
  evidence.browser('activity inquiry lists the committed events', { activity });

  await attention(page, 'F3');
  await menu(page, '6');
  const count = operationCount(terminal);
  await typeAt(page, 3, 21, 'AC0000001');
  await typeAt(page, 7, 21, 'AC0000003');
  await typeAt(page, 11, 21, '5.00');
  await typeAt(page, 12, 21, 'Different owner');
  await attention(page, 'Enter');
  await waitScreen(page, 'THTX03');
  expect(await messageLine(page)).toContain('INTERNAL TRANSFERS MOVE FUNDS ONLY BETWEEN ACCOUNTS OWNED BY THE SAME MEMBER.');
  await expect(oia(page)).toContainText('08/022');
  expect(await fieldText(page, 11, 21, 16)).toBe('5.00');
  expect(operationCount(terminal)).toBe(count);
  evidence.database('rejected transfer recorded nothing', { operations: count });
});

test('a version conflict shows current values and keeps the unsent draft', async ({ page, terminal, evidence }, info) => {
  const other = await page.context().newPage();
  const original = terminal.query<{ nickname: string; statement_delivery: string; version: number }>(
    "SELECT nickname, statement_delivery, version FROM accounts WHERE dataset_id=? AND account_number='AC0000002'", terminal.datasetId('northstar'))[0];
  if (original === undefined) throw new Error('AC0000002 is missing.');
  for (const session of [page, other]) {
    await openTerminal(session, terminal.origin);
    await signOn(session, terminal.institutionNumber('northstar'), 'OP0002');
    await accountAction(session, 'AC0000002', 'M');
    await waitScreen(session, 'THAC05');
  }
  await cellAt(page, 7, 21).click();
  await page.keyboard.press('Alt+KeyE');
  await page.keyboard.type('Rainy day');

  const delivery = original.statement_delivery === 'paper' ? 'E' : 'P';
  await typeAt(other, 9, 21, delivery);
  await attention(other, 'Enter');
  await waitScreen(other, 'THAC06');
  await typeAt(other, 19, 34, 'Y');
  await attention(other, 'Enter');
  await waitScreen(other, 'THRC01');

  await attention(page, 'Enter');
  await waitScreen(page, 'THAC05');
  expect(await messageLine(page)).toContain('RECORD CHANGED BY ANOTHER USER. CURRENT VALUES SHOWN; YOUR ENTRIES ARE KEPT.');
  expect(await fieldText(page, 7, 21, 40)).toBe('Rainy day');
  expect(await fieldText(page, 8, 21, 58)).toBe(`NOW: ${original.nickname}`);
  expect(await fieldText(page, 9, 21, 1)).toBe(delivery);
  await shot(page, info, 'conflict-1-current-values');
  await attention(page, 'Enter');
  await waitScreen(page, 'THAC06');
  await typeAt(page, 19, 34, 'Y');
  await attention(page, 'Enter');
  await waitScreen(page, 'THRC01');
  const after = terminal.query<{ nickname: string; statement_delivery: string; version: number }>(
    "SELECT nickname, statement_delivery, version FROM accounts WHERE dataset_id=? AND account_number='AC0000002'", terminal.datasetId('northstar'))[0];
  expect(after).toEqual({ nickname: 'Rainy day', statement_delivery: delivery === 'P' ? 'paper' : 'electronic', version: original.version + 2 });
  evidence.browser('conflict screen', { draft: 'Rainy day', now: original.nickname, delivery });
  evidence.database('both changes kept, version advanced twice', { original, after });
  await other.close();
});

test('duplicate business numbers resolve only within the signed-on institution', async ({ page, terminal, evidence }) => {
  const northstar = balances(terminal, 'northstar', 'AC0000001');
  const riverton = balances(terminal, 'riverton', 'AC0000001');
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('riverton'), 'OP0002');
  expect((await rows(page))[1]).toContain('RIVERTON');
  await accountAction(page, 'AC0000001', 'D');
  await waitScreen(page, 'THTX01');
  await page.keyboard.type('1.00');
  await typeAt(page, 9, 21, 'Riverton deposit');
  await attention(page, 'Enter');
  await typeAt(page, 19, 34, 'Y');
  await attention(page, 'Enter');
  await waitScreen(page, 'THRC01');
  expect(balances(terminal, 'riverton', 'AC0000001').AC0000001).toBe((riverton.AC0000001 ?? 0) + 100);
  expect(balances(terminal, 'northstar', 'AC0000001')).toEqual(northstar);
  evidence.database('only the Riverton AC0000001 changed', { northstar, riverton, rivertonAfter: balances(terminal, 'riverton', 'AC0000001') });
});

test('statements and exports download real files with their digests', async ({ page, terminal, evidence }, info) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await accountAction(page, 'AC0000001', 'T');
  await waitScreen(page, 'THST01');
  await typeAt(page, 7 + await listIndex(page, 'STORED'), 1, 'D');
  await attention(page, 'Enter');
  await expect(page.locator('.transfer')).toBeVisible();
  const offered = /SHA-256 ([0-9a-f]{64})/u.exec(await page.locator('.transfer').textContent() ?? '')?.[1];
  const pending = page.waitForEvent('download');
  await page.keyboard.press('Alt+KeyD');
  const download = await pending;
  const storedPath = info.outputPath(download.suggestedFilename());
  await download.saveAs(storedPath);
  const stored = readFileSync(storedPath);
  const digest = createHash('sha256').update(stored).digest('hex');
  expect(digest).toBe(offered);
  const recorded = terminal.query<{ digest: string; media_type: string }>(`SELECT v.digest, v.media_type FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
    JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id WHERE a.dataset_id=? AND a.account_number='AC0000001' AND v.digest=?`, terminal.datasetId('northstar'), digest);
  expect(recorded.length).toBeGreaterThan(0);
  if (recorded[0]?.media_type === 'application/pdf') expect(stored.subarray(0, 5).toString('latin1')).toBe('%PDF-');
  await shot(page, info, 'documents-1-offered');
  evidence.browser('stored document downloaded with Alt+D', { fileName: download.suggestedFilename(), bytes: stored.byteLength, digest });
  evidence.database('downloaded bytes match a recorded document version digest', { recorded });

  await attention(page, 'F5');
  await waitScreen(page, 'THEX01');
  await typeAt(page, 5, 21, '2026-08-01');
  await typeAt(page, 6, 21, '2026-09-01');
  await attention(page, 'Enter');
  const exported = page.waitForEvent('download');
  await page.getByRole('link', { name: /^Download / }).click();
  const csvDownload = await exported;
  expect(csvDownload.suggestedFilename()).toBe('northstar-AC0000001-transactions-2026-08-01_2026-09-01.csv');
  const csvPath = info.outputPath(csvDownload.suggestedFilename());
  await csvDownload.saveAs(csvPath);
  const lines = readFileSync(csvPath, 'utf8').trimEnd().split(/\r?\n/u);
  expect(lines[0]).toBe('member_number,account_number,currency,effective_date,reference,description,status,signed_minor_units,running_balance_minor_units,counterparty,receipt_number');
  const expected = terminal.query<{ count: number }>(`SELECT COUNT(*) AS count FROM journal_lines jl JOIN journals j ON j.dataset_id=jl.dataset_id AND j.id=jl.journal_id
    JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id JOIN accounts a ON a.dataset_id=la.dataset_id AND a.id=la.customer_account_id
    WHERE a.dataset_id=? AND a.account_number='AC0000001' AND j.effective_date>='2026-08-01' AND j.effective_date<'2026-09-01'`, terminal.datasetId('northstar'))[0]?.count;
  expect(lines.length - 1).toBe(expected);
  expect(lines.slice(1).every((line) => line.startsWith('NM000002,AC0000001,USD,2026-08-'))).toBe(true);
  evidence.browser('CSV export downloaded from the transfer link', { fileName: csvDownload.suggestedFilename(), rows: lines.length - 1 });
  evidence.database('CSV row count equals ledger lines in range', { expected });
});

test('Unicode names and wide characters are shown in cells and stored exactly', async ({ page, terminal, evidence }, info) => {
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');
  await menu(page, '1');
  await typeAt(page, 3, 11, 'Zoë');
  await attention(page, 'Enter');
  expect((await rows(page))[7]).toContain("NM000008 Zoë O'Connor");
  await attention(page, 'F3');

  const nickname = 'Café 日本 ✓';
  await accountAction(page, 'AC0000005', 'M');
  await waitScreen(page, 'THAC05');
  await cellAt(page, 7, 21).click();
  await page.keyboard.press('Alt+KeyE');
  await page.keyboard.type(nickname);
  await expect(oia(page)).toContainText('08/033');
  await shot(page, info, 'unicode-1-wide-cells');
  await attention(page, 'Enter');
  await waitScreen(page, 'THAC06');
  expect((await rows(page)).join('\n')).toContain(nickname);
  await typeAt(page, 19, 34, 'Y');
  await attention(page, 'Enter');
  await waitScreen(page, 'THRC01');
  const stored = terminal.query<{ nickname: string }>("SELECT nickname FROM accounts WHERE dataset_id=? AND account_number='AC0000005'", terminal.datasetId('northstar'))[0]?.nickname;
  expect(stored).toBe(nickname);
  evidence.browser('wide characters advanced the cursor by two cells each', { nickname, cursorAfterTyping: '08/033' });
  evidence.database('nickname stored exactly', { stored });
});

test('the screen fits small windows, keeps a visible cursor and shows when input is paused', async ({ page, terminal, evidence }, info) => {
  await page.setViewportSize({ width: 820, height: 640 });
  await openTerminal(page, terminal.origin);
  const small = await page.locator('.screen').boundingBox();
  expect(small).not.toBe(null);
  expect((small?.x ?? 0) + (small?.width ?? 0)).toBeLessThanOrEqual(820);
  await expect(page.locator('.screen .cur')).toBeVisible();
  await shot(page, info, 'layout-1-small');

  await page.locator('.hints').click();
  await expect(terminalRoot(page)).not.toHaveClass(/has-focus/u);
  await expect(page.getByRole('button', { name: /INPUT PAUSED/u })).toBeVisible();
  await page.keyboard.type('7');
  expect(await fieldText(page, 13, 28, 2)).toBe('');
  await shot(page, info, 'layout-2-paused');
  await page.getByRole('button', { name: /INPUT PAUSED/u }).click();
  await expect(terminalRoot(page)).toHaveClass(/has-focus/u);

  await page.setViewportSize({ width: 1600, height: 1000 });
  const large = await page.locator('.screen').boundingBox();
  expect(large?.width ?? 0).toBeGreaterThan(small?.width ?? 0);
  evidence.browser('screen width follows the window', { small: small?.width, large: large?.width });
});
