import { execFileSync } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';

import { test, expect, openTerminal, signOn, typeAt, attention, waitScreen, rows } from './fixtures.js';
import { OPS } from '../src/server/screens/ops-registry.js';

interface MenuOp {
  section: string;
  sectionCode: string;
  optionCode: string;
  operation: string;
}

// The menu is intentionally data driven here so qualification follows the operator's
// visible path rather than calling the host or shared service directly.
const MENU_OPS: readonly MenuOp[] = [
  ...[
    ['ID01', 'member.identity_evidence.register'], ['ID02', 'member.identity.verify'], ['ID03', 'member.identity.resolve'],
    ['NM01', 'member.legal_name.update'], ['NM02', 'member.preferred_name.update'], ['DC01', 'document.index'],
    ['DC03', 'document.bundle.redact'], ['DC04', 'document.signature.collect'], ['CN01', 'consent.delivery.record'],
    ['CN02', 'consent.withdraw'], ['EX01', 'document.customer_export.create'], ['RH01', 'document.retention_hold.apply'],
    ['IR01', 'case.information.request'], ['ES01', 'case.escalate'], ['AN01', 'document.annotation.update'],
    ['MD01', 'document.metadata.update'], ['CP01', 'communication.preference.update'], ['CM01', 'communication.send'],
    ['CM02', 'communication.delivery.update'], ['AR01', 'maintenance.address.reconcile'], ['AR02', 'maintenance.address.destination.update'],
  ].map(([optionCode, operation]) => ({ section: 'service', sectionCode: 'SV00', optionCode: optionCode ?? '', operation: operation ?? '' })) as MenuOp[],
  ...[
    ['MG01', 'member.merge'], ['MP01', 'member.merge.plan.inspect'], ['DC10', 'member.deceased.record'],
    ['BO01', 'member.beneficial_owners.update'], ['TX10', 'member.tax_classification.update'], ['PC01', 'account.product.convert'],
    ['OA01', 'account.owner.add'], ['SR01', 'account.signer.remove'], ['OD01', 'account.overdraft_limit.update'],
    ['HL01', 'account.hold.place'], ['HL02', 'account.hold.release'], ['RS01', 'account.restriction.apply'],
    ['RS02', 'account.restriction.release'], ['FE01', 'fee.assess'], ['FE02', 'fee.waiver.create'],
    ['FE03', 'fee.refund'], ['RV10', 'cash.deposit.reverse'], ['RV11', 'cash.withdrawal.reverse'],
    ['RV12', 'transfer.internal.reverse'], ['IN01', 'interest.adjust'], ['ED01', 'transaction.effective_date.correct'],
    ['DS01', 'transaction.description.update'], ['MI01', 'account.maturity.instruct'],
  ].map(([optionCode, operation]) => ({ section: 'finance', sectionCode: 'FN00', optionCode: optionCode ?? '', operation: operation ?? '' })) as MenuOp[],
  ...[
    ['BN01', 'beneficiary.create'], ['BN02', 'beneficiary.verify'], ['BN03', 'beneficiary.routing.update'],
    ['BN04', 'beneficiary.retire'], ['PM01', 'payment.create'], ['PM02', 'payment.submit'],
    ['PM03', 'payment.approve_release'], ['PM04', 'payment.settle'], ['PM05', 'payment.cancel'],
    ['SC01', 'payment.schedule.create'], ['SC02', 'payment.schedule.materialize'], ['SC03', 'payment.occurrence.amend'],
    ['SC04', 'payment.schedule.end'], ['RT01', 'payment.return.resolve'], ['CD01', 'card.replace'],
    ['CD02', 'card.lock.update'], ['CD03', 'card.limit.update'], ['DP01', 'dispute.open'],
    ['DP02', 'dispute.provisional_credit.issue'], ['DP03', 'dispute.evidence.submit'], ['DP04', 'dispute.settle'],
    ['LN01', 'loan.application.prepare'], ['LN02', 'loan.payment.allocate'], ['LN03', 'loan.payoff.quote'],
    ['LN04', 'loan.close'], ['LN05', 'document.loan_closure.issue'], ['SU01', 'reconciliation.suspense.investigate'],
    ['SU02', 'reconciliation.suspense.clear'], ['BI01', 'batch.import'],
  ].map(([optionCode, operation]) => ({ section: 'payments', sectionCode: 'PY00', optionCode: optionCode ?? '', operation: operation ?? '' })) as MenuOp[],
  ...[
    ['RT10', 'reconciliation.transfer'], ['RT11', 'reconciliation.settlement_batch'], ['RT12', 'reconciliation.cash_day'],
    ['RT13', 'batch.preview'], ['IN01', 'institution.context.verify'],
  ].map(([optionCode, operation]) => ({ section: 'recon', sectionCode: 'RC00', optionCode: optionCode ?? '', operation: operation ?? '' })) as MenuOp[],
];

const SHARD_SIZE = 10;

test('qualifies every registered operation through its visible terminal entry', async ({ page, terminal }, testInfo) => {
  const shard = Number(process.env.TERMINAL_QUAL_SHARD ?? '0');
  const selected = MENU_OPS.slice(shard * SHARD_SIZE, (shard + 1) * SHARD_SIZE);
  test.skip(selected.length === 0, `qualification shard ${shard} has no operations`);
  const runId = process.env.TERMINAL_QUAL_RUN ?? `qual-${new Date().toISOString().replaceAll(':', '-')}-${process.pid}`;
  const sourceSha = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: resolve(import.meta.dirname, '..', '..'), encoding: 'utf8' }).trim();
  const command = `npm run build && TERMINAL_QUAL_RUN=${runId} TERMINAL_QUAL_SHARD=${shard} npx playwright test -c verification/playwright.config.ts verification/qualification.spec.ts`;
  await openTerminal(page, terminal.origin);
  await signOn(page, terminal.institutionNumber('northstar'), 'OP0002');

  const records: unknown[] = [];
  for (const item of selected) {
    const spec = OPS[item.operation];
    if (spec === undefined) throw new Error(`registered operation ${item.operation} is missing`);
    await typeAt(page, 19, 15, item.sectionCode);
    await attention(page, 'Enter');
    await waitScreen(page, 'THMENU');
    const index = MENU_OPS.filter((candidate) => candidate.section === item.section).findIndex((candidate) => candidate.optionCode === item.optionCode);
    for (let pageIndex = 0; pageIndex < Math.floor(index / 12); pageIndex += 1) await attention(page, 'PageDown');
    await typeAt(page, 19, 15, item.optionCode);
    await attention(page, 'Enter');
    await waitScreen(page, spec.screenId);
    const entryRows = await rows(page);
    await page.keyboard.press('Enter');
    await page.waitForTimeout(100);
    const resultRows = await rows(page);
    const visibleResult = resultRows.join('\n');
    expect(visibleResult.length).toBeGreaterThan(0);
    records.push({
      sourceSha, runId, utc: new Date().toISOString(), command, test: testInfo.title,
      capability: item.operation, option: item.optionCode, visibleEntry: entryRows.join('\n'),
      action: 'Enter with empty fields', visibleResult,
      outcome: visibleResult.includes('ENTER ') || visibleResult.includes('NOT FOUND') || visibleResult.includes('NO ') ? 'refusal-or-empty-result' : 'query-or-review-result',
      artifactPath: testInfo.outputPath('qualification.json'),
      recovery: 'No business write was attempted; the blank-input refusal/query result is safe to retry.',
    });
    await attention(page, 'F3');
    // Query operations push a result frame whose screen ID may match the form;
    // pop it before returning to the section menu.
    if (await page.locator('#terminal').getAttribute('data-screen-id') === spec.screenId) await attention(page, 'F3');
    await waitScreen(page, 'THMENU');
    await attention(page, 'F3');
    await waitScreen(page, 'THMENU');
  }
  const artifact = testInfo.outputPath('qualification.json');
  writeFileSync(artifact, `${JSON.stringify({ sourceSha, runId, shard, totalShards: Math.ceil(MENU_OPS.length / SHARD_SIZE), records }, null, 2)}\n`);
  const durable = join(resolve(import.meta.dirname, 'evidence'), runId);
  mkdirSync(durable, { recursive: true });
  writeFileSync(join(durable, `shard-${String(shard).padStart(2, '0')}.json`), `${JSON.stringify({ sourceSha, runId, shard, records }, null, 2)}\n`);
});
