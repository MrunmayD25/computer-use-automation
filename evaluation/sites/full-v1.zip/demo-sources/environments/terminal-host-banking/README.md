# Terminal Host Banking

A browser terminal for branch banking, modelled on IBM 3270 and 5250 host screens. Operators work on fixed 80 × 24 character screens with protected and editable fields, a cursor, function keys, an operator information area and a message line. Every screen reads and writes the shared financial database through `@computer-use/financial-database`. The terminal holds no business data of its own.

See [SPEC.md](SPEC.md) for the product definition, IMPLEMENTATION.md (historical material omitted from this bundle) for what is built and verified, and capability-manifest.json (historical material omitted from this bundle) for per-capability readiness.

## Requirements

- Node.js 25.9 or later.
- A seeded financial database. The canonical file is `environments/database/financial/.runtime/financial.sqlite`. Seed it once if it is missing:

  ```sh
  npm --prefix environments/database/financial run seed
  ```

The terminal never seeds, reseeds or migrates the database. It refuses to start when the named world is missing.

## Start

From `environments/`:

```sh
npm install
npm run start:terminal-host-banking
```

Then open <http://127.0.0.1:4340>. The workspace script builds the shared package and the terminal, then starts the server. From `environments/terminal-host-banking/`, `npm start` does the same for this app alone.

## Options

`node dist/server/main.js [options]` after `npm run build`:

| Option | Default | Meaning |
| --- | --- | --- |
| `--port <n>` | `TERMINAL_HOST_PORT`, then `4340` | Listener port. `0` picks a free port and prints it. |
| `--host <address>` | `127.0.0.1` | Listener address. |
| `--database <path>` | `FINANCIAL_DATABASE_PATH`, then the canonical file | Seeded financial SQLite file. |
| `--world <name>` | `financial-demo-v1` | Named world whose institutions the terminal binds. |
| `--operators <list>` | `OP0002,OP0003` | Operator actor numbers allowed to sign on. |
| `--verbose` | off | Logs each request with its status and latency. |

The desktop MDI console defaults to port 4330, so both can run together. Pointing both at one database file shares one mutable world; a change made in one is visible in the other.

## Database selection

- **Shared demo.** Run with the defaults. Changes persist in the canonical file and every app that opens it sees them.
- **Disposable copy.** Copy the canonical file (with no open writers) and pass `--database /path/to/copy.sqlite`. Nothing reaches the canonical file.
- **Evaluator run.** The evaluator owns an isolated run and embeds the terminal with that run's store. See [Evaluator mode](#evaluator-mode).

Each institution in the world is its own dataset. The sign-on screen lists them by number; account and member numbers resolve only within the signed-on institution, even where numbers repeat across institutions.

## Signing on

Type an institution number and an operator ID, then press Enter. With one institution or operator the field is filled for you. The seeded operators have different grants. `OP0002` (teller) posts cash deposits and withdrawals. `OP0003` (branch operations) posts internal transfers. `OP0002` also works cases and writes restricted notes; `OP0005` (supervisor) routes cases out of restricted queues. The main menu marks functions the operator cannot perform as `NOT GRANTED`; their screens can still be viewed, and the host refuses the change with the permission it lacks.

## Operations

The menu pages (F7/F8) across six sections: core member and account work, servicing (identity, names, documents, consent, cases, communications), money (fees, payments, beneficiaries, schedules, cards, disputes, loans), reconciliation and directories, approvals, and maintenance. Operations run through generic forms that resolve references through F4 pick directories — members, accounts, evidence, policies, checkers, journals, batches, cards, loans and the rest — so operators never need an id from outside the terminal. Every change stages through a review screen and commits through the shared financial services with an idempotency key; supervised changes route through the approval screens to an independent checker who decides and executes.

## Keyboard

The legend on each screen names the keys that screen accepts. The keypad under the screen offers the same keys by mouse.

| Key | Browser keys |
| --- | --- |
| Enter | Enter |
| PF1–PF12 | F1–F12, or Alt+1 … Alt+0, Alt+-, Alt+= |
| PF13–PF24 | Shift+F1–F12, F13–F24, or Alt+Shift with the PF1–PF12 alternatives |
| PF7 / PF8 (page) | Page Up / Page Down |
| Clear | Pause, or Alt+C |
| Next / previous field | Tab / Shift+Tab |
| Cursor | Arrow keys; Home goes to the first input field; End goes to the end of the field's text |
| Insert / overwrite | Insert, or Alt+I (the status line shows `INS` or `OVR`) |
| Delete / backspace | Delete / Backspace, within the field only |
| Erase to end of field | Ctrl+Delete, or Alt+E |
| Erase all input | Alt+Delete, or Alt+X |
| Reset (clear a keyboard lock) | Esc, or Alt+R |
| Download an offered file | Alt+D, or the link in the transfer bar |

On every screen, F1 shows help, F3 goes back and F12 cancels. Paste with the usual browser shortcut. A paste goes into the current field only, and one that does not fit is refused whole. Browser shortcuts that use Cmd stay with the browser. When the keyboard is locked after an error, type nothing until Reset. The host ignores a key sent for a screen it has already replaced.

## Checks

From `environments/terminal-host-banking/`:

```sh
npm run check    # typecheck, lint and unit/host tests on disposable database copies
npm run verify   # build, then Playwright browser verification
```

`npm run verify` writes screenshots, downloaded files and `evidence.json` per test under `verification/artifacts/<run>/`. Set `TERMINAL_HOST_VERIFICATION_RUN` to name the run; the default is a timestamp and process ID. Each `evidence.json` records browser observations and database observations separately. Tests copy the canonical database into a temporary directory and never write to the canonical file.

The workspace-level `npm run check`, `npm test`, `npm run build` and `npm run verify` in `environments/` include this app.

## Evaluator mode

An evaluator embeds the terminal around a verification run it owns:

```ts
import { verificationRunStore } from '@computer-use/financial-database/services';
import { startTerminalHost } from './src/server/app.js';

const handle = await startTerminalHost({
  store: verificationRunStore(run),          // run.read / run.write only
  bindings: [binding],                        // the run's institution binding
  operator: { actorNumbers: ['OP0002'], fixed: true },
  principalKind: 'automation',
  port: 0,
});
// ... drive the browser at handle.origin ...
await handle.close();                         // closes the listener, not the run
```

With `fixed: true` the backend names the operator and the sign-on screen cannot change it. Closing the terminal or any session leaves the run open for the evaluator's own `verify` and `close`. `verification/evaluator-run.spec.ts` is a working example that the task verifier grades.

## Shutdown

Press Ctrl+C or send SIGTERM. The server stops accepting connections and closes idle ones. After two seconds it closes any that remain, then closes the database. Terminal sessions live in memory, so a restart signs every operator off. Business data is unaffected.

