# Terminal Host Banking specification

## Identity

| Field | Value |
| --- | --- |
| Application ID | `terminal-host-banking` |
| Version | 0.1.0 |
| Family | Terminal host (3270/5250 style block-mode screens) |
| Default port | 4340 (`TERMINAL_HOST_PORT`) |
| Data | Shared financial database through `@computer-use/financial-database` |

A branch operator signs on to one institution and services members and accounts on 80 × 24 screens. The host sends a whole screen; the operator edits unprotected fields locally and presses an attention key (Enter, a PF key or Clear). Only then does the host see the modified fields, the cursor position and the key. This block-mode exchange is the product. It is not a skin over a web form.

## Screens

Every screen shows its screen ID in the top row, stable business identifiers on record screens, and a page indicator on paged screens. The bottom two rows carry the key legend; a message line reports the result of the last key. The menu accepts an option number or a transaction code such as `MB01` or `TX02`.

| Module | Screens |
| --- | --- |
| Session | `THSIGN` sign-on, `THMENU` main menu, `THHELP` help for the current screen (paged; returns with entries intact) |
| Members | `THMB01` search and list, `THMB02` inquiry (2 pages), `THMB03` new person or organization member, `THMB04` review new member, `THMB05` contact maintenance, `THMB06` review contact change, `THMB07` notes, `THMB08` add note (2 editor pages), `THMB09` note, `THMB10` review new note |
| Cases | `THCS01` case work queue, `THCS02` case inquiry (summary page, then history pages), `THCS03` open case, `THCS04` review, `THCS05` route, `THCS06` review, `THCS07` change status, `THCS08` review, `THCS09` correct subject with evidence and approval, `THCS10` review, `THCS11` case notes, `THCS12` add case note, `THCS13` case note, `THCS14` review case note |
| Saved searches | `THSS01` saved searches, `THSS02` results with column scrolling, `THSS03` editor, `THSS04` review, `THSS05` review deletion |
| Accounts | `THAC01` search and list, `THAC02` inquiry (2 pages), `THAC03` open account, `THAC04` review new account, `THAC05` maintenance (nickname, statement delivery), `THAC06` review maintenance, `THAC07` close account with eligibility, `THAC08` review closure |
| Money | `THTX01` cash deposit, `THTX02` cash withdrawal, `THTX03` internal transfer, `THTX04` review money movement |
| Receipts | `THRC01` receipt, `THRC02` receipt inquiry |
| History | `THHI01` transaction history with filters, `THHI02` entry detail |
| Statements | `THST01` stored documents and ledger periods, `THST02` statement view, `THEX01` transaction export |
| Activity | `THAV01` activity inquiry, `THAV02` event detail |

List screens take a one-letter selection code beside a row. Record screens let the operator type another identifier over the key field to switch records on the same coordinates. `THAC02` shows any account, `THTX04` reviews deposits, withdrawals and transfers, and `THAC06` reviews either maintenance change. Returning to a list restores its criteria, page and position, and clears the selection codes.

## Terminal mechanisms

- **Fields.** The host describes each field by buffer address, row, column, length in cells, capacity in characters, protection, numeric type and tone. An input field may wrap across rows, as a 3270 field does. The client's field buffer is separate from the rendered cells; cells only display it.
- **Long values.** Capacities come from the shared limits, not from field widths. A value longer than its cells scrolls inside the field, and the status line shows the character position against the limit with `<` or `>` when text is hidden. Review screens continue long values on following rows and page with F7/F8. Notes use a two-page editor. Messages longer than the message line end in `(F1 MORE)`, and F1 shows them whole.
- **Editing.** Typing overwrites by default; Insert toggles insert mode. Typing into a protected cell, overflowing a field in insert mode, or entering a letter in a numeric field locks the keyboard until Reset. A full field skips the cursor to the next input field, never into protected text. Tab and Shift+Tab move between input fields and wrap. Delete, Backspace, erase to end of field and erase all input act within fields only.
- **Paste.** A paste goes into the current field from the cursor. Text with line breaks, text that does not fit and non-numeric text in a numeric field are refused whole. A paste never spills into another field and never sends the screen.
- **Attention keys.** Enter, PF1–PF24 and Clear send the modified fields with the screen's sequence number. F keys, Alt alternatives, Page Up and Page Down, and the on-screen keypad map to the same keys. The keyboard shows `X SYSTEM` while the host owns the screen; keys pressed then are ignored.
- **Input ownership.** The host processes one message per session at a time. It acts only on a message that answers the current screen's sequence, and warns and changes nothing for a stale one. A transmission is all or nothing: if any field is refused or processing fails, the session's screen stack is restored.
- **Validation.** A refused entry keeps every typed value, names the problem on the message line, and puts the cursor on the field.
- **Unsaved changes.** F3 or F12 on a screen with unsent edits first asks for confirmation. The same key again discards them; Enter keeps them. F1 opens help and returns with the entries intact. Clear redisplays the screen without the unsent entries, as on a 3270.
- **Review.** Every change goes through a review screen that shows before and after values and an idempotency key. Nothing is written until the operator types Y and presses Enter. A repeated request returns the original receipt.
- **Conflicts.** If another operator changed the record since the screen was read, the host keeps the operator's draft and shows the current stored values beside it (`NOW:`).
- **Characters.** Cells are measured by user-perceived character. East Asian wide, fullwidth and emoji-presentation characters take two cells, and the cursor never rests on their second cell. Control, bidirectional override and zero-width formatting characters are refused. Stored values are never altered for display. A stored value containing a control character, such as a line break written by another application, is shown protected because a 3270 field cannot carry it.
- **Layout.** The screen scales to the window between 9 and 20 pixel cells. The cursor stays visible in overwrite, insert and unfocused states. When the terminal loses focus, an overlay says input is paused.
- **Downloads.** Statements and exports are offered through a transfer bar with file name, size and SHA-256 digest; Alt+D or the link downloads the bytes.

## Business behaviour

All rules come from the shared services: minor-unit amounts with explicit currency and exponent, double-entry journals, holds and available funds, account eligibility, atomic commands with idempotency keys and record versions, capability grants, durable receipts and business events. The terminal adds no financial rules. Screen handlers parse and validate entry formats, call `reviewCommand` for the review and `executeCommand` to commit, and render what the services return.

| Area | Functions |
| --- | --- |
| Members | Search by name, number, account prefix, email or phone with status filter; inquiry with contact details and accounts; person and organization creation; contact maintenance; notes up to 2,000 characters, general or restricted, with restricted notes withheld from operators without case or supervisory authority |
| Cases | Work queue by text, state, queue and own assignment; inquiry with timeline, work items, SLA intervals and documents; open, route, resolve, close, reopen, approved subject correction and case notes |
| Saved searches | Private or shared member, account and case searches with filters, one sort, columns and a result limit; run against current data; modify and delete |
| Accounts | Search and member account lists; inquiry with balances, holds, restrictions, parties and eligibility reasons; open, nickname, statement delivery; closure of eligible zero-balance accounts |
| Money | Cash deposit and withdrawal, internal transfer between one member's accounts in one currency; review; durable receipts with journal lines |
| History | Effective-date range, direction, amount range, text in reference or description, one exact reference ignoring letter case, status (posted or reversed), order; entry detail with journal |
| Statements | Stored statement documents served as their recorded bytes with a verified digest; ledger-period statement views; generated statement PDFs; CSV export of a date range |
| Activity | Committed business events by kind or text, newest first; event detail linking to receipts, members and accounts |

## Identity and sessions

The backend decides who the operator is. In shared mode the sign-on screen accepts only operators configured on the command line. In evaluator mode the backend fixes one operator and the terminal cannot change it. Each write records that operator's actor and the configured principal kind. Terminal sessions hold presentation state only (screen stack, sequence, pending message, offered files) and live in memory. Closing a session or the server never writes business data and never closes an evaluator's run.

## Evaluator integration

`startTerminalHost` takes any `FinancialStore`. The evaluator passes `verificationRunStore(run)`, which reads and writes only through the run's `read` and `write`. It also passes the run's institution binding and a fixed operator. The public API exposes screens and offered files only; no task contract, expected answer or grading data reaches the browser. Benchmark workflows and grading definitions live under `evaluation/`.

## Completion criteria

- Every screen above renders real data and every advertised function commits through the shared services, with a receipt and business events.
- Browser tests exercise field editing, paste, PF keys and alternatives, coordinate reuse, paging and restoration, validation, drafts, repeated submission, version conflicts, institution isolation, downloads, Unicode and layout.
- An app-driven operation inside an isolated verification run passes the task verifier.
- The capability manifest states readiness per capability using the shared contract's vocabulary.

