# Desktop MDI console

A browser-hosted operations desktop for Northstar, Riverton and Harbor. It opens many overlapping record windows over the shared financial database. [SPEC.md](SPEC.md) is the contract. IMPLEMENTATION.md (historical material omitted from this bundle) records decisions, evidence and limits. capability-manifest.json (historical material omitted from this bundle) records the qualified canonical capabilities and their browser evidence. Record desks and the operations catalog expose finance and servicing commands. See COVERAGE.md (historical material omitted from this bundle) for release status and source provenance.

## Run the application

Use Node 25.9 or newer. The desktop reads the shared database and never seeds it, so seed it once first. From `environments/`:

```sh
npm ci
npm --prefix database/financial run seed -- --path .runtime/financial.sqlite --verbose
npm run start:desktop-mdi-console
```

The seed path is relative to `database/financial/`, which is where the desktop looks by default. Open `http://127.0.0.1:4330`. `npm start -w desktop-mdi-console` builds and starts the application alone.

| Option | Default | Meaning |
| --- | --- | --- |
| `--port <n>` | `4330`, or `DESKTOP_MDI_PORT` | Listener port. `0` picks a free port. |
| `--host <address>` | `127.0.0.1` | Listener address. |
| `--database <path>` | `environments/database/financial/.runtime/financial.sqlite`, or `FINANCIAL_DATABASE_PATH` | Seeded financial SQLite file. |
| `--world <name>` | `financial-demo-v1` | Named world whose institution bindings the desktop serves. |
| `--operators <list>` | `OP0002,OP0003` | Operator numbers allowed to sign on. The first signs on by default. |
| `--verbose` | off | Log each request with status and latency. |

Pass options after `--`, for example `npm start -w desktop-mdi-console -- --port 4400 --verbose`. SIGINT and SIGTERM close the listener, drain connections and close the database.

In the canonical world, OP0002 (Casey Patel) is a servicer who can maintain records, post cash and work cases. OP0003 (Morgan Ellis) is a payments maker who can transfer. OP0001 (Jordan Lee) is a read-only viewer. Use **Desktop, Sign on as another operator** to switch.

## Using the desktop

Start from the menu bar or the welcome buttons. Double-click a grid row to open it, or use Shift+Enter or the row's context menu for a second window. **Help, Keyboard shortcuts** (Alt+Shift+K) lists every shortcut. The status bar always names the active window, institution, member and account. **New windows open in** chooses the institution for new searches.

## Evaluator mode

The evaluator starts the desktop in-process over its own run. The run's connection, capture, snapshots and disposal stay with the evaluator.

```ts
import { verificationRunStore } from '@computer-use/financial-database/services';
import { startDesktopConsole } from 'desktop-mdi-console/src/server/app.js';

const desktop = await startDesktopConsole({
  store: verificationRunStore(run), bindings: [binding], mode: 'verification',
  operator: { actorNumbers: ['OP0002'], fixed: true }, principalKind: 'automation', port: 0,
  publicDirectory: 'environments/desktop-mdi-console/dist/public',
});
// ...drive the UI at desktop.origin...
await desktop.close(); // detaches only; the run stays open for verification
```

## Checks

From this directory:

```sh
npm run check    # typecheck, lint, API tests on disposable copies
npm run verify   # build, then Playwright browser verification
```

Tests and browser verification seed a small world once into `.runtime/test-template.sqlite` and copy it for each test. `npm run verify` writes screenshots, per-test `evidence.json` files with separate browser and database sections, and one verifier report per qualification case under `verification/artifacts/<run>/`. Set `DESKTOP_MDI_VERIFICATION_RUN` to name the run.

| Spec | Covers |
| --- | --- |
| `desktop.spec.ts` | Window mechanics, stale edits and shortcuts. |
| `ownership.spec.ts` | Late responses, busy owners, stacked dialogs, restored state, overlapping edits and stale reviews. |
| `workspace.spec.ts` | Member accounts, transaction filters, stored documents, case links and saved searches. |
| `servicing.spec.ts` | Money commands, downloads, institution isolation and the servicing lifecycle. |
| `evaluator-run.spec.ts`, `qualification.spec.ts` | App-driven cases graded by the database verifier inside isolated runs. |

