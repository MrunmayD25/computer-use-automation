import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore, type FinancialStore } from '@computer-use/financial-database/services';
import { inject } from 'vitest';

import { startDesktopConsole, type DesktopConsoleHandle } from '../src/server/app.js';

export interface TestDesktop {
  path: string;
  bindings: readonly DatasetBinding[];
  store: FinancialStore;
  origin: string;
  handle: DesktopConsoleHandle;
  /** A cookie-carrying client for one browser session. */
  client: () => TestClient;
  close: () => Promise<void>;
}

export interface TestClient {
  get: (path: string) => Promise<Response>;
  post: (path: string, body: unknown, headers?: Record<string, string>) => Promise<Response>;
  json: <T>(path: string, body?: unknown) => Promise<T>;
}

/** Copies the cached template so each test owns a disposable database. */
export async function startTestDesktop(operators: readonly string[] = ['OP0002', 'OP0003', 'OP0001']): Promise<TestDesktop> {
  const directory = mkdtempSync(join(tmpdir(), 'desktop-mdi-'));
  const path = join(directory, 'financial.sqlite');
  copyFileSync(inject('templatePath'), path);
  const bindings = inject('templateBindings');
  const store = openFinancialStore({ path });
  const handle = await startDesktopConsole({ store, bindings, mode: 'shared', operator: { actorNumbers: operators, fixed: false }, port: 0, onClose: () => { store.close(); } });
  return {
    path, bindings, store, origin: handle.origin, handle,
    client() {
      let cookie = '';
      const send = async (path: string, init: RequestInit = {}): Promise<Response> => {
        const response = await fetch(`${handle.origin}${path}`, { ...init, headers: { ...(cookie === '' ? {} : { cookie }), ...(init.headers as Record<string, string> | undefined) } });
        const set = response.headers.get('set-cookie');
        if (set !== null) cookie = set.split(';')[0] ?? '';
        return response;
      };
      const client: TestClient = {
        get: (path) => send(path),
        post: (path, body, headers = {}) => send(path, { method: 'POST', body: JSON.stringify(body), headers: { 'content-type': 'application/json', ...headers } }),
        async json<T>(path: string, body?: unknown): Promise<T> {
          const response = body === undefined ? await client.get(path) : await client.post(path, body);
          if (!response.ok) throw new Error(`${path} returned ${String(response.status)}: ${await response.text()}`);
          return await response.json() as T;
        },
      };
      return client;
    },
    async close() {
      await handle.close();
      rmSync(directory, { recursive: true, force: true });
    },
  };
}

export function bindingOf(desktop: TestDesktop, institutionId: string): DatasetBinding {
  const binding = desktop.bindings.find((item) => item.institutionId === institutionId);
  if (binding === undefined) throw new Error(`No ${institutionId} binding.`);
  return binding;
}
