import type { DatasetBinding } from '@computer-use/financial-database';
import type { TestProject } from 'vitest/node';

import { ensureTemplate } from './template.js';

declare module 'vitest' {
  export interface ProvidedContext {
    templatePath: string;
    templateBindings: readonly DatasetBinding[];
  }
}

export default async function setup(project: TestProject): Promise<void> {
  const template = await ensureTemplate();
  project.provide('templatePath', template.path);
  project.provide('templateBindings', template.bindings);
}
