import { createHash } from 'node:crypto';
import { existsSync, mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import type {
  AccountDetail, AccountRow, CaseDetail, CaseRow, CaseSubjectCorrectionEvidenceDocument, CommandOutcome, DocumentListRow, IdentityEvidenceSummary, MemberDetail, MemberRow, PageResult, PolicyVersionSummary, Receipt, ReviewOutcome, ServiceCommand, ServicingApprovalCheckerSummary, TransactionRow,
} from '@computer-use/financial-database/services';
import { verificationRunStore } from '@computer-use/financial-database/services';
import { createRun } from '@computer-use/financial-database/verification';
import { afterAll, beforeAll, describe, expect, inject, it } from 'vitest';

import type { LimitedPage, SavedSearchList, SessionInfo } from '../src/shared/api.js';
import { startDesktopConsole } from '../src/server/app.js';
import { loadVerifier } from '../verification/evaluator.js';
import { bindingOf, startTestDesktop, type TestClient, type TestDesktop } from './support.js';

let desktop: TestDesktop;

beforeAll(async () => { desktop = await startTestDesktop(['OP0002', 'OP0003', 'OP0001', 'OP0005']); });
afterAll(async () => { await desktop.close(); });

const execute = (client: TestClient, institution: string, command: ServiceCommand, idempotencyKey: string): Promise<CommandOutcome> =>
  client.json<CommandOutcome>(`/api/i/${institution}/commands`, { command, idempotencyKey });

function committed(outcome: CommandOutcome): Receipt {
  if (outcome.kind !== 'committed') throw new Error(`Expected a commit, received ${JSON.stringify(outcome)}`);
  return outcome.receipt;
}

async function openAccounts(client: TestClient, institution: string): Promise<AccountDetail[]> {
  const page = await client.json<PageResult<AccountRow>>(`/api/i/${institution}/accounts?status=open&currency=USD&sort=accountNumber&limit=200`);
  return Promise.all(page.items.map((row) => client.json<AccountDetail>(`/api/i/${institution}/accounts/${row.id}`)));
}

describe('desktop session', () => {
  it('lists bound institutions and the signed-on operator without exposing datasets', async () => {
    const session = await desktop.client().json<SessionInfo>('/api/session');
    expect(session.mode).toBe('shared');
    expect(session.institutions.map((item) => [item.institutionId, item.asOf])).toEqual([
      ['northstar', '2026-09-14T15:00:00.000Z'], ['riverton', '2026-09-14T15:00:00.000Z'], ['harbor', '2026-09-14T15:00:00.000Z'],
    ]);
    expect(session.operator.actorNumber).toBe('OP0002');
    expect(session.operator.profiles.northstar?.roles).toEqual(['servicer']);
    expect(session.operatorChoices.map((choice) => choice.actorNumber)).toEqual(['OP0002', 'OP0003', 'OP0001', 'OP0005']);
    expect(JSON.stringify(session)).not.toContain('dataset');
  });

  it('refuses institutions outside the binding and raw dataset identifiers', async () => {
    const client = desktop.client();
    const unknown = await client.get('/api/i/elsewhere/members');
    expect(unknown.status).toBe(404);
    expect(await unknown.json()).toEqual({ error: { code: 'unknown_institution', message: 'This desktop is not bound to that institution.' } });
    expect((await client.get(`/api/i/${bindingOf(desktop, 'northstar').datasetId}/members`)).status).toBe(404);
  });

  it('restricts sign-on to configured operators', async () => {
    const client = desktop.client();
    const refused = await client.post('/api/session/operator', { actorNumber: 'OP9999' });
    expect(refused.status).toBe(403);
    expect(((await refused.json()) as { error: { code: string } }).error.code).toBe('operator_not_configured');
    expect(await client.json('/api/session/operator', { actorNumber: 'OP0003' })).toEqual({ actorNumber: 'OP0003' });
    expect((await client.json<SessionInfo>('/api/session')).operator.actorNumber).toBe('OP0003');
    expect((await desktop.client().json<SessionInfo>('/api/session')).operator.actorNumber).toBe('OP0002');
  });

  it('rejects cross-origin writes', async () => {
    const response = await desktop.client().post('/api/i/northstar/commands/review', { command: { kind: 'member.note.add', memberId: 'x', visibility: 'general', text: 'x' } }, { origin: 'http://attacker.example' });
    expect(response.status).toBe(403);
  });
});

describe('institution isolation', () => {
  it('resolves the same member number to different records per institution', async () => {
    const client = desktop.client();
    const northstar = await client.json<PageResult<MemberRow>>('/api/i/northstar/members?query=NM000002');
    const riverton = await client.json<PageResult<MemberRow>>('/api/i/riverton/members?query=NM000002');
    expect(northstar.items.map((row) => row.memberNumber)).toEqual(['NM000002']);
    expect(riverton.items.map((row) => row.memberNumber)).toEqual(['NM000002']);
    expect(northstar.items[0]?.id).not.toBe(riverton.items[0]?.id);
    const crossRead = await client.get(`/api/i/riverton/members/${northstar.items[0]?.id ?? ''}`);
    expect(crossRead.status).toBe(404);
  });
});

describe('money commands', () => {
  it('reviews, commits once, replays a duplicate and refuses a reused key with a different command', async () => {
    const client = desktop.client();
    const target = (await openAccounts(client, 'northstar')).find((detail) => detail.eligibility.credit.eligible);
    if (target === undefined) throw new Error('No credit-eligible account.');
    const command: ServiceCommand = { kind: 'cash.deposit', accountId: target.account.id, expectedVersion: target.account.version, amount: { minorUnits: 1234, currency: 'USD' }, description: 'Branch cash deposit' };
    const review = await client.json<ReviewOutcome>('/api/i/northstar/commands/review', { command });
    expect(review.kind).toBe('reviewable');
    if (review.kind !== 'reviewable') return;
    expect([review.review.amount, review.review.accounts.map((account) => account.accountNumber)]).toEqual([{ minorUnits: 1234, currency: 'USD' }, [target.account.accountNumber]]);

    const receipt = committed(await execute(client, 'northstar', command, 'deposit-key-0001'));
    expect(receipt.operationKind).toBe('cash.deposit');
    expect(receipt.actor.actorNumber).toBe('OP0002');
    expect(receipt.journals[0]?.lines.map((line) => [line.accountNumber, line.debitMinorUnits, line.creditMinorUnits])).toEqual([[null, 1234, 0], [target.account.accountNumber, 0, 1234]]);
    const after = await client.json<AccountDetail>(`/api/i/northstar/accounts/${target.account.id}`);
    expect(after.account.postedMinorUnits - target.account.postedMinorUnits).toBe(1234);

    const replay = await execute(client, 'northstar', command, 'deposit-key-0001');
    expect(replay.kind === 'duplicate' ? replay.receipt.receiptNumber : replay.kind).toBe(receipt.receiptNumber);
    const conflict = await execute(client, 'northstar', { ...command, amount: { minorUnits: 1235, currency: 'USD' } }, 'deposit-key-0001');
    expect(conflict.kind === 'rejected' ? conflict.code : conflict.kind).toBe('idempotency_conflict');
    expect((await client.json<AccountDetail>(`/api/i/northstar/accounts/${target.account.id}`)).account.postedMinorUnits).toBe(after.account.postedMinorUnits);

    const stored = await client.json<Receipt>(`/api/i/northstar/receipts/${receipt.receiptNumber}`);
    expect(stored).toEqual(receipt);
    expect((await client.get(`/api/i/riverton/receipts/${receipt.receiptNumber}`)).status).toBe(404);
  });

  it('enforces the transfer grant for the signed-on operator', async () => {
    const client = desktop.client();
    const accounts = (await openAccounts(client, 'northstar')).filter((detail) => detail.eligibility.debit.eligible && detail.eligibility.credit.eligible && detail.account.availableMinorUnits > 10_000);
    const source = accounts.find((detail) => accounts.some((other) => other !== detail && other.account.memberId === detail.account.memberId));
    const destination = accounts.find((detail) => detail !== source && detail.account.memberId === source?.account.memberId);
    if (source === undefined || destination === undefined) throw new Error('No same-member transfer pair.');
    const command: ServiceCommand = {
      kind: 'transfer.internal', sourceAccountId: source.account.id, destinationAccountId: destination.account.id, expectedSourceVersion: source.account.version,
      expectedDestinationVersion: destination.account.version, amount: { minorUnits: 5000, currency: 'USD' }, description: 'Move to savings',
    };
    const denied = await execute(client, 'northstar', command, 'transfer-key-0001');
    expect(denied.kind === 'rejected' ? denied.code : denied.kind).toBe('not_authorized');
    await client.json('/api/session/operator', { actorNumber: 'OP0003' });
    const receipt = committed(await execute(client, 'northstar', command, 'transfer-key-0002'));
    expect(receipt.journals[0]?.lines.map((line) => [line.accountNumber, line.debitMinorUnits, line.creditMinorUnits])).toEqual([
      [source.account.accountNumber, 5000, 0], [destination.account.accountNumber, 0, 5000],
    ]);
  });

  it('leaves no business rows behind for a viewer', async () => {
    const client = desktop.client();
    await client.json('/api/session/operator', { actorNumber: 'OP0001' });
    const target = (await openAccounts(client, 'riverton'))[0];
    if (target === undefined) throw new Error('No riverton account.');
    const count = (): number => desktop.store.read((database) => (database.prepare('SELECT COUNT(*) AS n FROM operations').get() as { n: number }).n);
    const before = count();
    const outcome = await execute(client, 'riverton', { kind: 'cash.deposit', accountId: target.account.id, expectedVersion: target.account.version, amount: { minorUnits: 100, currency: 'USD' }, description: 'Viewer attempt' }, 'viewer-key-0001');
    expect(outcome.kind === 'rejected' ? outcome.code : outcome.kind).toBe('not_authorized');
    expect(count()).toBe(before);
  });
});

describe('record-scoped stale edits', () => {
  it('rejects a stale contact edit but accepts an unrelated account edit made from an older view', async () => {
    const client = desktop.client();
    const member = (await client.json<PageResult<MemberRow>>('/api/i/harbor/members?status=active&limit=5')).items[0];
    if (member === undefined) throw new Error('No harbor member.');
    const detail = await client.json<MemberDetail>(`/api/i/harbor/members/${member.id}`);
    const account = detail.accounts.find((row) => row.status === 'open');
    if (account === undefined) throw new Error('Member has no open account.');

    committed(await execute(client, 'harbor', { kind: 'contact.update', memberId: member.id, expectedVersion: member.version, email: 'first.editor@example.test' }, 'contact-key-0001'));
    const stale = await execute(client, 'harbor', { kind: 'contact.update', memberId: member.id, expectedVersion: member.version, email: 'second.editor@example.test' }, 'contact-key-0002');
    expect(stale).toEqual({ kind: 'rejected', code: 'stale_version', message: expect.any(String) as string, currentVersion: member.version + 1 });
    committed(await execute(client, 'harbor', { kind: 'account.nickname.update', accountId: account.id, expectedVersion: account.version, nickname: 'Household bills' }, 'nickname-key-0001'));

    const after = await client.json<MemberDetail>(`/api/i/harbor/members/${member.id}`);
    expect([after.email?.value, after.accounts.find((row) => row.id === account.id)?.nickname]).toEqual(['first.editor@example.test', 'Household bills']);
  });
});

describe('documents', () => {
  it('downloads generated statement PDFs and transaction CSV exports with matching digests', async () => {
    const client = desktop.client();
    const target = (await openAccounts(client, 'northstar'))[0];
    if (target === undefined) throw new Error('No account.');
    const { periods } = await client.json<{ periods: string[] }>(`/api/i/northstar/accounts/${target.account.id}/statements`);
    const period = periods[0];
    if (period === undefined) throw new Error('No statement period.');

    const pdf = await client.get(`/api/i/northstar/accounts/${target.account.id}/statement.pdf?period=${period}`);
    const pdfBytes = Buffer.from(await pdf.arrayBuffer());
    expect(pdfBytes.subarray(0, 5).toString('latin1')).toBe('%PDF-');
    expect(pdf.headers.get('content-disposition')).toBe(`attachment; filename="northstar-${target.account.accountNumber}-statement-${period}.pdf"`);
    expect(pdf.headers.get('x-document-digest')).toBe(createHash('sha256').update(pdfBytes).digest('hex'));

    const csv = await client.get(`/api/i/northstar/accounts/${target.account.id}/transactions.csv?startDate=2026-01-01&endDate=2026-09-15`);
    const text = await csv.text();
    expect(csv.headers.get('content-type')).toBe('text/csv; charset=utf-8');
    expect(text.split('\n')[0]?.startsWith('﻿') ? text.split('\n')[0]?.slice(1) : text.split('\n')[0]).toMatch(/^"?[A-Za-z]/u);
    expect(csv.headers.get('x-document-digest')).toBe(createHash('sha256').update(Buffer.from(text, 'utf8')).digest('hex'));
  });
});

describe('search options', () => {
  it('finds an entry by exact reference in any letter case and filters it by status', async () => {
    const client = desktop.client();
    const target = (await openAccounts(client, 'harbor')).find((detail) => detail.eligibility.credit.eligible);
    if (target === undefined) throw new Error('No credit-eligible harbor account.');
    const receipt = committed(await execute(client, 'harbor', { kind: 'cash.deposit', accountId: target.account.id, expectedVersion: target.account.version, amount: { minorUnits: 777, currency: 'USD' }, description: 'Reference search deposit' }, 'reference-search-0001'));
    const search = (query: string): Promise<PageResult<TransactionRow>> => client.json<PageResult<TransactionRow>>(`/api/i/harbor/accounts/${target.account.id}/transactions?startDate=2026-09-01&endDate=2026-09-15&${query}`);
    const exact = await search(`reference=${receipt.businessReference.toLowerCase()}`);
    expect(exact.items.map((row) => [row.reference, row.amountMinorUnits, row.status, row.receiptNumber])).toEqual([[receipt.businessReference, 777, 'posted', receipt.receiptNumber]]);
    expect((await search(`reference=${receipt.businessReference.slice(0, -1)}`)).total).toBe(0);
    expect((await search(`reference=${receipt.businessReference}&status=posted`)).total).toBe(1);
    expect((await search(`reference=${receipt.businessReference}&status=reversed`)).total).toBe(0);
    expect((await client.get(`/api/i/harbor/accounts/${target.account.id}/transactions?startDate=2026-09-01&endDate=2026-09-15&status=pending`)).status).toBe(400);
  });

  it('stops totals and pages at an opened search result limit while reporting every match', async () => {
    const client = desktop.client();
    const all = await client.json<LimitedPage<MemberRow>>('/api/i/northstar/members?sort=memberNumber&limit=10');
    const limited = await client.json<LimitedPage<MemberRow>>('/api/i/northstar/members?sort=memberNumber&limit=2&offset=2&maxResults=3');
    expect([all.limitedTo, limited.items.map((row) => row.memberNumber), limited.total, limited.limitedTo, limited.matched]).toEqual([null, [all.items[2]?.memberNumber], 3, 3, all.total]);
    expect((await client.json<LimitedPage<MemberRow>>('/api/i/northstar/members?limit=2&offset=4&maxResults=3')).items).toEqual([]);
  });
});

describe('stored documents', () => {
  it('lists stored document versions by type and account with their owning member', async () => {
    const client = desktop.client();
    expect(await client.json<string[]>('/api/i/northstar/document-types')).toEqual([
      'account-statement', 'address-evidence', 'address-evidence-image', 'batch-input', 'delivery-disclosure', 'dispute-evidence',
      'loan-closure-confirmation', 'loan-closure-confirmation-template', 'loan-payoff-quote', 'redacted-evidence', 'servicing-notice', 'settlement-input', 'signature-evidence', 'simulated-lien-release-template', 'statement-csv',
    ]);
    const statements = await client.json<PageResult<DocumentListRow>>('/api/i/northstar/documents?accountId=northstar-account-1&documentType=account-statement&limit=50');
    expect(statements.total).toBe(13);
    expect([...new Set(statements.items.map((row) => `${row.documentType} ${row.accountNumber ?? ''} ${row.memberNumber}`))]).toEqual(['account-statement AC0000001 NM000002']);
    const first = statements.items[0];
    if (first === undefined) throw new Error('No stored statement.');
    const content = await client.get(`/api/i/northstar/documents/${first.versionId}/content`);
    expect(createHash('sha256').update(Buffer.from(await content.arrayBuffer())).digest('hex')).toBe(first.digest);
  });
});

describe('saved searches', () => {
  it('creates, lists, refuses a stale update, updates and deletes a private search', async () => {
    const client = desktop.client();
    const definition = { entity: 'cases', filters: { priority: 'urgent', overdue: true }, sort: [{ field: 'due_at', direction: 'asc' }], columns: ['case_number', 'due_at'], maxResults: 5 } as const;
    const created = committed(await execute(client, 'northstar', { kind: 'search.saved.create', name: 'Urgent overdue', visibility: 'private', definition }, 'saved-search-0001'));
    const searchId = created.affected.find((record) => record.kind === 'saved-search')?.id ?? '';
    const list = (): Promise<SavedSearchList> => client.json<SavedSearchList>('/api/i/northstar/saved-searches?entity=cases');
    const listed = await list();
    const row = listed.searches.find((search) => search.id === searchId);
    expect([row?.name, row?.visibility, row?.mine, row?.problem, row?.definition, listed.vocabulary.sorts.due_at]).toEqual(['Urgent overdue', 'private', true, null, definition, 'due']);

    const stale = await execute(client, 'northstar', { kind: 'search.saved.update', searchId, expectedRevision: 'stale-revision', definition: { ...definition, maxResults: 10 } }, 'saved-search-0002');
    expect(stale.kind === 'rejected' ? stale.code : stale.kind).toBe('stale_version');
    committed(await execute(client, 'northstar', { kind: 'search.saved.update', searchId, expectedRevision: row?.revision ?? '', definition: { ...definition, maxResults: 10 } }, 'saved-search-0003'));
    const updated = (await list()).searches.find((search) => search.id === searchId);
    expect(updated?.definition?.maxResults).toBe(10);
    committed(await execute(client, 'northstar', { kind: 'search.saved.delete', searchId, expectedRevision: updated?.revision ?? '' }, 'saved-search-0004'));
    expect((await list()).searches.map((search) => search.id)).not.toContain(searchId);
    expect((await client.get('/api/i/northstar/saved-searches?entity=loans')).status).toBe(400);
  });
});

describe('unknown outcomes', () => {
  it('settles an attempt by its request key: the receipt when committed, not_committed otherwise', async () => {
    const client = desktop.client();
    const target = (await openAccounts(client, 'riverton')).find((detail) => detail.eligibility.credit.eligible);
    if (target === undefined) throw new Error('No credit-eligible riverton account.');
    const receipt = committed(await execute(client, 'riverton', { kind: 'cash.deposit', accountId: target.account.id, expectedVersion: target.account.version, amount: { minorUnits: 250, currency: 'USD' }, description: 'Outcome lookup' }, 'outcome-key-0001'));
    expect(await client.json<Receipt>('/api/i/riverton/operations/by-key/outcome-key-0001')).toEqual(receipt);
    const missing = await client.get('/api/i/riverton/operations/by-key/outcome-key-0002');
    expect([missing.status, await missing.json()]).toEqual([404, { error: { code: 'not_committed', message: 'No operation committed under this request key.' } }]);
    expect((await client.get('/api/i/northstar/operations/by-key/outcome-key-0001')).status).toBe(404);
  });
});

interface CaseSubjectPrerequisites {
  identityEvidence: IdentityEvidenceSummary[];
  evidenceDocuments: CaseSubjectCorrectionEvidenceDocument[];
  approvalCheckers: ServicingApprovalCheckerSummary[];
  policyVersions: PolicyVersionSummary[];
  approvals: { kind: 'found'; approvals: { id: string; status: string; fingerprint: string }[] };
}

describe('case subject correction', () => {
  it('uses exact evidence and independent approval, and refuses missing prerequisites or authority', async () => {
    const client = desktop.client();
    const record = (await client.json<LimitedPage<CaseRow>>('/api/i/northstar/cases?query=CS000002')).items.find((row) => row.caseNumber === 'CS000002');
    if (record === undefined) throw new Error('No case CS000002.');
    const prerequisites = await client.json<CaseSubjectPrerequisites>(`/api/i/northstar/servicing/case-subject-correction/${record.memberId}?correctedMemberId=northstar-member-3`);
    const evidenceVersionId = prerequisites.evidenceDocuments.find((item) => item.memberId === 'northstar-member-3')?.versionId;
    const checker = prerequisites.approvalCheckers.find((item) => item.actorNumber === 'OP0005');
    const policy = prerequisites.policyVersions[0];
    if (evidenceVersionId === undefined || checker === undefined || policy === undefined) throw new Error('Corrected-member case correction prerequisites are missing.');
    const target: Extract<ServiceCommand, { kind: 'case.subject.correct' }> = {
      kind: 'case.subject.correct', caseId: record.id, expectedVersion: record.version, correctMemberId: 'northstar-member-3', correctAccountId: 'northstar-account-3', evidenceVersionId, approvalId: 'pending-approval',
    };
    const unauthorized = await execute(client, 'northstar', { ...target, evidenceVersionId: 'missing-version' }, 'case-subject-maker-without-authority');
    expect(unauthorized).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    const requested = committed(await execute(client, 'northstar', { kind: 'approval.request', target, checkerActorId: checker.id, policyVersionId: policy.id, expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: null }, 'case-subject-request'));
    const approvalId = requested.affected.find((item) => item.kind === 'approval')?.id;
    if (approvalId === undefined) throw new Error('Approval request omitted its ID.');
    expect(await execute(client, 'northstar', { ...target, approvalId }, 'case-subject-maker-refused')).toMatchObject({ kind: 'rejected', code: 'not_authorized' });
    await client.json('/api/session/operator', { actorNumber: 'OP0005' });
    expect(await execute(client, 'northstar', { ...target, evidenceVersionId: 'missing-version', approvalId }, 'case-subject-missing-evidence')).toMatchObject({ kind: 'rejected', code: 'ownership_mismatch' });
    const checkerView = await client.json<CaseSubjectPrerequisites>(`/api/i/northstar/servicing/case-subject-correction/${record.memberId}`);
    const approval = checkerView.approvals.approvals.find((item) => item.id === approvalId);
    if (approval === undefined) throw new Error('Checker cannot see the pending approval.');
    committed(await execute(client, 'northstar', { kind: 'approval.decide', approvalId, expectedFingerprint: approval.fingerprint, decision: 'approve', reason: 'Reviewed the exact misfiled subject and current evidence.' }, 'case-subject-approve'));
    expect(await execute(client, 'northstar', { ...target, approvalId: 'missing-approval' }, 'case-subject-no-approval')).toMatchObject({ kind: 'rejected', code: 'not_authorized', field: 'approvalId' });
    committed(await execute(client, 'northstar', { ...target, approvalId }, 'case-subject-correct'));
    const detail = await client.json<CaseDetail>(`/api/i/northstar/cases/${record.id}`);
    expect([detail.case.memberId, detail.case.accountId, detail.case.version, detail.case.queueCode]).toEqual(['northstar-member-3', 'northstar-account-3', record.version + 1, 'RESTRICTED']);
    expect(detail.events.at(-1)?.detail).toContain('Corrected subject from');
  });
});

describe('verification mode', () => {
  it('grades an API-driven change, then disposes the run and keeps the report', async () => {
    const { startTaskRun, desktopStatementDeliveryContract, desktopCaseFacts: facts } = await loadVerifier();
    const root = mkdtempSync(join(tmpdir(), 'desktop-mdi-graded-'));
    const binding = bindingOf(desktop, 'northstar');
    const session = await startTaskRun({ root, sourcePath: inject('templatePath'), contract: desktopStatementDeliveryContract(binding) });
    try {
      const handle = await startDesktopConsole({ store: verificationRunStore(session), bindings: [binding], mode: 'verification', operator: { actorNumbers: ['OP0002'], fixed: true }, principalKind: 'automation', port: 0 });
      const cookie = (await fetch(`${handle.origin}/api/session`)).headers.get('set-cookie')?.split(';')[0] ?? '';
      const outcome = await (await fetch(`${handle.origin}/api/i/northstar/commands`, {
        method: 'POST', headers: { 'content-type': 'application/json', cookie },
        body: JSON.stringify({ command: { kind: 'account.statement_delivery.update', accountId: facts.accountId, expectedVersion: facts.versionBefore, statementDelivery: facts.statementDelivery }, idempotencyKey: 'run-delivery-0001' }),
      })).json() as CommandOutcome;
      const receipt = committed(outcome);
      await handle.close();

      const { databasePath } = session.descriptor();
      expect(existsSync(databasePath)).toBe(true);
      const reportPath = join(root, 'report.json');
      const report = await session.verify({ disposition: 'completed', outputs: { accountNumber: facts.accountNumber, statementDelivery: facts.statementDelivery, receiptNumber: receipt.receiptNumber } }, { reportPath, dispose: true });
      expect([report.databaseVerdict, report.checks.filter((check) => check.status !== 'pass')]).toEqual(['pass', []]);
      expect(existsSync(databasePath)).toBe(false);
      expect((JSON.parse(readFileSync(reportPath, 'utf8')) as { runId: string }).runId).toBe(report.runId);
    } finally {
      session.close();
      rmSync(root, { recursive: true, force: true });
    }
  });

  it('routes writes through the run writer with trusted actor context and leaves the run open after the desktop closes', async () => {
    const root = mkdtempSync(join(tmpdir(), 'desktop-mdi-run-'));
    const binding = bindingOf(desktop, 'northstar');
    const run = await createRun({ root, sourcePath: inject('templatePath'), bindings: [binding], contractDigest: 'a'.repeat(64) });
    try {
      run.begin();
      const handle = await startDesktopConsole({ store: verificationRunStore(run), bindings: [binding], mode: 'verification', operator: { actorNumbers: ['OP0002'], fixed: true }, principalKind: 'automation', port: 0 });
      const session = await (await fetch(`${handle.origin}/api/session`)).json() as SessionInfo;
      expect([session.mode, session.operatorChoices, session.institutions.map((item) => item.institutionId)]).toEqual(['verification', [], ['northstar']]);
      const cookie = (await fetch(`${handle.origin}/api/session`)).headers.get('set-cookie')?.split(';')[0] ?? '';
      const switched = await fetch(`${handle.origin}/api/session/operator`, { method: 'POST', headers: { 'content-type': 'application/json', cookie }, body: JSON.stringify({ actorNumber: 'OP0003' }) });
      expect(switched.status).toBe(403);
      const accounts = await (await fetch(`${handle.origin}/api/i/northstar/accounts?status=open&limit=1`, { headers: { cookie } })).json() as PageResult<AccountRow>;
      const account = accounts.items[0];
      if (account === undefined) throw new Error('No account.');
      const outcome = await (await fetch(`${handle.origin}/api/i/northstar/commands`, {
        method: 'POST', headers: { 'content-type': 'application/json', cookie },
        body: JSON.stringify({ command: { kind: 'account.nickname.update', accountId: account.id, expectedVersion: account.version, nickname: 'Evaluator nickname' }, idempotencyKey: 'run-nickname-0001' }),
      })).json() as CommandOutcome;
      expect(outcome.kind).toBe('committed');
      await handle.close();

      expect(run.read((database) => database.prepare('SELECT nickname FROM accounts WHERE dataset_id=? AND id=?').get(binding.datasetId, account.id))).toEqual({ nickname: 'Evaluator nickname' });
      const reportPath = join(root, 'missing-report.json');
      expect(() => { run.dispose({ reportPath }); }).toThrow('Finish the run and persist its report before disposal.');
      const evidence = run.finish();
      expect(evidence.transactions.map((transaction) => [transaction.context.kind, transaction.context.actorId, transaction.changes.map((change) => `${change.operation}:${change.table}`)])).toEqual([
        ['automation', 'northstar-actor-2', ['insert:operations', 'insert:operation_receipts', 'update:accounts', 'insert:business_events']],
      ]);
      expect(() => { run.dispose({ reportPath }); }).toThrow(/ENOENT/u);
      expect([existsSync(run.descriptor().databasePath), existsSync(run.descriptor().evidencePath)]).toEqual([true, true]);
    } finally {
      run.close();
      rmSync(root, { recursive: true, force: true });
    }
  });
});

describe('finance and servicing surface', () => {
  it('lists bounded finance records and returns an exact snapshot with fingerprint', async () => {
    const client = desktop.client();
    const rejected = await client.json<{ kind: string; code: string }>('/api/i/northstar/query/finance', { kind: 'finance.records', resource: 'payment', scope: {}, limit: 5 });
    expect(rejected).toMatchObject({ kind: 'rejected', code: 'validation' });
    const account = (await client.json<PageResult<AccountRow>>('/api/i/northstar/accounts?status=open&limit=1')).items[0];
    expect(account?.id).toBeDefined();
    const journals = await client.json<{ kind: string; items: { id: string }[] }>('/api/i/northstar/query/finance', { kind: 'finance.records', resource: 'journal', scope: { accountId: account?.id ?? '' }, limit: 5 });
    expect(journals.kind).toBe('listed');
    const listed = journals as unknown as { items: { id: string }[]; total: number };
    expect(listed.total).toBeGreaterThan(0);
    const first = listed.items[0];
    expect(first?.id).toBeDefined();
    const detail = await client.json<{ kind: string; snapshot?: { id: string; fingerprint: string; record: Record<string, unknown> } }>('/api/i/northstar/query/finance', { kind: 'finance.record', resource: 'journal', id: first?.id ?? '' });
    expect(detail.kind).toBe('found');
    expect(detail.snapshot?.fingerprint).toMatch(/^[0-9a-f]{64}$/);
    expect(Object.keys(detail.snapshot?.record ?? {}).length).toBeGreaterThan(3);
  });

  it('serves member-scoped servicing reads: evidence, histories, consents, documents and jobs', async () => {
    const client = desktop.client();
    const member = (await client.json<PageResult<MemberRow>>('/api/i/northstar/members?query=NM000001')).items[0];
    expect(member?.id).toBe('northstar-member-1');
    const memberId = member?.id ?? '';
    if (memberId === '') throw new Error('Seeded member missing.');
    for (const path of ['identity-evidence', 'addresses', 'destinations', 'consents', 'preferences', 'maintenance-requests', 'communication-jobs', 'documents', 'name-history', 'tax-history']) {
      const rows = await client.json<unknown[]>(`/api/i/northstar/servicing/${path}/${memberId}`);
      expect(Array.isArray(rows), path).toBe(true);
    }
    const evidence = await client.json<IdentityEvidenceSummary[]>(`/api/i/northstar/servicing/identity-evidence/${memberId}`);
    expect(evidence[0]?.memberId).toBe(memberId);
    const names = await client.json<{ givenName: string; familyName: string }[]>(`/api/i/northstar/servicing/name-history/${memberId}`);
    expect(names.length).toBeGreaterThan(0);
    expect(names[0]?.givenName.length).toBeGreaterThan(0);
  });

  it('lists approvals and approval checkers for finance and servicing command kinds', async () => {
    const client = desktop.client();
    const approvals = await client.json<{ kind: string; approvals: { id: string; status: string }[] }>('/api/i/northstar/approvals');
    expect(approvals.kind).toBe('found');
    for (const kind of ['member.legal_name.update', 'payment.approve_release', 'account.hold.place']) {
      const checkers = await client.json<ServicingApprovalCheckerSummary[]>(`/api/i/northstar/servicing/checkers/${kind}`);
      expect(Array.isArray(checkers), kind).toBe(true);
      expect(checkers.every((checker) => checker.actorNumber !== ''), kind).toBe(true);
    }
  });

  it('executes a finance command through the generic envelope with review, receipt and idempotent retry', async () => {
    const client = desktop.client();
    const account = (await openAccounts(client, 'northstar')).find((detail) => detail.eligibility.debit.eligible);
    expect(account?.account.id).toBeDefined();
    if (account === undefined) throw new Error('No debit-eligible account.');
    const command = {
      kind: 'account.hold.place', accountId: account.account.id, expectedVersion: account.account.version,
      amount: { minorUnits: 500, currency: 'USD' }, reason: 'Court order review', expiresAt: '2027-06-01T00:00:00.000Z', releaseAuthority: 'legal-clearance',
    } as unknown as ServiceCommand;
    const review = await client.json<ReviewOutcome>('/api/i/northstar/commands/review', { command });
    expect(review.kind).toBe('reviewable');
    const key = `api-hold-${Date.now()}`;
    const outcome = committed(await execute(client, 'northstar', command, key));
    const retry = await execute(client, 'northstar', command, key);
    expect(retry.kind).toBe('duplicate');
    expect((retry as { receipt: Receipt }).receipt.receiptNumber).toBe(outcome.receiptNumber);
    const stale = await execute(client, 'northstar', command, `api-hold-stale-${Date.now()}`);
    expect(stale).toMatchObject({ kind: 'rejected', code: 'stale_version' });
    const holds = await client.json<{ kind: string; items: { id: string }[] }>('/api/i/northstar/query/finance', { kind: 'finance.records', resource: 'hold', scope: { accountId: account.account.id }, limit: 10 });
    const existing = new Set(account.holds.map((hold) => hold.id));
    const placed = holds.items.filter((item) => !existing.has(item.id));
    expect(placed).toHaveLength(1);
    const hold = await client.json<{ kind: string; snapshot?: { fingerprint: string } }>('/api/i/northstar/query/finance', { kind: 'finance.record', resource: 'hold', id: placed[0]?.id ?? '' });
    expect(hold.snapshot?.fingerprint).toMatch(/^[0-9a-f]{64}$/);
  });

  it('runs an atomic command batch and exposes the receipt', async () => {
    const client = desktop.client();
    const member = (await client.json<PageResult<MemberRow>>('/api/i/northstar/members?query=NM000001')).items[0];
        const commands = [
      { kind: 'member.note.add', memberId: member?.id, visibility: 'general', text: 'Atomic batch note' },
    ] as unknown as ServiceCommand[];
    const outcome = await client.json<{ kind: string; receipt?: { receiptNumber: string }; items?: { kind: string }[] }>('/api/i/northstar/commands/atomic', { commands, idempotencyKey: `api-atomic-${Date.now()}` });
    expect(outcome.kind).toBe('committed');
    expect(outcome.receipt?.receiptNumber).toMatch(/^RCP/);
    expect(outcome.items).toHaveLength(1);
  });

  it('exports a statement bundle with digested bytes and retrieves issued historical statements', async () => {
    const client = desktop.client();
    const detail = (await openAccounts(client, 'northstar'))[0];
    if (detail === undefined) throw new Error('No open account.');
    const exported = await client.json<{ kind: string; artifacts?: { format: string; digest: string; byteLength: number; contentBase64: string; mediaType: string }[] }>('/api/i/northstar/statements/export', {
      memberId: detail.account.memberId, accountId: detail.account.id, period: '2026-08', formats: ['pdf', 'csv'], destinationId: 'browser-download',
    });
    expect(exported.kind).toBe('artifacts');
    for (const artifact of exported.artifacts ?? []) {
      const bytes = Buffer.from(artifact.contentBase64, 'base64');
      expect(bytes.length).toBe(artifact.byteLength);
      expect(createHash('sha256').update(bytes).digest('hex')).toBe(artifact.digest);
    }
    const statements = await client.json<{ documents: { versionId: string; mediaType: string; digest: string; periodStart: string | null; periodEnd: string | null }[] }>(`/api/i/northstar/accounts/${detail.account.id}/statements`);
    const issued = statements.documents.find((document) => document.mediaType === 'application/pdf' && document.periodStart !== null);
    if (issued !== undefined) {
      const response = await client.get(`/api/i/northstar/accounts/${detail.account.id}/statements/historical?periodStart=${issued.periodStart}&periodEnd=${issued.periodEnd}&format=application/pdf`);
      expect(response.status).toBe(200);
      const bytes = Buffer.from(await response.arrayBuffer());
      expect(createHash('sha256').update(bytes).digest('hex')).toBe(issued.digest);
    }
  });

  it('resolves identity candidates and serves merge-plan inventory for member operations', async () => {
    const client = desktop.client();
    const resolved = await client.json<{ resolution: string; candidates: { memberId: string; score: number }[] }>('/api/i/northstar/identity/resolve', { memberNumber: 'NM000001' });
    expect(['unique', 'none', 'ambiguous']).toContain(resolved.resolution);
    if (resolved.candidates.length > 0) expect(resolved.candidates[0]?.memberId).toContain('northstar-member-1');
    const operator = await client.json('/api/session/operator', { actorNumber: 'OP0005' });
    expect(operator).toEqual({ actorNumber: 'OP0005' });
    const plans = await client.json<{ kind: string; items: { id: string }[] }>('/api/i/northstar/query/finance', { kind: 'finance.records', resource: 'merge-plan', scope: {}, limit: 10 });
    expect(plans.kind).toBe('listed');
    for (const item of plans.items) {
      const inventory = await client.json<{ kind: string; fingerprint?: string; tables?: unknown[] }>(`/api/i/northstar/merge-plans/${item.id}`);
      expect(inventory.kind).toBe('found');
      expect(inventory.fingerprint).toMatch(/^[0-9a-f]{64}$/);
    }
  });
});
