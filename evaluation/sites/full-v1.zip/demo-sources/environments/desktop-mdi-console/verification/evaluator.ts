import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

import type { DatasetBinding } from '@computer-use/financial-database';
import type { VerificationRun } from '@computer-use/financial-database/verification';

/** The evaluator owns grading definitions; this module only types the parts browser verification calls. */
const VERIFIER_DIRECTORY = resolve(import.meta.dirname, '..', '..', '..', 'evaluation', 'verifier');

export interface VerifierCheck { id: string; status: string; requirementId?: string; message?: string; actual?: unknown; expected?: unknown }

export interface VerifierReport {
  runId: string;
  databaseVerdict: string;
  overallTaskVerdict: string;
  checks: VerifierCheck[];
  externalRequirements: unknown[];
  capturedBindings?: Record<string, unknown>;
}

export interface TaskRunSession extends Pick<VerificationRun, 'read' | 'write'> {
  descriptor: () => { runId: string; databasePath: string; evidencePath: string };
  verify: (submission: unknown, options: { reportPath: string; dispose: boolean }) => Promise<VerifierReport>;
  dispose: (options: { reportPath: string }) => void;
  close: () => void;
}

export interface DepositCase {
  accountId: string;
  accountNumber: string;
  memberNumber: string;
  amountMinorUnits: number;
  currency: string;
  description: string;
  actorId: string;
  balanceBefore: number;
}

/** Facts of the further qualification cases, as the evaluator states them. */
export interface DesktopCaseFacts {
  accountId: string;
  accountNumber: string;
  nickname: string;
  statementDeliveryBefore: string;
  versionBefore: number;
  balanceBefore: number;
  siblingAccountId: string;
  siblingAccountNumber: string;
  siblingBalance: number;
  currency: string;
  statementDelivery: string;
  transferMinorUnits: number;
  transferDescription: string;
  overdraftMinorUnits: number;
  overdraftDescription: string;
  reviewMinorUnits: number;
  reviewDescription: string;
}

type ContractFactory = (binding: DatasetBinding) => unknown;

interface Verifier {
  startTaskRun: (options: { root: string; sourcePath: string; contract: unknown }) => Promise<TaskRunSession>;
}

interface Qualification {
  startDesktopQualificationRun: Verifier['startTaskRun'];
  desktopDepositCase: DepositCase;
  desktopDepositContract: ContractFactory;
  desktopCaseFacts: DesktopCaseFacts;
  desktopStatementDeliveryContract: ContractFactory;
  desktopTransferContract: ContractFactory;
  desktopWithdrawalRejectedContract: ContractFactory;
  desktopReviewCancelledContract: ContractFactory;
  desktopEditCancelledContract: ContractFactory;
}

export async function loadVerifier(): Promise<Verifier & Qualification> {
  const load = async <T>(...path: string[]): Promise<T> => await import(pathToFileURL(join(VERIFIER_DIRECTORY, ...path)).href) as T;
  const deposit = await load<Pick<Qualification, 'desktopDepositCase' | 'desktopDepositContract'>>('app-qualification', 'desktop-mdi-console-deposit.mjs');
  const cases = await load<Omit<Qualification, 'desktopDepositCase' | 'desktopDepositContract'>>('app-qualification', 'desktop-mdi-console-cases.mjs');
  return {
    startTaskRun: cases.startDesktopQualificationRun, startDesktopQualificationRun: cases.startDesktopQualificationRun, desktopDepositCase: deposit.desktopDepositCase, desktopDepositContract: deposit.desktopDepositContract,
    desktopCaseFacts: cases.desktopCaseFacts, desktopStatementDeliveryContract: cases.desktopStatementDeliveryContract, desktopTransferContract: cases.desktopTransferContract,
    desktopWithdrawalRejectedContract: cases.desktopWithdrawalRejectedContract, desktopReviewCancelledContract: cases.desktopReviewCancelledContract, desktopEditCancelledContract: cases.desktopEditCancelledContract,
  };
}
