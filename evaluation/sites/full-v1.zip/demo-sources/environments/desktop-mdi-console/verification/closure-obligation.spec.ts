import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { executeCommand, openFinancialStore } from '@computer-use/financial-database/services';
import { withTrustedFixtureTransaction } from '@computer-use/financial-database/testing';
import { startDesktopConsole } from '../src/server/app.js';
import { ensureTemplate } from '../test/template.js';
import { bindingFor, expect, findAccount, openDesktop, PUBLIC_DIRECTORY, shot, test } from './fixtures.js';

test('paused payment obligations keep a zero-balance account open through the rendered closure form', async ({ page, evidence, pageErrors }, info) => {
  const template = await ensureTemplate();
  const binding = bindingFor(template.bindings, 'northstar');
  const root = mkdtempSync(join(tmpdir(), 'desktop-closure-obligation-'));
  const path = join(root, 'financial.sqlite');
  copyFileSync(template.path, path);
  const store = openFinancialStore({ path });
  let handle: Awaited<ReturnType<typeof startDesktopConsole>> | undefined;
  try {
    const member = store.read(database => database.prepare("SELECT id,party_id FROM members WHERE dataset_id=? AND status='active' ORDER BY member_number LIMIT 1").get(binding.datasetId));
    if (typeof member?.id !== 'string' || typeof member.party_id !== 'string') throw new Error('Closure fixture requires an active member.');
    const partyId = member.party_id;
    const opened = executeCommand(store, { binding, actorId: 'northstar-actor-2', reference: 'browser-closure-fixture' }, { kind: 'account.open', memberId: member.id, productId: 'northstar-product-USD-checking', nickname: 'Closure obligation', statementDelivery: 'paper' }, 'browser-closure-fixture-open');
    if (opened.kind !== 'committed' || opened.receipt.result === null || typeof opened.receipt.result.accountId !== 'string' || typeof opened.receipt.result.accountNumber !== 'string') throw new Error(`Could not open closure fixture: ${JSON.stringify(opened)}`);
    const accountId = opened.receipt.result.accountId;
    const accountNumber = opened.receipt.result.accountNumber;
    withTrustedFixtureTransaction({ path, binding }, database => {
      database.prepare("INSERT INTO beneficiaries (dataset_id,id,owner_party_id,display_name,status) VALUES (?,'closure-browser-beneficiary',?,'Retained utility','active')").run(binding.datasetId, partyId);
      database.prepare("INSERT INTO beneficiary_routes (dataset_id,id,beneficiary_id,version,routing_kind,masked_destination,simulated_token,status,verified_at,expires_at) VALUES (?,'closure-browser-route','closure-browser-beneficiary',1,'ach','****0012','SYNTHETIC-CLOSURE-ROUTE','verified','2026-09-10T15:00:00.000Z',NULL)").run(binding.datasetId);
      database.prepare("INSERT INTO payment_schedules (dataset_id,id,source_account_id,beneficiary_route_id,rule_json,time_zone,calendar_version,start_date,end_date,state) VALUES (?,'closure-browser-schedule',?,'closure-browser-route','{}','America/Chicago','US-FI-2026.1','2026-09-14',NULL,'paused')").run(binding.datasetId, accountId);
      database.prepare("INSERT INTO schedule_occurrences (dataset_id,id,schedule_id,local_date,payment_id,state) VALUES (?,'closure-browser-occurrence','closure-browser-schedule','2026-09-15',NULL,'planned')").run(binding.datasetId);
    });
    handle = await startDesktopConsole({ store, bindings: [binding], mode: 'shared', operator: { actorNumbers: ['OP0002'], fixed: true }, port: 0, publicDirectory: PUBLIC_DIRECTORY });
    await openDesktop(page, handle.origin);
    const account = await findAccount(page, accountNumber);
    await expect(account.getByTestId('posted-balance')).toHaveText('0.00 USD');
    await account.getByRole('tab', { name: 'Close' }).click();
    await expect(account).toContainText('1 unretired payment schedule(s) use this account.');
    await expect(account.getByRole('button', { name: 'Close account…' })).toBeDisabled();
    const persisted = store.read(database => database.prepare('SELECT status,version,closed_at FROM accounts WHERE dataset_id=? AND id=?').get(binding.datasetId, accountId));
    expect(persisted).toEqual({ status: 'open', version: 1, closed_at: null });
    expect(pageErrors).toEqual([]);
    evidence.browser('Closure shows the unresolved schedule and disables commit', { accountNumber });
    evidence.database('Account remains open at version1', persisted);
    await shot(page, info, 'paused-schedule-prevents-closure');
  } finally {
    await handle?.close();
    store.close();
    rmSync(root, { recursive: true, force: true });
  }
});
