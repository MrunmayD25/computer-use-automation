import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

import type { Download, Locator, Page } from '@playwright/test';

import { chooseMenu, expect, findAccount, openDesktop, raise, shot, test, windows } from './fixtures.js';

const sha256 = (bytes: Buffer): string => createHash('sha256').update(bytes).digest('hex');

async function download(page: Page, link: Locator): Promise<{ file: Download; bytes: Buffer; digest: string | undefined }> {
  const [file] = await Promise.all([page.waitForEvent('download'), link.click()]);
  const bytes = readFileSync(await file.path());
  const href = await link.getAttribute('href');
  if (href === null) throw new Error('The download link has no address.');
  const response = await page.request.get(new URL(href, page.url()).href);
  expect(response.status()).toBe(200);
  return { file, bytes, digest: response.headers()['x-document-digest'] };
}

test('money commands validate, reject without effect, post once and stay revisitable', async ({ page, desktop, evidence, pageErrors }, info) => {
  const datasetId = desktop.datasetId('northstar');
  const operations = (): number => desktop.query<{ count: number }>('SELECT COUNT(*) AS count FROM operations WHERE dataset_id=?', datasetId)[0]?.count ?? -1;
  const balances = (): { account_id: string; posted_balance_minor_units: number }[] => desktop.query(
    "SELECT account_id, posted_balance_minor_units FROM account_balances WHERE dataset_id=? AND account_id IN ('northstar-account-1','northstar-account-2') ORDER BY account_id", datasetId);
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, 'AC0000001');
  await account.getByRole('button', { name: 'Withdrawal…' }).click();
  const withdrawal = windows(page, 'money');
  await expect(withdrawal.getByTestId('card-account-number')).toHaveText('AC0000001');
  const before = operations();

  await withdrawal.getByRole('button', { name: 'Review cash withdrawal…' }).click();
  await expect(withdrawal.locator('.field-error')).toHaveCount(1);
  await expect(withdrawal.getByRole('dialog')).toHaveCount(0);
  await withdrawal.getByLabel('Amount (USD)').fill('5966.15');
  await withdrawal.getByRole('button', { name: 'Review cash withdrawal…' }).click();
  await expect(withdrawal.getByTestId('rejection-code')).toHaveAttribute('data-code', 'insufficient_funds');
  await expect(withdrawal.getByRole('dialog')).toHaveCount(0);
  expect(operations()).toBe(before);
  evidence.database('validation and insufficient funds wrote nothing', { operationsBefore: before, operationsAfter: operations() });

  await withdrawal.getByLabel('Amount (USD)').fill('20.00');
  await withdrawal.getByRole('button', { name: 'Review cash withdrawal…' }).click();
  const review = withdrawal.getByRole('dialog', { name: 'Review cash withdrawal' });
  await expect(review.getByTestId('review-amount')).toHaveText('20.00 USD');
  await page.keyboard.press('Enter');
  const withdrawalReceipt = await withdrawal.getByTestId('receipt-number').innerText();
  await expect(account.getByTestId('posted-balance')).toHaveText('5,946.14 USD');
  expect(operations()).toBe(before + 1);

  const menubar = page.getByRole('menubar', { name: 'Desktop menu' });
  await menubar.getByRole('menuitem', { name: 'Money', exact: true }).click();
  await expect(page.getByRole('menu', { name: 'Money' }).getByRole('menuitem', { name: 'Internal transfer…' })).toHaveAttribute('aria-disabled', 'true');
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'OP0002 · Casey Patel' }).click();
  const signOn = page.getByRole('dialog', { name: 'Sign on as another operator' });
  await signOn.getByRole('radio', { name: /^OP0003/u }).check();
  await signOn.getByRole('button', { name: 'Sign on' }).click();
  await expect(page.getByTestId('status-operator')).toHaveText('Operator OP0003 · Morgan Ellis (payments-maker)');

  await chooseMenu(page, 'Money', 'Internal transfer…');
  const transfer = windows(page, 'money').nth(1);
  await transfer.getByLabel('Account number').fill('AC0000001');
  await transfer.getByRole('button', { name: 'Find', exact: true }).click();
  await expect(transfer.getByTestId('account-card-debit').getByTestId('card-account-number')).toHaveText('AC0000001');
  await transfer.getByLabel('Destination (same member)').selectOption('northstar-account-2');
  await expect(transfer.getByTestId('account-card-credit').getByTestId('card-account-number')).toHaveText('AC0000002');
  await transfer.getByLabel('Amount (USD)').fill('10.00');
  await transfer.getByRole('button', { name: 'Review internal transfer…' }).click();
  const transferReview = transfer.getByRole('dialog', { name: 'Review internal transfer' });
  await expect(transferReview.getByTestId('review-amount')).toHaveText('10.00 USD');
  const key = await transferReview.getByTestId('idempotency-key').innerText();
  await shot(page, info, 'transfer-review');
  await transferReview.getByRole('button', { name: 'Post transfer' }).dblclick();
  const transferReceipt = await transfer.getByTestId('receipt-number').innerText();
  await expect(account.getByTestId('posted-balance')).toHaveText('5,936.14 USD');
  expect(desktop.query('SELECT actor_id, operation_kind, status FROM operations WHERE dataset_id=? AND idempotency_key=?', datasetId, key))
    .toEqual([{ actor_id: 'northstar-actor-3', operation_kind: 'transfer.internal', status: 'committed' }]);
  expect(balances()).toEqual([{ account_id: 'northstar-account-1', posted_balance_minor_units: 593614 }, { account_id: 'northstar-account-2', posted_balance_minor_units: 439527 }]);
  evidence.browser('money receipts', { withdrawalReceipt, transferReceipt, requestKey: key });
  evidence.database('transfer committed once under OP0003', { operations: operations(), balances: balances() });

  await chooseMenu(page, 'Servicing', 'Activity and audit');
  const activity = windows(page, 'activity');
  await expect(activity.getByRole('row').filter({ hasText: transferReceipt }).first()).toBeVisible();
  await expect(activity.getByRole('row').filter({ hasText: withdrawalReceipt }).first()).toBeVisible();

  await chooseMenu(page, 'Money', 'Find receipt…');
  const find = page.getByRole('dialog', { name: 'Find receipt' });
  await find.getByLabel('Receipt number').fill(withdrawalReceipt);
  await find.getByRole('button', { name: 'Open receipt' }).click();
  const receipt = windows(page, 'receipt');
  await expect(receipt.getByTestId('receipt-view-number')).toHaveText(withdrawalReceipt);
  await expect(receipt).toContainText('OP0002 · Casey Patel');
  await shot(page, info, 'receipt-revisited');
  expect(pageErrors).toEqual([]);
});

test('statements and exports download the exact bytes the server digests', async ({ page, desktop, evidence, pageErrors }) => {
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, 'AC0000001');
  await account.getByRole('tab', { name: 'Statements' }).click();
  const link = account.getByRole('link', { name: /^Statement \d{4}-\d{2} \(PDF\)$/u }).first();
  const period = /\d{4}-\d{2}/u.exec(await link.innerText())?.[0];
  const pdf = await download(page, link);
  expect(pdf.file.suggestedFilename()).toBe(`northstar-AC0000001-statement-${period ?? ''}.pdf`);
  expect(pdf.bytes.subarray(0, 5).toString('latin1')).toBe('%PDF-');
  expect(pdf.bytes.subarray(-6).toString('latin1').trim()).toBe('%%EOF');
  expect(pdf.digest).toBe(sha256(pdf.bytes));

  await account.getByRole('tab', { name: 'Transactions' }).click();
  const csv = await download(page, account.getByRole('link', { name: 'Export CSV' }));
  expect(csv.file.suggestedFilename()).toBe('northstar-AC0000001-transactions-start_now.csv');
  const lines = csv.bytes.toString('utf8').trimEnd().split(/\r?\n/u);
  expect(lines[0]).toBe('member_number,account_number,currency,effective_date,reference,description,status,signed_minor_units,running_balance_minor_units,counterparty,receipt_number');
  expect(lines.length).toBeGreaterThan(1);
  expect(lines.slice(1).filter((line) => !line.startsWith('NM000002,AC0000001,USD,'))).toEqual([]);
  expect(csv.digest).toBe(sha256(csv.bytes));
  evidence.browser('downloads', { pdf: { name: pdf.file.suggestedFilename(), bytes: pdf.bytes.length, digest: pdf.digest }, csv: { name: csv.file.suggestedFilename(), rows: lines.length - 1, digest: csv.digest } });
  expect(pageErrors).toEqual([]);
});

test('windows stay bound to their institution and cannot read across institutions', async ({ page, desktop, evidence, pageErrors }, info) => {
  await openDesktop(page, desktop.origin);
  const northstar = await findAccount(page, 'AC0000001');
  await expect(northstar.getByTestId('posted-balance')).toHaveText('5,966.14 USD');

  await page.getByLabel('New windows open in').selectOption('riverton');
  await page.keyboard.press('Alt+Shift+A');
  const search = page.locator('section.window[data-window-kind="account-search"][data-institution="riverton"]');
  await expect(search).toHaveAttribute('data-active', 'true');
  await search.getByRole('searchbox', { name: 'Search accounts' }).fill('AC0000001');
  await search.getByRole('searchbox', { name: 'Search accounts' }).press('Enter');
  await search.getByRole('grid', { name: 'Accounts' }).getByRole('row').filter({ hasText: 'AC0000001' }).dblclick();
  const riverton = page.locator('section.window[data-window-kind="account"][data-institution="riverton"]');
  await expect(riverton.getByTestId('posted-balance')).toHaveText('11,668.71 USD');
  await expect(riverton.locator('.institution-badge')).toHaveText('Riverton');
  await expect(page.getByTestId('status-institution')).toHaveText('Institution: Riverton');
  await shot(page, info, 'two-institutions');

  await raise(page, northstar);
  await expect(page.getByTestId('status-institution')).toHaveText('Institution: Northstar');
  await expect(northstar.getByTestId('posted-balance')).toHaveText('5,966.14 USD');
  const crossRead = await page.request.get(`${desktop.origin}/api/i/riverton/accounts/northstar-account-1`);
  expect(crossRead.status()).toBe(404);
  evidence.browser('same account number, separate institutions', { northstar: '5,966.14 USD', riverton: '11,668.71 USD', crossInstitutionRead: crossRead.status() });
  expect(pageErrors).toEqual([]);
});

test('servicing lifecycle: onboard, note, open and close an account, assign and move a case', async ({ page, desktop, evidence, pageErrors }, info) => {
  const datasetId = desktop.datasetId('northstar');
  await openDesktop(page, desktop.origin);
  await chooseMenu(page, 'Members', 'New member…');
  const form = windows(page, 'member-new').getByRole('form', { name: 'New member' });
  await form.getByLabel('Legal given name').fill('Priya');
  await form.getByLabel('Legal family name').fill('Raman');
  await form.getByLabel('Birth date').fill('1990-04-12');
  await form.getByLabel('Email').fill('priya.raman@example.test');
  await form.getByRole('button', { name: 'Create member' }).click();
  const member = windows(page, 'member');
  await expect(member.locator('.record-number')).toHaveText(/^NM\d{6}$/u);
  const memberNumber = await member.locator('.record-number').innerText();
  expect(desktop.query('SELECT status, version FROM members WHERE dataset_id=? AND member_number=?', datasetId, memberNumber)).toEqual([{ status: 'active', version: 1 }]);

  await member.getByRole('tab', { name: 'Notes' }).click();
  await member.getByRole('form', { name: 'Add member note' }).getByLabel('New note').fill('Prefers email contact.');
  await member.getByRole('button', { name: 'Add note' }).click();
  await expect(member.locator('.note-text')).toHaveText(['Prefers email contact.']);

  await member.getByRole('button', { name: 'Open account…' }).click();
  const opening = windows(page, 'account-open');
  await opening.getByLabel('Product').selectOption('northstar-product-USD-checking');
  await opening.getByLabel('Nickname').fill('Everyday');
  await opening.getByRole('button', { name: 'Open account', exact: true }).click();
  await expect(opening.getByRole('alert')).toContainText('Opening an electronic-delivery account requires effective party-wide statement consent.');
  expect(desktop.query('SELECT a.id FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id WHERE a.dataset_id=? AND m.member_number=?', datasetId, memberNumber)).toEqual([]);
  await opening.getByLabel('Statement delivery').selectOption('paper');
  await opening.getByRole('button', { name: 'Open account', exact: true }).click();
  const account = page.locator(`section.window[data-window-kind="account"]`);
  await expect(account.locator('.record-number')).toHaveText(/^AC\d{7}$/u);
  const accountNumber = await account.locator('.record-number').innerText();
  await expect(account.getByTestId('posted-balance')).toHaveText('0.00 USD');

  await account.getByRole('tab', { name: 'Close' }).click();
  await account.getByLabel('Reason for closing').fill('Opened in error.');
  await account.getByRole('button', { name: 'Close account…' }).click();
  const confirm = account.getByRole('dialog', { name: `Close account ${accountNumber}` });
  await confirm.getByRole('button', { name: 'Close account' }).click();
  await expect(account.getByTestId('receipt-number')).toBeVisible();
  expect(desktop.query('SELECT status, nickname FROM accounts WHERE dataset_id=? AND account_number=?', datasetId, accountNumber)).toEqual([{ status: 'closed', nickname: 'Everyday' }]);
  evidence.database('onboarded member and closed zero-balance account', { memberNumber, accountNumber });

  await chooseMenu(page, 'Servicing', 'Case register');
  await windows(page, 'case-register').getByRole('grid', { name: 'Cases' }).getByRole('row').filter({ hasText: 'CS000001' }).dblclick();
  const caseWindow = windows(page, 'case');
  await expect(caseWindow.locator('.record-number')).toHaveText('CS000001');
  const assignment = caseWindow.getByRole('form', { name: 'Case assignment' });
  await assignment.getByLabel('Assignee').selectOption('northstar-actor-7');
  await assignment.getByLabel('Reason for change').fill('Balancing workload.');
  await assignment.getByRole('button', { name: 'Save assignment' }).click();
  await expect(caseWindow.getByTestId('receipt-number')).toBeVisible();
  await caseWindow.getByRole('group', { name: 'Status changes' }).getByRole('button', { name: 'Pending customer…' }).click();
  const transition = caseWindow.getByRole('dialog', { name: 'Change CS000001 to Pending customer' });
  await transition.getByLabel('Reason').fill('Waiting for signed form.');
  await transition.getByRole('button', { name: 'Change status' }).click();
  await expect(transition).toHaveCount(0);
  await expect(caseWindow.locator('.record-header')).toContainText('Cameron Díaz');
  await caseWindow.getByRole('tab', { name: 'Notes' }).click();
  await caseWindow.getByRole('form', { name: 'Add case note' }).getByLabel('New note').fill('Form requested by email.');
  await caseWindow.getByRole('button', { name: 'Add note' }).click();
  await expect(caseWindow.locator('.note-text').first()).toHaveText('Form requested by email.');
  await shot(page, info, 'case-worked');
  expect(desktop.query('SELECT state, assigned_actor_id, version FROM cases WHERE dataset_id=? AND case_number=?', datasetId, 'CS000001'))
    .toEqual([{ state: 'pending-customer', assigned_actor_id: 'northstar-actor-7', version: 3 }]);
  evidence.database('case assigned, moved and annotated', { case: 'CS000001', state: 'pending-customer', assignee: 'northstar-actor-7' });
  expect(pageErrors).toEqual([]);
});
