import type { Locator } from '@playwright/test';

import { contactField, expect, findAccount, openDesktop, openMember, raise, shot, taskbar, test, windows } from './fixtures.js';

const MEMBER = 'NM000002';

const zIndex = (window: Locator): Promise<number> => window.evaluate((node) => Number((node as HTMLElement).style.zIndex));
async function box(locator: Locator): Promise<{ x: number; y: number; width: number; height: number }> {
  const value = await locator.boundingBox();
  if (value === null) throw new Error('The element has no layout box.');
  return { x: Math.round(value.x), y: Math.round(value.y), width: Math.round(value.width), height: Math.round(value.height) };
}

test('overlapping editors keep their own drafts, z-order, geometry and focus', async ({ page, desktop, evidence, pageErrors }, info) => {
  await openDesktop(page, desktop.origin);
  const first = await openMember(page, MEMBER);
  const second = await openMember(page, MEMBER, { newWindow: true });
  await expect(windows(page, 'member')).toHaveCount(2);

  await raise(page, first);
  expect(await zIndex(first)).toBeGreaterThan(await zIndex(second));
  await contactField(first, 'Email').fill('first.draft@example.test');
  await raise(page, second);
  await contactField(second, 'Phone').fill('312-555-7777');
  expect(await zIndex(second)).toBeGreaterThan(await zIndex(first));
  await expect(contactField(first, 'Email')).toHaveValue('first.draft@example.test');
  await expect(contactField(first, 'Phone')).toHaveValue('312-555-1002');
  await expect(contactField(second, 'Email')).toHaveValue('alex.morgan2@example.test');
  await expect(contactField(second, 'Phone')).toHaveValue('312-555-7777');
  await expect(first).toHaveAttribute('aria-label', /, unsaved changes$/u);
  await expect(page.getByTestId('status-member')).toHaveText(`Member: ${MEMBER}`);
  evidence.browser('duplicate editors keep separate drafts', { first: await first.getAttribute('aria-label'), second: await second.getAttribute('aria-label') });

  await raise(page, first);
  const start = await box(first);
  await page.mouse.move(start.x + 150, start.y + 10);
  await page.mouse.down();
  await page.mouse.move(start.x + 290, start.y + 100, { steps: 6 });
  await page.mouse.up();
  const moved = await box(first);
  expect([moved.x - start.x, moved.y - start.y, moved.width, moved.height]).toEqual([140, 90, start.width, start.height]);

  const grip = await box(first.getByTestId('resize-se'));
  await page.mouse.move(grip.x + grip.width / 2, grip.y + grip.height / 2);
  await page.mouse.down();
  await page.mouse.move(grip.x + grip.width / 2 + 120, grip.y + grip.height / 2 + 70, { steps: 6 });
  await page.mouse.up();
  const resized = await box(first);
  expect([resized.x, resized.y, resized.width - moved.width, resized.height - moved.height]).toEqual([moved.x, moved.y, 120, 70]);
  evidence.browser('drag and resize', { start, moved, resized });

  await contactField(first, 'Email').click();
  await page.keyboard.press('Alt+Shift+M');
  await expect(first).toHaveClass(/minimized/u);
  await expect(taskbar(page).getByRole('button').nth(1)).toHaveClass(/task-minimized/u);
  await taskbar(page).getByRole('button').nth(1).click();
  await expect(first).toHaveAttribute('data-active', 'true');
  await expect(contactField(first, 'Email')).toBeFocused();
  await expect(contactField(first, 'Email')).toHaveValue('first.draft@example.test');
  expect(await box(first)).toEqual(resized);

  await first.getByRole('button', { name: /^Close Member/u }).click();
  const confirm = first.getByRole('dialog', { name: 'Unsaved changes' });
  await expect(confirm).toBeVisible();
  await expect(first.locator('.window-body')).toHaveAttribute('inert', '');
  await raise(page, second);
  await contactField(second, 'Phone').fill('312-555-8888');
  await expect(contactField(second, 'Phone')).toHaveValue('312-555-8888');
  await expect(confirm).toBeVisible();
  await shot(page, info, 'window-local-modal');
  evidence.browser('window-local modal leaves other windows usable', { confirmOpenWhileEditingOther: true });

  await raise(page, first);
  await confirm.getByRole('button', { name: 'Discard changes' }).click();
  await expect(windows(page, 'member')).toHaveCount(1);
  await expect(contactField(second, 'Phone')).toHaveValue('312-555-8888');
  expect(pageErrors).toEqual([]);
});

test('stale edits are detected per record, keep the draft and resolve onto the latest version', async ({ page, desktop, evidence, pageErrors }, info) => {
  const datasetId = desktop.datasetId('northstar');
  const contacts = (): { kind: string; value: string }[] => desktop.query(
    `SELECT cp.kind, cp.value FROM contact_points cp JOIN members m ON m.dataset_id=cp.dataset_id AND m.party_id=cp.party_id
     WHERE m.dataset_id=? AND m.member_number=? AND cp.valid_to IS NULL ORDER BY cp.kind`, datasetId, MEMBER);
  await openDesktop(page, desktop.origin);
  const editor = await openMember(page, MEMBER);
  await contactField(editor, 'Phone').fill('312-555-0142');

  const account = await findAccount(page, 'AC0000001');
  await account.getByRole('form', { name: 'Account maintenance' }).getByLabel('Nickname').fill('Rainy day');
  await page.keyboard.press('Control+s');
  await expect(account.getByTestId('receipt-number')).toBeVisible();
  expect(desktop.query('SELECT nickname, version FROM accounts WHERE dataset_id=? AND account_number=?', datasetId, 'AC0000001')).toEqual([{ nickname: 'Rainy day', version: 3 }]);
  await expect(editor).toHaveAttribute('aria-label', /, unsaved changes$/u);
  await page.waitForResponse((response) => response.url().endsWith('/stamps'));
  await page.waitForResponse((response) => response.url().endsWith('/stamps'));
  await expect(editor.getByTestId('stale-banner')).toHaveCount(0);
  evidence.database('unrelated account save committed while the member draft stayed open', { nickname: 'Rainy day', contacts: contacts() });

  const other = await openMember(page, MEMBER, { newWindow: true });
  await contactField(other, 'Email').fill('alex.new@example.test');
  await page.keyboard.press('Control+s');
  await expect(other.getByTestId('receipt-number')).toBeVisible();

  const banner = editor.getByTestId('stale-banner');
  await expect(banner).toHaveText('You are editing version 2; version 3 is current. Your draft is kept and nothing was saved.');
  await expect(contactField(editor, 'Phone')).toHaveValue('312-555-0142');
  await expect(contactField(editor, 'Email')).toHaveValue('alex.morgan2@example.test');
  await raise(page, editor);
  await editor.getByRole('button', { name: 'Compare' }).click();
  const compare = editor.getByRole('dialog', { name: `Compare Member ${MEMBER}` });
  await expect(compare.locator('tr[data-field="email"] > *')).toHaveText(['Email', 'alex.morgan2@example.test', 'alex.morgan2@example.test', 'alex.new@example.test (changed)', 'Server']);
  await expect(compare.locator('tr[data-field="phone"] > *')).toHaveText(['Phone', '312-555-1002', '312-555-0142 (edited)', '312-555-1002', 'Mine']);
  await expect(compare.getByRole('radio')).toHaveCount(0);
  await shot(page, info, 'stale-compare');
  await compare.getByRole('button', { name: 'Close' }).click();
  await expect(compare).toHaveCount(0);

  await editor.getByRole('button', { name: 'Keep my edits on latest' }).click();
  await expect(banner).toHaveCount(0);
  await expect(contactField(editor, 'Email')).toHaveValue('alex.new@example.test');
  await expect(contactField(editor, 'Phone')).toHaveValue('312-555-0142');
  await contactField(editor, 'Phone').focus();
  await page.keyboard.press('Control+s');
  await expect(editor.getByTestId('receipt-number')).toBeVisible();
  await expect(editor).not.toHaveAttribute('aria-label', /unsaved changes/u);
  expect(contacts()).toEqual([{ kind: 'email', value: 'alex.new@example.test' }, { kind: 'phone', value: '312-555-0142' }]);
  expect(desktop.query('SELECT version FROM members WHERE dataset_id=? AND member_number=?', datasetId, MEMBER)).toEqual([{ version: 4 }]);
  evidence.database('both edits persisted after resolving the conflict', { contacts: contacts(), memberVersion: 4 });
  expect(pageErrors).toEqual([]);
});

test('shortcuts respect inputs, menus and dialogs and target the active window', async ({ page, desktop, evidence, pageErrors }, info) => {
  await openDesktop(page, desktop.origin);
  const menubar = page.getByRole('menubar', { name: 'Desktop menu' });
  const membersMenu = menubar.getByRole('menuitem', { name: 'Members', exact: true });
  await page.keyboard.press('F10');
  await expect(menubar.getByRole('menuitem', { name: 'Desktop', exact: true })).toBeFocused();
  await page.keyboard.press('ArrowRight');
  await expect(membersMenu).toBeFocused();
  await page.keyboard.press('Enter');
  const dropdown = page.getByRole('menu', { name: 'Members' });
  await expect(dropdown.getByRole('menuitem', { name: 'Find member…' })).toBeFocused();
  await page.keyboard.press('Alt+Shift+A');
  await expect(windows(page, 'account-search')).toHaveCount(0);
  await page.keyboard.press('Escape');
  await expect(dropdown).toHaveCount(0);
  await expect(membersMenu).toBeFocused();
  await page.keyboard.press('Escape');
  await expect(membersMenu).not.toBeFocused();

  await page.keyboard.press('Alt+Shift+F');
  const search = windows(page, 'member-search');
  const searchBox = search.getByRole('searchbox', { name: 'Search members' });
  await expect(searchBox).toBeFocused();
  await page.keyboard.type('NM/2');
  await expect(searchBox).toHaveValue('NM/2');
  await searchBox.fill(MEMBER);
  await searchBox.press('Enter');
  const row = search.getByRole('row').filter({ hasText: MEMBER });
  await row.click();
  await expect(row).toBeFocused();
  await page.keyboard.press('/');
  await expect(searchBox).toBeFocused();

  await row.click();
  await page.keyboard.press('Shift+F10');
  const context = page.locator('.context-menu').getByRole('menu');
  await expect(context.getByRole('menuitem').first()).toBeFocused();
  await page.keyboard.press('Escape');
  await expect(context).toHaveCount(0);
  await expect(row).toBeFocused();

  await page.keyboard.press('Alt+Shift+K');
  const help = page.getByRole('dialog', { name: 'Keyboard shortcuts' });
  await expect(help).toBeVisible();
  await expect(page.locator('.desktop-chrome')).toHaveAttribute('inert', '');
  await page.keyboard.press('Alt+Shift+A');
  await expect(windows(page, 'account-search')).toHaveCount(0);
  await shot(page, info, 'desktop-modal');
  await page.keyboard.press('Escape');
  await expect(help).toHaveCount(0);
  await expect(row).toBeFocused();
  evidence.browser('menus and desktop dialog suspend shortcuts and restore focus', { focusedAfterDialog: await row.getAttribute('aria-rowindex') });

  await page.keyboard.press('Alt+Shift+A');
  const accountSearch = windows(page, 'account-search');
  await expect(accountSearch).toHaveAttribute('data-active', 'true');
  await page.keyboard.press('Alt+Shift+]');
  await expect(search).toHaveAttribute('data-active', 'true');
  await page.keyboard.press('Control+s');
  await expect(page.locator('output.status-message')).toContainText('has nothing to save.');

  await page.evaluate(() => {
    Object.assign(window, { print: () => {
      const printing = [...document.querySelectorAll('section.window.printing')].map((node) => node.getAttribute('data-window-kind'));
      document.body.dataset.printed = `${printing.join(',')}|${String(document.body.classList.contains('print-one-window'))}`;
    } });
  });
  await page.keyboard.press('Control+p');
  await expect(page.locator('body')).toHaveAttribute('data-printed', 'member-search|true');

  await page.keyboard.press('Alt+Shift+W');
  await expect(search).toHaveCount(0);
  await expect(accountSearch).toHaveAttribute('data-active', 'true');
  expect(pageErrors).toEqual([]);
});
