import { existsSync } from 'node:fs';
import { join } from 'node:path';

import { verificationRunStore } from '@computer-use/financial-database/services';

import { startDesktopConsole } from '../src/server/app.js';
import { ensureTemplate } from '../test/template.js';
import { loadVerifier } from './evaluator.js';
import { bindingFor, displayedMoney, expect, findAccount, openDesktop, PUBLIC_DIRECTORY, shot, test, windows } from './fixtures.js';

test('an app-driven deposit inside an isolated verification run passes the database verifier', async ({ page, evidence, pageErrors }, info) => {
  const { startTaskRun, desktopDepositContract, desktopDepositCase: facts } = await loadVerifier();
  const template = await ensureTemplate();
  const binding = bindingFor(template.bindings, 'northstar');
  const root = info.outputPath('evaluator');
  const session = await startTaskRun({ root, sourcePath: template.path, contract: desktopDepositContract(binding) });
  const handle = await startDesktopConsole({
    store: verificationRunStore(session), bindings: [binding], mode: 'verification',
    operator: { actorNumbers: ['OP0002'], fixed: true }, principalKind: 'automation', port: 0, publicDirectory: PUBLIC_DIRECTORY,
  });
  let outputs: Record<string, unknown>;
  let requestKey: string;
  try {
    await openDesktop(page, handle.origin);
    await expect(page.getByTestId('status-operator')).toContainText('OP0002');

    const account = await findAccount(page, facts.accountNumber);
    const before = displayedMoney(await account.getByTestId('posted-balance').innerText());
    expect(before).toEqual({ minorUnits: facts.balanceBefore, currency: 'USD' });
    await expect(page.getByTestId('status-account')).toContainText(facts.accountNumber);
    evidence.browser('ui-target', { window: await account.getAttribute('aria-label'), postedBalance: before });
    await shot(page, info, 'evaluator-1-target');

    await account.getByRole('button', { name: 'Deposit…' }).click();
    const money = windows(page, 'money');
    await expect(money).toHaveAttribute('data-active', 'true');
    await expect(money.getByTestId('card-account-number')).toHaveText(facts.accountNumber);
    await money.getByLabel('Amount (USD)').fill('125.40');
    await money.getByLabel('Description').fill(facts.description);
    await money.getByRole('button', { name: 'Review cash deposit…' }).click();

    const review = money.getByRole('dialog', { name: 'Review cash deposit' });
    await expect(review.getByTestId('review-amount')).toHaveText('125.40 USD');
    requestKey = await review.getByTestId('idempotency-key').innerText();
    await shot(page, info, 'evaluator-2-review');
    await review.getByRole('button', { name: 'Post deposit' }).dblclick();

    const receiptNumber = await money.getByTestId('receipt-number').innerText();
    expect(receiptNumber).toMatch(/^RCP\d{8}$/u);
    await expect(review).toHaveCount(0);
    await money.getByRole('button', { name: `Open receipt ${receiptNumber}` }).click();
    const receipt = windows(page, 'receipt');
    await expect(receipt.getByTestId('receipt-view-number')).toHaveText(receiptNumber);
    await expect(receipt.getByRole('table').first().getByRole('row')).toHaveCount(3);
    evidence.browser('ui-receipt', { receiptNumber, requestKey, receiptWindow: await receipt.getAttribute('aria-label') });

    await expect(account.getByTestId('posted-balance')).toHaveText('6,091.54 USD');
    const after = displayedMoney(await account.getByTestId('posted-balance').innerText());
    evidence.browser('ui-outcome', { postedBalance: after });
    await shot(page, info, 'evaluator-3-outcome');
    outputs = { accountNumber: facts.accountNumber, amountMinorUnits: displayedMoney('125.40 USD').minorUnits, currency: after.currency, postedMinorUnits: after.minorUnits, receiptNumber };
    expect(pageErrors).toEqual([]);
  } finally {
    await handle.close();
  }

  const operations = session.read((database) => database.prepare('SELECT actor_id, operation_kind, status FROM operations WHERE dataset_id=? AND idempotency_key=?').all(binding.datasetId, requestKey));
  expect(operations).toEqual([{ actor_id: facts.actorId, operation_kind: 'cash.deposit', status: 'committed' }]);
  evidence.database('run still readable after the application closed', { requestKey, operations });

  const { databasePath } = session.descriptor();
  expect(existsSync(databasePath)).toBe(true);
  const reportPath = join(root, 'report.json');
  const report = await session.verify({ disposition: 'completed', outputs }, { reportPath, dispose: true });
  session.close();
  expect([existsSync(databasePath), existsSync(reportPath)]).toEqual([false, true]);
  const failing = report.checks.filter((check) => check.status !== 'pass');
  evidence.database('verifier report', { reportPath, databaseVerdict: report.databaseVerdict, checks: report.checks.length, failing, capturedBindings: report.capturedBindings });
  await info.attach('verifier-report', { path: reportPath, contentType: 'application/json' });
  expect(failing).toEqual([]);
  expect(report.databaseVerdict).toBe('pass');
});
