import { chooseMenu, expect, openMember, openDesktop, shot, test, windows } from './fixtures.js';

const pickOption = async (form: ReturnType<typeof windows>, fieldLabel: string, fieldName: string, optionText: string): Promise<void> => {
  const search = form.getByRole('searchbox', { name: `Find ${fieldLabel}` });
  await search.fill(optionText);
  const option = form.getByRole('listbox', { name: `${fieldLabel} options` }).getByRole('button', { name: new RegExp(optionText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')) });
  await expect(option.first()).toBeVisible();
  await option.first().click();
  await expect(form.getByTestId(`pick-${fieldName}`)).toBeVisible();
};

test('a hold is placed and released through the generic operations desk with bound records', async ({ page, desktop, evidence, pageErrors }, info) => {
  const datasetId = desktop.datasetId('northstar');
  await openDesktop(page, desktop.origin);

  await chooseMenu(page, 'Servicing', 'Operations catalog');
  const catalog = windows(page, 'operations');
  await catalog.getByRole('searchbox', { name: 'Filter operations' }).fill('hold');
  await catalog.getByRole('button', { name: 'Place account hold' }).click();

  const form = windows(page, 'operation');
  await pickOption(form, 'Account', 'accountId', 'AC0000001');
  await form.getByLabel('Hold amount').fill('500');
  await form.getByLabel('Reason').fill('Court order review');
  await form.getByLabel('Expires at').fill('2027-06-01T00:00:00Z');
  await form.getByLabel('Release authority').fill('legal-clearance');
  await form.getByRole('button', { name: 'Review…' }).click();

  const review = form.getByRole('dialog', { name: 'Review place account hold' });
  await expect(review.getByTestId('review-command')).toContainText('"kind": "account.hold.place"');
  await expect(review.getByTestId('idempotency-key')).toContainText('account.hold.place:');
  await shot(page, info, 'operations-hold-review');
  await review.getByRole('button', { name: 'Commit' }).click();
  await expect(form.getByTestId('receipt-number')).toBeVisible();
  const receipt = await form.getByTestId('receipt-number').innerText();
  expect(receipt).toMatch(/^RCP/);
  evidence.browser('hold placed through the generic form', { receipt });

  const holds = desktop.query<{ id: string; amount_minor_units: number; status: string }>(
    "SELECT id, amount_minor_units, status FROM holds WHERE dataset_id=? AND account_id='northstar-account-1' AND reason='Court order review'", datasetId);
  expect(holds[0]?.status).toBe('active');
  expect(holds[0]?.amount_minor_units).toBe(50000);
  evidence.database('hold row committed with exact amount', holds[0]);

  await chooseMenu(page, 'Servicing', 'Operations catalog');
  await catalog.getByRole('searchbox', { name: 'Filter operations' }).fill('release');
  await catalog.getByRole('button', { name: 'Release account hold' }).click();
  const release = windows(page, 'operation').nth(1);
  await pickOption(release, 'Scope account', '__scopeAccount', 'AC0000001');
  await pickOption(release, 'Hold', 'holdId', 'active');
  await release.getByLabel('Amount to release (minor units)').fill('50000');
  await release.getByLabel('Release authority').fill('legal-clearance');
  await release.getByLabel('Evidence reference').fill('ORDER-77');
  await release.getByRole('button', { name: 'Review…' }).click();
  const releaseReview = release.getByRole('dialog', { name: 'Review release account hold' });
  await expect(releaseReview.getByTestId('review-command')).toContainText('"expectedFingerprint"');
  await releaseReview.getByRole('button', { name: 'Commit' }).click();
  await expect(release.getByTestId('receipt-number')).toBeVisible();

  const released = desktop.query<{ status: string }>('SELECT status FROM holds WHERE dataset_id=? AND id=?', datasetId, holds[0]?.id ?? '');
  expect(released[0]?.status).toBe('released');
  evidence.database('hold released through the fingerprint-bound command', released[0]);
  expect(pageErrors).toEqual([]);
});

test('the payments desk scopes to an account and opens a fingerprinted record', async ({ page, desktop, evidence, pageErrors }, info) => {
  await openDesktop(page, desktop.origin);
  await chooseMenu(page, 'Money', 'Payments…');
  const records = windows(page, 'finance-records');
  await records.getByRole('searchbox', { name: 'Scope account' }).fill('AC0000001');
  const accountOption = records.getByRole('button', { name: /AC0000001/ });
  await expect(accountOption).toBeVisible();
  await accountOption.click();
  const grid = records.getByTestId('finance-records');
  await expect(grid.getByRole('row').nth(1)).toBeVisible();
  await grid.getByRole('button', { name: 'Open' }).first().click();

  const record = windows(page, 'finance-record');
  await expect(record.getByTestId('record-fingerprint')).toContainText(/[0-9a-f]{64}/);
  await expect(record.getByTestId('record-fields')).toContainText('northstar-');
  await shot(page, info, 'finance-record');
  evidence.browser('payment record opened with fingerprint', { fingerprint: await record.getByTestId('record-fingerprint').innerText() });
  expect(pageErrors).toEqual([]);
});

test('member servicing shows identity evidence, histories and documents for the member', async ({ page, desktop, evidence, pageErrors }, info) => {
  await openDesktop(page, desktop.origin)
  const member = await openMember(page, 'NM000001');
  await member.getByRole('button', { name: 'Servicing…' }).click();
  const servicing = windows(page, 'member-servicing');
  await expect(servicing.getByRole('tab', { name: 'Identity evidence' })).toHaveAttribute('aria-selected', 'true');
  await expect(servicing.getByRole('table')).toContainText('passport');
  await servicing.getByRole('tab', { name: 'Name history' }).click();
  await expect(servicing.getByRole('table')).toContainText('Alex');
  await servicing.getByRole('tab', { name: 'Documents' }).click();
  await expect(servicing.getByRole('table').first()).toBeVisible();
  await servicing.getByRole('tab', { name: 'Maintenance requests' }).click();
  await expect(servicing.getByRole('table')).toContainText('MR000001');
  await shot(page, info, 'member-servicing');
  evidence.browser('member servicing tabs render scoped lists', {});
  expect(pageErrors).toEqual([]);
});

test('the approvals desk lists pending and decided approvals', async ({ page, desktop, evidence, pageErrors }, info) => {
  await openDesktop(page, desktop.origin)
  await chooseMenu(page, 'Servicing', 'Approvals');
  const approvals = windows(page, 'approvals');
  await expect(approvals.getByRole('table')).toBeVisible();
  await expect(approvals.getByRole('table')).toContainText('northstar-approval');
  await shot(page, info, 'approvals');
  evidence.browser('approvals listed', {});
  expect(pageErrors).toEqual([]);
});
