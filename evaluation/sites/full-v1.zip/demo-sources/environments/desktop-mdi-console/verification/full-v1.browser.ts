import { expect, type Page } from '@playwright/test';

import {
  CATALOG, WORKFLOW_STEPS, evidencePath, populateVisibleControls, qualificationRecord, sourceSha, writeEvidence,
} from '../../../evaluation/browser-qualification.mjs';
import { OPERATIONS } from '../src/client/operations/registry.js';
import { chooseMenu, contactField, openDesktop, openMember, raise, test, windows } from './fixtures.js';

const APPLICATION_ID = 'desktop-mdi-console';
const SHARD_SIZE = 12;
const shard = (): number => Number(process.env.DESKTOP_QUAL_SHARD ?? '0');
const runId = (): string => process.env.DESKTOP_QUAL_RUN ?? `full-v1-${sourceSha().slice(0, 7)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
const command = (): string => `DESKTOP_QUAL_SHARD=${String(shard())} DESKTOP_QUAL_RUN=${runId()} npx playwright test -c verification/playwright.config.ts verification/full-v1.browser.ts`;

interface SessionProfile {
  operator: { profiles: Record<string, { commands: string[] } | null> };
}

async function signOnForCapability(page: Page, capability: string): Promise<void> {
  for (const actorNumber of ['OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0001']) {
    const session = await page.evaluate(async (candidate): Promise<SessionProfile> => {
      await fetch('/api/session/operator', {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ actorNumber: candidate }),
      });
      return fetch('/api/session').then(async (response) => response.json() as Promise<SessionProfile>);
    }, actorNumber);
    if (session.operator.profiles.northstar?.commands.includes(capability) === true) {
      await page.reload();
      await expect(page.getByTestId('status-operator')).toContainText(actorNumber);
      return;
    }
  }
  await page.evaluate(async () => {
    await fetch('/api/session/operator', {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ actorNumber: 'OP0002' }),
    });
  });
  await page.reload();
}

async function exerciseCore(page: Page, capability: string): Promise<{ entry: string; action: string; result: string }> {
  let menu = 'Members'; let item = 'Find member…'; let kind = 'member-search';
  if (capability === 'member.create') { item = 'New member…'; kind = 'member-new'; }
  else if (capability.startsWith('account.') || capability.includes('statement') || capability === 'account.list' || capability === 'transaction.search') { menu = 'Accounts'; item = capability.includes('statement') ? 'Statements and documents' : 'Find account…'; kind = capability.includes('statement') ? 'documents' : 'account-search'; }
  else if (capability === 'cash.deposit' || capability === 'cash.withdraw' || capability === 'transfer.internal' || capability === 'operation.review') { menu = 'Money'; item = capability === 'cash.withdraw' ? 'Cash withdrawal…' : capability === 'transfer.internal' ? 'Internal transfer…' : 'Cash deposit…'; kind = 'money'; }
  else if (capability.startsWith('case.') || capability === 'case.note.add') { menu = 'Servicing'; item = capability === 'case.open' ? 'New case…' : 'Case register'; kind = capability === 'case.open' ? 'case-new' : 'case-register'; }
  else if (capability.startsWith('reconciliation.') || capability === 'reconciliation.cash_day') { menu = 'Servicing'; item = 'Reconciliation'; kind = 'reconciliation'; }
  else if (capability.startsWith('batch.')) { menu = 'Servicing'; item = 'Batches'; kind = 'batches'; }
  else if (capability === 'activity.inspect') { menu = 'Servicing'; item = 'Activity and audit'; kind = 'activity'; }
  else if (capability === 'member.identity.resolve') { menu = 'Servicing'; item = 'Identity resolution…'; kind = 'identity-resolve'; }
  await chooseMenu(page, menu, item);
  const surface = windows(page, kind).last();
  await expect(surface).toBeVisible();
  const entry = await surface.innerText();
  const action = await populateVisibleControls(surface);
  const search = surface.locator('input[type="search"]:visible').first();
  if (await search.isVisible().catch(() => false)) await search.press('Enter').catch(() => undefined);
  await page.waitForTimeout(50);
  return { entry, action: action || `opened ${menu} → ${item}`, result: await surface.innerText() };
}

async function exerciseCapability(page: Page, origin: string, capability: string): Promise<{ entry: string; action: string; result: string }> {
  await openDesktop(page, origin);
  await signOnForCapability(page, capability);
  const spec = OPERATIONS.find(candidate => candidate.kind === capability);
  if (spec === undefined) return exerciseCore(page, capability);
  await chooseMenu(page, 'Servicing', 'Operations catalog');
  const catalog = windows(page, 'operations');
  await catalog.getByRole('searchbox', { name: 'Filter operations' }).fill(capability);
  await catalog.getByRole('button', { name: spec.label, exact: true }).click();
  const form = windows(page, 'operation').last();
  await expect(form).toBeVisible();
  const entry = await form.innerText();
  const action = await populateVisibleControls(form);
  await form.getByRole('button', { name: 'Review…', exact: true }).click();
  await page.waitForTimeout(50);
  return { entry, action, result: await form.innerText() };
}

test('qualifies canonical task options through populated MDI windows', async ({ page, desktop }, info) => {
  const selected = CATALOG.slice(shard() * SHARD_SIZE, (shard() + 1) * SHARD_SIZE);
  test.skip(selected.length === 0, 'empty task shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `capability-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const task of selected) {
    const observation = await exerciseCapability(page, desktop.origin, task.capability);
    records.push(qualificationRecord({
      applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${task.capability}]`, artifact,
      identity: { task: task.id, capability: task.capability, option: task.capability }, visibleEntry: observation.entry,
      action: observation.action, visibleResult: observation.result,
      businessEffect: 'The populated MDI window produced a reviewed command, record inquiry, or operation-specific visible refusal.',
      recovery: 'Independent windows keep drafts, outcomes, and record identity visible for correction or receipt recovery.',
    }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'capabilities.json', records, { shard: shard() });
});

test('qualifies workflow catalog and recovery branches through MDI windows', async ({ page, desktop }, info) => {
  const selected = Object.entries(WORKFLOW_STEPS).slice(shard() * 4, (shard() + 1) * 4);
  test.skip(selected.length === 0, 'empty workflow shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `workflow-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const [workflow, steps] of selected) {
    const results: string[] = [];
    for (const step of steps) results.push(`${step}\n${(await exerciseCapability(page, desktop.origin, step)).result}`);
    records.push(qualificationRecord({
      applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} catalog path]`, artifact,
      identity: { workflow, branch: 'catalog-path' }, visibleEntry: `Traversed ${steps.join(' → ')} through independent desktop windows.`,
      visibleResult: results.join('\n--- next visible step ---\n'), businessEffect: 'Every workflow step reached its real desk, record window, or reviewed operation form.',
      recovery: 'The taskbar and separately owned windows preserve the route back to each step.',
    }));
    const recovery = await exerciseCapability(page, desktop.origin, steps.at(-1) ?? 'activity.inspect');
    records.push(qualificationRecord({
      applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} recovery]`, artifact,
      identity: { workflow, branch: 'recovery' }, visibleEntry: `Reopened ${steps.at(-1) ?? 'activity.inspect'} in a new MDI window.`, action: recovery.action,
      visibleResult: recovery.result, businessEffect: 'The final step reopened with a fresh record snapshot or safe reviewed refusal.',
      recovery: 'The operator can compare, refresh, or close the new window without duplicating an earlier committed effect.',
    }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'workflows.json', records, { shard: shard() });
});

test('qualifies MDI family and shared-world boundaries', async ({ page, desktop }, info) => {
  test.skip(shard() !== 0, 'recorded once');
  await openDesktop(page, desktop.origin);
  await chooseMenu(page, 'Members', 'Find member…');
  await chooseMenu(page, 'Accounts', 'Find account in a new window');
  await chooseMenu(page, 'Servicing', 'Activity and audit');
  await chooseMenu(page, 'Desktop', 'Cascade windows');
  const familyArtifact = evidencePath(APPLICATION_ID, runId(), 'family-mechanism.json');
  const familyRecord = qualificationRecord({
    applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [family]`, artifact: familyArtifact,
    identity: { mechanism: 'desktop-mdi' }, visibleEntry: await page.locator('.desktop-root').innerText(),
    visibleResult: `open windows=${String(await page.locator('section.window').count())}; taskbar buttons=${String(await page.getByRole('navigation', { name: 'Open windows' }).getByRole('button').count())}`,
    businessEffect: 'Three independently owned windows were opened, cascaded, focused, and represented on the taskbar.',
    recovery: 'The taskbar and window menu restore covered or minimized work without changing its bound institution or record.',
  });
  writeEvidence(APPLICATION_ID, runId(), 'family-mechanism.json', [familyRecord]);

  const editor = await openMember(page, 'NM000002');
  await contactField(editor, 'Email').fill('held-mdi@example.test');
  const peer = await openMember(page, 'NM000002', { newWindow: true });
  await contactField(peer, 'Email').fill('peer-mdi@example.test');
  await contactField(peer, 'Phone').fill('312-555-0199');
  await page.keyboard.press('Control+s');
  await expect(peer.getByTestId('receipt-number')).toBeVisible();
  const peerResult = await peer.innerText();
  await raise(page, editor);
  await expect(editor.getByTestId('stale-banner')).toContainText(/changed|version/iu);
  const staleResult = await editor.innerText();
  await editor.getByRole('button', { name: 'Discard my edits', exact: true }).click();
  await expect(contactField(editor, 'Email')).toHaveValue('peer-mdi@example.test');
  const peerVisible = await editor.innerText();

  await chooseMenu(page, 'Members', 'Find member in a new window');
  const search = windows(page, 'member-search').last();
  const query = search.getByRole('searchbox', { name: 'Search members' });
  await query.fill('SR000001');
  await query.press('Enter');
  const isolationResult = await search.innerText();
  expect(isolationResult).not.toContain('Southridge');

  const sharedArtifact = evidencePath(APPLICATION_ID, runId(), 'shared-world.json');
  const common = { applicationId: APPLICATION_ID, runId: runId(), command: command(), artifact: sharedArtifact };
  writeEvidence(APPLICATION_ID, runId(), 'shared-world.json', [
    qualificationRecord({ ...common, test: `${info.title} [peer visibility]`, identity: { shared_world_check: 'peer_visibility' }, visibleEntry: peerResult, visibleResult: peerVisible, businessEffect: 'A peer MDI window committed a contact update that a reopened record window reread from the shared store.', recovery: 'The receipt and reopened record expose the peer effect without replaying it.' }),
    qualificationRecord({ ...common, test: `${info.title} [stale rejection]`, identity: { shared_world_check: 'stale_rejection' }, visibleEntry: 'Two member windows held different email edits from the same version.', visibleResult: staleResult, businessEffect: 'The older window displayed the explicit stale conflict after the peer saved.', recovery: 'The draft was preserved for compare/resolve rather than overwriting the peer.' }),
    qualificationRecord({ ...common, test: `${info.title} [institution isolation]`, identity: { shared_world_check: 'institution_isolation' }, visibleEntry: 'The Northstar member-search window was populated with SR000001.', visibleResult: isolationResult, businessEffect: 'No foreign-institution member was returned in the Northstar window.', recovery: 'The window retained its Northstar ownership and did not fall back across institutions.' }),
  ]);
});

test('the desktop operation registry stays structurally complete', () => {
  expect(new Set(OPERATIONS.map(operation => operation.kind)).size).toBe(OPERATIONS.length);
});
