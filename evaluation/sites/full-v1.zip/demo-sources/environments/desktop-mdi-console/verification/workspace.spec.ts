import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

import { chooseMenu, expect, findAccount, openDesktop, openMember, shot, test, windows } from './fixtures.js';

test('the member window lists the member\'s accounts and opens one', async ({ page, desktop, pageErrors }) => {
  await openDesktop(page, desktop.origin);
  const member = await openMember(page, 'NM000002');
  const grid = member.getByRole('grid', { name: 'Accounts of NM000002' });
  await expect(grid.locator('tbody tr td:first-child')).toHaveText(['AC0000001', 'AC0000002', 'LN00000002']);
  await grid.locator('tbody tr', { hasText: 'AC0000002' }).dblclick();
  const account = windows(page, 'account');
  await expect(account.locator('.record-number')).toHaveText('AC0000002');
  await expect(account.getByTestId('posted-balance')).toHaveText('4,385.27 USD');
  expect(pageErrors).toEqual([]);
});

test('transactions filter by exact reference in any letter case and by status', async ({ page, desktop, evidence, pageErrors }) => {
  const [latest] = desktop.query<{ reference: string; status: string }>(
    `SELECT j.reference, j.status FROM journals j JOIN journal_lines jl ON jl.dataset_id=j.dataset_id AND jl.journal_id=j.id
     WHERE j.dataset_id=? AND jl.ledger_account_id='northstar-customer-ledger-1' ORDER BY j.effective_date DESC, j.posted_at DESC, j.reference DESC LIMIT 1`, desktop.datasetId('northstar'));
  if (latest === undefined) throw new Error('AC0000001 has no ledger entries.');
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, 'AC0000001');
  await account.getByRole('tab', { name: 'Transactions' }).click();
  const filters = account.getByRole('form', { name: 'Transaction filters' });
  const grid = account.getByRole('grid', { name: 'Transactions for AC0000001' });
  await filters.getByLabel('Reference').fill(latest.reference.toLowerCase());
  await filters.getByRole('button', { name: 'Apply' }).click();
  await expect(grid.locator('tbody tr')).toHaveCount(1);
  await expect(grid.locator('tbody tr td').nth(1)).toHaveText(latest.reference);
  await filters.getByLabel('Status').selectOption(latest.status === 'posted' ? 'reversed' : 'posted');
  await filters.getByRole('button', { name: 'Apply' }).click();
  await expect(account.getByText('No transactions match these filters.')).toBeVisible();
  await filters.getByLabel('Status').selectOption(latest.status);
  await filters.getByRole('button', { name: 'Apply' }).click();
  await expect(grid.locator('tbody tr')).toHaveCount(1);
  evidence.browser('exact reference and status filters', latest);
  expect(pageErrors).toEqual([]);
});

test('the documents window finds stored statements, downloads the exact bytes and opens the owning account', async ({ page, desktop, evidence, pageErrors }, info) => {
  await openDesktop(page, desktop.origin);
  await chooseMenu(page, 'Accounts', 'Statements and documents');
  const documents = windows(page, 'documents');
  await documents.getByRole('searchbox', { name: 'Search documents' }).fill('AC0000001');
  await documents.getByRole('searchbox', { name: 'Search documents' }).press('Enter');
  await documents.getByRole('combobox', { name: /^Type/u }).selectOption('account-statement');
  const grid = documents.getByRole('grid', { name: 'Documents' });
  await expect(grid.locator('tbody tr')).toHaveCount(13);
  const row = grid.locator('tbody tr').first();
  await row.click();
  const digest = await row.locator('code').getAttribute('title');
  const [download] = await Promise.all([page.waitForEvent('download'), documents.getByRole('link', { name: 'Download selected' }).click()]);
  const bytes = readFileSync(await download.path());
  expect(createHash('sha256').update(bytes).digest('hex')).toBe(digest);
  const versionId = await row.getAttribute('data-key');
  expect(desktop.query('SELECT digest FROM document_versions WHERE dataset_id=? AND id=?', desktop.datasetId('northstar'), versionId ?? '')).toEqual([{ digest }]);
  evidence.database('downloaded bytes match the stored digest', { versionId, digest, byteLength: bytes.length });
  await shot(page, info, 'workspace-documents');
  await row.dblclick();
  await expect(windows(page, 'account').locator('.record-number')).toHaveText('AC0000001');
  expect(pageErrors).toEqual([]);
});

test('a supervisor corrects a case subject with versioned evidence and an exact independent approval', async ({ page, desktop, evidence, pageErrors }) => {
  const datasetId = desktop.datasetId('northstar');
  const [source] = desktop.query<{ id: string; member_id: string; version: number }>("SELECT id,member_id,version FROM cases WHERE dataset_id=? AND case_number='CS000002'", datasetId);
  if (source === undefined) throw new Error('Case CS000002 is missing.');
  await openDesktop(page, desktop.origin);
  const prerequisites = await page.evaluate(async ({ memberId }) => {
    const response = await fetch(`/api/i/northstar/servicing/case-subject-correction/${encodeURIComponent(memberId)}?correctedMemberId=northstar-member-3`);
    return await response.json() as { evidenceDocuments: { versionId: string; memberId: string }[]; approvalCheckers: { id: string; actorNumber: string }[]; policyVersions: { id: string }[] };
  }, { memberId: source.member_id });
  const evidenceVersionId = prerequisites.evidenceDocuments.find((item) => item.memberId === 'northstar-member-3')?.versionId;
  const checker = prerequisites.approvalCheckers.find((item) => item.actorNumber === 'OP0005');
  const policy = prerequisites.policyVersions[0];
  if (evidenceVersionId === undefined || checker === undefined || policy === undefined) throw new Error('Case correction prerequisites are missing.');
  const proposal = { kind: 'case.subject.correct', caseId: source.id, expectedVersion: source.version, correctMemberId: 'northstar-member-3', correctAccountId: 'northstar-account-3', evidenceVersionId, approvalId: 'pending-approval' };
  const requested = await page.evaluate(async ({ proposal: target, checkerId, policyId }) => {
    const response = await fetch('/api/i/northstar/commands', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ command: { kind: 'approval.request', target, checkerActorId: checkerId, policyVersionId: policyId, expiresAt: '2026-09-15T15:00:00.000Z', amountLimit: null }, idempotencyKey: 'desktop-browser-subject-request' }) });
    return await response.json() as { kind: string; receipt?: { affected: { kind: string; id: string }[] } };
  }, { proposal, checkerId: checker.id, policyId: policy.id });
  const approvalId = requested.receipt?.affected.find((item) => item.kind === 'approval')?.id;
  if (requested.kind !== 'committed' || approvalId === undefined) throw new Error(`Approval request failed: ${JSON.stringify(requested)}`);
  await page.evaluate(async () => { await fetch('/api/session/operator', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ actorNumber: 'OP0005' }) }); });
  const approval = await page.evaluate(async ({ memberId, approvalId: wanted }) => {
    const response = await fetch(`/api/i/northstar/servicing/case-subject-correction/${encodeURIComponent(memberId)}`);
    const body = await response.json() as { approvals: { approvals: { id: string; fingerprint: string }[] } };
    return body.approvals.approvals.find((item) => item.id === wanted) ?? null;
  }, { memberId: source.member_id, approvalId });
  if (approval === null) throw new Error('The checker cannot see the requested approval.');
  await page.evaluate(async ({ approvalId: id, fingerprint }) => {
    await fetch('/api/i/northstar/commands', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ command: { kind: 'approval.decide', approvalId: id, expectedFingerprint: fingerprint, decision: 'approve', reason: 'Exact subject correction reviewed.' }, idempotencyKey: 'desktop-browser-subject-approve' }) });
  }, { approvalId, fingerprint: approval.fingerprint });
  await page.reload();
  await chooseMenu(page, 'Servicing', 'Case register');
  const register = windows(page, 'case-register');
  await register.getByRole('searchbox', { name: 'Search cases' }).fill('CS000002');
  await register.getByRole('searchbox', { name: 'Search cases' }).press('Enter');
  await register.getByRole('combobox', { name: /^State/u }).selectOption('');
  await register.getByRole('grid', { name: 'Cases' }).locator('tbody tr', { hasText: 'CS000002' }).dblclick();
  const caseWindow = windows(page, 'case');
  await expect(caseWindow.locator('.record-number')).toHaveText('CS000002');
  await caseWindow.getByRole('button', { name: 'Correct subject with approval…' }).click();
  const correction = caseWindow.getByRole('dialog', { name: 'Correct subject of CS000002' });
  await correction.getByLabel('Correct member ID').fill('northstar-member-3');
  await correction.getByLabel('Correct account ID').fill('northstar-account-3');
  await correction.getByLabel('Evidence document version').selectOption(evidenceVersionId);
  await correction.getByLabel('Approved decision').selectOption(approvalId);
  await correction.getByRole('button', { name: 'Correct subject' }).click();
  await expect(correction).toHaveCount(0);
  await expect(caseWindow).toHaveAttribute('aria-label', /^Case CS000002 · /u);
  await expect(page.getByTestId('status-account')).toHaveText('Account: AC0000003');
  const stored = desktop.query('SELECT c.member_id,c.account_id,q.visibility FROM cases c JOIN queues q ON q.dataset_id=c.dataset_id AND q.id=c.queue_id WHERE c.dataset_id=? AND c.case_number=?', datasetId, 'CS000002');
  expect(stored).toEqual([{ member_id: 'northstar-member-3', account_id: 'northstar-account-3', visibility: 'restricted' }]);
  evidence.browser('subject correction used prerequisite evidence and approved decision', { evidenceVersionId, approvalId });
  evidence.database('case subject corrected and restricted', stored);
  expect(pageErrors).toEqual([]);
});

test('a saved member search keeps its filters, columns and result limit when reopened in a new window', async ({ page, desktop, evidence, pageErrors }) => {
  const [active] = desktop.query<{ n: number }>("SELECT COUNT(*) AS n FROM members WHERE dataset_id=? AND status='active'", desktop.datasetId('northstar'));
  await openDesktop(page, desktop.origin);
  await chooseMenu(page, 'Members', 'Find member…');
  const search = windows(page, 'member-search');
  await search.getByRole('combobox', { name: /^Status/u }).selectOption('active');
  await search.getByRole('button', { name: 'Columns…' }).click();
  const columns = search.getByRole('dialog', { name: 'Columns' });
  await columns.getByLabel('Email').uncheck();
  await columns.getByRole('button', { name: 'Apply' }).click();
  await search.getByRole('button', { name: 'Save search…' }).click();
  const save = search.getByRole('dialog', { name: 'Save search' });
  await save.getByLabel('Name').fill('Active members');
  await save.getByLabel('Result limit').fill('5');
  await save.getByRole('button', { name: 'Save search' }).click();
  await expect(save).toHaveCount(0);
  await expect(page.locator('output.status-message')).toHaveText('Saved search “Active members”.');
  await search.getByRole('button', { name: 'Close Member search' }).click();
  await expect(search).toHaveCount(0);

  await chooseMenu(page, 'Members', 'Find member…');
  await expect(search.getByRole('combobox', { name: /^Status/u })).toHaveValue('');
  await search.getByRole('combobox', { name: 'Saved searches' }).selectOption({ label: 'Active members' });
  await expect(search.getByRole('combobox', { name: /^Status/u })).toHaveValue('active');
  const headers = search.getByRole('grid', { name: 'Members' }).locator('thead th');
  await expect(headers).toHaveText(['Member ▲', 'Name', 'Type', 'Status', 'Phone', 'Open accts', 'Joined']);
  await expect(search.getByTestId('limit-hint')).toHaveText(`Limited to 5 of ${String(active?.n ?? 0)} matches`);
  await expect(search.getByRole('grid', { name: 'Members' }).locator('tbody tr')).toHaveCount(5);
  const stored = desktop.query('SELECT actor_id, visibility FROM saved_searches WHERE dataset_id=? AND name=?', desktop.datasetId('northstar'), 'Active members');
  expect(stored).toEqual([{ actor_id: 'northstar-actor-2', visibility: 'private' }]);
  evidence.database('saved search row', stored);
  expect(pageErrors).toEqual([]);
});
