import type { Page } from '@playwright/test';

import { chooseMenu, contactField, expect, findAccount, openDesktop, openMember, raise, shot, taskbar, test, windows } from './fixtures.js';

const MEMBER = 'NM000002';
const ACCOUNT = 'AC0000001';

interface Held { arrived: Promise<void>; release: () => void }

/**
 * Holds the first matching response in the browser until the test releases it. The server has already
 * answered, so this models a slow network, not a slow server. Scheduling stays in the test.
 */
async function holdResponse(page: Page, url: RegExp, method: 'GET' | 'POST'): Promise<Held> {
  let release = (): void => undefined;
  let arrive = (): void => undefined;
  const released = new Promise<void>((resolve) => { release = resolve; });
  const arrived = new Promise<void>((resolve) => { arrive = resolve; });
  let taken = false;
  await page.route(url, async (route) => {
    if (taken || route.request().method() !== method) { await route.fallback(); return; }
    taken = true;
    arrive();
    await released;
    await route.fallback();
  });
  return { arrived, release };
}

const statusMessage = (page: Page) => page.locator('output.status-message');

test('a review that returns after the operator moved on opens in its owner window without taking focus', async ({ page, desktop, evidence, pageErrors }, info) => {
  const operations = (): unknown => desktop.query('SELECT COUNT(*) AS n FROM operations WHERE dataset_id=?', desktop.datasetId('northstar'));
  const before = operations();
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, ACCOUNT);
  await account.getByRole('button', { name: 'Deposit…' }).click();
  const money = windows(page, 'money');
  await money.getByLabel('Amount (USD)').fill('10.00');
  const held = await holdResponse(page, /\/commands\/review$/u, 'POST');
  await money.getByRole('button', { name: 'Review cash deposit…' }).click();
  await held.arrived;

  await chooseMenu(page, 'Members', 'Find member…');
  const search = windows(page, 'member-search');
  const box = search.getByRole('searchbox', { name: 'Search members' });
  await box.fill('NM00000');
  held.release();

  const review = money.getByRole('dialog', { name: 'Review cash deposit' });
  await expect(review.getByTestId('review-amount')).toHaveText('10.00 USD');
  await expect(search).toHaveAttribute('data-active', 'true');
  await expect(money).toHaveAttribute('data-active', 'false');
  await expect(box).toBeFocused();
  await box.pressSequentially('2');
  await expect(box).toHaveValue('NM000002');
  evidence.browser('late review stayed in its owner', { activeWindow: await page.getByTestId('status-window').innerText() });
  await shot(page, info, 'ownership-late-review');

  await raise(page, money);
  await expect(review.getByRole('button', { name: 'Post deposit' })).toBeFocused();
  await review.getByRole('button', { name: 'Back' }).click();
  await expect(review).toHaveCount(0);
  await expect(money.locator(':focus')).toHaveCount(1);
  await expect(search.locator(':focus')).toHaveCount(0);
  expect(operations()).toEqual(before);
  expect(pageErrors).toEqual([]);
});

test('an owner waiting for a result refuses to close, and keeps its dialog through minimize and restore', async ({ page, desktop, evidence, pageErrors }) => {
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, ACCOUNT);
  await account.getByRole('form', { name: 'Account maintenance' }).getByLabel('Nickname').fill('Held save');
  const held = await holdResponse(page, /\/api\/i\/northstar\/commands$/u, 'POST');
  await account.getByRole('button', { name: 'Save changes' }).click();
  await held.arrived;

  await account.getByRole('button', { name: `Close Account ${ACCOUNT} · Reserve` }).click();
  await expect(statusMessage(page)).toHaveText(`Account ${ACCOUNT} · Reserve is waiting for a result. Close it once the result arrives.`);
  await expect(account).toHaveAttribute('aria-busy', 'true');
  await chooseMenu(page, 'Desktop', 'Close all windows…');
  await expect(statusMessage(page)).toHaveText(`Kept Account ${ACCOUNT} · Reserve open: an open dialog or a request in progress must finish first.`);
  await expect(windows(page, 'account-search')).toHaveCount(0);
  await expect(windows(page, 'account')).toHaveCount(1);
  evidence.database('the held save already committed on the server', desktop.query('SELECT nickname, version FROM accounts WHERE dataset_id=? AND account_number=?', desktop.datasetId('northstar'), ACCOUNT));

  held.release();
  await expect(account.getByTestId('receipt-number')).toBeVisible();
  await expect(account).toHaveAttribute('aria-busy', 'false');
  await account.getByRole('button', { name: `Close Account ${ACCOUNT} · Held save` }).click();
  await expect(windows(page, 'account')).toHaveCount(0);
  expect(desktop.query('SELECT nickname, version FROM accounts WHERE dataset_id=? AND account_number=?', desktop.datasetId('northstar'), ACCOUNT)).toEqual([{ nickname: 'Held save', version: 3 }]);

  const member = await openMember(page, MEMBER);
  await contactField(member, 'Email').fill('kept.draft@example.test');
  await member.getByRole('button', { name: /^Close Member NM000002/u }).click();
  const confirm = member.getByRole('dialog', { name: 'Unsaved changes' });
  await expect(confirm.getByRole('button', { name: 'Save and close' })).toBeFocused();
  await member.getByRole('button', { name: /^Minimize Member NM000002/u }).click();
  await expect(member).toHaveClass(/minimized/u);
  await taskbar(page).getByRole('button', { name: /^Member NM000002/u }).click();
  await expect(member).toHaveAttribute('data-active', 'true');
  await expect(confirm.getByRole('button', { name: 'Save and close' })).toBeFocused();
  await page.keyboard.press('Escape');
  await expect(confirm).toHaveCount(0);
  await expect(contactField(member, 'Email')).toHaveValue('kept.draft@example.test');
  expect(pageErrors).toEqual([]);
});

test('a late response for the previous record is ignored after the window switches records', async ({ page, desktop, evidence, pageErrors }) => {
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, ACCOUNT);
  const held = await holdResponse(page, /\/accounts\/northstar-account-1$/u, 'GET');
  await account.getByRole('toolbar', { name: 'Account actions' }).getByRole('button', { name: 'Refresh' }).click();
  await held.arrived;
  await account.getByLabel('Switch to another account of this member').selectOption('northstar-account-2');
  await expect(account.locator('.record-number')).toHaveText('AC0000002');
  const late = page.waitForResponse((response) => response.url().endsWith('/accounts/northstar-account-1'));
  held.release();
  await late;
  await expect(account.locator('.record-number')).toHaveText('AC0000002');
  await expect(account.getByTestId('posted-balance')).toHaveText('4,385.27 USD');
  await expect(account).toHaveAttribute('aria-label', /^Account AC0000002 · Household, /u);
  await expect(page.getByTestId('status-account')).toHaveText('Account: AC0000002');
  evidence.browser('late response ignored', { window: await account.getAttribute('aria-label') });
  expect(pageErrors).toEqual([]);
});

test('window dialogs and desktop dialogs stack: a background result waits under the desktop dialog and then takes focus in its owner', async ({ page, desktop, pageErrors }, info) => {
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, ACCOUNT);
  await account.getByRole('button', { name: 'Deposit…' }).click();
  const money = windows(page, 'money');
  await money.getByLabel('Amount (USD)').fill('12.00');
  const held = await holdResponse(page, /\/commands\/review$/u, 'POST');
  await money.getByRole('button', { name: 'Review cash deposit…' }).click();
  await held.arrived;

  await chooseMenu(page, 'Help', 'About this desktop');
  const about = page.getByRole('dialog', { name: 'About this desktop' });
  await expect(about.getByRole('button', { name: 'Close' })).toBeFocused();
  held.release();
  const review = money.getByRole('dialog', { name: 'Review cash deposit' });
  await expect(review.getByTestId('review-amount')).toHaveText('12.00 USD');
  await expect(about.getByRole('button', { name: 'Close' })).toBeFocused();
  await shot(page, info, 'ownership-stacked-dialogs');

  await page.keyboard.press('Escape');
  await expect(about).toHaveCount(0);
  await expect(review.getByRole('button', { name: 'Post deposit' })).toBeFocused();
  await page.keyboard.press('Escape');
  await expect(review).toHaveCount(0);
  await expect(money.getByLabel('Amount (USD)')).toHaveValue('12.00');
  expect(pageErrors).toEqual([]);
});

test('selection, drafts and focus survive minimize, restore, cascade and switching windows', async ({ page, desktop, pageErrors }) => {
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, ACCOUNT);
  const nickname = account.getByRole('form', { name: 'Account maintenance' }).getByLabel('Nickname');
  await nickname.fill('Draft kept');

  await chooseMenu(page, 'Members', 'Find member…');
  const search = windows(page, 'member-search');
  const box = search.getByRole('searchbox', { name: 'Search members' });
  await box.fill('NM00000');
  await box.press('Enter');
  const row = search.getByRole('grid', { name: 'Members' }).locator('tbody tr').nth(2);
  await row.click();
  await expect(row).toHaveAttribute('aria-selected', 'true');
  await expect(row).toBeFocused();
  await page.keyboard.press('Alt+Shift+M');
  await expect(search).toHaveClass(/minimized/u);
  await raise(page, search);
  await expect(row).toHaveAttribute('aria-selected', 'true');
  await expect(row).toBeFocused();

  await chooseMenu(page, 'Desktop', 'Cascade windows');
  await raise(page, account);
  await expect(nickname).toHaveValue('Draft kept');
  await expect(nickname).toBeFocused();
  await raise(page, search);
  await expect(row).toBeFocused();
  await expect(box).toHaveValue('NM00000');
  expect(pageErrors).toEqual([]);
});

test('editing one field in two windows requires an explicit choice and keeps the other window\'s unrelated change', async ({ page, desktop, evidence, pageErrors }, info) => {
  const datasetId = desktop.datasetId('northstar');
  const contacts = (): { kind: string; value: string }[] => desktop.query(
    `SELECT cp.kind, cp.value FROM contact_points cp JOIN members m ON m.dataset_id=cp.dataset_id AND m.party_id=cp.party_id
     WHERE m.dataset_id=? AND m.member_number=? AND cp.valid_to IS NULL ORDER BY cp.kind`, datasetId, MEMBER);
  await openDesktop(page, desktop.origin);
  const editor = await openMember(page, MEMBER);
  await contactField(editor, 'Email').fill('mine@example.test');
  const other = await openMember(page, MEMBER, { newWindow: true });
  await contactField(other, 'Email').fill('theirs@example.test');
  await contactField(other, 'Phone').fill('312-555-0199');
  await page.keyboard.press('Control+s');
  await expect(other.getByTestId('receipt-number')).toBeVisible();

  await raise(page, editor);
  await expect(editor.getByTestId('stale-banner')).toHaveText('You are editing version 2; version 3 is current. Your draft is kept and nothing was saved.');
  await expect(editor.getByTestId('stale-overlap')).toHaveText(' Email changed here and elsewhere. Compare and choose which value to keep.');
  await expect(editor.getByRole('button', { name: 'Keep my edits on latest' })).toHaveCount(0);
  await contactField(editor, 'Email').focus();
  await page.keyboard.press('Control+s');
  await expect(statusMessage(page)).toHaveText(`Member ${MEMBER} changed elsewhere. Resolve the conflict before saving.`);
  expect(contacts()).toEqual([{ kind: 'email', value: 'theirs@example.test' }, { kind: 'phone', value: '312-555-0199' }]);

  await editor.getByRole('button', { name: 'Compare' }).click();
  const compare = editor.getByRole('dialog', { name: `Compare Member ${MEMBER}` });
  await expect(compare.locator('tr[data-field="email"] > *').first()).toHaveText('Email');
  await expect(compare.locator('tr[data-field="phone"] > *')).toHaveText(['Phone', '312-555-1002', '312-555-1002', '312-555-0199 (changed)', 'Server']);
  const apply = compare.getByRole('button', { name: 'Apply to my draft' });
  await expect(apply).toBeDisabled();
  await compare.getByRole('group', { name: 'Keep which Email' }).getByLabel('Mine').check();
  await expect(apply).toBeEnabled();
  await shot(page, info, 'ownership-overlap-choice');
  await apply.click();
  await expect(compare).toHaveCount(0);
  await expect(editor.getByTestId('stale-banner')).toHaveCount(0);
  await expect(contactField(editor, 'Email')).toHaveValue('mine@example.test');
  await expect(contactField(editor, 'Phone')).toHaveValue('312-555-0199');
  await contactField(editor, 'Email').focus();
  await page.keyboard.press('Control+s');
  await expect(editor.getByTestId('receipt-number')).toBeVisible();
  expect(contacts()).toEqual([{ kind: 'email', value: 'mine@example.test' }, { kind: 'phone', value: '312-555-0199' }]);
  expect(desktop.query('SELECT version FROM members WHERE dataset_id=? AND member_number=?', datasetId, MEMBER)).toEqual([{ version: 4 }]);
  evidence.database('explicit choice saved, unrelated change kept', { contacts: contacts() });
  expect(pageErrors).toEqual([]);
});

test('a money review goes stale when another window posts to the same account and posts only after a fresh review', async ({ page, desktop, evidence, pageErrors }, info) => {
  const datasetId = desktop.datasetId('northstar');
  await openDesktop(page, desktop.origin);
  const account = await findAccount(page, ACCOUNT);
  await account.getByRole('button', { name: 'Deposit…' }).click();
  const deposit = windows(page, 'money').nth(0);
  await deposit.getByLabel('Amount (USD)').fill('50.00');
  await deposit.getByRole('button', { name: 'Review cash deposit…' }).click();
  const review = deposit.getByRole('dialog', { name: 'Review cash deposit' });
  await expect(review.getByTestId(`review-available-${ACCOUNT}`).locator('td')).toHaveText([ACCOUNT, '5,966.14 USD', '6,016.14 USD']);
  const key = await review.getByTestId('idempotency-key').innerText();

  await raise(page, account);
  await account.getByRole('button', { name: 'Withdrawal…' }).click();
  const withdrawal = windows(page, 'money').nth(1);
  await withdrawal.getByLabel('Amount (USD)').fill('10.00');
  await withdrawal.getByRole('button', { name: 'Review cash withdrawal…' }).click();
  const withdrawalReview = withdrawal.getByRole('dialog', { name: 'Review cash withdrawal' });
  const withdrawalKey = await withdrawalReview.getByTestId('idempotency-key').innerText();
  await withdrawalReview.getByRole('button', { name: 'Post withdrawal' }).click();
  await expect(withdrawal.getByTestId('receipt-number')).toBeVisible();

  await raise(page, deposit);
  await expect(review.getByTestId('review-stale')).toHaveText(`${ACCOUNT}: posted balance 5,966.14 USD is now 5,956.14 USD; available balance 5,966.14 USD is now 5,956.14 USD.`);
  await expect(review.getByRole('button', { name: 'Post deposit' })).toHaveCount(0);
  await shot(page, info, 'ownership-stale-review');
  await review.getByRole('button', { name: 'Review again' }).click();
  await expect(review.getByTestId('review-notice')).toHaveText('Reviewed again with current balances.');
  await expect(review.getByTestId(`review-available-${ACCOUNT}`).locator('td')).toHaveText([ACCOUNT, '5,956.14 USD', '6,006.14 USD']);
  await expect(review.getByTestId('idempotency-key')).toHaveText(key);
  await review.getByRole('button', { name: 'Post deposit' }).click();
  await expect(deposit.getByTestId('receipt-number')).toBeVisible();

  const balance = desktop.query('SELECT posted_balance_minor_units AS posted FROM account_balances WHERE dataset_id=? AND account_id=?', datasetId, 'northstar-account-1');
  const operations = desktop.query('SELECT idempotency_key AS key, operation_kind AS kind FROM operations WHERE dataset_id=? AND idempotency_key IN (?,?) ORDER BY operation_kind', datasetId, key, withdrawalKey);
  expect([balance, operations]).toEqual([[{ posted: 600614 }], [{ key, kind: 'cash.deposit' }, { key: withdrawalKey, kind: 'cash.withdraw' }]]);
  evidence.database('deposit posted once on the refreshed review', { balance, operations, key });
  expect(pageErrors).toEqual([]);
});
