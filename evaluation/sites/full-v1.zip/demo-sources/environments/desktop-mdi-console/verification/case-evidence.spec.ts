import { chooseMenu, expect, openDesktop, test, windows } from './fixtures.js';

test('a closed case reopens only with an exact current member document', async ({ page, desktop, evidence, pageErrors }) => {
  const datasetId = desktop.datasetId('northstar');
  const [document] = desktop.query<{ id: string }>(`SELECT v.id FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id
    JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id JOIN cases c ON c.dataset_id=m.dataset_id AND c.member_id=m.id
    WHERE c.dataset_id=? AND c.case_number='CS000005' AND v.status IN ('current','signed') LIMIT 1`, datasetId);
  if (document === undefined) throw new Error('Case evidence fixture is missing.');
  await openDesktop(page, desktop.origin);
  await chooseMenu(page, 'Servicing', 'Case register');
  const register = windows(page, 'case-register');
  await register.getByRole('combobox', { name: 'State', exact: true }).selectOption('closed');
  await register.getByRole('searchbox', { name: 'Search cases' }).fill('CS000005');
  await register.getByRole('searchbox', { name: 'Search cases' }).press('Enter');
  await register.getByRole('grid', { name: 'Cases' }).locator('tbody tr', { hasText: 'CS000005' }).dblclick();
  const record = windows(page, 'case');
  await record.getByRole('button', { name: 'Reopen with evidence…' }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByLabel('Reopening basis').fill('Member requests renewed review of retained statement.');
  await dialog.getByLabel('Evidence document version').fill('missing-document-version');
  await dialog.getByRole('button', { name: 'Change status', exact: true }).click();
  await expect(dialog).toContainText('Evidence is outside the case member scope or is not visible to this operator.');
  expect(desktop.query("SELECT state FROM cases WHERE dataset_id=? AND case_number='CS000005'", datasetId)).toEqual([{ state: 'closed' }]);
  await dialog.getByLabel('Evidence document version').fill(document.id);
  await dialog.getByRole('button', { name: 'Change status', exact: true }).click();
  await expect(dialog).toHaveCount(0);
  await expect(record.getByTestId('receipt-number')).toBeVisible();
  const effects = desktop.query(`SELECT c.state,d.kind,d.reference_id,d.state AS dependency_state FROM cases c JOIN case_dependencies d ON d.dataset_id=c.dataset_id AND d.case_id=c.id
    WHERE c.dataset_id=? AND c.case_number='CS000005' AND d.kind='new-evidence'`, datasetId);
  expect(effects).toEqual([{ state: 'reopened', kind: 'new-evidence', reference_id: document.id, dependency_state: 'open' }]);
  evidence.database('exact reopening evidence and new work', effects);
  evidence.browser('missing document refused; current member document accepted', document);
  expect(pageErrors).toEqual([]);
});
