import { expect, openDesktop, test, windows } from './fixtures.js';

test('workbench shows institution context, live queue and desk launchers', async ({ page, desktop, evidence, pageErrors }) => {
  await openDesktop(page, desktop.origin);
  const workbench = page.getByRole('region', { name: 'Operations workbench' });
  await expect(workbench).toBeVisible();
  await expect(workbench.getByRole('heading', { level: 1 })).toBeVisible();
  await expect(workbench.getByRole('heading', { name: 'Case work queue' })).toBeVisible();
  await expect(workbench.getByRole('heading', { name: 'Recent activity' })).toBeVisible();
  await workbench.getByRole('button', { name: 'Find member', exact: true }).click();
  await expect(windows(page, 'member-search')).toHaveCount(1);
  await expect(page.getByTestId('status-institution')).toContainText('Northstar');
  evidence.browser('active workbench and member desk launcher', { windows: await windows(page, 'member-search').count() });
  evidence.database('workbench uses live queue and activity endpoints', { institution: 'inst-northstar', pageErrors });
  expect(pageErrors).toEqual([]);
});
