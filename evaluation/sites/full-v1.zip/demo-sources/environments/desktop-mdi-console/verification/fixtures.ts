import { copyFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';

import type { DatasetBinding } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';
import { test as base, expect, type Locator, type Page, type TestInfo } from '@playwright/test';

import { startDesktopConsole } from '../src/server/app.js';
import { ensureTemplate } from '../test/template.js';

export const PUBLIC_DIRECTORY = resolve(import.meta.dirname, '..', 'dist', 'public');

export interface LaunchedDesktop {
  origin: string;
  bindings: readonly DatasetBinding[];
  datasetId: (institutionId: string) => string;
  /** Read-only query against this test's disposable copy of the template world. */
  query: <T>(sql: string, ...params: SQLInputValue[]) => T[];
}

/** Browser observations and database observations are recorded separately and written per test. */
export interface EvidenceLog {
  browser: (label: string, detail: unknown) => void;
  database: (label: string, detail: unknown) => void;
}

interface Fixtures {
  desktop: LaunchedDesktop;
  evidence: EvidenceLog;
  /** Uncaught exceptions and console errors, excluding the browser's own log line for an expected 4xx response. */
  pageErrors: string[];
}

export function bindingFor(bindings: readonly DatasetBinding[], institutionId: string): DatasetBinding {
  const binding = bindings.find((item) => item.institutionId === institutionId);
  if (binding === undefined) throw new Error(`The template world has no ${institutionId} dataset.`);
  return binding;
}

export const test = base.extend<Fixtures>({
  desktop: async ({ browserName: _browserName }, use) => {
    const template = await ensureTemplate();
    const directory = mkdtempSync(join(tmpdir(), 'desktop-mdi-verify-'));
    const path = join(directory, 'financial.sqlite');
    let handle: Awaited<ReturnType<typeof startDesktopConsole>> | undefined;
    try {
      copyFileSync(template.path, path);
      const store = openFinancialStore({ path });
      handle = await startDesktopConsole({
        store, bindings: template.bindings, mode: 'shared', operator: { actorNumbers: ['OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0001'], fixed: false },
        port: 0, publicDirectory: PUBLIC_DIRECTORY, onClose: () => { store.close(); },
      });
      await use({
        origin: handle.origin,
        bindings: template.bindings,
        datasetId: (institutionId) => bindingFor(template.bindings, institutionId).datasetId,
        query<T>(sql: string, ...params: SQLInputValue[]): T[] {
          using database = new DatabaseSync(path, { readOnly: true });
          return database.prepare(sql).all(...params) as T[];
        },
      });
    } finally {
      await handle?.close();
      rmSync(directory, { recursive: true, force: true });
    }
  },
  evidence: async ({ browserName: _browserName }, use, info) => {
    const browser: { label: string; detail: unknown }[] = [];
    const database: { label: string; detail: unknown }[] = [];
    await use({ browser: (label, detail) => { browser.push({ label, detail }); }, database: (label, detail) => { database.push({ label, detail }); } });
    const path = info.outputPath('evidence.json');
    writeFileSync(path, `${JSON.stringify({ test: info.titlePath.slice(1), status: info.status, browser, database }, null, 2)}\n`);
    await info.attach('evidence', { path, contentType: 'application/json' });
  },
  pageErrors: async ({ page }, use) => {
    const errors: string[] = [];
    page.on('pageerror', (error) => { errors.push(error.message); });
    page.on('console', (message) => { if (message.type() === 'error' && !message.text().startsWith('Failed to load resource')) errors.push(message.text()); });
    await use(errors);
  },
});

export { expect };

export async function shot(page: Page, info: TestInfo, name: string): Promise<void> {
  const path = info.outputPath(`${name}.png`);
  await page.screenshot({ path });
  await info.attach(name, { path, contentType: 'image/png' });
}

export async function openDesktop(page: Page, origin: string): Promise<void> {
  await page.goto(origin);
  await expect(page.getByRole('menubar', { name: 'Desktop menu' })).toBeVisible();
}

export async function chooseMenu(page: Page, menu: string, entry: string): Promise<void> {
  await page.getByRole('menubar', { name: 'Desktop menu' }).getByRole('menuitem', { name: menu, exact: true }).click();
  await page.getByRole('menu', { name: menu }).getByRole('menuitem', { name: entry, exact: true }).click();
}

export const windows = (page: Page, kind: string): Locator => page.locator(`section.window[data-window-kind="${kind}"]`);
export const activeWindow = (page: Page): Locator => page.locator('section.window[data-active="true"]');
export const taskbar = (page: Page): Locator => page.getByRole('navigation', { name: 'Open windows' });

/** Brings a window to the front through its taskbar button, as an operator would when it is covered. */
export async function raise(page: Page, window: Locator): Promise<void> {
  if (await window.getAttribute('data-active') === 'true') return;
  const id = await window.getAttribute('data-window-id');
  const index = await page.locator('section.window').evaluateAll((nodes, target) => nodes.findIndex((node) => node.getAttribute('data-window-id') === target), id);
  await taskbar(page).getByRole('button').nth(index).click();
  await expect(window).toHaveAttribute('data-active', 'true');
}

/** Parses the desktop's rendered money format, for example "6,091.54 USD", into exact minor units. */
export function displayedMoney(text: string): { minorUnits: number; currency: string } {
  const match = /^(-?)([\d,]+)(?:\.(\d+))?\s+([A-Z]{3})$/u.exec(text.trim());
  if (match === null) throw new Error(`Not a rendered amount: ${text}`);
  const [, sign = '', whole = '0', fraction = '', currency = ''] = match;
  const minorUnits = Number(`${whole.replaceAll(',', '')}${fraction}`);
  return { minorUnits: sign === '-' ? -minorUnits : minorUnits, currency };
}

async function openFromSearch(page: Page, kind: 'member' | 'account', value: string, newWindow: boolean): Promise<Locator> {
  const search = windows(page, `${kind}-search`);
  if (await search.count() === 0) await chooseMenu(page, kind === 'member' ? 'Members' : 'Accounts', kind === 'member' ? 'Find member…' : 'Find account…');
  else await raise(page, search);
  const box = search.getByRole('searchbox', { name: kind === 'member' ? 'Search members' : 'Search accounts' });
  await box.fill(value);
  await box.press('Enter');
  const row = search.getByRole('grid', { name: kind === 'member' ? 'Members' : 'Accounts' }).getByRole('row').filter({ hasText: value });
  await expect(row).toHaveCount(1);
  const before = await windows(page, kind).count();
  if (newWindow) {
    await row.click();
    await row.press('Shift+Enter');
  } else {
    await row.dblclick();
  }
  await expect(windows(page, kind)).toHaveCount(before + 1);
  const id = await windows(page, kind).nth(before).getAttribute('data-window-id');
  const opened = page.locator(`section.window[data-window-id="${id ?? ''}"]`);
  await expect(opened.locator('.record-number')).toHaveText(value);
  await expect(opened).toHaveAttribute('data-active', 'true');
  return opened;
}

export const findAccount = (page: Page, accountNumber: string): Promise<Locator> => openFromSearch(page, 'account', accountNumber, false);
export const findMember = (page: Page, memberNumber: string): Promise<Locator> => openFromSearch(page, 'member', memberNumber, false);
export const openMember = (page: Page, memberNumber: string, options: { newWindow?: boolean } = {}): Promise<Locator> => openFromSearch(page, 'member', memberNumber, options.newWindow ?? false);

export const contactField = (window: Locator, label: 'Email' | 'Phone'): Locator => window.getByRole('form', { name: 'Contact details' }).getByLabel(label, { exact: true });
