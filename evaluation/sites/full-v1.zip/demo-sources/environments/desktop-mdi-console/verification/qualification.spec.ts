import { join } from 'node:path';

import type { DatasetBinding } from '@computer-use/financial-database';
import { verificationRunStore } from '@computer-use/financial-database/services';
import type { Locator, Page, TestInfo } from '@playwright/test';

import { startDesktopConsole } from '../src/server/app.js';
import { ensureTemplate } from '../test/template.js';
import { loadVerifier, type VerifierReport } from './evaluator.js';
import { bindingFor, displayedMoney, expect, findAccount, openDesktop, PUBLIC_DIRECTORY, shot, test, windows, type EvidenceLog } from './fixtures.js';

const verifier = await loadVerifier();
const facts = verifier.desktopCaseFacts;

interface Submission { disposition: string; outputs: Record<string, unknown> }

/**
 * Drives one case through the rendered desktop inside its own evaluator run, then lets the evaluator
 * grade and dispose the run. The app sees only the run's store; the contract stays with the evaluator.
 */
async function qualify(page: Page, info: TestInfo, evidence: EvidenceLog, contract: (binding: DatasetBinding) => unknown, actorNumber: string, drive: () => Promise<Submission>): Promise<VerifierReport> {
  const template = await ensureTemplate();
  const binding = bindingFor(template.bindings, 'northstar');
  const root = info.outputPath('evaluator');
  const session = await verifier.startTaskRun({ root, sourcePath: template.path, contract: contract(binding) });
  let submission: Submission;
  try {
    const handle = await startDesktopConsole({
      store: verificationRunStore(session), bindings: [binding], mode: 'verification',
      operator: { actorNumbers: [actorNumber], fixed: true }, principalKind: 'automation', port: 0, publicDirectory: PUBLIC_DIRECTORY,
    });
    try {
      await openDesktop(page, handle.origin);
      await expect(page.getByTestId('status-operator')).toContainText(actorNumber);
      submission = await drive();
    } finally {
      await handle.close();
    }
    const reportPath = join(root, 'report.json');
    const report = await session.verify(submission, { reportPath, dispose: true });
    evidence.database('verifier report', { reportPath, databaseVerdict: report.databaseVerdict, overallTaskVerdict: report.overallTaskVerdict, checks: report.checks.map((check) => `${check.id}:${check.status}`) });
    await info.attach('verifier-report', { path: reportPath, contentType: 'application/json' });
    return report;
  } finally {
    session.close();
  }
}

const postedOf = async (account: Locator): Promise<number> => displayedMoney(await account.getByTestId('posted-balance').innerText()).minorUnits;

test('statement delivery change is saved, re-read after reopening and qualified by the verifier', async ({ page, evidence, pageErrors }, info) => {
  const report = await qualify(page, info, evidence, verifier.desktopStatementDeliveryContract, 'OP0002', async () => {
    const account = await findAccount(page, facts.accountNumber);
    const delivery = account.getByRole('form', { name: 'Account maintenance' }).getByLabel('Statement delivery');
    await expect(delivery).toHaveValue(facts.statementDeliveryBefore);
    await delivery.selectOption(facts.statementDelivery);
    await account.getByRole('button', { name: 'Save changes' }).click();
    const receiptNumber = await account.getByTestId('receipt-number').innerText();
    await account.getByRole('button', { name: /^Close Account/u }).click();
    await expect(windows(page, 'account')).toHaveCount(0);
    const reopened = await findAccount(page, facts.accountNumber);
    await expect(reopened.getByRole('form', { name: 'Account maintenance' }).getByLabel('Statement delivery')).toHaveValue(facts.statementDelivery);
    evidence.browser('delivery re-read after reopening', { receiptNumber, statementDelivery: facts.statementDelivery });
    await shot(page, info, 'qualify-delivery');
    return { disposition: 'completed', outputs: { accountNumber: facts.accountNumber, statementDelivery: facts.statementDelivery, receiptNumber } };
  });
  expect([report.databaseVerdict, report.checks.filter((check) => check.status !== 'pass')]).toEqual(['pass', []]);
  expect(pageErrors).toEqual([]);
});

test('a payments maker transfer between one member\'s accounts posts once and is qualified by the verifier', async ({ page, evidence, pageErrors }, info) => {
  const report = await qualify(page, info, evidence, verifier.desktopTransferContract, 'OP0003', async () => {
    const account = await findAccount(page, facts.accountNumber);
    await account.getByRole('button', { name: 'Transfer…' }).click();
    const money = windows(page, 'money');
    await expect(money.getByTestId('card-account-number')).toHaveText(facts.accountNumber);
    const destination = money.getByLabel('Destination (same member)');
    await expect(destination.locator('option')).toHaveText(['Choose an account', `${facts.siblingAccountNumber} · USD savings · USD`, 'LN00000002 · EUR loan · EUR (different currency)']);
    await destination.selectOption({ label: `${facts.siblingAccountNumber} · USD savings · USD` });
    await money.getByLabel('Amount (USD)').fill('25.00');
    await money.getByLabel('Description').fill(facts.transferDescription);
    await money.getByRole('button', { name: 'Review internal transfer…' }).click();
    const review = money.getByRole('dialog', { name: 'Review internal transfer' });
    await expect(review.getByTestId(`review-available-${facts.accountNumber}`).locator('td')).toHaveText([facts.accountNumber, '5,966.14 USD', '5,941.14 USD']);
    await expect(review.getByTestId(`review-available-${facts.siblingAccountNumber}`).locator('td')).toHaveText([facts.siblingAccountNumber, '4,385.27 USD', '4,410.27 USD']);
    await review.getByRole('button', { name: 'Post transfer' }).dblclick();
    const receiptNumber = await money.getByTestId('receipt-number').innerText();
    await expect(review).toHaveCount(0);
    await expect(account.getByTestId('posted-balance')).toHaveText('5,941.14 USD');
    const sourcePosted = await postedOf(account);
    await account.getByLabel('Switch to another account of this member').selectOption(facts.siblingAccountId);
    await expect(account.locator('.record-number')).toHaveText(facts.siblingAccountNumber);
    await expect(account.getByTestId('posted-balance')).toHaveText('4,410.27 USD');
    const destinationPosted = await postedOf(account);
    evidence.browser('balances after transfer', { receiptNumber, sourcePosted, destinationPosted });
    return { disposition: 'completed', outputs: {
      sourceAccountNumber: facts.accountNumber, destinationAccountNumber: facts.siblingAccountNumber, amountMinorUnits: displayedMoney('25.00 USD').minorUnits, currency: 'USD',
      sourcePostedMinorUnits: sourcePosted, destinationPostedMinorUnits: destinationPosted, receiptNumber,
    } };
  });
  expect([report.databaseVerdict, report.checks.filter((check) => check.status !== 'pass')]).toEqual(['pass', []]);
  expect(pageErrors).toEqual([]);
});

test('a withdrawal above the available balance is rejected at review and qualified as having no effect', async ({ page, evidence, pageErrors }, info) => {
  const report = await qualify(page, info, evidence, verifier.desktopWithdrawalRejectedContract, 'OP0002', async () => {
    const account = await findAccount(page, facts.accountNumber);
    await account.getByRole('button', { name: 'Withdrawal…' }).click();
    const money = windows(page, 'money');
    await money.getByLabel('Amount (USD)').fill('6000.00');
    await money.getByLabel('Description').fill(facts.overdraftDescription);
    await money.getByRole('button', { name: 'Review cash withdrawal…' }).click();
    await expect(money.getByText('The withdrawal exceeds the available balance.').first()).toBeVisible();
    await expect(money.getByRole('dialog')).toHaveCount(0);
    const reason = await money.getByTestId('rejection-code').getAttribute('data-code');
    await expect(account.getByTestId('posted-balance')).toHaveText('5,966.14 USD');
    const posted = await postedOf(account);
    evidence.browser('rejected before review', { reason, posted });
    await shot(page, info, 'qualify-withdrawal-rejected');
    return { disposition: 'business_rejected', outputs: { accountNumber: facts.accountNumber, reason, postedMinorUnits: posted } };
  });
  expect([report.databaseVerdict, report.checks.filter((check) => check.status !== 'pass')]).toEqual(['pass', []]);
  expect(pageErrors).toEqual([]);
});

test('a reviewed deposit abandoned at the review dialog is qualified as cancelled with no effect', async ({ page, evidence, pageErrors }, info) => {
  const report = await qualify(page, info, evidence, verifier.desktopReviewCancelledContract, 'OP0002', async () => {
    const account = await findAccount(page, facts.accountNumber);
    await account.getByRole('button', { name: 'Deposit…' }).click();
    const money = windows(page, 'money');
    await money.getByLabel('Amount (USD)').fill('50.00');
    await money.getByLabel('Description').fill(facts.reviewDescription);
    await money.getByRole('button', { name: 'Review cash deposit…' }).click();
    const review = money.getByRole('dialog', { name: 'Review cash deposit' });
    await expect(review.getByTestId('review-amount')).toHaveText('50.00 USD');
    await expect(review.getByTestId(`review-available-${facts.accountNumber}`).locator('td')).toHaveText([facts.accountNumber, '5,966.14 USD', '6,016.14 USD']);
    await review.getByRole('button', { name: 'Back' }).click();
    await expect(review).toHaveCount(0);
    await expect(money.getByLabel('Amount (USD)')).toHaveValue('50.00');
    await expect(account.getByTestId('posted-balance')).toHaveText('5,966.14 USD');
    const posted = await postedOf(account);
    evidence.browser('review closed without posting', { posted });
    return { disposition: 'cancelled', outputs: { accountNumber: facts.accountNumber, amountMinorUnits: 5000, currency: 'USD', postedMinorUnits: posted } };
  });
  expect([report.databaseVerdict, report.checks.filter((check) => check.status !== 'pass')]).toEqual(['pass', []]);
  expect(pageErrors).toEqual([]);
});

test('cancelled account edits leave the stored record as it was after reopening', async ({ page, evidence, pageErrors }, info) => {
  const report = await qualify(page, info, evidence, verifier.desktopEditCancelledContract, 'OP0002', async () => {
    const account = await findAccount(page, facts.accountNumber);
    const form = account.getByRole('form', { name: 'Account maintenance' });
    await form.getByLabel('Nickname').fill('Rainy day');
    await form.getByLabel('Statement delivery').selectOption(facts.statementDelivery);
    await expect(account).toHaveAttribute('aria-label', /, unsaved changes$/u);
    await form.getByRole('button', { name: 'Cancel edits' }).click();
    await expect(form.getByLabel('Nickname')).toHaveValue(facts.nickname);
    await expect(account).not.toHaveAttribute('aria-label', /unsaved changes/u);
    await account.getByRole('button', { name: /^Close Account/u }).click();
    await expect(windows(page, 'account')).toHaveCount(0);
    const reopened = (await findAccount(page, facts.accountNumber)).getByRole('form', { name: 'Account maintenance' });
    await expect(reopened.getByLabel('Nickname')).toHaveValue(facts.nickname);
    await expect(reopened.getByLabel('Statement delivery')).toHaveValue(facts.statementDeliveryBefore);
    evidence.browser('stored values after reopening', { nickname: facts.nickname, statementDelivery: facts.statementDeliveryBefore });
    return { disposition: 'cancelled', outputs: { accountNumber: facts.accountNumber, statementDelivery: facts.statementDeliveryBefore, nickname: facts.nickname } };
  });
  expect([report.databaseVerdict, report.checks.filter((check) => check.status !== 'pass')]).toEqual(['pass', []]);
  expect(pageErrors).toEqual([]);
});
