import { fileURLToPath } from 'node:url';
import { defineConfig } from 'vite';

export default defineConfig({
  root: fileURLToPath(new URL('src/client', import.meta.url)),
  base: '/',
  oxc: { jsx: { runtime: 'automatic' } },
  build: {
    outDir: fileURLToPath(new URL('dist/public', import.meta.url)),
    emptyOutDir: true,
    sourcemap: true,
  },
});
