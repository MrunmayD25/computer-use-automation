import { randomBytes } from 'node:crypto';
import { existsSync } from 'node:fs';
import { createServer, type Server } from 'node:http';
import { join } from 'node:path';

import type { DatasetBinding } from '@computer-use/financial-database';
import {
  authorizeQuery, CAPABILITY_GRANTS, SAVED_SEARCH_ENTITIES, SHARED_SEARCH_GRANTS, accountDetail, accountDocuments, accountTransactions, caseDetail, communicationJob, documentAnnotation, documentContent, documentTypes, executeAtomicCommandBatch, executeCommand, exportStatement, institutionSummary,
  listActivity, listApprovals, listCaseSubjectCorrectionEvidence, listDocumentAnnotations, listDocumentSignatures, listEffectivePolicyVersions, listMemberAddressDestinations, listMemberAddresses, listMemberCommunicationJobs, listMemberCommunicationPreferences,
  listMemberConsents, listMemberDocumentVersions, listMemberIdentityEvidence, listMemberMaintenanceRequests, listMemberNameHistory, listMemberRetentionHolds, listMemberTaxHistory, listSavedSearches, listServicingApprovalCheckers, listServicingQueues,
  maintenanceRequest, memberDetail, operatorProfile, queryFinance, queryMemberMergePlan, receiptByIdempotencyKey, receiptByNumber, recordStamps, referenceData, renderGeneratedStatement, resolveMemberIdentity, retrieveCustomerExportArtifact,
  retrieveHistoricalStatement, reviewCommand, searchAccounts, searchCases, searchDocuments, searchMembers, servicingCaseDetail, statementData, statementPeriods, transactionsCsv, validateServiceCommand,
  type FinanceCommandKind, type FinancialStore, type PageResult, type ServiceCommand, type ServiceContext,
  type ServicingCommandKind, type ServicingQueryResult, type SqlDatabase, type TransactionRow, type WritePrincipal,
} from '@computer-use/financial-database/services';
import express, { type NextFunction, type Request, type Response } from 'express';
import type { z } from 'zod';

import type { ApiErrorBody, InstitutionInfo, LimitedPage, OperatorChoice, OperatorInstitutionProfile, SavedSearchList, SessionInfo } from '../shared/api.js';
import {
  accountQuerySchema, activityQuerySchema, atomicBodySchema, caseQuerySchema, defined, documentQuerySchema, executeBodySchema, exportQuerySchema, historicalStatementQuerySchema, identityResolveBodySchema, idempotencyKeySchema,
  memberQuerySchema, operatorBodySchema, reviewBodySchema, savedSearchQuerySchema, stampBodySchema, statementExportBodySchema, statementQuerySchema, transactionQuerySchema,
} from './schemas.js';

export const APPLICATION_ID = 'desktop-mdi-console';
export const APPLICATION_VERSION = '0.1.0';
const MAX_EXPORT_ROWS = 10_000;
const MAX_SESSIONS = 500;
const MAX_LIST_LIMIT = 200;
/** Local handles the backend approves as statement-export destinations; bytes stream back to the caller. */
const APPROVED_EXPORT_DESTINATIONS = ['browser-download'] as const;

export interface OperatorConfig {
  /** Actor numbers allowed to sign on, resolved per institution. The first is the default. */
  actorNumbers: readonly string[];
  /** When true the backend fixes the operator and the browser cannot switch it. */
  fixed: boolean;
}

export interface DesktopConsoleOptions {
  store: FinancialStore;
  bindings: readonly DatasetBinding[];
  operator: OperatorConfig;
  mode: 'shared' | 'verification';
  /** Principal kind recorded with each write; evaluator runs normally use `automation`. */
  principalKind?: WritePrincipal['kind'];
  publicDirectory?: string;
  host?: string;
  port?: number;
  verbose?: boolean;
  /** Called when the listener stops; the shared CLI closes its store here, an evaluator keeps its run. */
  onClose?: () => void;
}

export interface DesktopConsoleHandle {
  origin: string;
  close: () => Promise<void>;
}

class HttpError extends Error {
  constructor(readonly status: number, readonly code: string, message: string, readonly field?: string) { super(message); }
}

interface UiSession {
  id: string;
  actorNumber: string;
  lastSeen: number;
}

function parse<T>(schema: z.ZodType<T>, value: unknown): T {
  const result = schema.safeParse(value);
  if (!result.success) {
    const issue = result.error.issues[0];
    throw new HttpError(400, 'invalid_request', issue === undefined ? 'The request is invalid.' : `${issue.path.join('.') || 'request'}: ${issue.message}`, issue?.path.join('.'));
  }
  return result.data;
}

function servicingValue<T>(result: ServicingQueryResult<T>): T {
  if (result.kind === 'authorized') return result.value;
  throw new HttpError(result.code === 'not_authorized' ? 403 : 400, result.code, result.message, result.field);
}

function parseCookies(header: string | undefined): Map<string, string> {
  const cookies = new Map<string, string>();
  for (const part of header?.split(';') ?? []) {
    const index = part.indexOf('=');
    if (index > 0) cookies.set(part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim()));
  }
  return cookies;
}

/** Applies an opened saved search's result limit: the total and pages stop at it instead of silently continuing. */
function limited<T>(page: PageResult<T>, maxResults: number | undefined): LimitedPage<T> {
  if (maxResults === undefined) return { ...page, limitedTo: null, matched: page.total };
  const items = page.offset >= maxResults ? [] : page.items.slice(0, maxResults - page.offset);
  return { ...page, items, total: Math.min(page.total, maxResults), limitedTo: maxResults, matched: page.total };
}

function listFrom(value: string | undefined): string[] | undefined {
  return value === undefined || value === '' ? undefined : value.split(',').map((item) => item.trim()).filter((item) => item.length > 0);
}

function contentDisposition(filename: string): string {
  return `attachment; filename="${filename.replaceAll(/[^A-Za-z0-9._-]/gu, '_')}"`;
}

/** Builds the HTTP application. Browser input selects institutions and records, never datasets or actors. */
export function createDesktopApp(options: DesktopConsoleOptions): express.Express {
  const { store } = options;
  if (options.operator.actorNumbers.length === 0) throw new Error('At least one operator actor number is required.');
  const institutions = new Map<string, { binding: DatasetBinding; info: InstitutionInfo }>();
  store.read((database) => {
    for (const binding of options.bindings) {
      const summary = institutionSummary(database, binding.datasetId);
      if (summary.institutionId !== binding.institutionId) throw new Error(`Dataset ${binding.datasetId} does not belong to ${binding.institutionId}.`);
      institutions.set(binding.institutionId, { binding, info: { institutionId: summary.institutionId, displayName: summary.displayName, legalName: summary.legalName, timeZone: summary.timeZone, defaultCurrency: summary.defaultCurrency, asOf: summary.asOf } });
    }
  });
  if (institutions.size === 0) throw new Error('At least one institution binding is required.');
  const sessions = new Map<string, UiSession>();
  const app = express();
  app.disable('x-powered-by');
  app.set('query parser', 'simple');

  if (options.verbose === true) {
    app.use((request, response, next) => {
      const started = process.hrtime.bigint();
      response.on('finish', () => console.error(`${request.method} ${request.originalUrl} ${response.statusCode} ${Number(process.hrtime.bigint() - started) / 1e6}ms`));
      next();
    });
  }
  app.use('/api', (request, response, next) => {
    response.setHeader('Cache-Control', 'no-store');
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      const origin = request.get('origin');
      if (origin !== undefined && origin !== `${request.protocol}://${request.get('host') ?? ''}`) { next(new HttpError(403, 'cross_origin', 'Cross-origin requests are not accepted.')); return; }
    }
    next();
  });
  // Command routes accept indexed document bytes, which legitimately exceed the ordinary JSON limit.
  app.use('/api/i/:institutionId/commands', express.json({ limit: '16mb' }));
  app.use('/api', express.json({ limit: '64kb' }));

  const session = (request: Request, response: Response): UiSession => {
    const cookie = parseCookies(request.get('cookie')).get('mdi_session');
    const existing = cookie === undefined ? undefined : sessions.get(cookie);
    if (existing !== undefined) { existing.lastSeen = Date.now(); return existing; }
    if (sessions.size >= MAX_SESSIONS) {
      const oldest = [...sessions.values()].sort((a, b) => a.lastSeen - b.lastSeen)[0];
      if (oldest !== undefined) sessions.delete(oldest.id);
    }
    const created: UiSession = { id: randomBytes(18).toString('base64url'), actorNumber: options.operator.actorNumbers[0] ?? '', lastSeen: Date.now() };
    sessions.set(created.id, created);
    response.setHeader('Set-Cookie', `mdi_session=${created.id}; Path=/; HttpOnly; SameSite=Strict`);
    return created;
  };

  const institution = (request: Request): { binding: DatasetBinding; info: InstitutionInfo } => {
    const found = institutions.get(String(request.params.institutionId));
    if (found === undefined) throw new HttpError(404, 'unknown_institution', 'This desktop is not bound to that institution.');
    return found;
  };

  const profile = (actorNumber: string, binding: DatasetBinding): OperatorInstitutionProfile | null => store.read((database) => {
    const found = operatorProfile(database, binding.datasetId, binding.institutionId, actorNumber);
    if (found === undefined) return null;
    const active = found.status === 'active';
    const commands = active ? Object.entries(CAPABILITY_GRANTS).filter(([, grants]) => grants.some((grant) => found.permissions.includes(grant))).map(([kind]) => kind) : [];
    const shareSearches = active && SHARED_SEARCH_GRANTS.some((grant) => found.permissions.includes(grant));
    return { actorId: found.actor.id, actorNumber: found.actor.actorNumber, displayName: found.actor.displayName, status: found.status, roles: found.roles, permissions: found.permissions, commands, shareSearches };
  });

  const actorFor = (request: Request, response: Response, binding: DatasetBinding): { actorId: string; ui: UiSession } => {
    const ui = session(request, response);
    const found = profile(ui.actorNumber, binding);
    if (found === null) throw new HttpError(403, 'operator_unavailable', `Operator ${ui.actorNumber} is not registered at this institution.`);
    return { actorId: found.actorId, ui };
  };

  const read = <T>(request: Request, query: (database: SqlDatabase, datasetId: string) => T): T => {
    const { binding } = institution(request);
    return store.read((database) => query(database, binding.datasetId));
  };

  const listLimit = (request: Request): number => {
    const raw = request.query.limit;
    if (raw === undefined) return 100;
    const value = Number(raw);
    if (!Number.isInteger(value) || value < 1 || value > MAX_LIST_LIMIT) throw new HttpError(400, 'invalid_request', 'Invalid list limit.');
    return value;
  };

  app.get('/healthz', (_request, response) => { response.json({ status: 'ok', applicationId: APPLICATION_ID }); });

  app.get('/api/session', (request, response) => {
    const ui = session(request, response);
    const choices: OperatorChoice[] = options.operator.fixed ? [] : options.operator.actorNumbers.map((actorNumber) => {
      const first = [...institutions.values()][0];
      const found = first === undefined ? null : profile(actorNumber, first.binding);
      return { actorNumber, displayName: found?.displayName ?? actorNumber, roles: found?.roles ?? [] };
    });
    const body: SessionInfo = {
      applicationId: APPLICATION_ID, applicationVersion: APPLICATION_VERSION, mode: options.mode,
      institutions: [...institutions.values()].map((entry) => entry.info),
      operator: { actorNumber: ui.actorNumber, profiles: Object.fromEntries([...institutions.values()].map((entry) => [entry.info.institutionId, profile(ui.actorNumber, entry.binding)])) },
      operatorChoices: choices,
    };
    response.json(body);
  });

  app.post('/api/session/operator', (request, response) => {
    const ui = session(request, response);
    const { actorNumber } = parse(operatorBodySchema, request.body);
    if (options.operator.fixed) throw new HttpError(403, 'operator_fixed', 'The operator for this desktop is fixed by its backend.');
    if (!options.operator.actorNumbers.includes(actorNumber)) throw new HttpError(403, 'operator_not_configured', `Operator ${actorNumber} is not configured for sign-on.`);
    ui.actorNumber = actorNumber;
    response.json({ actorNumber });
  });

  const router = express.Router({ mergeParams: true });
  app.use('/api/i/:institutionId', router);
  const documentReaders = new WeakMap<Request,{institutionId:string;actorId:string}>();
  router.use((request, response, next) => {
    const { binding } = institution(request);
    const { actorId } = actorFor(request, response, binding);
    const denied = store.read(database => authorizeQuery(database, { binding, actorId, reference: APPLICATION_ID }));
    if (denied !== null) throw new HttpError(403, denied.code, denied.message);
    documentReaders.set(request,{institutionId:binding.institutionId,actorId});
    next();
  });

  router.get('/reference', (request, response) => {
    const { binding } = institution(request);
    response.json(store.read((database) => referenceData(database, binding.datasetId, binding.institutionId)));
  });

  router.get('/members', (request, response) => {
    const { maxResults, ...query } = parse(memberQuerySchema, request.query);
    response.json(limited(read(request, (database, datasetId) => searchMembers(database, datasetId, defined(query))), maxResults));
  });

  router.get('/members/:memberId', (request, response) => {
    const detail = read(request, (database, datasetId) => memberDetail(database, datasetId, request.params.memberId, documentReader(request)));
    if (detail === undefined) throw new HttpError(404, 'not_found', 'The member does not exist at this institution.');
    response.json(detail);
  });

  router.get('/servicing/case-subject-correction/:memberId', (request, response) => {
    const context = serviceContext(request, response);
    const correctedMemberId = typeof request.query.correctedMemberId === 'string' && request.query.correctedMemberId.trim() !== '' ? request.query.correctedMemberId.trim() : request.params.memberId;
    const prerequisites = store.read((database) => ({
      ...servicingValue(listCaseSubjectCorrectionEvidence(database, context, request.params.memberId, correctedMemberId)),
      approvalCheckers: servicingValue(listServicingApprovalCheckers(database, context, 'case.subject.correct')),
      policyVersions: servicingValue(listEffectivePolicyVersions(database, context)),
    }));
    response.json({ ...prerequisites, approvals: listApprovals(store, context) });
  });

  router.get('/accounts', (request, response) => {
    const { maxResults, ...query } = parse(accountQuerySchema, request.query);
    response.json(limited(read(request, (database, datasetId) => searchAccounts(database, datasetId, defined(query))), maxResults));
  });

  router.get('/accounts/:accountId', (request, response) => {
    const detail = read(request, (database, datasetId) => accountDetail(database, datasetId, request.params.accountId));
    if (detail === undefined) throw new HttpError(404, 'not_found', 'The account does not exist at this institution.');
    response.json(detail);
  });

  router.get('/accounts/:accountId/transactions', (request, response) => {
    const query = parse(transactionQuerySchema, request.query);
    const accountId = request.params.accountId;
    const result = read(request, (database, datasetId) => accountDetail(database, datasetId, accountId) === undefined ? undefined : accountTransactions(database, datasetId, accountId, defined(query)));
    if (result === undefined) throw new HttpError(404, 'not_found', 'The account does not exist at this institution.');
    response.json(result);
  });

  router.get('/accounts/:accountId/statements', (request, response) => {
    const accountId = request.params.accountId;
    const result = read(request, (database, datasetId) => accountDetail(database, datasetId, accountId) === undefined ? undefined
      : { periods: statementPeriods(database, datasetId, accountId), documents: accountDocuments(database, datasetId, accountId, documentReader(request)) });
    if (result === undefined) throw new HttpError(404, 'not_found', 'The account does not exist at this institution.');
    response.json(result);
  });

  router.get('/accounts/:accountId/statement.pdf', async (request, response) => {
    const { period } = parse(statementQuerySchema, request.query);
    const { binding, info } = institution(request);
    const statement = store.read((database) => statementData(database, binding.datasetId, request.params.accountId, period));
    if (statement === undefined) throw new HttpError(404, 'not_found', 'The account does not exist at this institution.');
    const artifact = await renderGeneratedStatement(statement, info.asOf);
    response.setHeader('Content-Type', 'application/pdf');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${statement.account.accountNumber}-statement-${period}.pdf`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.setHeader('X-Document-Kind', 'generated-statement');
    response.end(Buffer.from(artifact.bytes));
  });

  router.get('/accounts/:accountId/transactions.csv', (request, response) => {
    const query = parse(exportQuerySchema, request.query);
    const { binding, info } = institution(request);
    const accountId = request.params.accountId;
    const result = store.read((database) => {
      const detail = accountDetail(database, binding.datasetId, accountId);
      if (detail === undefined) return undefined;
      const rows: TransactionRow[] = [];
      for (let offset = 0; ; offset += 200) {
        const page = accountTransactions(database, binding.datasetId, accountId, { ...defined(query), order: 'oldest', limit: 200, offset });
        rows.push(...page.items);
        if (rows.length > MAX_EXPORT_ROWS) throw new HttpError(413, 'export_too_large', `The export exceeds ${MAX_EXPORT_ROWS} rows; narrow the date range.`);
        if (offset + page.limit >= page.total) break;
      }
      return { detail, rows };
    });
    if (result === undefined) throw new HttpError(404, 'not_found', 'The account does not exist at this institution.');
    const artifact = transactionsCsv(result.detail.account, result.rows);
    const range = `${query.startDate ?? 'start'}_${query.endDate ?? 'now'}`;
    response.setHeader('Content-Type', 'text/csv; charset=utf-8');
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${result.detail.account.accountNumber}-transactions-${range}.csv`));
    response.setHeader('X-Document-Digest', artifact.digest);
    response.end(Buffer.from(artifact.bytes));
  });

  router.get('/documents/:versionId/content', (request, response) => {
    const { binding, info } = institution(request);
    const document = store.read((database) => documentContent(database, binding.datasetId, request.params.versionId, documentReader(request)));
    if (document === undefined) throw new HttpError(404, 'not_found', 'The document version does not exist at this institution.');
    const extension = document.mediaType === 'application/pdf' ? 'pdf' : document.mediaType === 'text/csv' ? 'csv' : document.mediaType === 'image/png' ? 'png' : 'bin';
    const base = document.displayName.replace(/\.[a-z]+$/iu, '');
    response.setHeader('Content-Type', document.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${info.institutionId}-${base}-v${document.version}.${extension}`));
    response.setHeader('X-Document-Digest', document.digest);
    response.setHeader('X-Document-Version', document.versionId);
    response.end(Buffer.from(document.bytes));
  });

  router.get('/activity', (request, response) => {
    const query = parse(activityQuerySchema, request.query);
    response.json(read(request, (database, datasetId) => listActivity(database, datasetId, defined(query))));
  });

  router.get('/receipts/:receiptNumber', (request, response) => {
    const receipt = read(request, (database, datasetId) => receiptByNumber(database, datasetId, request.params.receiptNumber));
    if (receipt === undefined) throw new HttpError(404, 'not_found', 'No receipt with that number exists at this institution.');
    response.json(receipt);
  });

  router.get('/cases', (request, response) => {
    const { states, queueIds, overdue, assignedActorId, maxResults, ...rest } = parse(caseQuerySchema, request.query);
    const stateList = listFrom(states);
    const queueList = listFrom(queueIds);
    response.json(limited(read(request, (database, datasetId) => searchCases(database, datasetId, {
      ...defined(rest),
      ...(stateList === undefined ? {} : { states: stateList }),
      ...(queueList === undefined ? {} : { queueIds: queueList }),
      ...(overdue === undefined ? {} : { overdue: overdue === 'true' }),
      ...(assignedActorId === undefined || assignedActorId === '' ? {} : { assignedActorId: assignedActorId === 'unassigned' ? null : assignedActorId }),
    })), maxResults));
  });

  router.get('/documents', (request, response) => {
    const query = parse(documentQuerySchema, request.query);
    response.json(read(request, (database, datasetId) => searchDocuments(database, datasetId, defined(query), documentReader(request))));
  });

  router.get('/document-types', (request, response) => {
    response.json(read(request, (database, datasetId) => documentTypes(database, datasetId)));
  });

  router.get('/saved-searches', (request, response) => {
    const { entity } = parse(savedSearchQuerySchema, request.query);
    const { binding } = institution(request);
    const { actorId } = actorFor(request, response, binding);
    const body: SavedSearchList = { searches: store.read((database) => listSavedSearches(database, binding.datasetId, actorId, entity)), vocabulary: SAVED_SEARCH_ENTITIES[entity] };
    response.json(body);
  });

  router.get('/operations/by-key/:idempotencyKey', (request, response) => {
    const key = parse(idempotencyKeySchema, request.params.idempotencyKey);
    const receipt = read(request, (database, datasetId) => receiptByIdempotencyKey(database, datasetId, key));
    if (receipt === undefined) throw new HttpError(404, 'not_committed', 'No operation committed under this request key.');
    response.json(receipt);
  });

  router.get('/cases/:caseId', (request, response) => {
    const detail = read(request, (database, datasetId) => caseDetail(database, datasetId, request.params.caseId, documentReader(request)));
    if (detail === undefined) throw new HttpError(404, 'not_found', 'The case does not exist at this institution.');
    response.json(detail);
  });

  router.post('/stamps', (request, response) => {
    const body = parse(stampBodySchema, request.body);
    response.json(read(request, (database, datasetId) => recordStamps(database, datasetId, defined(body))));
  });

  const documentReader = (request: Request) => { const reader=documentReaders.get(request); if(reader===undefined) throw new HttpError(403,'operator_unavailable','The request has no authorized operator.'); return reader; };

  const serviceContext = (request: Request, response: Response): Parameters<typeof executeCommand>[1] => {
    const { binding } = institution(request);
    const { actorId, ui } = actorFor(request, response, binding);
    return { binding, actorId, principalKind: options.principalKind ?? 'human', reference: `${APPLICATION_ID}:${ui.id.slice(0, 12)}` };
  };

  /**
   * Translates a wire command into a service command. `document.index` carries its content as
   * `contentBase64`/`contentText` on the wire and as immutable `bytes` inside the service boundary;
   * every other field passes through to the shared field-level validator unchanged.
   */
  const toServiceCommand = (value: unknown): ServiceCommand => {
    let candidate = value;
    if (typeof value === 'object' && value !== null && !Array.isArray(value) && Reflect.get(value, 'kind') === 'document.index') {
      const { contentBase64, contentText, ...rest } = value as Record<string, unknown>;
      let bytes: Uint8Array | undefined;
      if (typeof contentBase64 === 'string') bytes = new Uint8Array(Buffer.from(contentBase64, 'base64'));
      else if (typeof contentText === 'string') bytes = new TextEncoder().encode(contentText);
      candidate = { ...rest, ...(bytes === undefined ? {} : { bytes }) };
    }
    const invalid = validateServiceCommand(candidate);
    if (invalid !== null) throw new HttpError(400, invalid.code, invalid.message, invalid.field);
    return candidate as ServiceCommand;
  };

  router.post('/commands/review', (request, response) => {
    const { command } = parse(reviewBodySchema, request.body);
    response.json(reviewCommand(store, serviceContext(request, response), toServiceCommand(defined(command))));
  });

  router.post('/commands', (request, response) => {
    const { command, idempotencyKey } = parse(executeBodySchema, request.body);
    response.json(executeCommand(store, serviceContext(request, response), toServiceCommand(defined(command)), idempotencyKey));
  });

  router.post('/commands/atomic', (request, response) => {
    const { commands, idempotencyKey } = parse(atomicBodySchema, request.body);
    response.json(executeAtomicCommandBatch(store, serviceContext(request, response), commands.map(command => toServiceCommand(defined(command))), idempotencyKey));
  });

  router.post('/query/finance', (request, response) => {
    response.json(queryFinance(store, serviceContext(request, response), request.body));
  });

  router.get('/approvals', (request, response) => {
    response.json(listApprovals(store, serviceContext(request, response), listLimit(request)));
  });

  router.get('/merge-plans/:planId', (request, response) => {
    response.json(queryMemberMergePlan(store, serviceContext(request, response), request.params.planId));
  });

  router.post('/identity/resolve', (request, response) => {
    const context = serviceContext(request, response);
    const criteria = parse(identityResolveBodySchema, request.body);
    response.json(servicingValue(store.read(database => resolveMemberIdentity(database, context, criteria, listLimit(request)))));
  });

  const paramValue = (request: Request, name: string): string => {
    const value = request.params[name];
    return typeof value === 'string' ? value : '';
  };

  const servicingList = (param: string, fn: (database: SqlDatabase, context: ServiceContext, id: string, limit: number) => ServicingQueryResult<unknown>) => (request: Request, response: Response) => {
    const context = serviceContext(request, response);
    response.json(servicingValue(store.read(database => fn(database, context, paramValue(request, param), listLimit(request)))));
  };

  router.get('/servicing/identity-evidence/:memberId', servicingList('memberId', listMemberIdentityEvidence));
  router.get('/servicing/addresses/:memberId', servicingList('memberId', listMemberAddresses));
  router.get('/servicing/consents/:memberId', servicingList('memberId', listMemberConsents));
  router.get('/servicing/retention-holds/:memberId', servicingList('memberId', listMemberRetentionHolds));
  router.get('/servicing/preferences/:memberId', servicingList('memberId', listMemberCommunicationPreferences));
  router.get('/servicing/destinations/:memberId', servicingList('memberId', listMemberAddressDestinations));
  router.get('/servicing/maintenance-requests/:memberId', servicingList('memberId', listMemberMaintenanceRequests));
  router.get('/servicing/name-history/:memberId', servicingList('memberId', listMemberNameHistory));
  router.get('/servicing/tax-history/:memberId', servicingList('memberId', listMemberTaxHistory));
  router.get('/servicing/communication-jobs/:memberId', servicingList('memberId', listMemberCommunicationJobs));
  router.get('/servicing/annotations/:versionId', servicingList('versionId', listDocumentAnnotations));
  router.get('/servicing/signatures/:versionId', servicingList('versionId', listDocumentSignatures));

  router.get('/servicing/documents/:memberId', (request, response) => {
    const context = serviceContext(request, response);
    const documentType = typeof request.query.documentType === 'string' && request.query.documentType.trim() !== '' ? request.query.documentType.trim() : undefined;
    response.json(servicingValue(store.read(database => listMemberDocumentVersions(database, context, request.params.memberId, documentType, listLimit(request)))));
  });

  const servicingDetail = (param: string, fn: (database: SqlDatabase, context: ServiceContext, id: string, limit: number) => ServicingQueryResult<unknown>, missing: string) => (request: Request, response: Response) => {
    const context = serviceContext(request, response);
    const detail = servicingValue(store.read(database => fn(database, context, paramValue(request, param), listLimit(request))));
    if (detail === undefined) throw new HttpError(404, 'not_found', missing);
    response.json(detail);
  };

  router.get('/servicing/case-detail/:caseId', servicingDetail('caseId', servicingCaseDetail, 'The case does not exist at this institution.'));
  router.get('/servicing/maintenance-request/:requestId', servicingDetail('requestId', maintenanceRequest, 'The maintenance request does not exist at this institution.'));
  router.get('/servicing/communication-job/:jobId', servicingDetail('jobId', communicationJob, 'The communication job does not exist at this institution.'));
  router.get('/servicing/annotation/:annotationId', (request, response) => {
    const context = serviceContext(request, response);
    const detail = servicingValue(store.read(database => documentAnnotation(database, context, request.params.annotationId)));
    if (detail === undefined) throw new HttpError(404, 'not_found', 'The annotation does not exist at this institution.');
    response.json(detail);
  });

  router.get('/servicing/queues', (request, response) => {
    const context = serviceContext(request, response);
    response.json(servicingValue(store.read(database => listServicingQueues(database, context, listLimit(request)))));
  });

  router.get('/servicing/policies', (request, response) => {
    const context = serviceContext(request, response);
    response.json(servicingValue(store.read(database => listEffectivePolicyVersions(database, context, listLimit(request)))));
  });

  router.get('/servicing/checkers/:commandKind', (request, response) => {
    const context = serviceContext(request, response);
    response.json(servicingValue(store.read(database => listServicingApprovalCheckers(database, context, request.params.commandKind as ServicingCommandKind | FinanceCommandKind, listLimit(request)))));
  });

  router.post('/statements/export', async (request, response) => {
    const context = serviceContext(request, response);
    const body = parse(statementExportBodySchema, request.body);
    const result = await exportStatement(store, context, body, APPROVED_EXPORT_DESTINATIONS);
    if (result.kind !== 'artifacts') { response.json(result); return; }
    const { artifacts } = result;
    response.json({
      ...result,
      artifacts: artifacts.map(({ bytes, ...meta }, index) => ({ ...meta, format: body.formats[index] ?? 'unknown', byteLength: bytes.byteLength, contentBase64: Buffer.from(bytes).toString('base64') })),
    });
  });

  router.get('/accounts/:accountId/statements/historical', (request, response) => {
    const context = serviceContext(request, response);
    const query = parse(historicalStatementQuerySchema, request.query);
    const found = servicingValue(store.read(database => retrieveHistoricalStatement(database, context, request.params.accountId, query.periodStart, query.periodEnd, query.format)));
    if (found === undefined) throw new HttpError(404, 'not_found', 'No statement version exists for that account and period.');
    const extension = found.mediaType === 'application/pdf' ? 'pdf' : found.mediaType === 'text/csv' ? 'csv' : 'html';
    response.setHeader('Content-Type', found.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${found.accountId}-statement-${found.periodStart}-${extension}`));
    response.setHeader('X-Document-Digest', found.digest);
    response.setHeader('X-Document-Version', found.versionId);
    response.end(Buffer.from(found.bytes));
  });

  router.get('/members/:memberId/exports/:versionId', (request, response) => {
    const context = serviceContext(request, response);
    const found = servicingValue(store.read(database => retrieveCustomerExportArtifact(database, context, request.params.memberId, request.params.versionId)));
    if (found === undefined) throw new HttpError(404, 'not_found', 'The customer export artifact does not exist at this institution.');
    response.setHeader('Content-Type', found.mediaType);
    response.setHeader('Content-Disposition', contentDisposition(`${found.memberId}-customer-export-${found.versionId}.json`));
    response.setHeader('X-Document-Digest', found.digest);
    response.setHeader('X-Document-Version', found.versionId);
    response.end(Buffer.from(found.bytes));
  });

  app.use('/api', (_request, _response, next) => { next(new HttpError(404, 'not_found', 'Unknown API route.')); });

  const publicDirectory = options.publicDirectory;
  if (publicDirectory !== undefined && existsSync(join(publicDirectory, 'index.html'))) {
    app.use(express.static(publicDirectory, { index: false, maxAge: '1h', setHeaders: (response, path) => { if (path.endsWith('.html')) response.setHeader('Cache-Control', 'no-store'); } }));
    app.get('/{*path}', (_request, response) => { response.setHeader('Cache-Control', 'no-store'); response.sendFile('index.html', { root: publicDirectory }); });
  } else {
    app.get('/', (_request, response) => { response.status(503).type('text/plain').send('The desktop client is not built. Run npm run build in environments/desktop-mdi-console.'); });
  }

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    const failure = error instanceof HttpError ? error
      : error instanceof RangeError ? new HttpError(400, 'invalid_request', error.message)
        : error instanceof SyntaxError ? new HttpError(400, 'invalid_json', 'The request body is not valid JSON.')
          : new HttpError(500, 'internal_error', 'The desktop backend failed to complete the request.');
    if (failure.status === 500) console.error(error);
    const body: ApiErrorBody = { error: { code: failure.code, message: failure.message, ...(failure.field === undefined ? {} : { field: failure.field }) } };
    response.status(failure.status).json(body);
  });
  return app;
}

/**
 * Starts the desktop on a loopback listener. The caller owns the store: the CLI closes its shared
 * connection in `onClose`, while an evaluator keeps its verification run alive after the listener stops.
 */
export async function startDesktopConsole(options: DesktopConsoleOptions): Promise<DesktopConsoleHandle> {
  const app = createDesktopApp(options);
  const host = options.host ?? '127.0.0.1';
  const server: Server = createServer(app);
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(options.port ?? 4330, host, () => { server.off('error', reject); resolve(); });
  });
  const address = server.address();
  if (address === null || typeof address === 'string') throw new Error('Listener has no TCP address.');
  const origin = `http://${host}:${String(address.port)}`;
  let closing: Promise<void> | undefined;
  return {
    origin,
    close() {
      closing ??= new Promise<void>((resolve, reject) => {
        server.closeIdleConnections();
        const force = setTimeout(() => server.closeAllConnections(), 2_000);
        server.close((error) => {
          clearTimeout(force);
          try { options.onClose?.(); } catch (closeError) { reject(closeError instanceof Error ? closeError : new Error(String(closeError))); return; }
          if (error === undefined) resolve(); else reject(error);
        });
      });
      return closing;
    },
  };
}
