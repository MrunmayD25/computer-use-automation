import { z } from 'zod';

const id = z.string().min(1).max(200);

/**
 * Wire shape of a business command. The shared `validateServiceCommand` is the authoritative
 * boundary for fields, kinds and types; this schema only establishes the envelope. The
 * document.index `bytes` field cannot cross JSON, so the wire carries `contentBase64` or
 * `contentText`, translated server-side into immutable bytes before validation.
 */
export const commandSchema = z.looseObject({ kind: z.string().min(1).max(100) });

export const idempotencyKeySchema = z.string().regex(/^[A-Za-z0-9._:-]{8,128}$/u);
export const executeBodySchema = z.strictObject({ command: commandSchema, idempotencyKey: idempotencyKeySchema });
export const reviewBodySchema = z.strictObject({ command: commandSchema });
export const atomicBodySchema = z.strictObject({ commands: z.array(commandSchema).min(1).max(50), idempotencyKey: idempotencyKeySchema });
/** Field/value identity evidence submitted for resolution; the shared service scores and bounds it. */
export const identityResolveBodySchema = z.record(z.string().min(1).max(60), z.string().min(1).max(200));
export const statementExportBodySchema = z.strictObject({
  memberId: id, accountId: id,
  period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/u),
  formats: z.array(z.enum(['html', 'csv', 'pdf'])).min(1).max(3).refine(list => new Set(list).size === list.length),
  destinationId: z.string().min(1).max(200),
});
export const historicalStatementQuerySchema = z.strictObject({
  periodStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/u),
  periodEnd: z.string().regex(/^\d{4}-\d{2}-\d{2}$/u),
  format: z.enum(['application/pdf', 'text/csv', 'text/html']).optional(),
});
export const operatorBodySchema = z.strictObject({ actorNumber: z.string().regex(/^[A-Z]{2}\d{4}$/u) });
export const stampBodySchema = z.strictObject({ members: z.array(id).max(100).optional(), accounts: z.array(id).max(100).optional(), cases: z.array(id).max(100).optional() });

const limit = z.coerce.number().int().min(1).max(200).default(50);
const offset = z.coerce.number().int().min(0).max(1_000_000).default(0);
const direction = z.enum(['asc', 'desc']).optional();
const optionalText = z.string().max(200).optional();
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/u).optional();
const optionalAmount = z.coerce.number().int().min(0).max(1_000_000_000_000).optional();

/** Result limit of an opened saved search; totals and pages stop at it instead of continuing silently. */
const maxResults = z.coerce.number().int().min(1).max(10_000).optional();

export const memberQuerySchema = z.strictObject({ query: optionalText, status: optionalText, sort: optionalText, direction, limit, offset, maxResults });
export const accountQuerySchema = z.strictObject({ memberId: optionalText, query: optionalText, status: optionalText, currency: optionalText, sort: optionalText, direction, limit, offset, maxResults });
export const transactionQuerySchema = z.strictObject({
  startDate: isoDate, endDate: isoDate, direction: z.enum(['credit', 'debit']).optional(), minMinorUnits: optionalAmount, maxMinorUnits: optionalAmount,
  text: optionalText, reference: optionalText, status: z.enum(['posted', 'reversed']).optional(), order: z.enum(['newest', 'oldest']).optional(), limit, offset,
});
export const documentQuerySchema = z.strictObject({ query: optionalText, documentType: optionalText, memberId: optionalText, accountId: optionalText, sort: optionalText, direction, limit, offset });
export const savedSearchQuerySchema = z.strictObject({ entity: z.enum(['members', 'accounts', 'cases']) });
export const exportQuerySchema = z.strictObject({ startDate: isoDate, endDate: isoDate });
export const statementQuerySchema = z.strictObject({ period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/u) });
export const activityQuerySchema = z.strictObject({ memberId: optionalText, accountId: optionalText, caseId: optionalText, kind: optionalText, actorId: optionalText, query: optionalText, limit, offset });
export const caseQuerySchema = z.strictObject({
  memberId: optionalText, accountId: optionalText, states: optionalText, queueIds: optionalText, assignedActorId: optionalText, priority: optionalText,
  overdue: z.enum(['true', 'false']).optional(), query: optionalText, sort: optionalText, direction, limit, offset, maxResults,
});

/** Removes absent optional properties so parsed values satisfy exact optional property types. */
export function defined<T extends Record<string, unknown>>(value: T): { [K in keyof T]: Exclude<T[K], undefined> } {
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item !== undefined)) as { [K in keyof T]: Exclude<T[K], undefined> };
}
