/** Wire types shared by the desktop client and its backend. Business shapes come from the financial services. */

import type { PageResult, SavedSearchEntitySpec, SavedSearchRow } from '@computer-use/financial-database/services';

/** A list page; when an opened saved search limits results, `total` stops at `limitedTo` and `matched` counts every match. */
export interface LimitedPage<T> extends PageResult<T> {
  limitedTo: number | null;
  matched: number;
}

/** The operator's own and shared saved searches for one entity, with the shared field vocabulary they use. */
export interface SavedSearchList {
  searches: SavedSearchRow[];
  vocabulary: SavedSearchEntitySpec;
}

export interface InstitutionInfo {
  institutionId: string;
  displayName: string;
  legalName: string;
  timeZone: string;
  defaultCurrency: string;
  asOf: string;
}

export interface OperatorInstitutionProfile {
  actorId: string;
  actorNumber: string;
  displayName: string;
  status: string;
  roles: string[];
  permissions: string[];
  /** Command kinds this operator may run here, derived on the server from the shared capability grants. */
  commands: string[];
  /** Whether this operator may share saved searches with the institution team. */
  shareSearches: boolean;
}

export interface OperatorChoice {
  actorNumber: string;
  displayName: string;
  roles: string[];
}

export interface SessionInfo {
  applicationId: 'desktop-mdi-console';
  applicationVersion: string;
  mode: 'shared' | 'verification';
  institutions: InstitutionInfo[];
  operator: { actorNumber: string; profiles: Record<string, OperatorInstitutionProfile | null> };
  /** Configured sign-on identities; empty when the backend fixes the operator. */
  operatorChoices: OperatorChoice[];
}

export interface ApiErrorBody {
  error: { code: string; message: string; field?: string };
}
