import { useState, type ReactNode } from 'react';

import type { ActivityRow, PageResult } from '@computer-use/financial-database/services';

import { getJson, institutionPath, queryString } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands } from '../desktop/context';
import { item, separator } from '../desktop/Menu';
import { formatInstant } from '../format';
import { Grid, type Column } from '../widgets/Grid';
import { useResource } from '../widgets/useResource';

export interface ActivityScope { memberId?: string; accountId?: string; caseId?: string }

/** Committed business events, newest first, with links to receipts and records. */
export function ActivityPanel({ scope, label, revision = '' }: { scope: ActivityScope; label: string; revision?: string }): ReactNode {
  const { open } = useDesktop();
  const { institution } = useWindow();
  const institutionId = institution.institutionId;
  const [text, setText] = useState('');
  const [applied, setApplied] = useState('');
  const [page, setPage] = useState({ offset: 0, limit: 50 });
  const [selected, setSelected] = useState<string | null>(null);
  const params = { ...scope, query: applied, ...page };
  const result = useResource(() => getJson<PageResult<ActivityRow>>(institutionPath(institutionId, `/activity${queryString(params)}`)), `${JSON.stringify(params)}|${revision}`);
  const openRecord = (row: ActivityRow): void => {
    if (row.resourceKind === 'member') open(institutionId, { kind: 'member', memberId: row.resourceId });
    else if (row.resourceKind === 'account') open(institutionId, { kind: 'account', accountId: row.resourceId });
    else if (row.resourceKind === 'case') open(institutionId, { kind: 'case', caseId: row.resourceId });
  };
  const openRow = (row: ActivityRow): void => {
    if (row.receiptNumber !== null) open(institutionId, { kind: 'receipt', receiptNumber: row.receiptNumber });
    else openRecord(row);
  };
  const columns: Column<ActivityRow>[] = [
    { key: 'sequence', label: '#', width: 64, align: 'right', render: (row) => row.sequence },
    { key: 'occurred', label: 'When', width: 160, render: (row) => formatInstant(row.occurredAt, institution.timeZone) },
    { key: 'kind', label: 'Event', width: 170, render: (row) => row.kind },
    { key: 'resource', label: 'Record', width: 110, render: (row) => row.resourceKind },
    { key: 'summary', label: 'Summary', width: 300, render: (row) => row.summary },
    { key: 'actor', label: 'Operator', width: 150, render: (row) => row.actor === null ? 'system' : `${row.actor.actorNumber} · ${row.actor.displayName}` },
    { key: 'receipt', label: 'Receipt', width: 120, render: (row) => row.receiptNumber === null ? '' : (
      <button type="button" className="link" tabIndex={-1} onClick={(event) => { event.stopPropagation(); open(institutionId, { kind: 'receipt', receiptNumber: row.receiptNumber ?? '' }); }}>{row.receiptNumber}</button>
    ) },
  ];
  return (
    <div className="grid-panel">
      <form className="toolbar" role="search" aria-label={`Filter ${label}`} onSubmit={(event) => { event.preventDefault(); setApplied(text.trim()); setPage((current) => ({ ...current, offset: 0 })); }}>
        <input type="search" aria-label="Filter activity" placeholder="Event, summary or receipt" value={text} onChange={(event) => { setText(event.target.value); }} />
        <button type="submit">Filter</button>
        <span className="toolbar-spacer" />
        <button type="button" onClick={result.reload}>Refresh</button>
      </form>
      <Grid
        label={label} columns={columns} rows={result.data?.items ?? []} rowKey={(row) => String(row.sequence)} total={result.data?.total ?? 0} offset={page.offset} limit={page.limit}
        onPage={(offset) => { setPage((current) => ({ ...current, offset })); }} onLimit={(limit) => { setPage({ offset: 0, limit }); }}
        selectedKey={selected} onSelect={setSelected} onOpen={openRow}
        contextMenu={(row) => [
          item('Open receipt', () => { if (row.receiptNumber !== null) open(institutionId, { kind: 'receipt', receiptNumber: row.receiptNumber }); }, { disabled: row.receiptNumber === null }),
          separator,
          item(`Open ${row.resourceKind}`, () => { openRecord(row); }, { disabled: !['member', 'account', 'case'].includes(row.resourceKind) }),
        ]}
        loading={result.loading} error={result.error} onRetry={result.reload} empty={applied === '' ? 'No activity recorded.' : `No activity matches “${applied}”.`}
      />
    </div>
  );
}

export function ActivityWindow({ memberId, accountId, caseId, label }: { memberId: string | null; accountId: string | null; caseId: string | null; label: string }): ReactNode {
  const scope: ActivityScope = { ...(memberId === null ? {} : { memberId }), ...(accountId === null ? {} : { accountId }), ...(caseId === null ? {} : { caseId }) };
  const [revision, setRevision] = useState(0);
  useWindowChrome(`Activity · ${label}`, {}, false);
  useWindowCommands({ refresh: () => { setRevision((value) => value + 1); } });
  return <div className="grid-window"><ActivityPanel scope={scope} label={`Activity for ${label}`} revision={String(revision)} /></div>;
}
