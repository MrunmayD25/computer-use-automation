import { useCallback, useRef, useState, type ReactNode } from 'react';

import { OPERATIONS } from '../operations/registry';

import type { CommandOutcome, MemberDetail, Receipt, ReferenceData, Rejection, ServiceCommand } from '@computer-use/financial-database/services';

import { ApiError, executeCommand, getJson, institutionPath, newIdempotencyKey } from '../api';
import { useBusyWhile, useDesktop, useWindow } from '../desktop/context';
import { Dialog } from '../desktop/Dialog';
import { stampWatcher } from '../desktop/stamps';
import { formatMoney } from '../format';
import { Banner } from '../widgets/fields';
import { useResource, type Resource } from '../widgets/useResource';

const BASE_LABELS: Readonly<Record<string, string>> = {
  'member.create': 'Member created', 'contact.update': 'Contact details updated', 'member.note.add': 'Member note added', 'account.open': 'Account opened',
  'account.nickname.update': 'Nickname updated', 'account.statement_delivery.update': 'Statement delivery updated', 'account.close': 'Account closed',
  'cash.deposit': 'Cash deposit', 'cash.withdraw': 'Cash withdrawal', 'transfer.internal': 'Internal transfer', 'case.open': 'Case opened', 'case.assign': 'Case assigned',
  'case.transition': 'Case status changed', 'case.note.add': 'Case note added', 'case.subject.correct': 'Case subject corrected',
  'search.saved.create': 'Saved search created', 'search.saved.update': 'Saved search updated', 'search.saved.delete': 'Saved search deleted',
};

/** Command kind → display label: hand-tuned labels plus every registry operation's label. */
export const COMMAND_LABELS: Readonly<Record<string, string>> = {
  ...Object.fromEntries(OPERATIONS.map((op) => [op.kind, op.label])),
  ...BASE_LABELS,
};

const REJECTION_TITLES: Readonly<Record<string, string>> = {
  validation: 'Check the highlighted field.', not_found: 'Record not found.', stale_version: 'Changed by someone else.', actor_inactive: 'Operator inactive.',
  not_authorized: 'Not permitted.', ineligible: 'Not eligible.', insufficient_funds: 'Insufficient funds.', currency_mismatch: 'Currency mismatch.', same_account: 'Same account.',
  ownership_mismatch: 'Different owners.', limit_exceeded: 'Limit exceeded.', closure_blocked: 'Closure blocked.', duplicate_identity: 'Possible duplicate member.',
  duplicate_open_case: 'Duplicate open case.', account_limit_reached: 'Account limit reached.', invalid_transition: 'Status change not allowed.', open_dependencies: 'Open dependencies.',
  idempotency_conflict: 'Request key reused.',
};

export function rejectionTitle(code: string): string {
  return REJECTION_TITLES[code] ?? 'Rejected.';
}

const referenceCache = new Map<string, Promise<ReferenceData>>();

export function useReference(institutionId: string): Resource<ReferenceData> {
  return useResource(() => {
    let cached = referenceCache.get(institutionId);
    if (cached === undefined) {
      cached = getJson<ReferenceData>(institutionPath(institutionId, '/reference'));
      cached.catch(() => { referenceCache.delete(institutionId); });
      referenceCache.set(institutionId, cached);
    }
    return cached;
  }, institutionId);
}

export function exponentOf(reference: ReferenceData | undefined, currency: string): number {
  return reference?.currencies.find((entry) => entry.code === currency)?.exponent ?? 2;
}

export function Money({ minorUnits, currency, exponent }: { minorUnits: number; currency: string; exponent: number }): ReactNode {
  return <span className={`money${minorUnits < 0 ? ' negative' : ''}`}>{formatMoney(minorUnits, currency, exponent)}</span>;
}

export function StatusTag({ status }: { status: string }): ReactNode {
  return <span className={`status-tag status-${status.replaceAll(/[^a-z-]/gu, '')}`}>{status}</span>;
}

export type Committed = Extract<CommandOutcome, { kind: 'committed' | 'duplicate' }>;

export type SubmitOutcome = CommandOutcome | { kind: 'failed'; message: string };

/**
 * Runs commands for one form. A submission already in flight blocks repeats, and a retry of the
 * same command after a failed or lost response reuses its request key so it cannot apply twice.
 */
export function useSubmission(): { pending: boolean; submit: (institutionId: string, command: ServiceCommand) => Promise<SubmitOutcome | null> } {
  const [pending, setPending] = useState(false);
  useBusyWhile(pending);
  const inFlight = useRef(false);
  const last = useRef<{ json: string; key: string } | null>(null);
  const submit = useCallback(async (institutionId: string, command: ServiceCommand): Promise<SubmitOutcome | null> => {
    if (inFlight.current) return null;
    inFlight.current = true;
    setPending(true);
    const json = JSON.stringify([institutionId, command]);
    if (last.current?.json !== json) last.current = { json, key: newIdempotencyKey(command.kind) };
    try {
      const outcome = await executeCommand(institutionId, command, last.current.key);
      if (outcome.kind !== 'rejected' || outcome.code !== 'idempotency_conflict') last.current = null;
      if (outcome.kind === 'committed' || outcome.kind === 'duplicate') stampWatcher.checkSoon();
      return outcome;
    } catch (error) {
      return { kind: 'failed', message: error instanceof ApiError && error.code === 'network' ? `${error.message} Saving again resends the same request, so it cannot apply twice.` : error instanceof Error ? error.message : 'The request failed.' };
    } finally {
      inFlight.current = false;
      setPending(false);
    }
  }, []);
  return { pending, submit };
}

export function memberName(detail: MemberDetail): string {
  if (detail.person !== null) return `${detail.person.preferredName ?? detail.person.legalGiven} ${detail.person.legalFamily}`;
  return detail.organization?.legalName ?? detail.member.memberNumber;
}

/** Success, duplicate-replay or rejection feedback for the last submission in a window. */
export function OutcomeBanner({ outcome, onDismiss }: { outcome: SubmitOutcome | Rejection; onDismiss?: () => void }): ReactNode {
  const { open } = useDesktop();
  const { institution } = useWindow();
  const dismiss = onDismiss === undefined ? null : <button type="button" onClick={onDismiss}>Dismiss</button>;
  if (outcome.kind === 'committed' || outcome.kind === 'duplicate') {
    const { receipt } = outcome;
    return (
      <Banner tone="success" title={`${COMMAND_LABELS[receipt.operationKind] ?? receipt.operationKind}${outcome.kind === 'duplicate' ? ' (already recorded)' : ''}.`}
        actions={<><button type="button" onClick={() => { open(institution.institutionId, { kind: 'receipt', receiptNumber: receipt.receiptNumber }); }}>Open receipt {receipt.receiptNumber}</button>{dismiss}</>}>
        Receipt <span data-testid="receipt-number">{receipt.receiptNumber}</span> · reference {receipt.businessReference}
      </Banner>
    );
  }
  if (outcome.kind === 'unchanged') return <Banner tone="info" title="Nothing changed." actions={dismiss ?? undefined}>{outcome.message}</Banner>;
  if (outcome.kind === 'failed') return <Banner tone="warning" title="Outcome unknown." actions={dismiss ?? undefined}>{outcome.message}</Banner>;
  return <Banner tone="error" title={rejectionTitle(outcome.code)} actions={dismiss ?? undefined}><span data-testid="rejection-code" data-code={outcome.code}>{outcome.message}</span></Banner>;
}

export function receiptContext(receipt: Receipt): string {
  return receipt.affected.map((entry) => entry.label).join(', ');
}

/** Values of an edited record plus the version the edit is based on. */
export interface Versioned<T> { version: number; values: T }

interface DraftState<T> { version: number; baseline: T; draft: T }

function same<T extends Record<string, string>>(a: T, b: T): boolean {
  return Object.keys(a).every((key) => a[key] === b[key]);
}

export interface RecordDraft<T extends Record<string, string>> {
  draft: T;
  baseline: T;
  /** Version the draft was started from; sent as expectedVersion. */
  version: number;
  dirty: boolean;
  edited: (field: keyof T) => boolean;
  set: (field: keyof T, value: string) => void;
  discard: () => void;
  /**
   * Moves the draft onto the newest loaded version. Unedited fields take the server's values, so
   * concurrent changes are kept; edited fields keep the draft unless `choices` picks the server's
   * value. Returns false, changing nothing, while a field in `overlap` has no choice.
   */
  rebase: (choices?: Partial<Record<keyof T, 'mine' | 'theirs'>>) => boolean;
  /** Accepts the listed fields (default all) as saved at the version the server reported. */
  saved: (version: number, fields?: readonly (keyof T)[]) => void;
  /** Newer version known from the loaded record or the stamp watcher while edits are pending. */
  conflictVersion: number | null;
  /** Server values once a version newer than the draft's has loaded. */
  latest: T | null;
  /** Fields whose server value changed after the draft was started. */
  changedElsewhere: (keyof T)[];
  /** Fields edited here that the server now holds with a different value; each needs an explicit choice. */
  overlap: (keyof T)[];
}

/**
 * Record-scoped draft: it follows the server while untouched, keeps edits when the record
 * changes elsewhere, and reports a conflict only for a newer version of this record.
 * Resolving never takes the draft's value over a concurrent change to the same field silently.
 */
export function useRecordDraft<T extends Record<string, string>>(recordKey: string, source: Versioned<T> | undefined, stampVersion: number | undefined): RecordDraft<T> | null {
  const [state, setState] = useState<DraftState<T> | null>(null);
  const [key, setKey] = useState(recordKey);
  if (key !== recordKey) { setKey(recordKey); setState(null); }
  const fresh = (value: Versioned<T>): DraftState<T> => ({ version: value.version, baseline: value.values, draft: value.values });
  if (state !== null && source !== undefined && source.version > state.version && same(state.draft, state.baseline)) setState(fresh(source));
  const current = state ?? (source === undefined ? null : fresh(source));
  if (current === null) return null;
  const dirty = !same(current.draft, current.baseline);
  const newest = Math.max(source?.version ?? 0, stampVersion ?? 0);
  const conflictVersion = dirty && newest > current.version ? newest : null;
  const latest = source === undefined || source.version <= current.version ? null : source.values;
  const fields = Object.keys(current.baseline) as (keyof T)[];
  const changedElsewhere = latest === null ? [] : fields.filter((field) => latest[field] !== current.baseline[field]);
  const overlap = latest === null ? [] : changedElsewhere.filter((field) => current.draft[field] !== current.baseline[field] && current.draft[field] !== latest[field]);
  return {
    draft: current.draft, baseline: current.baseline, version: current.version, dirty, conflictVersion, latest, changedElsewhere, overlap,
    edited: (field) => current.draft[field] !== current.baseline[field],
    set: (field, value) => { setState({ ...current, draft: { ...current.draft, [field]: value } }); },
    discard: () => { setState(source === undefined ? null : fresh(source)); },
    rebase: (choices = {}) => {
      if (source === undefined || latest === null) return false;
      if (overlap.some((field) => choices[field] === undefined)) return false;
      const draft = { ...source.values };
      for (const field of fields) {
        if (current.draft[field] === current.baseline[field]) continue;
        if (overlap.includes(field) && choices[field] === 'theirs') continue;
        draft[field] = current.draft[field];
      }
      setState({ version: source.version, baseline: source.values, draft });
      return true;
    },
    saved: (version, fields) => {
      const baseline = { ...current.baseline };
      for (const field of fields ?? Object.keys(current.draft)) baseline[field] = current.draft[field];
      setState({ version, baseline, draft: current.draft });
    },
  };
}

/** Field-by-field comparison of the draft with the latest version, with an explicit choice for each field changed in both places. */
function CompareDialog<T extends Record<string, string>>({ subject, editor, labels, close }: { subject: string; editor: RecordDraft<T>; labels: Readonly<Record<keyof T, string>>; close: () => void }): ReactNode {
  const [choices, setChoices] = useState<Partial<Record<keyof T, 'mine' | 'theirs'>>>({});
  const unresolved = editor.overlap.filter((field) => choices[field] === undefined);
  const apply = (): void => { if (unresolved.length === 0 && editor.rebase(choices)) close(); };
  return (
    <Dialog scope="window" title={`Compare ${subject}`} onCancel={close} onSubmit={apply} width={720}
      actions={<>
        <button type="submit" className="primary" disabled={editor.latest === null || unresolved.length > 0}>Apply to my draft</button>
        <button type="button" onClick={close} data-autofocus>Close</button>
      </>}>
      <table className="compare-table">
        <thead><tr><th scope="col">Field</th><th scope="col">When you started (v{editor.version})</th><th scope="col">Your draft</th><th scope="col">Now on server</th><th scope="col">Keep</th></tr></thead>
        <tbody>
          {(Object.keys(labels) as (keyof T)[]).map((field) => {
            const mine = editor.edited(field);
            const theirs = editor.changedElsewhere.includes(field);
            const name = `keep-${String(field)}`;
            return (
              <tr key={String(field)} className={mine || theirs ? 'compare-changed' : undefined} data-field={String(field)}>
                <th scope="row">{labels[field]}</th>
                <td>{editor.baseline[field] || '—'}</td>
                <td>{editor.draft[field] || '—'}{mine ? ' (edited)' : ''}</td>
                <td>{editor.latest === null ? '…' : editor.latest[field] || '—'}{theirs ? ' (changed)' : ''}</td>
                <td>{editor.overlap.includes(field) ? (
                  <fieldset className="radio-inline" aria-label={`Keep which ${labels[field]}`}>
                    <label><input type="radio" name={name} checked={choices[field] === 'mine'} onChange={() => { setChoices({ ...choices, [field]: 'mine' }); }} /> Mine</label>
                    <label><input type="radio" name={name} checked={choices[field] === 'theirs'} onChange={() => { setChoices({ ...choices, [field]: 'theirs' }); }} /> Server</label>
                  </fieldset>
                ) : mine ? 'Mine' : theirs ? 'Server' : '—'}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {editor.latest === null ? <p className="hint">Loading the latest version…</p> : null}
    </Dialog>
  );
}

/** Stale-edit banner: the draft is kept and the operator chooses how to resolve it. */
export function ConflictBanner<T extends Record<string, string>>({ subject, editor, labels, latestLoaded, onReload }: { subject: string; editor: RecordDraft<T>; labels: Readonly<Record<keyof T, string>>; latestLoaded: boolean; onReload: () => void }): ReactNode {
  const { dialogs } = useWindow();
  if (editor.conflictVersion === null) return null;
  const compare = (): void => { dialogs.show((close) => <CompareDialog subject={subject} editor={editor} labels={labels} close={close} />); };
  const overlapping = editor.overlap.map((field) => labels[field]).join(', ');
  return (
    <Banner tone="warning" title={`${subject} changed elsewhere.`} actions={<>
      <button type="button" disabled={!latestLoaded} onClick={compare}>Compare</button>
      {editor.overlap.length === 0 ? <button type="button" disabled={!latestLoaded} onClick={() => { editor.rebase(); }}>Keep my edits on latest</button> : null}
      <button type="button" disabled={!latestLoaded} onClick={() => { editor.discard(); onReload(); }}>Discard my edits</button>
    </>}>
      <span data-testid="stale-banner">You are editing version {editor.version}; version {editor.conflictVersion} is current. Your draft is kept and nothing was saved.</span>
      {editor.overlap.length === 0 ? null : <span data-testid="stale-overlap"> {overlapping} changed here and elsewhere. Compare and choose which value to keep.</span>}
    </Banner>
  );
}

export function addDays(isoDate: string, days: number): string {
  const date = new Date(`${isoDate}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}
