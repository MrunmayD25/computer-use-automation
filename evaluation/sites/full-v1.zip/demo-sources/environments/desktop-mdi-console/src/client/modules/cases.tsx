import { useEffect, useRef, useState, type ReactNode } from 'react';

import type { CaseDetail, CaseRow, CaseSubjectCorrectionEvidenceDocument, IdentityEvidenceSummary, ServiceCommand, MemberDetail, MemberRow, PageResult, PolicyVersionSummary, ServicingApprovalCheckerSummary } from '@computer-use/financial-database/services';

import type { LimitedPage } from '../../shared/api';
import { ApiError, getJson, institutionPath, queryString } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands, type DesktopApi } from '../desktop/context';
import { Dialog } from '../desktop/Dialog';
import { item, separator, type MenuEntry } from '../desktop/Menu';
import { useRecordStamp } from '../desktop/stamps';
import { formatInstant, titleCase } from '../format';
import { Banner, DetailList, LoadFailure, Loading, SelectField, TextAreaField, TextField, Toolbar } from '../widgets/fields';
import { Grid, nextSort, type Column } from '../widgets/Grid';
import { SplitPane, Tabs } from '../widgets/layout';
import { useResource } from '../widgets/useResource';
import { ActivityPanel } from './activity';
import { addDays, ConflictBanner, memberName, OutcomeBanner, StatusTag, useRecordDraft, useReference, useSubmission, type SubmitOutcome } from './common';
import { ColumnsButton, LimitHint, listFilter, SavedSearchBar, textFilter, type SearchFilters, type SearchView } from './saved-searches';

const ACTIVE_STATES = ['open', 'pending-customer', 'pending-internal', 'reopened'];
const CASE_STATES = ['open', 'pending-customer', 'pending-internal', 'resolved', 'closed', 'reopened'];
const PRIORITIES = ['low', 'normal', 'high', 'urgent'];

export function caseColumns(timeZone: string): Column<CaseRow>[] {
  return [
    { key: 'caseNumber', label: 'Case', width: 96, sortKey: 'caseNumber', field: 'case_number', render: (row) => row.caseNumber },
    { key: 'member', label: 'Member', width: 180, sortKey: 'member', field: 'member_number', render: (row) => `${row.memberNumber} · ${row.memberName}` },
    { key: 'account', label: 'Account', width: 104, field: 'account_number', render: (row) => row.accountNumber ?? '—' },
    { key: 'category', label: 'Category', width: 150, field: 'category', render: (row) => row.categoryLabel },
    { key: 'summary', label: 'Summary', width: 240, field: 'summary', render: (row) => row.summary },
    { key: 'state', label: 'State', width: 128, sortKey: 'state', field: 'state', render: (row) => <StatusTag status={row.state} /> },
    { key: 'priority', label: 'Priority', width: 80, sortKey: 'priority', field: 'priority', render: (row) => row.priority },
    { key: 'queue', label: 'Queue', width: 140, sortKey: 'queue', field: 'queue_code', render: (row) => row.queueName },
    { key: 'assignee', label: 'Assignee', width: 140, sortKey: 'assignee', field: 'assigned_name', render: (row) => row.assignedName ?? 'Unassigned' },
    { key: 'due', label: 'Due', width: 170, sortKey: 'due', field: 'due_at', render: (row) => <span className={row.overdue ? 'overdue' : undefined}>{formatInstant(row.dueAt, timeZone)}{row.overdue ? ' · overdue' : ''}</span> },
  ];
}

/** A list filter shown as one select; a saved search that picked several values keeps them as one extra choice. */
function ListSelect({ label, value, options, anyLabel, onChange }: { label: string; value: readonly string[]; options: readonly { value: string; label: string }[]; anyLabel: string; onChange: (value: string[]) => void }): ReactNode {
  const joined = value.join(',');
  const known = joined === '' || options.some((option) => option.value === joined);
  return (
    <label>{label} <select value={joined} onChange={(event) => { onChange(event.target.value === '' ? [] : event.target.value.split(',')); }}>
      <option value="">{anyLabel}</option>
      {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      {known ? null : <option value={joined}>{value.length} selected</option>}
    </select></label>
  );
}

export function caseActions(desktop: DesktopApi, institutionId: string, row: CaseRow): MenuEntry[] {
  const { open } = desktop;
  return [
    item('Open case', () => { open(institutionId, { kind: 'case', caseId: row.id }); }),
    item('Open in new window', () => { open(institutionId, { kind: 'case', caseId: row.id }, { reuse: false }); }),
    separator,
    item(`Member ${row.memberNumber}`, () => { open(institutionId, { kind: 'member', memberId: row.memberId }); }),
    item(row.accountNumber === null ? 'No linked account' : `Account ${row.accountNumber}`, () => { if (row.accountId !== null) open(institutionId, { kind: 'account', accountId: row.accountId }); }, { disabled: row.accountId === null }),
    item('Activity', () => { open(institutionId, { kind: 'activity', memberId: null, accountId: null, caseId: row.id, label: row.caseNumber }); }),
  ];
}

export function CaseRegisterWindow(): ReactNode {
  const desktop = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const reference = useReference(institutionId);
  const me = desktop.session.operator.profiles[institutionId]?.actorId ?? '';
  const allColumns = caseColumns(win.institution.timeZone);
  const initial: SearchView = { filters: { states: ACTIVE_STATES }, sort: { key: 'due', direction: 'asc' }, visible: allColumns.map((column) => column.key), maxResults: null };
  const [text, setText] = useState('');
  const [view, setView] = useState<SearchView>(initial);
  const [page, setPage] = useState({ offset: 0, limit: 50 });
  const [selected, setSelected] = useState<string | null>(null);
  const search = useRef<HTMLInputElement>(null);
  const { filters } = view;
  const query = textFilter(filters, 'query');
  const params = {
    query, states: listFilter(filters, 'states').join(','), queueIds: listFilter(filters, 'queueIds').join(','), assignedActorId: textFilter(filters, 'assignedActorId'),
    priority: textFilter(filters, 'priority'), overdue: filters.overdue === true ? 'true' : undefined, sort: view.sort.key, direction: view.sort.direction, maxResults: view.maxResults, ...page,
  };
  const result = useResource(() => getJson<LimitedPage<CaseRow>>(institutionPath(institutionId, `/cases${queryString(params)}`)), JSON.stringify(params));
  useWindowChrome(query === '' ? 'Case register' : `Cases · “${query}”`, {}, false);
  useWindowCommands({ refresh: result.reload, focusSearch: () => { search.current?.focus(); } });
  const filter = (change: SearchFilters): void => { setView((current) => ({ ...current, filters: { ...current.filters, ...change } })); setPage((current) => ({ ...current, offset: 0 })); };
  const apply = (next: SearchView): void => { setView(next); setText(textFilter(next.filters, 'query')); setPage((current) => ({ ...current, offset: 0 })); };
  const columns = view.visible.flatMap((key) => allColumns.filter((column) => column.key === key));
  return (
    <div className="grid-window">
      <form className="toolbar" role="search" aria-label="Case search" onSubmit={(event) => { event.preventDefault(); filter({ query: text.trim() }); }}>
        <input ref={search} type="search" aria-label="Search cases" placeholder="Case #, member #, name or summary" value={text} onChange={(event) => { setText(event.target.value); }} data-autofocus />
        <button type="submit">Search</button>
        <ListSelect label="State" anyLabel="All" value={listFilter(filters, 'states')} onChange={(states) => { filter({ states }); }}
          options={[{ value: ACTIVE_STATES.join(','), label: 'Active' }, ...CASE_STATES.map((state) => ({ value: state, label: titleCase(state) }))]} />
        <ListSelect label="Queue" anyLabel="Any" value={listFilter(filters, 'queueIds')} onChange={(queueIds) => { filter({ queueIds }); }}
          options={(reference.data?.queues ?? []).map((queue) => ({ value: queue.id, label: queue.name }))} />
        <label>Assignee <select value={textFilter(filters, 'assignedActorId')} onChange={(event) => { filter({ assignedActorId: event.target.value }); }}>
          <option value="">Anyone</option>{me === '' ? null : <option value={me}>Me</option>}<option value="unassigned">Unassigned</option>
          {(reference.data?.caseWorkers ?? []).filter((worker) => worker.id !== me).map((worker) => <option key={worker.id} value={worker.id}>{worker.displayName}</option>)}
        </select></label>
        <label>Priority <select value={textFilter(filters, 'priority')} onChange={(event) => { filter({ priority: event.target.value }); }}><option value="">Any</option>{PRIORITIES.map((priority) => <option key={priority} value={priority}>{priority}</option>)}</select></label>
        <label className="checkbox"><input type="checkbox" checked={filters.overdue === true} onChange={(event) => { filter({ overdue: event.target.checked }); }} /> Overdue</label>
        <span className="toolbar-spacer" />
        <button type="button" disabled={!desktop.can(institutionId, 'case.open')} onClick={() => { desktop.open(institutionId, { kind: 'case-new', memberId: null, accountId: null }, { reuse: false }); }}>New case…</button>
        <button type="button" onClick={result.reload}>Refresh</button>
      </form>
      <div className="toolbar" role="toolbar" aria-label="Case search views">
        <SavedSearchBar entity="cases" columns={allColumns} view={view} fallback={initial} onApply={apply} />
        <ColumnsButton columns={allColumns} visible={view.visible} onChange={(visible) => { setView((current) => ({ ...current, visible })); }} />
        <LimitHint page={result.data} />
      </div>
      <Grid
        label="Cases" columns={columns} rows={result.data?.items ?? []} rowKey={(row) => row.id} total={result.data?.total ?? 0} offset={page.offset} limit={page.limit}
        onPage={(offset) => { setPage((current) => ({ ...current, offset })); }} onLimit={(limit) => { setPage({ offset: 0, limit }); }}
        sort={view.sort} onSort={(key) => { setView((current) => ({ ...current, sort: nextSort(current.sort, key) })); setPage((current) => ({ ...current, offset: 0 })); }}
        selectedKey={selected} onSelect={setSelected} onOpen={(row, newWindow) => { desktop.open(institutionId, { kind: 'case', caseId: row.id }, { reuse: !newWindow }); }}
        contextMenu={(row) => caseActions(desktop, institutionId, row)} loading={result.loading} error={result.error} onRetry={result.reload} empty="No cases match these filters."
      />
    </div>
  );
}

function TransitionDialog({ institutionId, record, toState, close, onDone }: { institutionId: string; record: CaseRow; toState: string; close: () => void; onDone: (outcome: SubmitOutcome) => void }): ReactNode {
  const [reason, setReason] = useState('');
  const [evidenceVersionId, setEvidenceVersionId] = useState('');
  const requiresEvidence = toState === 'closed' || toState === 'reopened';
  const [error, setError] = useState<string | undefined>(undefined);
  const [result, setResult] = useState<SubmitOutcome | null>(null);
  const submission = useSubmission();
  const submit = async (): Promise<void> => {
    if (reason.trim() === '') { setError('Enter the reason for the status change.'); return; }
    if (requiresEvidence && evidenceVersionId.trim() === '') { setError('Enter the current member document version.'); return; }
    const command: ServiceCommand = toState === 'closed'
      ? { kind: 'case.close', caseId: record.id, expectedVersion: record.version, resolutionCode: reason.trim(), effectEvidenceVersionId: evidenceVersionId.trim() }
      : toState === 'reopened'
        ? { kind: 'case.reopen', caseId: record.id, expectedVersion: record.version, reopeningBasis: reason.trim(), evidenceVersionId: evidenceVersionId.trim() }
        : { kind: 'case.transition', caseId: record.id, expectedVersion: record.version, toState: toState as 'open', reason: reason.trim() };
    const outcome = await submission.submit(institutionId, command);
    if (outcome === null) return;
    if (outcome.kind === 'committed' || outcome.kind === 'duplicate') { close(); onDone(outcome); } else setResult(outcome);
  };
  return (
    <Dialog scope="window" title={`Change ${record.caseNumber} to ${titleCase(toState)}`} busy={submission.pending} onCancel={close} onSubmit={() => { void submit(); }}
      actions={<><button type="submit" className="primary" disabled={submission.pending}>{submission.pending ? 'Saving…' : 'Change status'}</button><button type="button" onClick={close} disabled={submission.pending}>Cancel</button></>}>
      <p><StatusTag status={record.state} /> → <StatusTag status={toState} /></p>
      <TextAreaField label={toState === 'closed' ? 'Resolution code' : toState === 'reopened' ? 'Reopening basis' : 'Reason'} value={reason} onChange={(value) => { setReason(value); setError(undefined); }} error={error} required maxLength={500} rows={3} />
      {requiresEvidence ? <TextField label="Evidence document version" value={evidenceVersionId} onChange={setEvidenceVersionId} required /> : null}
      {toState === 'reopened' ? <p>Creates a new evidence work item due in seven days.</p> : null}
      {result === null ? null : <OutcomeBanner outcome={result} />}
    </Dialog>
  );
}

interface CaseSubjectCorrectionPrerequisites {
  identityEvidence: IdentityEvidenceSummary[] | { kind: 'rejected'; message: string };
  evidenceDocuments: CaseSubjectCorrectionEvidenceDocument[];
  approvalCheckers: ServicingApprovalCheckerSummary[] | { kind: 'rejected'; message: string };
  policyVersions: PolicyVersionSummary[] | { kind: 'rejected'; message: string };
  approvals: { kind: 'found'; approvals: { id: string; status: string; target: unknown }[] } | { kind: 'rejected'; message: string };
}

function CaseSubjectCorrectionDialog({ institutionId, record, close, onDone }: { institutionId: string; record: CaseRow; close: () => void; onDone: (outcome: SubmitOutcome) => void }): ReactNode {
  const [memberId, setMemberId] = useState(record.memberId);
  const [accountId, setAccountId] = useState(record.accountId ?? '');
  const [evidenceVersionId, setEvidenceVersionId] = useState('');
  const [approvalId, setApprovalId] = useState('');
  const prerequisiteKey = `${record.memberId}:${memberId.trim()}`;
  const prerequisites = useResource(() => getJson<CaseSubjectCorrectionPrerequisites>(institutionPath(institutionId,
    `/servicing/case-subject-correction/${record.memberId}${queryString({ correctedMemberId: memberId.trim() })}`)), prerequisiteKey);
  const [error, setError] = useState<string | undefined>(undefined);
  const [result, setResult] = useState<SubmitOutcome | null>(null);
  const submission = useSubmission();
  const evidence = prerequisites.data?.evidenceDocuments ?? [];
  const checkers = Array.isArray(prerequisites.data?.approvalCheckers) ? prerequisites.data.approvalCheckers : [];
  const policies = Array.isArray(prerequisites.data?.policyVersions) ? prerequisites.data.policyVersions : [];
  const approvals = prerequisites.data?.approvals.kind === 'found' ? prerequisites.data.approvals.approvals.filter((item) => item.status === 'approved') : [];
  const submit = async (): Promise<void> => {
    if (prerequisites.loading || prerequisites.error !== null) return;
    if (memberId.trim() === '' || evidenceVersionId === '' || approvalId === '') { setError('Correct member, current evidence, and an approved independent decision are required.'); return; }
    const outcome = await submission.submit(institutionId, { kind: 'case.subject.correct', caseId: record.id, expectedVersion: record.version, correctMemberId: memberId.trim(), correctAccountId: accountId.trim() === '' ? null : accountId.trim(), evidenceVersionId, approvalId });
    if (outcome === null) return;
    if (outcome.kind === 'committed' || outcome.kind === 'duplicate' || outcome.kind === 'unchanged') { close(); onDone(outcome); } else setResult(outcome);
  };
  return (
    <Dialog scope="window" title={`Correct subject of ${record.caseNumber}`} busy={submission.pending} onCancel={close} onSubmit={() => { void submit(); }}
      actions={<><button type="submit" className="primary" disabled={submission.pending || prerequisites.loading || prerequisites.error !== null}>{submission.pending ? 'Correcting…' : 'Correct subject'}</button><button type="button" onClick={close} disabled={submission.pending}>Cancel</button></>}>
      <p>This preserves the case history, restricts its evidence for renewed access review, and applies only the exact proposal covered by the approval.</p>
      {prerequisites.loading ? <Loading label="Loading evidence and approval prerequisites…" /> : null}
      {prerequisites.error === null ? null : <Banner tone="error" title="Prerequisites unavailable">{prerequisites.error.message}</Banner>}
      <TextField label="Correct member ID" value={memberId} onChange={(value) => { setMemberId(value); setEvidenceVersionId(''); setApprovalId(''); setError(undefined); }} required />
      <TextField label="Correct account ID" value={accountId} onChange={(value) => { setAccountId(value); setApprovalId(''); }} />
      <SelectField label="Evidence document version" value={evidenceVersionId} onChange={(value) => { setEvidenceVersionId(value); setApprovalId(''); }} options={[{ value: '', label: 'Choose current evidence' }, ...evidence.map((item) => ({ value: item.versionId, label: `${item.memberId === record.memberId ? 'Original' : 'Corrected'} · ${item.documentType} · ${item.displayName} · ${item.versionId}` }))]} />
      <SelectField label="Approved decision" value={approvalId} onChange={setApprovalId} options={[{ value: '', label: 'Choose approved decision' }, ...approvals.map((item) => ({ value: item.id, label: item.id }))]} />
      <p className="muted">Request the exact proposal under an effective policy ({policies.map((item) => item.version).join(', ') || 'none available'}); an eligible independent checker ({checkers.map((item) => item.actorNumber).join(', ') || 'none available'}) must approve it.</p>
      {error === undefined ? null : <Banner tone="error">{error}</Banner>}
      {result === null ? null : <OutcomeBanner outcome={result} />}
    </Dialog>
  );
}

const CASE_FIELD_LABELS = { queueId: 'Queue', assignedActorId: 'Assignee' } as const;
const ASSIGNMENT_FIELDS = ['queueId', 'assignedActorId'] as const;

/** Case editor: assignment, status transitions, notes, timeline and linked records. */
export function CaseWindow({ caseId }: { caseId: string }): ReactNode {
  const { open, can, notify } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const timeZone = win.institution.timeZone;
  const reference = useReference(institutionId);
  const detail = useResource(() => getJson<CaseDetail>(institutionPath(institutionId, `/cases/${caseId}`)), caseId);
  const stamp = useRecordStamp(institutionId, 'cases', caseId);
  const reload = detail.reload;
  const stampKey = stamp?.stamp;
  useEffect(() => { if (stampKey !== undefined) reload(); }, [stampKey, reload]);
  const record = detail.data?.case;
  const source = record === undefined ? undefined : { version: record.version, values: { queueId: record.queueId, assignedActorId: record.assignedActorId ?? '' } };
  const editor = useRecordDraft(caseId, source, stamp?.version);
  const [reason, setReason] = useState('');
  const [note, setNote] = useState({ text: '', visibility: 'general' });
  const [errors, setErrors] = useState<{ reason?: string; note?: string }>({});
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const [tab, setTab] = useState('details');
  const submission = useSubmission();
  const dirty = (editor?.dirty ?? false) || note.text.trim() !== '';
  useWindowChrome(record === undefined ? 'Case' : `Case ${record.caseNumber} · ${record.summary.slice(0, 40)}`,
    record === undefined ? {} : { case: record.caseNumber, member: record.memberNumber, ...(record.accountNumber === null ? {} : { account: record.accountNumber }) }, dirty);

  /** Saves case routing against the version the operator reviewed. */
  const saveAssignment = async (): Promise<boolean> => {
    if (editor === null || record === undefined || !editor.dirty) return true;
    if (editor.conflictVersion !== null) { notify(`Case ${record.caseNumber} changed elsewhere. Resolve the conflict before saving.`, 'error'); return false; }
    if (reason.trim() === '') { setTab('details'); setErrors({ reason: 'Enter the reason for the change.' }); return false; }
    if (ASSIGNMENT_FIELDS.some((field) => editor.edited(field))) {
      const result = await submission.submit(institutionId, { kind: 'case.assign', caseId, expectedVersion: editor.version, queueId: editor.draft.queueId, assignedActorId: editor.draft.assignedActorId === '' ? null : editor.draft.assignedActorId, reason: reason.trim() });
      if (result === null) return false;
      setOutcome(result);
      if (result.kind !== 'committed' && result.kind !== 'duplicate' && result.kind !== 'unchanged') { reload(); return false; }
      editor.saved(result.kind === 'unchanged' ? editor.version : editor.version + 1, ASSIGNMENT_FIELDS);
    }
    reload();
    setReason('');
    setErrors({});
    return true;
  };
  const addNote = async (): Promise<boolean> => {
    if (note.text.trim() === '') return true;
    const result = await submission.submit(institutionId, { kind: 'case.note.add', caseId, visibility: note.visibility as 'general', text: note.text.trim() });
    if (result === null) return false;
    setOutcome(result);
    if (result.kind === 'committed' || result.kind === 'duplicate') { setNote({ text: '', visibility: 'general' }); reload(); return true; }
    return false;
  };
  const save = async (): Promise<boolean> => {
    if (!dirty) { notify('This case has no unsaved changes.'); return true; }
    return await saveAssignment() && await addNote();
  };
  useWindowCommands({ save, refresh: reload });

  if (detail.data === undefined || record === undefined || editor === null) {
    return <div className="record-window">{detail.error === null ? <Loading /> : <LoadFailure error={detail.error} onRetry={reload} />}</div>;
  }
  const data = detail.data;
  const canManage = can(institutionId, 'case.assign') && record.state !== 'closed';
  const canCorrectSubject = can(institutionId, 'case.subject.correct');
  const transition = (toState: string): void => {
    win.dialogs.show((close) => <TransitionDialog institutionId={institutionId} record={record} toState={toState} close={close} onDone={(result) => { setOutcome(result); reload(); notify(`Case ${record.caseNumber} is now ${toState}.`); }} />);
  };
  const details = (
    <div className="panel-scroll">
      <ConflictBanner subject={`Case ${record.caseNumber}`} editor={editor} labels={CASE_FIELD_LABELS} latestLoaded={record.version >= (editor.conflictVersion ?? 0)} onReload={reload} />
      <DetailList items={[
        ['Summary', record.summary], ['Category', record.categoryLabel], ['Priority', record.priority], ['Opened', formatInstant(record.openedAt, timeZone)],
        ['Due', <span key="d" className={record.overdue ? 'overdue' : undefined}>{formatInstant(record.dueAt, timeZone)}{record.overdue ? ' · overdue' : ''}</span>],
        ['Member', <button key="m" type="button" className="link" onClick={() => { open(institutionId, { kind: 'member', memberId: record.memberId }); }}>{record.memberNumber} · {record.memberName}</button>],
        ['Account', record.accountId === null ? '' : <button key="a" type="button" className="link" onClick={() => { if (record.accountId !== null) open(institutionId, { kind: 'account', accountId: record.accountId }); }}>{record.accountNumber}</button>],
        ['Version', `v${String(record.version)}`],
      ]} />
      <h4>Status</h4>
      <div className="button-row" role="group" aria-label="Status changes">
        {data.allowedTransitions.length === 0 ? <span className="muted">No status changes are available from {record.state}.</span>
          : data.allowedTransitions.map((state) => <button key={state} type="button" disabled={!can(institutionId, 'case.transition')} onClick={() => { transition(state); }}>{titleCase(state)}…</button>)}
        {record.state === 'resolved' ? <button type="button" disabled={!can(institutionId, 'case.close')} onClick={() => { transition('closed'); }}>Close with evidence…</button> : null}
        {record.state === 'resolved' || record.state === 'closed' ? <button type="button" disabled={!can(institutionId, 'case.reopen')} onClick={() => { transition('reopened'); }}>Reopen with evidence…</button> : null}
      </div>
      <h4>Subject</h4>
      <button type="button" disabled={!canCorrectSubject} onClick={() => { win.dialogs.show((close) => <CaseSubjectCorrectionDialog institutionId={institutionId} record={record} close={close} onDone={(result) => { setOutcome(result); reload(); notify(`Case ${record.caseNumber} subject corrected.`); }} />); }}>Correct subject with approval…</button>
      <h4>Assignment</h4>
      <form className="form-grid" aria-label="Case assignment" onSubmit={(event) => { event.preventDefault(); void saveAssignment(); }}>
        <SelectField label="Queue" name="queue" value={editor.draft.queueId} onChange={(value) => { editor.set('queueId', value); }} changed={editor.edited('queueId')}
          options={(reference.data?.queues ?? [{ id: record.queueId, name: record.queueName }]).map((queue) => ({ value: queue.id, label: queue.name, disabled: !canManage }))} />
        <SelectField label="Assignee" name="assignee" value={editor.draft.assignedActorId} onChange={(value) => { editor.set('assignedActorId', value); }} changed={editor.edited('assignedActorId')}
          options={[{ value: '', label: 'Unassigned', disabled: !canManage }, ...(reference.data?.caseWorkers ?? []).map((worker) => ({ value: worker.id, label: `${worker.displayName} (${worker.actorNumber})`, disabled: !canManage }))]} />
        <TextField label="Reason for change" name="assignment-reason" value={reason} onChange={(value) => { setReason(value); setErrors({}); }} error={errors.reason} maxLength={500} wide />
        <div className="form-actions">
          <button type="submit" className="primary" disabled={!editor.dirty || submission.pending || !canManage}>{submission.pending ? 'Saving…' : 'Save assignment'}</button>
          <button type="button" disabled={!editor.dirty} onClick={() => { editor.discard(); setReason(''); }}>Cancel edits</button>
        </div>
      </form>
    </div>
  );
  const notes = (
    <div className="panel-scroll">
      <form className="form-grid" aria-label="Add case note" onSubmit={(event) => { event.preventDefault(); void addNote(); }}>
        <TextAreaField label="New note" name="case-note" value={note.text} onChange={(text) => { setNote({ ...note, text }); }} maxLength={2000} rows={3} error={errors.note} />
        <SelectField label="Visibility" value={note.visibility} onChange={(visibility) => { setNote({ ...note, visibility }); }} options={[{ value: 'general', label: 'General' }, { value: 'restricted', label: 'Restricted' }]} />
        <div className="form-actions"><button type="submit" className="primary" disabled={note.text.trim() === '' || submission.pending || !can(institutionId, 'case.note.add')}>Add note</button></div>
      </form>
      <ol className="note-list">{data.notes.map((entry) => (
        <li key={entry.id}><div className="note-meta">{formatInstant(entry.createdAt, timeZone)} · {entry.actor?.displayName ?? 'system'} · {entry.visibility}</div><div className="note-text">{entry.text}</div></li>
      ))}</ol>
    </div>
  );
  const linked = (
    <div className="panel-scroll">
      <h4>Dependencies</h4>
      {data.dependencies.length === 0 ? <p className="empty">None. The case can close once resolved.</p> : (
        <table className="simple-table" aria-label="Case dependencies"><thead><tr><th scope="col">Kind</th><th scope="col">Reference</th><th scope="col">State</th><th scope="col">Due</th></tr></thead>
          <tbody>{data.dependencies.map((dependency) => <tr key={dependency.id}><td>{dependency.kind}</td><td>{dependency.referenceId}</td><td>{dependency.state}</td><td>{formatInstant(dependency.dueAt, timeZone)}</td></tr>)}</tbody></table>
      )}
      <h4>Documents</h4>
      {data.documents.length === 0 ? <p className="empty">No documents linked.</p> : (
        <ul className="link-list">{data.documents.map((document) => (
          <li key={document.versionId}><a href={institutionPath(institutionId, `/documents/${document.versionId}/content`)} download>{document.displayName}</a> <span className="muted">{document.purpose} · v{document.version} · {document.visibility}</span></li>
        ))}</ul>
      )}
    </div>
  );
  const timeline = (
    <div className="panel-scroll">
      <h4>Timeline</h4>
      <ol className="event-list" aria-label="Case events">{data.events.map((event) => (
        <li key={event.sequence}><StatusTag status={event.state} /> {formatInstant(event.occurredAt, timeZone)} · {event.actor?.displayName ?? 'system'}<div className="muted">{event.detail}</div></li>
      ))}</ol>
      <h4>Service level</h4>
      <ul className="event-list">{data.sla.map((interval) => <li key={interval.startsAt}>{interval.state} from {formatInstant(interval.startsAt, timeZone)}{interval.endsAt === null ? '' : ` to ${formatInstant(interval.endsAt, timeZone)}`}{interval.reason === null ? '' : ` · ${interval.reason}`}</li>)}</ul>
    </div>
  );
  return (
    <div className="record-window">
      <Toolbar label="Case actions">
        <button type="button" onClick={() => { void save(); }} disabled={!dirty || submission.pending}>Save</button>
        <button type="button" onClick={reload}>Refresh</button>
        <span className="toolbar-spacer" />
        <button type="button" onClick={() => { open(institutionId, { kind: 'activity', memberId: null, accountId: null, caseId, label: record.caseNumber }); }}>Activity</button>
      </Toolbar>
      <div className="record-header">
        <div><span className="record-number">{record.caseNumber}</span> <StatusTag status={record.state} /> <span className="muted">{record.queueName} · {record.assignedName ?? 'Unassigned'}</span></div>
      </div>
      {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
      <SplitPane orientation="horizontal" initialPercent={62} label="Resize case panes" first={
        <Tabs label="Case sections" selected={tab} onSelect={setTab} tabs={[
          { id: 'details', label: 'Details', content: () => details },
          { id: 'notes', label: 'Notes', badge: data.notes.length, content: () => notes },
          { id: 'linked', label: 'Linked records', content: () => linked },
          { id: 'activity', label: 'Activity', content: () => <ActivityPanel scope={{ caseId }} label={`Activity for ${record.caseNumber}`} revision={stampKey ?? ''} /> },
        ]} />
      } second={timeline} />
    </div>
  );
}

/** Opens a servicing case for a member, optionally linked to one of the member's accounts. */
export function NewCaseWindow({ memberId, accountId }: { memberId: string | null; accountId: string | null }): ReactNode {
  const { can, notify } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const reference = useReference(institutionId);
  const [lookup, setLookup] = useState('');
  const [resolvedMemberId, setResolvedMemberId] = useState(memberId);
  const member = useResource(resolvedMemberId === null ? null : () => getJson<MemberDetail>(institutionPath(institutionId, `/members/${resolvedMemberId}`)), resolvedMemberId ?? '');
  const [form, setForm] = useState({ accountId: accountId ?? '', category: 'account-servicing', priority: 'normal', queueId: '', assignedActorId: '', summary: '', dueDate: addDays(win.institution.asOf.slice(0, 10), 5) });
  const [errors, setErrors] = useState<Partial<Record<'lookup' | 'summary' | 'dueDate' | 'queue', string>>>({});
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const submission = useSubmission();
  const dirty = form.summary !== '' || (lookup !== '' && resolvedMemberId === null);
  const detail = member.data;
  useWindowChrome(detail === undefined ? 'New case' : `New case · ${detail.member.memberNumber}`, detail === undefined ? {} : { member: detail.member.memberNumber }, dirty);
  const queueId = form.queueId === '' ? reference.data?.queues[0]?.id ?? '' : form.queueId;

  const findMember = async (): Promise<void> => {
    const number = lookup.trim().toUpperCase();
    try {
      const page = await getJson<PageResult<MemberRow>>(institutionPath(institutionId, `/members${queryString({ query: number, limit: 10 })}`));
      const match = page.items.find((row) => row.memberNumber === number);
      if (match === undefined) { setErrors({ lookup: `No member ${number} exists at ${win.institution.displayName}.` }); return; }
      setErrors({});
      setForm((current) => ({ ...current, accountId: '' }));
      setResolvedMemberId(match.id);
    } catch (error) { setErrors({ lookup: error instanceof ApiError ? error.message : 'The member lookup failed.' }); }
  };
  const submit = async (): Promise<boolean> => {
    const problems: typeof errors = {};
    if (detail === undefined) problems.lookup = 'Find the member first.';
    if (form.summary.trim() === '') problems.summary = 'Summarize the request.';
    if (!/^\d{4}-\d{2}-\d{2}$/u.test(form.dueDate)) problems.dueDate = 'Choose a due date.';
    if (queueId === '') problems.queue = 'Choose a queue.';
    setErrors(problems);
    if (Object.keys(problems).length > 0 || detail === undefined) return false;
    const result = await submission.submit(institutionId, {
      kind: 'case.open', memberId: detail.member.id, accountId: form.accountId === '' ? null : form.accountId, queueId, assignedActorId: form.assignedActorId === '' ? null : form.assignedActorId,
      category: form.category, priority: form.priority as 'normal', summary: form.summary.trim(), dueDate: form.dueDate,
    });
    if (result === null) return false;
    if (result.kind === 'committed' || result.kind === 'duplicate') {
      const created = result.receipt.affected.find((entry) => entry.kind === 'case');
      notify(`Opened case ${created?.label ?? ''}. Receipt ${result.receipt.receiptNumber}.`);
      if (created !== undefined) win.retarget({ kind: 'case', caseId: created.id }, `Case ${created.label}`);
      return true;
    }
    setOutcome(result);
    return false;
  };
  useWindowCommands({ save: submit });
  const allowed = can(institutionId, 'case.open');
  return (
    <div className="form-window">
      <div className="form-scroll">
        {allowed ? null : <Banner tone="warning" title="Not permitted.">Operator roles at {win.institution.displayName} do not include case management.</Banner>}
        {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
        <form className="form-grid" aria-label="New case" noValidate onSubmit={(event) => { event.preventDefault(); void submit(); }}>
          <fieldset className="fieldset-wide">
            <legend>Member</legend>
            {detail === undefined ? (
              <div className="inline-lookup">
                <TextField label="Member number" type="search" value={lookup} onChange={(value) => { setLookup(value); setErrors({}); }} error={errors.lookup} placeholder="NM000001" autoFocus />
                <button type="button" onClick={() => { void findMember(); }}>Find</button>
              </div>
            ) : <p><strong>{detail.member.memberNumber}</strong> · {memberName(detail)} <StatusTag status={detail.member.status} /> {memberId === null ? <button type="button" className="link" onClick={() => { setResolvedMemberId(null); }}>Change</button> : null}</p>}
            {member.loading ? <Loading /> : null}
          </fieldset>
          <SelectField label="Linked account" value={form.accountId} onChange={(value) => { setForm({ ...form, accountId: value }); }}
            options={[{ value: '', label: 'No account' }, ...(detail?.accounts ?? []).map((account) => ({ value: account.id, label: `${account.accountNumber} · ${account.productName}` }))]} />
          <SelectField label="Category" value={form.category} onChange={(value) => { setForm({ ...form, category: value }); }} options={(reference.data?.caseCategories ?? []).map((category) => ({ value: category.code, label: category.label }))} />
          <SelectField label="Priority" value={form.priority} onChange={(value) => { setForm({ ...form, priority: value }); }} options={PRIORITIES.map((priority) => ({ value: priority, label: titleCase(priority) }))} />
          <SelectField label="Queue" value={queueId} onChange={(value) => { setForm({ ...form, queueId: value }); }} error={errors.queue} options={(reference.data?.queues ?? []).map((queue) => ({ value: queue.id, label: queue.name }))} />
          <SelectField label="Assignee" value={form.assignedActorId} onChange={(value) => { setForm({ ...form, assignedActorId: value }); }}
            options={[{ value: '', label: 'Unassigned' }, ...(reference.data?.caseWorkers ?? []).map((worker) => ({ value: worker.id, label: `${worker.displayName} (${worker.actorNumber})` }))]} />
          <TextField label="Due date" type="date" value={form.dueDate} onChange={(value) => { setForm({ ...form, dueDate: value }); }} error={errors.dueDate} />
          <TextAreaField label="Summary" value={form.summary} onChange={(value) => { setForm({ ...form, summary: value }); setErrors({}); }} error={errors.summary} maxLength={200} rows={2} required />
          <div className="form-actions"><button type="submit" className="primary" disabled={!allowed || submission.pending}>{submission.pending ? 'Opening…' : 'Open case'}</button></div>
        </form>
      </div>
    </div>
  );
}
