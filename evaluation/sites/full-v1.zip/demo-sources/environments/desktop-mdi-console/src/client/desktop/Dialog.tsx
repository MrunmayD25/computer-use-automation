import { useCallback, useEffect, useId, useRef, useState, type KeyboardEvent, type ReactNode } from 'react';

const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

export function focusableWithin(root: HTMLElement): HTMLElement[] {
  return [...root.querySelectorAll<HTMLElement>(FOCUSABLE)].filter((element) => !element.closest('[inert]') && element.getClientRects().length > 0);
}

export interface DialogProps {
  title: string;
  children: ReactNode;
  actions: ReactNode;
  /** Escape and the Cancel action. Ignored while busy so an in-flight submission cannot be abandoned mid-way. */
  onCancel: () => void;
  /** Enter in a field, or the submit button. */
  onSubmit?: () => void;
  busy?: boolean;
  width?: number;
  scope: 'window' | 'desktop';
  tone?: 'normal' | 'warning';
}

/** The active window's open local dialog control that should hold focus, if any. */
function activeWindowDialogTarget(): HTMLElement | null {
  const dialog = document.querySelector<HTMLElement>('section.window[data-active="true"] .modal-window [role="dialog"]');
  return dialog === null ? null : dialog.querySelector<HTMLElement>('[data-autofocus]') ?? focusableWithin(dialog)[0] ?? dialog;
}

/**
 * Modal dialog that owns focus: it focuses its first control, traps Tab, and answers Escape and Enter.
 * A window dialog that opens in a background window, or under a desktop dialog, leaves focus where the
 * operator is working; its window focuses it when activated.
 */
export function Dialog({ title, children, actions, onCancel, onSubmit, busy = false, width = 440, scope, tone = 'normal' }: DialogProps): ReactNode {
  const ref = useRef<HTMLFormElement>(null);
  const titleId = useId();
  useEffect(() => {
    const node = ref.current;
    if (node === null) return;
    const owner = node.closest<HTMLElement>('section.window');
    if (scope === 'window' && owner !== null && (owner.dataset.active !== 'true' || document.querySelector('.modal-desktop') !== null)) return;
    const target = node.querySelector<HTMLElement>('[data-autofocus]') ?? focusableWithin(node)[0] ?? node;
    target.focus();
  }, [scope]);
  const onKeyDown = (event: KeyboardEvent<HTMLFormElement>): void => {
    if (event.key === 'Escape') {
      event.preventDefault();
      event.stopPropagation();
      if (!busy) onCancel();
      return;
    }
    if (event.key !== 'Tab' || ref.current === null) return;
    const items = focusableWithin(ref.current);
    const first = items[0];
    const last = items.at(-1);
    if (first === undefined || last === undefined) { event.preventDefault(); return; }
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  };
  return (
    <div className={`modal-backdrop modal-${scope}`}>
      <form
        ref={ref} role="dialog" aria-modal="true" aria-labelledby={titleId} aria-busy={busy} className={`dialog dialog-${tone}`} style={{ width }} tabIndex={-1}
        onKeyDown={onKeyDown} onSubmit={(event) => { event.preventDefault(); if (!busy) onSubmit?.(); }}
      >
        <div className="dialog-title" id={titleId}>{title}</div>
        <div className="dialog-body">{children}</div>
        <div className="dialog-actions">{actions}</div>
      </form>
    </div>
  );
}

export type DialogRender = (close: () => void) => ReactNode;

export interface DialogHost {
  show: (render: DialogRender) => void;
  close: () => void;
  node: ReactNode;
  open: boolean;
}

/**
 * Holds at most one dialog and returns focus to the element that was focused when it opened.
 * Focus returns only while it is still inside the closing dialog, or nowhere: a dialog that closes
 * because a background window's request finished must not take focus from the window in use.
 */
export function useDialogHost(): DialogHost {
  const [render, setRender] = useState<DialogRender | null>(null);
  const returnFocus = useRef<HTMLElement | null>(null);
  const container = useRef<HTMLDivElement>(null);
  const close = useCallback(() => {
    const focused = document.activeElement;
    const owned = focused === null || focused === document.body || (container.current?.contains(focused) ?? false);
    const ownerWindow = container.current?.closest<HTMLElement>('section.window') ?? null;
    setRender(null);
    const remembered = returnFocus.current;
    returnFocus.current = null;
    // A dialog that opened while another window was in use remembers that window's control; it returns focus within its own window instead.
    const target = ownerWindow === null || remembered === null || ownerWindow.contains(remembered) ? remembered : null;
    if (owned) {
      requestAnimationFrame(() => {
        if (target !== null && target !== document.body && target.isConnected && target.closest('[inert]') === null) target.focus();
        else if (ownerWindow !== null) (focusableWithin(ownerWindow.querySelector<HTMLElement>('.window-body') ?? ownerWindow)[0] ?? ownerWindow).focus();
        else activeWindowDialogTarget()?.focus();
      });
    }
  }, []);
  const show = useCallback((next: DialogRender) => {
    if (returnFocus.current === null && document.activeElement instanceof HTMLElement) returnFocus.current = document.activeElement;
    setRender(() => next);
  }, []);
  return { show, close, node: render === null ? null : <div ref={container} className="dialog-host">{render(close)}</div>, open: render !== null };
}

export interface ChoiceOption<T extends string> { value: T; label: string; primary?: boolean; danger?: boolean }

/** Promise-based confirmation rendered in a host; resolves to the chosen value, or null on cancel. */
export function choose<T extends string>(host: DialogHost, scope: 'window' | 'desktop', title: string, message: ReactNode, options: readonly ChoiceOption<T>[], tone: 'normal' | 'warning' = 'normal'): Promise<T | null> {
  return new Promise((resolve) => {
    host.show((close) => {
      const finish = (value: T | null): void => { close(); resolve(value); };
      const primary = options.find((option) => option.primary === true);
      return (
        <Dialog
          scope={scope} title={title} tone={tone} onCancel={() => { finish(null); }} {...(primary === undefined ? {} : { onSubmit: () => { finish(primary.value); } })}
          actions={<>
            {options.map((option) => (
              <button key={option.value} type={option.primary === true ? 'submit' : 'button'} className={option.danger === true ? 'danger' : option.primary === true ? 'primary' : ''} data-autofocus={option.primary === true ? true : undefined}
                onClick={option.primary === true ? undefined : () => { finish(option.value); }}>{option.label}</button>
            ))}
            <button type="button" data-autofocus={primary === undefined ? true : undefined} onClick={() => { finish(null); }}>Cancel</button>
          </>}
        >
          {message}
        </Dialog>
      );
    });
  });
}
