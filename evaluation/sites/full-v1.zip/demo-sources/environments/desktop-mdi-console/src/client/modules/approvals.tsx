import { useState, type ReactNode } from 'react';

import type { Money as MoneyValue, Rejection } from '@computer-use/financial-database/services';

import { ApiError, executeCommand, getJson, institutionPath, newIdempotencyKey } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands } from '../desktop/context';
import { Dialog } from '../desktop/Dialog';
import { stampWatcher } from '../desktop/stamps';
import { Banner, DetailList, Loading, TextAreaField, Toolbar } from '../widgets/fields';
import { useResource } from '../widgets/useResource';
import { COMMAND_LABELS, OutcomeBanner, rejectionTitle, useReference, Money, exponentOf, type SubmitOutcome } from './common';

interface ApprovalRow {
  id: string;
  status: string;
  fingerprint: string;
  target: unknown;
  expiresAt: string;
  amountLimit: MoneyValue | null;
}

interface ApprovalList { kind: 'found'; approvals: ApprovalRow[]; total: number; truncated: boolean }

function targetKind(target: unknown): string {
  return typeof target === 'object' && target !== null && typeof (target as { kind?: unknown }).kind === 'string' ? (target as { kind: string }).kind : 'approval';
}

function DecideDialog({ institutionId, approval, close, onDone }: { institutionId: string; approval: ApprovalRow; close: () => void; onDone: (outcome: SubmitOutcome) => void }): ReactNode {
  const [decision, setDecision] = useState<'approve' | 'deny'>('approve');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<Rejection | string | null>(null);
  const submit = async (): Promise<void> => {
    if (busy || reason.trim() === '') { if (reason.trim() === '') setFailure('Enter the decision reason.'); return; }
    setBusy(true);
    try {
      const outcome = await executeCommand(institutionId, { kind: 'approval.decide', approvalId: approval.id, expectedFingerprint: approval.fingerprint, decision, reason: reason.trim() }, newIdempotencyKey('approval.decide'));
      if (outcome.kind === 'committed' || outcome.kind === 'duplicate') { stampWatcher.checkSoon(); close(); onDone(outcome); return; }
      if (outcome.kind === 'rejected') setFailure(outcome); else setFailure(outcome.message);
    } catch (error) {
      setFailure(error instanceof ApiError ? error.message : 'The decision could not be recorded.');
    } finally { setBusy(false); }
  };
  return (
    <Dialog scope="window" title={`Decide ${approval.id}`} busy={busy} width={560} onCancel={close} onSubmit={() => { void submit(); }}
      actions={<><button type="submit" className="primary" disabled={busy} data-autofocus>Record decision</button><button type="button" onClick={close} disabled={busy}>Cancel</button></>}>
      <DetailList items={[
        ['Target', COMMAND_LABELS[targetKind(approval.target)] ?? targetKind(approval.target)],
        ['Expires', approval.expiresAt],
      ]} />
      <pre className="command-preview" data-testid="approval-target">{JSON.stringify(approval.target, null, 2)}</pre>
      <fieldset className="radio-inline" aria-label="Decision">
        <label><input type="radio" name="decision" checked={decision === 'approve'} onChange={() => { setDecision('approve'); }} /> Approve</label>
        <label><input type="radio" name="decision" checked={decision === 'deny'} onChange={() => { setDecision('deny'); }} /> Deny</label>
      </fieldset>
      <TextAreaField label="Reason" value={reason} onChange={setReason} required />
      {failure === null ? null : typeof failure === 'string'
        ? <Banner tone="warning">{failure}</Banner>
        : <Banner tone="error" title={rejectionTitle(failure.code)}><span data-testid="rejection-code" data-code={failure.code}>{failure.message}</span></Banner>}
      <p className="hint">Fingerprint <code>{approval.fingerprint}</code></p>
    </Dialog>
  );
}

/** Approval inbox: pending decisions for the operator's checkable kinds plus decided history. */
export function ApprovalsWindow(): ReactNode {
  const { can, notify, open } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const reference = useReference(institutionId);
  const [status, setStatus] = useState('');
  const list = useResource(() => getJson<ApprovalList | Rejection>(institutionPath(institutionId, '/approvals')), 'approvals');
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  useWindowChrome(`Approvals · ${win.institution.displayName}`, {}, false);
  useWindowCommands({ refresh: () => { list.reload(); } });
  const rows = list.data?.kind === 'found' ? list.data.approvals.filter((row) => status === '' || row.status === status) : [];
  const pending = rows.filter((row) => row.status === 'pending').length;
  return (
    <div className="list-window">
      <Toolbar label="Approval actions">
        <select aria-label="Filter by status" value={status} onChange={(event) => { setStatus(event.target.value); }}>
          <option value="">All statuses</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="denied">Denied</option><option value="expired">Expired</option>
        </select>
        <button type="button" onClick={() => { list.reload(); }}>Refresh</button>
        {can(institutionId, 'approval.request') ? <button type="button" onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'approval.request' }, { reuse: false }); }}>New approval request…</button> : null}
      </Toolbar>
      {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
      {list.loading ? <Loading label="Loading approvals…" /> : null}
      {list.data !== undefined && list.data.kind === 'rejected' ? <Banner tone="error" title="List rejected.">{list.data.message}</Banner> : null}
      {list.error === null ? null : <Banner tone="error" title="Could not load.">{list.error.message}</Banner>}
      {pending > 0 ? <Banner tone="info" title={`${pending} awaiting decision.`} /> : null}
      <div className="grid-scroll">
        <table className="grid" data-testid="approvals">
          <thead><tr><th scope="col">Approval</th><th scope="col">Target</th><th scope="col">Status</th><th scope="col">Amount limit</th><th scope="col">Expires</th><th scope="col" /></tr></thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id} data-approval={row.id}>
                <td><code>{row.id}</code></td>
                <td>{COMMAND_LABELS[targetKind(row.target)] ?? targetKind(row.target)}</td>
                <td>{row.status}</td>
                <td>{row.amountLimit === null ? '—' : <Money minorUnits={row.amountLimit.minorUnits} currency={row.amountLimit.currency} exponent={exponentOf(reference.data, row.amountLimit.currency)} />}</td>
                <td>{row.expiresAt}</td>
                <td>{row.status === 'pending' && can(institutionId, 'approval.decide')
                  ? <button type="button" onClick={() => { win.dialogs.show((close) => <DecideDialog institutionId={institutionId} approval={row} close={close} onDone={(result) => { setOutcome(result); list.reload(); notify(`Approval ${row.id} decided.`); }} />); }}>Decide…</button>
                  : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
