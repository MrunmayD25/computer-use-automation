export type ShortcutId =
  | 'save' | 'print' | 'refresh' | 'close' | 'minimize' | 'next-window' | 'previous-window' | 'menu' | 'focus-search' | 'shortcuts' | 'find-member' | 'find-account';

export interface Shortcut {
  id: ShortcutId;
  keys: string;
  description: string;
  /** Window shortcuts act on the active window and are withheld while that window shows a dialog. */
  scope: 'window' | 'desktop';
  /** When false, the key is left to text fields and selects so typing is never hijacked. */
  inEditable: boolean;
  matches(event: KeyboardEvent): boolean;
}

const plain = (event: KeyboardEvent): boolean => !event.altKey && !event.ctrlKey && !event.metaKey;
const altShift = (code: string) => (event: KeyboardEvent): boolean => event.altKey && event.shiftKey && !event.ctrlKey && !event.metaKey && event.code === code;
const command = (code: string) => (event: KeyboardEvent): boolean => (event.ctrlKey || event.metaKey) && !event.altKey && !event.shiftKey && event.code === code;

export const SHORTCUTS: readonly Shortcut[] = [
  { id: 'save', keys: 'Ctrl+S', description: 'Save the active window', scope: 'window', inEditable: true, matches: command('KeyS') },
  { id: 'print', keys: 'Ctrl+P', description: 'Print the active window only', scope: 'window', inEditable: true, matches: command('KeyP') },
  { id: 'refresh', keys: 'Alt+Shift+R', description: 'Refresh the active window from the server (drafts are kept)', scope: 'window', inEditable: true, matches: altShift('KeyR') },
  { id: 'close', keys: 'Alt+Shift+W', description: 'Close the active window, confirming unsaved changes', scope: 'window', inEditable: true, matches: altShift('KeyW') },
  { id: 'minimize', keys: 'Alt+Shift+M', description: 'Minimize the active window to the taskbar', scope: 'window', inEditable: true, matches: altShift('KeyM') },
  { id: 'next-window', keys: 'Alt+Shift+]', description: 'Activate the next window', scope: 'desktop', inEditable: true, matches: altShift('BracketRight') },
  { id: 'previous-window', keys: 'Alt+Shift+[', description: 'Activate the previous window', scope: 'desktop', inEditable: true, matches: altShift('BracketLeft') },
  { id: 'find-member', keys: 'Alt+Shift+F', description: 'Open member search', scope: 'desktop', inEditable: true, matches: altShift('KeyF') },
  { id: 'find-account', keys: 'Alt+Shift+A', description: 'Open account search', scope: 'desktop', inEditable: true, matches: altShift('KeyA') },
  { id: 'menu', keys: 'F10', description: 'Move focus to the menu bar', scope: 'desktop', inEditable: true, matches: (event) => plain(event) && !event.shiftKey && event.key === 'F10' },
  { id: 'focus-search', keys: '/', description: 'Focus the search field of the active window (ignored while typing)', scope: 'window', inEditable: false, matches: (event) => plain(event) && event.key === '/' },
  { id: 'shortcuts', keys: 'Alt+Shift+K', description: 'Show this list of keyboard shortcuts', scope: 'desktop', inEditable: true, matches: altShift('KeyK') },
];

/** Keys handled by focused widgets rather than the desktop registry. */
export const CONTEXT_KEYS: readonly { keys: string; description: string }[] = [
  { keys: 'Enter', description: 'Confirm the default action of a dialog, or open the selected grid row' },
  { keys: 'Esc', description: 'Cancel a dialog or close a menu, returning focus to where it was' },
  { keys: 'Shift+F10 / Menu', description: 'Open the context menu for the selected grid row' },
  { keys: 'Arrow keys', description: 'Move through menus, tabs, grid rows and split-pane dividers' },
  { keys: 'Tab / Shift+Tab', description: 'Move focus; inside a dialog focus stays within the dialog' },
];

export function isEditable(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  if (target.isContentEditable) return true;
  if (target instanceof HTMLInputElement) return !['button', 'checkbox', 'radio', 'submit', 'reset'].includes(target.type);
  return target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement;
}

export function shortcutLabel(id: ShortcutId): string {
  return SHORTCUTS.find((shortcut) => shortcut.id === id)?.keys ?? '';
}
