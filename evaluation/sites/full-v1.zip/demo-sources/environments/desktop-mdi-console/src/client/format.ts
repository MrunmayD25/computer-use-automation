/** Formats exact integer minor units without floating-point arithmetic on the fraction. */
export function formatMoney(minorUnits: number, currency: string, exponent: number): string {
  const scale = 10 ** exponent;
  const absolute = Math.abs(minorUnits);
  const whole = Math.trunc(absolute / scale).toLocaleString('en-US');
  const fraction = exponent === 0 ? '' : `.${String(absolute % scale).padStart(exponent, '0')}`;
  return `${minorUnits < 0 ? '-' : ''}${whole}${fraction} ${currency}`;
}

export type AmountParse = { ok: true; minorUnits: number } | { ok: false; message: string };

/** Parses a typed decimal amount into minor units for a currency exponent. */
export function parseAmount(text: string, exponent: number): AmountParse {
  const trimmed = text.trim().replaceAll(',', '');
  if (trimmed === '') return { ok: false, message: 'Enter an amount.' };
  const pattern = exponent === 0 ? /^\d+$/u : new RegExp(`^\\d+(\\.\\d{1,${String(exponent)}})?$`, 'u');
  if (!pattern.test(trimmed)) return { ok: false, message: exponent === 0 ? 'Enter a whole amount; this currency has no minor units.' : `Enter a number with at most ${String(exponent)} decimal places.` };
  const [whole = '0', fraction = ''] = trimmed.split('.');
  const minorUnits = Number(whole) * 10 ** exponent + Number(fraction.padEnd(exponent, '0') || '0');
  if (!Number.isSafeInteger(minorUnits) || minorUnits > 1_000_000_000_000) return { ok: false, message: 'The amount is too large.' };
  if (minorUnits <= 0) return { ok: false, message: 'Enter an amount greater than zero.' };
  return { ok: true, minorUnits };
}

export function formatInstant(iso: string | null, timeZone: string): string {
  if (iso === null) return '';
  return new Intl.DateTimeFormat('en-US', { timeZone, dateStyle: 'medium', timeStyle: 'short' }).format(new Date(iso));
}

export function formatDate(isoDate: string | null): string {
  if (isoDate === null) return '';
  return new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', dateStyle: 'medium' }).format(new Date(`${isoDate.slice(0, 10)}T00:00:00Z`));
}

export function titleCase(value: string): string {
  return value.replaceAll(/[-_.]/gu, ' ').replace(/^\w/u, (letter) => letter.toUpperCase());
}

/** Lossless display text for an unknown record value: scalars verbatim, structures as JSON. */
export function describeValue(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return JSON.stringify(value);
}
