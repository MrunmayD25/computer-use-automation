import { useId, useRef, useState, type KeyboardEvent, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';

export interface TabSpec { id: string; label: string; content: () => ReactNode; badge?: string | number }

/** Tabs whose panels stay mounted once visited, so each tab keeps its scroll position and local state. */
export function Tabs({ label, tabs, selected, onSelect }: { label: string; tabs: readonly TabSpec[]; selected: string; onSelect: (id: string) => void }): ReactNode {
  const prefix = useId();
  const [visited, setVisited] = useState<ReadonlySet<string>>(() => new Set([selected]));
  if (!visited.has(selected)) setVisited(new Set([...visited, selected]));
  const list = useRef<HTMLDivElement>(null);
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>): void => {
    const index = tabs.findIndex((tab) => tab.id === selected);
    const next = event.key === 'ArrowRight' ? index + 1 : event.key === 'ArrowLeft' ? index - 1 : event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : null;
    if (next === null) return;
    event.preventDefault();
    const tab = tabs[(next + tabs.length) % tabs.length];
    if (tab === undefined) return;
    onSelect(tab.id);
    list.current?.querySelector<HTMLElement>(`#${CSS.escape(`${prefix}-tab-${tab.id}`)}`)?.focus();
  };
  return (
    <div className="tabs">
      <div ref={list} role="tablist" aria-label={label} className="tab-list" onKeyDown={onKeyDown}>
        {tabs.map((tab) => (
          <button
            key={tab.id} id={`${prefix}-tab-${tab.id}`} type="button" role="tab" aria-selected={tab.id === selected} aria-controls={`${prefix}-panel-${tab.id}`}
            tabIndex={tab.id === selected ? 0 : -1} className="tab" onClick={() => { onSelect(tab.id); }}
          >{tab.label}{tab.badge === undefined ? null : <span className="tab-badge">{tab.badge}</span>}</button>
        ))}
      </div>
      {tabs.filter((tab) => visited.has(tab.id)).map((tab) => (
        <div key={tab.id} id={`${prefix}-panel-${tab.id}`} role="tabpanel" aria-labelledby={`${prefix}-tab-${tab.id}`} hidden={tab.id !== selected} className="tab-panel">
          {tab.content()}
        </div>
      ))}
    </div>
  );
}

/** Two docked panes with a draggable, keyboard-adjustable divider. `horizontal` places panes side by side. */
export function SplitPane({ orientation, initialPercent, label, first, second, minPercent = 20 }: { orientation: 'horizontal' | 'vertical'; initialPercent: number; label: string; first: ReactNode; second: ReactNode; minPercent?: number }): ReactNode {
  const [percent, setPercent] = useState(initialPercent);
  const root = useRef<HTMLDivElement>(null);
  const clamp = (value: number): number => Math.max(minPercent, Math.min(100 - minPercent, value));
  const horizontal = orientation === 'horizontal';
  const startDrag = (event: ReactPointerEvent<HTMLDivElement>): void => {
    if (event.button !== 0 || root.current === null) return;
    event.preventDefault();
    const target = event.currentTarget;
    const rect = root.current.getBoundingClientRect();
    target.setPointerCapture(event.pointerId);
    const onMove = (move: PointerEvent): void => {
      setPercent(clamp(horizontal ? ((move.clientX - rect.left) / rect.width) * 100 : ((move.clientY - rect.top) / rect.height) * 100));
    };
    const onUp = (): void => { target.removeEventListener('pointermove', onMove); target.removeEventListener('pointerup', onUp); };
    target.addEventListener('pointermove', onMove);
    target.addEventListener('pointerup', onUp);
  };
  return (
    <div ref={root} className={`split split-${orientation}`}>
      <div className="split-pane" style={{ flexBasis: `${String(percent)}%` }}>{first}</div>
      <div
        role="separator" aria-label={label} aria-orientation={horizontal ? 'vertical' : 'horizontal'} aria-valuenow={Math.round(percent)} aria-valuemin={minPercent} aria-valuemax={100 - minPercent}
        tabIndex={0} className="split-divider" onPointerDown={startDrag}
        onKeyDown={(event) => {
          const delta = ['ArrowLeft', 'ArrowUp'].includes(event.key) ? -5 : ['ArrowRight', 'ArrowDown'].includes(event.key) ? 5 : 0;
          if (event.key === 'Home') setPercent(minPercent);
          else if (event.key === 'End') setPercent(100 - minPercent);
          else if (delta !== 0) setPercent((value) => clamp(value + delta));
          else return;
          event.preventDefault();
        }}
      />
      <div className="split-pane split-rest">{second}</div>
    </div>
  );
}
