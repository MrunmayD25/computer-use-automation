import { useState, type ReactNode } from 'react';

import type { SavedSearchDefinition, SavedSearchEntity, SavedSearchEntitySpec, SavedSearchFilterValue, SavedSearchRow } from '@computer-use/financial-database/services';

import type { LimitedPage, SavedSearchList } from '../../shared/api';
import { getJson, institutionPath, queryString } from '../api';
import { useDesktop, useWindow } from '../desktop/context';
import { choose, Dialog } from '../desktop/Dialog';
import { SelectField, TextField } from '../widgets/fields';
import type { SortState } from '../widgets/Grid';
import { useResource } from '../widgets/useResource';
import { OutcomeBanner, useSubmission, type SubmitOutcome } from './common';

export type SearchFilters = Readonly<Record<string, SavedSearchFilterValue>>;

/** What a search window shows: filters in the shared saved-search vocabulary, one sort, visible columns and an optional result limit. */
export interface SearchView {
  filters: SearchFilters;
  sort: SortState;
  /** Visible column keys in display order. */
  visible: readonly string[];
  maxResults: number | null;
}

interface ViewColumn { key: string; label: string; field?: string }

export function textFilter(filters: SearchFilters, key: string): string {
  const value = filters[key];
  return typeof value === 'string' ? value : '';
}

export function listFilter(filters: SearchFilters, key: string): readonly string[] {
  const value = filters[key];
  return Array.isArray(value) ? value : [];
}

/** Drops empty values so a definition stores only the filters in force. */
function compact(filters: SearchFilters): Record<string, SavedSearchFilterValue> {
  return Object.fromEntries(Object.entries(filters).filter(([, value]) => value !== '' && value !== false && !(Array.isArray(value) && value.length === 0)));
}

function toDefinition(entity: SavedSearchEntity, view: SearchView, columns: readonly ViewColumn[], vocabulary: SavedSearchEntitySpec): SavedSearchDefinition {
  const sortField = Object.entries(vocabulary.sorts).find(([, key]) => key === view.sort.key)?.[0];
  const fields = view.visible.flatMap((key) => { const field = columns.find((column) => column.key === key)?.field; return field === undefined ? [] : [field]; });
  return { entity, filters: compact(view.filters), sort: sortField === undefined ? [] : [{ field: sortField, direction: view.sort.direction }], columns: fields, ...(view.maxResults === null ? {} : { maxResults: view.maxResults }) };
}

function fromDefinition(definition: SavedSearchDefinition, columns: readonly ViewColumn[], vocabulary: SavedSearchEntitySpec, fallback: SearchView): SearchView {
  const [sort] = definition.sort;
  const sortKey = sort === undefined ? undefined : vocabulary.sorts[sort.field];
  const visible = definition.columns.flatMap((field) => { const key = columns.find((column) => column.field === field)?.key; return key === undefined ? [] : [key]; });
  return {
    filters: definition.filters,
    sort: sort === undefined || sortKey === undefined ? fallback.sort : { key: sortKey, direction: sort.direction },
    visible: visible.length === 0 ? fallback.visible : visible,
    maxResults: definition.maxResults ?? null,
  };
}

function SaveSearchDialog({ canShare, onSubmit, close }: { canShare: boolean; onSubmit: (name: string, visibility: 'private' | 'shared', maxResults: number | null) => Promise<SubmitOutcome | null>; close: () => void }): ReactNode {
  const [form, setForm] = useState({ name: '', visibility: 'private', limit: '' });
  const [errors, setErrors] = useState<{ name?: string; limit?: string }>({});
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (): Promise<void> => {
    const problems: typeof errors = {};
    if (form.name.trim() === '') problems.name = 'Name the search.';
    const limit = form.limit.trim() === '' ? null : Number(form.limit);
    if (limit !== null && (!Number.isSafeInteger(limit) || limit < 1 || limit > 10_000)) problems.limit = 'Enter a whole number from 1 through 10,000, or leave it empty.';
    setErrors(problems);
    if (Object.keys(problems).length > 0) return;
    setBusy(true);
    const result = await onSubmit(form.name.trim(), form.visibility as 'private' | 'shared', limit);
    setBusy(false);
    if (result === null) return;
    if (result.kind === 'committed' || result.kind === 'duplicate') close(); else setOutcome(result);
  };
  return (
    <Dialog scope="window" title="Save search" busy={busy} onCancel={close} onSubmit={() => { void submit(); }}
      actions={<><button type="submit" className="primary" disabled={busy}>Save search</button><button type="button" onClick={close} disabled={busy}>Cancel</button></>}>
      <TextField label="Name" value={form.name} onChange={(name) => { setForm({ ...form, name }); setErrors({}); }} error={errors.name} maxLength={80} required autoFocus />
      <SelectField label="Visibility" value={form.visibility} onChange={(visibility) => { setForm({ ...form, visibility }); }}
        options={[{ value: 'private', label: 'Only me' }, { value: 'shared', label: 'Shared with the institution team', disabled: !canShare }]}
        hint={canShare ? undefined : 'Sharing needs case management or supervisory authority.'} />
      <TextField label="Result limit" value={form.limit} inputMode="decimal" onChange={(limit) => { setForm({ ...form, limit }); setErrors({}); }} error={errors.limit} hint="Optional. Totals stop at this many results." />
      {outcome === null ? null : <OutcomeBanner outcome={outcome} />}
    </Dialog>
  );
}

function ColumnsDialog({ columns, visible, onApply, close }: { columns: readonly ViewColumn[]; visible: readonly string[]; onApply: (visible: string[]) => void; close: () => void }): ReactNode {
  const [chosen, setChosen] = useState<readonly string[]>(visible);
  const toggle = (key: string, on: boolean): void => {
    setChosen(on ? columns.map((column) => column.key).filter((item) => item === key || chosen.includes(item)) : chosen.filter((item) => item !== key));
  };
  return (
    <Dialog scope="window" title="Columns" onCancel={close} onSubmit={() => { if (chosen.length > 0) { onApply([...chosen]); close(); } }}
      actions={<><button type="submit" className="primary" disabled={chosen.length === 0}>Apply</button><button type="button" onClick={close}>Cancel</button></>}>
      <fieldset className="checkbox-list">
        <legend>Visible columns</legend>
        {columns.map((column, index) => (
          <label key={column.key}><input type="checkbox" checked={chosen.includes(column.key)} data-autofocus={index === 0 ? true : undefined} onChange={(event) => { toggle(column.key, event.target.checked); }} /> {column.label}</label>
        ))}
      </fieldset>
      {chosen.length === 0 ? <p className="field-error" role="alert">Keep at least one column.</p> : null}
    </Dialog>
  );
}

/** Opens a window-local chooser of the grid's visible columns. */
export function ColumnsButton({ columns, visible, onChange }: { columns: readonly ViewColumn[]; visible: readonly string[]; onChange: (visible: string[]) => void }): ReactNode {
  const { dialogs } = useWindow();
  return <button type="button" onClick={() => { dialogs.show((close) => <ColumnsDialog columns={columns} visible={visible} onApply={onChange} close={close} />); }}>Columns…</button>;
}

/** Tells the operator that an opened saved search stops the result set at its limit. */
export function LimitHint({ page }: { page: LimitedPage<unknown> | undefined }): ReactNode {
  if (page?.limitedTo === null || page === undefined) return null;
  return <span className="limit-hint" data-testid="limit-hint">Limited to {page.limitedTo.toLocaleString('en-US')} of {page.matched.toLocaleString('en-US')} matches</span>;
}

/**
 * Saved searches of one entity through the shared service: open one to apply its filters, sort,
 * columns and limit; save the current view as a new search; update or delete one the operator owns.
 */
export function SavedSearchBar({ entity, columns, view, fallback, onApply }: { entity: SavedSearchEntity; columns: readonly ViewColumn[]; view: SearchView; fallback: SearchView; onApply: (view: SearchView) => void }): ReactNode {
  const { notify, session } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [selectedId, setSelectedId] = useState('');
  const list = useResource(() => getJson<SavedSearchList>(institutionPath(institutionId, `/saved-searches${queryString({ entity })}`)), `${institutionId}|${entity}`);
  const submission = useSubmission();
  const profile = session.operator.profiles[institutionId];
  const allowed = profile?.commands.includes('search.saved.create') ?? false;
  const searches = list.data?.searches ?? [];
  const selected: SavedSearchRow | undefined = searches.find((search) => search.id === selectedId);
  const vocabulary = list.data?.vocabulary;

  const openSearch = (id: string): void => {
    setSelectedId(id);
    const search = searches.find((row) => row.id === id);
    if (search?.definition === null || search === undefined || vocabulary === undefined) return;
    onApply(fromDefinition(search.definition, columns, vocabulary, fallback));
    notify(`Opened saved search “${search.name}”.`);
  };
  const report = (outcome: SubmitOutcome | null, success: string): boolean => {
    if (outcome === null) return false;
    if (outcome.kind === 'committed' || outcome.kind === 'duplicate') { notify(success); list.reload(); return true; }
    notify(outcome.message, 'error');
    list.reload();
    return false;
  };
  const save = (): void => {
    if (vocabulary === undefined) return;
    win.dialogs.show((close) => (
      <SaveSearchDialog canShare={profile?.shareSearches ?? false} close={close} onSubmit={async (name, visibility, maxResults) => {
        const outcome = await submission.submit(institutionId, { kind: 'search.saved.create', name, visibility, definition: toDefinition(entity, { ...view, maxResults }, columns, vocabulary) });
        if (outcome !== null && (outcome.kind === 'committed' || outcome.kind === 'duplicate')) {
          const created = outcome.receipt.affected.find((record) => record.kind === 'saved-search');
          if (created !== undefined) setSelectedId(created.id);
          onApply({ ...view, maxResults });
          report(outcome, `Saved search “${name}”.`);
        }
        return outcome;
      }} />
    ));
  };
  const update = async (): Promise<void> => {
    if (selected === undefined || vocabulary === undefined) return;
    report(await submission.submit(institutionId, { kind: 'search.saved.update', searchId: selected.id, expectedRevision: selected.revision, definition: toDefinition(entity, view, columns, vocabulary) }), `Updated saved search “${selected.name}”.`);
  };
  const remove = async (): Promise<void> => {
    if (selected === undefined) return;
    const choice = await choose(win.dialogs, 'window', 'Delete saved search', <p>Delete “{selected.name}”? Other operators lose it too if it is shared.</p>, [{ value: 'delete', label: 'Delete search', danger: true }], 'warning');
    if (choice !== 'delete') return;
    if (report(await submission.submit(institutionId, { kind: 'search.saved.delete', searchId: selected.id, expectedRevision: selected.revision }), `Deleted saved search “${selected.name}”.`)) setSelectedId('');
  };
  return (
    <span className="saved-searches">
      <select aria-label="Saved searches" value={selectedId} onChange={(event) => { openSearch(event.target.value); }} disabled={list.data === undefined}>
        <option value="">{list.error === null ? 'Saved searches' : 'Saved searches unavailable'}</option>
        {searches.map((search) => (
          <option key={search.id} value={search.id} disabled={search.definition === null}>
            {search.name}{search.mine ? '' : ` · ${search.owner.displayName}`}{search.visibility === 'shared' ? ' (shared)' : ''}{search.problem === null ? '' : ' (cannot open)'}
          </option>
        ))}
      </select>
      <button type="button" onClick={save} disabled={!allowed || vocabulary === undefined || submission.pending}>Save search…</button>
      <button type="button" onClick={() => { void update(); }} disabled={selected?.mine !== true || submission.pending}>Update</button>
      <button type="button" onClick={() => { void remove(); }} disabled={selected?.mine !== true || submission.pending}>Delete…</button>
    </span>
  );
}
