import { StrictMode, useCallback, useEffect, useState, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';

import type { SessionInfo } from '../shared/api';
import { ApiError, getJson } from './api';
import { Desktop } from './desktop/Desktop';

function App(): ReactNode {
  const [session, setSession] = useState<SessionInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(async () => {
    try {
      setSession(await getJson<SessionInfo>('/api/session'));
      setError(null);
    } catch (failure) {
      setError(failure instanceof ApiError ? failure.message : 'The desktop could not start.');
    }
  }, []);
  useEffect(() => { void load(); }, [load]);
  if (session === null) {
    return (
      <div className="boot" role={error === null ? 'status' : 'alert'}>
        {error === null ? 'Starting operations desktop…' : <>{error} <button type="button" onClick={() => { void load(); }}>Retry</button></>}
      </div>
    );
  }
  return <Desktop session={session} reloadSession={load} />;
}

const root = document.getElementById('root');
if (root === null) throw new Error('Missing #root element.');
createRoot(root).render(<StrictMode><App /></StrictMode>);
