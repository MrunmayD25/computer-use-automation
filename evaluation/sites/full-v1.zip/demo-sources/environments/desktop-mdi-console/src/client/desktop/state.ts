/** Window manager model: every internal window, its bounds and flags, plus explicit z-order and activation. */

export type MoneyMode = 'deposit' | 'withdraw' | 'transfer';

export type WindowSpec =
  | { kind: 'member-search' }
  | { kind: 'member'; memberId: string }
  | { kind: 'member-new' }
  | { kind: 'account-search' }
  | { kind: 'account'; accountId: string }
  | { kind: 'account-open'; memberId: string }
  | { kind: 'money'; mode: MoneyMode; accountId: string | null }
  | { kind: 'receipt'; receiptNumber: string }
  | { kind: 'case-register' }
  | { kind: 'case'; caseId: string }
  | { kind: 'case-new'; memberId: string | null; accountId: string | null }
  | { kind: 'documents' }
  | { kind: 'activity'; memberId: string | null; accountId: string | null; caseId: string | null; label: string }
  | { kind: 'operations' }
  | { kind: 'operation'; commandKind: string; prefill?: Record<string, unknown> }
  | { kind: 'finance-records'; resource: string; scope: Record<string, string>; label: string }
  | { kind: 'finance-record'; resource: string; recordId: string }
  | { kind: 'approvals' }
  | { kind: 'member-servicing'; memberId: string }
  | { kind: 'identity-resolve' }
  | { kind: 'reconciliation' }
  | { kind: 'batches' }
  | { kind: 'statements'; accountId: string; memberId: string };

export interface Bounds { x: number; y: number; width: number; height: number }

/** Business identifiers shown in the status bar for the active window. */
export interface RecordContext { member?: string; account?: string; case?: string }

export interface DesktopWindow {
  id: string;
  institutionId: string;
  spec: WindowSpec;
  title: string;
  context: RecordContext;
  bounds: Bounds;
  restoreBounds: Bounds | null;
  minimized: boolean;
  dirty: boolean;
}

export interface DesktopState {
  windows: DesktopWindow[];
  /** Window IDs from bottom to top. */
  order: string[];
  activeId: string | null;
  serial: number;
  recent: { institutionId: string; spec: WindowSpec; title: string }[];
}

export type DesktopAction =
  | { type: 'open'; institutionId: string; spec: WindowSpec; title: string; reuse: boolean; area: { width: number; height: number } }
  | { type: 'focus'; id: string }
  | { type: 'minimize'; id: string }
  | { type: 'toggle-maximize'; id: string; area: { width: number; height: number } }
  | { type: 'move'; id: string; x: number; y: number; area: { width: number; height: number } }
  | { type: 'resize'; id: string; width: number; height: number }
  | { type: 'close'; id: string }
  | { type: 'update'; id: string; title?: string; context?: RecordContext; dirty?: boolean }
  | { type: 'retarget'; id: string; spec: WindowSpec; title: string }
  | { type: 'cycle'; direction: 1 | -1 }
  | { type: 'cascade'; area: { width: number; height: number } };

export const MIN_WIDTH = 320;
export const MIN_HEIGHT = 200;

const DEFAULT_SIZES: Record<WindowSpec['kind'], { width: number; height: number }> = {
  'member-search': { width: 820, height: 460 }, member: { width: 900, height: 560 }, 'member-new': { width: 560, height: 520 },
  'account-search': { width: 900, height: 460 }, account: { width: 920, height: 580 }, 'account-open': { width: 520, height: 380 },
  money: { width: 600, height: 520 }, receipt: { width: 640, height: 540 }, 'case-register': { width: 940, height: 480 }, case: { width: 900, height: 580 },
  'case-new': { width: 600, height: 560 }, activity: { width: 860, height: 460 }, documents: { width: 980, height: 480 },
  operations: { width: 720, height: 540 }, operation: { width: 720, height: 600 }, 'finance-records': { width: 940, height: 480 },
  'finance-record': { width: 720, height: 540 }, approvals: { width: 980, height: 480 }, 'member-servicing': { width: 980, height: 560 },
  'identity-resolve': { width: 720, height: 540 }, reconciliation: { width: 1040, height: 640 }, batches: { width: 1040, height: 560 },
  statements: { width: 940, height: 620 },
};

export function specKey(institutionId: string, spec: WindowSpec): string {
  return `${institutionId}|${JSON.stringify(spec)}`;
}

export const initialDesktop: DesktopState = { windows: [], order: [], activeId: null, serial: 0, recent: [] };

function topVisible(order: readonly string[], windows: readonly DesktopWindow[], except?: string): string | null {
  for (let index = order.length - 1; index >= 0; index -= 1) {
    const id = order[index];
    if (id !== except && windows.some((item) => item.id === id && !item.minimized)) return id ?? null;
  }
  return null;
}

function raise(state: DesktopState, id: string): DesktopState {
  return { ...state, order: [...state.order.filter((item) => item !== id), id], activeId: id, windows: state.windows.map((item) => item.id === id && item.minimized ? { ...item, minimized: false } : item) };
}

function patch(state: DesktopState, id: string, change: (window: DesktopWindow) => DesktopWindow): DesktopState {
  return { ...state, windows: state.windows.map((item) => item.id === id ? change(item) : item) };
}

function clampSize(bounds: Bounds, area: { width: number; height: number }): Bounds {
  const width = Math.max(MIN_WIDTH, Math.min(bounds.width, area.width));
  const height = Math.max(MIN_HEIGHT, Math.min(bounds.height, area.height));
  return { x: Math.max(0, Math.min(bounds.x, area.width - width)), y: Math.max(0, Math.min(bounds.y, area.height - height)), width, height };
}

export function desktopReducer(state: DesktopState, action: DesktopAction): DesktopState {
  switch (action.type) {
    case 'open': {
      const key = specKey(action.institutionId, action.spec);
      const recent = [{ institutionId: action.institutionId, spec: action.spec, title: action.title }, ...state.recent.filter((item) => specKey(item.institutionId, item.spec) !== key)].slice(0, 10);
      const existing = action.reuse ? state.windows.find((item) => specKey(item.institutionId, item.spec) === key) : undefined;
      if (existing !== undefined) return { ...raise(state, existing.id), recent };
      const serial = state.serial + 1;
      const id = `w${String(serial)}`;
      const size = DEFAULT_SIZES[action.spec.kind];
      const step = (serial - 1) % 8;
      const bounds = clampSize({ x: 16 + step * 26, y: 12 + step * 26, ...size }, action.area);
      const window: DesktopWindow = { id, institutionId: action.institutionId, spec: action.spec, title: action.title, context: {}, bounds, restoreBounds: null, minimized: false, dirty: false };
      return { ...state, serial, windows: [...state.windows, window], order: [...state.order, id], activeId: id, recent };
    }
    case 'focus':
      return state.windows.some((item) => item.id === action.id) ? raise(state, action.id) : state;
    case 'minimize': {
      const next = patch(state, action.id, (item) => ({ ...item, minimized: true }));
      return { ...next, activeId: state.activeId === action.id ? topVisible(next.order, next.windows, action.id) : state.activeId };
    }
    case 'toggle-maximize':
      return raise(patch(state, action.id, (item) => item.restoreBounds === null
        ? { ...item, restoreBounds: item.bounds, bounds: { x: 0, y: 0, width: action.area.width, height: action.area.height } }
        : { ...item, bounds: item.restoreBounds, restoreBounds: null }), action.id);
    case 'move':
      return patch(state, action.id, (item) => ({
        ...item, restoreBounds: null,
        bounds: { ...item.bounds, x: Math.round(Math.max(80 - item.bounds.width, Math.min(action.x, action.area.width - 80))), y: Math.round(Math.max(0, Math.min(action.y, action.area.height - 32))) },
      }));
    case 'resize':
      return patch(state, action.id, (item) => ({ ...item, restoreBounds: null, bounds: { ...item.bounds, width: Math.round(Math.max(MIN_WIDTH, action.width)), height: Math.round(Math.max(MIN_HEIGHT, action.height)) } }));
    case 'close': {
      const windows = state.windows.filter((item) => item.id !== action.id);
      const order = state.order.filter((item) => item !== action.id);
      return { ...state, windows, order, activeId: state.activeId === action.id ? topVisible(order, windows) : state.activeId };
    }
    case 'update': {
      const current = state.windows.find((item) => item.id === action.id);
      if (current === undefined || ((action.title ?? current.title) === current.title && (action.dirty ?? current.dirty) === current.dirty
        && (action.context === undefined || JSON.stringify(action.context) === JSON.stringify(current.context)))) return state;
      return patch(state, action.id, (item) => ({
        ...item, ...(action.title === undefined ? {} : { title: action.title }), ...(action.context === undefined ? {} : { context: action.context }), ...(action.dirty === undefined ? {} : { dirty: action.dirty }),
      }));
    }
    case 'retarget':
      return patch(state, action.id, (item) => ({ ...item, spec: action.spec, title: action.title, dirty: false }));
    case 'cycle': {
      if (state.windows.length === 0) return state;
      const index = state.windows.findIndex((item) => item.id === state.activeId);
      const next = state.windows[(index + action.direction + state.windows.length) % state.windows.length];
      return next === undefined ? state : raise(state, next.id);
    }
    case 'cascade':
      return {
        ...state,
        windows: state.windows.map((item) => {
          const step = state.order.indexOf(item.id) % 10;
          return { ...item, minimized: false, restoreBounds: null, bounds: clampSize({ ...item.bounds, x: 16 + step * 26, y: 12 + step * 26 }, action.area) };
        }),
        activeId: state.activeId ?? state.order.at(-1) ?? null,
      };
  }
}
