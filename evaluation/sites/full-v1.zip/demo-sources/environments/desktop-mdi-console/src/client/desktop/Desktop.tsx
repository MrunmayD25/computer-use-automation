import { useCallback, useEffect, useMemo, useReducer, useRef, useState, type ReactNode } from 'react';

import type { Receipt } from '@computer-use/financial-database/services';

import type { SessionInfo } from '../../shared/api';
import { ApiError, getJson, institutionPath, postJson } from '../api';
import { formatDate } from '../format';
import { WindowContent } from '../modules/WindowContent';
import { SelectField, TextField } from '../widgets/fields';
import { DesktopContext, type DesktopApi } from './context';
import { choose, Dialog, useDialogHost, type DialogHost } from './Dialog';
import { ContextMenu, item, MenuBar, separator, type ContextMenuState, type MenuBarHandle, type MenuEntry } from './Menu';
import { CONTEXT_KEYS, isEditable, SHORTCUTS, shortcutLabel, type ShortcutId } from './shortcuts';
import { desktopReducer, initialDesktop, type DesktopWindow, type WindowSpec } from './state';
import { WindowFrame, type FrameHandle } from './WindowFrame';
import { Workbench } from './Workbench';

const BADGES = ['badge-a', 'badge-b', 'badge-c', 'badge-d'];
const MONEY_TITLES = { deposit: 'Cash deposit', withdraw: 'Cash withdrawal', transfer: 'Internal transfer' } as const;

export function initialTitle(spec: WindowSpec): string {
  switch (spec.kind) {
    case 'member-search': return 'Member search';
    case 'member': return 'Member';
    case 'member-new': return 'New member';
    case 'account-search': return 'Account search';
    case 'account': return 'Account';
    case 'account-open': return 'Open account';
    case 'money': return MONEY_TITLES[spec.mode];
    case 'receipt': return `Receipt ${spec.receiptNumber}`;
    case 'case-register': return 'Case register';
    case 'case': return 'Case';
    case 'case-new': return 'New case';
    case 'activity': return `Activity · ${spec.label}`;
    case 'documents': return 'Documents';
    case 'operations': return 'Operations';
    case 'operation': return 'Operation';
    case 'finance-records': return spec.label;
    case 'finance-record': return 'Record';
    case 'approvals': return 'Approvals';
    case 'member-servicing': return 'Member servicing';
    case 'identity-resolve': return 'Identity resolution';
    case 'reconciliation': return 'Reconciliation';
    case 'batches': return 'Batches';
    case 'statements': return 'Statements';
  }
}

function ShortcutHelp({ close }: { close: () => void }): ReactNode {
  return (
    <Dialog scope="desktop" title="Keyboard shortcuts" onCancel={close} onSubmit={close} width={620} actions={<button type="submit" className="primary" data-autofocus>Close</button>}>
      <table className="shortcut-table">
        <thead><tr><th scope="col">Keys</th><th scope="col">Action</th></tr></thead>
        <tbody>
          {SHORTCUTS.map((shortcut) => <tr key={shortcut.id}><td><kbd>{shortcut.keys}</kbd></td><td>{shortcut.description}</td></tr>)}
          {CONTEXT_KEYS.map((entry) => <tr key={entry.keys}><td><kbd>{entry.keys}</kbd></td><td>{entry.description}</td></tr>)}
        </tbody>
      </table>
      <p className="hint">On macOS, ⌘ works in place of Ctrl. Desktop shortcuts pause while a menu or dialog is open, and a window's shortcuts pause while that window shows a dialog.</p>
    </Dialog>
  );
}

function SignOnDialog({ session, close, reloadSession, notify }: { session: SessionInfo; close: () => void; reloadSession: () => Promise<void>; notify: (text: string) => void }): ReactNode {
  const [choice, setChoice] = useState(session.operator.actorNumber);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | undefined>(undefined);
  const submit = async (): Promise<void> => {
    setBusy(true);
    try {
      await postJson('/api/session/operator', { actorNumber: choice });
      await reloadSession();
      close();
      notify(`Signed on as ${choice}. Open drafts are kept; new submissions use this operator.`);
    } catch (failure) {
      setError(failure instanceof ApiError ? failure.message : 'Sign-on failed.');
    } finally { setBusy(false); }
  };
  return (
    <Dialog scope="desktop" title="Sign on as another operator" busy={busy} onCancel={close} onSubmit={() => { void submit(); }}
      actions={<><button type="submit" className="primary" disabled={busy}>Sign on</button><button type="button" onClick={close} disabled={busy}>Cancel</button></>}>
      <fieldset className="radio-list">
        <legend>Configured operators</legend>
        {session.operatorChoices.map((operator, index) => (
          <label key={operator.actorNumber}>
            <input type="radio" name="operator" value={operator.actorNumber} checked={choice === operator.actorNumber} data-autofocus={index === 0 ? true : undefined} onChange={() => { setChoice(operator.actorNumber); }} />
            {operator.actorNumber} · {operator.displayName} <span className="muted">({operator.roles.join(', ') || 'no roles'})</span>
          </label>
        ))}
      </fieldset>
      {error === undefined ? null : <p className="field-error" role="alert">{error}</p>}
    </Dialog>
  );
}

function FindReceiptDialog({ session, initialInstitution, close, onFound }: { session: SessionInfo; initialInstitution: string; close: () => void; onFound: (institutionId: string, receipt: Receipt) => void }): ReactNode {
  const [institutionId, setInstitutionId] = useState(initialInstitution);
  const [number, setNumber] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | undefined>(undefined);
  const submit = async (): Promise<void> => {
    const value = number.trim().toUpperCase();
    if (!/^RCP\d{8}$/u.test(value)) { setError('Enter a receipt number such as RCP00000042.'); return; }
    setBusy(true);
    try {
      const receipt = await getJson<Receipt>(institutionPath(institutionId, `/receipts/${value}`));
      close();
      onFound(institutionId, receipt);
    } catch (failure) {
      setError(failure instanceof ApiError ? failure.message : 'The receipt could not be loaded.');
    } finally { setBusy(false); }
  };
  return (
    <Dialog scope="desktop" title="Find receipt" busy={busy} onCancel={close} onSubmit={() => { void submit(); }}
      actions={<><button type="submit" className="primary" disabled={busy}>Open receipt</button><button type="button" onClick={close} disabled={busy}>Cancel</button></>}>
      <SelectField label="Institution" value={institutionId} onChange={setInstitutionId} options={session.institutions.map((item) => ({ value: item.institutionId, label: item.displayName }))} />
      <TextField label="Receipt number" value={number} onChange={(value) => { setNumber(value); setError(undefined); }} error={error} autoFocus placeholder="RCP00000042" />
    </Dialog>
  );
}

/** The desktop shell: menu bar, window layer with z-order, taskbar, status bar, desktop dialogs and shortcuts. */
export function Desktop({ session, reloadSession }: { session: SessionInfo; reloadSession: () => Promise<void> }): ReactNode {
  const [state, dispatch] = useReducer(desktopReducer, initialDesktop);
  const stateRef = useRef(state);
  stateRef.current = state;
  const layer = useRef<HTMLElement>(null);
  const menuBar = useRef<MenuBarHandle>(null);
  const frames = useRef(new Map<string, FrameHandle>());
  const dialogs: DialogHost = useDialogHost();
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null);
  const [message, setMessage] = useState<{ text: string; tone: 'info' | 'error' } | null>(null);
  const [working, setWorking] = useState(session.institutions[0]?.institutionId ?? '');
  const desktopDialogOpen = useRef(false);
  desktopDialogOpen.current = dialogs.open;

  const area = useCallback(() => {
    const rect = layer.current?.getBoundingClientRect();
    return { width: Math.max(480, Math.floor(rect?.width ?? 1280)), height: Math.max(320, Math.floor(rect?.height ?? 720)) };
  }, []);
  const institution = useCallback((institutionId: string) => {
    const found = session.institutions.find((entry) => entry.institutionId === institutionId);
    if (found === undefined) throw new Error(`Unknown institution ${institutionId}.`);
    return found;
  }, [session]);
  const badgeClass = (institutionId: string): string => BADGES[session.institutions.findIndex((entry) => entry.institutionId === institutionId) % BADGES.length] ?? 'badge-a';
  const open = useCallback((institutionId: string, spec: WindowSpec, options: { reuse?: boolean } = {}) => {
    dispatch({ type: 'open', institutionId, spec, title: initialTitle(spec), reuse: options.reuse ?? true, area: area() });
  }, [area]);
  const can = useCallback((institutionId: string, commandKind: string) => {
    const profile = session.operator.profiles[institutionId];
    return profile?.commands.includes(commandKind) ?? false;
  }, [session]);
  const notify = useCallback((text: string, tone: 'info' | 'error' = 'info') => { setMessage({ text, tone }); }, []);
  const register = useCallback((id: string, handle: FrameHandle | null) => { if (handle === null) frames.current.delete(id); else frames.current.set(id, handle); }, []);
  const openContextMenu = useCallback((x: number, y: number, label: string, entries: readonly MenuEntry[], returnFocus: HTMLElement | null) => { setContextMenu({ x, y, label, entries, returnFocus }); }, []);
  const api = useMemo<DesktopApi>(() => ({ session, institution, open, can, notify, openContextMenu, dialogs }), [session, institution, open, can, notify, openContextMenu, dialogs]);

  const withActive = useCallback((action: (frame: FrameHandle, window: DesktopWindow) => void) => {
    const current = stateRef.current;
    const window = current.windows.find((entry) => entry.id === current.activeId);
    const frame = window === undefined ? undefined : frames.current.get(window.id);
    if (window === undefined || frame === undefined) { notify('No window is active.'); return; }
    action(frame, window);
  }, [notify]);

  const showShortcuts = useCallback(() => { dialogs.show((close) => <ShortcutHelp close={close} />); }, [dialogs]);
  const showSignOn = useCallback(() => {
    dialogs.show((close) => <SignOnDialog session={session} close={close} reloadSession={reloadSession} notify={notify} />);
  }, [dialogs, notify, reloadSession, session]);
  const showFindReceipt = useCallback(() => {
    dialogs.show((close) => <FindReceiptDialog session={session} initialInstitution={working} close={close} onFound={(institutionId, receipt) => { open(institutionId, { kind: 'receipt', receiptNumber: receipt.receiptNumber }); }} />);
  }, [dialogs, open, session, working]);
  const showAbout = useCallback(() => {
    dialogs.show((close) => (
      <Dialog scope="desktop" title="About this desktop" onCancel={close} onSubmit={close} actions={<button type="submit" className="primary" data-autofocus>Close</button>}>
        <p>Operations desktop {session.applicationVersion} · {session.mode === 'verification' ? 'verification run (operator fixed by the evaluator backend)' : 'shared institution data'}.</p>
        <ul>{session.institutions.map((entry) => <li key={entry.institutionId}>{entry.displayName} ({entry.legalName}) · {entry.timeZone} · business date {formatDate(entry.asOf)}</li>)}</ul>
      </Dialog>
    ));
  }, [dialogs, session]);

  const closeAll = useCallback(async () => {
    const held = (window: DesktopWindow): boolean => frames.current.get(window.id)?.hasDialog() === true || frames.current.get(window.id)?.isBusy() === true;
    const dirty = stateRef.current.windows.filter((window) => window.dirty && !held(window));
    if (dirty.length > 0) {
      const choice = await choose(dialogs, 'desktop', 'Close all windows', (
        <><p>These windows have unsaved changes:</p><ul>{dirty.map((window) => <li key={window.id}>{window.title} ({institution(window.institutionId).displayName})</li>)}</ul></>
      ), [{ value: 'close', label: 'Discard changes and close all', danger: true }], 'warning');
      if (choice !== 'close') return;
    }
    const kept = stateRef.current.windows.filter(held);
    for (const window of stateRef.current.windows) if (!held(window)) dispatch({ type: 'close', id: window.id });
    if (kept.length > 0) notify(`Kept ${kept.map((window) => window.title).join(', ')} open: an open dialog or a request in progress must finish first.`);
  }, [dialogs, institution, notify]);

  const run = useCallback((id: ShortcutId) => {
    switch (id) {
      case 'save': withActive((frame) => { void frame.save(); }); break;
      case 'print': withActive((frame) => { frame.print(); }); break;
      case 'refresh': withActive((frame, window) => { frame.refresh(); notify(`Refreshed ${window.title}.`); }); break;
      case 'close': withActive((frame) => { void frame.requestClose(); }); break;
      case 'minimize': withActive((_frame, window) => { dispatch({ type: 'minimize', id: window.id }); }); break;
      case 'focus-search': withActive((frame) => { frame.focusSearch(); }); break;
      case 'next-window': dispatch({ type: 'cycle', direction: 1 }); break;
      case 'previous-window': dispatch({ type: 'cycle', direction: -1 }); break;
      case 'menu': menuBar.current?.focus(); break;
      case 'shortcuts': showShortcuts(); break;
      case 'find-member': open(working, { kind: 'member-search' }); break;
      case 'find-account': open(working, { kind: 'account-search' }); break;
    }
  }, [notify, open, showShortcuts, withActive, working]);
  const runRef = useRef(run);
  runRef.current = run;

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent): void => {
      const shortcut = SHORTCUTS.find((entry) => entry.matches(event));
      if (shortcut === undefined) return;
      if (shortcut.id === 'save' || shortcut.id === 'print') event.preventDefault();
      // Focus decides first: the menu-open flag reaches this handler one render late.
      if (event.target instanceof Element && event.target.closest('[aria-modal="true"],[role="menu"],[role="menubar"]') !== null) return;
      if (desktopDialogOpen.current) return;
      if (!shortcut.inEditable && isEditable(event.target)) return;
      if (shortcut.scope === 'window') {
        const current = stateRef.current;
        if (current.activeId !== null && frames.current.get(current.activeId)?.hasDialog() === true) return;
      }
      event.preventDefault();
      runRef.current(shortcut.id);
    };
    const onBeforeUnload = (event: BeforeUnloadEvent): void => { if (stateRef.current.windows.some((window) => window.dirty)) event.preventDefault(); };
    document.addEventListener('keydown', onKeyDown);
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => { document.removeEventListener('keydown', onKeyDown); window.removeEventListener('beforeunload', onBeforeUnload); };
  }, []);

  const active = state.windows.find((window) => window.id === state.activeId) ?? null;
  const contextInstitution = active?.institutionId ?? working;
  const profile = session.operator.profiles[contextInstitution] ?? null;
  const w = working;
  const menus = [
    { label: 'Desktop', entries: [
      item('Sign on as another operator…', showSignOn, { disabled: session.operatorChoices.length === 0 }),
      separator,
      { kind: 'heading', label: 'New windows open in' } as const,
      ...session.institutions.map((entry) => item(entry.displayName, () => { setWorking(entry.institutionId); notify(`New windows now open in ${entry.displayName}.`); }, { checked: entry.institutionId === w })),
      separator,
      item('Cascade windows', () => { dispatch({ type: 'cascade', area: area() }); }),
      item('Close all windows…', () => { void closeAll(); }, { disabled: state.windows.length === 0 }),
    ] },
    { label: 'Members', entries: [
      item('Find member…', () => { open(w, { kind: 'member-search' }); }, { shortcut: shortcutLabel('find-member') }),
      item('Find member in a new window', () => { open(w, { kind: 'member-search' }, { reuse: false }); }),
      separator,
      item('New member…', () => { open(w, { kind: 'member-new' }, { reuse: false }); }, { disabled: !can(w, 'member.create') }),
    ] },
    { label: 'Accounts', entries: [
      item('Find account…', () => { open(w, { kind: 'account-search' }); }, { shortcut: shortcutLabel('find-account') }),
      item('Find account in a new window', () => { open(w, { kind: 'account-search' }, { reuse: false }); }),
      separator,
      item('Statements and documents', () => { open(w, { kind: 'documents' }); }),
    ] },
    { label: 'Money', entries: [
      item('Cash deposit…', () => { open(w, { kind: 'money', mode: 'deposit', accountId: null }, { reuse: false }); }, { disabled: !can(w, 'cash.deposit') }),
      item('Cash withdrawal…', () => { open(w, { kind: 'money', mode: 'withdraw', accountId: null }, { reuse: false }); }, { disabled: !can(w, 'cash.withdraw') }),
      item('Internal transfer…', () => { open(w, { kind: 'money', mode: 'transfer', accountId: null }, { reuse: false }); }, { disabled: !can(w, 'transfer.internal') }),
      separator,
      item('Payments…', () => { open(w, { kind: 'finance-records', resource: 'payment', scope: {}, label: 'Payments' }); }),
      item('Beneficiaries…', () => { open(w, { kind: 'finance-records', resource: 'beneficiary', scope: {}, label: 'Beneficiaries' }); }),
      item('Cards…', () => { open(w, { kind: 'finance-records', resource: 'card', scope: {}, label: 'Cards' }); }),
      item('Disputes…', () => { open(w, { kind: 'finance-records', resource: 'dispute', scope: {}, label: 'Disputes' }); }),
      item('Loans…', () => { open(w, { kind: 'finance-records', resource: 'loan', scope: {}, label: 'Loans' }); }),
      separator,
      item('Find receipt…', showFindReceipt),
    ] },
    { label: 'Servicing', entries: [
      item('Case register', () => { open(w, { kind: 'case-register' }); }),
      item('New case…', () => { open(w, { kind: 'case-new', memberId: null, accountId: null }, { reuse: false }); }, { disabled: !can(w, 'case.open') }),
      separator,
      item('Identity resolution…', () => { open(w, { kind: 'identity-resolve' }); }),
      item('Approvals', () => { open(w, { kind: 'approvals' }); }),
      item('Reconciliation', () => { open(w, { kind: 'reconciliation' }); }),
      item('Batches', () => { open(w, { kind: 'batches' }); }),
      separator,
      item('Activity and audit', () => { open(w, { kind: 'activity', memberId: null, accountId: null, caseId: null, label: 'All activity' }); }),
      item('Operations catalog', () => { open(w, { kind: 'operations' }); }),
    ] },
    { label: 'Window', entries: [
      item('Save', () => { run('save'); }, { shortcut: shortcutLabel('save'), disabled: active === null }),
      item('Refresh', () => { run('refresh'); }, { shortcut: shortcutLabel('refresh'), disabled: active === null }),
      item('Print', () => { run('print'); }, { shortcut: shortcutLabel('print'), disabled: active === null }),
      item('Minimize', () => { run('minimize'); }, { shortcut: shortcutLabel('minimize'), disabled: active === null }),
      item('Close', () => { run('close'); }, { shortcut: shortcutLabel('close'), disabled: active === null }),
      separator,
      item('Next window', () => { run('next-window'); }, { shortcut: shortcutLabel('next-window'), disabled: state.windows.length === 0 }),
      item('Previous window', () => { run('previous-window'); }, { shortcut: shortcutLabel('previous-window'), disabled: state.windows.length === 0 }),
      ...(state.windows.length === 0 ? [] : [separator, { kind: 'heading', label: 'Open windows' } as const,
        ...state.windows.map((window) => item(`${window.title} · ${institution(window.institutionId).displayName}${window.minimized ? ' (minimized)' : ''}`, () => { dispatch({ type: 'focus', id: window.id }); }, { checked: window.id === state.activeId }))]),
      ...(state.recent.length === 0 ? [] : [separator, { kind: 'heading', label: 'Recently opened' } as const,
        ...state.recent.map((entry) => item(`${entry.title} · ${institution(entry.institutionId).displayName}`, () => { open(entry.institutionId, entry.spec); }))]),
    ] },
    { label: 'Help', entries: [
      item('Keyboard shortcuts', showShortcuts, { shortcut: shortcutLabel('shortcuts') }),
      item('About this desktop', showAbout),
    ] },
  ] satisfies { label: string; entries: MenuEntry[] }[];

  const visible = state.windows.filter((window) => !window.minimized);
  return (
    <DesktopContext.Provider value={api}>
      <div className="desktop-root">
        <div className="desktop-chrome" inert={dialogs.open}>
          <header className="topbar">
            <MenuBar menus={menus} handle={menuBar} />
            <div className="topbar-context">
              <label className="working-institution">New windows open in{' '}
                <select value={working} onChange={(event) => { setWorking(event.target.value); }}>
                  {session.institutions.map((entry) => <option key={entry.institutionId} value={entry.institutionId}>{entry.displayName}</option>)}
                </select>
              </label>
              {session.mode === 'verification' ? <span className="mode-badge">Verification run</span> : null}
              <button type="button" className="operator-button" onClick={showSignOn} disabled={session.operatorChoices.length === 0} title="Sign on as another operator">
                {session.operator.actorNumber} · {profile?.displayName ?? 'not registered here'}
              </button>
            </div>
          </header>
          <main ref={layer} className="window-layer" aria-label="Desktop workspace">
            {visible.length === 0 ? <Workbench institutionId={working} recent={state.recent} /> : null}
            {state.windows.map((window) => (
              <WindowFrame
                key={window.id} window={window} zIndex={10 + state.order.indexOf(window.id)} active={window.id === state.activeId && !window.minimized}
                institution={institution(window.institutionId)} badgeClass={badgeClass(window.institutionId)} dispatch={dispatch} area={area} register={register} notify={notify}
              >
                <WindowContent spec={window.spec} />
              </WindowFrame>
            ))}
          </main>
          <nav className="taskbar" aria-label="Open windows">
            {state.windows.map((window) => (
              <button
                key={window.id} type="button" aria-pressed={window.id === state.activeId && !window.minimized} className={`task${window.minimized ? ' task-minimized' : ''}`}
                title={`${window.title} · ${institution(window.institutionId).displayName}`}
                onClick={() => { dispatch(window.id === state.activeId && !window.minimized ? { type: 'minimize', id: window.id } : { type: 'focus', id: window.id }); }}
                onContextMenu={(event) => {
                  event.preventDefault();
                  openContextMenu(event.clientX, event.clientY - 90, `${window.title} window`, [
                    item(window.minimized ? 'Restore' : 'Bring to front', () => { dispatch({ type: 'focus', id: window.id }); }),
                    item('Minimize', () => { dispatch({ type: 'minimize', id: window.id }); }, { disabled: window.minimized }),
                    separator,
                    item('Close', () => { void frames.current.get(window.id)?.requestClose(); }),
                  ], event.currentTarget);
                }}
              >
                <span className={`institution-dot ${badgeClass(window.institutionId)}`} aria-hidden="true" />
                {window.title}{window.dirty ? ' •' : ''}
              </button>
            ))}
          </nav>
          <footer className="statusbar" aria-label="Active context">
            <span data-testid="status-operator">Operator {session.operator.actorNumber} · {profile === null ? 'not registered here' : `${profile.displayName} (${profile.roles.join(', ') || 'no roles'})`}</span>
            <span data-testid="status-window">Window: {active === null ? 'none' : active.title}</span>
            <span data-testid="status-institution">Institution: {institution(contextInstitution).displayName}</span>
            {active?.context.member === undefined ? null : <span data-testid="status-member">Member: {active.context.member}</span>}
            {active?.context.account === undefined ? null : <span data-testid="status-account">Account: {active.context.account}</span>}
            {active?.context.case === undefined ? null : <span data-testid="status-case">Case: {active.context.case}</span>}
            <span>Business date: {formatDate(institution(contextInstitution).asOf)}</span>
            <output className={`status-message${message?.tone === 'error' ? ' status-error' : ''}`} aria-live="polite">{message?.text ?? ''}</output>
          </footer>
        </div>
        {dialogs.node}
        {contextMenu === null ? null : <ContextMenu state={contextMenu} onDismiss={() => { setContextMenu(null); }} />}
      </div>
    </DesktopContext.Provider>
  );
}
