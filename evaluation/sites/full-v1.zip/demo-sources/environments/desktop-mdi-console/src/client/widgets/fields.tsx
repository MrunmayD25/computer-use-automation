import { useId, type ReactNode, type Ref } from 'react';

import type { ApiError } from '../api';

interface FieldFrameProps { label: string; error?: string | undefined; hint?: string | undefined; children: (props: { id: string; describedBy: string | undefined; invalid: boolean }) => ReactNode; wide?: boolean }

function FieldFrame({ label, error, hint, children, wide = false }: FieldFrameProps): ReactNode {
  const id = useId();
  const messageId = `${id}-message`;
  const message = error ?? hint;
  return (
    <div className={`field${wide ? ' field-wide' : ''}${error === undefined ? '' : ' field-invalid'}`}>
      <label htmlFor={id}>{label}</label>
      {children({ id, describedBy: message === undefined ? undefined : messageId, invalid: error !== undefined })}
      {message === undefined ? null : <span id={messageId} className={error === undefined ? 'field-hint' : 'field-error'} role={error === undefined ? undefined : 'alert'}>{message}</span>}
    </div>
  );
}

interface TextFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string | undefined;
  hint?: string | undefined;
  type?: 'text' | 'email' | 'tel' | 'date' | 'search';
  maxLength?: number;
  required?: boolean;
  readOnly?: boolean;
  placeholder?: string;
  inputMode?: 'decimal' | 'text';
  name?: string;
  inputRef?: Ref<HTMLInputElement>;
  autoFocus?: boolean;
  wide?: boolean;
  changed?: boolean;
}

export function TextField({ label, value, onChange, error, hint, type = 'text', maxLength, required = false, readOnly = false, placeholder, inputMode, name, inputRef, autoFocus = false, wide = false, changed = false }: TextFieldProps): ReactNode {
  return (
    <FieldFrame label={`${label}${required ? ' *' : ''}`} error={error} hint={hint} wide={wide}>
      {({ id, describedBy, invalid }) => (
        <input
          id={id} ref={inputRef} name={name} type={type} value={value} maxLength={maxLength} required={required} readOnly={readOnly} placeholder={placeholder} inputMode={inputMode}
          aria-invalid={invalid} aria-describedby={describedBy} data-autofocus={autoFocus ? true : undefined} className={changed ? 'changed' : undefined}
          onChange={(event) => { onChange(event.target.value); }}
        />
      )}
    </FieldFrame>
  );
}

export function TextAreaField({ label, value, onChange, error, hint, maxLength, required = false, rows = 4, name }: { label: string; value: string; onChange: (value: string) => void; error?: string | undefined; hint?: string | undefined; maxLength?: number; required?: boolean; rows?: number; name?: string }): ReactNode {
  return (
    <FieldFrame label={`${label}${required ? ' *' : ''}`} error={error} hint={hint} wide>
      {({ id, describedBy, invalid }) => (
        <textarea id={id} name={name} value={value} rows={rows} maxLength={maxLength} required={required} aria-invalid={invalid} aria-describedby={describedBy} onChange={(event) => { onChange(event.target.value); }} />
      )}
    </FieldFrame>
  );
}

export interface Option { value: string; label: string; disabled?: boolean }

export function SelectField({ label, value, onChange, options, error, hint, required = false, name, changed = false, wide = false }: { label: string; value: string; onChange: (value: string) => void; options: readonly Option[]; error?: string | undefined; hint?: string | undefined; required?: boolean; name?: string; changed?: boolean; wide?: boolean }): ReactNode {
  return (
    <FieldFrame label={`${label}${required ? ' *' : ''}`} error={error} hint={hint} wide={wide}>
      {({ id, describedBy, invalid }) => (
        <select id={id} name={name} value={value} aria-invalid={invalid} aria-describedby={describedBy} className={changed ? 'changed' : undefined} onChange={(event) => { onChange(event.target.value); }}>
          {options.map((option) => <option key={option.value} value={option.value} disabled={option.disabled}>{option.label}</option>)}
        </select>
      )}
    </FieldFrame>
  );
}

export function Banner({ tone, title, children, actions }: { tone: 'info' | 'warning' | 'error' | 'success'; title?: string; children?: ReactNode; actions?: ReactNode }): ReactNode {
  return (
    <div className={`banner banner-${tone}`} role={tone === 'error' || tone === 'warning' ? 'alert' : 'status'}>
      <div className="banner-text">{title === undefined ? null : <strong>{title} </strong>}{children}</div>
      {actions === undefined ? null : <div className="banner-actions">{actions}</div>}
    </div>
  );
}

export function LoadFailure({ error, onRetry }: { error: ApiError; onRetry: () => void }): ReactNode {
  return <Banner tone="error" title="Could not load." actions={<button type="button" onClick={onRetry}>Retry</button>}>{error.message}</Banner>;
}

export function Loading({ label = 'Loading…' }: { label?: string }): ReactNode {
  return <div className="loading" role="status" aria-live="polite"><span className="spinner" aria-hidden="true" />{label}</div>;
}

export function Toolbar({ label, children }: { label: string; children: ReactNode }): ReactNode {
  return <div className="toolbar" role="toolbar" aria-label={label}>{children}</div>;
}

export function DetailList({ items }: { items: readonly (readonly [string, ReactNode])[] }): ReactNode {
  return (
    <dl className="detail-list">
      {items.map(([term, value]) => <div key={term} className="detail-row"><dt>{term}</dt><dd>{value === '' || value === null ? '—' : value}</dd></div>)}
    </dl>
  );
}
