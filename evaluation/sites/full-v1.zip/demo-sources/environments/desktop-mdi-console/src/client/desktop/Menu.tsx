import { useEffect, useImperativeHandle, useLayoutEffect, useRef, useState, type KeyboardEvent, type ReactNode, type Ref } from 'react';

export type MenuEntry =
  | { kind: 'item'; label: string; shortcut?: string; disabled?: boolean; checked?: boolean; onSelect: () => void }
  | { kind: 'separator' }
  | { kind: 'heading'; label: string };

export const item = (label: string, onSelect: () => void, options: { shortcut?: string; disabled?: boolean; checked?: boolean } = {}): MenuEntry => ({ kind: 'item', label, onSelect, ...options });
export const separator: MenuEntry = { kind: 'separator' };

type CloseReason = 'escape' | 'select' | 'tab' | 'outside';

interface MenuListProps {
  label: string;
  entries: readonly MenuEntry[];
  onClose: (reason: CloseReason) => void;
  /** Left/right arrow from a menubar dropdown moves to the neighbouring menu. */
  onNavigate?: (direction: 1 | -1) => void;
  style?: React.CSSProperties;
  className?: string;
}

/** A vertical menu that focuses its first enabled item and supports arrow, Home/End, Enter and Escape keys. */
export function MenuList({ label, entries, onClose, onNavigate, style, className }: MenuListProps): ReactNode {
  const ref = useRef<HTMLUListElement>(null);
  const items = (): HTMLElement[] => [...(ref.current?.querySelectorAll<HTMLElement>('[role="menuitem"]:not([aria-disabled="true"]),[role="menuitemcheckbox"]:not([aria-disabled="true"])') ?? [])];
  useEffect(() => { items()[0]?.focus(); }, []);
  const select = (entry: MenuEntry): void => {
    if (entry.kind !== 'item' || entry.disabled === true) return;
    onClose('select');
    entry.onSelect();
  };
  const onKeyDown = (event: KeyboardEvent<HTMLUListElement>): void => {
    const list = items();
    const index = list.indexOf(document.activeElement as HTMLElement);
    const focus = (next: number): void => { list[(next + list.length) % list.length]?.focus(); };
    switch (event.key) {
      case 'ArrowDown': focus(index + 1); break;
      case 'ArrowUp': focus(index - 1); break;
      case 'Home': focus(0); break;
      case 'End': focus(list.length - 1); break;
      case 'Escape': onClose('escape'); break;
      case 'Tab': onClose('tab'); return;
      case 'ArrowRight': if (onNavigate === undefined) return; onNavigate(1); break;
      case 'ArrowLeft': if (onNavigate === undefined) return; onNavigate(-1); break;
      default: return;
    }
    event.preventDefault();
    event.stopPropagation();
  };
  return (
    <ul ref={ref} role="menu" aria-label={label} className={`menu ${className ?? ''}`} style={style} onKeyDown={onKeyDown}>
      {entries.map((entry, index) => {
        if (entry.kind === 'separator') return <li key={`s${String(index)}`} role="separator" className="menu-separator" />;
        if (entry.kind === 'heading') return <li key={`h${String(index)}`} role="presentation" className="menu-heading">{entry.label}</li>;
        return (
          <li
            key={`${entry.label}${String(index)}`} role={entry.checked === undefined ? 'menuitem' : 'menuitemcheckbox'} aria-checked={entry.checked} tabIndex={-1}
            aria-disabled={entry.disabled === true ? true : undefined} aria-keyshortcuts={entry.shortcut} className="menu-item"
            onClick={() => { select(entry); }} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); event.stopPropagation(); select(entry); } }}
            onPointerEnter={(event) => { if (entry.disabled !== true) event.currentTarget.focus(); }}
          >
            <span className="menu-check" aria-hidden="true">{entry.checked === true ? '✓' : ''}</span>
            <span className="menu-label">{entry.label}</span>
            {entry.shortcut === undefined ? null : <span className="menu-shortcut" aria-hidden="true">{entry.shortcut}</span>}
          </li>
        );
      })}
    </ul>
  );
}

export interface MenuBarHandle { focus(): void }

export interface MenuBarProps {
  menus: readonly { label: string; entries: readonly MenuEntry[] }[];
  handle: Ref<MenuBarHandle>;
}

/** Application menu bar with roving focus; F10 enters it and Escape returns focus to where the operator was. */
export function MenuBar({ menus, handle }: MenuBarProps): ReactNode {
  const [open, setOpen] = useState<number | null>(null);
  const [focusIndex, setFocusIndex] = useState(0);
  const buttons = useRef<(HTMLButtonElement | null)[]>([]);
  const root = useRef<HTMLDivElement>(null);
  const restore = useRef<HTMLElement | null>(null);
  const rememberOrigin = (): void => {
    const active = document.activeElement;
    if (active instanceof HTMLElement && root.current?.contains(active) !== true) restore.current = active;
  };
  useImperativeHandle(handle, () => ({ focus() { rememberOrigin(); setFocusIndex(0); buttons.current[0]?.focus(); } }));
  useEffect(() => {
    if (open === null) return undefined;
    const onPointer = (event: PointerEvent): void => { if (!(event.target instanceof Node) || root.current?.contains(event.target) !== true) setOpen(null); };
    document.addEventListener('pointerdown', onPointer, true);
    return () => { document.removeEventListener('pointerdown', onPointer, true); };
  }, [open]);
  const leave = (): void => {
    const target = restore.current;
    restore.current = null;
    if (target?.isConnected === true && target.closest('[inert]') === null) target.focus();
    // Focus that came from the page body cannot be handed back by focus(); leave the menu bar explicitly.
    const current = document.activeElement;
    if (current instanceof HTMLElement && root.current?.contains(current) === true) current.blur();
  };
  const move = (index: number, openMenu: boolean): void => {
    const next = (index + menus.length) % menus.length;
    setFocusIndex(next);
    if (openMenu) setOpen(next); else buttons.current[next]?.focus();
  };
  return (
    <div ref={root} role="menubar" aria-label="Desktop menu" className="menubar">
      {menus.map((menu, index) => (
        <div key={menu.label} className="menubar-entry">
          <button
            ref={(node) => { buttons.current[index] = node; }} type="button" role="menuitem" aria-haspopup="menu" aria-expanded={open === index}
            tabIndex={index === focusIndex ? 0 : -1} className={open === index ? 'open' : ''}
            onFocus={() => { rememberOrigin(); setFocusIndex(index); }}
            onClick={() => { rememberOrigin(); setOpen(open === index ? null : index); }}
            onPointerEnter={() => { if (open !== null && open !== index) setOpen(index); }}
            onKeyDown={(event) => {
              switch (event.key) {
                case 'ArrowRight': move(index + 1, false); break;
                case 'ArrowLeft': move(index - 1, false); break;
                case 'ArrowDown': case 'Enter': case ' ': setOpen(index); break;
                case 'Escape': leave(); break;
                default: return;
              }
              event.preventDefault();
            }}
          >{menu.label}</button>
          {open === index ? (
            <MenuList
              label={menu.label} entries={menu.entries} className="menubar-dropdown"
              onNavigate={(direction) => { move(index + direction, true); }}
              onClose={(reason) => {
                setOpen(null);
                if (reason === 'escape') buttons.current[index]?.focus();
                else if (reason === 'select') leave();
              }}
            />
          ) : null}
        </div>
      ))}
    </div>
  );
}

export interface ContextMenuState { x: number; y: number; label: string; entries: readonly MenuEntry[]; returnFocus: HTMLElement | null }

/** Floating context menu clamped to the viewport; closing restores focus to its invoker. */
export function ContextMenu({ state, onDismiss }: { state: ContextMenuState; onDismiss: () => void }): ReactNode {
  const ref = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState({ left: state.x, top: state.y });
  useLayoutEffect(() => {
    const node = ref.current;
    if (node === null) return;
    const rect = node.getBoundingClientRect();
    setPosition({ left: Math.max(0, Math.min(state.x, window.innerWidth - rect.width - 4)), top: Math.max(0, Math.min(state.y, window.innerHeight - rect.height - 4)) });
  }, [state.x, state.y]);
  useEffect(() => {
    const onPointer = (event: PointerEvent): void => { if (!(event.target instanceof Node) || ref.current?.contains(event.target) !== true) onDismiss(); };
    document.addEventListener('pointerdown', onPointer, true);
    return () => { document.removeEventListener('pointerdown', onPointer, true); };
  }, [onDismiss]);
  return (
    <div ref={ref} className="context-menu" style={position}>
      <MenuList label={state.label} entries={state.entries} onClose={(reason) => {
        onDismiss();
        if (reason !== 'outside' && state.returnFocus?.isConnected === true) state.returnFocus.focus();
      }} />
    </div>
  );
}
