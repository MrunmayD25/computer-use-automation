import { createContext, useContext, useEffect } from 'react';

import type { InstitutionInfo, SessionInfo } from '../../shared/api';
import type { DialogHost } from './Dialog';
import type { MenuEntry } from './Menu';
import type { RecordContext, WindowSpec } from './state';

/** Actions a window's content exposes to the desktop's repeated Save, Refresh, Print and search commands. */
export interface WindowCommands {
  /** Resolves true when the window has nothing left to save. */
  save?: () => Promise<boolean>;
  refresh?: () => void;
  print?: () => void;
  focusSearch?: () => void;
}

export interface DesktopApi {
  session: SessionInfo;
  institution: (institutionId: string) => InstitutionInfo;
  /** Opens a window, focusing an identical one unless `reuse` is false. */
  open: (institutionId: string, spec: WindowSpec, options?: { reuse?: boolean }) => void;
  /** True when the signed-on operator may run the command kind at the institution. */
  can: (institutionId: string, commandKind: string) => boolean;
  notify: (text: string, tone?: 'info' | 'error') => void;
  openContextMenu: (x: number, y: number, label: string, entries: readonly MenuEntry[], returnFocus: HTMLElement | null) => void;
  dialogs: DialogHost;
}

export interface WindowApi {
  id: string;
  institution: InstitutionInfo;
  spec: WindowSpec;
  active: boolean;
  /** Window-local modal host: it blocks only this window. */
  dialogs: DialogHost;
  setTitle: (title: string) => void;
  setContext: (context: RecordContext) => void;
  setDirty: (dirty: boolean) => void;
  /** Switches the window to another record of the same kind. */
  retarget: (spec: WindowSpec, title: string) => void;
  requestClose: () => void;
  setCommands: (commands: WindowCommands) => void;
  /** Marks a request of this window as in flight until the returned release runs; the window refuses to close meanwhile. */
  holdBusy: () => () => void;
}

export const DesktopContext = createContext<DesktopApi | null>(null);
export const WindowContext = createContext<WindowApi | null>(null);

export function useDesktop(): DesktopApi {
  const value = useContext(DesktopContext);
  if (value === null) throw new Error('useDesktop must be used inside the desktop.');
  return value;
}

export function useWindow(): WindowApi {
  const value = useContext(WindowContext);
  if (value === null) throw new Error('useWindow must be used inside a window.');
  return value;
}

/** Publishes the latest command handlers of a window on every render. */
export function useWindowCommands(commands: WindowCommands): void {
  const { setCommands } = useWindow();
  useEffect(() => { setCommands(commands); });
}

/** Holds the owning window busy while `pending` is true, so closing it cannot discard the request's outcome. */
export function useBusyWhile(pending: boolean): void {
  const { holdBusy } = useWindow();
  useEffect(() => (pending ? holdBusy() : undefined), [holdBusy, pending]);
}

/** Keeps the window title, status-bar context and dirty flag in step with the content. */
export function useWindowChrome(title: string, context: RecordContext, dirty: boolean): void {
  const { setTitle, setContext, setDirty } = useWindow();
  useEffect(() => { setTitle(title); }, [setTitle, title]);
  const contextKey = JSON.stringify(context);
  useEffect(() => { setContext(JSON.parse(contextKey) as RecordContext); }, [setContext, contextKey]);
  useEffect(() => { setDirty(dirty); }, [setDirty, dirty]);
}
