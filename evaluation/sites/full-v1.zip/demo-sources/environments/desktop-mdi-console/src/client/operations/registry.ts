/**
 * Operation registry: a declarative description of every business command the desktop can
 * review and execute. Bespoke windows (member/account/money/case) keep their dedicated forms;
 * this registry covers the full finance, servicing and approval surface plus a catalog entry
 * point so every capability is independently reachable through an ordinary window.
 */

import type { FinanceListKind } from '@computer-use/financial-database/services';

/** Loose draft map: keys are command field names, values are what each field kind produces. */
export type DraftValues = Record<string, unknown>;

export type FieldKind =
  | 'text' | 'textarea' | 'date' | 'datetime' | 'int' | 'money' | 'boolean' | 'select' | 'list' | 'nullable'
  | 'member' | 'account' | 'case' | 'queue' | 'policy' | 'checker' | 'approval' | 'evidence' | 'consent'
  | 'doc-version' | 'address-dest' | 'maint-request' | 'comm-job' | 'finance' | 'merge-plan'
  | 'address' | 'owners' | 'excerpts' | 'region' | 'maint-command' | 'maint-patch' | 'command-target' | 'file';

export interface FieldSpec {
  /** Command field name. Picker fields also write their bound companions (see `binds`). */
  name: string;
  label: string;
  kind: FieldKind;
  /** Optional fields are omitted from the command when left blank. */
  optional?: boolean | undefined;
  /** Blank produces explicit null instead of omitting the field. */
  nullable?: boolean | undefined;
  /** Value provides picker context and binds but is not itself emitted in the command. */
  contextOnly?: boolean | undefined;
  options?: readonly string[] | undefined;
  /** Show this field only when the predicate holds for the current draft. */
  when?: ((values: DraftValues) => boolean) | undefined;
  help?: string | undefined;
  /** Finance list resource for `finance` pickers. */
  resource?: FinanceListKind | undefined;
  /** Scope key and the draft field whose selected id scopes the list. */
  scopeKey?: 'memberId' | 'accountId' | 'caseId' | 'batchId' | 'scheduleId' | 'cardId' | 'paymentId' | 'beneficiaryId' | 'disputeId' | 'loanId' | 'settlementBatchId' | 'businessDate' | undefined;
  scopeFrom?: string | undefined;
  /** Member-scoped pickers read this draft field for the member id. */
  memberFrom?: string | undefined;
  /** Account field whose selected currency drives a `money` field's default currency. */
  currencyFrom?: string | undefined;
  /** Bound command fields filled from the picked record: source attribute → command field. */
  binds?: Partial<Record<'fingerprint' | 'version' | 'updatedAt' | 'memberId' | 'accountId' | 'partyId', string>> | undefined;
  /** Picked payload keys copied into command fields: payload key → command field. */
  copy?: Readonly<Record<string, string>> | undefined;
  /** Extra command fields derived from the picked record; runs after binds and copy. */
  fill?: ((summary: Record<string, unknown>) => Record<string, unknown>) | undefined;
}

export interface OperationSpec {
  kind: string;
  label: string;
  group: string;
  fields: readonly FieldSpec[];
  help?: string | undefined;
}

const text = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'text', ...extra });
const area = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'textarea', ...extra });
const date = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'date', ...extra });
const datetime = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'datetime', ...extra });
const int = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'int', ...extra });
const money = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'money', ...extra });
const bool = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'boolean', ...extra });
const select = (name: string, label: string, options: readonly string[], extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'select', options, ...extra });
const list = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'list', ...extra });
const nullable = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'nullable', ...extra });
const member = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'member', ...extra });
const account = (name: string, label: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'account', ...extra });

/** Context-only scope pickers: they narrow finance lists but are never emitted in the command. */
const scopeAccount: FieldSpec = { name: '__scopeAccount', label: 'Scope account', kind: 'account', contextOnly: true };
const scopeMember: FieldSpec = { name: '__scopeMember', label: 'Scope member', kind: 'member', contextOnly: true };
const scopeSchedule: FieldSpec = { name: '__scopeSchedule', label: 'Scope schedule', kind: 'finance', resource: 'payment-schedule', contextOnly: true };

const approval = (name = 'approvalId'): FieldSpec => ({ name, label: 'Approved decision', kind: 'approval' });
const policy = (name: string, label = 'Policy version'): FieldSpec => ({ name, label, kind: 'policy' });
const evidence = (name: string, label: string, memberFrom?: string, extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'evidence', memberFrom, ...extra });
const finance = (name: string, label: string, resource: FinanceListKind, binds: FieldSpec['binds'], extra: Partial<FieldSpec> = {}): FieldSpec => ({ name, label, kind: 'finance', resource, binds, ...extra });

const RESTRICTIONS = ['debit-block', 'credit-block', 'closure-block', 'fraud-review', 'legal-hold'] as const;
const CARD_LIMITS = ['daily-purchase', 'cash', 'online'] as const;
const FREQUENCIES = ['daily', 'weekly', 'monthly'] as const;
const CHANNELS = ['electronic', 'email', 'mail', 'secure-message'] as const;
const PURPOSES = ['servicing', 'account-statements', 'marketing'] as const;
const RETENTION = ['servicing-evidence', 'financial-seven-years', 'operational-evidence'] as const;
const EVIDENCE_KINDS = ['passport', 'drivers-license', 'national-id', 'state-id'] as const;
const ROUTING_KINDS = ['ach', 'internal'] as const;
const RAILS = ['ach', 'internal'] as const;
const ORG_TYPES = ['corporation', 'nonprofit'] as const;
const CALENDARS = ['US-FI-2026.1'] as const;

const memberVersion = { binds: { version: 'expectedVersion' } } satisfies Partial<FieldSpec>;
const accountVersion = { binds: { version: 'expectedVersion' } } satisfies Partial<FieldSpec>;

export const OPERATIONS: readonly OperationSpec[] = [
  // — Identity and member maintenance —
  { kind: 'member.organization.create', label: 'Create organization member', group: 'Identity', fields: [
    text('legalName', 'Legal name'), text('registrationNumber', 'Registration number'), select('organizationType', 'Organization type', ORG_TYPES),
    nullable('email', 'Email'), nullable('phone', 'Phone'), { name: 'address', label: 'Address', kind: 'address', optional: true },
  ] },
  { kind: 'member.identity_evidence.register', label: 'Register identity evidence', group: 'Identity', fields: [
    member('memberId', 'Member'), { name: 'documentVersionId', label: 'Evidence document version', kind: 'doc-version', memberFrom: 'memberId' },
    text('evidenceId', 'Evidence id', { optional: true, help: 'Leave blank to register new evidence from the document.' }),
    select('evidenceKind', 'Evidence kind', EVIDENCE_KINDS), date('issuedAt', 'Issued'), date('expiresAt', 'Expires'), text('reference', 'Source reference'),
  ] },
  { kind: 'member.identity.verify', label: 'Verify member identity', group: 'Identity', fields: [
    member('memberId', 'Member'), evidence('evidenceId', 'Identity evidence', 'memberId'), text('method', 'Verification method', { help: 'For example document-review, in-person, or the institution’s verification method code.' }),
  ] },
  { kind: 'member.legal_name.update', label: 'Update legal name', group: 'Identity', fields: [
    member('memberId', 'Member', memberVersion), text('legalGiven', 'Legal given name'), text('legalFamily', 'Legal family name'),
    evidence('evidenceId', 'Name evidence', 'memberId'), approval(),
  ] },
  { kind: 'member.preferred_name.update', label: 'Update preferred name', group: 'Identity', fields: [
    member('memberId', 'Member', memberVersion), nullable('preferredName', 'Preferred name'), select('communicationScope', 'Communication scope', ['servicing', 'communications', 'all']),
  ] },
  { kind: 'member.deceased.record', label: 'Record member deceased', group: 'Identity', fields: [
    member('memberId', 'Member', memberVersion), evidence('evidenceId', 'Death evidence', 'memberId'), date('effectiveDate', 'Date of death'), approval(),
  ] },
  { kind: 'member.beneficial_owners.update', label: 'Update beneficial owners', group: 'Identity', fields: [
    member('organizationMemberId', 'Organization member', memberVersion), { name: 'owners', label: 'Beneficial owners', kind: 'owners' }, date('effectiveDate', 'Effective date'), approval(),
  ] },
  { kind: 'member.tax_classification.update', label: 'Update tax classification', group: 'Identity', fields: [
    member('memberId', 'Member', memberVersion), text('classification', 'Tax classification', { help: 'For example individual, corporation, partnership, exempt.' }),
    int('effectiveYear', 'Effective year'), evidence('evidenceId', 'Tax evidence', 'memberId'), approval(),
  ] },
  { kind: 'member.merge', label: 'Merge members', group: 'Identity', help: 'Pick an approved merge plan; the members, versions, inventory fingerprint and approvals bind from it.', fields: [
    { name: 'mergePlanId', label: 'Merge plan', kind: 'merge-plan' },
    list('relationshipAccountIds', 'Relationship accounts', { help: 'Account ids the merge keeps linked; pre-filled from the plan.' }),
    approval(),
  ] },

  // — Account maintenance —
  { kind: 'account.product.convert', label: 'Convert account product', group: 'Accounts', fields: [
    account('accountId', 'Account', accountVersion), text('targetProductId', 'Target product'), date('effectiveDate', 'Effective date'), bool('feeDisclosureAccepted', 'Fee disclosure accepted'), approval(),
  ] },
  { kind: 'account.owner.add', label: 'Add account owner', group: 'Accounts', fields: [
    account('accountId', 'Account', accountVersion), member('memberId', 'Member to add'), select('role', 'Role', ['owner', 'joint-owner']),
    date('effectiveDate', 'Effective date'), evidence('identityEvidenceId', 'Identity evidence', 'memberId'),
    { name: 'consentId', label: 'Consent', kind: 'consent', memberFrom: 'memberId' }, approval(),
  ] },
  { kind: 'account.signer.remove', label: 'Remove account signer', group: 'Accounts', fields: [
    account('accountId', 'Account', accountVersion), member('signerMemberId', 'Signer to remove'), datetime('effectiveAt', 'Effective at'), approval(),
  ] },
  { kind: 'account.overdraft_limit.update', label: 'Update overdraft limit', group: 'Accounts', fields: [
    account('accountId', 'Account', accountVersion), finance('facilityId', 'Facility', 'facility', { fingerprint: 'expectedFacilityFingerprint' }, { scopeKey: 'accountId', scopeFrom: 'accountId', nullable: true, help: 'Pick the current overdraft facility, or choose none when there is none.' }),
    money('limit', 'New limit', { currencyFrom: 'accountId' }), date('effectiveDate', 'Effective date'), nullable('expiresAt', 'Expires at', { help: 'ISO date-time or none.' }), approval(),
  ] },
  { kind: 'account.maturity.instruct', label: 'Maturity instruction', group: 'Accounts', fields: [
    account('accountId', 'Account', accountVersion), finance('instructionId', 'Existing instruction', 'maturity-instruction', { fingerprint: 'expectedInstructionFingerprint' }, { scopeKey: 'accountId', scopeFrom: 'accountId', nullable: true, help: 'Pick the current instruction, or choose none when there is none.' }),
    select('disposition', 'Disposition', ['renew', 'transfer', 'hold']),
    account('destinationAccountId', 'Destination account', { nullable: true, when: v => v.disposition === 'transfer' }),
    int('termMonths', 'Term months', { nullable: true, when: v => v.disposition === 'renew' }),
    int('approvedAnnualRateBps', 'Approved rate (bps)', { nullable: true, when: v => v.disposition === 'renew' }),
    approval(),
  ] },

  // — Holds and restrictions —
  { kind: 'account.hold.place', label: 'Place account hold', group: 'Holds & restrictions', fields: [
    account('accountId', 'Account', accountVersion), money('amount', 'Hold amount', { currencyFrom: 'accountId' }), text('reason', 'Reason'),
    datetime('expiresAt', 'Expires at'), text('releaseAuthority', 'Release authority', { help: 'For example card-operations or legal-clearance.' }),
  ] },
  { kind: 'account.hold.release', label: 'Release account hold', group: 'Holds & restrictions', fields: [
    scopeAccount, 
    finance('holdId', 'Hold', 'hold', { fingerprint: 'expectedFingerprint' }),
    int('amountMinorUnits', 'Amount to release (minor units)'), text('releaseAuthority', 'Release authority'), text('evidenceReference', 'Evidence reference'),
  ] },
  { kind: 'account.restriction.apply', label: 'Apply account restriction', group: 'Holds & restrictions', fields: [
    account('accountId', 'Account', accountVersion), select('restrictionType', 'Restriction', RESTRICTIONS), text('reason', 'Reason'),
    text('authority', 'Authority', { help: 'For example risk-operations or legal-clearance.' }),
    { name: 'caseId', label: 'Supporting case', kind: 'case' }, approval(),
  ] },
  { kind: 'account.restriction.release', label: 'Release account restriction', group: 'Holds & restrictions', fields: [
    scopeAccount, 
    finance('restrictionId', 'Restriction', 'restriction', { fingerprint: 'expectedFingerprint' }),
    evidence('clearanceEvidenceId', 'Clearance evidence'), approval(),
  ] },

  // — Fees —
  { kind: 'fee.assess', label: 'Assess fee', group: 'Fees', fields: [
    account('accountId', 'Account', accountVersion), text('feeCode', 'Fee code'), money('amount', 'Amount', { currencyFrom: 'accountId' }),
    text('basis', 'Basis'), policy('policyVersionId'),
  ] },
  { kind: 'fee.waiver.create', label: 'Create fee waiver', group: 'Fees', fields: [
    account('accountId', 'Account'), text('feeCode', 'Fee code'), date('validFrom', 'Valid from'), date('validThrough', 'Valid through'),
    money('amountLimit', 'Amount limit', { currencyFrom: 'accountId' }), int('maxOccurrences', 'Maximum occurrences'), text('reason', 'Reason'), approval(),
  ] },
  { kind: 'fee.refund', label: 'Refund fee', group: 'Fees', fields: [
    scopeAccount, 
    finance('feeId', 'Fee', 'fee', { fingerprint: 'expectedFingerprint' }), money('amount', 'Refund amount'), text('reason', 'Reason'),
  ] },

  // — Financial corrections —
  { kind: 'cash.deposit.reverse', label: 'Reverse cash deposit', group: 'Corrections', fields: [
    scopeAccount, 
    finance('journalId', 'Deposit journal', 'journal', { fingerprint: 'expectedFingerprint' }),
    evidence('correctionEvidenceId', 'Correction evidence'), approval(),
  ] },
  { kind: 'cash.withdrawal.reverse', label: 'Reverse cash withdrawal', group: 'Corrections', fields: [
    scopeAccount, 
    finance('journalId', 'Withdrawal journal', 'journal', { fingerprint: 'expectedFingerprint' }), text('reason', 'Reason'), approval(),
  ] },
  { kind: 'transfer.internal.reverse', label: 'Reverse internal transfer', group: 'Corrections', fields: [
    scopeAccount, 
    finance('transferJournalId', 'Transfer journal', 'transfer', { fingerprint: 'expectedFingerprint' }), money('amount', 'Amount to reverse'), text('reason', 'Reason'), approval(),
  ] },
  { kind: 'interest.adjust', label: 'Adjust interest', group: 'Corrections', fields: [
    account('accountId', 'Account'), finance('calculationId', 'Interest calculation', 'interest-calculation', { fingerprint: 'expectedFingerprint' }, { scopeKey: 'accountId', scopeFrom: 'accountId' }),
    money('approvedDelta', 'Approved delta', { currencyFrom: 'accountId' }), approval(),
  ] },
  { kind: 'transaction.effective_date.correct', label: 'Correct effective date', group: 'Corrections', fields: [
    scopeAccount, 
    finance('journalId', 'Journal', 'journal', { fingerprint: 'expectedFingerprint' }), date('correctedDate', 'Corrected date'), policy('policyVersionId'), text('reason', 'Reason'), approval(),
  ] },
  { kind: 'transaction.description.update', label: 'Update transaction description', group: 'Corrections', fields: [
    scopeAccount, 
    finance('journalId', 'Journal', 'journal', { fingerprint: 'expectedFingerprint' }), text('description', 'New description'),
  ] },

  // — Beneficiaries and payments —
  { kind: 'beneficiary.create', label: 'Create beneficiary', group: 'Payments', fields: [
    member('memberId', 'Member', { binds: { version: 'expectedMemberVersion' } }), text('displayName', 'Display name'),
    select('routingKind', 'Routing kind', ROUTING_KINDS), text('maskedDestination', 'Masked destination'), text('simulatedToken', 'Simulated token'),
    list('allowedRails', 'Allowed rails', { help: `One per line: ${RAILS.join(', ')}.` }),
  ] },
  { kind: 'beneficiary.verify', label: 'Verify beneficiary route', group: 'Payments', fields: [
    scopeMember, 
    finance('beneficiaryId', 'Beneficiary', 'beneficiary', {}),
    finance('routeId', 'Route', 'beneficiary-route', { fingerprint: 'expectedFingerprint' }, { scopeKey: 'beneficiaryId', scopeFrom: 'beneficiaryId' }),
    evidence('evidenceId', 'Verification evidence'), approval(),
  ] },
  { kind: 'beneficiary.routing.update', label: 'Update beneficiary routing', group: 'Payments', fields: [
    scopeMember, 
    finance('beneficiaryId', 'Beneficiary', 'beneficiary', {}),
    finance('routeId', 'Current route', 'beneficiary-route', { fingerprint: 'expectedRouteFingerprint' }, { scopeKey: 'beneficiaryId', scopeFrom: 'beneficiaryId' }),
    select('routingKind', 'Routing kind', ROUTING_KINDS), text('maskedDestination', 'Masked destination'), text('simulatedToken', 'Simulated token'),
    date('effectiveDate', 'Effective date'), approval(),
  ] },
  { kind: 'beneficiary.retire', label: 'Retire beneficiary', group: 'Payments', fields: [
    scopeMember, 
    finance('beneficiaryId', 'Beneficiary', 'beneficiary', { fingerprint: 'expectedFingerprint' }),
    select('dependentDisposition', 'Dependent disposition', ['reject-if-active', 'cancel-drafts']), text('reason', 'Reason'),
  ] },
  { kind: 'payment.create', label: 'Create payment', group: 'Payments', fields: [
    account('sourceAccountId', 'Source account', { binds: { version: 'expectedSourceVersion' } }),
    member('__beneficiaryMember', 'Beneficiary owner', { optional: true, help: 'Narrows the beneficiary list to one member.' }),
    finance('beneficiaryId', 'Beneficiary', 'beneficiary', {}, { scopeKey: 'memberId', scopeFrom: '__beneficiaryMember' }),
    finance('beneficiaryRouteId', 'Route', 'beneficiary-route', { fingerprint: 'expectedRouteFingerprint' }, { scopeKey: 'beneficiaryId', scopeFrom: 'beneficiaryId' }),
    money('amount', 'Amount', { currencyFrom: 'sourceAccountId' }), select('rail', 'Rail', RAILS),
    date('requestedDate', 'Requested date'), select('calendarVersion', 'Calendar', CALENDARS), datetime('cutoffAt', 'Cutoff'),
    text('reference', 'Reference'), select('targetState', 'Initial state', ['draft', 'pending-approval']),
  ] },
  { kind: 'payment.submit', label: 'Submit payment', group: 'Payments', fields: [
    scopeAccount, 
    finance('paymentId', 'Payment', 'payment', { version: 'expectedVersion' }),
  ] },
  { kind: 'payment.approve_release', label: 'Approve payment release', group: 'Payments', fields: [
    scopeAccount, 
    finance('paymentId', 'Payment', 'payment', { version: 'expectedVersion' }),
    date('requestedDate', 'Requested date'), select('calendarVersion', 'Calendar', CALENDARS), datetime('cutoffAt', 'Cutoff'), approval(),
  ] },
  { kind: 'payment.settle', label: 'Settle payment', group: 'Payments', fields: [
    scopeAccount, 
    finance('paymentId', 'Payment', 'payment', { version: 'expectedVersion' }), text('settlementReference', 'Settlement reference'),
  ] },
  { kind: 'payment.cancel', label: 'Cancel payment', group: 'Payments', fields: [
    scopeAccount, 
    finance('paymentId', 'Payment', 'payment', { version: 'expectedVersion' }), text('reason', 'Reason'),
  ] },
  { kind: 'payment.schedule.create', label: 'Create payment schedule', group: 'Payments', fields: [
    account('sourceAccountId', 'Source account', { binds: { version: 'expectedSourceVersion' } }),
    member('__beneficiaryMember', 'Beneficiary owner', { optional: true }),
    finance('beneficiaryId', 'Beneficiary', 'beneficiary', {}, { scopeKey: 'memberId', scopeFrom: '__beneficiaryMember' }),
    finance('beneficiaryRouteId', 'Route', 'beneficiary-route', { fingerprint: 'expectedRouteFingerprint' }, { scopeKey: 'beneficiaryId', scopeFrom: 'beneficiaryId' }),
    money('amount', 'Amount', { currencyFrom: 'sourceAccountId' }), select('frequency', 'Frequency', FREQUENCIES), int('interval', 'Interval'),
    date('startDate', 'Start date'), date('endDate', 'End date'), approval(),
  ] },
  { kind: 'payment.schedule.materialize', label: 'Materialize occurrence', group: 'Payments', fields: [
    scopeAccount, scopeSchedule, 
    finance('occurrenceId', 'Schedule occurrence', 'schedule-occurrence', { fingerprint: 'expectedFingerprint' }),
  ] },
  { kind: 'payment.occurrence.amend', label: 'Amend occurrence', group: 'Payments', fields: [
    scopeAccount, scopeSchedule, 
    finance('occurrenceId', 'Schedule occurrence', 'schedule-occurrence', { fingerprint: 'expectedFingerprint' }),
    money('newAmount', 'New amount'), date('newDate', 'New date'),
  ] },
  { kind: 'payment.schedule.end', label: 'End payment schedule', group: 'Payments', fields: [
    scopeAccount, 
    finance('scheduleId', 'Schedule', 'payment-schedule', { fingerprint: 'expectedFingerprint' }),
    date('endFromDate', 'End from date'), select('pendingDisposition', 'Pending disposition', ['cancel-planned', 'retain-released']), approval(),
  ] },
  { kind: 'payment.return.resolve', label: 'Resolve payment return', group: 'Payments', fields: [
    scopeAccount, 
    finance('returnId', 'Payment return', 'payment-return', { fingerprint: 'expectedFingerprint' }),
    finance('paymentId', 'Payment', 'payment', {}), select('disposition', 'Disposition', ['credit-source', 'investigate']), approval(),
  ] },

  // — Cards and disputes —
  { kind: 'card.replace', label: 'Replace card', group: 'Cards & disputes', fields: [
    scopeAccount, 
    finance('cardId', 'Card', 'card', { fingerprint: 'expectedFingerprint' }), text('reason', 'Reason'),
    member('memberId', 'Card holder member', { contextOnly: true, help: 'Scopes the evidence and delivery lists.' }),
    evidence('identityEvidenceId', 'Identity evidence', 'memberId'),
    { name: 'deliveryDestinationId', label: 'Delivery destination', kind: 'address-dest', memberFrom: 'memberId' },
    { name: 'deliveryAddressId', label: 'Delivery address', kind: 'text', help: 'Party address id from the member’s addresses.' },
  ] },
  { kind: 'card.lock.update', label: 'Lock or unlock card', group: 'Cards & disputes', fields: [
    scopeAccount, 
    finance('cardId', 'Card', 'card', { fingerprint: 'expectedFingerprint' }), select('requestedState', 'Requested state', ['locked', 'unlocked']), text('authority', 'Authority'),
  ] },
  { kind: 'card.limit.update', label: 'Update card limit', group: 'Cards & disputes', fields: [
    scopeAccount, 
    finance('cardId', 'Card', 'card', { fingerprint: 'expectedFingerprint' }), select('limitKind', 'Limit kind', CARD_LIMITS),
    money('amount', 'Limit amount'), datetime('effectiveAt', 'Effective at'), nullable('expiresAt', 'Expires at'), approval(),
  ] },
  { kind: 'dispute.open', label: 'Open dispute', group: 'Cards & disputes', fields: [
    scopeAccount, 
    finance('cardTransactionId', 'Card transaction', 'card-transaction', { fingerprint: 'expectedFingerprint' }),
    text('reason', 'Reason'), money('assertedAmount', 'Asserted amount'), list('evidenceIds', 'Evidence ids'),
  ] },
  { kind: 'dispute.provisional_credit.issue', label: 'Issue provisional credit', group: 'Cards & disputes', fields: [
    scopeAccount, 
    finance('disputeId', 'Dispute', 'dispute', { fingerprint: 'expectedFingerprint' }), money('amount', 'Credit amount'), approval(),
  ] },
  { kind: 'dispute.evidence.submit', label: 'Submit dispute evidence', group: 'Cards & disputes', fields: [
    scopeAccount, 
    finance('disputeId', 'Dispute', 'dispute', { fingerprint: 'expectedFingerprint' }),
    list('documentVersionIds', 'Document version ids'), datetime('deadline', 'Deadline'), text('recipient', 'Recipient'), select('channel', 'Channel', CHANNELS), approval(),
  ] },
  { kind: 'dispute.settle', label: 'Settle dispute', group: 'Cards & disputes', fields: [
    scopeAccount, 
    finance('disputeId', 'Dispute', 'dispute', { fingerprint: 'expectedFingerprint' }), select('decision', 'Decision', ['approved', 'denied']),
    money('finalAmount', 'Final amount'), approval(),
  ] },

  // — Loans —
  { kind: 'loan.application.prepare', label: 'Prepare loan application', group: 'Loans', fields: [
    member('memberId', 'Member', { binds: { version: 'expectedMemberVersion' } }), text('productId', 'Loan product'),
    money('requestedAmount', 'Requested amount'), int('termMonths', 'Term months'), text('purpose', 'Purpose'), list('evidenceIds', 'Evidence ids'),
  ] },
  { kind: 'loan.payment.allocate', label: 'Allocate loan payment', group: 'Loans', fields: [
    scopeAccount, 
    finance('loanId', 'Loan', 'loan', { fingerprint: 'expectedFingerprint' }), text('receivedFundsReference', 'Received funds reference'),
    money('amount', 'Amount'), select('allocationPolicy', 'Allocation policy', ['fees-interest-principal', 'fees-interest-principal-hold-remainder']),
  ] },
  { kind: 'loan.payoff.quote', label: 'Loan payoff quote', group: 'Loans', fields: [
    scopeAccount, 
    finance('loanId', 'Loan', 'loan', { fingerprint: 'expectedFingerprint' }), date('payoffDate', 'Payoff date'), policy('policyVersionId'),
  ] },
  { kind: 'loan.close', label: 'Close loan', group: 'Loans', fields: [
    scopeAccount, 
    finance('loanId', 'Loan', 'loan', { fingerprint: 'expectedFingerprint' }),
    member('memberId', 'Member', { contextOnly: true, help: 'Scopes the payoff evidence list.' }),
    evidence('payoffEvidenceId', 'Payoff evidence', 'memberId'), approval(),
  ] },
  { kind: 'document.loan_closure.issue', label: 'Issue loan closure document', group: 'Loans', fields: [
    scopeAccount, 
    finance('loanId', 'Loan', 'loan', { fingerprint: 'expectedClosureFingerprint' }, { help: 'Pick the loan after its closure is committed.' }),
    member('memberId', 'Member', { contextOnly: true, help: 'Scopes the template document list.' }),
    { name: 'templateVersionId', label: 'Template version', kind: 'doc-version', memberFrom: 'memberId', help: 'A loan-closure-confirmation or simulated-lien-release template.' },
    text('recipientPartyId', 'Recipient party id'), select('documentType', 'Document type', ['loan-closure-confirmation', 'simulated-lien-release']), approval(),
  ] },

  // — Reconciliation —
  { kind: 'reconciliation.suspense.investigate', label: 'Investigate suspense item', group: 'Reconciliation', fields: [
    finance('suspenseId', 'Suspense item', 'suspense-item', { fingerprint: 'expectedFingerprint' }),
    list('evidenceReferences', 'Evidence references'), account('proposedAccountId', 'Proposed account', { nullable: true }),
  ] },
  { kind: 'reconciliation.suspense.clear', label: 'Clear suspense item', group: 'Reconciliation', fields: [
    finance('suspenseId', 'Suspense item', 'suspense-item', { fingerprint: 'expectedFingerprint' }),
    account('destinationAccountId', 'Destination account'), money('amount', 'Amount', { currencyFrom: 'destinationAccountId' }),
    text('evidenceReference', 'Evidence reference'), approval(),
  ] },

  // — Batches —
  { kind: 'batch.import', label: 'Import batch', group: 'Batches', fields: [
    member('__batchMember', 'Document owner member', { help: 'Scopes the batch-input document list.' }),
    { name: 'documentVersionId', label: 'Batch input document', kind: 'doc-version', memberFrom: '__batchMember', help: 'A batch-input or settlement-input CSV document.' },
    text('inputDigest', 'Input digest', { help: 'SHA-256 digest shown on the selected document version.' }),
    text('batchNumber', 'Batch number'), select('batchKind', 'Batch kind', ['contact-update', 'fee-refund']), nullable('currency', 'Currency', { help: 'ISO currency or none.' }),
  ] },
  { kind: 'batch.contacts.apply', label: 'Apply contact batch item', group: 'Batches', fields: [
    finance('batchId', 'Batch', 'batch', {}), finance('itemId', 'Batch item', 'batch-item', { fingerprint: 'expectedFingerprint' }, { scopeKey: 'batchId', scopeFrom: 'batchId' }),
    approval(), select('conflictPolicy', 'Conflict policy', ['skip-stale', 'reject-all']),
  ] },
  { kind: 'batch.fee_refunds.apply', label: 'Apply fee-refund batch item', group: 'Batches', fields: [
    finance('batchId', 'Batch', 'batch', {}), finance('itemId', 'Batch item', 'batch-item', { fingerprint: 'expectedFingerprint' }, { scopeKey: 'batchId', scopeFrom: 'batchId' }), approval(),
  ] },

  // — Documents —
  { kind: 'document.index', label: 'Index document', group: 'Documents', fields: [
    member('memberId', 'Member'), text('ownerPartyId', 'Owner party id', { help: 'The member’s party id, shown on the member record.' }),
    account('accountId', 'Account', { optional: true, memberFrom: 'memberId' }), text('documentId', 'Existing document id', { optional: true, help: 'Add a version to an existing document, or leave blank for a new one.' }),
    text('documentType', 'Document type'), text('displayName', 'Display name'), select('retentionClass', 'Retention class', RETENTION),
    { name: 'contentBase64', label: 'Content file', kind: 'file' }, text('source', 'Source', { optional: true }), text('sourceDigest', 'Source digest', { optional: true }),
  ] },
  { kind: 'document.bundle.redact', label: 'Redact document bundle', group: 'Documents', fields: [
    member('memberId', 'Member'), { name: 'sourceVersionIds', label: 'Source versions', kind: 'list', help: 'Document version ids, one per line.' },
    text('recipientPurpose', 'Recipient purpose'), policy('redactionPolicyVersionId', 'Redaction policy'),
    { name: 'approvedExcerpts', label: 'Approved excerpts', kind: 'excerpts' }, text('displayName', 'Display name', { optional: true }),
  ] },
  { kind: 'document.signature.collect', label: 'Collect signature', group: 'Documents', fields: [
    select('action', 'Action', ['request', 'sign', 'decline', 'expire']),
    member('memberId', 'Member', { contextOnly: true }), { name: 'documentVersionId', label: 'Document version', kind: 'doc-version', memberFrom: 'memberId' },
    list('signerPartyIds', 'Signer party ids'), select('channel', 'Channel', CHANNELS),
    text('evidenceReference', 'Evidence reference', { optional: true, when: v => v.action !== 'request', help: 'Required for sign, decline and expire.' }),
  ] },
  { kind: 'document.annotation.update', label: 'Annotate document', group: 'Documents', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'documentVersionId', label: 'Document version', kind: 'doc-version', memberFrom: 'memberId' },
    select('action', 'Action', ['create', 'amend', 'remove']),
    text('annotationId', 'Annotation id', { optional: true, when: v => v.action !== 'create' }),
    text('expectedAnnotationFingerprint', 'Expected annotation fingerprint', { optional: true, when: v => v.action !== 'create' }),
    int('pageNumber', 'Page number', { when: v => v.action !== 'remove' }), { name: 'regionMicros', label: 'Region (millionths of page)', kind: 'region', when: v => v.action !== 'remove' },
    area('text', 'Annotation text', { optional: true, when: v => v.action !== 'remove' }),
  ] },
  { kind: 'document.metadata.update', label: 'Update document metadata', group: 'Documents', fields: [
    member('memberId', 'Member'), {
      name: 'documentVersionId', label: 'Document version (identifies document)', kind: 'doc-version', memberFrom: 'memberId',
      fill: summary => ({
        documentId: summary.documentId,
        expectedMetadata: { ownerPartyId: summary.ownerPartyId, accountId: summary.accountId, documentType: summary.documentType, displayName: summary.displayName, retentionClass: summary.retentionClass },
        documentType: summary.documentType, displayName: summary.displayName, ownerPartyId: summary.ownerPartyId, accountId: summary.accountId, retentionClass: summary.retentionClass,
      }),
    },
    text('documentType', 'Document type'), text('displayName', 'Display name'), text('ownerPartyId', 'Owner party id'),
    account('accountId', 'Account', { nullable: true, memberFrom: 'memberId' }), select('retentionClass', 'Retention class', RETENTION),
    approval('approvalId'),
  ] },
  { kind: 'document.retention_hold.apply', label: 'Apply retention hold', group: 'Documents', fields: [
    text('documentId', 'Document id', { optional: true }), { name: 'caseId', label: 'Case', kind: 'case', optional: true },
    text('reason', 'Reason'), datetime('reviewAt', 'Review at'), approval(),
  ], help: 'Bind the hold to a document or a case.' },
  { kind: 'document.customer_export.create', label: 'Create customer export', group: 'Documents', fields: [
    member('memberId', 'Member'), text('retentionClass', 'Retention class'), policy('disclosurePolicyVersionId', 'Disclosure policy'), text('recipientReference', 'Recipient reference'), approval(),
  ] },

  // — Consent —
  { kind: 'consent.delivery.record', label: 'Record consent delivery', group: 'Consent', fields: [
    member('memberId', 'Member', { binds: { partyId: 'partyId' }, contextOnly: true }),
    account('accountId', 'Account', { nullable: true, memberFrom: 'memberId' }), select('purpose', 'Purpose', PURPOSES), select('channel', 'Channel', CHANNELS),
    { name: 'disclosureVersionId', label: 'Disclosure version', kind: 'doc-version', memberFrom: 'memberId', help: 'A delivery-disclosure document version.' },
    text('evidence', 'Acknowledgement evidence'),
  ] },
  { kind: 'consent.withdraw', label: 'Withdraw consent', group: 'Consent', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'consentId', label: 'Consent', kind: 'consent', memberFrom: 'memberId' },
    datetime('effectiveAt', 'Effective at', { optional: true }), list('affectedChannels', 'Affected channels'),
  ] },

  // — Maintenance —
  { kind: 'maintenance.draft.save', label: 'Save maintenance draft', group: 'Maintenance', fields: [
    member('memberId', 'Member'), account('accountId', 'Account', { nullable: true, memberFrom: 'memberId' }),
    text('requestId', 'Existing request id', { optional: true }), text('requestNumber', 'Request number', { optional: true }),
    text('category', 'Category', { help: 'For example contact-review or servicing-note.' }), text('subject', 'Subject'),
    { name: 'requestedCommand', label: 'Requested change', kind: 'maint-command' },
    area('note', 'Note', { optional: true }), list('missingFields', 'Missing fields'),
    list('evidenceDocumentVersionIds', 'Evidence document versions', { optional: true }),
  ] },
  { kind: 'maintenance.draft.amend', label: 'Amend maintenance draft', group: 'Maintenance', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'requestId', label: 'Request', kind: 'maint-request', memberFrom: 'memberId', binds: { updatedAt: 'expectedUpdatedAt' } },
    { name: 'patch', label: 'Draft changes', kind: 'maint-patch' },
  ] },
  { kind: 'maintenance.request.submit', label: 'Submit maintenance request', group: 'Maintenance', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'requestId', label: 'Request', kind: 'maint-request', memberFrom: 'memberId', binds: { updatedAt: 'expectedUpdatedAt' } },
  ] },
  { kind: 'maintenance.request.withdraw', label: 'Withdraw maintenance request', group: 'Maintenance', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'requestId', label: 'Request', kind: 'maint-request', memberFrom: 'memberId', binds: { updatedAt: 'expectedUpdatedAt' } },
    text('reason', 'Reason'),
  ] },
  { kind: 'maintenance.request.review', label: 'Review maintenance request', group: 'Maintenance', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'requestId', label: 'Request', kind: 'maint-request', memberFrom: 'memberId', binds: { updatedAt: 'expectedUpdatedAt' } },
    select('decision', 'Decision', ['approve', 'reject', 'return-for-information']), text('reason', 'Reason'),
  ] },
  { kind: 'maintenance.request.process', label: 'Process maintenance request', group: 'Maintenance', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'requestId', label: 'Request', kind: 'maint-request', memberFrom: 'memberId', binds: { updatedAt: 'expectedUpdatedAt' } },
    select('disposition', 'Disposition', ['apply', 'reject']), text('reason', 'Reason'),
    text('appliedReceiptId', 'Applied receipt id', { optional: true, when: v => v.disposition === 'apply', help: 'Receipt of the committed change being applied.' }),
  ] },
  { kind: 'maintenance.address.reconcile', label: 'Reconcile address', group: 'Maintenance', fields: [
    member('memberId', 'Member', { binds: { version: 'expectedMemberVersion' } }), text('conflictingAddressId', 'Conflicting address id', { help: 'Party address id from the member’s addresses.' }),
    { name: 'winningEvidenceVersionId', label: 'Winning evidence version', kind: 'doc-version', memberFrom: 'memberId' },
    text('winningEvidenceDigest', 'Winning evidence digest'), text('precedence', 'Precedence'),
    { name: 'address', label: 'Canonical address', kind: 'address' }, approval(),
  ] },
  { kind: 'maintenance.address.destination.update', label: 'Update address destination', group: 'Maintenance', fields: [
    member('memberId', 'Member'), select('context', 'Context', ['member-mailing', 'account-statement', 'card-shipping', 'loan-notice']),
    text('targetId', 'Target id', { help: 'Member id or account id the destination serves.' }),
    text('addressId', 'Address id', { help: 'Party address id from the member’s addresses.' }),
    { name: 'evidenceVersionId', label: 'Evidence version', kind: 'doc-version', memberFrom: 'memberId' },
    date('effectiveDate', 'Effective date'),
    { name: 'expectedCurrentDestinationId', label: 'Current destination', kind: 'address-dest', memberFrom: 'memberId', nullable: true, help: 'Pick the destination currently effective for this context, or none.' },
    { name: 'consentId', label: 'Postal consent', kind: 'consent', memberFrom: 'memberId', nullable: true, help: 'Granted consent when policy requires one; choose none when not required.' },
    approval(),
  ] },
  { kind: 'edit.cancel', label: 'Cancel maintenance draft', group: 'Maintenance', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'requestId', label: 'Request', kind: 'maint-request', memberFrom: 'memberId', binds: { updatedAt: 'expectedUpdatedAt' } },
  ] },

  // — Communications —
  { kind: 'communication.preference.update', label: 'Update communication preference', group: 'Communications', fields: [
    member('memberId', 'Member', { binds: { partyId: 'partyId' }, contextOnly: true }), select('purpose', 'Purpose', PURPOSES), select('channel', 'Channel', CHANNELS), select('state', 'State', ['enabled', 'disabled']),
  ] },
  { kind: 'communication.send', label: 'Send communication', group: 'Communications', fields: [
    member('memberId', 'Member', { binds: { partyId: 'partyId' }, contextOnly: true }), select('channel', 'Channel', CHANNELS),
    text('destination', 'Destination', { optional: true, when: v => v.channel !== 'mail', help: 'Electronic destination; mail derives its destination.' }),
    { name: 'addressDestinationId', label: 'Address destination', kind: 'address-dest', memberFrom: 'memberId', optional: true, when: v => v.channel === 'mail' },
    select('purpose', 'Purpose', PURPOSES),
    { name: 'documentVersionId', label: 'Document version', kind: 'doc-version', memberFrom: 'memberId' },
    text('jobId', 'Existing job id', { optional: true }),
  ] },
  { kind: 'communication.delivery.update', label: 'Update delivery state', group: 'Communications', fields: [
    member('memberId', 'Member', { contextOnly: true }), { name: 'jobId', label: 'Communication job', kind: 'comm-job', memberFrom: 'memberId', copy: { state: 'expectedState' } },
    select('action', 'Action', ['accept', 'deliver', 'bounce', 'cancel']), text('detail', 'Detail'),
  ] },

  // — Cases —
  { kind: 'case.information.request', label: 'Request case information', group: 'Cases', fields: [
    { name: 'caseId', label: 'Case', kind: 'case', binds: { version: 'expectedVersion' } },
    list('fields', 'Fields requested', { help: 'Field names requested from the customer, one per line.' }),
    text('recipientPartyId', 'Recipient party id'), select('channel', 'Channel', CHANNELS), datetime('dueAt', 'Due at'),
    member('memberId', 'Member', { contextOnly: true, optional: true, help: 'Scopes the optional supporting document list.' }),
    { name: 'documentVersionId', label: 'Supporting document', kind: 'doc-version', memberFrom: 'memberId', optional: true },
    text('destination', 'Destination', { optional: true }),
  ] },
  { kind: 'case.escalate', label: 'Escalate case', group: 'Cases', fields: [
    { name: 'caseId', label: 'Case', kind: 'case', binds: { version: 'expectedVersion' } }, text('escalationRule', 'Escalation rule'),
  ] },

  // — Approvals —
  { kind: 'approval.request', label: 'Request approval', group: 'Approvals', fields: [
    { name: 'target', label: 'Operation needing approval', kind: 'command-target' },
    { name: 'checkerActorId', label: 'Checker', kind: 'checker' },
    policy('policyVersionId'), datetime('expiresAt', 'Expires at'), money('amountLimit', 'Amount limit', { nullable: true }),
  ] },
  { kind: 'approval.decide', label: 'Decide approval', group: 'Approvals', fields: [
    { name: 'approvalId', label: 'Approval', kind: 'approval', binds: { fingerprint: 'expectedFingerprint' }, help: 'Pick a pending approval; the decision binds its fingerprint.' },
    select('decision', 'Decision', ['approve', 'deny']), text('reason', 'Reason'),
  ] },
];

export const OPERATION_GROUPS: readonly string[] = [...new Set(OPERATIONS.map((spec) => spec.group))];

export function operationSpec(kind: string): OperationSpec | undefined {
  return OPERATIONS.find((spec) => spec.kind === kind);
}
