import { useCallback, useEffect, useRef, useState } from 'react';

import { ApiError } from '../api';

export interface Resource<T> {
  data: T | undefined;
  error: ApiError | null;
  loading: boolean;
  reload: () => void;
}

function toApiError(error: unknown): ApiError {
  return error instanceof ApiError ? error : new ApiError(0, 'client_error', error instanceof Error ? error.message : 'The request failed.');
}

/**
 * Loads data for a key, keeping the previous data visible while reloading and ignoring
 * responses that arrive after the key has changed.
 */
export function useResource<T>(load: (() => Promise<T>) | null, key: string): Resource<T> {
  const [state, setState] = useState<{ data: T | undefined; error: ApiError | null; loading: boolean; key: string }>({ data: undefined, error: null, loading: load !== null, key });
  const [generation, setGeneration] = useState(0);
  const loader = useRef(load);
  loader.current = load;
  useEffect(() => {
    const current = loader.current;
    if (current === null) { setState((previous) => ({ ...previous, loading: false })); return undefined; }
    let cancelled = false;
    setState((previous) => ({ data: previous.key === key ? previous.data : undefined, error: null, loading: true, key }));
    current().then(
      (data) => { if (!cancelled) setState({ data, error: null, loading: false, key }); },
      (error: unknown) => { if (!cancelled) setState((previous) => ({ ...previous, error: toApiError(error), loading: false })); },
    );
    return () => { cancelled = true; };
  }, [key, generation]);
  const reload = useCallback(() => { setGeneration((value) => value + 1); }, []);
  return { data: state.key === key ? state.data : undefined, error: state.error, loading: state.loading, reload };
}
