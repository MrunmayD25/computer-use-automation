import type { AtomicBatchOutcome, CommandOutcome, FinanceQuery, FinanceQueryResult, ReviewOutcome, ServiceCommand, StatementExportRequest } from '@computer-use/financial-database/services';

import type { ApiErrorBody } from '../shared/api';

export class ApiError extends Error {
  constructor(readonly status: number, readonly code: string, message: string, readonly field?: string) { super(message); }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let response: Response;
  try {
    response = await fetch(path, { ...init, credentials: 'same-origin', headers: { accept: 'application/json', ...(init.body === undefined ? {} : { 'content-type': 'application/json' }) } });
  } catch {
    throw new ApiError(0, 'network', 'The desktop backend could not be reached. Your draft is kept; retry when the connection returns.');
  }
  if (!response.ok) {
    let body: ApiErrorBody | undefined;
    try { body = await response.json() as ApiErrorBody; } catch { body = undefined; }
    throw new ApiError(response.status, body?.error.code ?? `http_${String(response.status)}`, body?.error.message ?? `The request failed with status ${String(response.status)}.`, body?.error.field);
  }
  return await response.json() as T;
}

export function getJson<T>(path: string): Promise<T> {
  return request<T>(path);
}

export function postJson<T>(path: string, body: unknown): Promise<T> {
  return request<T>(path, { method: 'POST', body: JSON.stringify(body) });
}

/** Path below one bound institution. The backend maps it to its trusted dataset. */
export function institutionPath(institutionId: string, path: string): string {
  return `/api/i/${encodeURIComponent(institutionId)}${path}`;
}

export function queryString(parameters: Readonly<Record<string, string | number | boolean | null | undefined>>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(parameters)) if (value !== undefined && value !== null && value !== '') search.set(key, String(value));
  const text = search.toString();
  return text === '' ? '' : `?${text}`;
}

export function reviewCommand(institutionId: string, command: ServiceCommand): Promise<ReviewOutcome> {
  return postJson<ReviewOutcome>(institutionPath(institutionId, '/commands/review'), { command });
}

/** Runs a command. Retrying with the same key returns the original receipt instead of repeating the effect. */
export function executeCommand(institutionId: string, command: ServiceCommand, idempotencyKey: string): Promise<CommandOutcome> {
  return postJson<CommandOutcome>(institutionPath(institutionId, '/commands'), { command, idempotencyKey });
}

export function newIdempotencyKey(kind: string): string {
  return `${kind}:${crypto.randomUUID()}`;
}

export function financeQuery(institutionId: string, query: FinanceQuery): Promise<FinanceQueryResult> {
  return postJson<FinanceQueryResult>(institutionPath(institutionId, '/query/finance'), query);
}

/** Runs a set of commands atomically; the whole batch commits or nothing does. */
export function executeAtomic(institutionId: string, commands: readonly ServiceCommand[], idempotencyKey: string): Promise<AtomicBatchOutcome> {
  return postJson<AtomicBatchOutcome>(institutionPath(institutionId, '/commands/atomic'), { commands, idempotencyKey });
}

export interface StatementArtifactResult {
  format: string;
  displayName: string;
  mediaType: string;
  digest: string;
  byteLength: number;
  contentBase64: string;
}

export interface StatementExportResponse {
  kind: string;
  destinationId?: string;
  observedAt?: string;
  artifacts?: StatementArtifactResult[];
  code?: string;
  message?: string;
  field?: string;
}

export function exportStatementBundle(institutionId: string, body: StatementExportRequest): Promise<StatementExportResponse> {
  return postJson<StatementExportResponse>(institutionPath(institutionId, '/statements/export'), body);
}
