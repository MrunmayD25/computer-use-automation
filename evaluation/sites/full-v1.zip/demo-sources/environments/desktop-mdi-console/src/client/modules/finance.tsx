import { useState, type ReactNode } from 'react';

import type { AccountRow, FinanceListKind, FinanceListScope, FinanceRecordSnapshot, MemberRow, PageResult } from '@computer-use/financial-database/services';

import { financeQuery, getJson, institutionPath, queryString } from '../api';
import { describeValue } from '../format';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands } from '../desktop/context';
import { OPERATIONS, type OperationSpec } from '../operations/registry';
import { Banner, Loading, Toolbar } from '../widgets/fields';
import { useResource } from '../widgets/useResource';
import { exponentOf, Money, useReference } from './common';

export const FINANCE_RESOURCES: readonly { kind: FinanceListKind; label: string; scopes: readonly (keyof FinanceListScope)[] }[] = [
  { kind: 'beneficiary', label: 'Beneficiaries', scopes: ['memberId'] },
  { kind: 'beneficiary-route', label: 'Beneficiary routes', scopes: ['beneficiaryId'] },
  { kind: 'payment', label: 'Payments', scopes: ['memberId', 'accountId'] },
  { kind: 'payment-schedule', label: 'Payment schedules', scopes: ['accountId'] },
  { kind: 'schedule-occurrence', label: 'Schedule occurrences', scopes: ['scheduleId'] },
  { kind: 'payment-return', label: 'Payment returns', scopes: ['paymentId'] },
  { kind: 'card', label: 'Cards', scopes: ['memberId', 'accountId'] },
  { kind: 'card-transaction', label: 'Card transactions', scopes: ['cardId'] },
  { kind: 'dispute', label: 'Disputes', scopes: ['memberId', 'cardId'] },
  { kind: 'loan', label: 'Loans', scopes: ['memberId', 'accountId'] },
  { kind: 'loan-application', label: 'Loan applications', scopes: ['memberId'] },
  { kind: 'payoff-quote', label: 'Payoff quotes', scopes: ['loanId'] },
  { kind: 'loan-closure', label: 'Loan closures', scopes: ['loanId'] },
  { kind: 'interest-calculation', label: 'Interest calculations', scopes: ['accountId'] },
  { kind: 'fee', label: 'Fees', scopes: ['accountId'] },
  { kind: 'fee-waiver', label: 'Fee waivers', scopes: ['accountId'] },
  { kind: 'hold', label: 'Holds', scopes: ['accountId'] },
  { kind: 'restriction', label: 'Restrictions', scopes: ['accountId'] },
  { kind: 'facility', label: 'Facilities', scopes: ['accountId'] },
  { kind: 'maturity-instruction', label: 'Maturity instructions', scopes: ['accountId'] },
  { kind: 'received-funds', label: 'Received funds', scopes: ['memberId'] },
  { kind: 'transaction', label: 'Transactions', scopes: ['accountId'] },
  { kind: 'journal', label: 'Journals', scopes: ['accountId'] },
  { kind: 'transfer', label: 'Transfers', scopes: ['accountId'] },
  { kind: 'settlement-batch', label: 'Settlement batches', scopes: [] },
  { kind: 'suspense-item', label: 'Suspense items', scopes: [] },
  { kind: 'batch', label: 'Batches', scopes: [] },
  { kind: 'batch-item', label: 'Batch items', scopes: ['batchId'] },
  { kind: 'merge-plan', label: 'Merge plans', scopes: [] },
  { kind: 'cash-session', label: 'Cash sessions', scopes: ['businessDate'] },
  { kind: 'reservation', label: 'Reservations', scopes: ['accountId'] },
  { kind: 'dispute-submission', label: 'Dispute submissions', scopes: ['disputeId'] },
];

export function resourceLabel(kind: FinanceListKind): string {
  return FINANCE_RESOURCES.find((entry) => entry.kind === kind)?.label ?? kind;
}

const SNAPSHOT_KINDS = new Set<string>([
  'beneficiary', 'beneficiary-route', 'payment', 'payment-schedule', 'schedule-occurrence', 'payment-return', 'card', 'card-transaction',
  'dispute', 'loan', 'interest-calculation', 'fee', 'hold', 'restriction', 'facility', 'maturity-instruction', 'received-funds',
  'transaction', 'journal', 'transfer', 'settlement-batch', 'suspense-item', 'batch', 'loan-closure',
]);

/** Operations whose first finance picker targets this resource, for record-action buttons. */
export function operationsFor(resource: FinanceListKind): readonly OperationSpec[] {
  const key = resource === 'schedule-occurrence' ? 'occurrenceId' : resource === 'batch-item' ? 'itemId' : `${resource}Id`;
  return OPERATIONS.filter((op) => op.fields.some((field) => field.kind === 'finance' && (field.resource === resource || field.name === key)));
}

function scopePrefill(resource: FinanceListKind, itemId: string, snapshot: FinanceRecordSnapshot | undefined): Record<string, unknown> {
  const record = snapshot?.record ?? {};
  const prefill: Record<string, unknown> = {};
  for (const op of OPERATIONS) {
    for (const field of op.fields) {
      if (field.kind === 'finance' && field.resource === resource) prefill[field.name] = itemId;
      if (field.kind === 'account' && typeof record.accountId === 'string') prefill[field.name] = record.accountId;
      if (field.kind === 'account' && typeof record.account_id === 'string') prefill[field.name] = record.account_id;
      if (field.kind === 'member' && typeof record.memberId === 'string') prefill[field.name] = record.memberId;
      if (field.kind === 'member' && typeof record.member_id === 'string') prefill[field.name] = record.member_id;
    }
  }
  return prefill;
}

/** Scope bar for record lists: pick a member or account (or type a scope id) before the bounded query runs. */
function ScopeBar({ resource, onScope }: { resource: FinanceListKind; onScope: (scope: FinanceListScope) => void }): ReactNode {
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const meta = FINANCE_RESOURCES.find((entry) => entry.kind === resource);
  const allowed = new Set<string>(meta?.scopes ?? []);
  const [memberQuery, setMemberQuery] = useState('');
  const [members, setMembers] = useState<MemberRow[] | null>(null);
  const [accountQuery, setAccountQuery] = useState('');
  const [accounts, setAccounts] = useState<AccountRow[] | null>(null);
  const [businessDate, setBusinessDate] = useState('');
  const findMembers = async (query: string): Promise<void> => {
    setMemberQuery(query);
    const page = await getJson<PageResult<MemberRow>>(institutionPath(institutionId, `/members${queryString({ query, limit: 8 })}`));
    setMembers(page.items);
  };
  const findAccounts = async (query: string): Promise<void> => {
    setAccountQuery(query);
    const page = await getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ query, limit: 8 })}`));
    setAccounts(page.items);
  };
  return (
    <div className="scope-bar">
      <span className="field-hint">This list needs a scope — choose a member or account{allowed.has('businessDate') ? ', or a business date' : ''}.</span>
      {allowed.has('memberId') ? (
        <span className="scope-pick">
          <input type="search" value={memberQuery} placeholder="Member name or number…" aria-label="Scope member"
            onChange={(event) => { void findMembers(event.target.value); }} />
          {members === null ? null : (
            <ul className="picker-results">{members.map((row) => <li key={row.id}><button type="button" onClick={() => { onScope({ memberId: row.id }); }}>{row.memberNumber} · {row.displayName}</button></li>)}</ul>
          )}
        </span>
      ) : null}
      {allowed.has('accountId') ? (
        <span className="scope-pick">
          <input type="search" value={accountQuery} placeholder="Account number…" aria-label="Scope account"
            onChange={(event) => { void findAccounts(event.target.value); }} />
          {accounts === null ? null : (
            <ul className="picker-results">{accounts.map((row) => <li key={row.id}><button type="button" onClick={() => { onScope({ accountId: row.id }); }}>{row.accountNumber} · {row.ownerName}</button></li>)}</ul>
          )}
        </span>
      ) : null}
      {allowed.has('businessDate') ? (
        <span className="scope-pick">
          <input type="date" value={businessDate} aria-label="Business date" onChange={(event) => { setBusinessDate(event.target.value); }} />
          <button type="button" disabled={businessDate === ''} onClick={() => { onScope({ businessDate }); }}>Apply date</button>
        </span>
      ) : null}
      {allowed.size === 0 || (!allowed.has('memberId') && !allowed.has('accountId') && !allowed.has('businessDate')) ? (
        <button type="button" onClick={() => { onScope({}); }}>List all</button>
      ) : null}
    </div>
  );
}

/** Docked grid of finance records under one scope; rows open the record window. */
export function FinanceRecordsWindow({ resource, scope: initialScope, label }: { resource: FinanceListKind; scope: FinanceListScope; label: string }): ReactNode {
  const { open } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [scope, setScope] = useState<FinanceListScope | null>(Object.keys(initialScope).length === 0 ? null : initialScope);
  const scopeKey = JSON.stringify(scope ?? {});
  const list = useResource(scope === null ? null : () => financeQuery(institutionId, { kind: 'finance.records', resource, scope: JSON.parse(scopeKey) as FinanceListScope, limit: 100 }), `${resource}:${scopeKey}`);
  useWindowChrome(`${label} · ${win.institution.displayName}`, {}, false);
  useWindowCommands({ refresh: () => { list.reload(); } });
  const items = list.data?.kind === 'listed' ? list.data.items : [];
  return (
    <div className="list-window">
      <Toolbar label={`${label} actions`}>
        {scope === null ? null : <button type="button" onClick={() => { setScope(null); }}>Change scope</button>}
        <button type="button" onClick={() => { list.reload(); }}>Refresh</button>
      </Toolbar>
      {scope === null ? <ScopeBar resource={resource} onScope={setScope} /> : null}
      {list.loading ? <Loading label={`Loading ${label.toLowerCase()}…`} /> : null}
      {list.data !== undefined && list.data.kind === 'rejected' ? <Banner tone="error" title="List rejected.">{list.data.message}</Banner> : null}
      {list.error === null ? null : <Banner tone="error" title="Could not load.">{list.error.message}</Banner>}
      {items.length === 0 && !list.loading && scope !== null ? <Banner tone="info">No {label.toLowerCase()} in this scope.</Banner> : null}
      <div className="grid-scroll">
        <table className="grid" data-testid="finance-records">
          <thead><tr><th scope="col">Record</th><th scope="col">Summary</th><th scope="col" /></tr></thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.id} data-record={item.id}>
                <td><code>{item.id}</code></td>
                <td>{Object.entries(item.fields).map(([key, value]) => `${key}=${describeValue(value) || '—'}`).join('  ')}</td>
                <td>{SNAPSHOT_KINDS.has(resource) ? <button type="button" onClick={() => { open(institutionId, { kind: 'finance-record', resource, recordId: item.id }, { reuse: false }); }}>Open</button> : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {list.data?.kind === 'listed' && !list.data.exhausted ? <Banner tone="info">The list continues past this bounded page; narrow the scope or page forward.</Banner> : null}
    </div>
  );
}

const moneyKeys = /minorUnits|_minor_units/iu;

/** One finance record: the authoritative snapshot plus every operation bound to this record type. */
export function FinanceRecordWindow({ resource, recordId }: { resource: FinanceListKind; recordId: string }): ReactNode {
  const { open, can } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const reference = useReference(institutionId);
  const detail = useResource(() => financeQuery(institutionId, { kind: 'finance.record', resource: resource as never, id: recordId }), `${resource}:${recordId}`);
  const snapshot = detail.data?.kind === 'found' ? detail.data.snapshot : undefined;
  const record = snapshot?.record ?? {};
  useWindowChrome(`${resourceLabel(resource)} ${recordId}`, {}, false);
  useWindowCommands({ refresh: () => { detail.reload(); } });
  const ops = operationsFor(resource);
  return (
    <div className="form-window">
      <Toolbar label={`${resourceLabel(resource)} actions`}>
        <button type="button" onClick={() => { detail.reload(); }}>Refresh</button>
        {ops.map((op) => (
          <button key={op.kind} type="button" disabled={!can(institutionId, op.kind)}
            onClick={() => { open(institutionId, { kind: 'operation', commandKind: op.kind, prefill: scopePrefill(resource, recordId, snapshot) }, { reuse: false }); }}>
            {op.label}…
          </button>
        ))}
      </Toolbar>
      {detail.loading ? <Loading label="Loading record…" /> : null}
      {detail.data !== undefined && detail.data.kind === 'rejected' ? <Banner tone="error" title="Record rejected.">{detail.data.message}</Banner> : null}
      {detail.data !== undefined && detail.data.kind !== 'found' && detail.data.kind !== 'rejected' ? <Banner tone="error" title="Not found.">The record does not exist at this institution.</Banner> : null}
      {snapshot === undefined ? null : (
        <>
          <p className="hint">Fingerprint <code data-testid="record-fingerprint">{snapshot.fingerprint}</code> · observed {snapshot.observedAt}</p>
          <table className="simple-table" data-testid="record-fields">
            <tbody>
              {Object.entries(record).map(([key, value]) => (
                <tr key={key}>
                  <th scope="row">{key}</th>
                  <td>{moneyKeys.test(key) && typeof value === 'number' && typeof record.currency === 'string'
                    ? <Money minorUnits={value} currency={record.currency} exponent={exponentOf(reference.data, record.currency)} />
                    : <code>{describeValue(value) || '—'}</code>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </div>
  );
}
