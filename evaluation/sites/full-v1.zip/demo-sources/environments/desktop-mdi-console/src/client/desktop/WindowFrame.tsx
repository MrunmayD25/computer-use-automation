import { useCallback, useEffect, useMemo, useRef, useState, type Dispatch, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';

import type { InstitutionInfo } from '../../shared/api';
import { WindowContext, type WindowApi, type WindowCommands } from './context';
import { choose, focusableWithin, useDialogHost } from './Dialog';
import type { DesktopAction, DesktopWindow, RecordContext, WindowSpec } from './state';

export interface FrameHandle {
  requestClose: () => Promise<boolean>;
  save: () => Promise<void>;
  refresh: () => void;
  print: () => void;
  focusSearch: () => void;
  hasDialog: () => boolean;
  isBusy: () => boolean;
}

interface WindowFrameProps {
  window: DesktopWindow;
  zIndex: number;
  active: boolean;
  institution: InstitutionInfo;
  badgeClass: string;
  dispatch: Dispatch<DesktopAction>;
  area: () => { width: number; height: number };
  register: (id: string, handle: FrameHandle | null) => void;
  notify: (text: string, tone?: 'info' | 'error') => void;
  children: ReactNode;
}

type Edge = 'e' | 's' | 'se';

/** One internal window: title bar, drag and resize, local dialogs, focus memory and its repeated commands. */
export function WindowFrame({ window: record, zIndex, active, institution, badgeClass, dispatch, area, register, notify, children }: WindowFrameProps): ReactNode {
  const { id, title, minimized, dirty, bounds } = record;
  const section = useRef<HTMLElement>(null);
  const body = useRef<HTMLDivElement>(null);
  const commands = useRef<WindowCommands>({});
  const lastFocus = useRef<HTMLElement | null>(null);
  const pointerActivation = useRef(false);
  const dialogs = useDialogHost();
  const busyHolds = useRef(0);
  const [busy, setBusy] = useState(false);
  const latest = useRef({ dirty, title, dialogs, busy });
  latest.current = { dirty, title, dialogs, busy };
  const holdBusy = useCallback(() => {
    busyHolds.current += 1;
    setBusy(true);
    let released = false;
    return () => {
      if (released) return;
      released = true;
      busyHolds.current -= 1;
      setBusy(busyHolds.current > 0);
    };
  }, []);

  useEffect(() => {
    if (!active || minimized) return;
    if (pointerActivation.current) { pointerActivation.current = false; return; }
    const node = section.current;
    if (node === null || node.contains(document.activeElement) || document.querySelector('.modal-desktop') !== null) return;
    const remembered = lastFocus.current;
    const target = remembered?.isConnected === true && remembered.closest('[inert]') === null && node.contains(remembered) ? remembered
      : node.querySelector<HTMLElement>('.modal-window [data-autofocus]') ?? (body.current === null ? undefined : focusableWithin(body.current)[0]) ?? node;
    target.focus({ preventScroll: true });
  }, [active, minimized]);

  const save = useCallback(async (): Promise<boolean> => {
    const handler = commands.current.save;
    if (handler === undefined) { notify(`${latest.current.title} has nothing to save.`); return true; }
    return handler();
  }, [notify]);

  const requestClose = useCallback(async (): Promise<boolean> => {
    if (latest.current.dialogs.open) { dispatch({ type: 'focus', id }); notify(`Finish the open dialog in ${latest.current.title} before closing it.`); return false; }
    if (latest.current.busy) { dispatch({ type: 'focus', id }); notify(`${latest.current.title} is waiting for a result. Close it once the result arrives.`); return false; }
    if (!latest.current.dirty) { dispatch({ type: 'close', id }); return true; }
    dispatch({ type: 'focus', id });
    const choice = await choose(latest.current.dialogs, 'window', 'Unsaved changes',
      <p>{latest.current.title} has changes that have not been saved. Save them before closing?</p>,
      [{ value: 'save', label: 'Save and close', primary: true }, { value: 'discard', label: 'Discard changes', danger: true }], 'warning');
    if (choice === null) return false;
    if (choice === 'save' && !await save()) return false;
    dispatch({ type: 'close', id });
    return true;
  }, [dispatch, id, notify, save]);

  const print = useCallback(() => {
    if (commands.current.print !== undefined) { commands.current.print(); return; }
    const node = section.current;
    if (node === null) return;
    node.classList.add('printing');
    document.body.classList.add('print-one-window');
    try { window.print(); } finally {
      node.classList.remove('printing');
      document.body.classList.remove('print-one-window');
    }
  }, []);

  const handle = useMemo<FrameHandle>(() => ({
    requestClose,
    save: async () => { if (latest.current.dialogs.open) { notify('Finish the open dialog first.'); return; } await save(); },
    refresh: () => { commands.current.refresh?.(); },
    print,
    focusSearch: () => {
      if (commands.current.focusSearch !== undefined) { commands.current.focusSearch(); return; }
      body.current?.querySelector<HTMLElement>('input[type="search"]')?.focus();
    },
    hasDialog: () => latest.current.dialogs.open,
    isBusy: () => latest.current.busy,
  }), [notify, print, requestClose, save]);

  useEffect(() => { register(id, handle); return () => { register(id, null); }; }, [handle, id, register]);

  const api = useMemo<WindowApi>(() => ({
    id, institution, spec: record.spec, active, dialogs,
    setTitle: (next: string) => { dispatch({ type: 'update', id, title: next }); },
    setContext: (context: RecordContext) => { dispatch({ type: 'update', id, context }); },
    setDirty: (next: boolean) => { dispatch({ type: 'update', id, dirty: next }); },
    retarget: (spec: WindowSpec, next: string) => { dispatch({ type: 'retarget', id, spec, title: next }); },
    requestClose: () => { void requestClose(); },
    setCommands: (next: WindowCommands) => { commands.current = next; },
    holdBusy,
  }), [active, dialogs, dispatch, holdBusy, id, institution, record.spec, requestClose]);

  const startDrag = (event: ReactPointerEvent<HTMLElement>): void => {
    if (event.button !== 0 || (event.target as Element).closest('button') !== null || record.restoreBounds !== null) return;
    const target = event.currentTarget;
    const start = { px: event.clientX, py: event.clientY, x: bounds.x, y: bounds.y };
    target.setPointerCapture(event.pointerId);
    const onMove = (move: PointerEvent): void => { dispatch({ type: 'move', id, x: start.x + move.clientX - start.px, y: start.y + move.clientY - start.py, area: area() }); };
    const onUp = (): void => { target.removeEventListener('pointermove', onMove); target.removeEventListener('pointerup', onUp); target.removeEventListener('pointercancel', onUp); };
    target.addEventListener('pointermove', onMove);
    target.addEventListener('pointerup', onUp);
    target.addEventListener('pointercancel', onUp);
  };

  const startResize = (edge: Edge) => (event: ReactPointerEvent<HTMLElement>): void => {
    if (event.button !== 0) return;
    event.preventDefault();
    const target = event.currentTarget;
    const start = { px: event.clientX, py: event.clientY, width: bounds.width, height: bounds.height };
    target.setPointerCapture(event.pointerId);
    const onMove = (move: PointerEvent): void => {
      dispatch({ type: 'resize', id, width: edge === 's' ? start.width : start.width + move.clientX - start.px, height: edge === 'e' ? start.height : start.height + move.clientY - start.py });
    };
    const onUp = (): void => { target.removeEventListener('pointermove', onMove); target.removeEventListener('pointerup', onUp); target.removeEventListener('pointercancel', onUp); };
    target.addEventListener('pointermove', onMove);
    target.addEventListener('pointerup', onUp);
    target.addEventListener('pointercancel', onUp);
  };

  const maximized = record.restoreBounds !== null;
  return (
    <section
      ref={section} className={`window${active ? ' active' : ''}${minimized ? ' minimized' : ''}${maximized ? ' maximized' : ''}`}
      style={{ left: bounds.x, top: bounds.y, width: bounds.width, height: bounds.height, zIndex }} tabIndex={-1} inert={minimized}
      aria-label={`${title}, ${institution.displayName}${dirty ? ', unsaved changes' : ''}`} aria-busy={busy} data-window-id={id} data-window-kind={record.spec.kind} data-institution={institution.institutionId} data-active={active}
      onPointerDownCapture={() => { if (!active) { pointerActivation.current = true; dispatch({ type: 'focus', id }); } }}
      onFocusCapture={(event) => {
        const target = event.target;
        if (body.current?.contains(target) === true) lastFocus.current = target;
        if (!active) { pointerActivation.current = true; dispatch({ type: 'focus', id }); }
      }}
    >
      <header className="window-titlebar" onPointerDown={startDrag} onDoubleClick={(event) => { if ((event.target as Element).closest('button') === null) dispatch({ type: 'toggle-maximize', id, area: area() }); }}>
        <span className={`institution-badge ${badgeClass}`} title={institution.legalName}>{institution.displayName}</span>
        <h2 className="window-title">{title}</h2>
        {dirty ? <span className="dirty-mark" title="Unsaved changes" aria-hidden="true">●</span> : null}
        <div className="window-controls">
          <button type="button" aria-label={`Minimize ${title}`} title="Minimize (Alt+Shift+M)" onClick={() => { dispatch({ type: 'minimize', id }); }}>▁</button>
          <button type="button" aria-label={`${maximized ? 'Restore' : 'Maximize'} ${title}`} title={maximized ? 'Restore' : 'Maximize'} onClick={() => { dispatch({ type: 'toggle-maximize', id, area: area() }); }}>{maximized ? '❐' : '☐'}</button>
          <button type="button" aria-label={`Close ${title}`} title="Close (Alt+Shift+W)" className="close" onClick={() => { void requestClose(); }}>✕</button>
        </div>
      </header>
      <WindowContext.Provider value={api}>
        <div ref={body} className="window-body" inert={dialogs.open}>{children}</div>
        {dialogs.node}
      </WindowContext.Provider>
      {maximized ? null : <>
        <div className="resize-handle resize-e" onPointerDown={startResize('e')} aria-hidden="true" />
        <div className="resize-handle resize-s" onPointerDown={startResize('s')} aria-hidden="true" />
        <div className="resize-handle resize-se" onPointerDown={startResize('se')} aria-hidden="true" data-testid="resize-se" />
      </>}
    </section>
  );
}
