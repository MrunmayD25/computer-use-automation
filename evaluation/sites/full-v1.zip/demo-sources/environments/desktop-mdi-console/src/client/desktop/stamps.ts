import type { RecordStamp, StampResponse } from '@computer-use/financial-database/services';
import { useCallback, useSyncExternalStore } from 'react';

import { institutionPath, postJson } from '../api';

export type StampKind = 'members' | 'accounts' | 'cases';

interface Subscription {
  institutionId: string;
  kind: StampKind;
  id: string;
  listeners: Set<() => void>;
  value: RecordStamp | null | undefined;
}

const POLL_MS = 2_500;
const MAX_PER_KIND = 100;

/**
 * Polls the version and change stamp of every record open in a window, batched per institution.
 * Record windows compare these against the version their draft was based on.
 */
class StampWatcher {
  private readonly subscriptions = new Map<string, Subscription>();
  private timer: ReturnType<typeof setTimeout> | null = null;
  private polling = false;
  /** A check requested mid-poll runs right after it instead of arming a second timer. */
  private checkRequested = false;

  subscribe(institutionId: string, kind: StampKind, id: string, listener: () => void): () => void {
    const key = `${institutionId}|${kind}|${id}`;
    let subscription = this.subscriptions.get(key);
    if (subscription === undefined) {
      subscription = { institutionId, kind, id, listeners: new Set(), value: undefined };
      this.subscriptions.set(key, subscription);
    }
    subscription.listeners.add(listener);
    this.schedule();
    return () => {
      const current = this.subscriptions.get(key);
      current?.listeners.delete(listener);
      if (current?.listeners.size === 0) this.subscriptions.delete(key);
    };
  }

  get(institutionId: string, kind: StampKind, id: string): RecordStamp | null | undefined {
    return this.subscriptions.get(`${institutionId}|${kind}|${id}`)?.value;
  }

  /** Requests an immediate check, for example after a save in another window. */
  checkSoon(): void {
    if (this.polling) { this.checkRequested = true; return; }
    if (this.timer !== null) clearTimeout(this.timer);
    this.timer = setTimeout(() => { void this.poll(); }, 50);
  }

  private schedule(): void {
    if (this.timer === null && !this.polling) this.timer = setTimeout(() => { void this.poll(); }, 200);
  }

  private async poll(): Promise<void> {
    this.timer = null;
    if (this.subscriptions.size === 0) return;
    this.polling = true;
    try {
      if (document.visibilityState === 'visible') {
        const byInstitution = new Map<string, Record<StampKind, string[]>>();
        for (const subscription of this.subscriptions.values()) {
          const request = byInstitution.get(subscription.institutionId) ?? { members: [], accounts: [], cases: [] };
          if (request[subscription.kind].length < MAX_PER_KIND) request[subscription.kind].push(subscription.id);
          byInstitution.set(subscription.institutionId, request);
        }
        await Promise.all([...byInstitution].map(async ([institutionId, request]) => {
          try {
            const response = await postJson<StampResponse>(institutionPath(institutionId, '/stamps'), request);
            for (const kind of ['members', 'accounts', 'cases'] as const) {
              for (const [id, value] of Object.entries(response[kind])) {
                const subscription = this.subscriptions.get(`${institutionId}|${kind}|${id}`);
                if (subscription !== undefined && JSON.stringify(subscription.value) !== JSON.stringify(value)) {
                  subscription.value = value;
                  for (const listener of subscription.listeners) listener();
                }
              }
            }
          } catch {
            // A failed poll leaves the last known stamps in place; the next interval retries.
          }
        }));
      }
    } finally {
      this.polling = false;
      const delay = this.checkRequested ? 50 : POLL_MS;
      this.checkRequested = false;
      if (this.subscriptions.size > 0) this.timer = setTimeout(() => { void this.poll(); }, delay);
    }
  }
}

export const stampWatcher = new StampWatcher();

/** Latest server stamp for a record: undefined until the first poll, null when the record no longer exists. */
export function useRecordStamp(institutionId: string, kind: StampKind, id: string | null): RecordStamp | null | undefined {
  const subscribe = useCallback((listener: () => void) => id === null ? () => undefined : stampWatcher.subscribe(institutionId, kind, id, listener), [institutionId, kind, id]);
  return useSyncExternalStore(subscribe, () => id === null ? undefined : stampWatcher.get(institutionId, kind, id));
}
