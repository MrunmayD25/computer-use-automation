import { useEffect, useRef, useState, type ReactNode } from 'react';

import type { AccountDetail, AccountRow, OperationReview, PageResult, Receipt, Rejection, ReviewedAccount, ServiceCommand } from '@computer-use/financial-database/services';

import { ApiError, executeCommand, getJson, institutionPath, newIdempotencyKey, queryString, reviewCommand } from '../api';
import { useBusyWhile, useDesktop, useWindow, useWindowChrome, useWindowCommands } from '../desktop/context';
import { Dialog } from '../desktop/Dialog';
import type { MoneyMode } from '../desktop/state';
import { stampWatcher, useRecordStamp } from '../desktop/stamps';
import { formatInstant, formatMoney, parseAmount } from '../format';
import { Banner, DetailList, LoadFailure, Loading, SelectField, TextField, Toolbar } from '../widgets/fields';
import { useResource } from '../widgets/useResource';
import { COMMAND_LABELS, exponentOf, Money, OutcomeBanner, rejectionTitle, StatusTag, useReference, type Committed } from './common';

const MODES = {
  deposit: { kind: 'cash.deposit', label: 'Cash deposit', verb: 'Post deposit', description: 'Cash deposit' },
  withdraw: { kind: 'cash.withdraw', label: 'Cash withdrawal', verb: 'Post withdrawal', description: 'Cash withdrawal' },
  transfer: { kind: 'transfer.internal', label: 'Internal transfer', verb: 'Post transfer', description: 'Internal transfer' },
} as const;

function AccountCard({ detail, side }: { detail: AccountDetail; side: 'debit' | 'credit' }): ReactNode {
  const { account } = detail;
  const eligibility = detail.eligibility[side];
  return (
    <div className="account-card" data-testid={`account-card-${side}`}>
      <DetailList items={[
        ['Account', <span key="n" data-testid="card-account-number">{account.accountNumber}</span>], ['Owner', `${account.ownerName} (${account.memberNumber})`], ['Product', account.productName],
        ['Status', <StatusTag key="s" status={account.status} />], ['Posted balance', <Money key="p" minorUnits={account.postedMinorUnits} currency={account.currency} exponent={account.exponent} />],
        ['Available balance', <Money key="a" minorUnits={account.availableMinorUnits} currency={account.currency} exponent={account.exponent} />],
      ]} />
      {eligibility.eligible ? null : <Banner tone="warning" title={side === 'debit' ? 'Debits blocked.' : 'Credits blocked.'}>{eligibility.reasons.join(' ')}</Banner>}
    </div>
  );
}

interface ReviewDialogProps {
  institutionId: string;
  command: ServiceCommand;
  review: OperationReview;
  verb: string;
  close: () => void;
  onCommitted: (outcome: Committed) => void;
}

/** What the operator confirmed: the command, the server's review of it and the request key that posts it. */
interface ReviewedTerms { command: ServiceCommand; review: OperationReview; key: string }

async function loadAccounts(institutionId: string, accounts: readonly ReviewedAccount[]): Promise<AccountDetail[]> {
  return await Promise.all(accounts.map((account) => getJson<AccountDetail>(institutionPath(institutionId, `/accounts/${account.id}`))));
}

/** Reviewed facts that no longer hold, one line per changed account; empty while the review is current. */
function changedTerms(reviewed: readonly ReviewedAccount[], current: readonly AccountDetail[]): string[] {
  return reviewed.flatMap((account, index) => {
    const now = current[index]?.account;
    if (now === undefined) return [];
    const money = (minorUnits: number): string => formatMoney(minorUnits, account.currency, account.exponent);
    const changes = [
      ...(now.status === account.status ? [] : [`status ${account.status} is now ${now.status}`]),
      ...(now.postedMinorUnits === account.postedBeforeMinorUnits ? [] : [`posted balance ${money(account.postedBeforeMinorUnits)} is now ${money(now.postedMinorUnits)}`]),
      ...(now.availableMinorUnits === account.availableBeforeMinorUnits ? [] : [`available balance ${money(account.availableBeforeMinorUnits)} is now ${money(now.availableMinorUnits)}`]),
    ];
    if (changes.length === 0 && now.version !== account.version) changes.push(`record version ${account.version} is now ${now.version}`);
    return changes.length === 0 ? [] : [`${account.accountNumber}: ${changes.join('; ')}.`];
  });
}

/** The same command against the account versions just loaded. */
/** True when two commands differ only in their stale-binding guards (`expected*`), matching the server's intent digest. */
function sameIntent(a: ServiceCommand, b: ServiceCommand): boolean {
  const strip = (command: ServiceCommand): Record<string, unknown> => Object.fromEntries(Object.entries(command).filter(([key]) => !key.startsWith('expected')));
  return JSON.stringify(strip(a)) === JSON.stringify(strip(b));
}

function withCurrentVersions(command: ServiceCommand, current: readonly AccountDetail[]): ServiceCommand {
  const version = (id: string, fallback: number): number => current.find((detail) => detail.account.id === id)?.account.version ?? fallback;
  if (command.kind === 'transfer.internal') {
    return { ...command, expectedSourceVersion: version(command.sourceAccountId, command.expectedSourceVersion), expectedDestinationVersion: version(command.destinationAccountId, command.expectedDestinationVersion) };
  }
  if (command.kind === 'cash.deposit' || command.kind === 'cash.withdraw') return { ...command, expectedVersion: version(command.accountId, command.expectedVersion) };
  return command;
}

/**
 * Confirmation of a reviewed money command. The request key follows the command: a repeated click
 * or a retry after a lost response sends the same key and returns the original receipt. When a
 * reviewed account's status or balances change, posting waits for a fresh review. A new review
 * that changes the command gets a new key, and only after any attempt with an unknown result is
 * settled through the request-key lookup.
 */
function ReviewDialog({ institutionId, command, review, verb, close, onCommitted }: ReviewDialogProps): ReactNode {
  const [terms, setTerms] = useState<ReviewedTerms>(() => ({ command, review, key: newIdempotencyKey(command.kind) }));
  const [busy, setBusy] = useState(false);
  const [rejection, setRejection] = useState<Rejection | null>(null);
  const [failure, setFailure] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [unknownResult, setUnknownResult] = useState(false);
  const [stale, setStale] = useState<string[]>([]);
  const inFlight = useRef(false);
  useBusyWhile(busy);
  const accounts = terms.review.accounts;
  const firstStamp = useRecordStamp(institutionId, 'accounts', accounts[0]?.id ?? null)?.stamp;
  const secondStamp = useRecordStamp(institutionId, 'accounts', accounts[1]?.id ?? null)?.stamp;
  useEffect(() => {
    if (firstStamp === undefined && secondStamp === undefined) return;
    let current = true;
    loadAccounts(institutionId, accounts).then(
      (details) => { if (current) setStale(changedTerms(accounts, details)); },
      () => { if (current) setStale(['The reviewed balances could not be rechecked. Review again before posting.']); },
    );
    return () => { current = false; };
  }, [firstStamp, secondStamp, institutionId, accounts]);

  const settle = (outcome: Committed): void => { stampWatcher.checkSoon(); close(); onCommitted(outcome); };
  const run = async (work: () => Promise<void>): Promise<void> => {
    if (inFlight.current) return;
    inFlight.current = true;
    setBusy(true);
    try { await work(); } finally { inFlight.current = false; setBusy(false); }
  };
  const post = (): Promise<void> => run(async () => {
    if (rejection !== null || stale.length > 0) return;
    setFailure(null);
    setNotice(null);
    try {
      const outcome = await executeCommand(institutionId, terms.command, terms.key);
      if (outcome.kind === 'committed' || outcome.kind === 'duplicate') { settle(outcome); return; }
      setUnknownResult(false);
      if (outcome.kind === 'rejected') setRejection(outcome); else setFailure(outcome.message);
    } catch (error) {
      if (error instanceof ApiError && error.status !== 0 && error.status < 500) { setUnknownResult(false); setFailure(error.message); return; }
      setUnknownResult(true);
      setFailure(error instanceof ApiError && error.code === 'network'
        ? 'The connection failed before a result arrived. Retrying sends the same request key, so the operation cannot post twice.'
        : 'The server did not confirm the result. Retrying sends the same request key, so the operation cannot post twice.');
    }
  });
  const checkOutcome = (): Promise<void> => run(async () => {
    try {
      const receipt = await getJson<Receipt>(institutionPath(institutionId, `/operations/by-key/${encodeURIComponent(terms.key)}`));
      settle({ kind: 'duplicate', receipt });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) {
        setUnknownResult(false);
        setFailure(null);
        setNotice('Nothing was posted under this request key.');
        return;
      }
      setFailure(error instanceof ApiError ? error.message : 'The result could not be checked.');
    }
  });
  const reviewAgain = (): Promise<void> => run(async () => {
    if (unknownResult) return;
    try {
      const next = withCurrentVersions(terms.command, await loadAccounts(institutionId, accounts));
      const outcome = await reviewCommand(institutionId, next);
      setFailure(null);
      setNotice(null);
      if (outcome.kind !== 'reviewable') {
        if (outcome.kind === 'rejected') setRejection(outcome); else setFailure(outcome.message);
        return;
      }
      setRejection(null);
      setStale([]);
      setTerms({ command: next, review: outcome.review, key: sameIntent(next, terms.command) ? terms.key : newIdempotencyKey(next.kind) });
      setNotice('Reviewed again with current balances.');
    } catch (error) {
      setFailure(error instanceof ApiError ? error.message : 'The review could not be refreshed.');
    }
  });

  const current = terms.review;
  const exponent = current.exponent ?? 2;
  const needsReview = stale.length > 0 || rejection?.code === 'stale_version';
  const primary = unknownResult
    ? <button type="button" className="primary" disabled={busy} data-autofocus onClick={() => { void checkOutcome(); }}>Check outcome</button>
    : needsReview
      ? <button type="button" className="primary" disabled={busy} data-autofocus onClick={() => { void reviewAgain(); }}>Review again</button>
      : <button type="submit" className="primary" disabled={busy || rejection !== null} data-autofocus>{busy ? 'Posting…' : failure === null ? verb : 'Retry with the same request'}</button>;
  return (
    <Dialog scope="window" title={`Review ${COMMAND_LABELS[terms.command.kind]?.toLowerCase() ?? terms.command.kind}`} busy={busy} width={560} onCancel={close} onSubmit={() => { void post(); }}
      actions={<>
        {primary}
        {unknownResult && stale.length === 0 ? <button type="submit" disabled={busy}>Retry with the same request</button> : null}
        <button type="button" onClick={close} disabled={busy}>{rejection === null ? 'Back' : 'Back to form'}</button>
      </>}>
      <DetailList items={[
        ['Institution', current.institutionName],
        ['Operation', COMMAND_LABELS[current.commandKind] ?? current.commandKind],
        ...current.accounts.map((account, index): [string, ReactNode] => [current.accounts.length > 1 ? (index === 0 ? 'From' : 'To') : 'Account', `${account.accountNumber} · ${account.ownerName} (${account.memberNumber}) · ${account.productName}`]),
        ['Amount', current.amount === null ? '' : <strong key="amount" data-testid="review-amount">{formatMoney(current.amount.minorUnits, current.amount.currency, exponent)}</strong>],
        ['Description', current.description ?? ''],
      ]} />
      <table className="simple-table" aria-label="Reviewed balances">
        <thead><tr><th scope="col">Account</th><th scope="col" className="align-right">Available now</th><th scope="col" className="align-right">After posting</th></tr></thead>
        <tbody>{current.accounts.map((account) => (
          <tr key={account.id} data-testid={`review-available-${account.accountNumber}`}>
            <td>{account.accountNumber}</td>
            <td className="align-right">{formatMoney(account.availableBeforeMinorUnits, account.currency, account.exponent)}</td>
            <td className="align-right">{formatMoney(account.availableAfterMinorUnits, account.currency, account.exponent)}</td>
          </tr>
        ))}</tbody>
      </table>
      {current.consequences.length === 0 ? null : <ul className="consequences">{current.consequences.map((line) => <li key={line}>{line}</li>)}</ul>}
      {stale.length === 0 ? null : (
        <Banner tone="warning" title="Reviewed terms changed.">
          <span data-testid="review-stale">{stale.join(' ')}</span> {unknownResult ? 'Check the outcome of the earlier attempt first.' : 'Review again before posting.'}
        </Banner>
      )}
      {rejection === null ? null : <Banner tone="error" title={rejectionTitle(rejection.code)}><span data-testid="rejection-code" data-code={rejection.code}>{rejection.message}</span> Nothing was posted.</Banner>}
      {failure === null ? null : <Banner tone="warning" title={unknownResult ? 'Result unknown.' : 'Not posted.'}>{failure}</Banner>}
      {notice === null ? null : <Banner tone="info"><span data-testid="review-notice">{notice}</span></Banner>}
      <p className="hint">Request key <code data-testid="idempotency-key">{terms.key}</code></p>
    </Dialog>
  );
}

/** Deposit, withdrawal or transfer form: resolve accounts, validate, review, then post once with a receipt. */
export function MoneyWindow({ mode, accountId }: { mode: MoneyMode; accountId: string | null }): ReactNode {
  const { can, notify } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const config = MODES[mode];
  const reference = useReference(institutionId);
  const [lookup, setLookup] = useState('');
  const [sourceId, setSourceId] = useState<string | null>(accountId);
  const [destinationId, setDestinationId] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState<string>(config.description);
  const [errors, setErrors] = useState<Partial<Record<'lookup' | 'amount' | 'description' | 'destination', string | undefined>>>({});
  const [outcome, setOutcome] = useState<Parameters<typeof OutcomeBanner>[0]['outcome'] | null>(null);
  const [reviewing, setReviewing] = useState(false);
  const lookupInput = useRef<HTMLInputElement>(null);

  const source = useResource(sourceId === null ? null : () => getJson<AccountDetail>(institutionPath(institutionId, `/accounts/${sourceId}`)), `source:${sourceId ?? ''}`);
  const memberId = source.data?.account.memberId ?? null;
  const siblings = useResource(mode !== 'transfer' || memberId === null ? null
    : () => getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ memberId, status: 'open', limit: 100 })}`)), `siblings:${memberId ?? ''}`);
  const destination = useResource(destinationId === '' ? null : () => getJson<AccountDetail>(institutionPath(institutionId, `/accounts/${destinationId}`)), `destination:${destinationId}`);
  const sourceStamp = useRecordStamp(institutionId, 'accounts', sourceId);
  const destinationStamp = useRecordStamp(institutionId, 'accounts', destinationId === '' ? null : destinationId);
  const reloadSource = source.reload;
  const reloadDestination = destination.reload;
  const sourceStampKey = sourceStamp?.stamp;
  const destinationStampKey = destinationStamp?.stamp;
  useEffect(() => { if (sourceStampKey !== undefined) reloadSource(); }, [sourceStampKey, reloadSource]);
  useEffect(() => { if (destinationStampKey !== undefined) reloadDestination(); }, [destinationStampKey, reloadDestination]);

  const allowed = can(institutionId, config.kind);
  const account = source.data?.account;
  const currency = account?.currency ?? win.institution.defaultCurrency;
  const exponent = account?.exponent ?? exponentOf(reference.data, currency);
  const dirty = amount !== '' || description !== config.description || (lookup !== '' && sourceId === null) || destinationId !== '';
  useWindowChrome(account === undefined ? config.label : `${config.label} · ${account.accountNumber}`, account === undefined ? {} : { member: account.memberNumber, account: account.accountNumber }, dirty);

  const findAccount = async (): Promise<void> => {
    const number = lookup.trim().toUpperCase();
    if (number === '') { setErrors({ lookup: 'Enter an account number.' }); return; }
    try {
      const page = await getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ query: number, limit: 10 })}`));
      const match = page.items.find((row) => row.accountNumber === number);
      if (match === undefined) { setErrors({ lookup: `No account ${number} exists at ${win.institution.displayName}.` }); return; }
      setErrors({});
      setDestinationId('');
      setSourceId(match.id);
    } catch (error) {
      setErrors({ lookup: error instanceof ApiError ? error.message : 'The account lookup failed.' });
    }
  };

  const buildCommand = (): ServiceCommand | null => {
    const problems: typeof errors = {};
    if (account === undefined) problems.lookup = 'Find the account first.';
    const parsed = parseAmount(amount, exponent);
    if (!parsed.ok) problems.amount = parsed.message;
    if (description.trim() === '') problems.description = 'Enter a description for the statement.';
    if (mode === 'transfer' && destination.data === undefined) problems.destination = 'Choose the destination account.';
    setErrors(problems);
    if (Object.keys(problems).length > 0 || account === undefined || !parsed.ok) return null;
    const money = { minorUnits: parsed.minorUnits, currency: account.currency };
    if (mode === 'transfer') {
      const target = destination.data?.account;
      if (target === undefined) return null;
      return { kind: 'transfer.internal', sourceAccountId: account.id, destinationAccountId: target.id, expectedSourceVersion: account.version, expectedDestinationVersion: target.version, amount: money, description: description.trim() };
    }
    return { kind: config.kind, accountId: account.id, expectedVersion: account.version, amount: money, description: description.trim() } as ServiceCommand;
  };

  const review = async (): Promise<void> => {
    if (reviewing || win.dialogs.open) return;
    const command = buildCommand();
    if (command === null) return;
    setReviewing(true);
    try {
      const result = await reviewCommand(institutionId, command);
      if (result.kind !== 'reviewable') { setOutcome(result); if (result.kind === 'rejected' && result.field === 'amount') setErrors({ amount: result.message }); return; }
      setOutcome(null);
      win.dialogs.show((close) => (
        <ReviewDialog institutionId={institutionId} command={command} review={result.review} verb={config.verb} close={close} onCommitted={(committed) => {
          setOutcome(committed);
          setAmount('');
          setDescription(config.description);
          source.reload();
          destination.reload();
          notify(`${config.label} posted at ${win.institution.displayName}. Receipt ${committed.receipt.receiptNumber}.`);
        }} />
      ));
    } catch (error) {
      setOutcome({ kind: 'failed', message: error instanceof ApiError ? error.message : 'The review could not be prepared.' });
    } finally { setReviewing(false); }
  };

  useWindowCommands({
    save: async () => { await review(); return false; },
    refresh: () => { source.reload(); destination.reload(); siblings.reload(); },
    focusSearch: () => { lookupInput.current?.focus(); },
  });

  const destinationOptions = (siblings.data?.items ?? []).filter((row) => row.id !== sourceId);
  return (
    <div className="form-window">
      <Toolbar label={`${config.label} actions`}>
        <button type="button" className="primary" disabled={!allowed || reviewing} onClick={() => { void review(); }}>Review…</button>
        <button type="button" onClick={() => { setAmount(''); setDescription(config.description); setErrors({}); setOutcome(null); }}>Clear</button>
        <button type="button" onClick={() => { source.reload(); destination.reload(); }}>Refresh</button>
      </Toolbar>
      <div className="form-scroll">
        {allowed ? null : <Banner tone="warning" title="Not permitted.">Operator roles at {win.institution.displayName} do not include {config.label.toLowerCase()}.</Banner>}
        {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
        <form className="form-grid" onSubmit={(event) => { event.preventDefault(); void review(); }} noValidate>
          <fieldset className="fieldset-wide">
            <legend>{mode === 'transfer' ? 'From account' : 'Account'}</legend>
            <div className="inline-lookup">
              <TextField label="Account number" name="account-number" type="search" value={lookup} onChange={(value) => { setLookup(value); setErrors({}); }} error={errors.lookup} inputRef={lookupInput} placeholder="AC0000001" autoFocus={accountId === null} />
              <button type="button" onClick={() => { void findAccount(); }}>Find</button>
            </div>
            {source.error === null ? null : <LoadFailure error={source.error} onRetry={source.reload} />}
            {source.loading && source.data === undefined ? <Loading /> : null}
            {source.data === undefined ? null : <AccountCard detail={source.data} side={mode === 'deposit' ? 'credit' : 'debit'} />}
          </fieldset>
          {mode !== 'transfer' ? null : (
            <fieldset className="fieldset-wide">
              <legend>To account</legend>
              <SelectField label="Destination (same member)" name="destination" value={destinationId} onChange={(value) => { setDestinationId(value); setErrors({}); }} error={errors.destination}
                options={[{ value: '', label: account === undefined ? 'Find the source account first' : destinationOptions.length === 0 ? 'No other open accounts' : 'Choose an account' },
                  ...destinationOptions.map((row) => ({ value: row.id, label: `${row.accountNumber} · ${row.productName} · ${row.currency}${row.currency === account?.currency ? '' : ' (different currency)'}` }))]} />
              {destination.data === undefined ? null : <AccountCard detail={destination.data} side="credit" />}
            </fieldset>
          )}
          <TextField label={`Amount (${currency})`} name="amount" value={amount} onChange={(value) => { setAmount(value); setErrors((current) => ({ ...current, amount: undefined })); }} error={errors.amount} inputMode="decimal" placeholder={exponent === 0 ? '1000' : `0.${'0'.repeat(exponent)}`} autoFocus={accountId !== null} required />
          <TextField label="Description" name="description" value={description} onChange={(value) => { setDescription(value); setErrors((current) => ({ ...current, description: undefined })); }} error={errors.description} maxLength={120} required />
          <div className="form-actions"><button type="submit" className="primary" disabled={!allowed || reviewing}>{reviewing ? 'Preparing review…' : `Review ${config.label.toLowerCase()}…`}</button></div>
        </form>
      </div>
    </div>
  );
}

/** Durable receipt rebuilt from stored operation, journal and event rows. */
export function ReceiptWindow({ receiptNumber }: { receiptNumber: string }): ReactNode {
  const { open } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const reference = useReference(institutionId);
  const receipt = useResource(() => getJson<Receipt>(institutionPath(institutionId, `/receipts/${receiptNumber}`)), receiptNumber);
  const data = receipt.data;
  const member = data?.affected.find((entry) => entry.kind === 'member')?.label;
  const account = data?.affected.find((entry) => entry.kind === 'account')?.label;
  const caseLabel = data?.affected.find((entry) => entry.kind === 'case')?.label;
  useWindowChrome(`Receipt ${receiptNumber}`, { ...(member === undefined ? {} : { member }), ...(account === undefined ? {} : { account }), ...(caseLabel === undefined ? {} : { case: caseLabel }) }, false);
  useWindowCommands({ refresh: receipt.reload });
  const openRecord = (kind: string, id: string): void => {
    if (kind === 'member') open(institutionId, { kind: 'member', memberId: id });
    else if (kind === 'account') open(institutionId, { kind: 'account', accountId: id });
    else if (kind === 'case') open(institutionId, { kind: 'case', caseId: id });
  };
  return (
    <div className="form-window receipt">
      <Toolbar label="Receipt actions">
        <button type="button" onClick={receipt.reload}>Refresh</button>
      </Toolbar>
      <div className="form-scroll">
        {receipt.error === null ? null : <LoadFailure error={receipt.error} onRetry={receipt.reload} />}
        {data === undefined ? (receipt.error === null ? <Loading /> : null) : (
          <>
            <h3 className="receipt-heading">{COMMAND_LABELS[data.operationKind] ?? data.operationKind} · {win.institution.displayName}</h3>
            <DetailList items={[
              ['Receipt number', <strong key="n" data-testid="receipt-view-number">{data.receiptNumber}</strong>], ['Status', <StatusTag key="s" status={data.status} />],
              ['Committed', formatInstant(data.committedAt, win.institution.timeZone)], ['Operator', `${data.actor.actorNumber} · ${data.actor.displayName}`],
              ['Business reference', data.businessReference], ['Operation ID', <code key="o">{data.operationId}</code>],
            ]} />
            <h4>Affected records</h4>
            <ul className="link-list">
              {data.affected.map((entry) => (
                <li key={`${entry.kind}:${entry.id}`}>
                  {['member', 'account', 'case'].includes(entry.kind) ? <button type="button" className="link" onClick={() => { openRecord(entry.kind, entry.id); }}>{entry.label}</button> : entry.label}
                  <span className="muted"> {entry.kind}</span>
                </li>
              ))}
            </ul>
            {data.journals.map((journal) => (
              <div key={journal.id} className="journal">
                <h4>Journal {journal.reference} · effective {journal.effectiveDate} · {journal.description}</h4>
                <table className="simple-table" aria-label={`Journal ${journal.reference} lines`}>
                  <thead><tr><th scope="col">Line</th><th scope="col">Ledger</th><th scope="col">Account</th><th scope="col" className="align-right">Debit</th><th scope="col" className="align-right">Credit</th></tr></thead>
                  <tbody>
                    {journal.lines.map((line) => (
                      <tr key={line.lineNumber}>
                        <td>{line.lineNumber}</td><td>{line.ledgerCode}</td><td>{line.accountNumber ?? '—'}</td>
                        <td className="align-right">{line.debitMinorUnits === 0 ? '' : formatMoney(line.debitMinorUnits, line.currency, exponentOf(reference.data, line.currency))}</td>
                        <td className="align-right">{line.creditMinorUnits === 0 ? '' : formatMoney(line.creditMinorUnits, line.currency, exponentOf(reference.data, line.currency))}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ))}
            <h4>Audit events</h4>
            <ol className="event-list">{data.events.map((event) => <li key={event.sequence}>#{event.sequence} {event.kind} · {event.summary}</li>)}</ol>
          </>
        )}
      </div>
    </div>
  );
}
