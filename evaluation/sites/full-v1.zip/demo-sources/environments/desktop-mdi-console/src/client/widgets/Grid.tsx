import { useRef, useState, type KeyboardEvent, type MouseEvent, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react';

import type { ApiError } from '../api';
import { useDesktop } from '../desktop/context';
import type { MenuEntry } from '../desktop/Menu';
import { LoadFailure } from './fields';

export interface Column<T> {
  key: string;
  label: string;
  width: number;
  render: (row: T) => ReactNode;
  /** Server sort key; columns without one are not sortable. */
  sortKey?: string;
  align?: 'left' | 'right';
  /** Stored field this column shows, in the shared saved-search vocabulary. */
  field?: string;
}

export interface SortState { key: string; direction: 'asc' | 'desc' }

export interface GridProps<T> {
  label: string;
  columns: readonly Column<T>[];
  rows: readonly T[];
  rowKey: (row: T) => string;
  total: number;
  offset: number;
  limit: number;
  onPage: (offset: number) => void;
  onLimit?: (limit: number) => void;
  sort?: SortState;
  onSort?: (key: string) => void;
  selectedKey: string | null;
  onSelect: (key: string) => void;
  onOpen?: (row: T, newWindow: boolean) => void;
  contextMenu?: (row: T) => readonly MenuEntry[];
  loading: boolean;
  error: ApiError | null;
  onRetry: () => void;
  empty: ReactNode;
}

const MIN_COLUMN = 48;

/** Docked data grid with resizable columns, server sort and paging, keyboard row navigation and row context menus. */
export function Grid<T>({ label, columns, rows, rowKey, total, offset, limit, onPage, onLimit, sort, onSort, selectedKey, onSelect, onOpen, contextMenu, loading, error, onRetry, empty }: GridProps<T>): ReactNode {
  const { openContextMenu } = useDesktop();
  const [widths, setWidths] = useState<Record<string, number>>(() => Object.fromEntries(columns.map((column) => [column.key, column.width])));
  const body = useRef<HTMLTableSectionElement>(null);
  const width = (column: Column<T>): number => widths[column.key] ?? column.width;
  const focusRow = (key: string): void => { body.current?.querySelector<HTMLElement>(`tr[data-key="${CSS.escape(key)}"]`)?.focus(); };
  const showMenu = (row: T, x: number, y: number, invoker: HTMLElement): void => {
    if (contextMenu === undefined) return;
    onSelect(rowKey(row));
    openContextMenu(x, y, `${label} row actions`, contextMenu(row), invoker);
  };

  const onRowKeyDown = (event: KeyboardEvent<HTMLTableRowElement>, row: T, index: number): void => {
    const move = (next: number): void => {
      const target = rows[Math.max(0, Math.min(rows.length - 1, next))];
      if (target === undefined) return;
      onSelect(rowKey(target));
      focusRow(rowKey(target));
    };
    if (event.key === 'ArrowDown') move(index + 1);
    else if (event.key === 'ArrowUp') move(index - 1);
    else if (event.key === 'Home') move(0);
    else if (event.key === 'End') move(rows.length - 1);
    else if (event.key === 'Enter' && onOpen !== undefined) onOpen(row, event.shiftKey);
    else if (event.key === 'ContextMenu' || (event.key === 'F10' && event.shiftKey)) {
      const rect = event.currentTarget.getBoundingClientRect();
      showMenu(row, rect.left + 32, rect.bottom, event.currentTarget);
    } else return;
    event.preventDefault();
    event.stopPropagation();
  };

  const startResize = (column: Column<T>) => (event: ReactPointerEvent<HTMLSpanElement>): void => {
    event.preventDefault();
    event.stopPropagation();
    const target = event.currentTarget;
    const start = { x: event.clientX, width: width(column) };
    target.setPointerCapture(event.pointerId);
    const onMove = (move: PointerEvent): void => { setWidths((current) => ({ ...current, [column.key]: Math.max(MIN_COLUMN, start.width + move.clientX - start.x) })); };
    const onUp = (): void => { target.removeEventListener('pointermove', onMove); target.removeEventListener('pointerup', onUp); };
    target.addEventListener('pointermove', onMove);
    target.addEventListener('pointerup', onUp);
  };

  const pages = Math.max(1, Math.ceil(total / limit));
  const page = Math.floor(offset / limit) + 1;
  const tabbableKey = selectedKey !== null && rows.some((row) => rowKey(row) === selectedKey) ? selectedKey : rows[0] === undefined ? null : rowKey(rows[0]);
  return (
    <div className="grid">
      <div className="grid-scroll">
        <table role="grid" aria-label={label} aria-rowcount={total + 1} aria-busy={loading} style={{ width: columns.reduce((sum, column) => sum + width(column), 0) }}>
          <colgroup>{columns.map((column) => <col key={column.key} style={{ width: width(column) }} />)}</colgroup>
          <thead>
            <tr>
              {columns.map((column) => {
                const sorted = sort?.key === column.sortKey && column.sortKey !== undefined;
                return (
                  <th key={column.key} scope="col" aria-sort={sorted ? (sort?.direction === 'asc' ? 'ascending' : 'descending') : undefined} className={column.align === 'right' ? 'align-right' : undefined}>
                    {column.sortKey === undefined || onSort === undefined ? <span className="th-label">{column.label}</span> : (
                      <button type="button" className="th-sort" onClick={() => { if (column.sortKey !== undefined) onSort(column.sortKey); }} title={`Sort by ${column.label}`}>
                        {column.label}<span className="sort-arrow" aria-hidden="true">{sorted ? (sort?.direction === 'asc' ? ' ▲' : ' ▼') : ''}</span>
                      </button>
                    )}
                    <span
                      className="column-resizer" role="separator" aria-orientation="vertical" aria-label={`Resize ${column.label} column`} aria-valuenow={width(column)} aria-valuemin={MIN_COLUMN} tabIndex={0}
                      onPointerDown={startResize(column)}
                      onKeyDown={(event) => {
                        const delta = event.key === 'ArrowRight' ? 16 : event.key === 'ArrowLeft' ? -16 : 0;
                        if (delta === 0) return;
                        event.preventDefault();
                        setWidths((current) => ({ ...current, [column.key]: Math.max(MIN_COLUMN, width(column) + delta) }));
                      }}
                    />
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody ref={body}>
            {rows.map((row, index) => {
              const key = rowKey(row);
              return (
                <tr
                  key={key} data-key={key} aria-rowindex={offset + index + 2} aria-selected={key === selectedKey} tabIndex={key === tabbableKey ? 0 : -1}
                  onClick={() => { onSelect(key); }} onDoubleClick={(event: MouseEvent) => { onOpen?.(row, event.shiftKey); }}
                  onContextMenu={(event) => { if (contextMenu === undefined) return; event.preventDefault(); showMenu(row, event.clientX, event.clientY, event.currentTarget); }}
                  onKeyDown={(event) => { onRowKeyDown(event, row, index); }}
                >
                  {columns.map((column) => <td key={column.key} className={column.align === 'right' ? 'align-right' : undefined}>{column.render(row)}</td>)}
                </tr>
              );
            })}
          </tbody>
        </table>
        {error !== null ? <LoadFailure error={error} onRetry={onRetry} /> : null}
        {error === null && !loading && rows.length === 0 ? <div className="grid-empty" role="status">{empty}</div> : null}
        {loading ? <div className="grid-loading" role="status">Loading…</div> : null}
      </div>
      <div className="pager" role="navigation" aria-label={`${label} pages`}>
        <button type="button" aria-label="First page" disabled={page <= 1 || loading} onClick={() => { onPage(0); }}>«</button>
        <button type="button" aria-label="Previous page" disabled={page <= 1 || loading} onClick={() => { onPage(Math.max(0, offset - limit)); }}>‹</button>
        <span className="pager-text">Page {page} of {pages}</span>
        <button type="button" aria-label="Next page" disabled={page >= pages || loading} onClick={() => { onPage(offset + limit); }}>›</button>
        <button type="button" aria-label="Last page" disabled={page >= pages || loading} onClick={() => { onPage((pages - 1) * limit); }}>»</button>
        {onLimit === undefined ? null : (
          <label className="pager-limit">Rows <select value={limit} onChange={(event) => { onLimit(Number(event.target.value)); }}>{[25, 50, 100, 200].map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
        )}
        <span className="pager-summary">{total === 0 ? 'No records' : `${(offset + 1).toLocaleString('en-US')}–${Math.min(total, offset + rows.length).toLocaleString('en-US')} of ${total.toLocaleString('en-US')}`}</span>
      </div>
    </div>
  );
}

/** Toggles a server sort: same key flips direction, a new key starts ascending. */
export function nextSort(current: SortState, key: string): SortState {
  return current.key === key ? { key, direction: current.direction === 'asc' ? 'desc' : 'asc' } : { key, direction: 'asc' };
}
