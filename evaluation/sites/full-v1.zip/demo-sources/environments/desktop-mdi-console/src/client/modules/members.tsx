import { useEffect, useRef, useState, type ReactNode } from 'react';

import type { AddressInput, MemberDetail, MemberRow, ServiceCommand } from '@computer-use/financial-database/services';

import type { LimitedPage } from '../../shared/api';
import { getJson, institutionPath, queryString } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands, type DesktopApi } from '../desktop/context';
import { item, separator, type MenuEntry } from '../desktop/Menu';
import { useRecordStamp } from '../desktop/stamps';
import { formatDate, formatInstant } from '../format';
import { Banner, DetailList, LoadFailure, Loading, SelectField, TextAreaField, TextField, Toolbar } from '../widgets/fields';
import { Grid, nextSort, type Column } from '../widgets/Grid';
import { SplitPane, Tabs } from '../widgets/layout';
import { useResource } from '../widgets/useResource';
import { accountActions, ACCOUNT_COLUMNS } from './accounts';
import { ActivityPanel } from './activity';
import { caseActions, caseColumns } from './cases';
import { ConflictBanner, memberName, OutcomeBanner, StatusTag, useRecordDraft, useReference, useSubmission, type SubmitOutcome } from './common';
import { ColumnsButton, LimitHint, SavedSearchBar, textFilter, type SearchFilters, type SearchView } from './saved-searches';

const MEMBER_STATUSES = ['', 'active', 'inactive', 'deceased', 'merged'];

export function memberActions(desktop: DesktopApi, institutionId: string, row: Pick<MemberRow, 'id' | 'memberNumber'>): MenuEntry[] {
  const { open, can } = desktop;
  return [
    item('Open member', () => { open(institutionId, { kind: 'member', memberId: row.id }); }),
    item('Open in new window', () => { open(institutionId, { kind: 'member', memberId: row.id }, { reuse: false }); }),
    separator,
    item('Open account…', () => { open(institutionId, { kind: 'account-open', memberId: row.id }, { reuse: false }); }, { disabled: !can(institutionId, 'account.open') }),
    item('New case…', () => { open(institutionId, { kind: 'case-new', memberId: row.id, accountId: null }, { reuse: false }); }, { disabled: !can(institutionId, 'case.open') }),
    item('Activity', () => { open(institutionId, { kind: 'activity', memberId: row.id, accountId: null, caseId: null, label: row.memberNumber }); }),
  ];
}

const MEMBER_COLUMNS: readonly Column<MemberRow>[] = [
  { key: 'memberNumber', label: 'Member', width: 100, sortKey: 'memberNumber', field: 'member_number', render: (row) => row.memberNumber },
  { key: 'name', label: 'Name', width: 200, sortKey: 'name', field: 'display_name', render: (row) => row.displayName },
  { key: 'kind', label: 'Type', width: 90, field: 'kind', render: (row) => row.kind },
  { key: 'status', label: 'Status', width: 90, sortKey: 'status', field: 'status', render: (row) => <StatusTag status={row.status} /> },
  { key: 'email', label: 'Email', width: 200, field: 'email', render: (row) => row.email ?? '' },
  { key: 'phone', label: 'Phone', width: 130, field: 'phone', render: (row) => row.phone ?? '' },
  { key: 'accounts', label: 'Open accts', width: 84, align: 'right', field: 'open_accounts', render: (row) => row.openAccounts },
  { key: 'joined', label: 'Joined', width: 110, sortKey: 'joined', field: 'joined_at', render: (row) => formatDate(row.joinedAt) },
];

const MEMBER_VIEW: SearchView = { filters: {}, sort: { key: 'memberNumber', direction: 'asc' }, visible: MEMBER_COLUMNS.map((column) => column.key), maxResults: null };

export function MemberSearchWindow(): ReactNode {
  const desktop = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [text, setText] = useState('');
  const [view, setView] = useState<SearchView>(MEMBER_VIEW);
  const [page, setPage] = useState({ offset: 0, limit: 50 });
  const [selected, setSelected] = useState<string | null>(null);
  const search = useRef<HTMLInputElement>(null);
  const query = textFilter(view.filters, 'query');
  const status = textFilter(view.filters, 'status');
  const params = { query, status, sort: view.sort.key, direction: view.sort.direction, maxResults: view.maxResults, ...page };
  const result = useResource(() => getJson<LimitedPage<MemberRow>>(institutionPath(institutionId, `/members${queryString(params)}`)), JSON.stringify(params));
  useWindowChrome(query === '' ? 'Member search' : `Members · “${query}”`, {}, false);
  useWindowCommands({ refresh: result.reload, focusSearch: () => { search.current?.focus(); } });
  const filter = (change: SearchFilters): void => { setView((current) => ({ ...current, filters: { ...current.filters, ...change } })); setPage((current) => ({ ...current, offset: 0 })); };
  const apply = (next: SearchView): void => { setView(next); setText(textFilter(next.filters, 'query')); setPage((current) => ({ ...current, offset: 0 })); };
  const columns = view.visible.flatMap((key) => MEMBER_COLUMNS.filter((column) => column.key === key));
  return (
    <div className="grid-window">
      <form className="toolbar" role="search" aria-label="Member search" onSubmit={(event) => { event.preventDefault(); filter({ query: text.trim() }); }}>
        <input ref={search} type="search" aria-label="Search members" placeholder="Member #, name, email, phone or account #" value={text} onChange={(event) => { setText(event.target.value); }} data-autofocus />
        <button type="submit">Search</button>
        <label>Status <select value={status} onChange={(event) => { filter({ status: event.target.value }); }}>
          {MEMBER_STATUSES.map((value) => <option key={value} value={value}>{value === '' ? 'Any' : value}</option>)}
        </select></label>
        <span className="toolbar-spacer" />
        <button type="button" disabled={!desktop.can(institutionId, 'member.create')} onClick={() => { desktop.open(institutionId, { kind: 'member-new' }, { reuse: false }); }}>New member…</button>
        <button type="button" onClick={result.reload}>Refresh</button>
      </form>
      <div className="toolbar" role="toolbar" aria-label="Member search views">
        <SavedSearchBar entity="members" columns={MEMBER_COLUMNS} view={view} fallback={MEMBER_VIEW} onApply={apply} />
        <ColumnsButton columns={MEMBER_COLUMNS} visible={view.visible} onChange={(visible) => { setView((current) => ({ ...current, visible })); }} />
        <LimitHint page={result.data} />
      </div>
      <Grid
        label="Members" columns={columns} rows={result.data?.items ?? []} rowKey={(row) => row.id} total={result.data?.total ?? 0} offset={page.offset} limit={page.limit}
        onPage={(offset) => { setPage((current) => ({ ...current, offset })); }} onLimit={(limit) => { setPage({ offset: 0, limit }); }}
        sort={view.sort} onSort={(key) => { setView((current) => ({ ...current, sort: nextSort(current.sort, key) })); setPage((current) => ({ ...current, offset: 0 })); }}
        selectedKey={selected} onSelect={setSelected} onOpen={(row, newWindow) => { desktop.open(institutionId, { kind: 'member', memberId: row.id }, { reuse: !newWindow }); }}
        contextMenu={(row) => memberActions(desktop, institutionId, row)} loading={result.loading} error={result.error} onRetry={result.reload}
        empty={query === '' ? 'No members match these filters.' : `No members match “${query}” at ${win.institution.displayName}.`}
      />
    </div>
  );
}

const CONTACT_LABELS = { email: 'Email', phone: 'Phone', line1: 'Address line 1', line2: 'Address line 2', city: 'City', region: 'Region', postalCode: 'Postal code', country: 'Country' } as const;
type ContactField = keyof typeof CONTACT_LABELS;
type ContactValues = Record<ContactField, string>;
const ADDRESS_FIELDS = ['line1', 'line2', 'city', 'region', 'postalCode', 'country'] as const;

function contactValues(detail: MemberDetail): ContactValues {
  const address = detail.address;
  return {
    email: detail.email?.value ?? '', phone: detail.phone?.value ?? '', line1: address?.line1 ?? '', line2: address?.line2 ?? '', city: address?.city ?? '',
    region: address?.region ?? '', postalCode: address?.postalCode ?? '', country: address?.country ?? '',
  };
}

function addressProblems(values: ContactValues): Partial<Record<ContactField, string>> {
  const problems: Partial<Record<ContactField, string>> = {};
  for (const field of ['line1', 'city', 'region', 'postalCode', 'country'] as const) if (values[field].trim() === '') problems[field] = `${CONTACT_LABELS[field]} is required for an address.`;
  if (values.country.trim() !== '' && !/^[A-Za-z]{2}$/u.test(values.country.trim())) problems.country = 'Use a two-letter country code.';
  return problems;
}

function addressOf(values: ContactValues): AddressInput {
  return { line1: values.line1.trim(), line2: values.line2.trim() === '' ? null : values.line2.trim(), city: values.city.trim(), region: values.region.trim(), postalCode: values.postalCode.trim(), country: values.country.trim().toUpperCase() };
}

/** Member inquiry and contact maintenance with notes, accounts and cases side by side. */
export function MemberWindow({ memberId }: { memberId: string }): ReactNode {
  const desktop = useDesktop();
  const { open, can, notify } = desktop;
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const detail = useResource(() => getJson<MemberDetail>(institutionPath(institutionId, `/members/${memberId}`)), memberId);
  const stamp = useRecordStamp(institutionId, 'members', memberId);
  const reload = detail.reload;
  const stampKey = stamp?.stamp;
  useEffect(() => { if (stampKey !== undefined) reload(); }, [stampKey, reload]);
  const data = detail.data;
  const source = data === undefined ? undefined : { version: data.member.version, values: contactValues(data) };
  const editor = useRecordDraft(memberId, source, stamp?.version);
  const [errors, setErrors] = useState<Partial<Record<ContactField | 'note', string>>>({});
  const [note, setNote] = useState({ text: '', visibility: 'general' });
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const [leftTab, setLeftTab] = useState('contact');
  const [rightTab, setRightTab] = useState('accounts');
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);
  const [selectedCase, setSelectedCase] = useState<string | null>(null);
  const submission = useSubmission();
  const dirty = (editor?.dirty ?? false) || note.text.trim() !== '';
  useWindowChrome(data === undefined ? 'Member' : `Member ${data.member.memberNumber} · ${memberName(data)}`, data === undefined ? {} : { member: data.member.memberNumber }, dirty);

  const saveContact = async (): Promise<boolean> => {
    if (editor === null || data === undefined || !editor.dirty) return true;
    if (editor.conflictVersion !== null) { setLeftTab('contact'); notify(`Member ${data.member.memberNumber} changed elsewhere. Resolve the conflict before saving.`, 'error'); return false; }
    const values = editor.draft;
    const problems: Partial<Record<ContactField, string>> = {};
    if (editor.edited('email') && values.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/u.test(values.email.trim())) problems.email = 'Enter a valid email address.';
    if (editor.edited('phone') && values.phone.trim() !== '' && !/^\+?[0-9 ()-]{7,20}$/u.test(values.phone.trim())) problems.phone = 'Enter a phone number of 7 to 20 digits.';
    const addressEdited = ADDRESS_FIELDS.some((field) => editor.edited(field));
    if (addressEdited) Object.assign(problems, addressProblems(values));
    setErrors(problems);
    if (Object.keys(problems).length > 0) { setLeftTab('contact'); return false; }
    const command: ServiceCommand = {
      kind: 'contact.update', memberId, expectedVersion: editor.version,
      ...(editor.edited('email') ? { email: values.email.trim() === '' ? null : values.email.trim() } : {}),
      ...(editor.edited('phone') ? { phone: values.phone.trim() === '' ? null : values.phone.trim() } : {}),
      ...(addressEdited ? { address: addressOf(values) } : {}),
    };
    const result = await submission.submit(institutionId, command);
    if (result === null) return false;
    setOutcome(result);
    reload();
    if (result.kind === 'committed' || result.kind === 'duplicate') { editor.saved(editor.version + 1); return true; }
    if (result.kind === 'unchanged') { editor.discard(); return true; }
    if (result.kind === 'rejected' && result.field !== undefined) {
      const field = result.field.replace(/^address\./u, '') as ContactField;
      if (field in CONTACT_LABELS) setErrors({ [field]: result.message });
    }
    setLeftTab('contact');
    return false;
  };
  const addNote = async (): Promise<boolean> => {
    if (note.text.trim() === '') return true;
    const result = await submission.submit(institutionId, { kind: 'member.note.add', memberId, visibility: note.visibility as 'general', text: note.text.trim() });
    if (result === null) return false;
    setOutcome(result);
    if (result.kind === 'committed' || result.kind === 'duplicate') { setNote({ text: '', visibility: 'general' }); reload(); return true; }
    setLeftTab('notes');
    return false;
  };
  const save = async (): Promise<boolean> => {
    if (!dirty) { notify('This member has no unsaved changes.'); return true; }
    const saved = await saveContact() && await addNote();
    if (saved) notify(`Saved member ${data?.member.memberNumber ?? ''}.`);
    return saved;
  };
  useWindowCommands({ save, refresh: reload });

  if (data === undefined || editor === null) {
    return <div className="record-window">{detail.error === null ? <Loading /> : <LoadFailure error={detail.error} onRetry={reload} />}</div>;
  }
  const member = data.member;
  const canMaintain = can(institutionId, 'contact.update') && !['deceased', 'merged'].includes(member.status);
  const field = (name: ContactField, extra: { type?: 'email' | 'tel'; maxLength?: number } = {}): ReactNode => (
    <TextField label={CONTACT_LABELS[name]} name={name} value={editor.draft[name]} onChange={(value) => { editor.set(name, value); setErrors((current) => ({ ...current, [name]: undefined })); }}
      error={errors[name]} changed={editor.edited(name)} readOnly={!canMaintain} {...extra} />
  );
  const contact = (
    <div className="panel-scroll">
      <ConflictBanner subject={`Member ${member.memberNumber}`} editor={editor} labels={CONTACT_LABELS} latestLoaded={member.version >= (editor.conflictVersion ?? 0)} onReload={reload} />
      {canMaintain ? null : <Banner tone="info">{member.status === 'active' || member.status === 'inactive' ? 'Your role cannot change contact details.' : `Contact details of a ${member.status} member cannot change.`}</Banner>}
      <form className="form-grid" aria-label="Contact details" noValidate onSubmit={(event) => { event.preventDefault(); void save(); }}>
        {field('email', { type: 'email', maxLength: 254 })}
        {field('phone', { type: 'tel', maxLength: 32 })}
        <fieldset className="fieldset-wide">
          <legend>Mailing address{data.address === null ? '' : ` · evidence ${data.address.evidenceStatus}`}</legend>
          <div className="form-grid">{ADDRESS_FIELDS.map((name) => <div key={name}>{field(name, { maxLength: name === 'country' ? 2 : 120 })}</div>)}</div>
        </fieldset>
        <div className="form-actions">
          <button type="submit" className="primary" disabled={!dirty || submission.pending}>{submission.pending ? 'Saving…' : 'Save'}</button>
          <button type="button" disabled={!editor.dirty || submission.pending} onClick={() => { editor.discard(); setErrors({}); }}>Cancel edits</button>
          <span className="muted">Editing version {editor.version}. Other windows may edit other records freely.</span>
        </div>
      </form>
    </div>
  );
  const identity = (
    <div className="panel-scroll">
      <DetailList items={data.person === null ? [
        ['Legal name', data.organization?.legalName ?? ''], ['Registration', data.organization?.registrationNumber ?? ''], ['Organization type', data.organization?.organizationType ?? ''],
      ] : [
        ['Legal given name', data.person.legalGiven], ['Legal family name', data.person.legalFamily], ['Preferred name', data.person.preferredName ?? ''],
        ['Birth date', formatDate(data.person.birthDate)], ['Deceased', formatDate(data.person.deceasedAt)],
      ]} />
      <DetailList items={[['Member number', member.memberNumber], ['Status', <StatusTag key="s" status={member.status} />], ['Joined', formatDate(member.joinedAt)], ['Tax classification', member.taxClassification], ['Record version', `v${String(member.version)}`]]} />
    </div>
  );
  const notes = (
    <div className="panel-scroll">
      <form className="form-grid" aria-label="Add member note" onSubmit={(event) => { event.preventDefault(); void addNote(); }}>
        <TextAreaField label="New note" name="member-note" value={note.text} onChange={(text) => { setNote({ ...note, text }); }} maxLength={2000} rows={3} error={errors.note} />
        <SelectField label="Visibility" value={note.visibility} onChange={(visibility) => { setNote({ ...note, visibility }); }} options={[{ value: 'general', label: 'General' }, { value: 'restricted', label: 'Restricted' }]} />
        <div className="form-actions"><button type="submit" className="primary" disabled={note.text.trim() === '' || submission.pending || !can(institutionId, 'member.note.add')}>Add note</button></div>
      </form>
      {data.notes.length === 0 ? <p className="empty">No notes yet.</p> : (
        <ol className="note-list">{data.notes.map((entry) => (
          <li key={entry.id}><div className="note-meta">{formatInstant(entry.createdAt, win.institution.timeZone)} · {entry.actor?.displayName ?? 'system'} · {entry.visibility}</div><div className="note-text">{entry.text}</div></li>
        ))}</ol>
      )}
    </div>
  );
  const accounts = (
    <Grid
      label={`Accounts of ${member.memberNumber}`} columns={ACCOUNT_COLUMNS.filter((column) => !['memberNumber', 'owner'].includes(column.key))} rows={data.accounts} rowKey={(row) => row.id}
      total={data.accounts.length} offset={0} limit={Math.max(1, data.accounts.length)} onPage={() => undefined} selectedKey={selectedAccount} onSelect={setSelectedAccount}
      onOpen={(row, newWindow) => { open(institutionId, { kind: 'account', accountId: row.id }, { reuse: !newWindow }); }} contextMenu={(row) => accountActions(desktop, institutionId, row)}
      loading={detail.loading} error={null} onRetry={reload} empty="This member has no accounts."
    />
  );
  const cases = (
    <Grid
      label={`Cases of ${member.memberNumber}`} columns={caseColumns(win.institution.timeZone).filter((column) => column.key !== 'member')} rows={data.cases} rowKey={(row) => row.id}
      total={data.cases.length} offset={0} limit={Math.max(1, data.cases.length)} onPage={() => undefined} selectedKey={selectedCase} onSelect={setSelectedCase}
      onOpen={(row, newWindow) => { open(institutionId, { kind: 'case', caseId: row.id }, { reuse: !newWindow }); }} contextMenu={(row) => caseActions(desktop, institutionId, row)}
      loading={detail.loading} error={null} onRetry={reload} empty="No cases for this member."
    />
  );
  return (
    <div className="record-window">
      <Toolbar label="Member actions">
        <button type="button" onClick={() => { void save(); }} disabled={!dirty || submission.pending}>Save</button>
        <button type="button" onClick={reload}>Refresh</button>
        <span className="toolbar-separator" />
        <button type="button" disabled={!can(institutionId, 'account.open') || member.status !== 'active'} onClick={() => { open(institutionId, { kind: 'account-open', memberId }, { reuse: false }); }}>Open account…</button>
        <button type="button" disabled={!can(institutionId, 'case.open')} onClick={() => { open(institutionId, { kind: 'case-new', memberId, accountId: null }, { reuse: false }); }}>New case…</button>
        <button type="button" onClick={() => { open(institutionId, { kind: 'member-servicing', memberId }); }}>Servicing…</button>
        <button type="button" onClick={() => { open(institutionId, { kind: 'finance-records', resource: 'payment', scope: { memberId }, label: `Payments · ${member.memberNumber}` }); }}>Payments</button>
        <button type="button" onClick={() => { open(institutionId, { kind: 'finance-records', resource: 'loan', scope: { memberId }, label: `Loans · ${member.memberNumber}` }); }}>Loans</button>
        <button type="button" onClick={() => { open(institutionId, { kind: 'activity', memberId, accountId: null, caseId: null, label: member.memberNumber }); }}>Activity</button>
      </Toolbar>
      <div className="record-header">
        <div><span className="record-number">{member.memberNumber}</span> <strong>{memberName(data)}</strong> <StatusTag status={member.status} /> <span className="muted">{member.kind} · joined {formatDate(member.joinedAt)}</span></div>
      </div>
      {data.redirectTo === null ? null : <Banner tone="info" title="Merged record." actions={<button type="button" onClick={() => { if (data.redirectTo !== null) open(institutionId, { kind: 'member', memberId: data.redirectTo.memberId }); }}>Open {data.redirectTo.memberNumber}</button>}>This member was merged into {data.redirectTo.memberNumber}.</Banner>}
      {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
      <SplitPane orientation="horizontal" initialPercent={55} label="Resize member panes"
        first={<Tabs label="Member details" selected={leftTab} onSelect={setLeftTab} tabs={[
          { id: 'contact', label: 'Contact', content: () => contact },
          { id: 'identity', label: 'Identity', content: () => identity },
          { id: 'notes', label: 'Notes', badge: data.notes.length, content: () => notes },
        ]} />}
        second={<Tabs label="Member relationships" selected={rightTab} onSelect={setRightTab} tabs={[
          { id: 'accounts', label: 'Accounts', badge: data.accounts.length, content: () => accounts },
          { id: 'cases', label: 'Cases', badge: data.cases.length, content: () => cases },
          { id: 'activity', label: 'Activity', content: () => <ActivityPanel scope={{ memberId }} label={`Activity for ${member.memberNumber}`} revision={stampKey ?? ''} /> },
        ]} />}
      />
    </div>
  );
}

const NEW_MEMBER = { legalGiven: '', legalFamily: '', preferredName: '', birthDate: '', email: '', phone: '', line1: '', line2: '', city: '', region: '', postalCode: '', country: '' };
type NewMemberField = keyof typeof NEW_MEMBER;

/** Member onboarding. On success the window becomes the new member's editor. */
export function NewMemberWindow(): ReactNode {
  const { can, notify } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [form, setForm] = useState(NEW_MEMBER);
  const [errors, setErrors] = useState<Partial<Record<NewMemberField, string>>>({});
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const submission = useSubmission();
  const dirty = Object.values(form).some((value) => value !== '');
  useWindowChrome('New member', {}, dirty);
  const set = (name: NewMemberField) => (value: string): void => { setForm((current) => ({ ...current, [name]: value })); setErrors((current) => ({ ...current, [name]: undefined })); };
  const submit = async (): Promise<boolean> => {
    const problems: Partial<Record<NewMemberField, string>> = {};
    if (form.legalGiven.trim() === '') problems.legalGiven = 'Enter the legal given name.';
    if (form.legalFamily.trim() === '') problems.legalFamily = 'Enter the legal family name.';
    if (!/^\d{4}-\d{2}-\d{2}$/u.test(form.birthDate)) problems.birthDate = 'Enter the birth date.';
    else if (form.birthDate >= win.institution.asOf.slice(0, 10)) problems.birthDate = 'The birth date must be before the business date.';
    if (form.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/u.test(form.email.trim())) problems.email = 'Enter a valid email address.';
    const hasAddress = ADDRESS_FIELDS.some((name) => form[name].trim() !== '');
    if (hasAddress) Object.assign(problems, addressProblems(form));
    setErrors(problems);
    if (Object.keys(problems).length > 0) return false;
    const result = await submission.submit(institutionId, {
      kind: 'member.create', legalGiven: form.legalGiven.trim(), legalFamily: form.legalFamily.trim(), preferredName: form.preferredName.trim() === '' ? null : form.preferredName.trim(),
      birthDate: form.birthDate, email: form.email.trim() === '' ? null : form.email.trim(), phone: form.phone.trim() === '' ? null : form.phone.trim(), address: hasAddress ? addressOf(form) : null,
    });
    if (result === null) return false;
    if (result.kind === 'committed' || result.kind === 'duplicate') {
      const created = result.receipt.affected.find((entry) => entry.kind === 'member');
      notify(`Created member ${created?.label ?? ''}. Receipt ${result.receipt.receiptNumber}.`);
      if (created !== undefined) win.retarget({ kind: 'member', memberId: created.id }, `Member ${created.label}`);
      return true;
    }
    setOutcome(result);
    if (result.kind === 'rejected' && result.field !== undefined && result.field.replace(/^address\./u, '') in NEW_MEMBER) setErrors({ [result.field.replace(/^address\./u, '')]: result.message });
    return false;
  };
  useWindowCommands({ save: submit });
  const allowed = can(institutionId, 'member.create');
  return (
    <div className="form-window">
      <div className="form-scroll">
        {allowed ? null : <Banner tone="warning" title="Not permitted.">Operator roles at {win.institution.displayName} do not include member onboarding.</Banner>}
        {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
        <form className="form-grid" aria-label="New member" noValidate onSubmit={(event) => { event.preventDefault(); void submit(); }}>
          <TextField label="Legal given name" value={form.legalGiven} onChange={set('legalGiven')} error={errors.legalGiven} maxLength={60} required autoFocus />
          <TextField label="Legal family name" value={form.legalFamily} onChange={set('legalFamily')} error={errors.legalFamily} maxLength={60} required />
          <TextField label="Preferred name" value={form.preferredName} onChange={set('preferredName')} error={errors.preferredName} maxLength={60} />
          <TextField label="Birth date" type="date" value={form.birthDate} onChange={set('birthDate')} error={errors.birthDate} required />
          <TextField label="Email" type="email" value={form.email} onChange={set('email')} error={errors.email} maxLength={254} />
          <TextField label="Phone" type="tel" value={form.phone} onChange={set('phone')} error={errors.phone} maxLength={32} />
          <fieldset className="fieldset-wide">
            <legend>Mailing address (optional)</legend>
            <div className="form-grid">{ADDRESS_FIELDS.map((name) => <div key={name}><TextField label={CONTACT_LABELS[name]} value={form[name]} onChange={set(name)} error={errors[name]} maxLength={name === 'country' ? 2 : 120} /></div>)}</div>
          </fieldset>
          <div className="form-actions"><button type="submit" className="primary" disabled={!allowed || submission.pending}>{submission.pending ? 'Creating…' : 'Create member'}</button></div>
        </form>
      </div>
    </div>
  );
}

/** Opens a deposit account for a member. On success the window becomes the account's editor. */
export function OpenAccountWindow({ memberId }: { memberId: string }): ReactNode {
  const { can, notify } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const reference = useReference(institutionId);
  const member = useResource(() => getJson<MemberDetail>(institutionPath(institutionId, `/members/${memberId}`)), memberId);
  const [form, setForm] = useState({ productId: '', nickname: '', statementDelivery: 'electronic' });
  const [errors, setErrors] = useState<{ productId?: string; nickname?: string }>({});
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const submission = useSubmission();
  const dirty = form.productId !== '' || form.nickname !== '';
  useWindowChrome(member.data === undefined ? 'Open account' : `Open account · ${member.data.member.memberNumber}`, member.data === undefined ? {} : { member: member.data.member.memberNumber }, dirty);
  const submit = async (): Promise<boolean> => {
    const problems: typeof errors = {};
    if (form.productId === '') problems.productId = 'Choose a product.';
    if (form.nickname.trim() === '' || form.nickname.trim().length > 40) problems.nickname = 'Enter a nickname of 1 to 40 characters.';
    setErrors(problems);
    if (Object.keys(problems).length > 0) return false;
    const result = await submission.submit(institutionId, { kind: 'account.open', memberId, productId: form.productId, nickname: form.nickname.trim(), statementDelivery: form.statementDelivery as 'paper' | 'electronic' });
    if (result === null) return false;
    if (result.kind === 'committed' || result.kind === 'duplicate') {
      const created = result.receipt.affected.find((entry) => entry.kind === 'account');
      notify(`Opened account ${created?.label ?? ''}. Receipt ${result.receipt.receiptNumber}.`);
      if (created !== undefined) win.retarget({ kind: 'account', accountId: created.id }, `Account ${created.label}`);
      return true;
    }
    setOutcome(result);
    return false;
  };
  useWindowCommands({ save: submit, refresh: member.reload });
  const allowed = can(institutionId, 'account.open');
  return (
    <div className="form-window">
      <div className="form-scroll">
        {member.error === null ? null : <LoadFailure error={member.error} onRetry={member.reload} />}
        {member.data === undefined ? <Loading /> : <p><strong>{member.data.member.memberNumber}</strong> · {memberName(member.data)} <StatusTag status={member.data.member.status} /> · {member.data.member.openAccounts} open accounts</p>}
        {allowed ? null : <Banner tone="warning" title="Not permitted.">Operator roles at {win.institution.displayName} do not include account opening.</Banner>}
        {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
        <form className="form-grid" aria-label="Open account" noValidate onSubmit={(event) => { event.preventDefault(); void submit(); }}>
          <SelectField label="Product" value={form.productId} onChange={(productId) => { setForm({ ...form, productId }); }} error={errors.productId} required
            options={[{ value: '', label: 'Choose a deposit product' }, ...(reference.data?.products ?? []).map((product) => ({ value: product.id, label: `${product.name} · ${product.currency}` }))]} />
          <TextField label="Nickname" value={form.nickname} onChange={(nickname) => { setForm({ ...form, nickname }); }} error={errors.nickname} maxLength={40} required />
          <SelectField label="Statement delivery" value={form.statementDelivery} onChange={(statementDelivery) => { setForm({ ...form, statementDelivery }); }} options={[{ value: 'electronic', label: 'Electronic' }, { value: 'paper', label: 'Paper' }]} />
          <div className="form-actions"><button type="submit" className="primary" disabled={!allowed || submission.pending}>{submission.pending ? 'Opening…' : 'Open account'}</button></div>
        </form>
      </div>
    </div>
  );
}
