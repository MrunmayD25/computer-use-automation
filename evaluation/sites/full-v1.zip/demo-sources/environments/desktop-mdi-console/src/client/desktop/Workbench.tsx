import { useState, type ReactNode } from 'react';

import type { ActivityRow, CaseRow, PageResult } from '@computer-use/financial-database/services';

import { getJson, institutionPath, queryString } from '../api';
import { formatDate, formatInstant } from '../format';
import { useResource } from '../widgets/useResource';
import { useDesktop } from './context';
import type { DesktopState, WindowSpec } from './state';

const DESKS: readonly [string, WindowSpec][] = [
  ['Find member', { kind: 'member-search' }], ['Find account', { kind: 'account-search' }],
  ['Case register', { kind: 'case-register' }], ['Cash deposit', { kind: 'money', mode: 'deposit', accountId: null }],
  ['Documents', { kind: 'documents' }], ['Approvals', { kind: 'approvals' }],
  ['Payments, cards and loans', { kind: 'operations' }], ['Reconciliation', { kind: 'reconciliation' }],
];

/** Institution-bound landing desk; record windows keep their own context when this desk changes. */
export function Workbench({ institutionId, recent }: { institutionId: string; recent: DesktopState['recent'] }): ReactNode {
  const { session, institution, open } = useDesktop();
  const bank = institution(institutionId);
  const operator = session.operator.profiles[institutionId];
  const [ownership, setOwnership] = useState('all');
  const params = queryString({ states: 'open,pending-customer,pending-internal,reopened', sort: 'due', direction: 'asc', limit: 8, offset: 0,
    ...(ownership === 'mine' ? { assignedActorId: operator?.actorId ?? 'unassigned' } : ownership === 'unassigned' ? { assignedActorId: 'unassigned' } : {}) });
  const cases = useResource(() => getJson<PageResult<CaseRow>>(institutionPath(institutionId, `/cases${params}`)), `${institutionId}|${params}`);
  const activity = useResource(() => getJson<PageResult<ActivityRow>>(institutionPath(institutionId, '/activity?limit=8&offset=0')), institutionId);
  return <section className="workbench" aria-label="Operations workbench">
    <header className="workbench-heading"><div><h1>{bank.displayName}</h1><p>Operations desk · {formatDate(bank.asOf)}</p></div>
      <div><strong>{operator?.displayName ?? session.operator.actorNumber}</strong><p>{operator?.roles.join(', ') ?? 'No institution access'}</p></div>
      <button type="button" onClick={() => { cases.reload(); activity.reload(); }}>Refresh workbench</button></header>
    <nav className="workbench-launcher" aria-label="Work desks">{DESKS.map(([label, spec]) => <button type="button" key={label} onClick={() => { open(institutionId, spec); }}>{label}</button>)}</nav>
    <div className="workbench-columns"><section className="workbench-panel" aria-label="Case work queue">
      <header><h2>Case work queue</h2><label>Assignment <select value={ownership} onChange={(event) => { setOwnership(event.target.value); }}><option value="all">All active cases</option><option value="mine">Assigned to me</option><option value="unassigned">Unassigned</option></select></label></header>
      <p className="workbench-caption">Earliest due first · {cases.data?.total ?? '…'} active cases · showing up to 8</p>
      {cases.loading ? <p role="status">Loading case queue…</p> : cases.error ? <p role="alert">{cases.error.message} <button type="button" onClick={cases.reload}>Retry cases</button></p> : <div className="workbench-table"><table><thead><tr><th>Case / member</th><th>Work required</th><th>Owner / queue</th><th>Due</th></tr></thead><tbody>
        {cases.data?.items.map((row) => <tr key={row.id}><td><button type="button" className="link" onClick={() => { open(institutionId, { kind: 'case', caseId: row.id }); }}>{row.caseNumber}</button><small>{row.memberNumber} · {row.memberName}</small></td><td>{row.summary}<small>{row.priority} · {row.state}</small></td><td>{row.assignedName ?? 'Unassigned'}<small>{row.queueName}</small></td><td className={row.overdue ? 'overdue' : undefined}>{formatInstant(row.dueAt, bank.timeZone)}{row.overdue ? <small>Overdue</small> : null}</td></tr>)}
      </tbody></table>{cases.data?.items.length === 0 ? <p>No active cases for this assignment. Choose another assignment or open the case register.</p> : null}</div>}
    </section><section className="workbench-panel" aria-label="Recent institution activity"><header><h2>Recent activity</h2><button type="button" onClick={() => { open(institutionId, { kind: 'activity', memberId: null, accountId: null, caseId: null, label: bank.displayName }); }}>View all</button></header>
      {activity.loading ? <p role="status">Loading activity…</p> : activity.error ? <p role="alert">{activity.error.message} <button type="button" onClick={activity.reload}>Retry activity</button></p> : <ul className="workbench-activity">{activity.data?.items.map((row) => <li key={row.sequence}><strong>{row.summary}</strong><small>{formatInstant(row.occurredAt, bank.timeZone)} · {row.actor?.displayName ?? 'System'}</small>{row.receiptNumber === null ? null : <button type="button" className="link" onClick={() => { open(institutionId, { kind: 'receipt', receiptNumber: row.receiptNumber ?? '' }); }}>{row.receiptNumber}</button>}</li>)}</ul>}
      {!activity.loading && !activity.error && activity.data?.items.length === 0 ? <p>No committed activity yet. Completed work and receipts will appear here.</p> : null}
    </section></div>
    <section className="workbench-recent" aria-label="Recently opened records"><h2>Recently opened</h2>{recent.filter((entry) => entry.institutionId === institutionId).length === 0 ? <p>Open a record from a work desk or queue to begin.</p> : recent.filter((entry) => entry.institutionId === institutionId).slice(0, 8).map((entry, index) => <button type="button" key={index} onClick={() => { open(entry.institutionId, entry.spec); }}>{entry.title}</button>)}</section>
  </section>;
}
