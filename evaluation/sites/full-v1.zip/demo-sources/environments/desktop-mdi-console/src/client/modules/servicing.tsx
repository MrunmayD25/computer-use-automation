import { useState, type ReactNode } from 'react';

import type { MemberDetail } from '@computer-use/financial-database/services';

import { ApiError, getJson, institutionPath, postJson } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands } from '../desktop/context';
import { Banner, Loading, TextField, Toolbar } from '../widgets/fields';
import { describeValue } from '../format';
import { useResource } from '../widgets/useResource';
import { memberName } from './common';

type Rows = Record<string, unknown>[];

function useMemberScopedList(path: string | null, key: string): { rows: Rows | null; error: ApiError | null; loading: boolean; reload: () => void } {
  const win = useWindow();
  const resource = useResource(path === null ? null : () => getJson<Rows>(institutionPath(win.institution.institutionId, path)), key);
  return { rows: resource.data ?? null, error: resource.error, loading: resource.loading, reload: resource.reload };
}

interface Tab {
  id: string;
  label: string;
  path: (memberId: string) => string;
  columns: { key: string; label: string }[];
  /** Operations offered from this tab, with the prefill built from the member and the row. */
  actions?: { commandKind: string; label: string; prefill?: (row: Record<string, unknown>, memberId: string) => Record<string, unknown> }[];
  /** Operations offered once per tab rather than per row. */
  tabActions?: { commandKind: string; label: string }[];
}

const TABS: readonly Tab[] = [
  {
    id: 'evidence', label: 'Identity evidence',
    path: (m) => `/servicing/identity-evidence/${encodeURIComponent(m)}`,
    columns: [{ key: 'kind', label: 'Kind' }, { key: 'status', label: 'Status' }, { key: 'issuedAt', label: 'Issued' }, { key: 'expiresAt', label: 'Expires' }, { key: 'sourceReference', label: 'Reference' }],
    tabActions: [
      { commandKind: 'member.identity_evidence.register', label: 'Register evidence' },
      { commandKind: 'member.identity.verify', label: 'Verify identity' },
    ],
  },
  {
    id: 'addresses', label: 'Addresses',
    path: (m) => `/servicing/addresses/${encodeURIComponent(m)}`,
    columns: [{ key: 'purpose', label: 'Purpose' }, { key: 'line1', label: 'Line 1' }, { key: 'city', label: 'City' }, { key: 'region', label: 'Region' }, { key: 'evidenceStatus', label: 'Evidence' }, { key: 'validFrom', label: 'From' }],
    tabActions: [
      { commandKind: 'maintenance.address.reconcile', label: 'Reconcile address' },
      { commandKind: 'maintenance.address.destination.update', label: 'Update destination' },
    ],
  },
  {
    id: 'destinations', label: 'Destinations',
    path: (m) => `/servicing/destinations/${encodeURIComponent(m)}`,
    columns: [{ key: 'context', label: 'Context' }, { key: 'targetId', label: 'Target' }, { key: 'partyAddressId', label: 'Address' }, { key: 'effectiveAt', label: 'Effective' }, { key: 'endsAt', label: 'Ends' }],
  },
  {
    id: 'consents', label: 'Consents',
    path: (m) => `/servicing/consents/${encodeURIComponent(m)}`,
    columns: [{ key: 'purpose', label: 'Purpose' }, { key: 'channel', label: 'Channel' }, { key: 'state', label: 'State' }, { key: 'effectiveAt', label: 'Effective' }],
    actions: [
      { commandKind: 'consent.withdraw', label: 'Withdraw', prefill: (row) => ({ consentId: row.id }) },
    ],
    tabActions: [{ commandKind: 'consent.delivery.record', label: 'Record consent delivery' }],
  },
  {
    id: 'preferences', label: 'Preferences',
    path: (m) => `/servicing/preferences/${encodeURIComponent(m)}`,
    columns: [{ key: 'purpose', label: 'Purpose' }, { key: 'channel', label: 'Channel' }, { key: 'state', label: 'State' }],
    tabActions: [{ commandKind: 'communication.preference.update', label: 'Update preference' }],
  },
  {
    id: 'maintenance', label: 'Maintenance requests',
    path: (m) => `/servicing/maintenance-requests/${encodeURIComponent(m)}`,
    columns: [{ key: 'requestNumber', label: 'Request' }, { key: 'subject', label: 'Subject' }, { key: 'category', label: 'Category' }, { key: 'state', label: 'State' }, { key: 'updatedAt', label: 'Updated' }],
    actions: [
      { commandKind: 'maintenance.draft.amend', label: 'Amend', prefill: (row) => ({ requestId: row.id, expectedUpdatedAt: row.updatedAt }) },
      { commandKind: 'maintenance.request.submit', label: 'Submit', prefill: (row) => ({ requestId: row.id, expectedUpdatedAt: row.updatedAt }) },
      { commandKind: 'maintenance.request.withdraw', label: 'Withdraw', prefill: (row) => ({ requestId: row.id, expectedUpdatedAt: row.updatedAt }) },
      { commandKind: 'maintenance.request.review', label: 'Review', prefill: (row) => ({ requestId: row.id, expectedUpdatedAt: row.updatedAt }) },
      { commandKind: 'maintenance.request.process', label: 'Process', prefill: (row) => ({ requestId: row.id, expectedUpdatedAt: row.updatedAt }) },
      { commandKind: 'edit.cancel', label: 'Cancel draft', prefill: (row) => ({ requestId: row.id, expectedUpdatedAt: row.updatedAt }) },
    ],
    tabActions: [{ commandKind: 'maintenance.draft.save', label: 'New maintenance draft' }],
  },
  {
    id: 'communications', label: 'Communications',
    path: (m) => `/servicing/communication-jobs/${encodeURIComponent(m)}`,
    columns: [{ key: 'purpose', label: 'Purpose' }, { key: 'channel', label: 'Channel' }, { key: 'destination', label: 'Destination' }, { key: 'state', label: 'State' }],
    actions: [
      { commandKind: 'communication.delivery.update', label: 'Update delivery', prefill: (row) => ({ jobId: row.id, expectedState: row.state }) },
    ],
    tabActions: [{ commandKind: 'communication.send', label: 'Send communication' }],
  },
  {
    id: 'documents', label: 'Documents',
    path: (m) => `/servicing/documents/${encodeURIComponent(m)}`,
    columns: [{ key: 'displayName', label: 'Document' }, { key: 'documentType', label: 'Type' }, { key: 'version', label: 'V' }, { key: 'status', label: 'Status' }, { key: 'mediaType', label: 'Media' }],
    tabActions: [
      { commandKind: 'document.index', label: 'Index document' },
      { commandKind: 'document.signature.collect', label: 'Collect signature' },
      { commandKind: 'document.annotation.update', label: 'Annotate' },
      { commandKind: 'document.metadata.update', label: 'Update metadata' },
      { commandKind: 'document.bundle.redact', label: 'Redact bundle' },
      { commandKind: 'document.retention_hold.apply', label: 'Retention hold' },
      { commandKind: 'document.customer_export.create', label: 'Customer export' },
    ],
  },
  {
    id: 'names', label: 'Name history',
    path: (m) => `/servicing/name-history/${encodeURIComponent(m)}`,
    columns: [{ key: 'kind', label: 'Kind' }, { key: 'givenName', label: 'Given' }, { key: 'familyName', label: 'Family' }, { key: 'validFrom', label: 'From' }, { key: 'validTo', label: 'To' }, { key: 'evidenceId', label: 'Evidence' }],
    tabActions: [
      { commandKind: 'member.legal_name.update', label: 'Update legal name' },
      { commandKind: 'member.preferred_name.update', label: 'Update preferred name' },
    ],
  },
  {
    id: 'tax', label: 'Tax history',
    path: (m) => `/servicing/tax-history/${encodeURIComponent(m)}`,
    columns: [{ key: 'classification', label: 'Classification' }, { key: 'validFrom', label: 'From' }, { key: 'validTo', label: 'To' }, { key: 'evidenceId', label: 'Evidence' }],
    tabActions: [{ commandKind: 'member.tax_classification.update', label: 'Update classification' }],
  },
];

function cellText(row: Record<string, unknown>, key: string): string {
  const value = row[key];
  if (value === null || value === undefined) return '—';
  if (typeof value === 'object') return JSON.stringify(value);
  return describeValue(value);
}

/** Member servicing center: every member-scoped servicing list and its operations in tabbed panes. */
export function MemberServicingWindow({ memberId }: { memberId: string }): ReactNode {
  const { open, can } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [tab, setTab] = useState('evidence');
  const detail = useResource(() => getJson<MemberDetail>(institutionPath(institutionId, `/members/${encodeURIComponent(memberId)}`)), `member:${memberId}`);
  const active = TABS.find((entry) => entry.id === tab) ?? TABS[0] ?? ({ id: 'evidence', label: '', path: () => '', columns: [] } satisfies Tab);
  const list = useMemberScopedList(active.path(memberId), `${active.id}:${memberId}`);
  const member = detail.data;
  const title = member === undefined ? 'Member servicing' : `Servicing · ${memberName(member)}`;
  useWindowChrome(title, member === undefined ? {} : { member: member.member.memberNumber }, false);
  useWindowCommands({ refresh: () => { detail.reload(); list.reload(); } });
  const run = (commandKind: string, prefill: Record<string, unknown>): void => {
    open(institutionId, { kind: 'operation', commandKind, prefill: { memberId, ...prefill } }, { reuse: false });
  };
  return (
    <div className="record-window">
      <div className="tab-list" role="tablist" aria-label="Servicing views">
        {TABS.map((entry) => <button key={entry.id} type="button" role="tab" aria-selected={entry.id === tab} className="tab" onClick={() => { setTab(entry.id); }}>{entry.label}</button>)}
      </div>
      <Toolbar label={`${active.label} actions`}>
        {(active.tabActions ?? []).map((action) => (
          <button key={action.commandKind} type="button" disabled={!can(institutionId, action.commandKind)} onClick={() => { run(action.commandKind, {}); }}>{action.label}…</button>
        ))}
        <button type="button" onClick={() => { list.reload(); }}>Refresh</button>
      </Toolbar>
      {list.loading ? <Loading label={`Loading ${active.label.toLowerCase()}…`} /> : null}
      {list.error === null ? null : <Banner tone="error" title="Could not load.">{list.error.message}</Banner>}
      {list.rows !== null && list.rows.length === 0 ? <Banner tone="info">No {active.label.toLowerCase()} for this member.</Banner> : null}
      {list.rows === null ? null : (
        <div className="grid-scroll">
          <table className="grid" data-testid={`servicing-${active.id}`}>
            <thead><tr><th scope="col">Id</th>{active.columns.map((column) => <th key={column.key} scope="col">{column.label}</th>)}{(active.actions ?? []).length === 0 ? null : <th scope="col" />}</tr></thead>
            <tbody>
              {list.rows.map((row) => (
                <tr key={String(row.id ?? row.versionId)} data-record={String(row.id ?? row.versionId)}>
                  <td><code>{String(row.id ?? row.versionId)}</code></td>
                  {active.columns.map((column) => <td key={column.key}>{cellText(row, column.key)}</td>)}
                  {(active.actions ?? []).length === 0 ? null : (
                    <td className="row-actions">
                      {(active.actions ?? []).map((action) => (
                        <button key={action.commandKind} type="button" disabled={!can(institutionId, action.commandKind)}
                          onClick={() => { run(action.commandKind, action.prefill?.(row, memberId) ?? {}); }}>{action.label}</button>
                      ))}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

interface IdentityCandidate { memberId: string; memberNumber: string; displayName: string; score: number; matchedFields: string[] }

/** Identity resolution: enter known evidence and inspect the candidates the service scores. */
export function IdentityResolveWindow(): ReactNode {
  const win = useWindow();
  const { open } = useDesktop();
  const institutionId = win.institution.institutionId;
  const [criteria, setCriteria] = useState({ memberNumber: '', email: '', phone: '', taxId: '', birthDate: '' });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ resolution: string; candidates: IdentityCandidate[] } | null>(null);
  const [failure, setFailure] = useState<string | null>(null);
  useWindowChrome(`Identity resolution · ${win.institution.displayName}`, {}, false);
  const resolve = async (): Promise<void> => {
    setBusy(true);
    setFailure(null);
    try {
      const body = Object.fromEntries(Object.entries(criteria).filter(([, value]) => value.trim() !== ''));
      setResult(await postJson(institutionPath(institutionId, '/identity/resolve'), body));
    } catch (error) {
      setFailure(error instanceof ApiError ? error.message : 'Resolution failed.');
    } finally { setBusy(false); }
  };
  return (
    <div className="form-window">
      <Toolbar label="Identity resolution">
        <button type="button" className="primary" disabled={busy} onClick={() => { void resolve(); }}>Resolve</button>
      </Toolbar>
      <p className="hint">Resolution never creates records: it reports none, one unique, or ambiguous candidates with the matched fields.</p>
      <div className="form-grid">
        <TextField label="Member number" value={criteria.memberNumber} onChange={(v) => { setCriteria({ ...criteria, memberNumber: v }); }} />
        <TextField label="Email" value={criteria.email} onChange={(v) => { setCriteria({ ...criteria, email: v }); }} />
        <TextField label="Phone" value={criteria.phone} onChange={(v) => { setCriteria({ ...criteria, phone: v }); }} />
        <TextField label="Tax id" value={criteria.taxId} onChange={(v) => { setCriteria({ ...criteria, taxId: v }); }} />
        <TextField label="Birth date" type="date" value={criteria.birthDate} onChange={(v) => { setCriteria({ ...criteria, birthDate: v }); }} />
      </div>
      {failure === null ? null : <Banner tone="error">{failure}</Banner>}
      {result === null ? null : (
        <Banner tone={result.resolution === 'unique' ? 'success' : result.resolution === 'none' ? 'info' : 'warning'} title={`Resolution: ${result.resolution}.`}>
          {result.candidates.length === 0 ? 'No member matched the supplied evidence.' : null}
        </Banner>
      )}
      {result === null || result.candidates.length === 0 ? null : (
        <table className="grid" data-testid="identity-candidates">
          <thead><tr><th scope="col">Member</th><th scope="col">Score</th><th scope="col">Matched fields</th><th scope="col" /></tr></thead>
          <tbody>
            {result.candidates.map((candidate) => (
              <tr key={candidate.memberId}>
                <td>{candidate.memberNumber} · {candidate.displayName}</td>
                <td>{candidate.score}</td>
                <td>{candidate.matchedFields.join(', ')}</td>
                <td><button type="button" onClick={() => { open(institutionId, { kind: 'member', memberId: candidate.memberId }); }}>Open member</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
