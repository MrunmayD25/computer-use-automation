import { useEffect, useRef, useState, type ReactNode } from 'react';

import type { AccountDetail, AccountRow, DocumentRow, PageResult, TransactionRow } from '@computer-use/financial-database/services';

import type { LimitedPage } from '../../shared/api';
import { getJson, institutionPath, queryString } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands, type DesktopApi } from '../desktop/context';
import { choose } from '../desktop/Dialog';
import { item, separator, type MenuEntry } from '../desktop/Menu';
import { useRecordStamp } from '../desktop/stamps';
import { formatDate, formatInstant, formatMoney, parseAmount } from '../format';
import { Banner, DetailList, LoadFailure, Loading, SelectField, TextAreaField, TextField, Toolbar } from '../widgets/fields';
import { Grid, nextSort, type Column } from '../widgets/Grid';
import { Tabs } from '../widgets/layout';
import { useResource } from '../widgets/useResource';
import { ActivityPanel } from './activity';
import { addDays, ConflictBanner, Money, OutcomeBanner, StatusTag, useRecordDraft, useReference, useSubmission, type SubmitOutcome } from './common';
import { ColumnsButton, LimitHint, SavedSearchBar, textFilter, type SearchFilters, type SearchView } from './saved-searches';

export function accountActions(desktop: DesktopApi, institutionId: string, row: Pick<AccountRow, 'id' | 'accountNumber' | 'memberId' | 'memberNumber'>): MenuEntry[] {
  const { open, can } = desktop;
  return [
    item('Open account', () => { open(institutionId, { kind: 'account', accountId: row.id }); }),
    item('Open in new window', () => { open(institutionId, { kind: 'account', accountId: row.id }, { reuse: false }); }),
    separator,
    item('Cash deposit…', () => { open(institutionId, { kind: 'money', mode: 'deposit', accountId: row.id }, { reuse: false }); }, { disabled: !can(institutionId, 'cash.deposit') }),
    item('Cash withdrawal…', () => { open(institutionId, { kind: 'money', mode: 'withdraw', accountId: row.id }, { reuse: false }); }, { disabled: !can(institutionId, 'cash.withdraw') }),
    item('Transfer from this account…', () => { open(institutionId, { kind: 'money', mode: 'transfer', accountId: row.id }, { reuse: false }); }, { disabled: !can(institutionId, 'transfer.internal') }),
    separator,
    item(`Member ${row.memberNumber}`, () => { open(institutionId, { kind: 'member', memberId: row.memberId }); }),
    item('New case…', () => { open(institutionId, { kind: 'case-new', memberId: row.memberId, accountId: row.id }, { reuse: false }); }, { disabled: !can(institutionId, 'case.open') }),
    item('Activity', () => { open(institutionId, { kind: 'activity', memberId: null, accountId: row.id, caseId: null, label: row.accountNumber }); }),
  ];
}

export const ACCOUNT_COLUMNS: readonly Column<AccountRow>[] = [
  { key: 'accountNumber', label: 'Account', width: 110, sortKey: 'accountNumber', field: 'account_number', render: (row) => row.accountNumber },
  { key: 'memberNumber', label: 'Member', width: 96, sortKey: 'memberNumber', field: 'member_number', render: (row) => row.memberNumber },
  { key: 'owner', label: 'Owner', width: 170, sortKey: 'owner', field: 'owner_name', render: (row) => row.ownerName },
  { key: 'product', label: 'Product', width: 160, sortKey: 'product', field: 'product_name', render: (row) => row.productName },
  { key: 'status', label: 'Status', width: 96, sortKey: 'status', field: 'status', render: (row) => <StatusTag status={row.status} /> },
  { key: 'nickname', label: 'Nickname', width: 150, sortKey: 'nickname', field: 'nickname', render: (row) => row.nickname },
  { key: 'posted', label: 'Posted', width: 130, sortKey: 'posted', align: 'right', field: 'posted_minor_units', render: (row) => <Money minorUnits={row.postedMinorUnits} currency={row.currency} exponent={row.exponent} /> },
  { key: 'available', label: 'Available', width: 130, sortKey: 'available', align: 'right', field: 'available_minor_units', render: (row) => <Money minorUnits={row.availableMinorUnits} currency={row.currency} exponent={row.exponent} /> },
];

const ACCOUNT_STATUSES = ['', 'open', 'dormant', 'restricted', 'closed', 'matured'];
const ACCOUNT_VIEW: SearchView = { filters: {}, sort: { key: 'accountNumber', direction: 'asc' }, visible: ACCOUNT_COLUMNS.map((column) => column.key), maxResults: null };

export function AccountSearchWindow(): ReactNode {
  const desktop = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const reference = useReference(institutionId);
  const [text, setText] = useState('');
  const [view, setView] = useState<SearchView>(ACCOUNT_VIEW);
  const [page, setPage] = useState({ offset: 0, limit: 50 });
  const [selected, setSelected] = useState<string | null>(null);
  const search = useRef<HTMLInputElement>(null);
  const query = textFilter(view.filters, 'query');
  const status = textFilter(view.filters, 'status');
  const currency = textFilter(view.filters, 'currency');
  const params = { query, status, currency, sort: view.sort.key, direction: view.sort.direction, maxResults: view.maxResults, ...page };
  const result = useResource(() => getJson<LimitedPage<AccountRow>>(institutionPath(institutionId, `/accounts${queryString(params)}`)), JSON.stringify(params));
  useWindowChrome(query === '' ? 'Account search' : `Accounts · “${query}”`, {}, false);
  useWindowCommands({ refresh: result.reload, focusSearch: () => { search.current?.focus(); } });
  const filter = (change: SearchFilters): void => { setView((current) => ({ ...current, filters: { ...current.filters, ...change } })); setPage((current) => ({ ...current, offset: 0 })); };
  const apply = (next: SearchView): void => { setView(next); setText(textFilter(next.filters, 'query')); setPage((current) => ({ ...current, offset: 0 })); };
  const columns = view.visible.flatMap((key) => ACCOUNT_COLUMNS.filter((column) => column.key === key));
  return (
    <div className="grid-window">
      <form className="toolbar" role="search" aria-label="Account search" onSubmit={(event) => { event.preventDefault(); filter({ query: text.trim() }); }}>
        <input ref={search} type="search" aria-label="Search accounts" placeholder="Account #, member #, owner or nickname" value={text} onChange={(event) => { setText(event.target.value); }} data-autofocus />
        <button type="submit">Search</button>
        <label>Status <select value={status} onChange={(event) => { filter({ status: event.target.value }); }}>{ACCOUNT_STATUSES.map((value) => <option key={value} value={value}>{value === '' ? 'Any' : value}</option>)}</select></label>
        <label>Currency <select value={currency} onChange={(event) => { filter({ currency: event.target.value }); }}>
          <option value="">Any</option>{(reference.data?.currencies ?? []).map((item) => <option key={item.code} value={item.code}>{item.code}</option>)}
        </select></label>
        <span className="toolbar-spacer" />
        <button type="button" onClick={result.reload}>Refresh</button>
      </form>
      <div className="toolbar" role="toolbar" aria-label="Account search views">
        <SavedSearchBar entity="accounts" columns={ACCOUNT_COLUMNS} view={view} fallback={ACCOUNT_VIEW} onApply={apply} />
        <ColumnsButton columns={ACCOUNT_COLUMNS} visible={view.visible} onChange={(visible) => { setView((current) => ({ ...current, visible })); }} />
        <LimitHint page={result.data} />
      </div>
      <Grid
        label="Accounts" columns={columns} rows={result.data?.items ?? []} rowKey={(row) => row.id} total={result.data?.total ?? 0} offset={page.offset} limit={page.limit}
        onPage={(offset) => { setPage((current) => ({ ...current, offset })); }} onLimit={(limit) => { setPage({ offset: 0, limit }); }}
        sort={view.sort} onSort={(key) => { setView((current) => ({ ...current, sort: nextSort(current.sort, key) })); setPage((current) => ({ ...current, offset: 0 })); }}
        selectedKey={selected} onSelect={setSelected} onOpen={(row, newWindow) => { desktop.open(institutionId, { kind: 'account', accountId: row.id }, { reuse: !newWindow }); }}
        contextMenu={(row) => accountActions(desktop, institutionId, row)} loading={result.loading} error={result.error} onRetry={result.reload}
        empty={query === '' ? 'No accounts match these filters.' : `No accounts match “${query}”.`}
      />
    </div>
  );
}

function TransactionsPanel({ account }: { account: AccountRow }): ReactNode {
  const { open } = useDesktop();
  const { institution } = useWindow();
  const institutionId = institution.institutionId;
  const empty = { from: '', through: '', direction: '', min: '', max: '', text: '', reference: '', status: '', order: 'newest' };
  const [form, setForm] = useState(empty);
  const [applied, setApplied] = useState(empty);
  const [errors, setErrors] = useState<Partial<Record<'min' | 'max' | 'through', string>>>({});
  const [page, setPage] = useState({ offset: 0, limit: 50 });
  const [selected, setSelected] = useState<string | null>(null);
  const minor = (value: string): number | undefined => { const parsed = parseAmount(value, account.exponent); return value.trim() === '' || !parsed.ok ? undefined : parsed.minorUnits; };
  const range = { startDate: applied.from === '' ? undefined : applied.from, endDate: applied.through === '' ? undefined : addDays(applied.through, 1) };
  const params = {
    ...range, direction: applied.direction === '' ? undefined : applied.direction, minMinorUnits: minor(applied.min), maxMinorUnits: minor(applied.max), text: applied.text === '' ? undefined : applied.text,
    reference: applied.reference.trim() === '' ? undefined : applied.reference.trim(), status: applied.status === '' ? undefined : applied.status, order: applied.order, ...page,
  };
  const result = useResource(() => getJson<PageResult<TransactionRow>>(institutionPath(institutionId, `/accounts/${account.id}/transactions${queryString(params)}`)),
    `${JSON.stringify(params)}|${String(account.postedMinorUnits)}|${String(account.availableMinorUnits)}`);
  const apply = (): void => {
    const problems: typeof errors = {};
    for (const field of ['min', 'max'] as const) { const parsed = parseAmount(form[field], account.exponent); if (form[field].trim() !== '' && !parsed.ok) problems[field] = parsed.message; }
    if (form.from !== '' && form.through !== '' && form.through < form.from) problems.through = 'The end date is before the start date.';
    setErrors(problems);
    if (Object.keys(problems).length > 0) return;
    setApplied(form);
    setPage((current) => ({ ...current, offset: 0 }));
  };
  const money = (value: number): string => formatMoney(value, account.currency, account.exponent);
  const columns: Column<TransactionRow>[] = [
    { key: 'date', label: 'Date', width: 104, render: (row) => formatDate(row.effectiveDate) },
    { key: 'reference', label: 'Reference', width: 124, render: (row) => row.reference },
    { key: 'description', label: 'Description', width: 200, render: (row) => row.description },
    { key: 'counterparty', label: 'Counterparty', width: 150, render: (row) => row.counterparty ?? '' },
    { key: 'debit', label: 'Debit', width: 120, align: 'right', render: (row) => row.amountMinorUnits < 0 ? money(-row.amountMinorUnits) : '' },
    { key: 'credit', label: 'Credit', width: 120, align: 'right', render: (row) => row.amountMinorUnits > 0 ? money(row.amountMinorUnits) : '' },
    { key: 'balance', label: 'Balance', width: 130, align: 'right', render: (row) => money(row.runningBalanceMinorUnits) },
    { key: 'status', label: 'Status', width: 90, render: (row) => <StatusTag status={row.status} /> },
    { key: 'receipt', label: 'Receipt', width: 116, render: (row) => row.receiptNumber ?? '' },
    { key: 'posted', label: 'Posted at', width: 150, render: (row) => formatInstant(row.postedAt, institution.timeZone) },
  ];
  const exportHref = `${institutionPath(institutionId, `/accounts/${account.id}/transactions.csv`)}${queryString(range)}`;
  return (
    <div className="grid-panel">
      <form className="filter-bar" aria-label="Transaction filters" onSubmit={(event) => { event.preventDefault(); apply(); }}>
        <TextField label="From" type="date" value={form.from} onChange={(value) => { setForm({ ...form, from: value }); }} />
        <TextField label="Through" type="date" value={form.through} onChange={(value) => { setForm({ ...form, through: value }); }} error={errors.through} />
        <SelectField label="Direction" value={form.direction} onChange={(value) => { setForm({ ...form, direction: value }); }} options={[{ value: '', label: 'Both' }, { value: 'credit', label: 'Credits' }, { value: 'debit', label: 'Debits' }]} />
        <TextField label="Min amount" value={form.min} inputMode="decimal" onChange={(value) => { setForm({ ...form, min: value }); }} error={errors.min} />
        <TextField label="Max amount" value={form.max} inputMode="decimal" onChange={(value) => { setForm({ ...form, max: value }); }} error={errors.max} />
        <TextField label="Text" type="search" value={form.text} onChange={(value) => { setForm({ ...form, text: value }); }} />
        <TextField label="Reference" value={form.reference} onChange={(value) => { setForm({ ...form, reference: value }); }} placeholder="TX0000000001" />
        <SelectField label="Status" value={form.status} onChange={(value) => { setForm({ ...form, status: value }); }} options={[{ value: '', label: 'Any' }, { value: 'posted', label: 'Posted' }, { value: 'reversed', label: 'Reversed' }]} />
        <SelectField label="Order" value={form.order} onChange={(value) => { setForm({ ...form, order: value }); }} options={[{ value: 'newest', label: 'Newest first' }, { value: 'oldest', label: 'Oldest first' }]} />
        <div className="filter-actions">
          <button type="submit">Apply</button>
          <button type="button" onClick={() => { setForm(empty); setApplied(empty); setErrors({}); }}>Reset</button>
          <a className="button" href={exportHref} download>Export CSV</a>
        </div>
      </form>
      <Grid
        label={`Transactions for ${account.accountNumber}`} columns={columns} rows={result.data?.items ?? []} rowKey={(row) => `${row.journalId}:${String(row.lineNumber)}`}
        total={result.data?.total ?? 0} offset={page.offset} limit={page.limit} onPage={(offset) => { setPage((current) => ({ ...current, offset })); }} onLimit={(limit) => { setPage({ offset: 0, limit }); }}
        selectedKey={selected} onSelect={setSelected} onOpen={(row) => { if (row.receiptNumber !== null) open(institutionId, { kind: 'receipt', receiptNumber: row.receiptNumber }); }}
        contextMenu={(row) => [item(row.receiptNumber === null ? 'No receipt (seeded history)' : `Open receipt ${row.receiptNumber}`, () => { if (row.receiptNumber !== null) open(institutionId, { kind: 'receipt', receiptNumber: row.receiptNumber }); }, { disabled: row.receiptNumber === null })]}
        loading={result.loading} error={result.error} onRetry={result.reload} empty="No transactions match these filters."
      />
    </div>
  );
}

function StatementsPanel({ account }: { account: AccountRow }): ReactNode {
  const { institution } = useWindow();
  const institutionId = institution.institutionId;
  const result = useResource(() => getJson<{ periods: string[]; documents: DocumentRow[] }>(institutionPath(institutionId, `/accounts/${account.id}/statements`)), `${account.id}|${String(account.postedMinorUnits)}`);
  if (result.error !== null) return <LoadFailure error={result.error} onRetry={result.reload} />;
  if (result.data === undefined) return <Loading />;
  const { periods, documents } = result.data;
  return (
    <div className="panel-scroll">
      <h4>Generated statements</h4>
      <p className="hint">Rendered on request from posted ledger entries as of the business date. Each download carries its SHA-256 digest in the response.</p>
      {periods.length === 0 ? <p className="empty">No statement periods yet.</p> : (
        <table className="simple-table" aria-label="Statement periods">
          <thead><tr><th scope="col">Period</th><th scope="col">Download</th></tr></thead>
          <tbody>{periods.map((period) => (
            <tr key={period}><td>{period}</td><td><a href={`${institutionPath(institutionId, `/accounts/${account.id}/statement.pdf`)}${queryString({ period })}`} download>Statement {period} (PDF)</a></td></tr>
          ))}</tbody>
        </table>
      )}
      <h4>Stored documents</h4>
      {documents.length === 0 ? <p className="empty">No stored documents for this account.</p> : (
        <table className="simple-table" aria-label="Stored documents">
          <thead><tr><th scope="col">Document</th><th scope="col">Type</th><th scope="col">Version</th><th scope="col">Period</th><th scope="col">Issued</th><th scope="col">Size</th><th scope="col">Digest</th><th scope="col">Download</th></tr></thead>
          <tbody>{documents.map((document) => (
            <tr key={document.versionId}>
              <td>{document.displayName}</td><td>{document.documentType}</td><td>{document.version}</td><td>{document.periodStart === null ? '' : `${document.periodStart} – ${document.periodEnd ?? ''}`}</td>
              <td>{formatInstant(document.issuedAt, institution.timeZone)}</td><td>{Math.ceil(document.byteLength / 1024)} KB</td><td><code title={document.digest}>{document.digest.slice(0, 12)}…</code></td>
              <td><a href={institutionPath(institutionId, `/documents/${document.versionId}/content`)} download>Download</a></td>
            </tr>
          ))}</tbody>
        </table>
      )}
    </div>
  );
}

const ACCOUNT_FIELD_LABELS = { nickname: 'Nickname', statementDelivery: 'Statement delivery' } as const;

/** Account inquiry and maintenance with transactions, statements, activity and closure. */
export function AccountWindow({ accountId }: { accountId: string }): ReactNode {
  const desktop = useDesktop();
  const { open, can, notify } = desktop;
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const detail = useResource(() => getJson<AccountDetail>(institutionPath(institutionId, `/accounts/${accountId}`)), accountId);
  const stamp = useRecordStamp(institutionId, 'accounts', accountId);
  const reload = detail.reload;
  const stampKey = stamp?.stamp;
  useEffect(() => { if (stampKey !== undefined) reload(); }, [stampKey, reload]);
  const data = detail.data;
  const account = data?.account;
  const source = account === undefined ? undefined : { version: account.version, values: { nickname: account.nickname, statementDelivery: account.statementDelivery } };
  const editor = useRecordDraft(accountId, source, stamp?.version);
  const [tab, setTab] = useState('overview');
  const [closeReason, setCloseReason] = useState('');
  const [closeError, setCloseError] = useState<string | undefined>(undefined);
  const [nicknameError, setNicknameError] = useState<string | undefined>(undefined);
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const submission = useSubmission();
  const siblings = useResource(account === undefined ? null : () => getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ memberId: account.memberId, limit: 100 })}`)), account?.memberId ?? '');
  const dirty = (editor?.dirty ?? false) || closeReason.trim() !== '';
  useWindowChrome(account === undefined ? 'Account' : `Account ${account.accountNumber}${account.nickname === '' ? '' : ` · ${account.nickname}`}`,
    account === undefined ? {} : { member: account.memberNumber, account: account.accountNumber }, dirty);
  const canMaintain = can(institutionId, 'account.nickname.update');

  const save = async (): Promise<boolean> => {
    if (editor === null || account === undefined) return true;
    if (!editor.dirty) { notify(`Account ${account.accountNumber} has no unsaved changes.`); return true; }
    if (editor.conflictVersion !== null) { setTab('overview'); notify(`Account ${account.accountNumber} changed elsewhere. Resolve the conflict before saving.`, 'error'); return false; }
    const nickname = editor.draft.nickname.trim();
    if (editor.edited('nickname') && (nickname === '' || nickname.length > 40)) { setTab('overview'); setNicknameError('Enter a nickname of 1 to 40 characters.'); return false; }
    setNicknameError(undefined);
    let version = editor.version;
    const saved: ('nickname' | 'statementDelivery')[] = [];
    let last: SubmitOutcome | null = null;
    const steps = [
      ...(editor.edited('nickname') ? [{ field: 'nickname' as const, command: () => ({ kind: 'account.nickname.update' as const, accountId, expectedVersion: version, nickname }) }] : []),
      ...(editor.edited('statementDelivery') ? [{ field: 'statementDelivery' as const, command: () => ({ kind: 'account.statement_delivery.update' as const, accountId, expectedVersion: version, statementDelivery: editor.draft.statementDelivery as 'paper' | 'electronic' }) }] : []),
    ];
    for (const step of steps) {
      const result = await submission.submit(institutionId, step.command());
      if (result === null) return false;
      last = result;
      if (result.kind === 'committed' || result.kind === 'duplicate') { version += 1; saved.push(step.field); continue; }
      if (result.kind === 'unchanged') { saved.push(step.field); continue; }
      break;
    }
    if (saved.length > 0) editor.saved(version, saved);
    setOutcome(last);
    reload();
    if (saved.length === steps.length) { notify(`Saved account ${account.accountNumber}.`); return true; }
    setTab('overview');
    return false;
  };

  const closeAccount = async (): Promise<void> => {
    if (account === undefined || data === undefined) return;
    const reason = closeReason.trim();
    if (reason === '') { setCloseError('Enter the reason for closing the account.'); return; }
    setCloseError(undefined);
    const choice = await choose(win.dialogs, 'window', `Close account ${account.accountNumber}`, (
      <><p>The account closes as of the business date. This cannot be reversed from this desktop.</p>
        <DetailList items={[['Account', `${account.accountNumber} · ${account.productName}`], ['Owner', `${account.ownerName} (${account.memberNumber})`],
          ['Posted balance', <Money key="p" minorUnits={account.postedMinorUnits} currency={account.currency} exponent={account.exponent} />], ['Reason', reason]]} /></>
    ), [{ value: 'close', label: 'Close account', primary: true, danger: true }], 'warning');
    if (choice !== 'close') return;
    const result = await submission.submit(institutionId, { kind: 'account.close', accountId, expectedVersion: account.version, reason });
    if (result === null) return;
    setOutcome(result);
    if (result.kind === 'committed' || result.kind === 'duplicate') { setCloseReason(''); notify(`Closed account ${account.accountNumber}.`); }
    reload();
  };

  const switchTo = async (targetId: string): Promise<void> => {
    if (targetId === accountId) return;
    if (submission.pending) { notify(`Account ${account?.accountNumber ?? ''} is waiting for a result. Switch once it arrives.`); return; }
    if (dirty) {
      const choice = await choose(win.dialogs, 'window', 'Switch account', <p>Account {account?.accountNumber} has unsaved changes. Discard them and switch?</p>, [{ value: 'switch', label: 'Discard and switch', danger: true }], 'warning');
      if (choice !== 'switch') return;
    }
    win.retarget({ kind: 'account', accountId: targetId }, 'Account');
  };

  useWindowCommands({ save, refresh: () => { reload(); siblings.reload(); } });

  if (data === undefined || account === undefined || editor === null) {
    return <div className="record-window">{detail.error === null ? <Loading /> : <LoadFailure error={detail.error} onRetry={reload} />}</div>;
  }
  const eligibility = data.eligibility;
  const overview = (
    <div className="panel-scroll">
      <ConflictBanner subject={`Account ${account.accountNumber}`} editor={editor} labels={ACCOUNT_FIELD_LABELS} latestLoaded={account.version >= (editor.conflictVersion ?? 0)} onReload={reload} />
      <form className="form-grid" aria-label="Account maintenance" onSubmit={(event) => { event.preventDefault(); void save(); }}>
        <TextField label="Nickname" name="nickname" value={editor.draft.nickname} onChange={(value) => { editor.set('nickname', value); }} maxLength={40} error={nicknameError} changed={editor.edited('nickname')} readOnly={!canMaintain || account.status === 'closed'} />
        <SelectField label="Statement delivery" name="statement-delivery" value={editor.draft.statementDelivery} onChange={(value) => { editor.set('statementDelivery', value); }} changed={editor.edited('statementDelivery')}
          options={[{ value: 'paper', label: 'Paper', disabled: !canMaintain }, { value: 'electronic', label: 'Electronic', disabled: !canMaintain }]} />
        <div className="form-actions">
          <button type="submit" className="primary" disabled={!editor.dirty || submission.pending || !canMaintain}>{submission.pending ? 'Saving…' : 'Save changes'}</button>
          <button type="button" disabled={!editor.dirty || submission.pending} onClick={() => { editor.discard(); setNicknameError(undefined); }}>Cancel edits</button>
        </div>
      </form>
      <h4>Eligibility</h4>
      <ul className="eligibility">
        {(['debit', 'credit', 'closure'] as const).map((side) => (
          <li key={side} className={eligibility[side].eligible ? 'ok' : 'blocked'}>{side === 'debit' ? 'Withdrawals and transfers out' : side === 'credit' ? 'Deposits and transfers in' : 'Closure'}: {eligibility[side].eligible ? 'allowed' : eligibility[side].reasons.join(' ')}</li>
        ))}
      </ul>
      <h4>Parties</h4>
      <table className="simple-table" aria-label="Account parties">
        <thead><tr><th scope="col">Party</th><th scope="col">Role</th><th scope="col">Since</th><th scope="col">Until</th></tr></thead>
        <tbody>{data.parties.map((party) => <tr key={`${party.partyId}${party.role}`}><td>{party.displayName}</td><td>{party.role}</td><td>{formatDate(party.startsAt)}</td><td>{formatDate(party.endsAt)}</td></tr>)}</tbody>
      </table>
      {data.holds.length === 0 ? null : <><h4>Holds</h4><table className="simple-table" aria-label="Holds"><thead><tr><th scope="col">Amount</th><th scope="col">Status</th><th scope="col">Reason</th><th scope="col">Placed</th></tr></thead>
        <tbody>{data.holds.map((hold) => <tr key={hold.id}><td><Money minorUnits={hold.amountMinorUnits} currency={account.currency} exponent={account.exponent} /></td><td>{hold.status}</td><td>{hold.reason}</td><td>{formatDate(hold.placedAt)}</td></tr>)}</tbody></table></>}
      {data.restrictions.length === 0 ? null : <><h4>Restrictions</h4><table className="simple-table" aria-label="Restrictions"><thead><tr><th scope="col">Kind</th><th scope="col">Status</th><th scope="col">Authority</th><th scope="col">Placed</th></tr></thead>
        <tbody>{data.restrictions.map((restriction) => <tr key={restriction.id}><td>{restriction.kind}</td><td>{restriction.status}</td><td>{restriction.authority}</td><td>{formatDate(restriction.placedAt)}</td></tr>)}</tbody></table></>}
      {data.cards.length === 0 ? null : <><h4>Cards</h4><ul>{data.cards.map((card) => <li key={card.id}>•••• {card.lastFour} · {card.status}</li>)}</ul></>}
    </div>
  );
  const closePanel = (
    <div className="panel-scroll">
      {eligibility.closure.eligible ? <Banner tone="info" title="Eligible for closure.">The balance is zero and nothing blocks closure.</Banner>
        : <Banner tone="warning" title="Closure blocked.">{eligibility.closure.reasons.join(' ')}</Banner>}
      <form className="form-grid" aria-label="Close account" onSubmit={(event) => { event.preventDefault(); void closeAccount(); }}>
        <TextAreaField label="Reason for closing" value={closeReason} onChange={setCloseReason} error={closeError} maxLength={500} rows={3} />
        <div className="form-actions"><button type="submit" className="danger" disabled={!eligibility.closure.eligible || submission.pending || !can(institutionId, 'account.close')}>Close account…</button></div>
      </form>
    </div>
  );
  return (
    <div className="record-window">
      <Toolbar label="Account actions">
        <button type="button" disabled={!can(institutionId, 'cash.deposit')} onClick={() => { open(institutionId, { kind: 'money', mode: 'deposit', accountId }, { reuse: false }); }}>Deposit…</button>
        <button type="button" disabled={!can(institutionId, 'cash.withdraw')} onClick={() => { open(institutionId, { kind: 'money', mode: 'withdraw', accountId }, { reuse: false }); }}>Withdrawal…</button>
        <button type="button" disabled={!can(institutionId, 'transfer.internal')} onClick={() => { open(institutionId, { kind: 'money', mode: 'transfer', accountId }, { reuse: false }); }}>Transfer…</button>
        <button type="button" disabled={!can(institutionId, 'account.hold.place')} onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'account.hold.place', prefill: { accountId, expectedVersion: account.version } }, { reuse: false }); }}>Place hold…</button>
        <button type="button" disabled={!can(institutionId, 'account.restriction.apply')} onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'account.restriction.apply', prefill: { accountId, expectedVersion: account.version } }, { reuse: false }); }}>Restrict…</button>
        <button type="button" disabled={!can(institutionId, 'fee.assess')} onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'fee.assess', prefill: { accountId, expectedVersion: account.version } }, { reuse: false }); }}>Assess fee…</button>
        <button type="button" onClick={() => { open(institutionId, { kind: 'statements', accountId, memberId: account.memberId }); }}>Statements…</button>
        <button type="button" disabled={!can(institutionId, 'case.open')} onClick={() => { open(institutionId, { kind: 'case-new', memberId: account.memberId, accountId }, { reuse: false }); }}>New case…</button>
        <span className="toolbar-separator" />
        <label className="toolbar-field">Switch to{' '}
          <select value={accountId} aria-label="Switch to another account of this member" onChange={(event) => { void switchTo(event.target.value); }}>
            {(siblings.data?.items ?? [account]).map((row) => <option key={row.id} value={row.id}>{row.accountNumber} · {row.productName}{row.status === 'open' ? '' : ` (${row.status})`}</option>)}
          </select>
        </label>
        <span className="toolbar-spacer" />
        <button type="button" onClick={() => { void save(); }} disabled={!editor.dirty || submission.pending}>Save</button>
        <button type="button" onClick={() => { reload(); siblings.reload(); }}>Refresh</button>
      </Toolbar>
      <div className="record-header">
        <div><span className="record-number">{account.accountNumber}</span> <StatusTag status={account.status} /> <span className="muted">{account.productName} · {account.currency}</span></div>
        <div>Owner <button type="button" className="link" onClick={() => { open(institutionId, { kind: 'member', memberId: account.memberId }); }}>{account.ownerName} ({account.memberNumber})</button></div>
        <div className="balances">
          <span>Posted <strong data-testid="posted-balance"><Money minorUnits={account.postedMinorUnits} currency={account.currency} exponent={account.exponent} /></strong></span>
          <span>Available <strong data-testid="available-balance"><Money minorUnits={account.availableMinorUnits} currency={account.currency} exponent={account.exponent} /></strong></span>
          <span className="muted">v{account.version} · as of {formatInstant(data.observedAt, win.institution.timeZone)}</span>
        </div>
      </div>
      {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
      <Tabs label="Account sections" selected={tab} onSelect={setTab} tabs={[
        { id: 'overview', label: 'Overview', content: () => overview },
        { id: 'transactions', label: 'Transactions', content: () => <TransactionsPanel account={account} /> },
        { id: 'statements', label: 'Statements', content: () => <StatementsPanel account={account} /> },
        { id: 'activity', label: 'Activity', content: () => <ActivityPanel scope={{ accountId }} label={`Activity for ${account.accountNumber}`} revision={stampKey ?? ''} /> },
        { id: 'close', label: 'Close', content: () => closePanel },
      ]} />
    </div>
  );
}
