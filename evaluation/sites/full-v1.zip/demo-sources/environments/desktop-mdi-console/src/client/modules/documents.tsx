import { useRef, useState, type ReactNode } from 'react';

import type { DocumentListRow, PageResult } from '@computer-use/financial-database/services';

import { getJson, institutionPath, queryString } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands, type DesktopApi } from '../desktop/context';
import { item, separator, type MenuEntry } from '../desktop/Menu';
import { formatDate, formatInstant } from '../format';
import { Grid, nextSort, type Column, type SortState } from '../widgets/Grid';
import { useResource } from '../widgets/useResource';

export function documentHref(institutionId: string, versionId: string): string {
  return institutionPath(institutionId, `/documents/${versionId}/content`);
}

/** Starts the browser download of a stored document version, as the Download link does. */
function download(href: string): void {
  const link = document.createElement('a');
  link.href = href;
  link.download = '';
  link.click();
}

function documentActions(desktop: DesktopApi, institutionId: string, row: DocumentListRow): MenuEntry[] {
  return [
    item(`Member ${row.memberNumber}`, () => { desktop.open(institutionId, { kind: 'member', memberId: row.memberId }); }),
    item(row.accountNumber === null ? 'No account' : `Account ${row.accountNumber}`, () => { if (row.accountId !== null) desktop.open(institutionId, { kind: 'account', accountId: row.accountId }); }, { disabled: row.accountId === null }),
    separator,
    item(`Download ${row.displayName} v${String(row.version)}`, () => { download(documentHref(institutionId, row.versionId)); }),
  ];
}

/** Stored statements and servicing documents of the institution, each leading to its owning member and account. */
export function DocumentsWindow(): ReactNode {
  const desktop = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const timeZone = win.institution.timeZone;
  const [text, setText] = useState('');
  const [applied, setApplied] = useState({ query: '', documentType: '' });
  const [sort, setSort] = useState<SortState>({ key: 'issued', direction: 'desc' });
  const [page, setPage] = useState({ offset: 0, limit: 50 });
  const [selected, setSelected] = useState<string | null>(null);
  const search = useRef<HTMLInputElement>(null);
  const types = useResource(() => getJson<string[]>(institutionPath(institutionId, '/document-types')), institutionId);
  const params = { ...applied, sort: sort.key, direction: sort.direction, ...page };
  const result = useResource(() => getJson<PageResult<DocumentListRow>>(institutionPath(institutionId, `/documents${queryString(params)}`)), JSON.stringify(params));
  useWindowChrome(applied.query === '' ? 'Documents' : `Documents · “${applied.query}”`, {}, false);
  useWindowCommands({ refresh: result.reload, focusSearch: () => { search.current?.focus(); } });
  const filter = (change: Partial<typeof applied>): void => { setApplied((current) => ({ ...current, ...change })); setPage((current) => ({ ...current, offset: 0 })); };
  const chosen = result.data?.items.find((row) => row.versionId === selected);
  const columns: Column<DocumentListRow>[] = [
    { key: 'issued', label: 'Issued', width: 150, sortKey: 'issued', render: (row) => formatInstant(row.issuedAt, timeZone) },
    { key: 'type', label: 'Type', width: 150, sortKey: 'type', render: (row) => row.documentType },
    { key: 'name', label: 'Document', width: 190, sortKey: 'name', render: (row) => `${row.displayName} · v${String(row.version)}` },
    { key: 'member', label: 'Member', width: 190, sortKey: 'member', render: (row) => `${row.memberNumber} · ${row.ownerName}` },
    { key: 'account', label: 'Account', width: 104, sortKey: 'account', render: (row) => row.accountNumber ?? '—' },
    { key: 'period', label: 'Period', width: 190, render: (row) => row.periodStart === null ? '' : `${formatDate(row.periodStart)} – ${formatDate(row.periodEnd)}` },
    { key: 'size', label: 'Size', width: 70, align: 'right', render: (row) => `${String(Math.ceil(row.byteLength / 1024))} KB` },
    { key: 'digest', label: 'SHA-256', width: 120, render: (row) => <code title={row.digest}>{row.digest.slice(0, 12)}…</code> },
  ];
  return (
    <div className="grid-window">
      <form className="toolbar" role="search" aria-label="Document search" onSubmit={(event) => { event.preventDefault(); filter({ query: text.trim() }); }}>
        <input ref={search} type="search" aria-label="Search documents" placeholder="Member #, account #, owner or file name" value={text} onChange={(event) => { setText(event.target.value); }} data-autofocus />
        <button type="submit">Search</button>
        <label>Type <select value={applied.documentType} onChange={(event) => { filter({ documentType: event.target.value }); }}>
          <option value="">Any</option>{(types.data ?? []).map((type) => <option key={type} value={type}>{type}</option>)}
        </select></label>
        <span className="toolbar-spacer" />
        {chosen === undefined ? <span className="muted">Select a document to download it</span>
          : <a className="button" href={documentHref(institutionId, chosen.versionId)} download>Download selected</a>}
        <button type="button" onClick={result.reload}>Refresh</button>
      </form>
      <Grid
        label="Documents" columns={columns} rows={result.data?.items ?? []} rowKey={(row) => row.versionId} total={result.data?.total ?? 0} offset={page.offset} limit={page.limit}
        onPage={(offset) => { setPage((current) => ({ ...current, offset })); }} onLimit={(limit) => { setPage({ offset: 0, limit }); }}
        sort={sort} onSort={(key) => { setSort((current) => nextSort(current, key)); setPage((current) => ({ ...current, offset: 0 })); }}
        selectedKey={selected} onSelect={setSelected}
        onOpen={(row, newWindow) => {
          if (row.accountId !== null) desktop.open(institutionId, { kind: 'account', accountId: row.accountId }, { reuse: !newWindow });
          else desktop.open(institutionId, { kind: 'member', memberId: row.memberId }, { reuse: !newWindow });
        }}
        contextMenu={(row) => documentActions(desktop, institutionId, row)} loading={result.loading} error={result.error} onRetry={result.reload}
        empty={applied.query === '' ? 'No documents match these filters.' : `No documents match “${applied.query}”.`}
      />
    </div>
  );
}
