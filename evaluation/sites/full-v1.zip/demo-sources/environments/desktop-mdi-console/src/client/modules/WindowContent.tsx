import type { ReactNode } from 'react';

import type { WindowSpec } from '../desktop/state';
import { AccountSearchWindow, AccountWindow } from './accounts';
import { ActivityWindow } from './activity';
import { ApprovalsWindow } from './approvals';
import { CaseRegisterWindow, CaseWindow, NewCaseWindow } from './cases';
import { BatchesWindow, ReconciliationWindow, StatementsWindow } from './domains';
import { DocumentsWindow } from './documents';
import { FinanceRecordsWindow, FinanceRecordWindow } from './finance';
import { MemberSearchWindow, MemberWindow, NewMemberWindow, OpenAccountWindow } from './members';
import { MoneyWindow, ReceiptWindow } from './money';
import { OperationsCatalogWindow, OperationWindow } from './operations';
import { IdentityResolveWindow, MemberServicingWindow } from './servicing';

/** Maps a window spec to its module; keys reset per-record state when a window switches records. */
export function WindowContent({ spec }: { spec: WindowSpec }): ReactNode {
  switch (spec.kind) {
    case 'member-search': return <MemberSearchWindow />;
    case 'member': return <MemberWindow key={spec.memberId} memberId={spec.memberId} />;
    case 'member-new': return <NewMemberWindow />;
    case 'account-search': return <AccountSearchWindow />;
    case 'account': return <AccountWindow key={spec.accountId} accountId={spec.accountId} />;
    case 'account-open': return <OpenAccountWindow memberId={spec.memberId} />;
    case 'money': return <MoneyWindow mode={spec.mode} accountId={spec.accountId} />;
    case 'receipt': return <ReceiptWindow key={spec.receiptNumber} receiptNumber={spec.receiptNumber} />;
    case 'case-register': return <CaseRegisterWindow />;
    case 'case': return <CaseWindow key={spec.caseId} caseId={spec.caseId} />;
    case 'case-new': return <NewCaseWindow memberId={spec.memberId} accountId={spec.accountId} />;
    case 'activity': return <ActivityWindow memberId={spec.memberId} accountId={spec.accountId} caseId={spec.caseId} label={spec.label} />;
    case 'documents': return <DocumentsWindow />;
    case 'operations': return <OperationsCatalogWindow />;
    case 'operation': return <OperationWindow key={spec.commandKind} commandKind={spec.commandKind} prefill={spec.prefill} />;
    case 'finance-records': return <FinanceRecordsWindow resource={spec.resource} scope={spec.scope} label={spec.label} />;
    case 'finance-record': return <FinanceRecordWindow key={spec.recordId} resource={spec.resource} recordId={spec.recordId} />;
    case 'approvals': return <ApprovalsWindow />;
    case 'member-servicing': return <MemberServicingWindow key={spec.memberId} memberId={spec.memberId} />;
    case 'identity-resolve': return <IdentityResolveWindow />;
    case 'reconciliation': return <ReconciliationWindow />;
    case 'batches': return <BatchesWindow />;
    case 'statements': return <StatementsWindow key={spec.accountId} accountId={spec.accountId} memberId={spec.memberId} />;
  }
}
