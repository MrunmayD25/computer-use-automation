import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

import type {
  AccountDetail, AccountRow, CaseDetail, CaseRow, FinanceListRow, MemberDetail, MemberRow, MergeInventory,
  OperationReview, PageResult, Rejection, ServiceCommand,
} from '@computer-use/financial-database/services';

import { ApiError, executeCommand, financeQuery, getJson, institutionPath, newIdempotencyKey, queryString, reviewCommand } from '../api';
import { useBusyWhile, useDesktop, useWindow, useWindowChrome, useWindowCommands } from '../desktop/context';
import { Dialog } from '../desktop/Dialog';
import { stampWatcher } from '../desktop/stamps';
import { describeValue, formatMoney, parseAmount } from '../format';
import { Banner, DetailList, SelectField, TextAreaField, TextField, Toolbar } from '../widgets/fields';
import { COMMAND_LABELS, exponentOf, OutcomeBanner, rejectionTitle, useReference, type Committed, type SubmitOutcome } from './common';
import type { DraftValues, FieldSpec, OperationSpec } from '../operations/registry';
import { OPERATION_GROUPS, OPERATIONS, operationSpec } from '../operations/registry';
import { FINANCE_RESOURCES } from './finance';

/* ---------- picked records ---------- */

interface PickOption { id: string; label: string; detail?: string; payload: Record<string, unknown> }
/** `payload` holds source attributes used by binds/copy/fill; `extra` holds command fields directly. */
interface PickResult { payload: Record<string, unknown>; extra?: Record<string, unknown>; memberCtx?: string }
type Needs = 'needs-member' | 'needs-scope';
type PickerLoad = (institutionId: string, values: DraftValues, memberCtx: string | null, query: string) => Promise<PickOption[] | Needs>;
type PickerResolve = (institutionId: string, option: PickOption) => Promise<PickResult>;

const snake = (key: string): string => key.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`);
const payloadValue = (payload: Record<string, unknown>, key: string): unknown => payload[key] ?? payload[snake(key)];

function bindsFromPayload(spec: FieldSpec, payload: Record<string, unknown>): Record<string, unknown> {
  const fields: Record<string, unknown> = {};
  for (const [source, target] of Object.entries(spec.binds ?? {})) fields[target] = payloadValue(payload, source);
  for (const [source, target] of Object.entries(spec.copy ?? {})) fields[target] = payloadValue(payload, source);
  if (spec.fill !== undefined) Object.assign(fields, spec.fill(payload));
  return fields;
}

function memberScopedList(path: (memberId: string) => string, map: (row: Record<string, unknown>) => PickOption): PickerLoad {
  return async (institutionId, _values, memberCtx, _query) => {
    const memberId = memberCtx;
    if (memberId === null || memberId === '') return 'needs-member';
    const rows = await getJson<Record<string, unknown>[]>(institutionPath(institutionId, path(memberId)));
    return rows.map(map);
  };
}

const summaryText = (summary: Record<string, unknown>): string => Object.entries(summary).filter(([key]) => !key.endsWith('Id') && !key.endsWith('_id')).map(([, value]) => describeValue(value)).filter((v) => v !== '').join(' · ');

const PICKERS: Record<string, { load: PickerLoad; resolve: PickerResolve }> = {
  member: {
    load: async (institutionId, _values, _memberCtx, query) => {
      const page = await getJson<PageResult<MemberRow>>(institutionPath(institutionId, `/members${queryString({ query, limit: 20 })}`));
      return page.items.map((row) => ({ id: row.id, label: `${row.memberNumber} · ${row.displayName}`, detail: row.status, payload: { ...row } }));
    },
    resolve: async (institutionId, option) => {
      const detail = await getJson<MemberDetail>(institutionPath(institutionId, `/members/${encodeURIComponent(option.id)}`));
      return { payload: { id: detail.member.id, version: detail.member.version, partyId: detail.member.partyId }, memberCtx: detail.member.id };
    },
  },
  account: {
    load: async (institutionId, _values, memberCtx, query) => {
      const page = await getJson<PageResult<AccountRow>>(institutionPath(institutionId, `/accounts${queryString({ query, memberId: memberCtx ?? undefined, limit: 20 })}`));
      return page.items.map((row) => ({ id: row.id, label: `${row.accountNumber} · ${row.ownerName}`, detail: `${row.status} · ${row.currency}`, payload: { ...row } }));
    },
    resolve: async (institutionId, option) => {
      const detail = await getJson<AccountDetail>(institutionPath(institutionId, `/accounts/${encodeURIComponent(option.id)}`));
      return { payload: { id: detail.account.id, version: detail.account.version, memberId: detail.account.memberId, currency: detail.account.currency }, memberCtx: detail.account.memberId };
    },
  },
  case: {
    load: async (institutionId, _values, memberCtx, query) => {
      const page = await getJson<PageResult<CaseRow>>(institutionPath(institutionId, `/cases${queryString({ query, memberId: memberCtx ?? undefined, limit: 20 })}`));
      return page.items.map((row) => ({ id: row.id, label: `${row.caseNumber} · ${row.summary}`, detail: row.state, payload: { ...row } }));
    },
    resolve: async (institutionId, option) => {
      const detail = await getJson<CaseDetail>(institutionPath(institutionId, `/cases/${encodeURIComponent(option.id)}`));
      return { payload: { id: detail.case.id, version: detail.case.version, memberId: detail.case.memberId }, memberCtx: detail.case.memberId };
    },
  },
  queue: {
    load: async (institutionId) => {
      const rows = await getJson<{ id: string; name: string; purpose: string }[]>(institutionPath(institutionId, '/servicing/queues'));
      return rows.map((row) => ({ id: row.id, label: row.name, detail: row.purpose, payload: { ...row } }));
    },
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  policy: {
    load: async (institutionId) => {
      const rows = await getJson<{ id: string; name: string; version: string; effectiveAt: string }[]>(institutionPath(institutionId, '/servicing/policies'));
      return rows.map((row) => ({ id: row.id, label: `${row.name} ${row.version}`, detail: `effective ${row.effectiveAt}`, payload: { ...row } }));
    },
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  approval: {
    load: async (institutionId, values, _memberCtx, _query) => {
      const result = await getJson<{ kind: string; approvals: { id: string; status: string; target: unknown; expiresAt: string }[] }>(institutionPath(institutionId, '/approvals'));
      const wanted = (values.__commandKind as string) === 'approval.decide' ? 'pending' : 'approved';
      return result.approvals.filter((item) => item.status === wanted).map((item) => ({
        id: item.id, label: `${item.id} · ${(item.target as { kind?: string }).kind ?? 'approval'}`, detail: `expires ${item.expiresAt}`, payload: { ...item },
      }));
    },
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id, fingerprint: describeValue(option.payload.fingerprint) } }),
  },
  checker: {
    load: async (institutionId, values) => {
      const target = values.target as { kind?: string } | undefined;
      const kind = target?.kind ?? '';
      if (kind === '') return 'needs-scope';
      const rows = await getJson<{ id: string; actorNumber: string; displayName: string }[]>(institutionPath(institutionId, `/servicing/checkers/${encodeURIComponent(kind)}`));
      return rows.map((row) => ({ id: row.id, label: `${row.displayName} (${row.actorNumber})`, payload: { ...row } }));
    },
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  evidence: {
    load: memberScopedList((memberId) => `/servicing/identity-evidence/${encodeURIComponent(memberId)}`, (row) => ({
      id: String(row.id), label: `${describeValue(row.kind)} · ${describeValue(row.sourceReference)}`, detail: `${describeValue(row.status)} · issued ${describeValue(row.issuedAt)}`, payload: row,
    })),
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  consent: {
    load: memberScopedList((memberId) => `/servicing/consents/${encodeURIComponent(memberId)}`, (row) => ({
      id: String(row.id), label: `${describeValue(row.purpose)} · ${describeValue(row.channel)}`, detail: `${describeValue(row.state)} · ${describeValue(row.effectiveAt)}`, payload: row,
    })),
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  'doc-version': {
    load: memberScopedList((memberId) => `/servicing/documents/${encodeURIComponent(memberId)}`, (row) => ({
      id: String(row.versionId), label: `${describeValue(row.displayName)} v${describeValue(row.version)}`, detail: `${describeValue(row.documentType)} · ${describeValue(row.mediaType)} · ${describeValue(row.digest)}`, payload: row,
    })),
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  'address-dest': {
    load: memberScopedList((memberId) => `/servicing/destinations/${encodeURIComponent(memberId)}`, (row) => ({
      id: String(row.id), label: `${describeValue(row.context)} · ${(row.address as { line1?: string }).line1 ?? describeValue(row.partyAddressId)}`, detail: `effective ${describeValue(row.effectiveAt)}`, payload: row,
    })),
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  'maint-request': {
    load: memberScopedList((memberId) => `/servicing/maintenance-requests/${encodeURIComponent(memberId)}`, (row) => ({
      id: String(row.id), label: `${describeValue(row.requestNumber)} · ${describeValue(row.subject)}`, detail: `${describeValue(row.state)} · updated ${describeValue(row.updatedAt)}`, payload: row,
    })),
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id, updatedAt: option.payload.updatedAt } }),
  },
  'comm-job': {
    load: memberScopedList((memberId) => `/servicing/communication-jobs/${encodeURIComponent(memberId)}`, (row) => ({
      id: String(row.id), label: `${describeValue(row.purpose)} · ${describeValue(row.channel)} → ${describeValue(row.destination)}`, detail: describeValue(row.state), payload: row,
    })),
    resolve: (_i, option) => Promise.resolve({ payload: { id: option.id } }),
  },
  finance: {
    load: () => Promise.resolve('needs-scope' as Needs),
    resolve: async (institutionId, option) => {
      const resource = option.payload.__resource as string;
      const result = await financeQuery(institutionId, { kind: 'finance.record', resource: resource as never, id: option.id });
      if (result.kind !== 'found') return { payload: { id: option.id } };
      const snapshot = result.snapshot;
      return { payload: { ...snapshot.record, fingerprint: snapshot.fingerprint } };
    },
  },
  'merge-plan': {
    load: async (institutionId) => {
      const result = await financeQuery(institutionId, { kind: 'finance.records', resource: 'merge-plan', scope: {}, limit: 50 });
      if (result.kind !== 'listed') return [];
      return result.items.map((item) => ({ id: item.id, label: `${item.fields.sourceNumber} → ${item.fields.targetNumber}`, detail: `plan ${item.fields.state}`, payload: item.fields }));
    },
    resolve: async (institutionId, option) => {
      const inventory = await getJson<MergeInventory | Rejection>(institutionPath(institutionId, `/merge-plans/${encodeURIComponent(option.id)}`));
      if (inventory.kind !== 'found') return { payload: {}, extra: { mergePlanId: option.id } };
      const accountsTable = inventory.tables.find((table) => table.table === 'accounts');
      const accountIds = accountsTable === undefined ? [] : accountsTable.records.map((record) => String(record.key.id));
      const [source, target] = await Promise.all([
        getJson<MemberDetail>(institutionPath(institutionId, `/members/${encodeURIComponent(inventory.sourceMemberId)}`)),
        getJson<MemberDetail>(institutionPath(institutionId, `/members/${encodeURIComponent(inventory.targetMemberId)}`)),
      ]);
      return {
        payload: {},
        memberCtx: inventory.targetMemberId,
        extra: {
          mergePlanId: inventory.mergePlanId, sourceMemberId: inventory.sourceMemberId, targetMemberId: inventory.targetMemberId,
          expectedSourceVersion: source.member.version, expectedTargetVersion: target.member.version,
          relationshipAccountIds: accountIds, expectedInventoryFingerprint: inventory.fingerprint,
        },
      };
    },
  },
};

/** Draft keys that supply a list scope without becoming command fields. */
const SCOPE_CONTEXT: Readonly<Record<string, string>> = {
  accountId: '__scopeAccount', memberId: '__scopeMember', scheduleId: '__scopeSchedule', paymentId: '__scopePayment',
  beneficiaryId: '__scopeBeneficiary', disputeId: '__scopeDispute', loanId: '__scopeLoan', batchId: '__scopeBatch',
  caseId: '__scopeCase', cardId: '__scopeCard', settlementBatchId: '__scopeSettlement', businessDate: '__scopeDate',
};

/** Finance list for one field; scope comes from the field spec, scope-context picks, then the member context. */
async function loadFinanceOptions(institutionId: string, spec: FieldSpec, values: DraftValues, memberCtx: string | null): Promise<PickOption[] | Needs> {
  const resource = spec.resource;
  if (resource === undefined) return 'needs-scope';
  const scope: Record<string, string> = {};
  if (spec.scopeKey !== undefined) {
    const scoped = spec.scopeFrom !== undefined ? values[spec.scopeFrom] : undefined;
    if (typeof scoped === 'string' && scoped !== '') scope[spec.scopeKey] = scoped;
  }
  if (Object.keys(scope).length === 0) {
    for (const key of FINANCE_RESOURCES.find((entry) => entry.kind === resource)?.scopes ?? []) {
      const supplied = values[SCOPE_CONTEXT[key] ?? ''] ?? values[key];
      if (typeof supplied === 'string' && supplied !== '') { scope[key] = supplied; break; }
      if (key === 'memberId' && memberCtx !== null) { scope.memberId = memberCtx; break; }
    }
  }
  if (Object.keys(scope).length === 0 && (FINANCE_RESOURCES.find((entry) => entry.kind === resource)?.scopes.length ?? 0) > 0) return 'needs-scope';
  const result = await financeQuery(institutionId, { kind: 'finance.records', resource, scope, limit: 50 });
  if (result.kind !== 'listed') return [];
  return result.items.map((item: FinanceListRow) => ({ id: item.id, label: summaryText(item.fields), detail: item.id, payload: { ...item.fields, __resource: resource } }));
}

function pickerSource(spec: FieldSpec): { load: PickerLoad; resolve: PickerResolve } {
  if (spec.kind === 'finance') {
    return {
      load: (institutionId, values, memberCtx, query) => loadFinanceOptions(institutionId, spec, values, memberCtx).then((options) => options === 'needs-scope' || options === 'needs-member' ? options : options.filter((option) => query === '' || option.label.toLowerCase().includes(query.toLowerCase()) || option.id.toLowerCase().includes(query.toLowerCase()))),
      resolve: (PICKERS.finance as { resolve: PickerResolve }).resolve,
    };
  }
  const base = PICKERS[spec.kind] as { load: PickerLoad; resolve: PickerResolve };
  return {
    load: async (institutionId, values, memberCtx, query) => {
      const member = spec.memberFrom !== undefined && typeof values[spec.memberFrom] === 'string' && values[spec.memberFrom] !== '' ? values[spec.memberFrom] as string : memberCtx;
      const result = await base.load(institutionId, values, member, query);
      return result === 'needs-member' || result === 'needs-scope' ? result : result.filter((option) => query === '' || option.label.toLowerCase().includes(query.toLowerCase()) || option.id.toLowerCase().includes(query.toLowerCase()));
    },
    resolve: async (institutionId, option) => {
      const resolved = await base.resolve(institutionId, option);
      return { ...resolved, payload: { ...option.payload, ...resolved.payload } };
    },
  };
}

/* ---------- picker widget ---------- */

interface DraftApi {
  values: DraftValues;
  setValues: (patch: DraftValues) => void;
  setField: (name: string, value: unknown) => void;
  memberCtx: string | null;
  setMemberCtx: (memberId: string | null) => void;
  picks: Record<string, PickOption | null>;
  setPick: (name: string, option: PickOption | null) => void;
  institutionId: string;
}

function PickerField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const [query, setQuery] = useState('');
  const [options, setOptions] = useState<PickOption[] | null>(null);
  const [needs, setNeeds] = useState<Needs | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const source = useMemo(() => pickerSource(spec), [spec]);
  const selected = draft.picks[spec.name] ?? null;
  const memberMissing = needs === 'needs-member';

  const load = useCallback(async (search: string): Promise<void> => {
    setLoading(true);
    setLoadError(null);
    try {
      const result = await source.load(draft.institutionId, draft.values, draft.memberCtx, search);
      if (result === 'needs-member' || result === 'needs-scope') { setNeeds(result); setOptions(null); }
      else { setNeeds(null); setOptions(result); }
    } catch (failure) {
      setLoadError(failure instanceof ApiError ? failure.message : 'The list could not be loaded.');
    } finally { setLoading(false); }
  }, [source, draft]);

  /* When the scoping pick lands after this picker was already asked, retry automatically. */
  const scopeDeps = [spec.scopeFrom === undefined ? undefined : draft.values[spec.scopeFrom], draft.memberCtx, ...Object.values(SCOPE_CONTEXT).map((key) => draft.values[key])];
  useEffect(() => { if (needs !== null && !loading) void load(query); }, scopeDeps);

  const pick = async (option: PickOption): Promise<void> => {
    setLoading(true);
    try {
      const resolved = await source.resolve(draft.institutionId, option);
      const patch: DraftValues = { [spec.name]: option.id, ...bindsFromPayload(spec, resolved.payload), ...(resolved.extra ?? {}) };
      draft.setValues(patch);
      draft.setPick(spec.name, { ...option, payload: { ...option.payload, ...resolved.payload } });
      if (resolved.memberCtx !== undefined) draft.setMemberCtx(resolved.memberCtx);
      setOpen(false);
    } catch (failure) {
      setLoadError(failure instanceof ApiError ? failure.message : 'The record could not be read.');
    } finally { setLoading(false); }
  };

  const clear = (): void => {
    const patch: DraftValues = { [spec.name]: spec.nullable ? null : undefined };
    for (const target of Object.values(spec.binds ?? {})) patch[target] = spec.nullable ? null : undefined;
    for (const target of Object.values(spec.copy ?? {})) patch[target] = spec.nullable ? null : undefined;
    if (spec.fill !== undefined) for (const key of Object.keys(spec.fill({}))) patch[key] = spec.nullable ? null : undefined;
    draft.setValues(patch);
    draft.setPick(spec.name, null);
  };

  return (
    <div className={`field field-wide${error === undefined ? '' : ' field-invalid'}`}>
      <label>{spec.label}{spec.optional || spec.nullable ? '' : ' *'}</label>
      <div className="picker">
        {selected === null ? null : (
          <span className="picker-current" data-testid={`pick-${spec.name}`}>
            <strong>{selected.label}</strong>{selected.detail === undefined ? '' : ` · ${selected.detail}`}
            <button type="button" onClick={clear}>Clear</button>
          </span>
        )}
        {selected !== null && spec.nullable !== true ? null : (
          <span className="picker-search">
            <input type="search" value={query} placeholder={`Find ${spec.label.toLowerCase()}…`} aria-label={`Find ${spec.label}`}
              onFocus={() => { setOpen(true); if (options === null && needs === null) void load(''); }}
              onChange={(event) => { setQuery(event.target.value); setOpen(true); void load(event.target.value); }} />
            {spec.nullable === true ? <button type="button" onClick={clear} disabled={selected === null}>None</button> : null}
          </span>
        )}
        {spec.nullable === true && selected === null && draft.values[spec.name] === null ? <span className="hint" data-testid={`pick-none-${spec.name}`}>None selected — the command sends an explicit empty value.</span> : null}
      </div>
      {open && needs === null && options !== null ? (
        <ul className="picker-results" role="listbox" aria-label={`${spec.label} options`}>
          {options.length === 0 ? <li className="picker-empty">No matching records.</li> : options.map((option) => (
            <li key={option.id}><button type="button" onClick={() => { void pick(option); }}>{option.label}{option.detail === undefined ? '' : ` — ${option.detail}`}</button></li>
          ))}
        </ul>
      ) : null}
      {memberMissing ? <MemberScopeNote draft={draft} /> : needs === 'needs-scope' ? <span className="field-hint">Pick {spec.scopeFrom ?? 'the scoping record'} first.</span> : null}
      {loading ? <span className="field-hint">Loading…</span> : null}
      {loadError === null ? null : <span className="field-error" role="alert">{loadError}</span>}
      {error === undefined ? (spec.help === undefined ? null : <span className="field-hint">{spec.help}</span>) : <span className="field-error" role="alert">{error}</span>}
    </div>
  );
}

/** Inline member search used when a member-scoped picker has no member context yet. */
function MemberScopeNote({ draft }: { draft: DraftApi }): ReactNode {
  const [query, setQuery] = useState('');
  const [options, setOptions] = useState<PickOption[] | null>(null);
  const find = async (text: string): Promise<void> => {
    setQuery(text);
    const page = await getJson<PageResult<MemberRow>>(institutionPath(draft.institutionId, `/members${queryString({ query: text, limit: 10 })}`));
    setOptions(page.items.map((row) => ({ id: row.id, label: `${row.memberNumber} · ${row.displayName}`, payload: { ...row } })));
  };
  return (
    <span className="picker-member-scope">
      <span className="field-hint">Choose the member whose records to list:</span>
      <input type="search" value={query} placeholder="Member search…" aria-label="Scope member" onChange={(event) => { void find(event.target.value); }} />
      {options === null ? null : (
        <ul className="picker-results">
          {options.map((option) => <li key={option.id}><button type="button" onClick={() => { draft.setMemberCtx(option.id); setOptions(null); }}>{option.label}</button></li>)}
        </ul>
      )}
    </span>
  );
}

/* ---------- scalar + compound field widgets ---------- */

function AddressField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const value = (draft.values[spec.name] ?? null) as { line1: string; line2: string; city: string; region: string; postalCode: string; country: string } | null;
  const current = value ?? { line1: '', line2: '', city: '', region: '', postalCode: '', country: '' };
  const setPart = (key: string, part: string): void => {
    draft.setField(spec.name, { ...current, [key]: part });
  };
  return (
    <fieldset className="field field-wide">
      <legend>{spec.label}{spec.optional ? '' : ' *'}</legend>
      {spec.optional && value === null ? <button type="button" onClick={() => { draft.setField(spec.name, current); }}>Add address</button> : (
        <div className="address-grid">
          <TextField label="Line 1" value={current.line1} onChange={(v) => { setPart('line1', v); }} required />
          <TextField label="Line 2" value={current.line2} onChange={(v) => { setPart('line2', v); }} />
          <TextField label="City" value={current.city} onChange={(v) => { setPart('city', v); }} required />
          <TextField label="Region" value={current.region} onChange={(v) => { setPart('region', v); }} required />
          <TextField label="Postal code" value={current.postalCode} onChange={(v) => { setPart('postalCode', v); }} required />
          <TextField label="Country" value={current.country} onChange={(v) => { setPart('country', v); }} required />
          {spec.optional ? <button type="button" onClick={() => { draft.setField(spec.name, undefined); }}>Remove address</button> : null}
        </div>
      )}
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </fieldset>
  );
}

function OwnersField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const rows = (draft.values[spec.name] ?? []) as { memberId: string; ownershipBps: string; isControlPerson: boolean; evidenceId: string }[];
  const setRows = (next: typeof rows): void => { draft.setField(spec.name, next); };
  return (
    <fieldset className="field field-wide">
      <legend>{spec.label} *</legend>
      {rows.map((row, index) => (
        <div className="owner-row" key={index}>
          <TextField label="Member id" value={row.memberId} onChange={(v) => { setRows(rows.map((r, i) => i === index ? { ...r, memberId: v } : r)); }} />
          <TextField label="Ownership (bps)" value={row.ownershipBps} inputMode="decimal" onChange={(v) => { setRows(rows.map((r, i) => i === index ? { ...r, ownershipBps: v } : r)); }} />
          <label className="check"><input type="checkbox" checked={row.isControlPerson} onChange={(e) => { setRows(rows.map((r, i) => i === index ? { ...r, isControlPerson: e.target.checked } : r)); }} /> Control person</label>
          <TextField label="Evidence id" value={row.evidenceId} onChange={(v) => { setRows(rows.map((r, i) => i === index ? { ...r, evidenceId: v } : r)); }} />
          <button type="button" onClick={() => { setRows(rows.filter((_, i) => i !== index)); }}>Remove</button>
        </div>
      ))}
      <button type="button" onClick={() => { setRows([...rows, { memberId: '', ownershipBps: '', isControlPerson: false, evidenceId: '' }]); }}>Add owner</button>
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </fieldset>
  );
}

function ExcerptsField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const rows = (draft.values[spec.name] ?? []) as { sourceVersionId: string; text: string }[];
  const sourceIds = (draft.values.sourceVersionIds ?? []) as string[];
  const setRows = (next: typeof rows): void => { draft.setField(spec.name, next); };
  return (
    <fieldset className="field field-wide">
      <legend>{spec.label} *</legend>
      <p className="hint">Each excerpt must quote the exact text retained from one of the listed source versions.</p>
      {rows.map((row, index) => (
        <div className="excerpt-row" key={index}>
          <SelectField label="Source version" value={row.sourceVersionId} onChange={(v) => { setRows(rows.map((r, i) => i === index ? { ...r, sourceVersionId: v } : r)); }}
            options={[{ value: '', label: 'Choose source' }, ...sourceIds.map((id) => ({ value: id, label: id }))]} />
          <TextAreaField label="Excerpt text" value={row.text} onChange={(v) => { setRows(rows.map((r, i) => i === index ? { ...r, text: v } : r)); }} rows={2} />
          <button type="button" onClick={() => { setRows(rows.filter((_, i) => i !== index)); }}>Remove</button>
        </div>
      ))}
      <button type="button" onClick={() => { setRows([...rows, { sourceVersionId: '', text: '' }]); }}>Add excerpt</button>
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </fieldset>
  );
}

function RegionField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const value = (draft.values[spec.name] ?? { x: '', y: '', width: '', height: '' }) as Record<string, string>;
  const setPart = (key: string, part: string): void => { draft.setField(spec.name, { ...value, [key]: part }); };
  return (
    <fieldset className="field">
      <legend>{spec.label}</legend>
      <div className="region-grid">
        {(['x', 'y', 'width', 'height'] as const).map((key) => (
          <TextField key={key} label={key} value={value[key] ?? ''} inputMode="decimal" onChange={(v) => { setPart(key, v); }} />
        ))}
      </div>
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </fieldset>
  );
}

function FileField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const value = draft.values[spec.name];
  const chosen = typeof value === 'string' && value !== '';
  const fileName = draft.values[`__${spec.name}Name`];
  return (
    <div className={`field field-wide${error === undefined ? '' : ' field-invalid'}`}>
      <label>{spec.label} *</label>
      <input type="file" accept="application/pdf,image/png,image/jpeg" onChange={(event) => {
        const file = event.target.files?.[0];
        if (file === undefined) return;
        const reader = new FileReader();
        reader.onload = () => {
          const data = typeof reader.result === 'string' ? reader.result : '';
          draft.setValues({ [spec.name]: data.slice(data.indexOf(',') + 1), [`__${spec.name}Name`]: file.name, mediaType: file.type === '' ? undefined : file.type });
        };
        reader.readAsDataURL(file);
      }} />
      {chosen ? <span className="field-hint" data-testid={`file-chosen-${spec.name}`}>{describeValue(fileName) || 'file'} ready — {Math.floor(value.length * 3 / 4)} bytes.</span> : null}
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </div>
  );
}

/** Field sets for the maintenance-requested core commands. */
const MAINT_COMMAND_SPECS: Readonly<Record<string, readonly FieldSpec[]>> = {
  'contact.update': [
    { name: 'memberId', label: 'Member', kind: 'member', binds: { version: 'expectedVersion' } },
    { name: 'email', label: 'Email', kind: 'nullable', optional: true }, { name: 'phone', label: 'Phone', kind: 'nullable', optional: true },
    { name: 'address', label: 'Address', kind: 'address', optional: true },
  ],
  'member.note.add': [
    { name: 'memberId', label: 'Member', kind: 'member' },
    { name: 'visibility', label: 'Visibility', kind: 'select', options: ['general', 'restricted'] }, { name: 'text', label: 'Note', kind: 'textarea' },
  ],
  'account.nickname.update': [
    { name: 'accountId', label: 'Account', kind: 'account', binds: { version: 'expectedVersion' } }, { name: 'nickname', label: 'Nickname', kind: 'text' },
  ],
  'account.statement_delivery.update': [
    { name: 'accountId', label: 'Account', kind: 'account', binds: { version: 'expectedVersion' } },
    { name: 'statementDelivery', label: 'Delivery', kind: 'select', options: ['paper', 'electronic'] },
  ],
  'account.close': [
    { name: 'accountId', label: 'Account', kind: 'account', binds: { version: 'expectedVersion' } }, { name: 'reason', label: 'Reason', kind: 'text' },
  ],
};

/** Embedded field set producing a nested command object (maintenance requests, approval targets). */
function SubCommandFields({ kinds, value, onChange, draft }: { kinds: readonly string[]; value: DraftValues | null; onChange: (command: DraftValues | null) => void; draft: DraftApi }): ReactNode {
  const [kind, setKind] = useState<string>(typeof value?.kind === 'string' ? value.kind : '');
  const sub = useSubDraft(value, onChange, kind, draft);
  const specs: Record<string, readonly FieldSpec[]> = Object.fromEntries(kinds.map((k) => {
    const found = operationSpec(k);
    return [k, found?.fields ?? MAINT_COMMAND_SPECS[k] ?? []];
  }));
  return (
    <div className="sub-command">
      <SelectField label="Change kind" value={kind} onChange={(next) => { setKind(next); if (next === '') onChange(null); }} options={[{ value: '', label: 'Choose the requested change' }, ...kinds.map((k) => ({ value: k, label: COMMAND_LABELS[k] ?? k }))]} />
      {kind === '' ? null : <OperationFields fields={specs[kind] ?? []} draft={sub} errors={{}} commandKind={kind} />}
    </div>
  );
}

/** A nested DraftApi whose value set is one object inside the parent draft. */
function useSubDraft(value: DraftValues | null, onChange: (command: DraftValues | null) => void, kind: string, parent: DraftApi): DraftApi {
  const values = value ?? {};
  const [picks, setPicks] = useState<Record<string, PickOption | null>>({});
  const [memberCtx, setMemberCtx] = useState<string | null>(null);
  return useMemo(() => ({
    values,
    institutionId: parent.institutionId,
    memberCtx,
    picks,
    setValues: (patch) => { onChange({ ...values, ...patch, kind }); },
    setField: (name, fieldValue) => { onChange({ ...values, [name]: fieldValue, kind }); },
    setMemberCtx,
    setPick: (name, option) => { setPicks((current) => ({ ...current, [name]: option })); },
  }), [values, kind, onChange, parent.institutionId, memberCtx, picks]);
}

function MaintCommandField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  return (
    <fieldset className="field field-wide">
      <legend>{spec.label} *</legend>
      <SubCommandFields kinds={Object.keys(MAINT_COMMAND_SPECS)} value={(draft.values[spec.name] ?? null) as DraftValues | null} onChange={(command) => { draft.setField(spec.name, command); }} draft={draft} />
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </fieldset>
  );
}

const PATCH_FIELDS: readonly { key: string; label: string; kind: 'text' | 'nullable' | 'textarea' | 'list' | 'maint-command' }[] = [
  { key: 'subject', label: 'Subject', kind: 'text' },
  { key: 'reason', label: 'Reason', kind: 'nullable' },
  { key: 'note', label: 'Note', kind: 'textarea' },
  { key: 'requestedCommand', label: 'Requested change', kind: 'maint-command' },
  { key: 'missingFields', label: 'Missing fields', kind: 'list' },
  { key: 'evidenceVersionId', label: 'Evidence version id', kind: 'text' },
  { key: 'evidenceDocumentVersionIds', label: 'Evidence document versions', kind: 'list' },
];

function MaintPatchField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const patch = (draft.values[spec.name] ?? {}) as DraftValues;
  const included = (key: string): boolean => Object.hasOwn(patch, key);
  const toggle = (key: string, on: boolean): void => {
    const next = { ...patch };
    if (on) next[key] = key === 'requestedCommand' ? null : '';
    else { Reflect.deleteProperty(next, key); draft.setField(spec.name, next); return; }
    draft.setField(spec.name, next);
  };
  const setPart = (key: string, value: unknown): void => { draft.setField(spec.name, { ...patch, [key]: value }); };
  const subDraft: DraftApi = { ...draft, values: patch, setValues: (p) => { draft.setField(spec.name, { ...patch, ...p }); }, setField: setPart };
  return (
    <fieldset className="field field-wide">
      <legend>{spec.label} *</legend>
      <p className="hint">Only the checked parts are amended.</p>
      {PATCH_FIELDS.map((field) => (
        <div key={field.key} className="patch-part">
          <label className="check"><input type="checkbox" checked={included(field.key)} onChange={(e) => { toggle(field.key, e.target.checked); }} /> {field.label}</label>
          {included(field.key) && field.kind === 'text' ? <TextField label={field.label} value={describeValue(patch[field.key])} onChange={(v) => { setPart(field.key, v); }} /> : null}
          {included(field.key) && field.kind === 'nullable' ? <TextField label={`${field.label} (blank = none)`} value={describeValue(patch[field.key])} onChange={(v) => { setPart(field.key, v === '' ? null : v); }} /> : null}
          {included(field.key) && field.kind === 'textarea' ? <TextAreaField label={field.label} value={describeValue(patch[field.key])} onChange={(v) => { setPart(field.key, v); }} /> : null}
          {included(field.key) && field.kind === 'list' ? <TextAreaField label={`${field.label} (one per line)`} value={Array.isArray(patch[field.key]) ? (patch[field.key] as string[]).join('\n') : ''} onChange={(v) => { setPart(field.key, v.split('\n').map((line) => line.trim()).filter((line) => line !== '')); }} /> : null}
          {included(field.key) && field.kind === 'maint-command' ? <SubCommandFields kinds={Object.keys(MAINT_COMMAND_SPECS)} value={(patch[field.key] ?? null) as DraftValues | null} onChange={(command) => { setPart(field.key, command); }} draft={subDraft} /> : null}
        </div>
      ))}
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </fieldset>
  );
}

/** The approval target: an embedded operation form producing the complete target command. */
function CommandTargetField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const target = (draft.values[spec.name] ?? null) as DraftValues | null;
  const approvable = OPERATIONS.filter((op) => op.fields.some((field) => field.name === 'approvalId'));
  return (
    <fieldset className="field field-wide">
      <legend>{spec.label} *</legend>
      {target === null ? null : <Banner tone="info" title={`Target: ${COMMAND_LABELS[String(target.kind)] ?? String(target.kind)}`}><code data-testid="approval-target">{JSON.stringify(target)}</code></Banner>}
      <SubCommandFields kinds={approvable.map((op) => op.kind)} value={target} onChange={(command) => { draft.setField(spec.name, command); }} draft={draft} />
      {error === undefined ? null : <span className="field-error" role="alert">{error}</span>}
    </fieldset>
  );
}

/* ---------- field dispatch ---------- */

function OperationField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const value = draft.values[spec.name];
  const set = (next: unknown): void => { draft.setField(spec.name, next); };
  switch (spec.kind) {
    case 'text': return <TextField label={spec.label} value={describeValue(value)} onChange={set} error={error} hint={spec.help} required={!spec.optional && !spec.nullable} />;
    case 'textarea': return <TextAreaField label={spec.label} value={describeValue(value)} onChange={set} error={error} hint={spec.help} required={!spec.optional && !spec.nullable} />;
    case 'date': return <TextField label={spec.label} type="date" value={describeValue(value)} onChange={set} error={error} hint={spec.help} required={!spec.optional && !spec.nullable} />;
    case 'datetime': return <TextField label={spec.label} value={describeValue(value)} placeholder="2026-01-31T17:00:00Z" onChange={set} error={error} hint={spec.help ?? 'ISO date-time.'} required={!spec.optional && !spec.nullable} />;
    case 'nullable': return <NullableText spec={spec} draft={draft} error={error} />;
    case 'int': return <IntField spec={spec} draft={draft} error={error} />;
    case 'money': return <MoneyField spec={spec} draft={draft} error={error} />;
    case 'boolean': return (
      <div className="field"><label className="check"><input type="checkbox" checked={value === true} onChange={(e) => { set(e.target.checked); }} /> {spec.label}</label>
        {error === undefined ? (spec.help === undefined ? null : <span className="field-hint">{spec.help}</span>) : <span className="field-error" role="alert">{error}</span>}</div>
    );
    case 'select': return <SelectField label={spec.label} value={describeValue(value)} onChange={set} error={error} hint={spec.help} required={!spec.optional && !spec.nullable}
      options={[{ value: '', label: `Choose ${spec.label.toLowerCase()}` }, ...(spec.options ?? []).map((option) => ({ value: option, label: option }))]} />;
    case 'list': return <TextAreaField label={`${spec.label} (one per line)`} value={Array.isArray(value) ? (value as string[]).join('\n') : ''} error={error} hint={spec.help} required={!spec.optional && !spec.nullable}
      onChange={(text) => { set(text.split('\n').map((line) => line.trim()).filter((line) => line !== '')); }} />;
    case 'address': return <AddressField spec={spec} draft={draft} error={error} />;
    case 'owners': return <OwnersField spec={spec} draft={draft} error={error} />;
    case 'excerpts': return <ExcerptsField spec={spec} draft={draft} error={error} />;
    case 'region': return <RegionField spec={spec} draft={draft} error={error} />;
    case 'maint-command': return <MaintCommandField spec={spec} draft={draft} error={error} />;
    case 'maint-patch': return <MaintPatchField spec={spec} draft={draft} error={error} />;
    case 'command-target': return <CommandTargetField spec={spec} draft={draft} error={error} />;
    case 'file': return <FileField spec={spec} draft={draft} error={error} />;
    default: return <PickerField spec={spec} draft={draft} error={error} />;
  }
}

function NullableText({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const value = draft.values[spec.name];
  const isNull = value === null;
  return (
    <div className={`field${error === undefined ? '' : ' field-invalid'}`}>
      <TextField label={spec.label} value={isNull ? '' : describeValue(value)} onChange={(v) => { draft.setField(spec.name, v); }} error={error} hint={spec.help} readOnly={isNull} required={!spec.optional} />
      <label className="check"><input type="checkbox" checked={isNull} onChange={(e) => { draft.setField(spec.name, e.target.checked ? null : ''); }} /> None</label>
    </div>
  );
}

function IntField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const value = draft.values[spec.name];
  const isNull = value === null;
  return (
    <div className={`field${error === undefined ? '' : ' field-invalid'}`}>
      <TextField label={spec.label} value={isNull ? '' : describeValue(value)} inputMode="decimal" readOnly={isNull}
        onChange={(v) => { draft.setField(spec.name, v.trim() === '' ? undefined : Number(v)); }} error={error} hint={spec.help} required={!spec.optional && !spec.nullable} />
      {spec.nullable ? <label className="check"><input type="checkbox" checked={isNull} onChange={(e) => { draft.setField(spec.name, e.target.checked ? null : undefined); }} /> None</label> : null}
    </div>
  );
}

function MoneyField({ spec, draft, error }: { spec: FieldSpec; draft: DraftApi; error?: string | undefined }): ReactNode {
  const win = useWindow();
  const reference = useReference(draft.institutionId);
  const value = draft.values[spec.name];
  const isNull = value === null;
  const moneyValue = (typeof value === 'object' && value !== null ? value : {}) as { minorUnits?: number | undefined; currency?: string | undefined };
  const [amount, setAmount] = useState(moneyValue.minorUnits === undefined ? '' : String(moneyValue.minorUnits));
  const currencyPick = spec.currencyFrom !== undefined ? draft.picks[spec.currencyFrom]?.payload : undefined;
  const currency = moneyValue.currency ?? (typeof currencyPick?.currency === 'string' ? currencyPick.currency : win.institution.defaultCurrency);
  const exponent = exponentOf(reference.data, currency);
  const setMoney = (minorUnits: number | undefined, nextCurrency: string): void => {
    draft.setField(spec.name, minorUnits === undefined ? undefined : { minorUnits, currency: nextCurrency });
  };
  return (
    <div className={`field${error === undefined ? '' : ' field-invalid'}`}>
      <div className="money-input">
        <TextField label={spec.label} value={amount} inputMode="decimal" readOnly={isNull} error={error}
          hint={spec.help ?? `Amount in ${currency} (e.g. 10.50).`}
          required={!spec.optional && !spec.nullable}
          onChange={(text) => {
            setAmount(text);
            const parsed = parseAmount(text, exponent);
            setMoney(parsed.ok ? parsed.minorUnits : undefined, currency);
          }} />
        <SelectField label="Currency" value={currency} onChange={(next) => {
          const parsed = parseAmount(amount, exponent);
          setMoney(parsed.ok ? parsed.minorUnits : undefined, next);
        }} options={(reference.data?.currencies ?? [{ code: currency, exponent }]).map((entry) => ({ value: entry.code, label: entry.code }))} />
        {spec.nullable ? <label className="check"><input type="checkbox" checked={isNull} onChange={(e) => { draft.setField(spec.name, e.target.checked ? null : undefined); setAmount(''); }} /> None</label> : null}
      </div>
    </div>
  );
}

function OperationFields({ fields, draft, errors, commandKind }: { fields: readonly FieldSpec[]; draft: DraftApi; errors: Record<string, string>; commandKind: string }): ReactNode {
  const visible = fields.filter((spec) => spec.when === undefined || spec.when(draft.values));
  const scoped = { ...draft, values: { ...draft.values, __commandKind: commandKind } };
  return <div className="form-grid">{visible.map((spec) => <OperationField key={spec.name} spec={spec} draft={scoped} error={errors[spec.name]} />)}</div>;
}

/* ---------- value coercion + command build ---------- */

function fieldValue(spec: FieldSpec, raw: unknown): { ok: true; value: unknown } | { ok: false; message: string } {
  const empty = raw === undefined || raw === '';
  if (empty) {
    if (spec.nullable) return { ok: true, value: null };
    if (spec.optional) return { ok: true, value: undefined };
    return { ok: false, message: `${spec.label} is required.` };
  }
  switch (spec.kind) {
    case 'int': {
      if (raw === null) return spec.nullable ? { ok: true, value: null } : { ok: false, message: `${spec.label} is required.` };
      const parsed = typeof raw === 'number' ? raw : Number(raw);
      if (!Number.isSafeInteger(parsed)) return { ok: false, message: `${spec.label} must be a whole number.` };
      return { ok: true, value: parsed };
    }
    case 'list': {
      const items = Array.isArray(raw) ? raw : [];
      if (items.length === 0 && !spec.optional) return { ok: false, message: `${spec.label} needs at least one entry.` };
      return { ok: true, value: items };
    }
    case 'boolean': return { ok: true, value: raw === true };
    case 'address': {
      if (raw === null || typeof raw !== 'object') return spec.optional === true ? { ok: true, value: undefined } : { ok: false, message: `${spec.label} is required.` };
      const address = raw as Record<string, string>;
      const missing = ['line1', 'city', 'region', 'postalCode', 'country'].find((key) => (address[key] ?? '').trim() === '');
      if (missing !== undefined) return { ok: false, message: `${spec.label}: ${missing} is required.` };
      return { ok: true, value: { line1: (address.line1 ?? '').trim(), line2: (address.line2 ?? '').trim() || null, city: (address.city ?? '').trim(), region: (address.region ?? '').trim(), postalCode: (address.postalCode ?? '').trim(), country: (address.country ?? '').trim() } };
    }
    case 'owners': {
      const rows = (raw ?? []) as { memberId: string; ownershipBps: string; isControlPerson: boolean; evidenceId: string }[];
      if (rows.length === 0) return { ok: false, message: 'Add at least one beneficial owner.' };
      const owners = rows.map((row) => ({ memberId: row.memberId.trim(), ownershipBps: Number(row.ownershipBps), isControlPerson: row.isControlPerson, evidenceId: row.evidenceId.trim() }));
      if (owners.some((owner) => owner.memberId === '' || !Number.isSafeInteger(owner.ownershipBps) || owner.evidenceId === '')) return { ok: false, message: 'Each owner needs a member id, whole-number basis points and an evidence id.' };
      return { ok: true, value: owners };
    }
    case 'excerpts': {
      const rows = (raw ?? []) as { sourceVersionId: string; text: string }[];
      if (rows.length === 0) return { ok: false, message: 'Add at least one approved excerpt.' };
      if (rows.some((row) => row.sourceVersionId === '' || row.text.trim() === '')) return { ok: false, message: 'Each excerpt needs a source version and text.' };
      return { ok: true, value: rows };
    }
    case 'region': {
      const region = raw as Record<string, string>;
      const out: Record<string, number> = {};
      for (const key of ['x', 'y', 'width', 'height']) {
        const parsed = Number(region[key]);
        if (!Number.isSafeInteger(parsed) || parsed < 0) return { ok: false, message: `${spec.label}: ${key} must be a non-negative whole number.` };
        out[key] = parsed;
      }
      return { ok: true, value: out };
    }
    case 'money': {
      if (raw === null) return spec.nullable ? { ok: true, value: null } : { ok: false, message: `${spec.label} is required.` };
      const moneyValue = raw as { minorUnits?: number; currency?: string };
      if (typeof moneyValue.minorUnits !== 'number' || typeof moneyValue.currency !== 'string') return { ok: false, message: `${spec.label} needs an amount.` };
      return { ok: true, value: moneyValue };
    }
    case 'file': {
      if (typeof raw !== 'string' || raw === '') return { ok: false, message: `${spec.label} is required.` };
      return { ok: true, value: raw };
    }
    default:
      return { ok: true, value: raw };
  }
}

export function buildCommand(spec: OperationSpec, values: DraftValues): { command: ServiceCommand } | { errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  const command: DraftValues = { kind: spec.kind };
  for (const field of spec.fields) {
    if (field.when !== undefined && !field.when(values)) continue;
    const raw = values[field.name];
    const result = fieldValue(field, raw);
    if (!result.ok) { errors[field.name] = result.message; continue; }
    if (result.value === undefined) continue;
    if (!field.contextOnly && !field.name.startsWith('__')) command[field.name] = result.value;
  }
  // Bound fields (versions, fingerprints, copied payload keys) live outside the field list;
  // those of hidden fields stay out of the command.
  const hidden = new Set(spec.fields.filter((field) => field.when !== undefined && !field.when(values))
    .flatMap((field) => [field.name, ...Object.values(field.binds ?? {}), ...Object.values(field.copy ?? {})]));
  for (const [key, value] of Object.entries(values)) {
    if (key === 'kind' || key.startsWith('__') || hidden.has(key) || Object.hasOwn(command, key)) continue;
    if (spec.fields.some((field) => field.name === key)) continue;
    if (value !== undefined) command[key] = value;
  }
  return Object.keys(errors).length === 0 ? { command: command as ServiceCommand } : { errors };
}

/* ---------- review dialog (shared review/commit/approval semantics) ---------- */

export function OperationReviewDialog({ institutionId, command, review, verb, close, onCommitted }: {
  institutionId: string; command: ServiceCommand; review: OperationReview; verb: string; close: () => void; onCommitted: (outcome: Committed) => void;
}): ReactNode {
  const [busy, setBusy] = useState(false);
  const [rejection, setRejection] = useState<Rejection | null>(null);
  const [failure, setFailure] = useState<string | null>(null);
  const [unknownResult, setUnknownResult] = useState(false);
  const [terms] = useState(() => ({ command, key: newIdempotencyKey(command.kind) }));
  const inFlight = useRef(false);
  useBusyWhile(busy);

  const run = async (work: () => Promise<void>): Promise<void> => {
    if (inFlight.current) return;
    inFlight.current = true;
    setBusy(true);
    try { await work(); } finally { inFlight.current = false; setBusy(false); }
  };
  const settle = (outcome: Committed): void => { stampWatcher.checkSoon(); close(); onCommitted(outcome); };
  const post = (): Promise<void> => run(async () => {
    setFailure(null);
    try {
      const outcome = await executeCommand(institutionId, terms.command, terms.key);
      if (outcome.kind === 'committed' || outcome.kind === 'duplicate') { settle(outcome); return; }
      setUnknownResult(false);
      if (outcome.kind === 'rejected') setRejection(outcome); else setFailure(outcome.message);
    } catch (error) {
      if (error instanceof ApiError && error.status !== 0 && error.status < 500) { setUnknownResult(false); setFailure(error.message); return; }
      setUnknownResult(true);
      setFailure('The server did not confirm the result. Retrying sends the same request key, so the operation cannot post twice.');
    }
  });
  const checkOutcome = (): Promise<void> => run(async () => {
    try {
      const receipt = await getJson<{ receiptNumber: string } & Record<string, unknown>>(institutionPath(institutionId, `/operations/by-key/${encodeURIComponent(terms.key)}`));
      settle({ kind: 'duplicate', receipt: receipt as never });
    } catch (error) {
      if (error instanceof ApiError && error.status === 404) { setUnknownResult(false); setFailure('Nothing was posted under this request key.'); return; }
      setFailure(error instanceof ApiError ? error.message : 'The result could not be checked.');
    }
  });

  const exponent = review.exponent ?? 2;
  const primary = unknownResult
    ? <button type="button" className="primary" disabled={busy} data-autofocus onClick={() => { void checkOutcome(); }}>Check outcome</button>
    : <button type="submit" className="primary" disabled={busy || rejection !== null} data-autofocus>{busy ? 'Posting…' : rejection === null ? verb : 'Back to form'}</button>;
  return (
    <Dialog scope="window" title={`Review ${COMMAND_LABELS[command.kind]?.toLowerCase() ?? command.kind}`} busy={busy} width={620} onCancel={close} onSubmit={() => { if (rejection === null) void post(); else close(); }}
      actions={<>
        {primary}
        {unknownResult ? <button type="submit" disabled={busy}>Retry with the same request</button> : null}
        <button type="button" onClick={close} disabled={busy}>{rejection === null ? 'Back' : 'Back to form'}</button>
      </>}>
      <DetailList items={[
        ['Institution', review.institutionName],
        ['Operation', COMMAND_LABELS[review.commandKind] ?? review.commandKind],
        ...review.accounts.map((account, index): [string, ReactNode] => [review.accounts.length > 1 ? (index === 0 ? 'From' : 'To') : 'Account', `${account.accountNumber} · ${account.ownerName}`]),
        ['Amount', review.amount === null ? '' : <strong key="amount" data-testid="review-amount">{formatMoney(review.amount.minorUnits, review.amount.currency, exponent)}</strong>],
        ['Description', review.description ?? ''],
      ]} />
      {review.consequences.length === 0 ? null : <ul className="consequences">{review.consequences.map((line) => <li key={line}>{line}</li>)}</ul>}
      <pre className="command-preview" data-testid="review-command">{JSON.stringify(command, null, 2)}</pre>
      {rejection === null ? null : <Banner tone="error" title={rejectionTitle(rejection.code)}><span data-testid="rejection-code" data-code={rejection.code}>{rejection.message}</span> Nothing was posted.</Banner>}
      {failure === null ? null : <Banner tone="warning" title={unknownResult ? 'Result unknown.' : 'Not posted.'}>{failure}</Banner>}
      <p className="hint">Request key <code data-testid="idempotency-key">{terms.key}</code></p>
    </Dialog>
  );
}

/* ---------- operation window ---------- */

export function OperationWindow({ commandKind, prefill }: { commandKind: string; prefill?: DraftValues | undefined }): ReactNode {
  const { can, notify, open } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const spec = operationSpec(commandKind);
  const [values, setValuesState] = useState<DraftValues>(() => ({ ...(prefill ?? {}) }));
  const [picks, setPicks] = useState<Record<string, PickOption | null>>({});
  const [memberCtx, setMemberCtx] = useState<string | null>(typeof prefill?.memberId === 'string' ? prefill.memberId : null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [outcome, setOutcome] = useState<SubmitOutcome | null>(null);
  const [reviewing, setReviewing] = useState(false);

  const draft: DraftApi = useMemo(() => ({
    values, institutionId, memberCtx, picks,
    setValues: (patch) => { setValuesState((current) => ({ ...current, ...patch })); },
    setField: (name, value) => { setValuesState((current) => ({ ...current, [name]: value })); },
    setMemberCtx,
    setPick: (name, option) => { setPicks((current) => ({ ...current, [name]: option })); },
  }), [values, institutionId, memberCtx, picks]);

  const dirty = Object.entries(values).some(([key, value]) => !key.startsWith('__') && value !== undefined && value !== '' && JSON.stringify(value) !== JSON.stringify(prefill?.[key]));
  useWindowChrome(spec === undefined ? 'Operation' : `${spec.label} · ${win.institution.displayName}`, {}, dirty);

  const review = async (): Promise<void> => {
    if (spec === undefined || reviewing || win.dialogs.open) return;
    const built = buildCommand(spec, values);
    if ('errors' in built) { setErrors(built.errors); return; }
    setErrors({});
    setReviewing(true);
    try {
      const result = await reviewCommand(institutionId, built.command);
      if (result.kind !== 'reviewable') { setOutcome(result); return; }
      setOutcome(null);
      win.dialogs.show((close) => (
        <OperationReviewDialog institutionId={institutionId} command={built.command} review={result.review} verb="Commit" close={close}
          onCommitted={(committed) => {
            setOutcome(committed);
            notify(`${spec.label} committed. Receipt ${committed.receipt.receiptNumber}.`);
          }} />
      ));
    } catch (error) {
      setOutcome({ kind: 'failed', message: error instanceof ApiError ? error.message : 'The review could not be prepared.' });
    } finally { setReviewing(false); }
  };

  const requestApproval = (): void => {
    if (spec === undefined) return;
    const built = buildCommand(spec, values);
    if ('errors' in built) { setErrors(built.errors); return; }
    const target = { ...built.command } as Record<string, unknown>;
    delete target.approvalId;
    open(institutionId, { kind: 'operation', commandKind: 'approval.request', prefill: { target } }, { reuse: false });
  };

  const allowed = can(institutionId, commandKind);
  const hasApprovalField = spec?.fields.some((field) => field.name === 'approvalId') ?? false;

  useWindowCommands({ save: async () => { await review(); return false; } });

  if (spec === undefined) return <Banner tone="error" title="Unknown operation.">No registry entry exists for {commandKind}.</Banner>;
  return (
    <div className="form-window">
      <Toolbar label={`${spec.label} actions`}>
        <button type="button" className="primary" disabled={!allowed || reviewing} onClick={() => { void review(); }}>Review…</button>
        {hasApprovalField && can(institutionId, 'approval.request') ? <button type="button" onClick={requestApproval}>Request approval…</button> : null}
        <button type="button" onClick={() => { setValuesState({ ...(prefill ?? {}) }); setPicks({}); setErrors({}); setOutcome(null); }}>Reset</button>
      </Toolbar>
      {allowed ? null : <Banner tone="warning" title="Not permitted.">The signed-on operator holds no grant for {commandKind}; the form stays readable for preparation.</Banner>}
      {outcome === null ? null : <OutcomeBanner outcome={outcome} onDismiss={() => { setOutcome(null); }} />}
      {spec.help === undefined ? null : <p className="hint">{spec.help}</p>}
      <OperationFields fields={spec.fields} draft={draft} errors={errors} commandKind={commandKind} />
    </div>
  );
}

/* ---------- operations catalog ---------- */

export function OperationsCatalogWindow(): ReactNode {
  const { open, can } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [filter, setFilter] = useState('');
  useWindowChrome(`Operations · ${win.institution.displayName}`, {}, false);
  const needle = filter.trim().toLowerCase();
  return (
    <div className="catalog-window">
      <Toolbar label="Operations catalog">
        <input type="search" value={filter} placeholder="Filter operations…" aria-label="Filter operations" onChange={(event) => { setFilter(event.target.value); }} />
      </Toolbar>
      {OPERATION_GROUPS.map((group) => {
        const entries = OPERATIONS.filter((op) => op.group === group && (needle === '' || op.label.toLowerCase().includes(needle) || op.kind.includes(needle)));
        if (entries.length === 0) return null;
        return (
          <section key={group} className="catalog-group">
            <h3>{group}</h3>
            <ul className="catalog-list">
              {entries.map((op) => (
                <li key={op.kind}>
                  <button type="button" disabled={!can(institutionId, op.kind)} onClick={() => { open(institutionId, { kind: 'operation', commandKind: op.kind }, { reuse: false }); }}
                    title={can(institutionId, op.kind) ? op.kind : `${op.kind} — not permitted for this operator`}>
                    {op.label}
                  </button>
                  <code>{op.kind}</code>
                </li>
              ))}
            </ul>
          </section>
        );
      })}
    </div>
  );
}
