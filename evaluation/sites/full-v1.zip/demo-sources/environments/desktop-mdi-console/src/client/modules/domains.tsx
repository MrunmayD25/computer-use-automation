import { useState, type ReactNode } from 'react';

import type { FinanceListRow } from '@computer-use/financial-database/services';

import { ApiError, exportStatementBundle, financeQuery, getJson, institutionPath, queryString } from '../api';
import { useDesktop, useWindow, useWindowChrome, useWindowCommands } from '../desktop/context';
import { Banner, Loading, SelectField, TextField, Toolbar } from '../widgets/fields';
import { useResource } from '../widgets/useResource';

/* ---------- reconciliation ---------- */

interface ReconResult { kind: string; data?: Record<string, unknown>; message?: string; code?: string }

function ReconPanel({ title, children, result }: { title: string; children: ReactNode; result: ReconResult | null }): ReactNode {
  return (
    <section className="recon-panel">
      <h3>{title}</h3>
      {children}
      {result === null ? null : result.kind === 'rejected'
        ? <Banner tone="error" title="Rejected."><span data-testid="rejection-code" data-code={result.code}>{result.message}</span></Banner>
        : <pre className="command-preview" data-testid={`recon-${title}`}>{JSON.stringify(result.data, null, 2)}</pre>}
    </section>
  );
}

/** Reconciliation desk: suspense queue, settlement batches, and the bounded comparison queries. */
export function ReconciliationWindow(): ReactNode {
  const { open, can } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [transfer, setTransfer] = useState({ journalId: '', fingerprint: '' });
  const [settlement, setSettlement] = useState({ batchId: '', fingerprint: '', digest: '', cutoff: '' });
  const [cashDay, setCashDay] = useState({ businessDate: '', sessionIds: '', declaredTotal: '' });
  const [results, setResults] = useState<Record<string, ReconResult | null>>({});
  const suspense = useResource(() => financeQuery(institutionId, { kind: 'finance.records', resource: 'suspense-item', scope: {}, limit: 100 }), 'suspense');
  const settlements = useResource(() => financeQuery(institutionId, { kind: 'finance.records', resource: 'settlement-batch', scope: {}, limit: 100 }), 'settlements');
  useWindowChrome(`Reconciliation · ${win.institution.displayName}`, {}, false);
  useWindowCommands({ refresh: () => { suspense.reload(); settlements.reload(); } });
  const run = async (key: string, query: Parameters<typeof financeQuery>[1]): Promise<void> => {
    setResults((current) => ({ ...current, [key]: null }));
    try {
      const outcome = await financeQuery(institutionId, query);
      setResults((current) => ({ ...current, [key]: outcome }));
    }
    catch (error) { setResults((current) => ({ ...current, [key]: { kind: 'rejected', message: error instanceof ApiError ? error.message : 'The query failed.' } })); }
  };
  const suspenseItems = suspense.data?.kind === 'listed' ? suspense.data.items : [];
  const settlementRows = settlements.data?.kind === 'listed' ? settlements.data.items : [];
  return (
    <div className="form-window">
      <Toolbar label="Reconciliation actions">
        <button type="button" onClick={() => { suspense.reload(); settlements.reload(); }}>Refresh</button>
        {can(institutionId, 'reconciliation.suspense.investigate') ? <button type="button" onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'reconciliation.suspense.investigate' }, { reuse: false }); }}>Investigate suspense…</button> : null}
        {can(institutionId, 'reconciliation.suspense.clear') ? <button type="button" onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'reconciliation.suspense.clear' }, { reuse: false }); }}>Clear suspense…</button> : null}
      </Toolbar>
      <div className="split-panes">
        <section>
          <h3>Suspense items</h3>
          {suspense.loading ? <Loading label="Loading suspense items…" /> : null}
          <table className="grid" data-testid="suspense-items">
            <thead><tr><th scope="col">Item</th><th scope="col">Remaining</th><th scope="col">State</th><th scope="col">Evidence</th></tr></thead>
            <tbody>{suspenseItems.map((item: FinanceListRow) => (
              <tr key={item.id}><td><code>{item.id}</code></td><td>{item.fields.remainingMinorUnits} {item.fields.currency}</td><td>{item.fields.state}</td><td>{item.fields.evidenceReference}</td></tr>
            ))}</tbody>
          </table>
        </section>
        <section>
          <h3>Settlement batches</h3>
          {settlements.loading ? <Loading label="Loading settlement batches…" /> : null}
          <table className="grid" data-testid="settlement-batches">
            <thead><tr><th scope="col">Reference</th><th scope="col">Declared total</th><th scope="col">State</th><th scope="col">Cutoff</th></tr></thead>
            <tbody>{settlementRows.map((item) => (
              <tr key={item.id}><td>{item.fields.reference}</td><td>{item.fields.declaredTotalMinorUnits} {item.fields.currency}</td><td>{item.fields.state}</td><td>{item.fields.cutoffAt}</td></tr>
            ))}</tbody>
          </table>
        </section>
      </div>
      <div className="split-panes">
        <ReconPanel title="Transfer reconciliation" result={results.transfer ?? null}>
          <TextField label="Transfer journal id" value={transfer.journalId} onChange={(v) => { setTransfer({ ...transfer, journalId: v }); }} />
          <TextField label="Expected fingerprint" value={transfer.fingerprint} onChange={(v) => { setTransfer({ ...transfer, fingerprint: v }); }} />
          <button type="button" onClick={() => { void run('transfer', { kind: 'reconciliation.transfer', transferJournalId: transfer.journalId, expectedFingerprint: transfer.fingerprint }); }}>Reconcile</button>
        </ReconPanel>
        <ReconPanel title="Settlement reconciliation" result={results.settlement ?? null}>
          <TextField label="Settlement batch id" value={settlement.batchId} onChange={(v) => { setSettlement({ ...settlement, batchId: v }); }} />
          <TextField label="Expected fingerprint" value={settlement.fingerprint} onChange={(v) => { setSettlement({ ...settlement, fingerprint: v }); }} />
          <TextField label="Settlement file digest" value={settlement.digest} onChange={(v) => { setSettlement({ ...settlement, digest: v }); }} />
          <TextField label="Cutoff" value={settlement.cutoff} placeholder="2026-01-31T17:00:00Z" onChange={(v) => { setSettlement({ ...settlement, cutoff: v }); }} />
          <button type="button" onClick={() => { void run('settlement', { kind: 'reconciliation.settlement_batch', settlementBatchId: settlement.batchId, expectedFingerprint: settlement.fingerprint, settlementFileDigest: settlement.digest, cutoff: settlement.cutoff }); }}>Reconcile</button>
        </ReconPanel>
        <ReconPanel title="Cash-day check" result={results.cashDay ?? null}>
          <TextField label="Business date" type="date" value={cashDay.businessDate} onChange={(v) => { setCashDay({ ...cashDay, businessDate: v }); }} />
          <TextField label="Cash session ids (comma separated)" value={cashDay.sessionIds} onChange={(v) => { setCashDay({ ...cashDay, sessionIds: v }); }} />
          <TextField label="Declared total (minor units)" value={cashDay.declaredTotal} inputMode="decimal" onChange={(v) => { setCashDay({ ...cashDay, declaredTotal: v }); }} />
          <button type="button" onClick={() => { void run('cashDay', { kind: 'reconciliation.cash_day', businessDate: cashDay.businessDate, cashSessionIds: cashDay.sessionIds.split(',').map((id) => id.trim()).filter((id) => id !== ''), declaredTotal: { minorUnits: Number(cashDay.declaredTotal), currency: win.institution.defaultCurrency } }); }}>Check</button>
        </ReconPanel>
      </div>
    </div>
  );
}

/* ---------- batches ---------- */

/** Batch register with item drill-down, preview, and apply operations. */
export function BatchesWindow(): ReactNode {
  const { open, can } = useDesktop();
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const [selected, setSelected] = useState<string | null>(null);
  const batches = useResource(() => financeQuery(institutionId, { kind: 'finance.records', resource: 'batch', scope: {}, limit: 100 }), 'batches');
  const items = useResource(selected === null ? null : () => financeQuery(institutionId, { kind: 'finance.records', resource: 'batch-item', scope: { batchId: selected }, limit: 200 }), `items:${selected ?? ''}`);
  const [preview, setPreview] = useState<ReconResult | null>(null);
  const [previewArgs, setPreviewArgs] = useState({ digest: '', schemaVersion: '1' });
  useWindowChrome(`Batches · ${win.institution.displayName}`, {}, false);
  useWindowCommands({ refresh: () => { batches.reload(); items.reload(); } });
  const batchRows = batches.data?.kind === 'listed' ? batches.data.items : [];
  const itemRows = items.data?.kind === 'listed' ? items.data.items : [];
  const selectedRow = batchRows.find((row) => row.id === selected);
  const runPreview = async (): Promise<void> => {
    if (selected === null) return;
    const detail = await financeQuery(institutionId, { kind: 'finance.record', resource: 'batch', id: selected });
    if (detail.kind !== 'found') { setPreview(detail); return; }
    setPreview(await financeQuery(institutionId, {
      kind: 'batch.preview', batchId: selected, expectedFingerprint: detail.snapshot.fingerprint,
      inputDigest: previewArgs.digest, schemaVersion: previewArgs.schemaVersion, allowedMemberIds: [], allowedAccountIds: [],
    }));
  };
  return (
    <div className="form-window">
      <Toolbar label="Batch actions">
        <button type="button" onClick={() => { batches.reload(); }}>Refresh</button>
        {can(institutionId, 'batch.import') ? <button type="button" onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'batch.import' }, { reuse: false }); }}>Import batch…</button> : null}
      </Toolbar>
      <div className="split-panes">
        <section>
          <h3>Batches</h3>
          {batches.loading ? <Loading label="Loading batches…" /> : null}
          <table className="grid" data-testid="batches">
            <thead><tr><th scope="col">Number</th><th scope="col">Kind</th><th scope="col">State</th><th scope="col" /></tr></thead>
            <tbody>{batchRows.map((row) => (
              <tr key={row.id} className={row.id === selected ? 'selected' : undefined} data-batch={row.id}>
                <td>{row.fields.batchNumber}</td><td>{row.fields.kind}</td><td>{row.fields.state}</td>
                <td><button type="button" onClick={() => { setSelected(row.id); setPreview(null); }}>Items</button></td>
              </tr>
            ))}</tbody>
          </table>
        </section>
        <section>
          <h3>Items {selectedRow === undefined ? '' : `· ${selectedRow.fields.batchNumber}`}</h3>
          {selected === null ? <p className="hint">Choose a batch to list its items.</p> : null}
          {items.loading ? <Loading label="Loading items…" /> : null}
          <table className="grid" data-testid="batch-items">
            <thead><tr><th scope="col">#</th><th scope="col">Source key</th><th scope="col">State</th><th scope="col">Amount</th><th scope="col">Failure</th><th scope="col" /></tr></thead>
            <tbody>{itemRows.map((item) => (
              <tr key={item.id}><td>{item.fields.ordinal}</td><td>{item.fields.sourceKey}</td><td>{item.fields.state}</td><td>{item.fields.amountMinorUnits ?? '—'}</td><td>{item.fields.failureCode ?? '—'}</td>
                <td>
                  {selectedRow?.fields.kind === 'contact-update' && can(institutionId, 'batch.contacts.apply') ? <button type="button" onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'batch.contacts.apply', prefill: { batchId: selected, itemId: item.id } }, { reuse: false }); }}>Apply…</button> : null}
                  {selectedRow?.fields.kind === 'fee-refund' && can(institutionId, 'batch.fee_refunds.apply') ? <button type="button" onClick={() => { open(institutionId, { kind: 'operation', commandKind: 'batch.fee_refunds.apply', prefill: { batchId: selected, itemId: item.id } }, { reuse: false }); }}>Apply…</button> : null}
                </td>
              </tr>
            ))}</tbody>
          </table>
        </section>
      </div>
      {selected === null ? null : (
        <section className="recon-panel">
          <h3>Batch preview</h3>
          <TextField label="Input digest" value={previewArgs.digest} onChange={(v) => { setPreviewArgs({ ...previewArgs, digest: v }); }} />
          <TextField label="Schema version" value={previewArgs.schemaVersion} onChange={(v) => { setPreviewArgs({ ...previewArgs, schemaVersion: v }); }} />
          <button type="button" onClick={() => { void runPreview(); }}>Preview</button>
          {preview === null ? null : preview.kind === 'rejected'
            ? <Banner tone="error" title="Preview rejected.">{preview.message}</Banner>
            : <pre className="command-preview" data-testid="batch-preview">{JSON.stringify(preview.data, null, 2)}</pre>}
        </section>
      )}
    </div>
  );
}

/* ---------- statements ---------- */

interface AccountStatementsProps { accountId: string; memberId: string }

const FORMATS = ['html', 'csv', 'pdf'] as const;

/** Statement center: issued versions, historical retrieval, and derived bundle export. */
export function StatementsWindow({ accountId, memberId }: AccountStatementsProps): ReactNode {
  const win = useWindow();
  const institutionId = win.institution.institutionId;
  const statements = useResource(() => getJson<{ periods: { period: string; openingMinorUnits: number; closingMinorUnits: number }[]; documents: { versionId: string; displayName: string; mediaType: string; digest: string; periodStart: string | null; periodEnd: string | null }[] }>(
    institutionPath(institutionId, `/accounts/${encodeURIComponent(accountId)}/statements`)), `statements:${accountId}`);
  const [exportState, setExportState] = useState({ period: '', formats: ['pdf'] as string[], destinationId: 'browser-download' });
  const [historical, setHistorical] = useState({ periodStart: '', periodEnd: '', format: 'application/pdf' });
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [failure, setFailure] = useState<string | null>(null);
  const [artifacts, setArtifacts] = useState<{ format: string; displayName: string; digest: string; byteLength: number; contentBase64: string; mediaType: string }[]>([]);
  useWindowChrome(`Statements · ${accountId}`, { account: accountId }, false);
  useWindowCommands({ refresh: () => { statements.reload(); } });
  const periods = statements.data?.periods ?? [];
  const documents = statements.data?.documents ?? [];

  const runExport = async (): Promise<void> => {
    setBusy(true);
    setFailure(null);
    setNotice(null);
    try {
      const result = await exportStatementBundle(institutionId, { memberId, accountId, period: exportState.period, formats: exportState.formats as ('html' | 'csv' | 'pdf')[], destinationId: exportState.destinationId });
      if (result.kind !== 'artifacts' || result.artifacts === undefined) { setFailure(result.message ?? 'The export was rejected.'); setArtifacts([]); return; }
      setArtifacts(result.artifacts);
      setNotice(`Bundle exported at ${result.observedAt ?? 'now'} — ${result.artifacts.length} artifact(s).`);
    } catch (error) {
      setFailure(error instanceof ApiError ? error.message : 'The export failed.');
    } finally { setBusy(false); }
  };

  const download = (artifact: { displayName: string; contentBase64: string; mediaType: string }): void => {
    const bytes = Uint8Array.from(atob(artifact.contentBase64), (c) => c.charCodeAt(0));
    const url = URL.createObjectURL(new Blob([bytes], { type: artifact.mediaType }));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = artifact.displayName;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const historicalUrl = `${institutionPath(institutionId, `/accounts/${encodeURIComponent(accountId)}/statements/historical`)}${queryString({ periodStart: historical.periodStart, periodEnd: historical.periodEnd, format: historical.format })}`;

  return (
    <div className="form-window">
      <Toolbar label="Statement actions"><button type="button" onClick={() => { statements.reload(); }}>Refresh</button></Toolbar>
      {statements.loading ? <Loading label="Loading statements…" /> : null}
      <section>
        <h3>Derived periods</h3>
        <table className="grid" data-testid="statement-periods">
          <thead><tr><th scope="col">Period</th><th scope="col">Opening</th><th scope="col">Closing</th><th scope="col">PDF</th></tr></thead>
          <tbody>{periods.map((period) => (
            <tr key={period.period}>
              <td>{period.period}</td>
              <td>{period.openingMinorUnits}</td><td>{period.closingMinorUnits}</td>
              <td><a href={institutionPath(institutionId, `/accounts/${encodeURIComponent(accountId)}/statement.pdf${queryString({ period: period.period })}`)} download>Download PDF</a></td>
            </tr>
          ))}</tbody>
        </table>
      </section>
      <section>
        <h3>Issued statement versions</h3>
        <table className="grid" data-testid="statement-documents">
          <thead><tr><th scope="col">Document</th><th scope="col">Media</th><th scope="col">Period</th><th scope="col">Digest</th><th scope="col" /></tr></thead>
          <tbody>{documents.map((document) => (
            <tr key={document.versionId}>
              <td>{document.displayName}</td><td>{document.mediaType}</td><td>{document.periodStart ?? '—'} → {document.periodEnd ?? '—'}</td><td><code>{document.digest.slice(0, 16)}…</code></td>
              <td><a href={institutionPath(institutionId, `/documents/${encodeURIComponent(document.versionId)}/content`)} download>Open bytes</a></td>
            </tr>
          ))}</tbody>
        </table>
      </section>
      <section className="recon-panel">
        <h3>Export bundle</h3>
        <SelectField label="Period" value={exportState.period} onChange={(v) => { setExportState({ ...exportState, period: v }); }}
          options={[{ value: '', label: 'Choose period' }, ...periods.map((period) => ({ value: period.period, label: period.period }))]} />
        <fieldset className="radio-inline" aria-label="Formats">
          {FORMATS.map((format) => (
            <label key={format}><input type="checkbox" checked={exportState.formats.includes(format)} onChange={(event) => {
              setExportState({ ...exportState, formats: event.target.checked ? [...exportState.formats, format] : exportState.formats.filter((item) => item !== format) });
            }} /> {format.toUpperCase()}</label>
          ))}
        </fieldset>
        <SelectField label="Destination" value={exportState.destinationId} onChange={(v) => { setExportState({ ...exportState, destinationId: v }); }}
          options={[{ value: 'browser-download', label: 'Browser download' }]} />
        <button type="button" className="primary" disabled={busy || exportState.period === '' || exportState.formats.length === 0} onClick={() => { void runExport(); }}>Export bundle</button>
        {notice === null ? null : <Banner tone="success">{notice}</Banner>}
        {failure === null ? null : <Banner tone="error">{failure}</Banner>}
        {artifacts.map((artifact) => (
          <div key={artifact.format} className="artifact-card" data-testid={`artifact-${artifact.format}`}>
            <strong>{artifact.displayName}</strong> · {artifact.mediaType} · {artifact.byteLength} bytes · <code>{artifact.digest}</code>
            <button type="button" onClick={() => { download(artifact); }}>Download</button>
          </div>
        ))}
      </section>
      <section className="recon-panel">
        <h3>Historical statement</h3>
        <TextField label="Period start" type="date" value={historical.periodStart} onChange={(v) => { setHistorical({ ...historical, periodStart: v }); }} />
        <TextField label="Period end" type="date" value={historical.periodEnd} onChange={(v) => { setHistorical({ ...historical, periodEnd: v }); }} />
        <SelectField label="Format" value={historical.format} onChange={(v) => { setHistorical({ ...historical, format: v }); }}
          options={[{ value: 'application/pdf', label: 'PDF' }, { value: 'text/csv', label: 'CSV' }, { value: 'text/html', label: 'HTML' }]} />
        <a className="button" href={historicalUrl} download data-testid="historical-download">Retrieve issued bytes</a>
        <p className="hint">Historical retrieval returns the issued, immutable bytes with their stored digest — never a re-generated statement.</p>
      </section>
    </div>
  );
}
