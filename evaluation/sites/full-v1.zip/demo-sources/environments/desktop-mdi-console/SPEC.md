# Desktop MDI console specification

## Identity and scope

`desktop-mdi-console` (version 0.1.0) is the third application in the environment registry (historical material omitted from this bundle), listed second among the ten additional applications. It is a browser-hosted operations desktop modeled on Ext JS and older enterprise desktop web clients. Operators at Northstar, Riverton and Harbor service members, accounts, money movements, statements, activity and servicing cases. Many record windows are open at once.

The application exposes ordinary business operations only. Benchmark tasks, expected answers, fixtures and grading live under [`evaluation/`](../../evaluation/README.md) and never reach the browser or the public API.

## Shared data

- The server opens the shared SQLite database of [`@computer-use/financial-database`](../database/financial/README.md) and binds one named world. Each institution maps to an explicit `institutionId` and `datasetId`. Business numbers collide across institutions, so every window, request and receipt carries its institution.
- The desktop never seeds or resets shared data. It refuses to start when the database file or the named world is missing.
- Reads and mutations go through the package's `./services` export. Every write is one SQLite transaction that records an operation, its receipt and audit events. Nothing authoritative is cached in the application.
- The browser sees institution identifiers only. Dataset identifiers stay on the server.

## Operator identity

- **Shared mode.** An HttpOnly, SameSite=Strict session cookie holds the signed-on operator number, chosen from the `--operators` list. The server resolves the actor per institution from `actors` and `actor_roles`. Permitted commands come from the shared `CAPABILITY_GRANTS`. A disabled operator gets no commands. The browser never sends an actor identifier.
- **Verification mode.** The evaluator starts the desktop in-process over `verificationRunStore(run)`. The operator is fixed, sign-on is refused, and writes carry the principal kind the evaluator supplies. Closing the desktop detaches from the run; the evaluator keeps ownership of the run, its snapshots, grading and disposal.
- Cross-origin writes are rejected. Request bodies are validated with strict schemas that reject unknown fields.

## Modules

| Module | Operations |
| --- | --- |
| Members | Search with sort and paging; inquiry with identity, contact, notes, accounts, cases and activity; list the member's accounts; create a member; edit email, phone and mailing address; add general or restricted notes; follow a merged member to its survivor. |
| Accounts | Search by number, member, owner or nickname with status and currency filters; inquiry with posted and available balances, parties, holds, restrictions, cards and eligibility; transaction search by date, direction, amount, text, exact reference in any letter case and posted or reversed status; open an account; edit nickname and statement delivery; close an eligible zero-balance account after review; switch to another account of the member. |
| Money | Cash deposit, cash withdrawal and internal transfer between one member's accounts. Each is validated, reviewed in a dialog showing exact terms and available balances before and after, then posted once with a durable receipt. |
| Receipts | Receipt windows rebuilt from stored operation, journal and event rows, with links to affected records. Find any receipt by number. |
| Statements and documents | Generated statement PDFs per period. A Documents window searches stored document versions by account, member, type or file name and downloads the exact stored bytes. Every download carries its SHA-256 digest. Transaction history export as CSV. |
| Activity and audit | Committed operations for the institution, member, account or case, filterable, with receipt links. |
| Cases | Case register with state, queue, assignee, priority and overdue filters; open a case; assign queue and worker with a reason; link, relink or unlink one of the case member's accounts with a reason; move through allowed states with a reason; add notes; view linked records, documents, timeline and service-level intervals. |
| Saved searches | Member, account and case searches can be saved with their filters, sort, visible columns and an optional result limit. A search is private, or shared when the operator holds case or supervisory authority. Saved searches are updated and deleted by revision. Each search window has a Columns dialog. |
| Operations catalog | Every shared command kind is listed by group. A generic form renders the registry's fields — member, account, case, document, finance-record and policy pickers, money with the bound currency, nullable values, compound owners, addresses, excerpts and page regions, and nested maintenance drafts — then reviews, requests approval and commits through the same dialog as the money windows. |
| Finance records | Bounded record lists per member, account, case, batch or business date for payments, beneficiaries, cards, disputes, loans, holds, restrictions, fees, journals, transfers, schedules, returns, suspense, batches and merge plans. A record window shows the exact snapshot and fingerprint and launches its operations prebound. |
| Member servicing | One tabbed window per member lists identity evidence, addresses, consents, preferences, destinations, name history, tax history, maintenance requests, communication jobs and documents, with the related operations. |
| Approvals | Pending and decided approvals with maker, checker and expiry. A decided approval binds to its target command; checker lists come from the shared approval policy. |
| Reconciliation | Suspense items and settlement batches with transfer, settlement and cash-day reconciliation queries bound by fingerprints and digests. |
| Batches | Batch register with item drill-down, import through a batch-input document, fingerprinted preview and per-item apply. |
| Statement export | Per-account statement export producing a generated document artifact (HTML, PDF or CSV) with its digest, plus retrieval of historical stored statements. |

A command the operator's roles do not permit is disabled, and the window states the business reason. Records in a state that forbids an action say why.

## Desktop mechanisms

- **Windows.** Windows overlap, drag by the title bar, resize from the right, bottom and corner, minimize to the taskbar, restore, maximize and cascade. Z-order is explicit: activating a window raises it. The active window has a distinct title bar and a pressed taskbar button.
- **Window state.** Each window keeps its own record, tabs, split position, grid sort, filters, page, selection, scroll and draft. Opening a record reuses its window unless the operator asks for a new one. Duplicate editors of one record are allowed and hold independent drafts.
- **Context.** The status bar shows the operator, active window, institution, member, account and case. Every window shows an institution badge.
- **Repeated commands.** Save, Refresh, Print, Minimize and Close exist in several windows, in the Window menu and as shortcuts. They always act on the window that owns them or on the active window. Print prints only that window.
- **Grids.** Docked grids support column resize by pointer and keyboard, sortable headers with `aria-sort`, paging with page size, row keyboard navigation, double-click or Enter to open, Shift+Enter for a new window, and row context menus by right-click, Shift+F10 or the Menu key.
- **Dialogs.** A window-local dialog blocks only its window. Other windows stay usable, and the dialog returns when its window is activated. A desktop dialog makes the whole desktop inert. Dialogs trap Tab, cancel on Escape, confirm on Enter, and return focus to where it came from within their own window. A window-local dialog that opens in a background window, or under a desktop dialog, does not take focus until its window is in use.
- **Request ownership.** A window waiting for a result refuses Close and switching records, and Close all leaves it open. A response for a record the window no longer shows is ignored.
- **Dirty close.** Closing a window with unsaved changes asks to save, discard or cancel. Close all lists every dirty window. Leaving the page with unsaved windows triggers the browser's guard.
- **Shortcuts.** Help, Keyboard shortcuts (Alt+Shift+K) lists them all. Ctrl+S saves, Ctrl+P prints, and Alt+Shift+R, W and M refresh, close and minimize the active window. Alt+Shift+] and [ cycle windows, Alt+Shift+F and A open searches, F10 enters the menu bar, and `/` focuses the active window's search. Shortcuts pause while a menu or dialog is open. `/` is left to text fields.

## Editing and submission rules

- **Stale edits are record-scoped.** Each editor keeps the record version its draft started from. A background check polls the version stamps of open records. When another window, application or operator changes the same record, the editor shows a banner and keeps the draft. The operator can compare fields, keep their edits on the latest version, or discard them. A field changed on both sides needs an explicit choice; fields changed only elsewhere take the latest value. Changes to other records never invalidate the draft. The server rejects a stale version independently.
- **Reviews go stale.** A money review watches the accounts it names. When a balance or status changes, the review states what changed and allows only Review again. The fresh review keeps the idempotency key while the command is unchanged.
- **Submissions.** A money review has one idempotency key for its lifetime. A repeated click, Enter or retry after a lost response returns the original receipt instead of posting twice. A reused key with different terms is refused. Other saves block repeat submission while in flight and retry with the same key.
- **Failure states.** Loading, empty results, load failures with retry, field validation, business rejections with their code, and unknown outcomes after a network failure are each shown distinctly. An unknown outcome is resolved with Check outcome, which reads the receipt by request key.

## Evaluator integration

The evaluator imports `startDesktopConsole` and passes a store over its run's `read` and `write`. The trusted evaluator context supplies the operator and principal kind. Grading definitions for application qualification live under [`evaluation/verifier/app-qualification/`](../../evaluation/verifier/app-qualification/), in `desktop-mdi-console-deposit.mjs` and `desktop-mdi-console-cases.mjs`. The evaluator grades and persists the report before it disposes the run.

## Completion criteria

The modules above provide implemented desktop surfaces over a disposable copy of the shared database. Current browser qualification is narrower: the capability manifest (historical material omitted from this bundle) marks catalog capabilities `supported_unverified` until capability-specific, current-commit evidence is recorded. COVERAGE.md (historical material omitted from this bundle) records the release gate and provenance, while `IMPLEMENTATION.md` (historical material omitted from this bundle) records implementation decisions and limits.

