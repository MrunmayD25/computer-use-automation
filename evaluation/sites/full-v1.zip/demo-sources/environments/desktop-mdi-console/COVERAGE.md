# desktop-mdi-console coverage

## Full-v1 qualification

Release verdict: FULL-V1 COMPLETE

- Source commit: `5d321dc48d1cd93ab526249342c3cddbfe532413`
- Evidence run: `full-v1-5d321dc-20260920`
- Visible task options: 102/102
- Workflow path and recovery branches: 30/30
- Family mechanism: desktop-mdi
- Shared-world checks: 3/3
- Durable records: `environments/desktop-mdi-console/verification/evidence/full-v1-5d321dc-20260920/`

The option-level matrix and exact commands, tests, visible entries/results, business effects, artifact paths, and recovery observations are in `capability-manifest.json` and the evidence directory.

## Reproduce the release audit

Run `npm --prefix environments run audit:full-v1` from the repository root. The audit fails closed on missing, stale, ignored, untracked, or wrong-application artifacts.
