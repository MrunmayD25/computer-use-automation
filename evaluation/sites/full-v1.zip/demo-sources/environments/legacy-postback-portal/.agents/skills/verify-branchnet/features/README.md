# BranchNet feature map

Each row maps an area of [`SPEC.md`](../../../../SPEC.md) to the browser tests that cover it. Paths are relative to `environments/legacy-postback-portal/`. Run one row with `npm run verify -- --grep '<test title fragment>'`.

## Modules

| SPEC area | Spec file | Test title fragment |
| --- | --- | --- |
| Home, menu, quick member search | `verification/operations.spec.ts` | `menu and quick search` |
| Members: search, open with return link, notes, requests tab | `verification/operations.spec.ts` | `members are searched` |
| Members: create with validation | `verification/portal.spec.ts` | `validation summary names each field` |
| Members: grid paging, sorting, expansion | `verification/portal.spec.ts` | `paging, sorting, and row expansion` |
| Members: contact edit, stale second window | `verification/portal.spec.ts` | `two windows edit one record`, `stale window gets a conflict` |
| Accounts: filter, open, deposit, withdraw, edit, close after review | `verification/operations.spec.ts` | `accounts are filtered` |
| Accounts: editable grid rows on a member | `verification/portal.spec.ts`, `verification/mechanisms.spec.ts` | `editable account rows`, `editable grid row commits` |
| Transactions: transfer with dependent controls | `verification/operations.spec.ts` | `transfer rebuilds dependent controls` |
| Transactions: review refresh, receipt refresh, duplicate post | `verification/mechanisms.spec.ts` | `refreshing a review` |
| Statements: account and period dropdowns, CSV | `verification/operations.spec.ts` | `statements follow` |
| Activity: action filter, calendar, record links, CSV | `verification/operations.spec.ts`, `verification/portal.spec.ts` | `activity filters`, `CSV exports` |
| Maintenance requests: draft, queue, submit, cancel | `verification/operations.spec.ts` | `request is drafted` |
| Maintenance requests: category chain and ineligible accounts | `verification/mechanisms.spec.ts` | `RequestEdit rebuilds reasons` |
| Maintenance requests: printable copy in its own window | `verification/portal.spec.ts` | `printable request` |
| Not-found pages for unknown identifiers | `verification/mechanisms.spec.ts` | `one server form` |

## Web Forms mechanisms

| SPEC mechanism | Spec file | Test title fragment |
| --- | --- | --- |
| Single server form, hidden fields, `__doPostBack`, `private, no-cache` | `verification/mechanisms.spec.ts` | `one server form` |
| Full-document postbacks (window marker and footer request number) | `verification/portal.spec.ts`, `verification/mechanisms.spec.ts` | `replace the whole document`, `editable grid row commits` |
| Scroll and focus restoration | `verification/mechanisms.spec.ts` | `restores the scroll position` |
| Generated, positional grid row names | `verification/mechanisms.spec.ts` | `names are positional` |
| Grid rebuilt with regenerated controls after Update | `verification/mechanisms.spec.ts` | `editable grid row commits` |
| Dependent controls | `verification/operations.spec.ts`, `verification/mechanisms.spec.ts` | `transfer rebuilds`, `statements follow`, `RequestEdit rebuilds reasons` |
| Event validation (value that was not offered, 400) | `verification/mechanisms.spec.ts` | `RequestEdit rebuilds reasons` |
| Validation summary separate from the `*` field markers | `verification/portal.spec.ts`, `verification/mechanisms.spec.ts` | `validation summary`, `validators mark fields` |
| Back restores a cached document that still posts | `verification/portal.spec.ts`, `verification/mechanisms.spec.ts` | `Back restores`, `names are positional`, `refreshing a review` |
| Refreshing a postback result resubmits it; refreshing a committed result is a GET | `verification/portal.spec.ts`, `verification/mechanisms.spec.ts` | `refresh resubmits`, `refreshing a review` |
| Stale revision: 409, entries preserved, comparison shown, no write | `verification/portal.spec.ts` | `two windows edit one record`, `stale window gets a conflict` |
| Expiry after idle timeout: 410 and reload | `verification/portal.spec.ts` | `expired page state` |
| Eviction from the bounded page-state history: 410 and reload | `verification/mechanisms.spec.ts` | `evicted from the bounded history` |
| Unknown session message | `verification/datasets.spec.ts` | `reset detaches only the requester` |

## Shared data and administration

| SPEC area | Spec file | Test title fragment |
| --- | --- | --- |
| Meridian Core and BranchNet on one database and `DEFAULT_DATASET`; each UI sees the other's changes; both admin APIs agree | `verification/cross-application.spec.ts` | `Meridian Core and BranchNet` |
| Isolated dataset independent of the demonstration dataset | `verification/datasets.spec.ts` | `isolated dataset stays independent` |
| Shared sessions; reset and disposal preserve peers, including a Meridian instance | `verification/datasets.spec.ts` | `reset detaches only the requester` |

Unit and HTTP tests under `test/` cover token validation, expiry, idempotent resubmission, and form-state limits below the browser.
