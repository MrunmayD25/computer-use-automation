---
name: verify-branchnet
description: Verify the BranchNet legacy postback portal through its real browser UI, alone or together with Meridian Core on one shared database, and inspect persisted state through the administration API. Use for changes within environments/legacy-postback-portal, not for agent benchmarks or other applications.
---

# Verify BranchNet

Run commands from `environments/legacy-postback-portal/`.

## Launch

From `environments/`, run `npm ci` once, then `npm run build` before every verification. The build compiles the database package, Meridian Core, and BranchNet. Install the browser with `npx playwright install chromium` when it is missing.

`npm run verify` runs the browser suite. Most tests start BranchNet in-process on ephemeral loopback ports with a temporary database. `verification/cross-application.spec.ts` and `verification/datasets.spec.ts` also spawn compiled CLIs: `../legacy-banking-console/dist/src/main.js` and `dist/src/main.js`. A stale or missing build therefore fails or tests old code. Rebuild after changing `src/`.

For manual inspection, start a disposable copy:

```sh
node dist/src/main.js --port 0 --admin-port 0 --admin-token-file /tmp/branchnet/admin.token --database /tmp/branchnet/shared.sqlite --verbose
```

With `--verbose`, stderr prints `BranchNet UI: <origin>` and `BranchNet admin: <origin>`, then one line per request: method, page, status, and the control that raised the postback. Without `--database`, the app opens the persistent shared file `../database/.runtime/shared.sqlite`. Without port flags, it listens on 4320 and 4321. Do not use either default for disposable checks. A Meridian Core preview may already run on 4310 to 4312 against the shared file. Leave that preview alone.

To check both applications together manually, start Meridian Core with the same `--database` path, ephemeral ports, and its own token file: `node ../legacy-banking-console/dist/src/main.js --port 0 --frame-port 0 --admin-port 0 --admin-token-file /tmp/branchnet/meridian.token --database /tmp/branchnet/shared.sqlite --verbose`. It prints `Meridian Core UI:`, `Meridian Core frame origin:`, and `Meridian Core admin:`.

## Doctor

- Run `npm run typecheck` and `npm run lint`.
- For a manual instance, `curl -sS -o /dev/null -w '%{http_code} %{redirect_url}\n' <ui-origin>/` must print `302` and a `/(S(<24 characters>))/Default.aspx` URL. Otherwise the listener is not BranchNet with a demonstration session.
- The administration listener answers only with `Authorization: Bearer <token>` from the token file. It rejects requests that carry browser headers such as `Origin` or `Sec-Fetch-*`.

## Drive

Run the full suite with `npm run verify`. Targeted runs:

- `npm run verify -- --grep 'Meridian Core and BranchNet'`: both applications on one database.
- `npm run verify -- --grep 'dataset'`: isolation, shared sessions, reset, and disposal.
- `npm run verify -- verification/mechanisms.spec.ts`: Web Forms mechanisms.

Drive business actions through rendered controls. Never post HTTP forms directly as a substitute for a UI check. The helpers encode the working patterns:

- `verification/fixtures.ts` provides the `instance` fixture: a fresh session on an isolated seed-7 dataset. It also provides `adminRequest`, `bankState` and `instanceState` for persisted state, `withEnvironment` for custom configuration such as a clock or history size, `capture` for screenshots, `markDocument` and `documentWasReplaced` to prove a postback replaced the document, and `requestNumber` for the footer counter.
- `verification/portal-ui.ts` has BranchNet control lookups by Web Forms ID suffix, member search and open, email edit, and notes.
- `verification/processes.ts` has `startMeridian` and `startBranchNet`, which spawn the compiled CLIs and parse origins from stderr. It also has `adminClient` and `stopAll`, which sends SIGTERM and returns each exit.
- `verification/meridian.ts` finds Meridian content by searching every frame of the page for a visible marker. Meridian's demonstration session uses the `combined-hard` layout, which nests frames across two origins. Do not import Meridian's own verification helpers.

Auto-postback dropdowns submit the form. Wait for the page `load` event, or for the rebuilt control, before reading the new document. Seed data is deterministic, so tests assert literal member numbers, emails, and balances. Seed 7 lists `NM426507` first on the Members page, and `DEFAULT_DATASET` includes `NM718367` Jonah Patel. Read literal values from `/instances/:id/state` rather than guessing them.

## Evidence

Playwright writes `verification/artifacts/<run-id>/results.json`, screenshots under `verification/artifacts/<run-id>/browser/<test>/`, and traces on failure. Set `BRANCHNET_VERIFICATION_RUN=<run-id>` to name the run. Without it, the run id is a timestamp and process id. `capture` attaches each screenshot to the report. The cross-application and dataset tests also attach JSON evidence: dataset ids, origins, and the revision log.

Confirm persistence through the administration state, not a screenshot. Check revisions and records after every mutation, and check that the revision does not change after a rejected, stale, expired, or refreshed submission. For cross-application checks, both administration listeners must report the same `datasetId`, the same revision, and equal `bank` records.

## Cleanup

Fixtures close in-process listeners and delete their temporary databases. Tests that spawn CLIs close the browser contexts that talked to those processes, then send SIGTERM through `stopAll`. They assert exit `{ code: 0, signal: null }` and delete the temporary directory only after every process has stopped. For manual runs, stop only the processes you started, then delete their temporary directory. Keep artifacts after cleanup.

## Helpers

- [Feature map](features/README.md) maps SPEC areas to the specs that cover them.
