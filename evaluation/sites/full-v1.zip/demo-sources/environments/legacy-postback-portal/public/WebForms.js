(function () {
  'use strict';

  var form = document.getElementById('aspnetForm');
  var postBackHref = /^javascript:__doPostBack\('([^']*)','([^']*)'\)$/;
  var textTypes = ['text', 'email', 'tel', 'search', 'number', 'password'];

  function field(name) {
    return form ? form.elements.namedItem(name) : null;
  }

  function remember(source) {
    var scroll = field('__SCROLLPOSITIONY');
    var focus = field('__LASTFOCUS');
    if (scroll) scroll.value = String(Math.round(window.scrollY || 0));
    if (focus) focus.value = source && source.id ? source.id : '';
  }

  function doPostBack(target, argument, source) {
    if (!form) return;
    field('__EVENTTARGET').value = target;
    field('__EVENTARGUMENT').value = argument;
    remember(source);
    form.submit();
  }

  window.__doPostBack = function (target, argument) {
    doPostBack(target, argument, document.activeElement);
  };

  document.addEventListener('click', function (event) {
    var element = event.target instanceof Element ? event.target : null;
    if (!element) return;
    if (element.closest('[data-print]')) {
      event.preventDefault();
      window.print();
      return;
    }
    if (element.closest('[data-close-window]')) {
      event.preventDefault();
      window.close();
      return;
    }
    var anchor = element.closest('a[href^="javascript:__doPostBack"]');
    if (!anchor) return;
    var match = postBackHref.exec(anchor.getAttribute('href') || '');
    if (!match) return;
    event.preventDefault();
    doPostBack(match[1], match[2], anchor);
  });

  document.addEventListener('change', function (event) {
    var control = event.target;
    if (control instanceof HTMLSelectElement && control.getAttribute('data-autopostback') === 'true') {
      window.setTimeout(function () {
        doPostBack(control.name, '', control);
      }, 0);
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' || event.isComposing || event.defaultPrevented) return;
    var input = event.target;
    if (!(input instanceof HTMLInputElement) || textTypes.indexOf(input.type) < 0) return;
    event.preventDefault();
    var panel = input.closest('[data-default-button]');
    var button = panel ? document.getElementById(panel.getAttribute('data-default-button')) : null;
    if (button instanceof HTMLElement && !button.hasAttribute('disabled')) {
      button.click();
      return;
    }
    doPostBack('', '', input);
  });

  if (form) {
    form.addEventListener('submit', function (event) {
      // A page restored from the back-forward cache can still hold the last link's target.
      field('__EVENTTARGET').value = '';
      field('__EVENTARGUMENT').value = '';
      remember(event.submitter || document.activeElement);
    });

    var scroll = field('__SCROLLPOSITIONY');
    if (scroll && /^\d+$/.test(scroll.value) && scroll.value !== '0') {
      window.scrollTo(0, Number(scroll.value));
    }
    var lastFocus = field('__LASTFOCUS');
    var focusTarget = lastFocus && lastFocus.value ? document.getElementById(lastFocus.value) : null;
    if (focusTarget && typeof focusTarget.focus === 'function') {
      focusTarget.focus({ preventScroll: true });
    }
  }
})();
