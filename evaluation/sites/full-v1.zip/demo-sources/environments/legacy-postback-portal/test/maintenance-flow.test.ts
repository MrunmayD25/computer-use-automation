import { afterEach, describe, expect, it } from 'vitest';

import {
  closePortals,
  controlName,
  open,
  required,
  startPortal,
  submit,
  type Portal,
  type PortalPage,
} from './conftest.js';

afterEach(closePortals);

async function session(
  portal: Portal,
  options: { actorNumber?: string; datasetId?: string } = {},
): Promise<{ instanceId: string; datasetId: string; at: (path: string) => URL }> {
  const created = await portal.createInstance(
    options.datasetId === undefined ? { seed: 7, actorNumber: options.actorNumber } : { datasetId: options.datasetId, actorNumber: options.actorNumber },
  );
  return { instanceId: created.instanceId, datasetId: created.datasetId, at: (path) => new URL(path, created.entryUrl) };
}

/** Opens a second session on the same dataset as the dataset-scoped supervisor. */
async function supervisor(portal: Portal, datasetId: string): Promise<{ at: (path: string) => URL }> {
  const created = await portal.createInstance({ datasetId, actorNumber: 'OP0005' });
  return { at: (path) => new URL(path, created.entryUrl) };
}

function fieldControl(page: PortalPage, key: string): string {
  return required(page.root.querySelector(`[id$="_fld_${key}"]`)?.getAttribute('name'), `operation field ${key}`);
}

/** Runs an operation end to end: open the form, review, commit, return the receipt page. */
async function runOperation(at: (path: string) => URL, query: string, fields: Record<string, string> = {}): Promise<PortalPage> {
  const form = await open(at(`Operation.aspx?${query}`));
  const entries = Object.fromEntries(Object.entries(fields).map(([key, value]) => [fieldControl(form, key), value]));
  const review = await submit(form, { button: controlName(form.root, 'btnReview'), fields: entries });
  expect(review.root.querySelector('#reviewPanel')).not.toBeNull();
  return submit(review, { button: controlName(review.root, 'btnCommit') });
}

async function makeDraft(at: (path: string) => URL, member: Record<string, unknown>, subject: string): Promise<string> {
  const editor = await open(at(`RequestEdit.aspx?member=${String(member.memberNumber)}`));
  const saved = await submit(editor, {
    button: controlName(editor.root, 'btnSave'),
    fields: {
      [controlName(editor.root, 'txtMember')]: String(member.memberNumber),
      [controlName(editor.root, 'txtSubject')]: subject,
      [controlName(editor.root, 'ddlRequested')]: 'member.note.add',
      [controlName(editor.root, 'txtRequestedJson')]: JSON.stringify({ memberId: String(member.id), visibility: 'general', text: 'Serviced request' }),
      [controlName(editor.root, 'txtReason')]: 'Servicing note explaining the request',
    },
  });
  return required(new URL(saved.url).searchParams.get('request'), 'request number');
}

describe('maintenance request lifecycle', () => {
  it('saves a draft, submits, approves, and applies it against the committed change receipt', async () => {
    const portal = await startPortal();
    const { instanceId, datasetId, at } = await session(portal);
    const checker = await supervisor(portal, datasetId);
    const member = required((await portal.state(instanceId)).members.items[0], 'member');
    const requestNumber = await makeDraft(at, member, 'Add a service note');
    expect(requestNumber).toMatch(/^[A-Z0-9-]+$/u);

    const detail = await open(at(`RequestDetail.aspx?request=${requestNumber}`));
    expect(detail.body).toContain('draft');
    expect(detail.body).toContain('Edit draft');

    // Submit: draft -> submitted.
    const submitted = await runOperation(at, `op=maintenance.request.submit&request=${requestNumber}`);
    expect(submitted.status).toBe(200);
    expect((await open(at(`RequestDetail.aspx?request=${requestNumber}`))).body).toContain('submitted');
    // A submitted request can no longer be edited as a draft.
    const blocked = await open(at(`RequestEdit.aspx?request=${requestNumber}`));
    expect(blocked.body).toContain('Only drafts can be changed');

    // Review: submitted -> approved, by the supervisor session.
    const reviewed = await runOperation(checker.at, `op=maintenance.request.review&request=${requestNumber}`, {
      decision: 'approve',
      reason: 'Complete and verified',
    });
    expect(reviewed.status).toBe(200);
    expect((await open(at(`RequestDetail.aspx?request=${requestNumber}`))).body).toContain('approved');

    // Apply: the operator commits the requested change, then binds its receipt.
    const receipt = await runOperation(at, `op=member.note.add&member=${String(member.memberNumber)}`, {
      visibility: 'general',
      text: 'Serviced request',
    });
    const receiptId = required(
      /Receipt id<\/th><td[^>]*>([^<]+)</u.exec(receipt.body)?.[1],
      'receipt id on receipt page',
    );
    const processed = await runOperation(checker.at, `op=maintenance.request.process&request=${requestNumber}`, {
      disposition: 'apply',
      reason: 'Change applied',
      appliedReceiptId: receiptId.trim(),
    });
    expect(processed.status).toBe(200);
    const done = await open(at(`RequestDetail.aspx?request=${requestNumber}`));
    expect(done.body).toContain('applied');
    expect(done.body).toContain(receiptId.trim());
  });

  it('withdraws a submitted request with a reason', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const member = required((await portal.state(instanceId)).members.items[0], 'member');
    const requestNumber = await makeDraft(at, member, 'Withdraw me');
    await runOperation(at, `op=maintenance.request.submit&request=${requestNumber}`);
    const withdrawn = await runOperation(at, `op=maintenance.request.withdraw&request=${requestNumber}`, { reason: 'Member withdrew the request' });
    expect(withdrawn.status).toBe(200);
    const detail = await open(at(`RequestDetail.aspx?request=${requestNumber}`));
    expect(detail.body).toContain('withdrawn');
  });

  it('returns a submitted request for information', async () => {
    const portal = await startPortal();
    const { instanceId, datasetId, at } = await session(portal);
    const checker = await supervisor(portal, datasetId);
    const member = required((await portal.state(instanceId)).members.items[0], 'member');
    const requestNumber = await makeDraft(at, member, 'Incomplete request');
    await runOperation(at, `op=maintenance.request.submit&request=${requestNumber}`);
    const returned = await runOperation(checker.at, `op=maintenance.request.review&request=${requestNumber}`, {
      decision: 'return-for-information',
      reason: 'Evidence document missing',
      missingFields: 'proof-of-address',
    });
    expect(returned.status).toBe(200);
    const detail = await open(at(`RequestDetail.aspx?request=${requestNumber}`));
    // The request returns to draft carrying the reviewer's missing-field list.
    expect(detail.body).toContain('draft');
    expect(detail.body).toContain('proof-of-address');
  });
});
