import { afterEach, describe, expect, it } from 'vitest';

import {
  closePortals,
  controlName,
  httpPost,
  formAction,
  open,
  pageOf,
  postBackBody,
  required,
  startPortal,
  submit,
  textOf,
  type Portal,
  type PortalPage,
} from './conftest.js';

afterEach(closePortals);

const SUMMARY = '#ctl00_MainContent_vsSummary';

async function session(portal: Portal): Promise<{ instanceId: string; at: (path: string) => URL }> {
  const created = await portal.createInstance({ seed: 7 });
  return { instanceId: created.instanceId, at: (path) => new URL(path, created.entryUrl) };
}

function fieldControl(page: PortalPage, key: string): string {
  return required(page.root.querySelector(`[id$="_fld_${key}"]`)?.getAttribute('name'), `operation field ${key}`);
}

/** Opens an operation form, posts Review, and returns the review document. */
async function review(at: (path: string) => URL, query: string, fields: Record<string, string> = {}): Promise<PortalPage> {
  const form = await open(at(`Operation.aspx?${query}`));
  const entries = Object.fromEntries(Object.entries(fields).map(([key, value]) => [fieldControl(form, key), value]));
  return submit(form, { button: controlName(form.root, 'btnReview'), fields: entries });
}

async function conflictOf(page: PortalPage, options: Parameters<typeof postBackBody>[1]): Promise<PortalPage> {
  const result = pageOf(await httpPost(formAction(page), postBackBody(page.root, options)));
  expect(result.status).toBe(409);
  return result;
}

async function makeDraft(at: (path: string) => URL, member: Record<string, unknown>, subject: string): Promise<string> {
  const editor = await open(at(`RequestEdit.aspx?member=${String(member.memberNumber)}`));
  const saved = await submit(editor, {
    button: controlName(editor.root, 'btnSave'),
    fields: {
      [controlName(editor.root, 'txtMember')]: String(member.memberNumber),
      [controlName(editor.root, 'txtSubject')]: subject,
      [controlName(editor.root, 'ddlRequested')]: 'member.note.add',
      [controlName(editor.root, 'txtRequestedJson')]: JSON.stringify({ memberId: String(member.id), visibility: 'general', text: 'placeholder' }),
      [controlName(editor.root, 'txtReason')]: 'Reason for the requested change',
    },
  });
  return required(new URL(saved.url).searchParams.get('request'), 'request number');
}

async function saveDraft(at: (path: string) => URL, requestNumber: string, subject: string): Promise<PortalPage> {
  const editor = await open(at(`RequestEdit.aspx?request=${requestNumber}`));
  return submit(editor, {
    button: controlName(editor.root, 'btnSave'),
    fields: { [controlName(editor.root, 'txtSubject')]: subject },
  });
}

describe('version-bound operations and durable form semantics', () => {
  it('rejects a commit whose bound version moved, then commits after a fresh review', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const account = required((await portal.state(instanceId)).accounts.items.find((a) => a.status === 'open'), 'open account');
    const url = `op=account.nickname.update&account=${String(account.accountNumber)}`;
    const before = await portal.state(instanceId);

    const mine = await review(at, url, { nickname: 'Mine' });
    const peer = await review(at, url, { nickname: 'Peer' });
    await submit(peer, { button: controlName(peer.root, 'btnCommit') });
    expect((await portal.state(instanceId)).operations).toBe(before.operations + 1);

    const stale = await conflictOf(mine, { button: controlName(mine.root, 'btnCommit') });
    expect(textOf(stale.root, SUMMARY)).toContain('changed');
    expect((await portal.state(instanceId)).operations).toBe(before.operations + 1);

    const reReviewed = await submit(stale, { button: controlName(stale.root, 'btnReview') });
    const committed = await submit(reReviewed, { button: controlName(reReviewed.root, 'btnCommit') });
    expect(committed.status).toBe(200);
    expect((await portal.state(instanceId)).operations).toBe(before.operations + 2);
  });

  it('rejects a stale draft amend, shows the saved/current comparison, and saves on retry', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const member = required((await portal.state(instanceId)).members.items[0], 'member');
    const requestNumber = await makeDraft(at, member, 'Initial draft');

    const mine = await open(at(`RequestEdit.aspx?request=${requestNumber}`));
    await saveDraft(at, requestNumber, 'Peer subject');
    const stale = await conflictOf(mine, {
      button: controlName(mine.root, 'btnSave'),
      fields: { [controlName(mine.root, 'txtSubject')]: 'My subject' },
    });
    expect(textOf(stale.root, SUMMARY)).toContain('changed');
    expect(textOf(stale.root, '#ctl00_MainContent_pnlCurrentValues')).toContain('Server revision');

    // The frozen page state keeps the old bound timestamp; recovery is a fresh open that rebinds it.
    const resaved = await saveDraft(at, requestNumber, 'My subject');
    expect(new URL(resaved.url).searchParams.get('request')).toBe(requestNumber);
    const detail = await open(at(`RequestDetail.aspx?request=${requestNumber}`));
    expect(textOf(detail.root, 'body')).toContain('My subject');
  });

  it('rejects a stale request submission while an amended draft stays draft', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const member = required((await portal.state(instanceId)).members.items[0], 'member');
    const requestNumber = await makeDraft(at, member, 'Submit me');

    const submitReview = await review(at, `op=maintenance.request.submit&request=${requestNumber}`);
    await saveDraft(at, requestNumber, 'Amended during submit review');
    const stale = await conflictOf(submitReview, { button: controlName(submitReview.root, 'btnCommit') });
    expect(textOf(stale.root, SUMMARY)).toContain('changed');
    const detail = await open(at(`RequestDetail.aspx?request=${requestNumber}`));
    expect(detail.body).toContain('draft');

    const fresh = await open(at(`Operation.aspx?op=maintenance.request.submit&request=${requestNumber}`));
    const reReview = await submit(fresh, { button: controlName(fresh.root, 'btnReview') });
    const submitted = await submit(reReview, { button: controlName(reReview.root, 'btnCommit') });
    expect(submitted.status).toBe(200);
  });

  it('commits a refreshed draft save exactly once when the postback repeats', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const member = required((await portal.state(instanceId)).members.items[0], 'member');
    const memberNumber = String(member.memberNumber);
    const editor = await open(at(`RequestEdit.aspx?member=${memberNumber}`));
    const body = postBackBody(editor.root, {
      button: controlName(editor.root, 'btnSave'),
      fields: {
        [controlName(editor.root, 'txtMember')]: memberNumber,
        [controlName(editor.root, 'txtSubject')]: 'Duplicate guard',
        [controlName(editor.root, 'ddlRequested')]: 'member.note.add',
        [controlName(editor.root, 'txtRequestedJson')]: JSON.stringify({ memberId: String(member.id), visibility: 'general', text: 'placeholder' }),
      },
    });
    const action = formAction(editor);
    const first = await httpPost(action, body);
    const repeat = await httpPost(action, body);
    expect([first.status, repeat.status]).toEqual([303, 303]);
    expect(first.headers.get('location')).toBe(repeat.headers.get('location'));
    const requestNumber = new URL(`http://x${String(first.headers.get('location'))}`).searchParams.get('request');

    const state = await portal.state(instanceId);
    expect(state.operations).toBeGreaterThan(0);
    const list = await open(at('Requests.aspx'));
    expect(list.body.match(new RegExp(`RequestDetail\\.aspx\\?request=${requestNumber ?? 'none'}`, 'gu'))?.length).toBe(1);
  });

  it('keeps unrelated reviewed operations committable after another window writes', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const state = await portal.state(instanceId);
    const account = required(state.accounts.items.find((a) => a.status === 'open'), 'open account');
    const member = required(state.members.items[0], 'member');

    const reviewPage = await review(at, `op=cash.deposit&account=${String(account.accountNumber)}`, {
      amount: '7.00',
      description: 'Counter deposit',
    });
    // An unrelated write (a note on a different subject) does not invalidate the bound version.
    const memberPage = await open(at(`MemberDetail.aspx?member=${String(member.memberNumber)}`));
    await submit(memberPage, {
      button: controlName(memberPage.root, 'btnAddNote'),
      fields: { [controlName(memberPage.root, 'txtNote')]: 'Unrelated change during review' },
    });
    const committed = await submit(reviewPage, { button: controlName(reviewPage.root, 'btnCommit') });
    expect(committed.status).toBe(200);
    expect(new URL(committed.url).pathname).toContain('Receipt.aspx');
  });
});
