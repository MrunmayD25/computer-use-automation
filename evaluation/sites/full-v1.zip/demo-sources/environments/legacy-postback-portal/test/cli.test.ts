import { mkdtemp, readdir, readFile, rm, stat, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';

import { afterEach, describe, expect, it } from 'vitest';

import { parseCli, writeAdminToken } from '../src/main.js';

const directories: string[] = [];

afterEach(async () => {
  await Promise.all(directories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })));
});

async function temporaryDirectory(): Promise<string> {
  const directory = await mkdtemp(join(tmpdir(), 'branchnet-cli-test-'));
  directories.push(directory);
  return directory;
}

describe('command line', () => {
  it('parses decimal ports and limits', () => {
    expect(parseCli(['--port', '0', '--admin-port', '4321', '--form-state-ttl', '60', '--form-state-history', '5', '--verbose'])).toEqual({
      port: 0,
      adminPort: 4321,
      adminTokenFile: '.runtime/admin.token',
      verbose: true,
      formStateTtlMs: 60_000,
      formStateHistory: 5,
      world: 'financial-demo-v1',
      operators: ['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0006', 'OP0007'],
    });
  });

  it.each(['', '0x10', '1e3', ' 80', '-1', '65536', '80.5'])('rejects the port %j', (value) => {
    expect(() => parseCli(['--port', value])).toThrow('--port requires a port from 0 through 65535.');
  });

  it.each(['', '0x10', '1e3', '0', '86401'])('rejects the form state lifetime %j', (value) => {
    expect(() => parseCli(['--form-state-ttl', value])).toThrow('--form-state-ttl requires an integer from 1 through 86400.');
  });

  it('replaces the admin token file by rename with owner-only permissions', async () => {
    const path = join(await temporaryDirectory(), 'admin.token');
    await writeFile(path, 'old-token\n', { mode: 0o644 });
    const before = await stat(path);

    await writeAdminToken(path, 'new-token');

    const after = await stat(path);
    expect(await readFile(path, 'utf8')).toBe('new-token\n');
    expect(after.mode & 0o777).toBe(0o600);
    expect(after.ino).not.toBe(before.ino);
    expect(await readdir(dirname(path))).toEqual(['admin.token']);
  });

  it('creates a missing token directory with owner-only permissions', async () => {
    const path = join(await temporaryDirectory(), 'runtime', 'admin.token');
    await writeAdminToken(path, 'first-token');
    expect(await readFile(path, 'utf8')).toBe('first-token\n');
    expect((await stat(dirname(path))).mode & 0o777).toBe(0o700);
  });
});
