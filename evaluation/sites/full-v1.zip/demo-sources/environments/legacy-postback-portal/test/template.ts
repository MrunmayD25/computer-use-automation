import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { join, resolve } from 'node:path';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase, type DatasetBinding } from '@computer-use/financial-database';
import { financialSeedCacheKey } from '@computer-use/financial-database/testing';

export const TEST_WORLD = 'branchnet-test-v1';

let cached: { path: string; bindings: readonly DatasetBinding[] } | undefined;

/**
 * Seeds a small disposable world once under .runtime and returns it. Tests and browser
 * verification copy this file; the shared canonical database is never opened or changed.
 * Bindings travel in a sidecar so worker processes never open the template database.
 */
export async function ensureTemplate(): Promise<{ path: string; bindings: readonly DatasetBinding[] }> {
  if (cached !== undefined) return cached;
  const directory = resolve(import.meta.dirname, '..', '.runtime');
  const key = financialSeedCacheKey();
  const path = join(directory, `test-template-${key}.sqlite`);
  const sidecar = join(directory, `test-template-${key}.bindings.json`);
  if (!existsSync(path) || !existsSync(sidecar)) {
    mkdirSync(directory, { recursive: true });
    // Each worker gets a unique SQLite base name. Reusing a PID after an interrupted
    // seed can leave a WAL beside the new file and silently resurrect old operations.
    const pending = join(directory, `test-template-pending-${process.pid}-${randomUUID()}.sqlite`);
    const bindings = await (async () => {
      using database = openFinancialDatabase({ path: pending });
      await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: TEST_WORLD, scale: 'small' });
      return database.getNamedWorld(TEST_WORLD);
    })();
    renameSync(pending, path);
    for (const suffix of ['-wal', '-shm']) {
      const pendingSidecar = `${pending}${suffix}`;
      const targetSidecar = `${path}${suffix}`;
      if (existsSync(pendingSidecar)) renameSync(pendingSidecar, targetSidecar);
      else rmSync(targetSidecar, { force: true });
    }
    writeFileSync(sidecar, `${JSON.stringify(bindings)}\n`);
  }
  cached = { path, bindings: JSON.parse(readFileSync(sidecar, 'utf8')) as DatasetBinding[] };
  return cached;
}
