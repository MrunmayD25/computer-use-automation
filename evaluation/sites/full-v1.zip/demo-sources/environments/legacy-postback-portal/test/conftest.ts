import { randomUUID } from 'node:crypto';
import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { ensureTemplate, TEST_WORLD } from './template.js';
import { parse, type HTMLElement } from 'node-html-parser';
import { z } from 'zod';

import { openPortalServices, type PortalServices } from '../src/financial.js';
import { startEnvironment, type EnvironmentConfig, type EnvironmentHandle } from '../src/main.js';
import type { PageName } from '../src/page-names.js';
import { createPageContext, PostedForm, type PageContext, type PageResponse } from '../src/runtime.js';
import { createSessionStore, SESSION_PATH_PATTERN, type SessionStore, type UiSession } from '../src/sessions.js';

export function required<T>(value: T | null | undefined, description: string): T {
  if (value === null || value === undefined) throw new Error(`Missing ${description}`);
  return value;
}

export interface RenderedDocument {
  status: number;
  body: string;
  root: HTMLElement;
}

export function parseDocument(status: number, body: string): RenderedDocument {
  return { status, body, root: parse(body) };
}

export function htmlDocument(response: PageResponse): RenderedDocument {
  if (response.kind !== 'html') throw new Error(`Expected HTML but received ${response.kind}`);
  return parseDocument(response.status, response.body);
}

export interface PostBackLink {
  id: string | null;
  target: string;
  argument: string;
  text: string;
}

export function postBackLinks(root: HTMLElement): PostBackLink[] {
  return root.querySelectorAll('a').flatMap((anchor) => {
    const match = /^javascript:__doPostBack\('([^']*)','([^']*)'\)$/u.exec(anchor.getAttribute('href') ?? '');
    if (match === null) return [];
    return [{ id: anchor.getAttribute('id') ?? null, target: match[1] ?? '', argument: match[2] ?? '', text: anchor.text }];
  });
}

export function findLink(root: HTMLElement, predicate: (link: PostBackLink) => boolean, description: string): PostBackLink {
  return required(postBackLinks(root).find(predicate), description);
}

export function hiddenValue(root: HTMLElement, name: string): string {
  return required(root.querySelector(`input[name="${name}"]`)?.getAttribute('value'), `hidden field ${name}`);
}

export function textOf(root: HTMLElement, selector: string): string {
  return required(root.querySelector(selector), selector).text.replace(/\s+/gu, ' ').trim();
}

export function selectOptions(root: HTMLElement, name: string): { value: string; text: string; disabled: boolean }[] {
  const select = required(root.querySelector(`select[name="${name}"]`), `select ${name}`);
  return select.querySelectorAll('option').map((option) => ({
    value: option.getAttribute('value') ?? option.text,
    text: option.text,
    disabled: option.hasAttribute('disabled'),
  }));
}

export interface PostBackOptions {
  target?: string;
  argument?: string;
  button?: string;
  fields?: Readonly<Record<string, string>>;
}

/** Serializes the document's form the way a browser does, then applies the requested postback. */
export function postBackBody(root: HTMLElement, options: PostBackOptions = {}): URLSearchParams {
  const form = required(root.querySelector('form'), 'server form');
  const overrides = new Map(Object.entries(options.fields ?? {}));
  const body = new URLSearchParams();
  const append = (name: string, value: string): void => {
    const override = overrides.get(name);
    overrides.delete(name);
    body.append(name, override ?? value);
  };
  let buttonValue: string | undefined;
  for (const element of form.querySelectorAll('input, select, textarea')) {
    const name = element.getAttribute('name');
    if (name === undefined || element.hasAttribute('disabled')) continue;
    const tag = element.tagName.toLowerCase();
    if (tag === 'select') {
      // Browsers submit nothing when the selected option is disabled; with none selected, the first enabled one.
      const options = element.querySelectorAll('option');
      const chosen = options.find((option) => option.hasAttribute('selected')) ?? options.find((option) => !option.hasAttribute('disabled'));
      const submitted = chosen === undefined || chosen.hasAttribute('disabled') ? undefined : (chosen.getAttribute('value') ?? '');
      if (submitted !== undefined || overrides.has(name)) append(name, submitted ?? '');
      continue;
    }
    if (tag === 'textarea') {
      append(name, element.text.replace(/^\r?\n/u, ''));
      continue;
    }
    const type = (element.getAttribute('type') ?? 'text').toLowerCase();
    if (type === 'submit' || type === 'button' || type === 'image') {
      if (name === options.button) buttonValue = element.getAttribute('value') ?? '';
      continue;
    }
    if (type === 'radio' || type === 'checkbox') {
      if (overrides.has(name)) {
        if (!body.has(name)) append(name, '');
      } else if (element.hasAttribute('checked')) {
        body.append(name, element.getAttribute('value') ?? 'on');
      }
      continue;
    }
    if (name === '__EVENTTARGET') append(name, options.target ?? '');
    else if (name === '__EVENTARGUMENT') append(name, options.argument ?? '');
    else append(name, element.getAttribute('value') ?? '');
  }
  if (overrides.size > 0) throw new Error(`The form has no controls named ${[...overrides.keys()].join(', ')}`);
  if (options.button !== undefined) {
    if (buttonValue === undefined) throw new Error(`The form has no enabled button ${options.button}`);
    body.append(options.button, buttonValue);
  }
  return body;
}

/* ---------- financial fixture plumbing ---------- */

export const TEST_INSTITUTION = 'northstar';

/** Copies the seeded template to a fresh file path inside `directory`. */
export async function copySeededDatabase(directory: string): Promise<string> {
  const path = join(directory, `world-${randomUUID()}.sqlite`);
  copyFileSync((await ensureTemplate()).path, path);
  return path;
}

export function createTemporaryDirectory(): { path: string; dispose(): void } {
  const path = mkdtempSync(join(tmpdir(), 'branchnet-'));
  return { path, dispose: () => rmSync(path, { recursive: true, force: true }) };
}

export interface RuntimeFixture {
  services: PortalServices;
  store: SessionStore;
  session: UiSession;
  advance(ms: number): void;
  context(page: PageName, query?: string): PageContext;
  post(page: PageName, root: HTMLElement, options?: PostBackOptions, query?: string): PageResponse;
  close(): void;
}

export function sessionCapability(entryPath: string): string {
  return required(SESSION_PATH_PATTERN.exec(entryPath)?.[1], 'session capability');
}

export async function createRuntimeFixture(
  options: { ttlMs?: number; capacity?: number; actorNumber?: string } = {},
  postBack: (ctx: PageContext, form: PostedForm) => PageResponse,
): Promise<RuntimeFixture> {
  const directory = createTemporaryDirectory();
  const path = await copySeededDatabase(directory.path);
  const services = openPortalServices({ path, world: TEST_WORLD });
  let now = Date.parse('2026-09-11T14:00:00.000Z');
  const store = createSessionStore({
    services,
    formState: { ttlMs: options.ttlMs ?? 60_000, capacity: options.capacity ?? 200, now: () => now },
  });
  const session = required(
    store.byCapability(sessionCapability(store.create({ ...(options.actorNumber === undefined ? {} : { actorNumber: options.actorNumber }) }).entryPath)),
    'session',
  );
  let requestNumber = 0;
  const context = (page: PageName, query = ''): PageContext =>
    createPageContext({
      services,
      session,
      page,
      query: new URLSearchParams(query),
      requestNumber: ++requestNumber,
      now: new Date(now),
    });
  return {
    services,
    store,
    session,
    advance(ms) {
      now += ms;
    },
    context,
    post(page, root, postOptions = {}, query = '') {
      const form = required(PostedForm.parse(postBackBody(root, postOptions).toString()), 'posted form');
      return postBack(context(page, query), form);
    },
    close() {
      if (services.ownsStore) services.store.close();
      services.database.close();
      directory.dispose();
    },
  };
}

/** The `name` of the control whose client id ends with `_<id>`, as ASP.NET renders naming containers. */
export function controlName(root: HTMLElement, id: string): string {
  return required(root.querySelector(`[id$="_${id}"]`)?.getAttribute('name'), `control ${id}`);
}

export interface HttpResult {
  status: number;
  headers: Headers;
  body: string;
  url: string;
}

export interface PortalPage extends RenderedDocument {
  url: string;
  headers: Headers;
}

async function httpRequest(url: string | URL, init: RequestInit = {}): Promise<HttpResult> {
  const response = await fetch(url, { ...init, redirect: 'manual' });
  return { status: response.status, headers: response.headers, body: await response.text(), url: String(url) };
}

export function httpGet(url: string | URL): Promise<HttpResult> {
  return httpRequest(url);
}

export function httpPost(url: string | URL, body: URLSearchParams): Promise<HttpResult> {
  return httpRequest(url, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: body.toString(),
  });
}

export function redirectLocation(result: HttpResult): string {
  return new URL(required(result.headers.get('location'), 'location header'), result.url).href;
}

export function pageOf(result: HttpResult): PortalPage {
  return { ...parseDocument(result.status, result.body), url: result.url, headers: result.headers };
}

const redirectLimit = 5;

async function settle(first: HttpResult): Promise<PortalPage> {
  let result = first;
  for (let hops = 0; result.status >= 300 && result.status < 400; hops += 1) {
    if (hops === redirectLimit) throw new Error(`More than ${String(redirectLimit)} redirects from ${first.url}`);
    result = await httpGet(redirectLocation(result));
  }
  return pageOf(result);
}

export async function open(url: string | URL): Promise<PortalPage> {
  return settle(await httpGet(url));
}

export function formAction(from: PortalPage): string {
  const action = required(from.root.querySelector('form')?.getAttribute('action'), 'form action');
  return new URL(action, from.url).href;
}

/** Posts the page's server form the way a browser would, without following any redirect. */
export function postBack(from: PortalPage, options: PostBackOptions = {}): Promise<HttpResult> {
  return httpPost(formAction(from), postBackBody(from.root, options));
}

export async function submit(from: PortalPage, options: PostBackOptions = {}): Promise<PortalPage> {
  return settle(await postBack(from, options));
}

const createdInstanceSchema = z.object({ instanceId: z.string(), entryUrl: z.string(), datasetId: z.string() });
export type CreatedInstance = z.infer<typeof createdInstanceSchema>;

const snapshotSchema = z.object({
  instanceId: z.string(),
  institutionId: z.string(),
  datasetId: z.string(),
  actorNumber: z.string(),
  revision: z.number().int(),
  operations: z.number().int(),
  summary: z.object({ members: z.number().int(), accounts: z.number().int() }).loose(),
  members: z.object({ items: z.array(z.record(z.string(), z.unknown())) }).loose(),
  accounts: z.object({ items: z.array(z.record(z.string(), z.unknown())) }).loose(),
});
export type InstanceState = z.infer<typeof snapshotSchema>;

export interface AdminResponse {
  status: number;
  headers: Headers;
  body: unknown;
}

export interface Portal {
  handle: EnvironmentHandle;
  adminToken: string;
  databasePath: string;
  admin(method: string, path: string, body?: unknown, headers?: Readonly<Record<string, string>>): Promise<AdminResponse>;
  createInstance(request: { seed?: number; institutionId?: string; actorNumber?: string | undefined } | { datasetId: string; actorNumber?: string | undefined }): Promise<CreatedInstance>;
  state(instanceId: string): Promise<InstanceState>;
}

const portals: { handle: EnvironmentHandle; directory: { path: string; dispose(): void } }[] = [];

export async function closePortals(): Promise<void> {
  await Promise.all(
    portals.splice(0).map(async ({ handle, directory }) => {
      await handle.close();
      directory.dispose();
    }),
  );
}

export function parseCreated(body: unknown): CreatedInstance {
  return createdInstanceSchema.parse(body);
}

/** Starts both listeners on ephemeral ports against a disposable seeded database; pair with `afterEach(closePortals)`. */
export async function startPortal(
  config: Omit<EnvironmentConfig, 'adminToken' | 'databasePath' | 'port' | 'adminPort' | 'world'> & { world?: string } = {},
): Promise<Portal> {
  const directory = createTemporaryDirectory();
  const databasePath = await copySeededDatabase(directory.path);
  const adminToken = randomUUID();
  const handle = await startEnvironment({
    port: 0,
    adminPort: 0,
    demo: false,
    ...config,
    adminToken,
    databasePath,
    world: config.world ?? TEST_WORLD,
  });
  portals.push({ handle, directory });
  const admin: Portal['admin'] = async (method, path, body, headers = {}) => {
    const response = await fetch(`${handle.origins.admin}${path}`, {
      method,
      headers: {
        authorization: `Bearer ${adminToken}`,
        ...(body === undefined ? {} : { 'content-type': 'application/json' }),
        ...headers,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    const text = await response.text();
    return { status: response.status, headers: response.headers, body: text === '' ? null : JSON.parse(text) };
  };
  return {
    handle,
    adminToken,
    databasePath,
    admin,
    async createInstance(request) {
      const response = await admin('POST', '/instances', request);
      if (response.status !== 201) throw new Error(`Instance creation failed with ${String(response.status)}`);
      return parseCreated(response.body);
    },
    async state(instanceId) {
      const response = await admin('GET', `/instances/${instanceId}/state`);
      if (response.status !== 200) throw new Error(`State request failed with ${String(response.status)}`);
      return snapshotSchema.parse(response.body);
    },
  };
}

type SessionUrl = (path: string) => URL;

export async function addNote(at: SessionUrl, memberNumber: string, text: string): Promise<PortalPage> {
  const page = await open(at(`MemberDetail.aspx?member=${memberNumber}`));
  return submit(page, { button: controlName(page.root, 'btnAddNote'), fields: { [controlName(page.root, 'txtNote')]: text } });
}

/** Fills an Operation.aspx form, reviews it, and commits; returns the receipt page. */
export async function runOperation(at: SessionUrl, query: string, fields: Readonly<Record<string, string>> = {}): Promise<PortalPage> {
  const form = await open(at(`Operation.aspx?${query}`));
  const entries: Record<string, string> = {};
  for (const [key, value] of Object.entries(fields)) {
    const control = form.root.querySelector(`[id$="_fld_${key}"]`);
    entries[required(control?.getAttribute('name'), `operation field ${key}`)] = value;
  }
  const review = await submit(form, { button: controlName(form.root, 'btnReview'), fields: entries });
  return submit(review, { button: controlName(review.root, 'btnCommit') });
}

/** Opens an account for the member and returns the new account number from the receipt page. */
export async function openAccount(at: SessionUrl, memberNumber: string, nickname: string): Promise<string> {
  const receipt = await runOperation(at, `op=account.open&member=${memberNumber}`, { nickname, statementDelivery: 'electronic' });
  const match = /"accountNumber"\s*:\s*"([^"]+)"/u.exec(receipt.body) ?? /\b(\d{6,})\b/.exec(textOf(receipt.root, '.receipt-json'));
  return required(match?.[1], 'opened account number');
}

export async function closeAccount(at: SessionUrl, accountNumber: string): Promise<PortalPage> {
  return runOperation(at, `op=account.close&account=${accountNumber}`, { reason: 'Closed by test helper' });
}

export async function deposit(at: SessionUrl, accountNumber: string, amount: string): Promise<PortalPage> {
  return runOperation(at, `op=cash.deposit&account=${accountNumber}`, { amount, description: 'Test deposit' });
}
