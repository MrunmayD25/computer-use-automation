import { afterEach, describe, expect, it } from 'vitest';

import {
  closePortals,
  controlName,
  findLink,
  formAction,
  hiddenValue,
  httpGet,
  httpPost,
  open,
  pageOf,
  postBack,
  postBackBody,
  redirectLocation,
  required,
  startPortal,
  submit,
  textOf,
  type Portal,
  type PortalPage,
} from './conftest.js';

afterEach(closePortals);

async function session(
  portal: Portal,
  options: { actorNumber?: string; datasetId?: string } = {},
): Promise<{ instanceId: string; datasetId: string; at: (path: string) => URL }> {
  const created = await portal.createInstance(
    options.datasetId === undefined ? { seed: 7, actorNumber: options.actorNumber } : { datasetId: options.datasetId, actorNumber: options.actorNumber },
  );
  return { instanceId: created.instanceId, datasetId: created.datasetId, at: (path) => new URL(path, created.entryUrl) };
}

function firstRowMember(page: PortalPage): string {
  const link = required(
    page.root.querySelector('#ctl00_MainContent_grdMembers tr.grid-row a[href^="MemberDetail.aspx"]'),
    'first member row link',
  );
  return required(new URLSearchParams(required(link.getAttribute('href'), 'href').split('?')[1]).get('member'), 'member number');
}

async function firstOpenAccount(portal: Portal, instanceId: string): Promise<{ accountNumber: string; memberNumber: string }> {
  const state = await portal.state(instanceId);
  const account = required(
    state.accounts.items.find((item) => item.status === 'open'),
    'open account',
  );
  return { accountNumber: String(account.accountNumber), memberNumber: typeof account.memberNumber === 'string' ? account.memberNumber : '' };
}

/** Reviews and returns the review document; fields map spec field keys to posted control names. */
async function review(page: PortalPage, fields: Record<string, string> = {}): Promise<PortalPage> {
  const entries = Object.fromEntries(
    Object.entries(fields).map(([key, value]) => [required(controlNameOrNull(page.root, `fld_${key}`) ?? undefined, `field ${key}`), value]),
  );
  return submit(page, { button: controlName(page.root, 'btnReview'), fields: entries });
}

function controlNameOrNull(root: PortalPage['root'], id: string): string | null {
  return root.querySelector(`[id$="_${id}"]`)?.getAttribute('name') ?? null;
}

describe('HTTP surface', () => {
  it('serves pages with the Web Forms document headers', async () => {
    const portal = await startPortal();
    const { at } = await session(portal);
    const home = await httpGet(at('Default.aspx'));
    expect(home.status).toBe(200);
    expect(home.headers.get('content-type')).toBe('text/html; charset=utf-8');
    expect(home.headers.get('cache-control')).toBe('private, no-cache');
    expect(home.headers.get('x-content-type-options')).toBe('nosniff');
    expect(home.headers.get('content-security-policy')).toContain("script-src 'self'");
    expect((await httpGet(new URL('/(S(aaaaaaaaaaaaaaaaaaaaaaaa))/Default.aspx', at('/')))).status).toBe(404);
    expect((await httpGet(at('Nowhere.aspx'))).status).toBe(404);
  });

  it('pages a grid through a postback that issues a new page-state token', async () => {
    const portal = await startPortal();
    const { at } = await session(portal);
    const first = await open(at('Members.aspx'));
    const next = findLink(first.root, (link) => link.argument === 'Page$2', 'page 2 link');
    expect(next.target).toBe('ctl00$MainContent$grdMembers');

    const second = await submit(first, { target: next.target, argument: next.argument });
    expect(second.status).toBe(200);
    expect(hiddenValue(second.root, '__VIEWSTATE')).not.toBe(hiddenValue(first.root, '__VIEWSTATE'));
    expect(firstRowMember(second)).not.toBe(firstRowMember(first));
  });

  it('answers expired page state with 410 and a link that reloads the same page', async () => {
    let clock = Date.parse('2026-09-11T15:00:00.000Z');
    const portal = await startPortal({ now: () => clock });
    const { at } = await session(portal);
    const page = await open(at('Members.aspx?q=a&page=2'));
    const previous = findLink(page.root, (link) => link.argument === 'Page$1', 'page 1 link');

    clock += 20 * 60_000 + 1;
    const expired = await postBack(page, { target: previous.target, argument: previous.argument });
    expect(expired.status).toBe(410);
    const body = pageOf(expired).root;
    expect(textOf(body, 'h1')).toBe('This page has expired');
    const reload = required(body.querySelector('ul.message-links a'), 'reload link');
    expect(reload.text).toBe('Reload this page');
    expect(reload.getAttribute('href')).toBe('Members.aspx?q=a&page=2');
    expect((await open(new URL(required(reload.getAttribute('href'), 'href'), expired.url))).status).toBe(200);
  });

  it('rejects tampered postbacks before any page code runs', async () => {
    const portal = await startPortal();
    const { at } = await session(portal);
    const page = await open(at('Accounts.aspx'));
    const status = controlName(page.root, 'ddlStatus');

    const invalidChoice = await postBack(page, { target: status, fields: { [status]: 'frozen' } });
    const unknownTarget = await postBack(page, { target: 'ctl00$MainContent$grdAccounts$ctl99$lnkExpand' });
    const wrongGenerator = await postBack(page, { fields: { __VIEWSTATEGENERATOR: '00000000' } });
    const unknownToken = await postBack(page, { fields: { __VIEWSTATE: 'A'.repeat(32) } });

    expect([invalidChoice.status, unknownTarget.status, wrongGenerator.status, unknownToken.status]).toEqual([400, 400, 400, 410]);
    expect(invalidChoice.body).toContain('Invalid postback or callback argument');
    expect(unknownTarget.body).toContain('Invalid postback or callback argument');
  });

  it('commits a double-submitted operation once and redirects both submissions to one receipt', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const account = await firstOpenAccount(portal, instanceId);
    const before = await portal.state(instanceId);

    const form = await open(at(`Operation.aspx?op=cash.deposit&account=${account.accountNumber}`));
    const reviewPage = await review(form, { amount: '12.34', description: 'Counter deposit' });
    expect(reviewPage.root.querySelector('#reviewPanel')).not.toBeNull();

    const body = postBackBody(reviewPage.root, { button: controlName(reviewPage.root, 'btnCommit') });
    const firstPost = await httpPost(formAction(reviewPage), body);
    const secondPost = await httpPost(formAction(reviewPage), body);
    expect([firstPost.status, secondPost.status]).toEqual([303, 303]);
    expect(redirectLocation(secondPost)).toBe(redirectLocation(firstPost));
    expect(redirectLocation(firstPost)).toMatch(/\/Receipt\.aspx\?no=[^&]+&msg=posted$/u);

    const after = await portal.state(instanceId);
    expect(after.operations).toBe(before.operations + 1);
    const receipt = await open(redirectLocation(firstPost));
    expect(receipt.status).toBe(200);
    expect(receipt.body).toContain('cash.deposit');
    expect(receipt.body).toContain('1234');
  });

  it('commits the server-bound review even when the post echoes different field values', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const account = await firstOpenAccount(portal, instanceId);
    const before = await portal.state(instanceId);

    const form = await open(at(`Operation.aspx?op=cash.deposit&account=${account.accountNumber}`));
    const reviewPage = await review(form, { amount: '12.34', description: 'Counter deposit' });
    // The review page renders no entry fields; posted values cannot reshape the stored review.
    const committed = pageOf(
      await postBack(reviewPage, {
        button: controlName(reviewPage.root, 'btnCommit'),
        fields: { 'ctl00$MainContent$fld_amount': '99.99' },
      }),
    );
    expect(committed.status).toBe(303);
    const receipt = await open(redirectLocation(committed));
    expect(receipt.body).toContain('1234');
    expect((await portal.state(instanceId)).operations).toBe(before.operations + 1);
  });

  it('rejects a commit bound to a version that another window already moved', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const account = await firstOpenAccount(portal, instanceId);
    const before = await portal.state(instanceId);
    const url = `Operation.aspx?op=account.nickname.update&account=${account.accountNumber}`;

    // Two windows each review the rename against the same starting version.
    const mine = await review(await open(at(url)), { nickname: 'My nickname' });
    const peer = await review(await open(at(url)), { nickname: 'Peer nickname' });
    const committed = await postBack(peer, { button: controlName(peer.root, 'btnCommit') });
    expect(committed.status).toBe(303);
    expect((await portal.state(instanceId)).operations).toBe(before.operations + 1);

    const stale = pageOf(await postBack(mine, { button: controlName(mine.root, 'btnCommit') }));
    expect(stale.status).toBe(409);
    expect(stale.body).toContain('changed');
    expect((await portal.state(instanceId)).operations).toBe(before.operations + 1);

    // Re-reviewing against the new version commits cleanly.
    const reReviewed = await submit(stale, { button: controlName(stale.root, 'btnReview') });
    const reCommitted = await postBack(reReviewed, { button: controlName(reReviewed.root, 'btnCommit') });
    expect(reCommitted.status).toBe(303);
    expect((await portal.state(instanceId)).operations).toBe(before.operations + 2);
  });

  it('rejects posted text beyond the rendered maxlength', async () => {
    const portal = await startPortal();
    const { instanceId, at } = await session(portal);
    const state = await portal.state(instanceId);
    const member = required(state.members.items[0], 'member');
    const page = await open(at(`MemberDetail.aspx?member=${String(member.memberNumber)}`));
    const note = controlName(page.root, 'txtNote');
    const button = controlName(page.root, 'btnAddNote');
    const tooLong = await postBack(page, { button, fields: { [note]: 'n'.repeat(2_001) } });
    expect(tooLong.status).toBe(400);
    expect(tooLong.body).toContain('Invalid postback or callback argument');
    const withinLimit = await postBack(page, { button, fields: { [note]: 'a'.repeat(2_000) } });
    expect(withinLimit.status).toBe(303);
  });

  it('refuses an ineligible close and a same-account transfer with service reasons', async () => {
    const portal = await startPortal();
    const { instanceId, datasetId: instanceDatasetId, at } = await session(portal);
    const state = await portal.state(instanceId);
    const funded = required(
      state.accounts.items.find((item) => item.status === 'open' && Number(item.postedBalanceMinorUnits) !== 0),
      'funded account',
    );

    const closeForm = await open(at(`Operation.aspx?op=account.close&account=${String(funded.accountNumber)}`));
    const refused = await submit(closeForm, {
      button: controlName(closeForm.root, 'btnReview'),
      fields: { [required(controlNameOrNull(closeForm.root, 'fld_reason'), 'reason')]: 'Requested by member' },
    });
    expect(refused.status).toBe(422);
    expect(refused.body).toContain('closure');
    expect((await portal.state(instanceId)).operations).toBe(state.operations);

    // Internal transfers are a payments-maker capability; a second session signs on as one on the same dataset.
    const payments = await session(portal, { datasetId: instanceDatasetId, actorNumber: 'OP0003' });
    const transfer = await open(payments.at(`Operation.aspx?op=transfer.internal&account=${String(funded.accountNumber)}`));
    const same = await submit(transfer, {
      button: controlName(transfer.root, 'btnReview'),
      fields: {
        [required(controlNameOrNull(transfer.root, 'fld_destination'), 'destination')]: String(funded.accountNumber),
        [required(controlNameOrNull(transfer.root, 'fld_amount'), 'amount')]: '1.00',
        [required(controlNameOrNull(transfer.root, 'fld_description'), 'description')]: 'Same account',
      },
    });
    // Same-account validation is attached to the destination field, so the
    // postback preserves the form and returns a normal HTML validation response.
    expect(same.status).toBe(200);
    expect(same.body).toContain('must differ');
    expect(controlNameOrNull(same.root, 'btnCommit')).toBeNull();
    expect((await portal.state(instanceId)).operations).toBe(state.operations);
  });
});
