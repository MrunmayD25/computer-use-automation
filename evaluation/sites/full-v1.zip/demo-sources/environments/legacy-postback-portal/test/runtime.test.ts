import { afterEach, describe, expect, it } from 'vitest';

import { gridView } from '../src/grid.js';
import { html } from '../src/html.js';
import { definePage, handlePostBack, rendered, type PageResponse } from '../src/runtime.js';
import {
  createRuntimeFixture,
  findLink,
  hiddenValue,
  htmlDocument,
  parseDocument,
  postBackBody,
  postBackLinks,
  textOf,
  type PostBackOptions,
  type RenderedDocument,
  type RuntimeFixture,
} from './conftest.js';

type ToyEvent =
  | { kind: 'select'; item: string }
  | { kind: 'page'; index: number }
  | { kind: 'color' }
  | { kind: 'save' };

interface ToyData {
  items: string[];
  pageIndex: number;
  selected: string | null;
  handled: string[];
}

const toyPage = definePage<ToyData, ToyEvent>({
  load: () => ({
    kind: 'ready',
    data: { items: ['alpha', 'bravo', 'charlie', 'delta', 'echo'], pageIndex: 0, selected: null, handled: [] },
    fields: { color: 'red', note: '' },
  }),
  handle(_ctx, state, event) {
    state.data.handled.push(event?.kind ?? 'none');
    if (event?.kind === 'select') state.data.selected = event.item;
    if (event?.kind === 'page') state.data.pageIndex = event.index;
    return rendered(state);
  },
  render: (_ctx, state, view) => ({
    title: 'Toy',
    breadcrumbs: [],
    body: html`${gridView(view)({
      id: 'gvItems',
      rows: state.data.items,
      emptyText: 'No items.',
      paging: { pageIndex: state.data.pageIndex, pageSize: 2, event: (index) => ({ kind: 'page', index }) },
      columns: [{ header: 'Item', cell: (item, row) => row.linkButton('lnkSelect', item, { kind: 'select', item }) }],
    })}${view.dropDownList('ddlColor', {
      field: 'color',
      items: [
        { value: 'red', text: 'Red' },
        { value: 'green', text: 'Green' },
      ],
      autoPostBack: { kind: 'color' },
    })}${view.textBox('txtNote', { field: 'note', maxLength: 20 })}${view.button('btnSave', 'Save', { kind: 'save' })}<p id="out">selected=${
      state.data.selected ?? '-'
    };handled=${state.data.handled.join(',')};color=${state.fields.color ?? ''};note=${state.fields.note ?? ''}</p>`,
  }),
});

let fixture: RuntimeFixture | undefined;

afterEach(() => {
  fixture?.close();
  fixture = undefined;
});

async function setup(options: { ttlMs?: number; capacity?: number } = {}): Promise<RuntimeFixture> {
  fixture = await createRuntimeFixture(options, handlePostBack);
  return fixture;
}

function open(current: RuntimeFixture, query = ''): RenderedDocument {
  return htmlDocument(toyPage.get(current.context('Members.aspx', query)));
}

function post(current: RuntimeFixture, document: RenderedDocument, options: PostBackOptions = {}): PageResponse {
  return current.post('Members.aspx', document.root, options);
}

function output(document: RenderedDocument): string {
  return textOf(document.root, '#out');
}

describe('page runtime', () => {
  it('names controls after the Web Forms control tree', async () => {
    const document = open(await setup());
    expect(document.status).toBe(200);
    expect(document.root.querySelectorAll('[name]').map((element) => element.getAttribute('name'))).toEqual([
      '__EVENTTARGET',
      '__EVENTARGUMENT',
      '__LASTFOCUS',
      '__VIEWSTATE',
      'ctl00$txtQuickSearch',
      'ctl00$btnQuickSearch',
      'ctl00$MainContent$ddlColor',
      'ctl00$MainContent$txtNote',
      'ctl00$MainContent$btnSave',
      '__VIEWSTATEGENERATOR',
      '__SCROLLPOSITIONY',
    ]);
    expect(postBackLinks(document.root)).toEqual([
      {
        id: 'ctl00_MainContent_gvItems_ctl02_lnkSelect',
        target: 'ctl00$MainContent$gvItems$ctl02$lnkSelect',
        argument: '',
        text: 'alpha',
      },
      {
        id: 'ctl00_MainContent_gvItems_ctl03_lnkSelect',
        target: 'ctl00$MainContent$gvItems$ctl03$lnkSelect',
        argument: '',
        text: 'bravo',
      },
      { id: null, target: 'ctl00$MainContent$gvItems', argument: 'Page$2', text: '2' },
      { id: null, target: 'ctl00$MainContent$gvItems', argument: 'Page$3', text: '3' },
    ]);
    expect(document.root.querySelector('#ctl00_MainContent_ddlColor')?.getAttribute('data-autopostback')).toBe('true');
    expect(hiddenValue(document.root, '__VIEWSTATE')).toMatch(/^[\w-]{32}$/u);
    expect(hiddenValue(document.root, '__VIEWSTATEGENERATOR')).toMatch(/^[0-9A-F]{8}$/u);
    expect(document.root.querySelector('form')?.getAttribute('action')).toBe('./Members.aspx');
  });

  it('loads posted fields and raises the posted submit button', async () => {
    const current = await setup();
    const result = htmlDocument(
      post(current, open(current), { button: 'ctl00$MainContent$btnSave', fields: { 'ctl00$MainContent$txtNote': 'hello' } }),
    );
    expect(output(result)).toBe('selected=-;handled=save;color=red;note=hello');
  });

  it('raises a posted submit button even when a stale __EVENTTARGET is present', async () => {
    const current = await setup();
    const result = htmlDocument(
      post(current, open(current), { target: 'ctl00$MainContent$gvItems$ctl02$lnkSelect', button: 'ctl00$MainContent$btnSave' }),
    );
    expect(output(result)).toBe('selected=-;handled=save;color=red;note=');
  });

  it('rejects posted text longer than the rendered maxlength', async () => {
    const current = await setup();
    const document = open(current);
    expect(document.root.querySelector('#ctl00_MainContent_txtNote')?.getAttribute('maxlength')).toBe('20');
    const tooLong = htmlDocument(post(current, document, { fields: { 'ctl00$MainContent$txtNote': 'x'.repeat(21) } }));
    expect(tooLong.status).toBe(400);
    expect(textOf(tooLong.root, 'h1')).toBe('Invalid postback or callback argument');
    const longest = htmlDocument(post(current, document, { fields: { 'ctl00$MainContent$txtNote': 'x'.repeat(20) } }));
    expect(output(longest)).toBe(`selected=-;handled=none;color=red;note=${'x'.repeat(20)}`);
  });

  it('serializes selects the way a browser does', () => {
    const form = (options: string) => parseDocument(200, `<form><select name="s">${options}</select></form>`).root;
    expect(postBackBody(form('<option value="a">A</option><option value="b" selected disabled>B</option>')).has('s')).toBe(false);
    expect(postBackBody(form('<option value="a" disabled>A</option><option value="b">B</option>')).get('s')).toBe('b');
    expect(postBackBody(form('<option value="a">A</option><option value="b" selected>B</option>')).get('s')).toBe('b');
  });

  it('raises an auto-postback dropdown through __EVENTTARGET', async () => {
    const current = await setup();
    const result = htmlDocument(
      post(current, open(current), {
        target: 'ctl00$MainContent$ddlColor',
        fields: { 'ctl00$MainContent$ddlColor': 'green' },
      }),
    );
    expect(output(result)).toBe('selected=-;handled=color;color=green;note=');
  });

  it('treats a postback without a target or button as no event', async () => {
    const current = await setup();
    const result = htmlDocument(post(current, open(current), { fields: { 'ctl00$MainContent$txtNote': 'typed' } }));
    expect(output(result)).toBe('selected=-;handled=none;color=red;note=typed');
  });

  it('rejects a dropdown value that the document did not offer', async () => {
    const current = await setup();
    const result = htmlDocument(post(current, open(current), { fields: { 'ctl00$MainContent$ddlColor': 'purple' } }));
    expect(result.status).toBe(400);
    expect(textOf(result.root, 'h1')).toBe('Invalid postback or callback argument');
    expect(result.root.querySelector('.message-links a')?.getAttribute('href')).toBe('Members.aspx');
  });

  it.each([
    ['an unrendered row', 'ctl00$MainContent$gvItems$ctl09$lnkSelect', ''],
    ['an unrendered page argument', 'ctl00$MainContent$gvItems', 'Page$9'],
    ['a button with an argument', 'ctl00$MainContent$btnSave', 'x'],
    ['a text box', 'ctl00$MainContent$txtNote', ''],
  ])('rejects %s as event target', async (_name, target, argument) => {
    const current = await setup();
    expect(htmlDocument(post(current, open(current), { target, argument })).status).toBe(400);
  });

  it('acts on the record rendered in the row, not the row position', async () => {
    const current = await setup();
    const first = open(current);
    const second = htmlDocument(post(current, first, { target: 'ctl00$MainContent$gvItems', argument: 'Page$2' }));
    const rowTarget = 'ctl00$MainContent$gvItems$ctl02$lnkSelect';
    expect(findLink(second.root, (link) => link.target === rowTarget, 'row link').text).toBe('charlie');
    expect(output(htmlDocument(post(current, first, { target: rowTarget })))).toBe('selected=alpha;handled=select;color=red;note=');
    expect(output(htmlDocument(post(current, second, { target: rowTarget })))).toBe(
      'selected=charlie;handled=page,select;color=red;note=',
    );
  });

  it('keeps older documents replayable after newer postbacks', async () => {
    const current = await setup();
    const first = open(current);
    const second = htmlDocument(post(current, first, { target: 'ctl00$MainContent$gvItems', argument: 'Page$2' }));
    htmlDocument(post(current, second, { target: 'ctl00$MainContent$gvItems', argument: 'Page$3' }));
    const replays = [1, 2].map(() =>
      htmlDocument(post(current, first, { target: 'ctl00$MainContent$gvItems', argument: 'Page$3' })),
    );
    expect(replays.map((document) => [document.status, output(document)])).toEqual([
      [200, 'selected=-;handled=page;color=red;note='],
      [200, 'selected=-;handled=page;color=red;note='],
    ]);
    expect(new Set(replays.map((document) => hiddenValue(document.root, '__VIEWSTATE'))).size).toBe(2);
  });

  it('expires idle page state with a link that reloads the same URL', async () => {
    const current = await setup({ ttlMs: 1_000 });
    const document = open(current, 'q=smith&page=2');
    current.advance(1_001);
    const result = htmlDocument(current.post('Members.aspx', document.root, {}, 'q=smith&page=2'));
    expect(result.status).toBe(410);
    expect(result.body).toContain('the changes you submitted were not saved');
    expect(result.root.querySelector('.message-links a')?.getAttribute('href')).toBe('Members.aspx?q=smith&page=2');
  });

  it('evicts the least recently used page state beyond the history limit', async () => {
    const current = await setup({ capacity: 2 });
    const [first, , third] = [open(current), open(current), open(current)];
    expect(htmlDocument(post(current, first)).status).toBe(410);
    expect(htmlDocument(post(current, third)).status).toBe(200);
  });

  it('rejects a token presented at another page URL', async () => {
    const current = await setup();
    const document = open(current);
    expect(htmlDocument(current.post('Accounts.aspx', document.root)).status).toBe(410);
  });

  it('rejects a mismatched view state generator', async () => {
    const current = await setup();
    const result = post(current, open(current), { fields: { __VIEWSTATEGENERATOR: 'DEADBEEF' } });
    expect(htmlDocument(result).status).toBe(400);
  });

  it('redirects the master quick search to the member list', async () => {
    const current = await setup();
    const result = post(current, open(current), {
      button: 'ctl00$btnQuickSearch',
      fields: { ctl00$txtQuickSearch: ' Vance ' },
    });
    expect(result).toEqual({ kind: 'redirect', location: 'Members.aspx?q=Vance', control: 'ctl00$btnQuickSearch' });
  });

  it('echoes scroll position and focus into the replacement document', async () => {
    const current = await setup();
    const result = htmlDocument(
      post(current, open(current), {
        target: 'ctl00$MainContent$ddlColor',
        fields: { __SCROLLPOSITIONY: '420', __LASTFOCUS: 'ctl00_MainContent_ddlColor' },
      }),
    );
    expect([hiddenValue(result.root, '__SCROLLPOSITIONY'), hiddenValue(result.root, '__LASTFOCUS')]).toEqual([
      '420',
      'ctl00_MainContent_ddlColor',
    ]);
  });
});
