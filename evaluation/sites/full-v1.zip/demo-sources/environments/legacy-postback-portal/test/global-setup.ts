import type { TestProject } from 'vitest/node';

import { ensureTemplate } from './template.js';

/** Seeds the shared test template once before any worker file loads it. */
export default async function setup(_project: TestProject): Promise<void> {
  await ensureTemplate();
}
