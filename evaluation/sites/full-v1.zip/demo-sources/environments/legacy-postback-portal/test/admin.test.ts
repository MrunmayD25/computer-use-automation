import { request } from 'node:http';

import { afterEach, describe, expect, it } from 'vitest';

import {
  closePortals,
  controlName,
  httpGet,
  open,
  parseCreated,
  required,
  startPortal,
  submit,
  type Portal,
} from './conftest.js';

afterEach(closePortals);

/** Raw HTTP, because fetch forbids overriding the Host header. */
function rawCreate(portal: Portal, headers: Readonly<Record<string, string>>): Promise<{ status: number; body: unknown }> {
  const admin = new URL(portal.handle.origins.admin);
  const payload = JSON.stringify({ seed: 3 });
  return new Promise((resolve, reject) => {
    const outgoing = request(
      {
        host: admin.hostname,
        port: admin.port,
        path: '/instances',
        method: 'POST',
        headers: { authorization: `Bearer ${portal.adminToken}`, 'content-type': 'application/json', ...headers },
      },
      (response) => {
        let text = '';
        response.setEncoding('utf8');
        response.on('data', (chunk: string) => (text += chunk));
        response.on('end', () => resolve({ status: response.statusCode ?? 0, body: JSON.parse(text) }));
      },
    );
    outgoing.on('error', reject);
    outgoing.end(payload);
  });
}

describe('environment administration', () => {
  it('requires the bearer token, rejects browser-origin requests, and validates bodies', async () => {
    const portal = await startPortal();
    const wrongToken = await portal.admin('POST', '/instances', { seed: 3 }, { authorization: 'Bearer not-the-admin-token' });
    const fromBrowser = await portal.admin('POST', '/instances', { seed: 3 }, { 'sec-fetch-site': 'same-site' });
    const badSeed = await portal.admin('POST', '/instances', { seed: -1 });
    const unknownInstance = await portal.admin('GET', '/instances/unknown/state');

    expect([wrongToken.status, fromBrowser.status, badSeed.status, unknownInstance.status]).toEqual([401, 403, 400, 404]);
    expect(wrongToken.body).toEqual({ error: 'Unauthorized' });
    expect(fromBrowser.body).toEqual({ error: 'Browser requests are forbidden' });
    expect(wrongToken.headers.get('cache-control')).toBe('no-store');
  });

  it('rejects an Origin-only browser request and a non-loopback Host header', async () => {
    const portal = await startPortal();
    expect(await rawCreate(portal, { origin: 'http://127.0.0.1:4320' })).toEqual({
      status: 403,
      body: { error: 'Browser requests are forbidden' },
    });
    expect(await rawCreate(portal, { host: `branchnet.example:${new URL(portal.handle.origins.admin).port}` })).toEqual({
      status: 403,
      body: { error: 'Invalid Host header' },
    });
    expect((await rawCreate(portal, {})).status).toBe(201);
  });

  it('creates a session on an isolated dataset and exports its state as a download', async () => {
    const portal = await startPortal();
    const created = await portal.createInstance({ seed: 11 });
    expect(created.entryUrl).toMatch(/^http:\/\/127\.0\.0\.1:\d+\/\(S\([a-z0-5]{24}\)\)\/Default\.aspx$/u);
    expect((await open(created.entryUrl)).status).toBe(200);

    const exported = await portal.admin('GET', `/instances/${created.instanceId}/export`);
    const state = await portal.state(created.instanceId);
    expect(exported.status).toBe(200);
    expect(exported.headers.get('content-disposition')).toBe(`attachment; filename="branchnet-${created.instanceId}.json"`);
    expect(exported.body).toEqual(state);
    expect(state.datasetId).toBe(created.datasetId);
  });

  it('refuses sessions beyond capacity with 429', async () => {
    const portal = await startPortal({ maxSessions: 1 });
    await portal.createInstance({ seed: 1 });
    const refused = await portal.admin('POST', '/instances', { seed: 2 });
    expect(refused.status).toBe(429);
    expect(refused.body).toEqual({ error: 'Too many active sessions.' });
  });

  it('reset and disposal replace only one session and preserve peer data', async () => {
    const portal = await startPortal();
    const first = await portal.createInstance({ seed: 11 });
    const peer = await portal.createInstance({ datasetId: first.datasetId });
    expect(peer.datasetId).toBe(first.datasetId);
    expect(peer.instanceId).not.toBe(first.instanceId);

    const initial = await portal.state(first.instanceId);
    const member = required(initial.members.items[0], 'first member');
    const notes = await open(new URL(`MemberDetail.aspx?member=${String(member.memberNumber)}`, first.entryUrl));
    const saved = await submit(notes, {
      button: controlName(notes.root, 'btnAddNote'),
      fields: { [controlName(notes.root, 'txtNote')]: 'Peer-visible note' },
    });
    expect(saved.status).toBe(200);
    const written = await portal.state(peer.instanceId);
    expect(written.operations).toBe(initial.operations + 1);
    const peerView = await open(new URL(`MemberDetail.aspx?member=${String(member.memberNumber)}`, peer.entryUrl));
    expect(peerView.body).toContain('Peer-visible note');

    const reset = await portal.admin('POST', `/instances/${first.instanceId}/reset`);
    expect(reset.status).toBe(201);
    const replaced = parseCreated(reset.body);
    expect(replaced.instanceId).not.toBe(first.instanceId);
    expect(replaced.datasetId).not.toBe(first.datasetId);
    expect(replaced.entryUrl).not.toBe(first.entryUrl);
    expect((await httpGet(first.entryUrl)).status).toBe(404);
    const fresh = await portal.state(replaced.instanceId);
    expect(fresh.operations).toBe(initial.operations);
    const freshView = await open(new URL(`MemberDetail.aspx?member=${String(member.memberNumber)}`, replaced.entryUrl));
    expect(freshView.body).not.toContain('Peer-visible note');
    expect((await portal.state(peer.instanceId)).operations).toBe(initial.operations + 1);

    expect((await portal.admin('DELETE', `/instances/${peer.instanceId}`)).status).toBe(204);
    expect((await portal.admin('GET', `/instances/${peer.instanceId}/state`)).status).toBe(404);
    expect((await httpGet(peer.entryUrl)).status).toBe(404);
    const reattached = await portal.createInstance({ datasetId: first.datasetId });
    const preserved = await portal.state(reattached.instanceId);
    expect(preserved.operations).toBe(initial.operations + 1);
    const preservedView = await open(new URL(`MemberDetail.aspx?member=${String(member.memberNumber)}`, reattached.entryUrl));
    expect(preservedView.body).toContain('Peer-visible note');
  });
});
