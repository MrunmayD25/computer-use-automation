import { describe, expect, it } from 'vitest';

import { FormStateHistory } from '../src/form-state.js';

function clock(start = 1_000_000): { now: () => number; advance: (ms: number) => void } {
  let current = start;
  return { now: () => current, advance: (ms) => (current += ms) };
}

describe('FormStateHistory', () => {
  it('issues opaque 32-character tokens that can be replayed', () => {
    const time = clock();
    const history = new FormStateHistory<string>({ ttlMs: 1_000, capacity: 5, now: time.now });
    const token = history.save('first');
    expect(token).toMatch(/^[A-Za-z0-9_-]{32}$/u);
    expect(history.lookup(token)).toBe('first');
    expect(history.lookup(token)).toBe('first');
    expect(history.lookup('unknown')).toBeUndefined();
  });

  it('expires state that stays idle longer than the TTL', () => {
    const time = clock();
    const history = new FormStateHistory<string>({ ttlMs: 1_000, capacity: 5, now: time.now });
    const token = history.save('page');
    time.advance(1_000);
    expect(history.lookup(token)).toBe('page');
    time.advance(1_000);
    expect(history.lookup(token)).toBe('page');
    time.advance(1_001);
    expect(history.lookup(token)).toBeUndefined();
  });

  it('evicts the least recently used state beyond its capacity', () => {
    const time = clock();
    const history = new FormStateHistory<string>({ ttlMs: 60_000, capacity: 3, now: time.now });
    const a = history.save('a');
    const b = history.save('b');
    const c = history.save('c');
    expect(history.lookup(a)).toBe('a');
    const d = history.save('d');
    expect([a, b, c, d].map((token) => history.lookup(token) ?? null)).toEqual(['a', null, 'c', 'd']);
    expect(history.size).toBe(3);
  });

  it('rejects invalid limits', () => {
    expect(() => new FormStateHistory({ ttlMs: 0, capacity: 1, now: Date.now })).toThrow(
      'Form state TTL must be a positive integer number of milliseconds.',
    );
    expect(() => new FormStateHistory({ ttlMs: 1, capacity: 0, now: Date.now })).toThrow(
      'Form state history must retain at least one page state.',
    );
  });
});
