import { describe, expect, it } from 'vitest';

import { formatAmount, formatMoney, parseMoney, parseSignedMoney } from '../src/money.js';

describe('parseMoney', () => {
  it.each([
    ['1,234.56', 123_456],
    ['12', 1_200],
    ['0.5', 50],
    ['0.01', 1],
    ['$10.00', 1_000],
    [' 12.3 ', 1_230],
    ['999999999999.99', 99_999_999_999_999],
    ['1,000,000', 100_000_000],
  ])('parses %j as %i minor units at exponent 2', (input, expected) => {
    expect(parseMoney(input, 2)).toBe(expected);
  });

  it('respects a zero-exponent currency', () => {
    expect(parseMoney('1,000', 0)).toBe(1_000);
    expect(parseMoney('12.5', 0)).toBeUndefined();
  });

  it.each(['', '0', '0.00', '-5', '1,23', '12.345', '1.2.3', 'abc', '1e3', '1234567890123', '9,999,999,999,999'])(
    'rejects %j',
    (input) => {
      expect(parseMoney(input, 2)).toBeUndefined();
    },
  );
});

describe('parseSignedMoney', () => {
  it.each([
    ['12.34', 1_234],
    ['-5', -500],
    ['-0.05', -5],
  ])('parses signed %j', (input, expected) => {
    expect(parseSignedMoney(input, 2)).toBe(expected);
  });

  it('rejects zero', () => {
    expect(parseSignedMoney('0', 2)).toBeUndefined();
  });
});

describe('formatMoney', () => {
  it.each([
    [123_456, 2, 'USD', '1,234.56 USD'],
    [0, 2, 'USD', '0.00 USD'],
    [-5, 2, 'USD', '-0.05 USD'],
    [100_000_000, 2, 'USD', '1,000,000.00 USD'],
    [81_240, 0, 'JPY', '81,240 JPY'],
    [12_345, 3, 'KWD', '12.345 KWD'],
  ])('formats %i at exponent %i as %s', (minor, exponent, currency, expected) => {
    expect(formatMoney(minor, exponent, currency)).toBe(expected);
  });
});

describe('formatAmount', () => {
  it('formats with the currency info exponent and code', () => {
    expect(formatAmount(123_456, { code: 'USD', exponent: 2, name: 'US dollar' })).toBe('1,234.56 USD');
    expect(formatAmount(1_234_000, { code: 'JPY', exponent: 0, name: 'yen' })).toBe('1,234,000 JPY');
  });
});
