import { describe, expect, it } from 'vitest';

import { html, raw } from '../src/html.js';

describe('html template', () => {
  it('escapes every interpolated string', () => {
    const name = `<script>alert("x")</script>&'`;
    expect(html`<p>${name}</p>`.value).toBe(
      '<p>&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;&amp;&#39;</p>',
    );
  });

  it('inserts safe fragments, arrays, and numbers without re-escaping', () => {
    const items = ['a<b', 'c'].map((item) => html`<li>${item}</li>`);
    expect(html`<ul>${items}</ul>${raw('<br>')}${42}`.value).toBe(
      '<ul><li>a&lt;b</li><li>c</li></ul><br>42',
    );
  });

  it('renders nothing for absent conditional fragments', () => {
    const missing: string | undefined = undefined;
    expect(html`[${null}${missing}${false}]`.value).toBe('[]');
  });
});
