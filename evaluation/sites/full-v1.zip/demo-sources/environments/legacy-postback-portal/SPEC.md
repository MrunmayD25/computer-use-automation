# Legacy postback portal specification

## Identity and scope

BranchNet is the branch administration intranet of Northstar Mutual, the fictional institution also served by Meridian Core. It is modeled on ASP.NET Web Forms applications from the 2005 to 2012 era and on JSP portals built the same way. Every page is one server form. Every interaction that changes what the page shows submits that form and replaces the whole document.

This is application #2 of the environment catalog in `../AGENTS.md` (historical material omitted from this bundle). It owns the folder `environments/legacy-postback-portal/`. It supports the common capability floor plus maintenance requests, request drafts, and printable request details.

The application has no benchmark goals, prescribed tasks, target records, expected answers, graders, or agent loops. Functional tests exercise ordinary operations.

The interface uses the classic ASP.NET "Professional" palette. Grid headers are `#5d7b9d` with white text. Alternating rows use `#f7f6f3` and white, selected or edited rows use `#e2ded6`, and the pager uses `#284775`. The banner is navy `#1c3f6e`, and text is 11px Verdana or Tahoma. The layout is desktop-oriented. All records are synthetic, and money is USD with integer minor units.

## Shared data

Canonical members, accounts, notes, ledger entries, activity, and maintenance requests belong to `@computer-use/financial-database`. The portal opens the canonical default database path and the configured financial binding for a normal launch, so it shares records with Meridian Core. It never keeps an authoritative copy of business records. Every GET and postback reads current records.

Maintenance requests are shared business entities. A saved draft request is a persisted record with status `draft`. It survives restarts and is visible to other applications. Unsaved field values, page state, form tokens, grid page indexes, expanded rows, and tab selection are presentation state. They live in the portal's UI session and expire.

Every mutation goes through the shared service `executeCommand` after `reviewCommand`, with the record version or fingerprint captured when the user loaded the values being edited or reviewed, and an idempotency key derived from the form instance. The shared package owns maintenance categories, reasons, account eligibility, and submission rules.

## Modules

| Module | Pages | Operations |
| --- | --- | --- |
| Home | `Default.aspx` | Draft and submitted request counts, recent activity, links to every module. |
| Members | `Members.aspx`, `MemberNew.aspx`, `MemberDetail.aspx` | Search by name or member number. Sortable, paginated grid with expandable rows and CSV export. Create a member. View identity and contact information. Edit contact information in place. Add and view notes. Per-member accounts grid with editable rows. Per-member maintenance requests. |
| Accounts | `Accounts.aspx`, `AccountOpen.aspx`, `AccountDetail.aspx` | Search and filter by status and product with postback dropdowns. Paginated grid with expandable rows. Open an account through dependent member and product controls. Inspect balances and status. Edit nickname and statement delivery. Close an eligible zero-balance account after review, or see the business reason closure is unavailable. |
| Transactions | `Transactions.aspx`, `TransactionReceipt.aspx`, history on `AccountDetail.aspx` | Deposit, withdraw, and transfer through dependent type, member, and account controls. Every movement has a server-validated review step. Receipts are durable pages derived from ledger entries. History is paginated with expandable rows. |
| Statements | `Statements.aspx` | Choose an account and a statement period through dependent dropdowns. View opening and closing balances, credits, debits, and entries. Export the period as CSV. Link to the owning member and account. |
| Activity | `Activity.aspx` | Committed changes in a paginated grid, filtered by action type with a postback dropdown and by date with a postback calendar control. Each row links to its affected record. CSV export. |
| Maintenance requests | `Requests.aspx`, `RequestEdit.aspx`, `RequestDetail.aspx`, `RequestPrint.aspx` | Queue filtered by status and member, with expandable rows. Create a request. Save and edit drafts. Submit a draft after review. Cancel a draft or submitted request with a reason. Show status, dates, and the request's activity. Open a printable copy in a separate window. |

Every page carries the master banner and menu, a quick member search, and breadcrumb links. Lists accept their filter, sort, and page state as GET query parameters, so return links restore the list the user came from. Record pages accept a business identifier: `member=NM…`, `account=…`, `entry=…`, or `request=MR…`. An unknown identifier renders a not-found message with links back to its list.

Every advertised operation works. When an operation is unavailable for a record, the page shows the business reason, such as a nonzero balance or a request that is no longer a draft. Lists show an explicit empty state. Every edit and review has a Cancel control that discards unsaved values and returns to the read-only view.

## Web Forms mechanisms

**Cookieless sessions.** URLs have the form `/(S(<session>))/Members.aspx`. The session segment is an unguessable capability that attaches the UI session to a dataset. The root URL redirects to the demonstration session. An unknown session renders a recoverable message with a link to start a new one.

**Single server form.** Each page renders one `<form method="post">` whose action is the page's own URL and query. Hidden fields are `__EVENTTARGET`, `__EVENTARGUMENT`, `__VIEWSTATE`, `__VIEWSTATEGENERATOR`, `__SCROLLPOSITIONY`, and `__LASTFOCUS`. `WebForms.js` defines `__doPostBack(target, argument)`. It routes clicks on `javascript:__doPostBack(…)` links and changes on auto-postback dropdowns, and restores scroll and focus after a postback. Buttons are ordinary submit inputs. Panels declare a default button so Enter triggers the intended action.

**Generated control names.** Names follow the Web Forms control tree, such as `ctl00$MainContent$gvMembers$ctl04$lnkSelect`. The matching IDs replace `$` with `_`. Grid row names derive from the row's position on the rendered page, so the same name refers to different records on different pages or sorts.

**Server-validated form state.** `__VIEWSTATE` is an opaque token referring to server-side page state. Page state holds the page, its query, logical field values, view data such as page index, sort, expanded row, edited row, and active tab, and the control registry of the rendered document. It also holds the form instance key and the dataset revision the current edit or review started from. A postback is accepted only when the token exists, belongs to the URL's session and page, and has not expired.

**Event validation.** The server resolves `__EVENTTARGET` and posted submit buttons only through the stored control registry. Grid row controls carry business identity in the registry, so a postback acts on the record the user saw even after another application inserts rows. A dropdown value outside the rendered options, or an unregistered event target, is rejected with an "Invalid postback" page that offers a reload.

**Expiry.** Page state expires after an idle timeout, 20 minutes by default. Each session also retains a bounded history of page states, 200 by default, and evicts the least recently used. Restarting the process discards all sessions. A postback with expired state renders HTTP 410 with a message explaining that the changes were not saved, and a control that reloads the same URL. `--form-state-ttl` and `--form-state-history` configure these limits.

**Full-document postbacks.** Paging, sorting, filtering, expanding rows, tab changes, dropdown changes, beginning an edit, validation failures, and review panels are rendered directly in the POST response. There is no client-side rendering, `fetch`, or loading overlay. The footer shows the render time and a per-process request number, so each replacement is visible.

**Dependent controls.** Auto-postback dropdowns rebuild the controls that depend on them.

- On `Transactions.aspx`, the transaction type controls whether destination controls appear. The member lookup fills the source account dropdown, and the transfer destination member fills the destination account dropdown without the source account.
- On `RequestEdit.aspx`, the category determines the reason dropdown, whether the account dropdown appears, and which accounts are eligible.
- On `Statements.aspx`, the account determines the available statement periods.
- On `AccountOpen.aspx`, the member lookup fills the member dropdown, and the selected member shows existing accounts.

**Grids.** Grids use numeric pagers (`Page$N`), sortable headers (`Sort$Field`), and expand controls. Editable rows show Edit, Update, and Cancel. After Update commits, the page redirects and the grid is rebuilt with regenerated row controls.

**Validation summaries.** Server validation is authoritative. Field validators render a red `*` beside the field. The messages appear only in a validation summary box above the form, and each message names its field label.

**Back, refresh, and several windows.** HTML responses use `Cache-Control: private, no-cache`, so Back restores the prior document from the browser cache without resubmitting. That document's page state remains valid within the history limit. Refreshing a postback result resubmits the same token and event, which recomputes the same view from the stored state against current data. Each window has its own page state, so several open forms do not overwrite each other's view state.

**Commits.** A committing event runs one shared command. Its idempotency key is the page's form instance key joined with the event name, and its expected revision is the page's captured revision. On success the response is a 303 redirect to a GET result page, following Post/Redirect/Get. That makes refreshing the result harmless and gives it a durable URL.

- A duplicate submission of the same form and event, from a double click or from resubmitting an older document, returns the stored receipt and the same result page.
- Reusing a committed form with different values renders a message that the form was already used, with a link to the current page.
- A stale revision re-renders the form with the user's entries preserved, the current saved values shown for comparison, and a new captured revision. The user can then review and save again.

## Maintenance request rules

These rules are owned by the shared package.

| Category | Account | Eligible accounts | Reasons |
| --- | --- | --- | --- |
| Address change | Not allowed | None | Relocation, mailing address only, correction of record |
| Statement reissue | Required | Any account of the member | Statement not received, duplicate copy, statement correction |
| Fee review | Required | Open accounts of the member | Overdraft fee, monthly maintenance fee, other fee |
| Stop payment | Required | Open checking accounts of the member | Lost check, disputed payee, duplicate payment |
| General inquiry | Optional | Any account of the member | Service question, product question, other |

- A draft requires a member, a category, and a subject of 1 to 120 characters. Details may be empty, up to 2,000 characters. The reason and account may be unset. A set reason must belong to the category. A set account must belong to the member and be allowed by the category.
- Only drafts can be edited or submitted. Submission requires a reason and non-empty details. It also requires an account when the category requires one, and that account must be eligible at the time of submission.
- Drafts and submitted requests can be cancelled with a reason of 1 to 500 characters. Cancelled requests are final.
- Request numbers such as `MR700000` are allocated by the shared transaction. Every change records an activity event whose resource is the request.

## Environment administration

A separate loopback listener, port 4321 by default, accepts bearer-authenticated JSON requests. It rejects browser-origin requests. The token is written to `.runtime/admin.token` with owner-only permissions.

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/instances` | `{seed}` creates an isolated dataset and UI session. `{datasetId}` attaches a UI session to an existing dataset. |
| GET | `/instances/:id/state` | Current records and revision. |
| GET | `/instances/:id/export` | Export the same state as a JSON download. |
| POST | `/instances/:id/reset` | Replace only this session with a fresh seeded dataset and new session URL. |
| DELETE | `/instances/:id` | Dispose of the UI session and preserve its dataset. |

The application listens on port 4320 by default. Ports 4320 and 4321 do not collide with Meridian Core's 4310 to 4312. All ports are configurable, and `0` selects ephemeral ports for tests.

## Completion criteria

- Every module and operation above works through visible controls in Chromium.
- Browser checks observe real document replacement on postbacks. They verify dependent controls, grid paging and expansion, row editing with regenerated names, validation summaries, Back and refresh, two windows editing one record with the stale one rejected, expired state recovery, CSV downloads, and the print window.
- Domain tests cover the maintenance rules and statement periods. HTTP tests cover token validation, event validation, expiry, idempotent resubmission, and stale versions. All tests use temporary databases and a seeded financial schema.
- Meridian Core and BranchNet run against one temporary database and the configured financial binding. A change made through each UI appears in the other UI.
- An isolated dataset stays independent of the shared one. Session reset and disposal preserve peer data.
- Typechecking, lint, unit and HTTP tests, production builds, and browser checks pass for both applications.

