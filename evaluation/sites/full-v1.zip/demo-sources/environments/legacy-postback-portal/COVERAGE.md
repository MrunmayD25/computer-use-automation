# legacy-postback-portal coverage

## Full-v1 qualification

Release verdict: FULL-V1 COMPLETE

- Source commit: `d84cc14bcb24b62f84db5897ec80d1f0bf0c6a1b`
- Evidence run: `full-v1-d84cc14-20260921-handoff`
- Visible task options: 102/102
- Workflow path and recovery branches: 30/30
- Family mechanism: server-rendered-postback
- Shared-world checks: 3/3
- Durable records: `environments/legacy-postback-portal/verification/evidence/full-v1-d84cc14-20260921-handoff/`

The option-level matrix and exact commands, tests, visible entries/results, business effects, artifact paths, and recovery observations are in `capability-manifest.json` and the evidence directory.

## Reproduce the release audit

Run `npm --prefix environments run audit:full-v1` from the repository root. The audit fails closed on missing, stale, ignored, untracked, or wrong-application artifacts.
