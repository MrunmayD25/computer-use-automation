import { fileURLToPath } from 'node:url';

import { documentContent } from '@computer-use/financial-database/services';
import express, { type Express, type NextFunction, type Request, type Response } from 'express';

import { resolveOperator, type PortalServices } from './financial.js';
import { renderMessagePage, type Link } from './layout.js';
import { isPageName } from './page-names.js';
import { PAGES } from './pages/index.js';
import { createPageContext, handlePostBack, PostedForm, type PageResponse } from './runtime.js';
import { SESSION_PATH_PATTERN, type SessionStore, type UiSession } from './sessions.js';

export interface PortalAppOptions {
  store: SessionStore;
  services: PortalServices;
  /** Entry path of the demonstration session, or null when the demo is disabled. */
  demoEntryPath: () => string | null;
  now: () => number;
  verbose: boolean;
}

const contentSecurityPolicy =
  "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; form-action 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'";

function contentDisposition(filename: string): string {
  return `attachment; filename="${filename.replace(/[^\w.-]/gu, '_')}"`;
}

interface Download {
  readonly mediaType: string;
  readonly fileName: string;
  readonly bytes: Uint8Array;
  readonly digest: string;
}

/** Read-only byte endpoints inside the session capability path, like a legacy .ashx handler. */
function sessionDownload(services: PortalServices, session: UiSession, name: string, query: URLSearchParams): Download | undefined {
  const operator = resolveOperator(services.store, session.binding, session.actorNumber);
  if (operator === undefined) return undefined;
  const reader = { institutionId: session.binding.institutionId, actorId: operator.actorId };
  if (name === 'DocumentContent.ashx') {
    const version = query.get('version') ?? '';
    const content = services.store.read((database) => documentContent(database, session.binding.datasetId, version, reader));
    if (content === undefined) return undefined;
    return { mediaType: content.mediaType, fileName: content.displayName, bytes: content.bytes, digest: content.digest };
  }
  return undefined;
}

export function createPortalApp(options: PortalAppOptions): Express {
  const app = express();
  app.disable('x-powered-by');
  app.set('etag', false);
  let requestCounter = 1000;

  function messagePage(response: Response, status: number, title: string, paragraphs: string[], links: Link[]): void {
    response
      .status(status)
      .type('html')
      .send(
        renderMessagePage({
          title,
          paragraphs,
          links: links.map((link) => ({ href: link.href, label: link.label })),
          renderedAt: new Date(options.now()),
          requestNumber: ++requestCounter,
        }),
      );
  }

  app.use((_request, response, next) => {
    // no-store would make Back fail with ERR_CACHE_MISS on postback results; no-cache restores them.
    response.setHeader('cache-control', 'private, no-cache');
    response.setHeader('x-content-type-options', 'nosniff');
    response.setHeader('referrer-policy', 'same-origin');
    response.setHeader('content-security-policy', contentSecurityPolicy);
    next();
  });

  app.use(
    '/assets',
    express.static(fileURLToPath(new URL('../public/', import.meta.url)), { fallthrough: false, maxAge: 0 }),
  );

  app.get('/favicon.ico', (_request, response) => {
    response.status(204).end();
  });

  app.get('/', (_request, response) => {
    const entry = options.demoEntryPath();
    if (entry === null) {
      messagePage(response, 404, 'No demonstration session', ['This BranchNet process was started without a demonstration session. Create a session through the administration listener.'], []);
      return;
    }
    response.redirect(302, entry);
  });

  app.use(express.text({ type: 'application/x-www-form-urlencoded', limit: '64kb' }));

  app.use((request, response, next) => {
    const match = SESSION_PATH_PATTERN.exec(request.path);
    if (match === null) {
      next();
      return;
    }
    const [, capability = '', pageName = ''] = match;
    const session = options.store.byCapability(capability);
    if (session === undefined) {
      messagePage(
        response,
        404,
        'Session not found',
        [
          'This BranchNet session link is unknown or has ended. Sessions end when the application restarts or when an administrator resets or disposes of them.',
          'Saved records are not affected.',
        ],
        [{ href: '/', label: 'Start a new session' }],
      );
      return;
    }
    const query = new URL(request.originalUrl, 'http://portal.invalid').searchParams;
    if (pageName.endsWith('.ashx')) {
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        response.setHeader('allow', 'GET, HEAD');
        messagePage(response, 405, 'Method not allowed', ['Use the links on the page.'], [{ href: 'Default.aspx', label: 'Home' }]);
        return;
      }
      const download = sessionDownload(options.services, session, pageName, query);
      if (download === undefined) {
        messagePage(response, 404, 'Not found', ['The requested resource does not exist or is not available to this operator.'], [{ href: 'Default.aspx', label: 'Home' }]);
        return;
      }
      response.setHeader('content-type', download.mediaType);
      response.setHeader('content-disposition', contentDisposition(download.fileName));
      response.setHeader('x-document-digest', download.digest);
      response.send(Buffer.from(download.bytes));
      return;
    }
    if (!isPageName(pageName)) {
      messagePage(response, 404, 'Page not found', [`The page ${pageName} does not exist.`], [{ href: 'Default.aspx', label: 'Home' }]);
      return;
    }
    if (request.method !== 'GET' && request.method !== 'HEAD' && request.method !== 'POST') {
      response.setHeader('allow', 'GET, HEAD, POST');
      messagePage(response, 405, 'Method not allowed', ['Use the links and buttons on the page.'], [{ href: 'Default.aspx', label: 'Home' }]);
      return;
    }
    let ctx;
    try {
      ctx = createPageContext({
        services: options.services,
        session,
        page: pageName,
        query,
        requestNumber: ++requestCounter,
        now: new Date(options.now()),
      });
    } catch (error) {
      messagePage(response, 500, 'Request failed', [error instanceof Error ? error.message : 'The server could not complete the request.'], [{ href: '/', label: 'BranchNet home' }]);
      return;
    }
    let result: PageResponse;
    if (request.method === 'POST') {
      const body: unknown = request.body;
      const form = PostedForm.parse(typeof body === 'string' ? body : '');
      if (form === undefined) {
        messagePage(response, 400, 'Invalid postback or callback argument', ['The submitted form repeated a field name. No changes were saved.'], [{ href: pageName, label: 'Reload this page' }]);
        return;
      }
      result = handlePostBack(ctx, form);
    } else {
      result = PAGES[pageName].get(ctx);
    }
    if (options.verbose) {
      const status = result.kind === 'html' ? String(result.status) : result.kind === 'redirect' ? '303' : '200';
      console.error(`${request.method} ${pageName} ${status}${result.control === null ? '' : ` ${result.control}`}`);
    }
    switch (result.kind) {
      case 'html':
        response.status(result.status).type('html').send(result.body);
        return;
      case 'redirect':
        response.redirect(303, result.location);
        return;
      case 'download':
        response.setHeader('content-type', result.contentType);
        response.setHeader('content-disposition', contentDisposition(result.filename));
        response.send(typeof result.body === 'string' ? result.body : Buffer.from(result.body));
        return;
    }
  });

  app.use((_request, response) => {
    messagePage(response, 404, 'Page not found', ['The requested address is not part of BranchNet.'], [{ href: '/', label: 'BranchNet home' }]);
  });

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    const status =
      typeof error === 'object' && error !== null && 'status' in error && typeof error.status === 'number'
        ? error.status
        : 500;
    if (status === 404) {
      messagePage(response, 404, 'Page not found', ['The requested address is not part of BranchNet.'], [{ href: '/', label: 'BranchNet home' }]);
      return;
    }
    if (status === 413) {
      messagePage(response, 413, 'Request too large', ['The submitted form exceeds the application limit. No changes were saved.'], [{ href: '/', label: 'BranchNet home' }]);
      return;
    }
    console.error('BranchNet request failed.', error);
    messagePage(response, 500, 'Request failed', ['The server could not complete the request. No further changes were made.'], [{ href: '/', label: 'BranchNet home' }]);
  });

  return app;
}
