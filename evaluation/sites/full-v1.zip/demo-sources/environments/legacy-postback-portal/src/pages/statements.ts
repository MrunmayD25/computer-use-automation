import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

import { renderCsv, searchAccounts, statementData, statementPeriods, type StatementData } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { csvDownload, definePage, redirectTo, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { accountSubject, cell } from '../ops/subjects.js';
import { day, detailsTable, HOME, money, notFound } from './shared.js';

interface StatementsData {
  readonly accountId: string;
  readonly accountNumber: string;
  readonly currency: string;
  readonly periods: readonly string[];
}

type StatementsEvent =
  | { readonly kind: 'locate' }
  | { readonly kind: 'open'; readonly period: string }
  | { readonly kind: 'csv'; readonly period: string }
  | { readonly kind: 'save'; readonly period: string };

function resolve(ctx: PageContext): StatementsData | undefined {
  const requested = ctx.query.get('account') ?? '';
  const fallback = requested === '' ? ctx.read((db, ds) => searchAccounts(db, ds, { query: '', status: 'open', limit: 1, offset: 0 }).items[0]?.accountNumber ?? '') : requested;
  const subject = accountSubject(ctx, fallback);
  if (subject.kind !== 'found') return undefined;
  const periods = ctx.read((db) => statementPeriods(db, ctx.binding.datasetId, subject.subject.id));
  return {
    accountId: subject.subject.id,
    accountNumber: cell(subject.subject.record?.account_number),
    currency: cell(subject.subject.record?.currency),
    periods,
  };
}

function statement(ctx: PageContext, accountId: string, period: string): StatementData | undefined {
  return ctx.read((db) => statementData(db, ctx.binding.datasetId, accountId, period));
}

export const statementsPage = definePage<StatementsData, StatementsEvent>({
  load(ctx): LoadOutcome<StatementsData> {
    const found = resolve(ctx);
    if (found === undefined) {
      return notFound('Choose an account', 'Statements are produced for one account at a time.', [
        { href: 'Accounts.aspx', label: 'Accounts' },
      ]);
    }
    return { kind: 'ready', data: found, fields: { account: ctx.query.get('account') ?? '' } };
  },
  handle(ctx, state, event): Outcome<StatementsData> {
    if (event === null || event.kind === 'locate') {
      return redirectTo(pageHref('Statements.aspx', { account: (state.fields.account ?? '').trim() }));
    }
    const data = statement(ctx, state.data.accountId, event.period);
    if (data === undefined) {
      state.errors.push({ field: null, message: `No statement exists for period ${event.period}.` });
      return rendered(state, 404);
    }
    const account = data.account;
    if (event.kind === 'csv') {
      let running = data.openingMinorUnits;
      const artifact = renderCsv({
        displayName: `${account.accountNumber}-${data.period}.csv`,
        columns: ['member_number', 'account_number', 'currency', 'effective_date', 'reference', 'description', 'signed_minor_units', 'running_balance_minor_units'],
        rows: data.entries.map((entry) => {
          running += entry.amountMinorUnits;
          return [account.memberNumber, account.accountNumber, account.currency, entry.date, entry.reference, entry.description, entry.amountMinorUnits, running];
        }),
      });
      return csvDownload(artifact.displayName, new TextDecoder().decode(artifact.bytes));
    }
    // save: write the CSV artifact to the approved export folder on the server.
    const artifact = renderCsv({
      displayName: `${account.accountNumber}-${data.period}.csv`,
      columns: ['member_number', 'account_number', 'currency', 'effective_date', 'reference', 'description', 'signed_minor_units'],
      rows: data.entries.map((entry) => [account.memberNumber, account.accountNumber, account.currency, entry.date, entry.reference, entry.description, entry.amountMinorUnits]),
    });
    mkdirSync(ctx.services.exportDirectory, { recursive: true });
    writeFileSync(join(ctx.services.exportDirectory, artifact.displayName), artifact.bytes);
    state.notice = `Saved ${artifact.displayName} to the export folder.`;
    return rendered(state);
  },
  render(ctx, state, view) {
    const data = state.data;
    const open = ctx.query.get('period');
    const selected = open === null ? undefined : statement(ctx, data.accountId, open);
    const periodRows = data.periods.map(
      (period) => html`<tr class="grid-row"><td><a href="${pageHref('Statements.aspx', { account: data.accountNumber, period })}">${period}</a></td><td>${view.button(`btnOpen${period.replace('-', '')}`, 'Open', { kind: 'open', period })}</td><td>${view.button(`btnCsv${period.replace('-', '')}`, 'CSV', { kind: 'csv', period })}</td><td>${view.button(`btnSave${period.replace('-', '')}`, 'Save to folder', { kind: 'save', period })}</td></tr>`,
    );
    return {
      title: `Statements · ${data.accountNumber}`,
      breadcrumbs: [HOME, { label: 'Accounts', href: 'Accounts.aspx' }, { label: data.accountNumber, href: pageHref('AccountDetail.aspx', { account: data.accountNumber }) }, { label: 'Statements', href: null }],
      body: html`
        <div class="locate-bar"><table class="form"><tr><th scope="row">${view.label('txtAccount', 'Account')}</th><td>${view.dropDownList('txtAccount', {
          field: 'account',
          items: ctx.read((db, ds) => searchAccounts(db, ds, { query: '', limit: 200, offset: 0 }).items.map((a) => ({ value: a.accountNumber, text: `${a.accountNumber} — ${a.ownerName} (${a.status})` }))),
          autoPostBack: { kind: 'locate' },
        })}</td></tr></table></div>
        <h2>Periods</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Period</th><th>View</th><th>Download</th><th>Export folder</th></tr>${periodRows}</table>
        ${selected === undefined ? '' : statementView(ctx, selected)}`,
    };
  },
});

function statementView(ctx: PageContext, statement: StatementData) {
  const account = statement.account;
  return html`<h2>Statement ${statement.period}</h2>
    ${detailsTable([
      ['Institution', statement.institutionName],
      ['Account', `${account.accountNumber} — ${account.ownerName}`],
      ['Period', `${statement.periodStart} to ${statement.periodEndExclusive}`],
      ['Opening', money(ctx, statement.openingMinorUnits, account.currency)],
      ['Credits', money(ctx, statement.creditsMinorUnits, account.currency)],
      ['Debits', money(ctx, statement.debitsMinorUnits, account.currency)],
      ['Closing', money(ctx, statement.closingMinorUnits, account.currency)],
    ])}
    <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Date</th><th>Reference</th><th>Description</th><th>Amount</th></tr>${statement.entries.map(
      (entry) => html`<tr class="grid-row"><td>${day(entry.date)}</td><td>${entry.reference}</td><td>${entry.description}</td><td class="amount">${money(ctx, entry.amountMinorUnits, account.currency)}</td></tr>`,
    )}</table>`;
}
