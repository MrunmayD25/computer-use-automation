import { maintenanceRequest, validateServiceCommand, type ServiceCommand } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, rejectionError, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { cell, memberSubject, pickers, requestSubject } from '../ops/subjects.js';
import { FieldCheck } from '../validation.js';
import { HOME, notFound, when } from './shared.js';

const REQUESTED_KINDS = ['contact.update', 'member.note.add', 'account.nickname.update', 'account.statement_delivery.update', 'account.close'] as const;
const CATEGORIES = ['address', 'contact', 'statement-delivery', 'account-maintenance', 'other'] as const;

interface EditData {
  /** Existing request id for amend, or null for a new draft. */
  readonly requestId: string | null;
  readonly requestNumber: string | null;
  readonly requestState: string | null;
  readonly memberNumber: string;
  readonly accountId: string;
  readonly category: string;
  readonly expectedUpdatedAt: string;
  readonly reason: string;
  /** Saved draft payload shown for comparison after edits. */
  readonly saved: string;
}

type EditEvent =
  | { readonly kind: 'refresh' }
  | { readonly kind: 'save' };

function loadExisting(ctx: PageContext): EditData | undefined {
  const reference = ctx.query.get('request');
  if (reference === null || reference === '') {
    return { requestId: null, requestNumber: null, requestState: null, memberNumber: ctx.query.get('member') ?? '', accountId: '', category: 'other', expectedUpdatedAt: '', reason: '', saved: '' };
  }
  const subject = requestSubject(ctx, reference);
  if (subject.kind !== 'found') return undefined;
  const detail = ctx.svc((db, context) => maintenanceRequest(db, context, subject.subject.id));
  if (detail.kind === 'rejected' || detail.value === undefined) return undefined;
  const request = detail.value;
  const draft = request.draft as Record<string, unknown>;
  const member = ctx.read((db) =>
    db.prepare('SELECT member_number FROM members WHERE dataset_id=? AND id=?').get(ctx.binding.datasetId, request.memberId) as { member_number: string } | undefined,
  );
  return {
    requestId: request.id,
    requestNumber: request.requestNumber,
    requestState: request.state,
    memberNumber: member?.member_number ?? '',
    accountId: request.accountId ?? '',
    category: request.category,
    expectedUpdatedAt: request.updatedAt,
    reason: request.reason ?? '',
    saved: JSON.stringify(draft, null, 2),
  };
}

function accountItems(ctx: PageContext, memberNumber: string): { value: string; text: string }[] {
  const member = memberSubject(ctx, memberNumber);
  if (member.kind !== 'found') return [];
  return pickers.memberAccounts(ctx, member.subject.id).map((a) => ({ value: a.value, text: a.label }));
}

function parseRequested(fields: Record<string, string>, check: FieldCheck): ServiceCommand | undefined {
  const kind = check.choice('requestedKind', 'Requested change', REQUESTED_KINDS);
  const raw = (fields.requestedJson ?? '').trim();
  let body: Record<string, unknown> = {};
  if (raw !== '') {
    try {
      const parsed: unknown = JSON.parse(raw);
      if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
        check.fail('requestedJson', 'The requested command must be a JSON object.');
        return undefined;
      }
      body = parsed as Record<string, unknown>;
    } catch {
      check.fail('requestedJson', 'The requested command is not valid JSON.');
      return undefined;
    }
  }
  if (kind === undefined) return undefined;
  const command = { kind, ...body } as unknown as ServiceCommand;
  const invalid = validateServiceCommand(command);
  if (invalid !== null) {
    check.fail('requestedJson', `Requested command is invalid: ${invalid.message}`);
    return undefined;
  }
  return command;
}

export const requestEditPage = definePage<EditData, EditEvent>({
  load(ctx): LoadOutcome<EditData> {
    const existing = loadExisting(ctx);
    if (existing === undefined) {
      return notFound('Request not found', 'No draft with that request number exists.', [
        { href: 'Requests.aspx', label: 'Back to requests' },
      ]);
    }
        const fields: Record<string, string> = {
      category: existing.category,
      requestedKind: 'contact.update',
      requestedJson: '',
      missingFields: '',
      evidence: '',
      note: '',
      member: existing.requestId === null ? (ctx.query.get('member') ?? '') : existing.memberNumber,
      account: existing.accountId,
      subject: '',
      reason: existing.reason,
    };
    if (existing.saved !== '') {
      try {
        const draft = JSON.parse(existing.saved) as Record<string, unknown>;
        fields.subject = typeof draft.subject === 'string' ? draft.subject : '';
        fields.requestedJson = JSON.stringify(draft.requestedCommand ?? {}, null, 2);
        fields.requestedKind = typeof (draft.requestedCommand as Record<string, unknown> | undefined)?.kind === 'string' ? String((draft.requestedCommand as Record<string, unknown>).kind) : 'contact.update';
        fields.missingFields = Array.isArray(draft.missingFields) ? (draft.missingFields as string[]).join('\n') : '';
        fields.evidence = Array.isArray(draft.evidenceDocumentVersionIds) ? (draft.evidenceDocumentVersionIds as string[]).join('\n') : '';
      } catch {
        // keep blank fields
      }
    }
    return { kind: 'ready', data: existing, fields };
  },

  handle(ctx, state, event): Outcome<EditData> {
    if (event === null || event.kind === 'refresh') return rendered(state);
    const check = new FieldCheck(state.fields);
    const memberNumber = check.text('member', 'Member', { required: true, max: 40 });
    const member = memberNumber === '' ? undefined : memberSubject(ctx, memberNumber);
    if (member !== undefined && member.kind !== 'found') {
      check.fail('member', `No member matches "${memberNumber}".`);
    }
    const accountField = check.optional('account', 'Account', { max: 80 });
    const accountId = member !== undefined && member.kind === 'found' ? (accountField ?? null) : null;
    const category = check.choice('category', 'Category', CATEGORIES);
    const subject = check.text('subject', 'Subject', { required: true, max: 200 });
    const reason = check.optional('reason', 'Reason', { max: 500 }) ?? '';
    const note = check.optional('note', 'Note', { max: 2000 }) ?? undefined;
    const missingFields = (state.fields.missingFields ?? '').split('\n').map((l) => l.trim()).filter((l) => l !== '');
    const evidence = (state.fields.evidence ?? '').split('\n').map((l) => l.trim()).filter((l) => l !== '');
    const requested = parseRequested(state.fields, check);
    if (!check.ok || member === undefined || member.kind !== 'found' || accountField === undefined || category === undefined || requested === undefined) {
      state.errors.push(...check.errors);
      return rendered(state);
    }
    const command: ServiceCommand =
      state.data.requestId === null
        ? ({
            kind: 'maintenance.draft.save',
            memberId: member.subject.id,
            accountId,
            category,
            subject,
            requestedCommand: requested,
            missingFields,
            ...(note === undefined ? {} : { note }),
            ...(evidence.length === 0 ? {} : { evidenceDocumentVersionIds: evidence }),
          } as unknown as ServiceCommand)
        : ({
            kind: 'maintenance.draft.amend',
            requestId: state.data.requestId,
            expectedUpdatedAt: state.data.expectedUpdatedAt,
            patch: {
              subject,
              reason: reason === '' ? null : reason,
              requestedCommand: requested,
              missingFields,
              ...(note === undefined ? {} : { note }),
              ...(evidence.length === 0 ? {} : { evidenceDocumentVersionIds: evidence }),
            },
          } as unknown as ServiceCommand);
    const outcome = ctx.execute(command, 'save', state.formKey);
    switch (outcome.kind) {
      case 'committed':
      case 'duplicate': {
        const result = outcome.receipt.result ?? {};
        const number = cell(result.requestNumber) || state.data.requestNumber || '';
        // draft.save has no reason field; a brand-new draft carrying one is amended immediately.
        const savedId = result.requestId;
        if (state.data.requestId === null && reason !== '' && typeof savedId === 'string') {
          const fresh = ctx.svc((db, context) => maintenanceRequest(db, context, savedId));
          if (fresh.kind === 'authorized' && fresh.value !== undefined) {
            ctx.execute(
              {
                kind: 'maintenance.draft.amend',
                requestId: savedId,
                expectedUpdatedAt: fresh.value.updatedAt,
                patch: { reason },
              },
              'save',
              `${state.formKey}-reason`,
            );
          }
        }
        return redirectTo(pageHref('RequestDetail.aspx', { request: number, msg: 'draft-saved' }));
      }
      case 'unchanged':
        state.notice = outcome.message;
        return rendered(state);
      case 'rejected':
        if (outcome.code === 'stale_version' && state.data.requestId !== null) {
          const fresh = ctx.svc((db, context) => maintenanceRequest(db, context, state.data.requestId ?? ''));
          if (fresh.kind === 'authorized' && fresh.value !== undefined) {
            state.comparison = [{ label: 'Server revision', saved: state.data.expectedUpdatedAt, current: fresh.value.updatedAt }];
          }
        }
        return rejectionError(state, outcome);
    }
  },

  render(ctx, state, view) {
    const memberNumber = state.fields.member ?? '';
    const items = accountItems(ctx, memberNumber);
    const blocked =
      state.data.requestId !== null && state.data.requestState !== 'draft'
        ? html`<div class="notice warning" id="ctl00_MainContent_lblBlocked">Request ${state.data.requestNumber} is ${state.data.requestState}. Only drafts can be changed.</div>`
        : '';
    return {
      title: state.data.requestId === null ? 'New maintenance request' : `Edit request ${state.data.requestNumber}`,
      breadcrumbs: [HOME, { label: 'Requests', href: 'Requests.aspx' }, { label: state.data.requestId === null ? 'New' : (state.data.requestNumber ?? ''), href: null }],
      body: html`
        ${blocked}
        ${state.data.requestId === null ? '' : html`<p class="hint">Editing draft ${state.data.requestNumber}, last saved ${when(state.data.expectedUpdatedAt)}.</p>`}
        <table class="form">
          <tr><th scope="row">${view.label('txtMember', 'Member')}</th><td>${view.textBox('txtMember', { field: 'member', maxLength: 40, columns: 20 })} <span class="format-hint">member number</span></td></tr>
          <tr><th scope="row">${view.label('ddlAccount', 'Account')}</th><td>${view.dropDownList('ddlAccount', {
            field: 'account',
            items: [{ value: '', text: memberNumber === '' ? '(enter member first)' : '(member-level request)' }, ...items],
            autoPostBack: { kind: 'refresh' },
          })}</td></tr>
          <tr><th scope="row">${view.label('ddlCategory', 'Category')}</th><td>${view.dropDownList('ddlCategory', {
            field: 'category',
            items: CATEGORIES.map((c) => ({ value: c, text: c })),
          })}</td></tr>
          <tr><th scope="row">${view.label('txtSubject', 'Subject')}</th><td>${view.textBox('txtSubject', { field: 'subject', maxLength: 200, columns: 40 })}</td></tr>
          <tr><th scope="row">${view.label('ddlRequested', 'Requested change')}</th><td>${view.dropDownList('ddlRequested', {
            field: 'requestedKind',
            items: REQUESTED_KINDS.map((k) => ({ value: k, text: k })),
            autoPostBack: { kind: 'refresh' },
          })}</td></tr>
          <tr><th scope="row">${view.label('txtRequestedJson', 'Requested command')}</th><td>${view.textArea('txtRequestedJson', { field: 'requestedJson', rows: 8, maxLength: 8000 })}<div class="field-help">JSON body for ${state.fields.requestedKind ?? 'the selected command'} — for example {"nickname":"House account"}.</div></td></tr>
          <tr><th scope="row">${view.label('txtMissing', 'Missing fields')}</th><td>${view.textArea('txtMissing', { field: 'missingFields', rows: 3, maxLength: 2000 })}<div class="field-help">Fields the customer still owes, one per line.</div></td></tr>
          <tr><th scope="row">${view.label('txtEvidence', 'Evidence document versions')}</th><td>${view.textArea('txtEvidence', { field: 'evidence', rows: 3, maxLength: 2000 })}<div class="field-help">One document version id per line.</div></td></tr>
          <tr><th scope="row">${view.label('txtReason', 'Reason')}</th><td>${view.textArea('txtReason', { field: 'reason', rows: 2, maxLength: 500 })}<div class="field-help">Required before the request can be submitted.</div></td></tr>
          <tr><th scope="row">${view.label('txtNote', 'Note')}</th><td>${view.textArea('txtNote', { field: 'note', rows: 3, maxLength: 2000 })}</td></tr>
        </table>
        ${state.data.saved === '' ? '' : html`<details><summary>Saved draft</summary><pre>${state.data.saved}</pre></details>`}
        <div class="actions">${view.button('btnSave', 'Save draft', { kind: 'save' }, { primary: true })}</div>`,
    };
  },
});
