import {
  listSavedSearches,
  savedSearchForActor,
  searchAccounts,
  searchCases,
  searchMembers,
  SAVED_SEARCH_ENTITIES,
  type AccountRow,
  type CaseRow,
  type MemberRow,
  type SavedSearchDefinition,
  type SavedSearchRow,
} from '@computer-use/financial-database/services';

import { html, type HtmlValue } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { accountLink, caseLink, HOME, memberLink } from './shared.js';

interface SearchesData {
  readonly rows: readonly SavedSearchRow[];
}

type SearchesEvent = { readonly kind: 'noop' };

function toSnake(name: string): string {
  return name.replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
}

/** Runs a saved definition through the entity's real query; only stored columns are rendered. */
function runSearch(ctx: PageContext, definition: SavedSearchDefinition): readonly (MemberRow | AccountRow | CaseRow)[] {
  const sort = definition.sort[0];
  const maxResults = Math.min(definition.maxResults ?? 200, 200);
  switch (definition.entity) {
    case 'members':
      return ctx.read((db, datasetId) =>
        searchMembers(db, datasetId, {
          query: String(definition.filters.query ?? ''),
          status: String(definition.filters.status ?? ''),
          sort: sort === undefined ? 'memberNumber' : (SAVED_SEARCH_ENTITIES.members.sorts[sort.field] ?? 'memberNumber'),
          direction: sort?.direction ?? 'asc',
          limit: maxResults,
          offset: 0,
        }).items,
      );
    case 'accounts':
      return ctx.read((db, datasetId) =>
        searchAccounts(db, datasetId, {
          query: String(definition.filters.query ?? ''),
          status: String(definition.filters.status ?? ''),
          currency: String(definition.filters.currency ?? ''),
          sort: sort === undefined ? 'accountNumber' : (SAVED_SEARCH_ENTITIES.accounts.sorts[sort.field] ?? 'accountNumber'),
          direction: sort?.direction ?? 'asc',
          limit: maxResults,
          offset: 0,
        }).items,
      );
    case 'cases':
      return ctx.read((db, datasetId) =>
        searchCases(db, datasetId, {
          query: String(definition.filters.query ?? ''),
          ...(Array.isArray(definition.filters.states) ? { states: definition.filters.states } : {}),
          ...(Array.isArray(definition.filters.queueIds) ? { queueIds: definition.filters.queueIds } : {}),
          ...(definition.filters.priority === undefined ? {} : { priority: String(definition.filters.priority) }),
          ...(definition.filters.assignedActorId === undefined ? {} : { assignedActorId: String(definition.filters.assignedActorId) }),
          overdue: definition.filters.overdue === true,
          sort: sort === undefined ? 'due' : (SAVED_SEARCH_ENTITIES.cases.sorts[sort.field] ?? 'due'),
          direction: sort?.direction ?? 'asc',
          limit: maxResults,
          offset: 0,
        }).items,
      );
  }
}

function cell(column: string, item: MemberRow | AccountRow | CaseRow): HtmlValue {
  const record = item as unknown as Record<string, unknown>;
  const value = record[toSnake(column).replace(/_([a-z])/g, (_m, letter: string) => letter.toUpperCase())] ?? record[column];
  if (column === 'member_number') return memberLink(String(value));
  if (column === 'account_number') return accountLink(String(value));
  if (column === 'case_number') return caseLink(String(value));
  if (Array.isArray(value)) return value.join(', ');
  if (typeof value === 'boolean') return value ? 'yes' : 'no';
  return typeof value === 'string' ? value : typeof value === 'number' ? String(value) : '—';
}

export const searchesPage = definePage<SearchesData, SearchesEvent>({
  load(ctx): LoadOutcome<SearchesData> {
    const rows = ctx.read((db) => listSavedSearches(db, ctx.binding.datasetId, ctx.actor.actorId));
    return { kind: 'ready', data: { rows } };
  },
  handle(_ctx, state, _event): Outcome<SearchesData> {
    return rendered(state);
  },
  render(ctx, state) {
    const runId = ctx.query.get('run');
    const runRow = runId === null ? undefined : ctx.read((db) => savedSearchForActor(db, ctx.binding.datasetId, ctx.actor.actorId, runId));
    let results: { definition: SavedSearchDefinition; items: readonly (MemberRow | AccountRow | CaseRow)[] } | undefined;
    if (runRow !== undefined && runRow.definition !== null) {
      results = { definition: runRow.definition, items: runSearch(ctx, runRow.definition) };
    }
    return {
      title: 'Saved searches',
      breadcrumbs: [HOME, { label: 'Saved searches', href: null }],
      body: html`
        <p class="hint">${state.data.rows.length} search${state.data.rows.length === 1 ? '' : 'es'} visible to ${ctx.actor.actorNumber} — yours first, then shared. <a href="${pageHref('Operation.aspx', { op: 'search.saved.create' })}">Save a search</a></p>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Name</th><th>Entity</th><th>Visibility</th><th>Owner</th><th></th></tr>${state.data.rows.map(
          (row) => html`<tr class="grid-row"><td>${row.name}</td><td>${row.definition?.entity ?? '—'}</td><td>${row.visibility}</td><td>${row.owner.actorNumber}</td>
            <td><a href="${pageHref('Searches.aspx', { run: row.id })}">Run</a> · <a href="${pageHref('Operation.aspx', { op: 'search.saved.update', search: row.id })}">Edit</a> · <a href="${pageHref('Operation.aspx', { op: 'search.saved.delete', search: row.id })}">Delete</a></td></tr>`,
        )}</table>
        ${results === undefined || runRow === undefined ? '' : html`<h2>${runRow.name}</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header">${results.definition.columns.map((column) => html`<th>${column}</th>`)}</tr>${results.items.map(
          (item) => html`<tr class="grid-row">${results.definition.columns.map((column) => html`<td>${cell(column, item)}</td>`)}</tr>`,
        )}</table>`}`,
    };
  },
});
