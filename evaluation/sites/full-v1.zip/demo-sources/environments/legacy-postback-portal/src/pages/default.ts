import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type Outcome, type PageContext } from '../runtime.js';
import { rows } from '../ops/subjects.js';
import { money } from './shared.js';

interface HomeData {
  readonly counts: { label: string; count: number }[];
  readonly accounts: { number: string; balance: number; currency: string }[];
}

function homeData(ctx: PageContext): HomeData {
  const dataset = ctx.services.database.dataset(ctx.binding);
  const summary = dataset.summary();
  const counts = [
    { label: 'Members', count: summary.members },
    { label: 'Accounts', count: summary.accounts },
    { label: 'Journal lines', count: summary.journalLines },
    { label: 'Payments', count: summary.payments },
    { label: 'Cards', count: summary.cards },
    { label: 'Loans', count: summary.loans },
    { label: 'Document versions', count: summary.documents },
    { label: 'Cases', count: summary.cases },
    { label: 'Batches', count: summary.batches },
  ];
  const accounts = rows(
    ctx,
    `SELECT a.account_number,b.posted_balance_minor_units,a.currency FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id WHERE a.dataset_id=? ORDER BY b.posted_balance_minor_units DESC LIMIT 8`,
    ctx.binding.datasetId,
  ).map((r) => ({ number: String(r.account_number), balance: Number(r.posted_balance_minor_units), currency: String(r.currency) }));
  return { counts, accounts };
}

export const defaultPage = definePage<HomeData, never>({
  load(ctx) {
    return { kind: 'ready', data: homeData(ctx) };
  },
  handle(_ctx, state, _event): Outcome<HomeData> {
    return rendered(state);
  },
  render(ctx, state) {
    const institution = ctx.institution;
    return {
      title: 'BranchNet Home',
      breadcrumbs: [{ label: 'Home', href: null }],
      body: html`
        <div class="home-grid">
          <section class="card"><h2>${institution.displayName}</h2>
            <p class="hint">${institution.legalName} · Dataset ${ctx.binding.datasetId} · as of ${institution.asOf.slice(0, 10)}</p>
            <table class="details"><tr><th scope="row">Signed on</th><td>${ctx.actor.actorNumber} ${ctx.actor.displayName} <a href="Operator.aspx">switch</a></td></tr>
            <tr><th scope="row">Roles</th><td>${ctx.actor.roles.join(', ')}</td></tr>
            <tr><th scope="row">Business time</th><td>${ctx.businessNow}</td></tr></table>
          </section>
          <section class="card"><h2>World</h2>
            <table class="details">${state.data.counts.map((c) => html`<tr><th scope="row">${c.label}</th><td>${c.count}</td></tr>`)}</table>
          </section>
          <section class="card"><h2>Largest accounts</h2>
            <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Account</th><th>Posted balance</th></tr>${state.data.accounts.map(
              (a) => html`<tr class="grid-row"><td><a href="${pageHref('AccountDetail.aspx', { account: a.number })}">${a.number}</a></td><td class="amount">${money(ctx, a.balance, a.currency)}</td></tr>`,
            )}</table>
          </section>
          <section class="card"><h2>Operations</h2>
            <p><a href="Operation.aspx">Open the operations directory</a> — every business action runs through review before commit.</p>
            <p><a href="Requests.aspx">Maintenance requests</a> · <a href="Approvals.aspx">Approvals</a> · <a href="Searches.aspx">Saved searches</a></p>
          </section>
        </div>`,
    };
  },
});
