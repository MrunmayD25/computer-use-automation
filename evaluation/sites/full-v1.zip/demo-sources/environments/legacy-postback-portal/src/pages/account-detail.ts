import { accountDetail, accountTransactions, type AccountDetail } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { accountSubject } from '../ops/subjects.js';
import { day, detailsTable, HOME, listCrumb, memberLink, money, notFound, when } from './shared.js';

interface DetailData {
  readonly accountId: string;
  readonly accountNumber: string;
  readonly memberNumber: string;
}

function detail(ctx: PageContext): AccountDetail | undefined {
  const subject = accountSubject(ctx, ctx.query.get('account') ?? '');
  if (subject.kind !== 'found') return undefined;
  return ctx.read((db) => accountDetail(db, ctx.binding.datasetId, subject.subject.id));
}

const ACCOUNT_OPS: readonly { kind: string; label: string }[] = [
  { kind: 'account.nickname.update', label: 'Update nickname' },
  { kind: 'account.statement_delivery.update', label: 'Update statement delivery' },
  { kind: 'cash.deposit', label: 'Deposit' },
  { kind: 'cash.withdraw', label: 'Withdraw' },
  { kind: 'transfer.internal', label: 'Transfer out' },
  { kind: 'account.product.convert', label: 'Convert product' },
  { kind: 'account.owner.add', label: 'Add owner' },
  { kind: 'account.signer.remove', label: 'Remove signer' },
  { kind: 'account.overdraft_limit.update', label: 'Overdraft limit' },
  { kind: 'account.hold.place', label: 'Place hold' },
  { kind: 'account.hold.release', label: 'Release hold' },
  { kind: 'account.restriction.apply', label: 'Apply restriction' },
  { kind: 'account.restriction.release', label: 'Release restriction' },
  { kind: 'fee.assess', label: 'Assess fee' },
  { kind: 'fee.waiver.create', label: 'Create fee waiver' },
  { kind: 'fee.refund', label: 'Refund fee' },
  { kind: 'account.maturity.instruct', label: 'Maturity instruction' },
  { kind: 'account.close', label: 'Close account' },
];

export const accountDetailPage = definePage<DetailData, never>({
  load(ctx): LoadOutcome<DetailData> {
    const found = detail(ctx);
    if (found === undefined) {
      return notFound('Account not found', 'No account with that number exists in this dataset.', [
        { href: 'Accounts.aspx', label: 'Back to accounts' },
      ]);
    }
    return { kind: 'ready', data: { accountId: found.account.id, accountNumber: found.account.accountNumber, memberNumber: found.account.memberNumber } };
  },
  handle(_ctx, state, _event): Outcome<DetailData> {
    return rendered(state);
  },
  render(ctx, _state) {
    const found = detail(ctx);
    if (found === undefined) {
      return { title: 'Account not found', breadcrumbs: [HOME, { label: 'Accounts', href: 'Accounts.aspx' }], body: html`<p>This account no longer exists.</p>` };
    }
    const account = found.account;
    const transactions = ctx.read((db) => accountTransactions(db, ctx.binding.datasetId, account.id, { order: 'newest', limit: 8, offset: 0 }));
    const ops = ACCOUNT_OPS.map(
      (op) => html`<a class="action-link" href="${pageHref('Operation.aspx', { op: op.kind, account: account.accountNumber })}">${op.label}</a>`,
    );
    return {
      title: `Account ${account.accountNumber}`,
      breadcrumbs: [HOME, listCrumb(ctx, 'Accounts', 'Accounts.aspx'), { label: account.accountNumber, href: null }],
      body: html`
        ${detailsTable([
          ['Account number', account.accountNumber],
          ['Owner', memberLink(account.memberNumber, `${account.ownerName} (${account.memberNumber})`)],
          ['Product', `${account.productCode} — ${account.productName}`],
          ['Status', `${account.status} (member ${found.memberStatus})`],
          ['Nickname', account.nickname],
          ['Currency', `${account.currency} (exponent ${account.exponent})`],
          ['Posted balance', money(ctx, account.postedMinorUnits, account.currency)],
          ['Available balance', money(ctx, account.availableMinorUnits, account.currency)],
          ['Statement delivery', account.statementDelivery],
          ['Opened', day(account.openedAt)],
          ['Closed', account.closedAt === null ? '—' : day(account.closedAt)],
          ['Version', String(account.version)],
          ['Record id', account.id],
        ])}
        <h2>Eligibility</h2>
        ${detailsTable([
          ['Debit', `${found.eligibility.debit.eligible ? 'eligible' : 'blocked'}${found.eligibility.debit.reasons.length === 0 ? '' : ` — ${found.eligibility.debit.reasons.join('; ')}`}`],
          ['Credit', `${found.eligibility.credit.eligible ? 'eligible' : 'blocked'}${found.eligibility.credit.reasons.length === 0 ? '' : ` — ${found.eligibility.credit.reasons.join('; ')}`}`],
          ['Closure', `${found.eligibility.closure.eligible ? 'eligible' : 'blocked'}${found.eligibility.closure.reasons.length === 0 ? '' : ` — ${found.eligibility.closure.reasons.join('; ')}`}`],
        ])}
        <div class="action-bar">${ops}</div>
        <h2>Parties</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Party</th><th>Role</th><th>From</th><th>To</th></tr>${found.parties.map(
          (p) => html`<tr class="grid-row"><td>${p.displayName}</td><td>${p.role}</td><td>${day(p.startsAt)}</td><td>${p.endsAt === null ? '—' : day(p.endsAt)}</td></tr>`,
        )}</table>
        <h2>Holds</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Hold</th><th>Amount</th><th>Status</th><th>Reason</th><th>Release authority</th><th>Placed</th></tr>${found.holds.map(
          (h) => html`<tr class="grid-row"><td>${h.id}</td><td class="amount">${money(ctx, h.amountMinorUnits, account.currency)}</td><td>${h.status}</td><td>${h.reason}</td><td>${h.releaseAuthority}</td><td>${when(h.placedAt)}</td></tr>`,
        )}</table>
        <h2>Restrictions</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Restriction</th><th>Kind</th><th>Status</th><th>Authority</th><th>Placed</th></tr>${found.restrictions.map(
          (r) => html`<tr class="grid-row"><td>${r.id}</td><td>${r.kind}</td><td>${r.status}</td><td>${r.authority}</td><td>${when(r.placedAt)}</td></tr>`,
        )}</table>
        <h2>Facilities</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Facility</th><th>Kind</th><th>Limit</th><th>Used</th><th>Status</th></tr>${found.facilities.map(
          (f) => html`<tr class="grid-row"><td>${f.id}</td><td>${f.kind}</td><td class="amount">${money(ctx, f.limitMinorUnits, account.currency)}</td><td class="amount">${money(ctx, f.usedMinorUnits, account.currency)}</td><td>${f.status}</td></tr>`,
        )}</table>
        <h2>Cards</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Card</th><th>Status</th></tr>${found.cards.map(
          (c) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'card', id: c.id })}">•••• ${c.lastFour}</a></td><td>${c.status}</td></tr>`,
        )}</table>
        <h2>Recent transactions</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Date</th><th>Reference</th><th>Description</th><th>Amount</th><th>Balance</th><th></th></tr>${transactions.items.map(
          (t) => html`<tr class="grid-row"><td>${day(t.effectiveDate)}</td><td>${t.reference}</td><td>${t.description}</td><td class="amount">${money(ctx, t.amountMinorUnits, account.currency)}</td><td class="amount">${money(ctx, t.runningBalanceMinorUnits, account.currency)}</td><td>${t.receiptNumber === null ? '' : html`<a href="${pageHref('Receipt.aspx', { no: t.receiptNumber })}">receipt</a>`}</td></tr>`,
        )}</table>
        <p class="hint"><a href="${pageHref('Transactions.aspx', { account: account.accountNumber })}">Full transaction history</a> · <a href="${pageHref('Statements.aspx', { account: account.accountNumber })}">Statements</a> · <a href="${pageHref('Activity.aspx', { account: account.id })}">Account activity</a></p>`,
    };
  },
});
