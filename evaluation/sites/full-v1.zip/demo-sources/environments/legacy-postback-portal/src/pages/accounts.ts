import { searchAccounts, type AccountRow } from '@computer-use/financial-database/services';

import { gridView } from '../grid.js';
import { html } from '../html.js';
import { definePage, redirectTo, type Outcome, type PageContext } from '../runtime.js';
import { pickers } from '../ops/subjects.js';
import { accountLink, day, HOME, memberLink, moneyCell, pageIndexFrom } from './shared.js';

const PAGE_SIZE = 20;
const SORTS = ['accountNumber', 'memberNumber', 'owner', 'product', 'status', 'nickname', 'posted', 'available', 'opened'] as const;
const STATUSES = ['', 'open', 'restricted', 'dormant', 'closed', 'matured'] as const;

interface AccountsData {
  readonly items: readonly AccountRow[];
  readonly total: number;
  readonly pageIndex: number;
  readonly sort: string;
  readonly descending: boolean;
}

type AccountsEvent =
  | { readonly kind: 'find' }
  | { readonly kind: 'page'; readonly index: number }
  | { readonly kind: 'sort'; readonly key: string };

function search(ctx: PageContext): AccountsData {
  const pageIndex = pageIndexFrom(ctx.query.get('page'));
  const sort = (SORTS as readonly string[]).includes(ctx.query.get('sort') ?? '') ? (ctx.query.get('sort') ?? 'accountNumber') : 'accountNumber';
  const descending = ctx.query.get('dir') === 'desc';
  const result = ctx.read((db, datasetId) =>
    searchAccounts(db, datasetId, {
      query: ctx.query.get('q') ?? '',
      status: ctx.query.get('status') ?? '',
      currency: ctx.query.get('ccy') ?? '',
      sort,
      direction: descending ? 'desc' : 'asc',
      limit: PAGE_SIZE,
      offset: pageIndex * PAGE_SIZE,
    }),
  );
  return { items: result.items, total: result.total, pageIndex, sort, descending };
}

function queryUrl(ctx: PageContext, patch: Record<string, string | null>): string {
  const query = new URLSearchParams(ctx.query);
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) query.delete(key);
    else query.set(key, value);
  }
  const text = query.toString();
  return `Accounts.aspx${text === '' ? '' : `?${text}`}`;
}

export const accountsPage = definePage<AccountsData, AccountsEvent>({
  load(ctx) {
    return {
      kind: 'ready',
      data: search(ctx),
      fields: { q: ctx.query.get('q') ?? '', status: ctx.query.get('status') ?? '', ccy: ctx.query.get('ccy') ?? '' },
    };
  },
  handle(ctx, state, event): Outcome<AccountsData> {
    if (event === null || event.kind === 'find') {
      return redirectTo(queryUrl(ctx, { q: (state.fields.q ?? '').trim(), status: state.fields.status ?? '', ccy: state.fields.ccy ?? '', page: null }));
    }
    switch (event.kind) {
      case 'page':
        return redirectTo(queryUrl(ctx, { page: String(event.index + 1) }));
      case 'sort':
        return redirectTo(queryUrl(ctx, { sort: event.key, dir: state.data.sort === event.key && !state.data.descending ? 'desc' : 'asc', page: null }));
    }
  },
  render(ctx, state, view) {
    const data = state.data;
    const grid = gridView<AccountsEvent>(view);
    return {
      title: 'Accounts',
      breadcrumbs: [HOME, { label: 'Accounts', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('txtQ', 'Search')} ${view.textBox('txtQ', { field: 'q', maxLength: 80, columns: 20 })}
            ${view.label('ddlStatus', 'Status')} ${view.dropDownList('ddlStatus', {
              field: 'status',
              items: STATUSES.map((s) => ({ value: s, text: s === '' ? 'All statuses' : s })),
            })}
            ${view.label('ddlCcy', 'Currency')} ${view.dropDownList('ddlCcy', {
              field: 'ccy',
              items: [{ value: '', text: 'All currencies' }, ...pickers.currencies(ctx).map((c) => ({ value: c.value, text: c.value }))],
            })}
            ${view.button('btnFind', 'Find', { kind: 'find' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} account${data.total === 1 ? '' : 's'}. <a href="AccountOpen.aspx">Open an account</a>.</p>
        ${grid({
          id: 'grdAccounts',
          rows: [...data.items],
          emptyText: 'No accounts match these filters.',
          columns: [
            { header: 'Account', sortKey: 'accountNumber', cell: (r) => accountLink(r.accountNumber) },
            { header: 'Member', sortKey: 'memberNumber', cell: (r) => memberLink(r.memberNumber, `${r.memberNumber} — ${r.ownerName}`) },
            { header: 'Product', sortKey: 'product', cell: (r) => `${r.productCode} ${r.productName}` },
            { header: 'Status', sortKey: 'status', cell: (r) => r.status },
            { header: 'Nickname', sortKey: 'nickname', cell: (r) => r.nickname },
            { header: 'Posted', sortKey: 'posted', cell: (r) => moneyCell(ctx, r.postedMinorUnits, r.currency) },
            { header: 'Available', sortKey: 'available', cell: (r) => moneyCell(ctx, r.availableMinorUnits, r.currency) },
            { header: 'Opened', sortKey: 'opened', cell: (r) => day(r.openedAt) },
          ],
          paging: { pageIndex: data.pageIndex, pageSize: PAGE_SIZE, total: data.total, event: (index) => ({ kind: 'page', index }) },
          sorting: { key: data.sort, descending: data.descending, event: (key) => ({ kind: 'sort', key }) },
        })}`,
    };
  },
});
