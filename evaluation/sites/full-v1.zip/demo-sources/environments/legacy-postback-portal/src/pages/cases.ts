import { listServicingQueues, searchCases, type CaseRow } from '@computer-use/financial-database/services';

import { gridView } from '../grid.js';
import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, type Outcome, type PageContext } from '../runtime.js';
import { row } from '../ops/subjects.js';
import { caseLink, day, HOME, memberLink, pageIndexFrom } from './shared.js';

const PAGE_SIZE = 20;
const SORTS = ['caseNumber', 'due', 'opened', 'state', 'priority', 'member', 'queue', 'assignee'] as const;

interface CasesData {
  readonly items: readonly CaseRow[];
  readonly total: number;
  readonly pageIndex: number;
  readonly sort: string;
  readonly descending: boolean;
}

type CasesEvent =
  | { readonly kind: 'find' }
  | { readonly kind: 'page'; readonly index: number }
  | { readonly kind: 'sort'; readonly key: string };

function search(ctx: PageContext): CasesData {
  const pageIndex = pageIndexFrom(ctx.query.get('page'));
  const sort = (SORTS as readonly string[]).includes(ctx.query.get('sort') ?? '') ? (ctx.query.get('sort') ?? 'due') : 'due';
  const descending = ctx.query.get('dir') === 'desc';
  const queueCode = ctx.query.get('queue') ?? '';
  const queueId =
    queueCode === ''
      ? undefined
      : (row(ctx, 'SELECT id FROM queues WHERE dataset_id=? AND code=?', ctx.binding.datasetId, queueCode)?.id as string | undefined);
  const state = ctx.query.get('state') ?? '';
  const result = ctx.read((db, datasetId) =>
    searchCases(db, datasetId, {
      query: ctx.query.get('q') ?? '',
      ...(state === '' ? {} : { states: [state] }),
      ...(queueId === undefined ? {} : { queueId }),
      overdue: ctx.query.get('overdue') === 'yes',
      sort,
      direction: descending ? 'desc' : 'asc',
      limit: PAGE_SIZE,
      offset: pageIndex * PAGE_SIZE,
    }),
  );
  return { items: result.items, total: result.total, pageIndex, sort, descending };
}

function queryUrl(ctx: PageContext, patch: Record<string, string | null>): string {
  const query = new URLSearchParams(ctx.query);
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) query.delete(key);
    else query.set(key, value);
  }
  const text = query.toString();
  return `Cases.aspx${text === '' ? '' : `?${text}`}`;
}

export const casesPage = definePage<CasesData, CasesEvent>({
  load(ctx) {
    return {
      kind: 'ready',
      data: search(ctx),
      fields: { q: ctx.query.get('q') ?? '', state: ctx.query.get('state') ?? '', queue: ctx.query.get('queue') ?? '', overdue: ctx.query.get('overdue') ?? 'no' },
    };
  },
  handle(ctx, state, event): Outcome<CasesData> {
    if (event === null || event.kind === 'find') {
      return redirectTo(queryUrl(ctx, { q: (state.fields.q ?? '').trim() || null, state: state.fields.state || null, queue: state.fields.queue || null, overdue: state.fields.overdue === 'yes' ? 'yes' : null, page: null }));
    }
    switch (event.kind) {
      case 'page':
        return redirectTo(queryUrl(ctx, { page: String(event.index + 1) }));
      case 'sort':
        return redirectTo(queryUrl(ctx, { sort: event.key, dir: state.data.sort === event.key && !state.data.descending ? 'desc' : 'asc', page: null }));
    }
  },
  render(ctx, state, view) {
    const data = state.data;
    const grid = gridView<CasesEvent>(view);
    const queues = ctx.svc((db, context) => listServicingQueues(db, context));
    const queueItems = queues.kind === 'authorized' ? queues.value.map((q) => ({ value: q.code, text: `${q.code} ${q.name}` })) : [];
    return {
      title: 'Servicing cases',
      breadcrumbs: [HOME, { label: 'Cases', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('txtQ', 'Search')} ${view.textBox('txtQ', { field: 'q', maxLength: 80, columns: 16 })}
            ${view.label('ddlState', 'State')} ${view.dropDownList('ddlState', {
              field: 'state',
              items: [
                { value: '', text: 'All states' },
                { value: 'open', text: 'Open' },
                { value: 'in-progress', text: 'In progress' },
                { value: 'waiting', text: 'Waiting' },
                { value: 'resolved', text: 'Resolved' },
                { value: 'closed', text: 'Closed' },
              ],
            })}
            ${view.label('ddlQueue', 'Queue')} ${view.dropDownList('ddlQueue', { field: 'queue', items: [{ value: '', text: 'All queues' }, ...queueItems] })}
            ${view.label('ddlOverdue', 'Overdue')} ${view.dropDownList('ddlOverdue', { field: 'overdue', items: [
              { value: 'no', text: 'All' }, { value: 'yes', text: 'Overdue only' },
            ] })}
            ${view.button('btnFind', 'Find', { kind: 'find' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} case${data.total === 1 ? '' : 's'}.</p>
        ${grid({
          id: 'grdCases',
          rows: [...data.items],
          emptyText: 'No cases match these filters.',
          columns: [
            { header: 'Case', sortKey: 'caseNumber', cell: (r) => caseLink(r.caseNumber) },
            { header: 'Member', sortKey: 'member', cell: (r) => memberLink(r.memberNumber, r.memberName) },
            { header: 'Queue', sortKey: 'queue', cell: (r) => r.queueName },
            { header: 'State', sortKey: 'state', cell: (r) => r.state },
            { header: 'Priority', sortKey: 'priority', cell: (r) => r.priority },
            { header: 'Category', cell: (r) => r.categoryLabel },
            { header: 'Assignee', sortKey: 'assignee', cell: (r) => r.assignedName ?? '—' },
            { header: 'Due', sortKey: 'due', cell: (r) => (r.overdue ? html`<span class="overdue">${day(r.dueAt)}</span>` : day(r.dueAt)) },
            { header: 'Summary', cell: (r) => r.summary },
          ],
          paging: { pageIndex: data.pageIndex, pageSize: PAGE_SIZE, total: data.total, event: (index) => ({ kind: 'page', index }) },
          sorting: { key: data.sort, descending: data.descending, event: (key) => ({ kind: 'sort', key }) },
        })}
        <p class="hint"><a href="${pageHref('Operation.aspx', { op: 'case.open' })}">Open a case</a></p>`,
    };
  },
});
