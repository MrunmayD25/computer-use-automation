import { accountTransactions, searchAccounts, transactionsCsv, type TransactionRow } from '@computer-use/financial-database/services';

import { gridView } from '../grid.js';
import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { csvDownload, definePage, redirectTo, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { accountSubject, cell } from '../ops/subjects.js';
import { day, HOME, money, notFound, pageIndexFrom } from './shared.js';

const PAGE_SIZE = 25;

interface TxData {
  readonly accountId: string;
  readonly accountNumber: string;
  readonly currency: string;
  readonly items: readonly TransactionRow[];
  readonly total: number;
  readonly pageIndex: number;
}

type TxEvent =
  | { readonly kind: 'find' }
  | { readonly kind: 'page'; readonly index: number }
  | { readonly kind: 'export' };

function filters(ctx: PageContext): { startDate?: string; endDate?: string; direction?: 'credit' | 'debit'; text?: string; order: 'newest' | 'oldest'; status?: 'posted' | 'reversed' } {
  const direction = ctx.query.get('dir2');
  const status = ctx.query.get('st');
  const from = ctx.query.get('from');
  const to = ctx.query.get('to');
  const text = ctx.query.get('text');
  return {
    ...(from === null || from === '' ? {} : { startDate: from }),
    ...(to === null || to === '' ? {} : { endDate: to }),
    ...(direction === 'credit' || direction === 'debit' ? { direction } : {}),
    ...(text === null || text === '' ? {} : { text }),
    order: ctx.query.get('order') === 'oldest' ? 'oldest' : 'newest',
    ...(status === 'posted' || status === 'reversed' ? { status } : {}),
  };
}

function resolve(ctx: PageContext): TxData | undefined {
  const requested = ctx.query.get('account') ?? '';
  const fallback = requested === '' ? ctx.read((db, ds) => searchAccounts(db, ds, { query: '', status: 'open', limit: 1, offset: 0 }).items[0]?.accountNumber ?? '') : requested;
  const subject = accountSubject(ctx, fallback);
  if (subject.kind !== 'found') return undefined;
  const record = subject.subject.record ?? {};
  const pageIndex = pageIndexFrom(ctx.query.get('page'));
  const result = ctx.read((db) => accountTransactions(db, ctx.binding.datasetId, subject.subject.id, { ...filters(ctx), limit: PAGE_SIZE, offset: pageIndex * PAGE_SIZE }));
  return { accountId: subject.subject.id, accountNumber: cell(record.account_number), currency: cell(record.currency), items: result.items, total: result.total, pageIndex };
}

function queryUrl(ctx: PageContext, patch: Record<string, string | null>): string {
  const query = new URLSearchParams(ctx.query);
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) query.delete(key);
    else query.set(key, value);
  }
  const text = query.toString();
  return `Transactions.aspx${text === '' ? '' : `?${text}`}`;
}

export const transactionsPage = definePage<TxData, TxEvent>({
  load(ctx): LoadOutcome<TxData> {
    const found = resolve(ctx);
    if (found === undefined) {
      return notFound('Account not found', 'Choose an account to see its transaction history.', [
        { href: 'Accounts.aspx', label: 'Accounts' },
      ]);
    }
    return {
      kind: 'ready',
      data: found,
      fields: {
        from: ctx.query.get('from') ?? '',
        to: ctx.query.get('to') ?? '',
        dir2: ctx.query.get('dir2') ?? '',
        text: ctx.query.get('text') ?? '',
        order: ctx.query.get('order') ?? 'newest',
        st: ctx.query.get('st') ?? '',
      },
    };
  },
  handle(ctx, state, event): Outcome<TxData> {
    if (event === null || event.kind === 'find') {
      return redirectTo(
        queryUrl(ctx, {
          from: (state.fields.from ?? '').trim() || null,
          to: (state.fields.to ?? '').trim() || null,
          dir2: state.fields.dir2 || null,
          text: (state.fields.text ?? '').trim() || null,
          order: state.fields.order || null,
          st: state.fields.st || null,
          page: null,
        }),
      );
    }
    if (event.kind === 'page') return redirectTo(queryUrl(ctx, { page: String(event.index + 1) }));
    // export: CSV of the filtered ledger lines.
    const accountRow = ctx.read((db) => searchAccounts(db, ctx.binding.datasetId, { ids: [state.data.accountId], offset: 0, limit: 1 }).items[0]);
    if (accountRow === undefined) return rendered(state, 404);
    const rows = ctx.read((db) => accountTransactions(db, ctx.binding.datasetId, state.data.accountId, { ...filters(ctx), limit: 200, offset: 0 }));
    const artifact = transactionsCsv(accountRow, rows.items);
    return csvDownload(artifact.displayName, new TextDecoder().decode(artifact.bytes));
  },
  render(ctx, state, view) {
    const data = state.data;
    const grid = gridView<TxEvent>(view);
    return {
      title: `Transactions · ${data.accountNumber}`,
      breadcrumbs: [HOME, { label: 'Accounts', href: 'Accounts.aspx' }, { label: data.accountNumber, href: pageHref('AccountDetail.aspx', { account: data.accountNumber }) }, { label: 'Transactions', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('txtFrom', 'From')} ${view.textBox('txtFrom', { field: 'from', maxLength: 10, columns: 12 })}
            ${view.label('txtTo', 'To')} ${view.textBox('txtTo', { field: 'to', maxLength: 10, columns: 12 })}
            ${view.label('ddlDir', 'Direction')} ${view.dropDownList('ddlDir', { field: 'dir2', items: [
              { value: '', text: 'Both' }, { value: 'credit', text: 'Credits' }, { value: 'debit', text: 'Debits' },
            ] })}
            ${view.label('txtText', 'Text')} ${view.textBox('txtText', { field: 'text', maxLength: 80, columns: 14 })}
            ${view.label('ddlOrder', 'Order')} ${view.dropDownList('ddlOrder', { field: 'order', items: [
              { value: 'newest', text: 'Newest first' }, { value: 'oldest', text: 'Oldest first' },
            ] })}
            ${view.label('ddlStatus', 'Status')} ${view.dropDownList('ddlStatus', { field: 'st', items: [
              { value: '', text: 'All' }, { value: 'posted', text: 'Posted' }, { value: 'reversed', text: 'Reversed' },
            ] })}
            ${view.button('btnFind', 'Find', { kind: 'find' })}
            ${view.button('btnExport', 'Export CSV', { kind: 'export' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} ledger entr${data.total === 1 ? 'y' : 'ies'}.</p>
        ${grid({
          id: 'grdTransactions',
          rows: [...data.items],
          emptyText: 'No transactions match these filters.',
          columns: [
            { header: 'Date', cell: (r) => day(r.effectiveDate) },
            { header: 'Posted', cell: (r) => r.postedAt.slice(0, 19) },
            { header: 'Reference', cell: (r) => r.reference },
            { header: 'Description', cell: (r) => r.description },
            { header: 'Status', cell: (r) => r.status },
            { header: 'Counterparty', cell: (r) => r.counterparty ?? '' },
            { header: 'Amount', className: 'amount', cell: (r) => money(ctx, r.amountMinorUnits, data.currency) },
            { header: 'Balance', className: 'amount', cell: (r) => money(ctx, r.runningBalanceMinorUnits, data.currency) },
            { header: 'Receipt', cell: (r) => (r.receiptNumber === null ? '' : html`<a href="${pageHref('Receipt.aspx', { no: r.receiptNumber })}">${r.receiptNumber}</a>`) },
          ],
          paging: { pageIndex: data.pageIndex, pageSize: PAGE_SIZE, total: data.total, event: (index) => ({ kind: 'page', index }) },
        })}`,
    };
  },
});
