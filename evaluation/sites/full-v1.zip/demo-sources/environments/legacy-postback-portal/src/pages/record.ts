import { readFinanceRecord, type FinanceRecordKind } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { definePage, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { HOME, notFound, when } from './shared.js';

const KINDS: readonly FinanceRecordKind[] = [
  'beneficiary', 'beneficiary-route', 'payment', 'payment-schedule', 'schedule-occurrence', 'payment-return',
  'card', 'card-transaction', 'dispute', 'loan', 'interest-calculation', 'fee', 'hold', 'restriction', 'facility',
  'maturity-instruction', 'received-funds', 'transaction', 'journal', 'transfer', 'settlement-batch', 'suspense-item', 'batch', 'loan-closure',
];

interface RecordData {
  readonly kind: string;
  readonly id: string;
}

function find(ctx: PageContext): { record: Record<string, unknown>; fingerprint: string } | undefined {
  const kind = ctx.query.get('kind') ?? '';
  const id = ctx.query.get('id') ?? '';
  if (!(KINDS as readonly string[]).includes(kind) || id === '') return undefined;
  const outcome = readFinanceRecord(ctx.services.store, ctx.context('branchnet:record'), kind as FinanceRecordKind, id);
  return outcome.kind === 'found' ? { record: outcome.snapshot.record, fingerprint: outcome.snapshot.fingerprint } : undefined;
}

export const recordPage = definePage<RecordData, never>({
  load(ctx): LoadOutcome<RecordData> {
    const found = find(ctx);
    if (found === undefined) {
      return notFound('Record not found', 'No business record of that kind and id exists, or the kind is not record-addressable.', [
        { href: 'Default.aspx', label: 'Home' },
      ]);
    }
    return { kind: 'ready', data: { kind: ctx.query.get('kind') ?? '', id: ctx.query.get('id') ?? '' } };
  },
  handle(_ctx, state, _event): Outcome<RecordData> {
    return rendered(state);
  },
  render(ctx, state) {
    const found = find(ctx);
    if (found === undefined) {
      return { title: 'Record', breadcrumbs: [HOME], body: html`<p>This record is no longer available.</p>` };
    }
    return {
      title: `${state.data.kind} ${state.data.id.slice(-8)}`,
      breadcrumbs: [HOME, { label: state.data.kind, href: null }],
      body: html`
        <p class="hint">Fingerprint <code>${found.fingerprint}</code> · read ${when(ctx.businessNow)}</p>
        <table class="details">${Object.entries(found.record).map(
          ([key, value]) => html`<tr><th scope="row">${key}</th><td>${typeof value === 'object' && value !== null ? html`<code>${JSON.stringify(value)}</code>` : String(value)}</td></tr>`,
        )}</table>`,
    };
  },
});
