import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type Outcome, type PageContext } from '../runtime.js';
import { rows } from '../ops/subjects.js';
import { accountLink, day, HOME, moneyCell } from './shared.js';

interface CardsData {
  readonly cards: readonly { id: string; accountNumber: string; lastFour: string; status: string }[];
  readonly disputes: readonly { id: string; caseNumber: string; accountNumber: string; amount: number; currency: string; state: string; deadline: string }[];
}

function load(ctx: PageContext): CardsData {
  return {
    cards: rows(
      ctx,
      `SELECT c.id,c.last_four,c.status,a.account_number FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? ORDER BY c.id LIMIT 200`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), accountNumber: String(r.account_number), lastFour: String(r.last_four), status: String(r.status) })),
    disputes: rows(
      ctx,
      `SELECT d.id,d.case_number,d.claimed_amount_minor_units,d.currency,d.state,d.deadline,a.account_number FROM disputes d JOIN accounts a ON a.dataset_id=d.dataset_id AND a.id=d.account_id WHERE d.dataset_id=? ORDER BY d.id LIMIT 100`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), caseNumber: String(r.case_number), accountNumber: String(r.account_number), amount: Number(r.claimed_amount_minor_units), currency: String(r.currency), state: String(r.state), deadline: String(r.deadline) })),
  };
}

export const cardsPage = definePage<CardsData, never>({
  load(ctx) {
    return { kind: 'ready', data: load(ctx) };
  },
  handle(_ctx, state, _event): Outcome<CardsData> {
    return rendered(state);
  },
  render(ctx, state) {
    const data = state.data;
    return {
      title: 'Cards and disputes',
      breadcrumbs: [HOME, { label: 'Cards', href: null }],
      body: html`
        <h2>Cards</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Card</th><th>Account</th><th>Status</th><th></th></tr>${data.cards.map(
          (c) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'card', id: c.id })}">•••• ${c.lastFour}</a></td><td>${accountLink(c.accountNumber)}</td><td>${c.status}</td>
            <td><a href="${pageHref('Operation.aspx', { op: 'card.lock.update', account: c.accountNumber })}">lock/unlock</a> · <a href="${pageHref('Operation.aspx', { op: 'card.limit.update', account: c.accountNumber })}">limit</a> · <a href="${pageHref('Operation.aspx', { op: 'card.replace', account: c.accountNumber })}">replace</a></td></tr>`,
        )}</table>
        <h2>Disputes</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Dispute</th><th>Account</th><th>Claimed</th><th>State</th><th>Deadline</th><th></th></tr>${data.disputes.map(
          (d) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'dispute', id: d.id })}">${d.caseNumber}</a></td><td>${accountLink(d.accountNumber)}</td><td class="amount">${moneyCell(ctx, d.amount, d.currency)}</td><td>${d.state}</td><td>${day(d.deadline)}</td>
            <td><a href="${pageHref('Operation.aspx', { op: 'dispute.provisional_credit.issue', dispute: d.id })}">credit</a> · <a href="${pageHref('Operation.aspx', { op: 'dispute.evidence.submit', dispute: d.id })}">evidence</a> · <a href="${pageHref('Operation.aspx', { op: 'dispute.settle', dispute: d.id })}">settle</a></td></tr>`,
        )}</table>
        <p class="hint"><a href="${pageHref('Operation.aspx', { op: 'dispute.open' })}">Open a dispute</a></p>`,
    };
  },
});
