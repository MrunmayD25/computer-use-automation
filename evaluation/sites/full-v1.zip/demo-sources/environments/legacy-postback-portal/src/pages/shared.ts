import type { FinanceRecordKind, MemberRow, AccountRow, CaseRow } from '@computer-use/financial-database/services';

import type { ListItem } from '../controls.js';
import { formatDate, formatDateTime } from '../format.js';
import { html, type HtmlValue, type SafeHtml } from '../html.js';
import type { Crumb, Link } from '../layout.js';
import { formatMoney } from '../money.js';
import { pageHref, safeReturnUrl } from '../page-names.js';
import type { LoadOutcome, PageContext } from '../runtime.js';
import { accountSubject, memberSubject, row, rows } from '../ops/subjects.js';

export const HOME: Crumb = { label: 'Home', href: 'Default.aspx' };

export function notFound(title: string, message: string, links: readonly Link[]): LoadOutcome<never> {
  return { kind: 'not-found', title, message, links };
}

export function detailsTable(entries: readonly (readonly [string, HtmlValue])[], id?: string): SafeHtml {
  return html`<table class="details"${id === undefined ? '' : html` id="${id}"`}>${entries.map(
    ([label, value]) => html`<tr><th scope="row">${label}</th><td>${value}</td></tr>`,
  )}</table>`;
}

/** Converts a 1-based `page` query value to a 0-based page index. */
export function pageIndexFrom(value: string | null): number {
  const number = Number(value);
  return Number.isSafeInteger(number) && number >= 1 ? number - 1 : 0;
}

export function listCrumb(ctx: PageContext, label: string, fallback: string): Crumb {
  return { label, href: safeReturnUrl(ctx.query.get('ReturnUrl')) ?? fallback };
}

/** Formats minor units at the code's stored exponent. */
export function money(ctx: PageContext, minorUnits: number, currency: string): string {
  const exponent = Number(row(ctx, 'SELECT exponent FROM currencies WHERE code=?', currency)?.exponent ?? 2);
  return formatMoney(minorUnits, exponent, currency);
}

export function currencyExponent(ctx: PageContext, currency: string): number {
  return Number(row(ctx, 'SELECT exponent FROM currencies WHERE code=?', currency)?.exponent ?? 2);
}

export function memberLink(memberNumber: string, text = memberNumber): SafeHtml {
  return html`<a href="${pageHref('MemberDetail.aspx', { member: memberNumber })}">${text}</a>`;
}

export function accountLink(accountNumber: string): SafeHtml {
  return html`<a href="${pageHref('AccountDetail.aspx', { account: accountNumber })}">${accountNumber}</a>`;
}

export function caseLink(caseNumber: string): SafeHtml {
  return html`<a href="${pageHref('CaseDetail.aspx', { case: caseNumber })}">${caseNumber}</a>`;
}

export function requestLink(requestNumber: string): SafeHtml {
  return html`<a href="${pageHref('RequestDetail.aspx', { request: requestNumber })}">${requestNumber}</a>`;
}

export function documentLink(versionId: string, text = 'Document'): SafeHtml {
  return html`<a href="${pageHref('DocumentDetail.aspx', { version: versionId })}">${text}</a>`;
}

/** Action link into the generic operation form, carrying the resolved subject references. */
export function opLink(kind: string, label: string, subjects: Readonly<Record<string, string>> = {}): SafeHtml {
  return html`<a class="action-link" href="${pageHref('Operation.aspx', { op: kind, ...subjects })}">${label}</a>`;
}

export function memberCaption(ctx: PageContext, memberNumber: string): string {
  const subject = memberSubject(ctx, memberNumber);
  return subject.kind === 'found' ? subject.subject.label : memberNumber;
}

export function accountCaption(ctx: PageContext, accountNumber: string): string {
  const subject = accountSubject(ctx, accountNumber);
  return subject.kind === 'found' ? subject.subject.label : accountNumber;
}

export function memberItems(ctx: PageContext): ListItem[] {
  return [
    { value: '', text: '-- Select member --' },
    ...rows(ctx, `SELECT m.member_number,p.display_name FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE m.dataset_id=? ORDER BY m.member_number LIMIT 200`, ctx.binding.datasetId).map(
      (r) => ({ value: String(r.member_number), text: `${String(r.member_number)} — ${String(r.display_name)}` }),
    ),
  ];
}

export function statusChip(status: string): SafeHtml {
  return html`<span class="status-${status}">${status}</span>`;
}

export const when = formatDateTime;
export const day = formatDate;

/** Money cell for a grid row; records expose currency per row. */
export function moneyCell(ctx: PageContext, minorUnits: number, currency: string): SafeHtml {
  return html`<span class="amount">${money(ctx, minorUnits, currency)}</span>`;
}

export type { MemberRow, AccountRow, CaseRow, FinanceRecordKind };
