import { memberDetail, type MemberDetail } from '@computer-use/financial-database/services';

import { gridView } from '../grid.js';
import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, rejectionError, rendered, type LoadOutcome, type Outcome, type PageContext, type PageState } from '../runtime.js';
import { cell, memberSubject, rows } from '../ops/subjects.js';
import { FieldCheck } from '../validation.js';
import { accountLink, caseLink, day, detailsTable, documentLink, HOME, listCrumb, money, notFound, requestLink, when } from './shared.js';

interface DetailData {
  readonly memberId: string;
  readonly memberNumber: string;
  /** Account id whose row is in edit mode, plus the version captured when editing began. */
  readonly editing: { accountId: string; accountNumber: string; expectedVersion: number } | null;
}

type DetailEvent =
  | { readonly kind: 'add-note' }
  | { readonly kind: 'edit-account'; readonly accountId: string }
  | { readonly kind: 'update-account'; readonly accountId: string }
  | { readonly kind: 'cancel-edit' };

const MEMBER_OPS: readonly { kind: string; label: string }[] = [
  { kind: 'contact.update', label: 'Update contact' },
  { kind: 'member.legal_name.update', label: 'Update legal name' },
  { kind: 'member.preferred_name.update', label: 'Update preferred name' },
  { kind: 'member.identity_evidence.register', label: 'Register identity evidence' },
  { kind: 'member.identity.verify', label: 'Verify identity' },
  { kind: 'member.tax_classification.update', label: 'Update tax classification' },
  { kind: 'member.beneficial_owners.update', label: 'Update beneficial owners' },
  { kind: 'member.deceased.record', label: 'Record deceased' },
  { kind: 'account.open', label: 'Open account' },
  { kind: 'case.open', label: 'Open case' },
  { kind: 'document.index', label: 'Index document' },
  { kind: 'consent.delivery.record', label: 'Record consent' },
  { kind: 'consent.withdraw', label: 'Withdraw consent' },
  { kind: 'document.customer_export.create', label: 'Customer export' },
  { kind: 'communication.preference.update', label: 'Communication preference' },
  { kind: 'communication.send', label: 'Send communication' },
  { kind: 'maintenance.address.reconcile', label: 'Reconcile address' },
  { kind: 'maintenance.address.destination.update', label: 'Update address destination' },
  { kind: 'beneficiary.create', label: 'Create beneficiary' },
  { kind: 'beneficiary.verify', label: 'Verify beneficiary' },
  { kind: 'beneficiary.routing.update', label: 'Update beneficiary routing' },
  { kind: 'beneficiary.retire', label: 'Retire beneficiary' },
  { kind: 'loan.application.prepare', label: 'Prepare loan application' },
  { kind: 'batch.import', label: 'Import batch' },
];

function detail(ctx: PageContext): MemberDetail | undefined {
  const subject = memberSubject(ctx, ctx.query.get('member') ?? '');
  if (subject.kind !== 'found') return undefined;
  return ctx.read((db) => memberDetail(db, ctx.binding.datasetId, subject.subject.id, ctx.reader()));
}

export const memberDetailPage = definePage<DetailData, DetailEvent>({
  load(ctx): LoadOutcome<DetailData> {
    const found = detail(ctx);
    if (found === undefined) {
      return notFound('Member not found', 'No member with that number exists in this dataset.', [
        { href: 'Members.aspx', label: 'Back to members' },
      ]);
    }
    return {
      kind: 'ready',
      data: { memberId: found.member.id, memberNumber: found.member.memberNumber, editing: null },
      fields: { noteVisibility: 'general', noteText: '' },
    };
  },

  handle(ctx, state, event): Outcome<DetailData> {
    if (event?.kind === 'edit-account') {
      const account = ctx.read((db, datasetId) =>
        memberDetail(db, datasetId, state.data.memberId, ctx.reader())?.accounts.find((a) => a.id === event.accountId),
      );
      if (account === undefined) {
        state.errors.push({ field: null, message: 'That account is no longer on this member.' });
        return rendered(state);
      }
      state.data = { ...state.data, editing: { accountId: account.id, accountNumber: account.accountNumber, expectedVersion: account.version } };
      state.fields.nickname = account.nickname;
      state.fields.delivery = account.statementDelivery;
      return rendered(state);
    }
    if (event?.kind === 'cancel-edit') {
      state.data = { ...state.data, editing: null };
      return rendered(state);
    }
    if (event?.kind === 'update-account') {
      const editing = state.data.editing;
      if (editing === null || editing.accountId !== event.accountId) return rendered(state);
      const check = new FieldCheck(state.fields);
      const nickname = check.text('nickname', 'Nickname', { required: true, max: 80 });
      const delivery = check.choice('delivery', 'Statement delivery', ['electronic', 'paper'] as const);
      if (!check.ok || delivery === undefined) {
        state.errors.push(...check.errors);
        return rendered(state);
      }
      const nicknameOutcome = ctx.execute(
        { kind: 'account.nickname.update', accountId: editing.accountId, expectedVersion: editing.expectedVersion, nickname },
        'update-account-nickname',
        state.formKey,
      );
      if (nicknameOutcome.kind === 'rejected') return rejectionError(state, nicknameOutcome);
      if (nicknameOutcome.kind === 'unchanged') {
        state.notice = nicknameOutcome.message;
        return rendered(state);
      }
      const deliveryOutcome = ctx.execute(
        {
          kind: 'account.statement_delivery.update',
          accountId: editing.accountId,
          expectedVersion: editing.expectedVersion + (nicknameOutcome.kind === 'committed' ? 1 : 0),
          statementDelivery: delivery,
        },
        'update-account-delivery',
        state.formKey,
      );
      if (deliveryOutcome.kind === 'rejected') return rejectionError(state, deliveryOutcome);
      return redirectTo(pageHref('MemberDetail.aspx', { member: state.data.memberNumber, msg: 'account-updated' }));
    }
    if (event?.kind !== 'add-note') return rendered(state);
    const check = new FieldCheck(state.fields);
    const visibility = check.choice('noteVisibility', 'Visibility', ['general', 'restricted'] as const);
    const text = check.text('noteText', 'Note text', { required: true, max: 2000 });
    if (!check.ok) {
      state.errors.push(...check.errors);
      return rendered(state);
    }
    const outcome = ctx.execute({ kind: 'member.note.add', memberId: state.data.memberId, visibility: visibility ?? 'general', text }, 'add-note', state.formKey);
    switch (outcome.kind) {
      case 'committed':
      case 'duplicate':
        return redirectTo(pageHref('MemberDetail.aspx', { member: state.data.memberNumber, msg: 'note-added' }));
      case 'unchanged':
        state.notice = outcome.message;
        return rendered(state);
      case 'rejected':
        return rejectionError(state, outcome);
    }
  },

  render(ctx, state, view) {
    const found = detail(ctx);
    if (found === undefined) {
      return {
        title: 'Member not found',
        breadcrumbs: [HOME, { label: 'Members', href: 'Members.aspx' }],
        body: html`<p>This member no longer exists.</p>`,
      };
    }
    const grid = gridView<DetailEvent>(view);
    const member = found.member;
    const name = found.person !== null ? `${found.person.legalGiven} ${found.person.legalFamily}` : found.organization?.legalName ?? member.displayName;
    const actions = html`<div class="action-bar">${MEMBER_OPS.map(
      (op) => html`<a class="action-link" href="${pageHref('Operation.aspx', { op: op.kind, member: member.memberNumber })}">${op.label}</a>`,
    )}</div>`;
    return {
      title: `Member ${member.memberNumber}`,
      breadcrumbs: [HOME, listCrumb(ctx, 'Members', 'Members.aspx'), { label: member.memberNumber, href: null }],
      body: html`
        ${found.redirectTo === null ? '' : html`<div class="notice warning">This member was merged into <a href="${pageHref('MemberDetail.aspx', { member: found.redirectTo.memberNumber })}">${found.redirectTo.memberNumber}</a>.</div>`}
        ${detailsTable([
          ['Member number', member.memberNumber],
          ['Name', name],
          ['Kind', member.kind],
          ['Status', member.status],
          ['Tax classification', member.taxClassification],
          ['Joined', day(member.joinedAt)],
          ['Email', found.email?.value ?? '—'],
          ['Phone', found.phone?.value ?? '—'],
          ['Address', found.address === null ? '—' : `${found.address.line1}, ${found.address.city}, ${found.address.region} ${found.address.postalCode} ${found.address.country}`],
          ['Version', String(member.version)],
          ['Record id', member.id],
        ])}
        ${actions}
        <h2>Accounts</h2>
        ${grid({
          id: 'grdAccounts',
          rows: [...found.accounts],
          emptyText: 'No accounts.',
          rowClass: (r) => (state.data.editing?.accountId === r.id ? 'editing' : null),
          columns: [
            { header: 'Account', cell: (r) => accountLink(r.accountNumber) },
            { header: 'Product', cell: (r) => r.productCode },
            {
              header: 'Nickname',
              cell: (r, rowView) =>
                state.data.editing?.accountId === r.id
                  ? rowView.textBox('txtNickname', { field: 'nickname', maxLength: 80 })
                  : r.nickname,
            },
            {
              header: 'Delivery',
              cell: (r, rowView) =>
                state.data.editing?.accountId === r.id
                  ? rowView.dropDownList('ddlDelivery', {
                      field: 'delivery',
                      items: [
                        { value: 'electronic', text: 'Electronic' },
                        { value: 'paper', text: 'Paper' },
                      ],
                    })
                  : r.statementDelivery,
            },
            { header: 'Status', cell: (r) => r.status },
            { header: 'Posted', cell: (r) => money(ctx, r.postedMinorUnits, r.currency) },
            { header: 'Available', cell: (r) => money(ctx, r.availableMinorUnits, r.currency) },
            {
              header: '',
              cell: (r, rowView) =>
                state.data.editing === null
                  ? rowView.linkButton('lnkEdit', 'Edit', { kind: 'edit-account', accountId: r.id })
                  : state.data.editing.accountId === r.id
                    ? html`${rowView.linkButton('lnkUpdate', 'Update', { kind: 'update-account', accountId: r.id })} ${rowView.linkButton('lnkCancel', 'Cancel', { kind: 'cancel-edit' })}`
                    : rowView.linkButton('lnkEdit', 'Edit', { kind: 'edit-account', accountId: r.id }),
            },
          ],
        })}
        <h2>Cases</h2>
        ${grid({
          id: 'grdCases',
          rows: [...found.cases],
          emptyText: 'No cases.',
          columns: [
            { header: 'Case', cell: (r) => caseLink(r.caseNumber) },
            { header: 'Queue', cell: (r) => r.queueCode },
            { header: 'State', cell: (r) => r.state },
            { header: 'Priority', cell: (r) => r.priority },
            { header: 'Summary', cell: (r) => r.summary },
            { header: 'Due', cell: (r) => day(r.dueAt) },
          ],
        })}
        <h2>Notes${found.restrictedNotesWithheld > 0 ? html` <span class="hint">(${found.restrictedNotesWithheld} restricted withheld)</span>` : ''}</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>When</th><th>By</th><th>Visibility</th><th>Note</th></tr>${found.notes.map(
          (note) => html`<tr class="grid-row"><td>${when(note.createdAt)}</td><td>${note.actor === null ? 'system' : `${note.actor.actorNumber} ${note.actor.displayName}`}</td><td>${note.visibility}</td><td>${note.text}</td></tr>`,
        )}</table>
        <h3>Add note</h3>
        <table class="form"><tr><th scope="row">${view.label('ddlNoteVisibility', 'Visibility')}</th><td>${view.dropDownList('ddlNoteVisibility', {
          field: 'noteVisibility',
          items: [
            { value: 'general', text: 'General' },
            { value: 'restricted', text: 'Restricted' },
          ],
        })}</td></tr><tr><th scope="row">${view.label('txtNote', 'Note')}</th><td>${view.textArea('txtNote', { field: 'noteText', rows: 3, maxLength: 2000 })}</td></tr></table>
        <div class="actions">${view.button('btnAddNote', 'Add note', { kind: 'add-note' })}</div>
        <h2>Identity evidence</h2>
        ${evidenceGrid(ctx, state)}
        <h2>Documents</h2>
        ${documentGrid(ctx, state)}
        <h2>Requests</h2>
        ${requestGrid(ctx, state)}
        <p class="hint"><a href="${pageHref('RequestEdit.aspx', { member: member.memberNumber })}">New request for this member</a></p>
        <p class="hint"><a href="${pageHref('Searches.aspx', { member: member.memberNumber })}">Saved searches</a> · <a href="${pageHref('Activity.aspx', { member: member.id })}">Member activity</a></p>`,
    };
  },
});

function evidenceGrid(ctx: PageContext, state: PageState<DetailData>) {
  const rows_ = ctx.read((db) =>
    db.prepare("SELECT e.id,e.kind,e.status,e.issued_at,e.expires_at,e.reference FROM identity_evidence e JOIN members m ON m.dataset_id=? AND m.id=? AND e.dataset_id=m.dataset_id AND e.party_id=m.party_id ORDER BY e.issued_at").all(ctx.binding.datasetId, state.data.memberId) as Record<string, unknown>[],
  );
  return html`<table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Evidence</th><th>Kind</th><th>Status</th><th>Issued</th><th>Expires</th><th>Reference</th></tr>${rows_.map(
    (r) => html`<tr class="grid-row"><td>${cell(r.id)}</td><td>${cell(r.kind)}</td><td>${cell(r.status)}</td><td>${cell(r.issued_at).slice(0, 10)}</td><td>${r.expires_at === null ? '—' : cell(r.expires_at).slice(0, 10)}</td><td>${cell(r.reference)}</td></tr>`,
  )}</table>`;
}

function documentGrid(ctx: PageContext, state: PageState<DetailData>) {
  const documents = rows(
    ctx,
    `SELECT v.id AS version_id,d.display_name,d.document_type,v.version,v.media_type,v.status,v.issued_at FROM document_versions v JOIN documents d ON d.dataset_id=v.dataset_id AND d.id=v.document_id JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id WHERE v.dataset_id=? AND m.id=? ORDER BY v.issued_at DESC LIMIT 50`,
    ctx.binding.datasetId,
    state.data.memberId,
  );
  return html`<table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Document</th><th>Type</th><th>Version</th><th>Media</th><th>Status</th><th>Issued</th></tr>${documents.map(
    (r) => html`<tr class="grid-row"><td>${documentLink(String(r.version_id), String(r.display_name))}</td><td>${String(r.document_type)}</td><td>${String(r.version)}</td><td>${String(r.media_type)}</td><td>${String(r.status)}</td><td>${String(r.issued_at).slice(0, 10)}</td></tr>`,
  )}</table>`;
}

function requestGrid(ctx: PageContext, state: PageState<DetailData>) {
  const requests = rows(
    ctx,
    `SELECT request_number,subject,state,updated_at FROM maintenance_requests WHERE dataset_id=? AND member_id=? ORDER BY created_at DESC LIMIT 50`,
    ctx.binding.datasetId,
    state.data.memberId,
  );
  return html`<table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Request</th><th>Subject</th><th>State</th><th>Updated</th></tr>${requests.map(
    (r) => html`<tr class="grid-row"><td>${requestLink(String(r.request_number))}</td><td>${String(r.subject)}</td><td>${String(r.state)}</td><td>${when(String(r.updated_at))}</td></tr>`,
  )}</table>`;
}
