import { specPageHost, type OpData, type OpEvent } from '../ops/engine.js';
import { operationSpec } from '../ops/specs.js';
import { definePage, type PageDefinition } from '../runtime.js';

const spec = operationSpec('account.open');
if (spec === undefined) throw new Error('account.open spec missing.');

const host: PageDefinition<OpData, OpEvent> = specPageHost(spec);

export const accountOpenPage = definePage<OpData, OpEvent>({
  load: (ctx) => host.load(ctx),
  handle: (ctx, state, event) => host.handle(ctx, state, event),
  render: (ctx, state, view) => host.render(ctx, state, view),
});
