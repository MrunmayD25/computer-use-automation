import type { PageName } from '../page-names.js';
import type { RegisteredPage } from '../runtime.js';
import { accountDetailPage } from './account-detail.js';
import { accountOpenPage } from './account-open.js';
import { accountsPage } from './accounts.js';
import { activityPage } from './activity.js';
import { approvalsPage } from './approvals.js';
import { batchesPage } from './batches.js';
import { cardsPage } from './cards.js';
import { caseDetailPage } from './case-detail.js';
import { casesPage } from './cases.js';
import { defaultPage } from './default.js';
import { documentDetailPage } from './document-detail.js';
import { documentsPage } from './documents.js';
import { loansPage } from './loans.js';
import { memberDetailPage } from './member-detail.js';
import { memberNewPage } from './member-new.js';
import { membersPage } from './members.js';
import { operationPage } from '../ops/engine.js';
import { operatorPage } from './operator.js';
import { paymentsPage } from './payments.js';
import { receiptPage } from './receipt.js';
import { recordPage } from './record.js';
import { requestDetailPage } from './request-detail.js';
import { requestEditPage } from './request-edit.js';
import { requestPrintPage } from './request-print.js';
import { requestsPage } from './requests.js';
import { searchesPage } from './searches.js';
import { statementsPage } from './statements.js';
import { transactionsPage } from './transactions.js';

export const PAGES: Readonly<Record<PageName, RegisteredPage>> = {
  'Default.aspx': defaultPage,
  'Members.aspx': membersPage,
  'MemberNew.aspx': memberNewPage,
  'MemberDetail.aspx': memberDetailPage,
  'Accounts.aspx': accountsPage,
  'AccountOpen.aspx': accountOpenPage,
  'AccountDetail.aspx': accountDetailPage,
  'Transactions.aspx': transactionsPage,
  'Receipt.aspx': receiptPage,
  'Statements.aspx': statementsPage,
  'Activity.aspx': activityPage,
  'Cases.aspx': casesPage,
  'CaseDetail.aspx': caseDetailPage,
  'Documents.aspx': documentsPage,
  'DocumentDetail.aspx': documentDetailPage,
  'Payments.aspx': paymentsPage,
  'Cards.aspx': cardsPage,
  'Loans.aspx': loansPage,
  'Batches.aspx': batchesPage,
  'Requests.aspx': requestsPage,
  'RequestEdit.aspx': requestEditPage,
  'RequestDetail.aspx': requestDetailPage,
  'RequestPrint.aspx': requestPrintPage,
  'Approvals.aspx': approvalsPage,
  'Searches.aspx': searchesPage,
  'Operator.aspx': operatorPage,
  'Operation.aspx': operationPage,
  'Record.aspx': recordPage,
};
