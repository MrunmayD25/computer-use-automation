import { maintenanceRequest, type MaintenanceRequestSummary } from '@computer-use/financial-database/services';

import { html, type HtmlValue } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { requestSubject, row } from '../ops/subjects.js';
import { detailsTable, documentLink, HOME, listCrumb, memberLink, notFound, when } from './shared.js';

interface DetailData {
  readonly requestId: string;
  readonly requestNumber: string;
}

function find(ctx: PageContext): MaintenanceRequestSummary | undefined | { denied: string } {
  const subject = requestSubject(ctx, ctx.query.get('request') ?? '');
  if (subject.kind !== 'found') return undefined;
  const result = ctx.svc((db, context) => maintenanceRequest(db, context, subject.subject.id));
  if (result.kind === 'rejected') return { denied: result.message };
  return result.value;
}

function actionBar(request: MaintenanceRequestSummary): HtmlValue {
  const requestRef = { request: request.requestNumber };
  const items = [
    request.state === 'draft' ? html`<a class="action-link" href="${pageHref('RequestEdit.aspx', requestRef)}">Edit draft</a>` : null,
    request.state === 'draft' ? html`<a class="action-link" href="${pageHref('Operation.aspx', { op: 'maintenance.request.submit', ...requestRef })}">Submit for review</a>` : null,
    request.state === 'draft' ? html`<a class="action-link" href="${pageHref('Operation.aspx', { op: 'edit.cancel', ...requestRef })}">Cancel draft</a>` : null,
    ['draft', 'submitted'].includes(request.state) ? html`<a class="action-link" href="${pageHref('Operation.aspx', { op: 'maintenance.request.withdraw', ...requestRef })}">Withdraw</a>` : null,
    request.state === 'submitted' ? html`<a class="action-link" href="${pageHref('Operation.aspx', { op: 'maintenance.request.review', ...requestRef })}">Review</a>` : null,
    request.state === 'approved' ? html`<a class="action-link" href="${pageHref('Operation.aspx', { op: 'maintenance.request.process', ...requestRef })}">Process</a>` : null,
    html`<a class="action-link" href="${pageHref('RequestPrint.aspx', requestRef)}">Printable detail</a>`,
  ];
  return html`<div class="action-bar">${items.filter((item) => item !== null)}</div>`;
}

export const requestDetailPage = definePage<DetailData, never>({
  load(ctx): LoadOutcome<DetailData> {
    const found = find(ctx);
    if (found === undefined) {
      return notFound('Request not found', 'No maintenance request with that number exists.', [
        { href: 'Requests.aspx', label: 'Back to requests' },
      ]);
    }
    if ('denied' in found) return notFound('Request restricted', found.denied, [{ href: 'Requests.aspx', label: 'Back to requests' }]);
    return { kind: 'ready', data: { requestId: found.id, requestNumber: found.requestNumber } };
  },
  handle(_ctx, state, _event): Outcome<DetailData> {
    return rendered(state);
  },
  render(ctx, _state) {
    const found = find(ctx);
    if (found === undefined || 'denied' in found) {
      return { title: 'Request', breadcrumbs: [HOME, { label: 'Requests', href: 'Requests.aspx' }], body: html`<p>This request is no longer available.</p>` };
    }
    const member = row(ctx, 'SELECT m.member_number,p.display_name FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE m.dataset_id=? AND m.id=?', ctx.binding.datasetId, found.memberId);
    const account = found.accountId === null ? null : row(ctx, 'SELECT account_number FROM accounts WHERE dataset_id=? AND id=?', ctx.binding.datasetId, found.accountId);
    return {
      title: `Request ${found.requestNumber}`,
      breadcrumbs: [HOME, listCrumb(ctx, 'Requests', 'Requests.aspx'), { label: found.requestNumber, href: null }],
      body: html`
        ${detailsTable([
          ['Request', found.requestNumber],
          ['Member', member === undefined ? '—' : memberLink(String(member.member_number), `${String(member.display_name)} (${String(member.member_number)})`)],
          ['Account', account === null || account === undefined ? '—' : html`<a href="${pageHref('AccountDetail.aspx', { account: String(account.account_number) })}">${String(account.account_number)}</a>`],
          ['Category', found.category],
          ['Reason', found.reason ?? '—'],
          ['Subject', found.subject],
          ['State', found.state],
          ['Created', when(found.createdAt)],
          ['Updated', when(found.updatedAt)],
          ['Applied receipt', found.appliedReceiptId ?? '—'],
        ])}
        ${actionBar(found)}
        <h2>Requested change</h2>
        <pre class="receipt-json">${JSON.stringify(found.draft, null, 2)}</pre>
        <h2>Attachments</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Document version</th><th>Purpose</th></tr>${found.attachments.map(
          (a) => html`<tr class="grid-row"><td>${documentLink(a.documentVersionId)}</td><td>${a.purpose}</td></tr>`,
        )}</table>`,
    };
  },
});
