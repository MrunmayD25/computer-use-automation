import { receiptByNumber, type Receipt } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { cell, row } from '../ops/subjects.js';
import { day, detailsTable, HOME, notFound, when } from './shared.js';

interface ReceiptData {
  readonly receiptNumber: string;
}

function find(ctx: PageContext): Receipt | undefined {
  const number = ctx.query.get('no') ?? '';
  return ctx.read((db) => receiptByNumber(db, ctx.binding.datasetId, number));
}

export const receiptPage = definePage<ReceiptData, never>({
  load(ctx): LoadOutcome<ReceiptData> {
    const receipt = find(ctx);
    if (receipt === undefined) {
      return notFound('Receipt not found', 'No operation receipt with that number exists in this dataset.', [
        { href: 'Activity.aspx', label: 'Activity' },
      ]);
    }
    return { kind: 'ready', data: { receiptNumber: receipt.receiptNumber } };
  },
  handle(_ctx, state, _event): Outcome<ReceiptData> {
    return rendered(state);
  },
  render(ctx, _state) {
    const receipt = find(ctx);
    if (receipt === undefined) {
      return { title: 'Receipt not found', breadcrumbs: [HOME], body: html`<p>This receipt no longer exists.</p>` };
    }
    const operation = row(ctx, 'SELECT operation_kind,idempotency_key,actor_id FROM operations WHERE dataset_id=? AND id=?', ctx.binding.datasetId, receipt.operationId);
    const receiptRow = row(ctx, 'SELECT id FROM operation_receipts WHERE dataset_id=? AND receipt_number=?', ctx.binding.datasetId, receipt.receiptNumber);
    const affected = receipt.affected.map(
      (record) => html`<tr class="grid-row"><td>${record.kind}</td><td><a href="${pageHref('Record.aspx', { kind: record.kind, id: record.id })}">${record.id}</a></td><td>${record.label}</td></tr>`,
    );
    const rows = [
      ['Receipt number', receipt.receiptNumber],
      ['Receipt id', receiptRow === undefined ? '—' : String(receiptRow.id)],
      ['Status', receipt.status],
      ['Operation kind', receipt.operationKind],
      ['Business reference', receipt.businessReference],
      ['Committed at', when(receipt.committedAt)],
      ['Actor', `${receipt.actor.actorNumber} ${receipt.actor.displayName}`],
      ['Idempotency key', cell(operation?.idempotency_key) || '—'],
      ['Dataset', ctx.binding.datasetId],
    ] as const;
    const journals = receipt.journals.map(
      (journal) => html`<h3>Journal ${journal.reference} — ${day(journal.effectiveDate)}</h3><p class="hint">${journal.description}</p>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Line</th><th>Ledger</th><th>Account</th><th>Debit</th><th>Credit</th><th>Memo</th></tr>${journal.lines.map(
          (line) => html`<tr class="grid-row"><td>${line.lineNumber}</td><td>${line.ledgerCode}</td><td>${line.accountNumber ?? ''}</td><td class="amount">${line.debitMinorUnits}</td><td class="amount">${line.creditMinorUnits}</td><td>${line.memo}</td></tr>`,
        )}</table>`,
    );
    return {
      title: `Receipt ${receipt.receiptNumber}`,
      ...(ctx.query.get('print') === '1' ? { layout: 'print' as const } : {}),
      breadcrumbs: [HOME, { label: 'Receipt', href: null }],
      body: html`
        ${detailsTable(rows)}
        <h2>Affected records</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Kind</th><th>Record</th><th>Label</th></tr>${affected}</table>
        ${journals}
        <h2>Result</h2>
        <pre class="receipt-json">${JSON.stringify(receipt.result, null, 2)}</pre>
        <p class="hint"><a href="${pageHref('Receipt.aspx', { no: receipt.receiptNumber, print: '1' })}">Printable receipt</a> · <a href="Activity.aspx">All activity</a></p>`,
    };
  },
});
