import { documentContent, type DocumentRow } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { day, detailsTable, HOME, listCrumb, notFound, when } from './shared.js';

interface DetailData {
  readonly versionId: string;
}

interface DocumentView {
  readonly version: DocumentRow;
  readonly versions: readonly { versionId: string; version: number; issuedAt: string; status: string; byteLength: number }[];
  readonly annotations: readonly { page: number; text: string; kind: string; version: number }[];
}

type DetailEvent = { readonly kind: 'download' };

function find(ctx: PageContext): DocumentView | undefined {
  const versionId = ctx.query.get('version') ?? '';
  return ctx.read((db, datasetId) => {
    const row = db
      .prepare(
        `SELECT v.id AS version_id,d.id AS document_id,d.document_type,d.display_name,v.version,v.media_type,v.digest,b.byte_length,v.issued_at,v.period_start,v.period_end,v.page_count,v.status,d.account_id,d.owner_party_id
         FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest WHERE v.dataset_id=? AND v.id=?`,
      )
      .get(datasetId, versionId);
    if (row === undefined) return undefined;
    const documentId = String(row.document_id);
    const versions = db
      .prepare('SELECT v.id AS version_id,v.version,v.issued_at,v.status,b.byte_length FROM document_versions v JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest WHERE v.dataset_id=? AND v.document_id=? ORDER BY v.version')
      .all(datasetId, documentId) as Record<string, unknown>[];
    const annotations = db
      .prepare('SELECT page_number,text,status,created_at FROM document_annotations WHERE dataset_id=? AND document_version_id=? ORDER BY page_number,id')
      .all(datasetId, versionId) as Record<string, unknown>[];
    return {
      version: {
        versionId: String(row.version_id), documentId, documentType: String(row.document_type), displayName: String(row.display_name),
        version: Number(row.version), mediaType: String(row.media_type), digest: String(row.digest), byteLength: Number(row.byte_length),
        issuedAt: String(row.issued_at), periodStart: row.period_start === null ? null : String(row.period_start), periodEnd: row.period_end === null ? null : String(row.period_end),
        pageCount: row.page_count === null ? null : Number(row.page_count), status: String(row.status), accountId: row.account_id === null ? null : String(row.account_id), ownerPartyId: String(row.owner_party_id),
      },
      versions: versions.map((v) => ({ versionId: String(v.version_id), version: Number(v.version), issuedAt: String(v.issued_at), status: String(v.status), byteLength: Number(v.byte_length) })),
      annotations: annotations.map((a) => ({ page: Number(a.page_number), text: String(a.text), kind: String(a.status), version: 0 })),
    };
  });
}

const DOC_OPS: readonly { kind: string; label: string }[] = [
  { kind: 'document.bundle.redact', label: 'Redact bundle' },
  { kind: 'document.signature.collect', label: 'Collect signature' },
  { kind: 'document.annotation.update', label: 'Annotate' },
  { kind: 'document.metadata.update', label: 'Update metadata' },
];

export const documentDetailPage = definePage<DetailData, DetailEvent>({
  load(ctx): LoadOutcome<DetailData> {
    const found = find(ctx);
    if (found === undefined) {
      return notFound('Document not found', 'No document version with that id exists in this dataset.', [
        { href: 'Documents.aspx', label: 'Back to documents' },
      ]);
    }
    return { kind: 'ready', data: { versionId: found.version.versionId } };
  },
  handle(ctx, state, event): Outcome<DetailData> {
    if (event?.kind !== 'download') return rendered(state);
    const content = ctx.read((db) => documentContent(db, ctx.binding.datasetId, state.data.versionId, ctx.reader()));
    if (content === undefined) {
      state.errors.push({ field: null, message: 'The document bytes are no longer available.' });
      return rendered(state, 404);
    }
    return { kind: 'download', filename: content.displayName, contentType: content.mediaType, body: content.bytes };
  },
  render(ctx, _state, view) {
    const found = find(ctx);
    if (found === undefined) {
      return { title: 'Document', breadcrumbs: [HOME, { label: 'Documents', href: 'Documents.aspx' }], body: html`<p>This document is no longer available.</p>` };
    }
    const version = found.version;
    const actions = DOC_OPS.map(
      (op) => html`<a class="action-link" href="${pageHref('Operation.aspx', { op: op.kind, document: version.versionId })}">${op.label}</a>`,
    );
    return {
      title: version.displayName,
      breadcrumbs: [HOME, listCrumb(ctx, 'Documents', 'Documents.aspx'), { label: version.displayName, href: null }],
      body: html`
        ${detailsTable([
          ['Document', `${version.displayName} v${version.version}`],
          ['Type', version.documentType],
          ['Status', version.status],
          ['Media', `${version.mediaType} · ${version.byteLength} bytes`],
          ['Issued', when(version.issuedAt)],
          ['Period', version.periodStart === null ? '—' : `${day(version.periodStart)} to ${day(version.periodEnd ?? version.periodStart)}`],
          ['Digest', version.digest],
          ['Pages', version.pageCount === null ? '—' : String(version.pageCount)],
        ])}
        <div class="actions">${view.button('btnDownload', 'Download', { kind: 'download' })}</div>
        <div class="action-bar">${actions}</div>
        <h2>Versions</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Version</th><th>Issued</th><th>Status</th><th>Bytes</th></tr>${found.versions.map(
          (v) => html`<tr class="grid-row"><td><a href="${pageHref('DocumentDetail.aspx', { version: v.versionId })}">${v.version}</a></td><td>${when(v.issuedAt)}</td><td>${v.status}</td><td class="amount">${v.byteLength}</td></tr>`,
        )}</table>
        <h2>Annotations</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Page</th><th>Text</th><th>Status</th></tr>${found.annotations.map(
          (a) => html`<tr class="grid-row"><td>${a.page}</td><td>${a.text}</td><td>${a.kind}</td></tr>`,
        )}</table>`,
    };
  },
});
