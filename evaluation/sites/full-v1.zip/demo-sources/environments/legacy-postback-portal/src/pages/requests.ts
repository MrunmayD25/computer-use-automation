import { html } from '../html.js';
import { definePage, redirectTo, type Outcome, type PageContext } from '../runtime.js';
import { rows } from '../ops/subjects.js';
import { HOME, memberLink, requestLink, statusChip, when } from './shared.js';

interface RequestsData {
  readonly items: readonly { id: string; number: string; memberNumber: string; memberName: string; category: string; subject: string; state: string; updatedAt: string }[];
  readonly total: number;
}

type RequestsEvent = { readonly kind: 'find' };

function load(ctx: PageContext): RequestsData {
  const state = ctx.query.get('state') ?? '';
  const clauses = ['r.dataset_id=?'];
  const parameters: string[] = [ctx.binding.datasetId];
  if (state !== '') {
    clauses.push('r.state=?');
    parameters.push(state);
  }
  const items = rows(
    ctx,
    `SELECT r.id,r.request_number,r.category,r.subject,r.state,r.updated_at,m.member_number,p.display_name FROM maintenance_requests r JOIN members m ON m.dataset_id=r.dataset_id AND m.id=r.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE ${clauses.join(' AND ')} ORDER BY r.updated_at DESC LIMIT 200`,
    ...parameters,
  ).map((r) => ({ id: String(r.id), number: String(r.request_number), memberNumber: String(r.member_number), memberName: String(r.display_name), category: String(r.category), subject: String(r.subject), state: String(r.state), updatedAt: String(r.updated_at) }));
  return { items, total: items.length };
}

export const requestsPage = definePage<RequestsData, RequestsEvent>({
  load(ctx) {
    return { kind: 'ready', data: load(ctx), fields: { state: ctx.query.get('state') ?? '' } };
  },
  handle(_ctx, state): Outcome<RequestsData> {
    return redirectTo(`Requests.aspx${state.fields.state === '' ? '' : `?state=${encodeURIComponent(state.fields.state ?? '')}`}`);
  },
  render(_ctx, state, view) {
    const data = state.data;
    return {
      title: 'Requests',
      breadcrumbs: [HOME, { label: 'Requests', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('ddlState', 'State')} ${view.dropDownList('ddlState', {
            field: 'state',
            items: ['', 'draft', 'submitted', 'approved', 'applied', 'rejected', 'withdrawn', 'cancelled'].map((s) => ({ value: s, text: s === '' ? 'All states' : s })),
          })} ${view.button('btnFind', 'Find', { kind: 'find' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} request${data.total === 1 ? '' : 's'}. <a href="RequestEdit.aspx">New request</a>.</p>
        <table id="${'ctl00_MainContent_grdRequests'}" class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Request</th><th>Member</th><th>Category</th><th>Subject</th><th>State</th><th>Updated</th></tr>${data.items.length === 0 ? html`<tr class="grid-empty"><td colspan="6">No maintenance requests</td></tr>` : data.items.map(
          (r) => html`<tr class="grid-row"><td>${requestLink(r.number)}</td><td>${memberLink(r.memberNumber, r.memberName)}</td><td>${r.category}</td><td>${r.subject}</td><td>${statusChip(r.state)}</td><td>${when(r.updatedAt)}</td></tr>`,
        )}</table>`,
    };
  },
});
