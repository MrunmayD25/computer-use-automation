import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type Outcome, type PageContext } from '../runtime.js';
import { rows } from '../ops/subjects.js';
import { accountLink, HOME, memberLink, moneyCell } from './shared.js';

interface LoansData {
  readonly loans: readonly { id: string; accountNumber: string; memberNumber: string; memberName: string; principal: number; currency: string; state: string }[];
  readonly applications: readonly { id: string; memberNumber: string; memberName: string; amount: number; currency: string; state: string }[];
}

function load(ctx: PageContext): LoansData {
  return {
    loans: rows(
      ctx,
      `SELECT l.id,l.principal_minor_units,l.currency,l.state,a.account_number,m.member_number,p.display_name FROM loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE l.dataset_id=? ORDER BY l.id LIMIT 200`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), accountNumber: String(r.account_number), memberNumber: String(r.member_number), memberName: String(r.display_name), principal: Number(r.principal_minor_units), currency: String(r.currency), state: String(r.state) })),
    applications: rows(
      ctx,
      `SELECT la.id,la.requested_amount_minor_units,la.currency,la.state,m.member_number,p.display_name FROM loan_applications la JOIN members m ON m.dataset_id=la.dataset_id AND m.id=la.member_id JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE la.dataset_id=? ORDER BY la.id LIMIT 100`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), memberNumber: String(r.member_number), memberName: String(r.display_name), amount: Number(r.requested_amount_minor_units), currency: String(r.currency), state: String(r.state) })),
  };
}

export const loansPage = definePage<LoansData, never>({
  load(ctx) {
    return { kind: 'ready', data: load(ctx) };
  },
  handle(_ctx, state, _event): Outcome<LoansData> {
    return rendered(state);
  },
  render(ctx, state) {
    const data = state.data;
    return {
      title: 'Loans',
      breadcrumbs: [HOME, { label: 'Loans', href: null }],
      body: html`
        <h2>Loans</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Loan</th><th>Account</th><th>Member</th><th>Principal</th><th>State</th><th></th></tr>${data.loans.map(
          (l) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'loan', id: l.id })}">${l.id.slice(-8)}</a></td><td>${accountLink(l.accountNumber)}</td><td>${memberLink(l.memberNumber, l.memberName)}</td><td class="amount">${moneyCell(ctx, l.principal, l.currency)}</td><td>${l.state}</td>
            <td><a href="${pageHref('Operation.aspx', { op: 'loan.payment.allocate', loan: l.id })}">allocate payment</a> · <a href="${pageHref('Operation.aspx', { op: 'loan.payoff.quote', loan: l.id })}">payoff quote</a> · <a href="${pageHref('Operation.aspx', { op: 'loan.close', loan: l.id })}">close</a></td></tr>`,
        )}</table>
        <h2>Applications</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Application</th><th>Member</th><th>Requested</th><th>State</th></tr>${data.applications.map(
          (a) => html`<tr class="grid-row"><td>${a.id.slice(-8)}</td><td>${memberLink(a.memberNumber, a.memberName)}</td><td class="amount">${moneyCell(ctx, a.amount, a.currency)}</td><td>${a.state}</td></tr>`,
        )}</table>
        <p class="hint"><a href="${pageHref('Operation.aspx', { op: 'loan.application.prepare' })}">Prepare a loan application</a></p>`,
    };
  },
});
