import { listApprovals } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, rejectionError, rendered, type Outcome, type PageContext } from '../runtime.js';
import { cell, row } from '../ops/subjects.js';
import { FieldCheck } from '../validation.js';
import { HOME, money, when } from './shared.js';

interface ApprovalRow {
  readonly id: string;
  readonly status: string;
  readonly fingerprint: string;
  readonly kind: string;
  readonly target: string;
  readonly makerNumber: string;
  readonly checkerNumber: string;
  readonly expiresAt: string;
  readonly amountLimit: string;
  readonly mine: boolean;
}

interface ApprovalsData {
  readonly rows: readonly ApprovalRow[];
  readonly denied: string | null;
}

type ApprovalsEvent = { readonly kind: 'decide'; readonly approvalId: string; readonly decision: 'approve' | 'deny' };

function load(ctx: PageContext): ApprovalsData {
  const outcome = listApprovals(ctx.services.store, ctx.context('branchnet:approvals'));
  if (outcome.kind === 'rejected') return { rows: [], denied: outcome.message };
  const rows = outcome.approvals.map((approval) => {
    const target = approval.target as { kind?: unknown };
    const maker = row(ctx, 'SELECT actor_number FROM actors WHERE dataset_id=? AND id=(SELECT maker_actor_id FROM business_approvals WHERE dataset_id=? AND id=?)', ctx.binding.datasetId, ctx.binding.datasetId, approval.id);
    const checker = row(ctx, 'SELECT actor_number FROM actors WHERE dataset_id=? AND id=(SELECT checker_actor_id FROM business_approvals WHERE dataset_id=? AND id=?)', ctx.binding.datasetId, ctx.binding.datasetId, approval.id);
    return {
      id: approval.id,
      status: approval.status,
      fingerprint: approval.fingerprint,
      kind: cell(target.kind),
      target: JSON.stringify(approval.target),
      makerNumber: cell(maker?.actor_number) || '?',
      checkerNumber: cell(checker?.actor_number) || '?',
      expiresAt: approval.expiresAt,
      amountLimit: approval.amountLimit === null ? 'unbounded' : money(ctx, approval.amountLimit.minorUnits, approval.amountLimit.currency),
      mine: checker !== undefined && String(checker.actor_number) === ctx.actor.actorNumber,
    };
  });
  return { rows, denied: null };
}

export const approvalsPage = definePage<ApprovalsData, ApprovalsEvent>({
  load(ctx) {
    return { kind: 'ready', data: load(ctx), fields: {} };
  },
  handle(ctx, state, event): Outcome<ApprovalsData> {
    if (event === null) return rendered(state);
    const approval = state.data.rows.find((r) => r.id === event.approvalId);
    if (approval === undefined) {
      state.errors.push({ field: null, message: 'This approval is no longer listed.' });
      return rendered(state, 410);
    }
    const check = new FieldCheck(state.fields);
    const reason = check.text(`reason_${event.approvalId}`, 'Reason', { required: true, max: 300 });
    if (!check.ok) {
      state.errors.push(...check.errors);
      return rendered(state);
    }
    const outcome = ctx.execute(
      { kind: 'approval.decide', approvalId: approval.id, expectedFingerprint: approval.fingerprint, decision: event.decision, reason },
      `decide:${event.approvalId}:${event.decision}`,
      state.formKey,
    );
    switch (outcome.kind) {
      case 'committed':
      case 'duplicate':
        return redirectTo(pageHref('Approvals.aspx', { msg: 'approval-decided' }));
      case 'unchanged':
        state.notice = outcome.message;
        return rendered(state);
      case 'rejected':
        return rejectionError(state, outcome);
    }
  },
  render(ctx, state, view) {
    const data = state.data;
    return {
      title: 'Approvals',
      breadcrumbs: [HOME, { label: 'Approvals', href: null }],
      body: html`
        ${data.denied === null ? '' : html`<div class="notice warning">${data.denied}</div>`}
        <p class="hint">${data.rows.length} approval${data.rows.length === 1 ? '' : 's'} involving ${ctx.actor.actorNumber}. The checker executes the approved command; the maker cannot.</p>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Approval</th><th>Action</th><th>Status</th><th>Maker</th><th>Checker</th><th>Limit</th><th>Expires</th><th>Scope</th><th></th></tr>${data.rows.map(
          (approval) => html`<tr class="grid-row"><td>${approval.id.slice(-8)}</td><td><code>${approval.kind}</code></td><td>${approval.status}</td><td>${approval.makerNumber}</td><td>${approval.checkerNumber}</td><td class="amount">${approval.amountLimit}</td><td>${when(approval.expiresAt)}</td>
            <td><details><summary>scope</summary><pre class="receipt-json">${approval.target}</pre></details></td>
            <td>${approval.status === 'pending' && approval.mine ? html`${view.textBox(`txtReason_${approval.id.slice(-8)}`, { field: `reason_${approval.id}`, maxLength: 300, columns: 14 })} ${view.button(`btnApprove_${approval.id.slice(-8)}`, 'Approve', { kind: 'decide', approvalId: approval.id, decision: 'approve' })} ${view.button(`btnDeny_${approval.id.slice(-8)}`, 'Deny', { kind: 'decide', approvalId: approval.id, decision: 'deny' })}` : ''}
            ${approval.status === 'approved' && approval.mine ? html`<a class="action-link" href="${pageHref('Operation.aspx', { op: approval.kind, approval: approval.id })}">Execute</a>` : ''}</td></tr>`,
        )}</table>`,
    };
  },
});
