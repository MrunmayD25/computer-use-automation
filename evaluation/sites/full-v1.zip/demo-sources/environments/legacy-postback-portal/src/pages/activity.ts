import { listActivity, type ActivityRow } from '@computer-use/financial-database/services';

import { gridView } from '../grid.js';
import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, type Outcome, type PageContext } from '../runtime.js';
import { HOME, pageIndexFrom, when } from './shared.js';

const PAGE_SIZE = 25;

interface ActivityData {
  readonly items: readonly ActivityRow[];
  readonly total: number;
  readonly pageIndex: number;
}

type ActivityEvent = { readonly kind: 'find' } | { readonly kind: 'page'; readonly index: number };

function search(ctx: PageContext): ActivityData {
  const pageIndex = pageIndexFrom(ctx.query.get('page'));
  const member = ctx.query.get('member');
  const account = ctx.query.get('account');
  const scoped = ctx.query.get('case');
  const kind = ctx.query.get('kind');
  const result = ctx.read((db, datasetId) =>
    listActivity(db, datasetId, {
      ...(member === null ? {} : { memberId: member }),
      ...(account === null ? {} : { accountId: account }),
      ...(scoped === null ? {} : { caseId: scoped }),
      ...(kind === null || kind === '' ? {} : { kind }),
      query: ctx.query.get('q') ?? '',
      limit: PAGE_SIZE,
      offset: pageIndex * PAGE_SIZE,
    }),
  );
  return { items: result.items, total: result.total, pageIndex };
}

function queryUrl(ctx: PageContext, patch: Record<string, string | null>): string {
  const query = new URLSearchParams(ctx.query);
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) query.delete(key);
    else query.set(key, value);
  }
  const text = query.toString();
  return `Activity.aspx${text === '' ? '' : `?${text}`}`;
}

export const activityPage = definePage<ActivityData, ActivityEvent>({
  load(ctx) {
    return { kind: 'ready', data: search(ctx), fields: { q: ctx.query.get('q') ?? '', kind: ctx.query.get('kind') ?? '' } };
  },
  handle(ctx, state, event): Outcome<ActivityData> {
    if (event === null || event.kind === 'find') {
      return redirectTo(queryUrl(ctx, { q: (state.fields.q ?? '').trim() || null, kind: state.fields.kind || null, page: null }));
    }
    return redirectTo(queryUrl(ctx, { page: String(event.index + 1) }));
  },
  render(_ctx, state, view) {
    const data = state.data;
    const grid = gridView<ActivityEvent>(view);
    return {
      title: 'Activity',
      breadcrumbs: [HOME, { label: 'Activity', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('txtQ', 'Search')} ${view.textBox('txtQ', { field: 'q', maxLength: 80, columns: 20 })}
            ${view.label('txtKind', 'Event kind')} ${view.textBox('txtKind', { field: 'kind', maxLength: 60, columns: 18 })}
            ${view.button('btnFind', 'Find', { kind: 'find' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} event${data.total === 1 ? '' : 's'}.</p>
        ${grid({
          id: 'grdActivity',
          rows: [...data.items],
          emptyText: 'No activity matches.',
          columns: [
            { header: 'When', cell: (r) => when(r.occurredAt) },
            { header: 'Kind', cell: (r) => r.kind },
            { header: 'Record', cell: (r) => html`<a href="${pageHref('Record.aspx', { kind: r.resourceKind, id: r.resourceId })}">${r.resourceKind} ${r.resourceId.slice(-8)}</a>` },
            { header: 'Summary', cell: (r) => r.summary },
            { header: 'Actor', cell: (r) => (r.actor === null ? 'system' : r.actor.actorNumber) },
            { header: 'Receipt', cell: (r) => (r.receiptNumber === null ? '' : html`<a href="${pageHref('Receipt.aspx', { no: r.receiptNumber })}">${r.receiptNumber}</a>`) },
          ],
          paging: { pageIndex: data.pageIndex, pageSize: PAGE_SIZE, total: data.total, event: (index) => ({ kind: 'page', index }) },
        })}`,
    };
  },
});
