import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, rendered, type Outcome } from '../runtime.js';
import { resolveOperator } from '../financial.js';
import { FieldCheck } from '../validation.js';
import { detailsTable, HOME, when } from './shared.js';

interface OperatorData {
  readonly actorNumber: string;
}

type OperatorEvent = { readonly kind: 'switch' };

export const operatorPage = definePage<OperatorData, OperatorEvent>({
  load(ctx) {
    return { kind: 'ready', data: { actorNumber: ctx.session.actorNumber }, fields: { actor: ctx.session.actorNumber } };
  },
  handle(ctx, state, event): Outcome<OperatorData> {
    if (event === null) return rendered(state);
    const check = new FieldCheck(state.fields);
    const actorNumber = check.choice('actor', 'Operator', ctx.services.operators);
    if (actorNumber === undefined) {
      state.errors.push(...check.errors);
      return rendered(state);
    }
    const operator = resolveOperator(ctx.services.store, ctx.binding, actorNumber);
    if (operator === undefined) {
      state.errors.push({ field: 'actor', message: `Operator ${actorNumber} is not registered in this dataset.` });
      return rendered(state);
    }
    if (operator.status !== 'active') {
      state.errors.push({ field: 'actor', message: `Operator ${actorNumber} is ${operator.status}; sign on as an active operator.` });
      return rendered(state);
    }
    ctx.session.actorNumber = actorNumber;
    return redirectTo(pageHref('Operator.aspx', { msg: 'operator-switched' }));
  },
  render(ctx, _state, view) {
    return {
      title: 'Operator',
      breadcrumbs: [HOME, { label: 'Operator', href: null }],
      body: html`
        ${detailsTable([
          ['Signed on', `${ctx.actor.actorNumber} ${ctx.actor.displayName}`],
          ['Status', ctx.actor.status],
          ['Roles', ctx.actor.roles.join(', ')],
          ['Permissions', `${ctx.actor.permissions.size} grants`],
          ['Institution', ctx.institution.displayName],
          ['Business time', when(ctx.businessNow)],
        ])}
        <h2>Switch operator</h2>
        <table class="form"><tr><th scope="row">${view.label('ddlActor', 'Operator')}</th><td>${view.dropDownList('ddlActor', {
          field: 'actor',
          items: ctx.services.operators.map((number) => ({ value: number, text: number })),
        })}</td></tr></table>
        <div class="actions">${view.button('btnSwitch', 'Sign on', { kind: 'switch' }, { primary: true })}</div>`,
    };
  },
});
