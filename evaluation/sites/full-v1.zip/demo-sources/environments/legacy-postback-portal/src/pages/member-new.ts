import { specPageHost, type OpData, type OpEvent } from '../ops/engine.js';
import { operationSpec } from '../ops/specs.js';
import { definePage, type PageDefinition } from '../runtime.js';

const spec = operationSpec('member.create');
if (spec === undefined) throw new Error('member.create spec missing.');

const host: PageDefinition<OpData, OpEvent> = specPageHost(spec);

export const memberNewPage = definePage<OpData, OpEvent>({
  load: (ctx) => host.load(ctx),
  handle: (ctx, state, event) => host.handle(ctx, state, event),
  render: (ctx, state, view) => host.render(ctx, state, view),
});
