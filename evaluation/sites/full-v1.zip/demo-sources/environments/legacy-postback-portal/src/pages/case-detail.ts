import { caseDetail, type CaseDetail } from '@computer-use/financial-database/services';

import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type LoadOutcome, type Outcome, type PageContext } from '../runtime.js';
import { caseSubject } from '../ops/subjects.js';
import { accountLink, day, detailsTable, HOME, listCrumb, memberLink, notFound, when } from './shared.js';

interface DetailData {
  readonly caseId: string;
  readonly caseNumber: string;
}

function find(ctx: PageContext): CaseDetail | undefined {
  const subject = caseSubject(ctx, ctx.query.get('case') ?? '');
  if (subject.kind !== 'found') return undefined;
  return ctx.read((db) => caseDetail(db, ctx.binding.datasetId, subject.subject.id, ctx.reader()));
}

const CASE_OPS: readonly { kind: string; label: string }[] = [
  { kind: 'case.assign', label: 'Assign' },
  { kind: 'case.transition', label: 'Transition' },
  { kind: 'case.note.add', label: 'Add note' },
  { kind: 'case.information.request', label: 'Request information' },
  { kind: 'case.escalate', label: 'Escalate' },
  { kind: 'case.subject.correct', label: 'Correct subject' },
  { kind: 'case.close', label: 'Close' },
  { kind: 'case.reopen', label: 'Reopen' },
];

export const caseDetailPage = definePage<DetailData, never>({
  load(ctx): LoadOutcome<DetailData> {
    const found = find(ctx);
    if (found === undefined) {
      return notFound('Case not found', 'No case with that number exists in this dataset.', [
        { href: 'Cases.aspx', label: 'Back to cases' },
      ]);
    }
    return { kind: 'ready', data: { caseId: found.case.id, caseNumber: found.case.caseNumber } };
  },
  handle(_ctx, state, _event): Outcome<DetailData> {
    return rendered(state);
  },
  render(ctx, _state) {
    const found = find(ctx);
    if (found === undefined) {
      return { title: 'Case', breadcrumbs: [HOME, { label: 'Cases', href: 'Cases.aspx' }], body: html`<p>This case is no longer available.</p>` };
    }
    const record = found.case;
    const actions = CASE_OPS.map(
      (op) => html`<a class="action-link" href="${pageHref('Operation.aspx', { op: op.kind, case: record.caseNumber })}">${op.label}</a>`,
    );
    return {
      title: `Case ${record.caseNumber}`,
      breadcrumbs: [HOME, listCrumb(ctx, 'Cases', 'Cases.aspx'), { label: record.caseNumber, href: null }],
      body: html`
        ${detailsTable([
          ['Case number', record.caseNumber],
          ['Member', memberLink(record.memberNumber, `${record.memberName} (${record.memberNumber})`)],
          ['Account', record.accountNumber === null ? '—' : accountLink(record.accountNumber)],
          ['Queue', `${record.queueCode} ${record.queueName}`],
          ['State', `${record.state}${record.overdue ? ' — overdue' : ''}`],
          ['Priority', record.priority],
          ['Category', record.categoryLabel],
          ['Assigned', record.assignedName ?? '—'],
          ['Opened', when(record.openedAt)],
          ['Due', day(record.dueAt)],
          ['Version', String(record.version)],
          ['Allowed transitions', found.allowedTransitions.join(', ') || 'none'],
          ['Summary', record.summary],
        ])}
        <div class="action-bar">${actions}</div>
        <h2>Notes${found.restrictedNotesWithheld > 0 ? html` <span class="hint">(${found.restrictedNotesWithheld} restricted withheld)</span>` : ''}</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>When</th><th>By</th><th>Visibility</th><th>Note</th></tr>${found.notes.map(
          (note) => html`<tr class="grid-row"><td>${when(note.createdAt)}</td><td>${note.actor === null ? 'system' : note.actor.actorNumber}</td><td>${note.visibility}</td><td>${note.text}</td></tr>`,
        )}</table>
        <h2>Document evidence</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Version</th><th>Document</th><th>Purpose</th><th>Visibility</th><th>Issued</th></tr>${found.documents.map(
          (doc) => html`<tr class="grid-row"><td><a href="${pageHref('DocumentDetail.aspx', { version: doc.versionId })}">${doc.versionId.slice(-8)}</a></td><td>${doc.displayName}</td><td>${doc.purpose}</td><td>${doc.visibility}</td><td>${when(doc.issuedAt)}</td></tr>`,
        )}</table>
        <h2>Dependencies</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Kind</th><th>Reference</th><th>State</th><th>Due</th></tr>${found.dependencies.map(
          (d) => html`<tr class="grid-row"><td>${d.kind}</td><td>${d.referenceId}</td><td>${d.state}</td><td>${d.dueAt === null ? '—' : day(d.dueAt)}</td></tr>`,
        )}</table>
        <h2>SLA</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>State</th><th>From</th><th>To</th><th>Reason</th></tr>${found.sla.map(
          (s) => html`<tr class="grid-row"><td>${s.state}</td><td>${when(s.startsAt)}</td><td>${s.endsAt === null ? '—' : when(s.endsAt)}</td><td>${s.reason ?? ''}</td></tr>`,
        )}</table>
        <h2>Timeline</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>#</th><th>State</th><th>When</th><th>By</th><th>Detail</th></tr>${found.events.map(
          (e) => html`<tr class="grid-row"><td>${e.sequence}</td><td>${e.state}</td><td>${when(e.occurredAt)}</td><td>${e.actor === null ? 'system' : e.actor.actorNumber}</td><td>${e.detail}</td></tr>`,
        )}</table>`,
    };
  },
});
