import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, rendered, type Outcome, type PageContext } from '../runtime.js';
import { rows } from '../ops/subjects.js';
import { day, HOME, moneyCell, when } from './shared.js';

interface BatchesData {
  readonly batches: readonly { id: string; number: string; kind: string; state: string; items: number; applied: number; createdAt: string }[];
  readonly settlements: readonly { id: string; reference: string; currency: string; total: number; state: string; cutoff: string }[];
  readonly suspense: readonly { id: string; amount: number; remaining: number; currency: string; state: string }[];
  readonly runs: readonly { id: string; reference: string; kind: string; state: string; asOf: string }[];
  readonly sessions: readonly { id: string; branch: string; date: string; state: string }[];
}

function load(ctx: PageContext): BatchesData {
  return {
    batches: rows(
      ctx,
      `SELECT b.id,b.batch_number,b.kind,b.state,b.created_at,COUNT(i.id) AS items,SUM(CASE WHEN i.state='applied' THEN 1 ELSE 0 END) AS applied FROM batches b LEFT JOIN batch_items i ON i.dataset_id=b.dataset_id AND i.batch_id=b.id WHERE b.dataset_id=? GROUP BY b.id ORDER BY b.created_at DESC LIMIT 100`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), number: String(r.batch_number), kind: String(r.kind), state: String(r.state), items: Number(r.items), applied: Number(r.applied ?? 0), createdAt: String(r.created_at) })),
    settlements: rows(
      ctx,
      `SELECT id,reference,currency,declared_total_minor_units,state,cutoff_at FROM settlement_batches WHERE dataset_id=? ORDER BY id LIMIT 100`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), reference: String(r.reference), currency: String(r.currency), total: Number(r.declared_total_minor_units), state: String(r.state), cutoff: String(r.cutoff_at) })),
    suspense: rows(
      ctx,
      `SELECT id,original_amount_minor_units,remaining_amount_minor_units,currency,state FROM suspense_items WHERE dataset_id=? ORDER BY id LIMIT 100`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), amount: Number(r.original_amount_minor_units), remaining: Number(r.remaining_amount_minor_units), currency: String(r.currency), state: String(r.state) })),
    runs: rows(
      ctx,
      `SELECT id,reference,kind,state,as_of FROM reconciliation_runs WHERE dataset_id=? ORDER BY id LIMIT 100`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), reference: String(r.reference), kind: String(r.kind), state: String(r.state), asOf: String(r.as_of) })),
    sessions: rows(
      ctx,
      `SELECT id,branch_id,business_date,state FROM cash_sessions WHERE dataset_id=? ORDER BY id LIMIT 100`,
      ctx.binding.datasetId,
    ).map((r) => ({ id: String(r.id), branch: String(r.branch_id), date: String(r.business_date), state: String(r.state) })),
  };
}

export const batchesPage = definePage<BatchesData, never>({
  load(ctx) {
    return { kind: 'ready', data: load(ctx) };
  },
  handle(_ctx, state, _event): Outcome<BatchesData> {
    return rendered(state);
  },
  render(ctx, state) {
    const data = state.data;
    return {
      title: 'Batches and reconciliation',
      breadcrumbs: [HOME, { label: 'Batches', href: null }],
      body: html`
        <h2>Batches</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Batch</th><th>Kind</th><th>State</th><th>Items</th><th>Applied</th><th>Created</th><th></th></tr>${data.batches.map(
          (b) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'batch', id: b.id })}">${b.number}</a></td><td>${b.kind}</td><td>${b.state}</td><td class="amount">${b.items}</td><td class="amount">${b.applied}</td><td>${when(b.createdAt)}</td>
            <td><a href="${pageHref('Operation.aspx', { op: 'batch.contacts.apply', batch: b.number })}">apply contacts</a> · <a href="${pageHref('Operation.aspx', { op: 'batch.fee_refunds.apply', batch: b.number })}">apply refunds</a></td></tr>`,
        )}</table>
        <p class="hint"><a href="${pageHref('Operation.aspx', { op: 'batch.import' })}">Import a batch</a></p>
        <h2>Settlement batches</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Reference</th><th>Currency</th><th>Declared total</th><th>State</th><th>Cutoff</th></tr>${data.settlements.map(
          (s) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'settlement-batch', id: s.id })}">${s.reference}</a></td><td>${s.currency}</td><td class="amount">${moneyCell(ctx, s.total, s.currency)}</td><td>${s.state}</td><td>${when(s.cutoff)}</td></tr>`,
        )}</table>
        <h2>Suspense items</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Item</th><th>Original</th><th>Remaining</th><th>State</th><th></th></tr>${data.suspense.map(
          (s) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'suspense-item', id: s.id })}">${s.id.slice(-8)}</a></td><td class="amount">${moneyCell(ctx, s.amount, s.currency)}</td><td class="amount">${moneyCell(ctx, s.remaining, s.currency)}</td><td>${s.state}</td>
            <td><a href="${pageHref('Operation.aspx', { op: 'reconciliation.suspense.investigate', suspense: s.id })}">investigate</a> · <a href="${pageHref('Operation.aspx', { op: 'reconciliation.suspense.clear', suspense: s.id })}">clear</a></td></tr>`,
        )}</table>
        <h2>Reconciliation runs</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Reference</th><th>Kind</th><th>State</th><th>As of</th></tr>${data.runs.map(
          (r) => html`<tr class="grid-row"><td>${r.reference}</td><td>${r.kind}</td><td>${r.state}</td><td>${day(r.asOf)}</td></tr>`,
        )}</table>
        <h2>Cash sessions</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Session</th><th>Branch</th><th>Business date</th><th>State</th></tr>${data.sessions.map(
          (s) => html`<tr class="grid-row"><td>${s.id.slice(-8)}</td><td>${s.branch}</td><td>${s.date}</td><td>${s.state}</td></tr>`,
        )}</table>`,
    };
  },
});
