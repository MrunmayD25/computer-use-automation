import { searchMembers, type MemberRow } from '@computer-use/financial-database/services';

import { gridView } from '../grid.js';
import { html } from '../html.js';
import { definePage, redirectTo, rendered, type Outcome, type PageContext } from '../runtime.js';
import { HOME, pageIndexFrom, memberLink } from './shared.js';

const PAGE_SIZE = 20;
const SORTS = ['memberNumber', 'name', 'status', 'joined'] as const;

interface MembersData {
  readonly items: readonly MemberRow[];
  readonly total: number;
  readonly pageIndex: number;
  readonly sort: string;
  readonly descending: boolean;
  /** Member numbers whose detail rows are expanded. */
  readonly expanded: readonly string[];
}

type MembersEvent =
  | { readonly kind: 'find' }
  | { readonly kind: 'page'; readonly index: number }
  | { readonly kind: 'sort'; readonly key: string }
  | { readonly kind: 'expand'; readonly memberNumber: string };

function search(ctx: PageContext): MembersData {
  const pageIndex = pageIndexFrom(ctx.query.get('page'));
  const sort = SORTS.includes(ctx.query.get('sort') as never) ? (ctx.query.get('sort') ?? 'memberNumber') : 'memberNumber';
  const descending = ctx.query.get('dir') === 'desc';
  const result = ctx.read((db, datasetId) =>
    searchMembers(db, datasetId, {
      query: ctx.query.get('q') ?? '',
      status: ctx.query.get('status') ?? '',
      sort,
      direction: descending ? 'desc' : 'asc',
      limit: PAGE_SIZE,
      offset: pageIndex * PAGE_SIZE,
    }),
  );
  return { items: result.items, total: result.total, pageIndex, sort, descending, expanded: [] };
}

function queryUrl(ctx: PageContext, patch: Record<string, string | null>): string {
  const query = new URLSearchParams(ctx.query);
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) query.delete(key);
    else query.set(key, value);
  }
  const text = query.toString();
  return `Members.aspx${text === '' ? '' : `?${text}`}`;
}

export const membersPage = definePage<MembersData, MembersEvent>({
  load(ctx) {
    const expanded = (ctx.query.get('x') ?? '').split(',').filter((value) => value !== '');
    return { kind: 'ready', data: { ...search(ctx), expanded }, fields: { q: ctx.query.get('q') ?? '', status: ctx.query.get('status') ?? '' } };
  },
  handle(ctx, state, event): Outcome<MembersData> {
    // The Find button posts field values; navigate so the URL carries the filters.
    if (event === null || event.kind === 'find') {
      return redirectTo(queryUrl(ctx, { q: (state.fields.q ?? '').trim(), status: state.fields.status ?? '', page: null }));
    }
    const current = () => ({ x: state.data.expanded.length === 0 ? null : state.data.expanded.join(',') });
    switch (event.kind) {
      case 'expand': {
        const expanded = state.data.expanded.includes(event.memberNumber)
          ? state.data.expanded.filter((number) => number !== event.memberNumber)
          : [...state.data.expanded, event.memberNumber];
        state.data = { ...state.data, expanded };
        return rendered(state);
      }
      case 'page':
        return redirectTo(queryUrl(ctx, { page: String(event.index + 1), ...current() }));
      case 'sort':
        return redirectTo(queryUrl(ctx, { sort: event.key, dir: state.data.sort === event.key && !state.data.descending ? 'desc' : 'asc', page: null, ...current() }));
    }
  },
  render(_ctx, state, view) {
    const data = state.data;
    const grid = gridView<MembersEvent>(view);
    return {
      title: 'Members',
      breadcrumbs: [HOME, { label: 'Members', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('txtQ', 'Search')} ${view.textBox('txtQ', { field: 'q', maxLength: 80, columns: 20 })}
            ${view.label('ddlStatus', 'Status')} ${view.dropDownList('ddlStatus', {
              field: 'status',
              items: [
                { value: '', text: 'All statuses' },
                { value: 'active', text: 'Active' },
                { value: 'deceased', text: 'Deceased' },
                { value: 'merged', text: 'Merged' },
                { value: 'former', text: 'Former' },
              ],
            })}
            ${view.button('btnFind', 'Find', { kind: 'find' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} member${data.total === 1 ? '' : 's'} found. <a href="MemberNew.aspx">Create a member</a>.</p>
        ${grid({
          id: 'grdMembers',
          rows: [...data.items],
          emptyText: 'No members match these filters.',
          columns: [
            { header: 'Member #', sortKey: 'memberNumber', cell: (r) => memberLink(r.memberNumber) },
            { header: 'Name', sortKey: 'name', cell: (r) => r.displayName },
            { header: 'Kind', cell: (r) => r.kind },
            { header: 'Status', sortKey: 'status', cell: (r) => r.status },
            { header: 'Email', cell: (r) => r.email ?? '' },
            { header: 'Phone', cell: (r) => r.phone ?? '' },
            { header: 'Open accounts', cell: (r) => String(r.openAccounts) },
            { header: 'Joined', sortKey: 'joined', cell: (r) => r.joinedAt.slice(0, 10) },
          ],
          paging: { pageIndex: data.pageIndex, pageSize: PAGE_SIZE, total: data.total, event: (index) => ({ kind: 'page', index }) },
          sorting: { key: data.sort, descending: data.descending, event: (key) => ({ kind: 'sort', key }) },
          expansion: {
            isExpanded: (r) => data.expanded.includes(r.memberNumber),
            event: (r) => ({ kind: 'expand', memberNumber: r.memberNumber }),
            detail: (r) => html`<table class="details"><tr><th>Record id</th><td>${r.id}</td></tr><tr><th>Email</th><td>${r.email ?? '—'}</td></tr><tr><th>Phone</th><td>${r.phone ?? '—'}</td></tr><tr><th>Version</th><td>${r.version}</td></tr></table>`,
          },
        })}`,
    };
  },
});
