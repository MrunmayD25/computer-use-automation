import { gridView } from '../grid.js';
import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, type Outcome, type PageContext } from '../runtime.js';
import { accountLink, day, HOME, moneyCell, pageIndexFrom, when } from './shared.js';

const PAGE_SIZE = 20;

interface Row {
  id: string;
  reference: string;
  accountNumber: string;
  amount: number;
  currency: string;
  state: string;
  requestedDate: string;
}

interface PaymentsData {
  readonly payments: readonly Row[];
  readonly schedules: readonly { id: string; accountNumber: string; state: string; rule: string }[];
  readonly returns: readonly { id: string; payment: string; amount: number; currency: string; code: string; at: string }[];
  readonly total: number;
  readonly pageIndex: number;
}

type PaymentsEvent = { readonly kind: 'find' } | { readonly kind: 'page'; readonly index: number };

function search(ctx: PageContext): PaymentsData {
  const pageIndex = pageIndexFrom(ctx.query.get('page'));
  const state = ctx.query.get('state') ?? '';
  const clauses = ['p.dataset_id=?'];
  const parameters: (string | number)[] = [ctx.binding.datasetId];
  if (state !== '') {
    clauses.push('p.state=?');
    parameters.push(state);
  }
  const where = clauses.join(' AND ');
  return ctx.read((db) => {
    const payments = db
      .prepare(
        `SELECT p.id,p.reference,p.amount_minor_units,p.currency,p.state,p.requested_date,a.account_number FROM payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE ${where} ORDER BY p.id LIMIT ? OFFSET ?`,
      )
      .all(...parameters, PAGE_SIZE, pageIndex * PAGE_SIZE) as Record<string, unknown>[];
    const total = (db.prepare(`SELECT COUNT(*) AS c FROM payments p WHERE ${where}`).get(...parameters) as { c: number }).c;
    const schedules = db
      .prepare(
        `SELECT s.id,s.rule_json,s.state,a.account_number FROM payment_schedules s JOIN accounts a ON a.dataset_id=s.dataset_id AND a.id=s.source_account_id WHERE s.dataset_id=? ORDER BY s.id LIMIT 50`,
      )
      .all(ctx.binding.datasetId) as Record<string, unknown>[];
    const returns = db
      .prepare(
        `SELECT r.id,r.return_code,r.amount_minor_units,r.occurred_at,p.reference,p.currency FROM payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id WHERE r.dataset_id=? ORDER BY r.id LIMIT 50`,
      )
      .all(ctx.binding.datasetId) as Record<string, unknown>[];
    return {
      payments: payments.map((r) => ({
        id: String(r.id), reference: String(r.reference), accountNumber: String(r.account_number),
        amount: Number(r.amount_minor_units), currency: String(r.currency), state: String(r.state), requestedDate: String(r.requested_date),
      })),
      schedules: schedules.map((r) => ({ id: String(r.id), accountNumber: String(r.account_number), state: String(r.state), rule: String(r.rule_json).slice(0, 80) })),
      returns: returns.map((r) => ({ id: String(r.id), payment: String(r.reference), amount: Number(r.amount_minor_units), currency: String(r.currency), code: String(r.return_code), at: String(r.occurred_at) })),
      total,
      pageIndex,
    };
  });
}

export const paymentsPage = definePage<PaymentsData, PaymentsEvent>({
  load(ctx) {
    return { kind: 'ready', data: search(ctx), fields: { state: ctx.query.get('state') ?? '' } };
  },
  handle(ctx, state, event): Outcome<PaymentsData> {
    if (event === null || event.kind === 'find') {
      return redirectTo(`Payments.aspx${state.fields.state === '' ? '' : `?state=${encodeURIComponent(state.fields.state ?? '')}`}`);
    }
    const query = new URLSearchParams(ctx.query);
    query.set('page', String(event.index + 1));
    return redirectTo(`Payments.aspx?${query}`);
  },
  render(ctx, state, view) {
    const data = state.data;
    const grid = gridView<PaymentsEvent>(view);
    return {
      title: 'Payments',
      breadcrumbs: [HOME, { label: 'Payments', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('ddlState', 'State')} ${view.dropDownList('ddlState', {
            field: 'state',
            items: ['', 'draft', 'pending-approval', 'released', 'settled', 'rejected', 'cancellation-requested', 'cancelled', 'returned'].map((s) => ({ value: s, text: s === '' ? 'All states' : s })),
          })} ${view.button('btnFind', 'Find', { kind: 'find' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} payment${data.total === 1 ? '' : 's'}. <a href="${pageHref('Operation.aspx', { op: 'payment.create' })}">Create a payment</a> · <a href="${pageHref('Operation.aspx', { op: 'payment.schedule.create' })}">Schedule</a></p>
        ${grid({
          id: 'grdPayments',
          rows: [...data.payments],
          emptyText: 'No payments.',
          columns: [
            { header: 'Reference', cell: (r) => html`<a href="${pageHref('Record.aspx', { kind: 'payment', id: r.id })}">${r.reference}</a>` },
            { header: 'Source', cell: (r) => accountLink(r.accountNumber) },
            { header: 'Amount', className: 'amount', cell: (r) => moneyCell(ctx, r.amount, r.currency) },
            { header: 'Requested', cell: (r) => day(r.requestedDate) },
            { header: 'State', cell: (r) => r.state },
          ],
          paging: { pageIndex: data.pageIndex, pageSize: PAGE_SIZE, total: data.total, event: (index) => ({ kind: 'page', index }) },
        })}
        <h2>Schedules</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Schedule</th><th>Source</th><th>Rule</th><th>State</th><th></th></tr>${data.schedules.map(
          (s) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'payment-schedule', id: s.id })}">${s.id.slice(-8)}</a></td><td>${accountLink(s.accountNumber)}</td><td><code>${s.rule}</code></td><td>${s.state}</td><td><a href="${pageHref('Operation.aspx', { op: 'payment.schedule.materialize', schedule: s.id })}">materialize</a> · <a href="${pageHref('Operation.aspx', { op: 'payment.schedule.end', schedule: s.id })}">end</a></td></tr>`,
        )}</table>
        <h2>Returns</h2>
        <table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Return</th><th>Payment</th><th>Amount</th><th>Code</th><th>When</th><th></th></tr>${data.returns.map(
          (r) => html`<tr class="grid-row"><td><a href="${pageHref('Record.aspx', { kind: 'payment-return', id: r.id })}">${r.id.slice(-8)}</a></td><td>${r.payment}</td><td class="amount">${moneyCell(ctx, r.amount, r.currency)}</td><td>${r.code}</td><td>${when(r.at)}</td><td><a href="${pageHref('Operation.aspx', { op: 'payment.return.resolve', return: r.id })}">resolve</a></td></tr>`,
        )}</table>`,
    };
  },
});
