import { gridView } from '../grid.js';
import { html } from '../html.js';
import { pageHref } from '../page-names.js';
import { definePage, redirectTo, type Outcome, type PageContext } from '../runtime.js';
import { documentLink, HOME, pageIndexFrom, when } from './shared.js';

const PAGE_SIZE = 20;

interface DocRow {
  versionId: string;
  documentId: string;
  displayName: string;
  documentType: string;
  mediaType: string;
  version: number;
  status: string;
  issuedAt: string;
  byteLength: number;
  ownerName: string;
}

interface DocumentsData {
  readonly items: readonly DocRow[];
  readonly total: number;
  readonly pageIndex: number;
}

type DocumentsEvent =
  | { readonly kind: 'find' }
  | { readonly kind: 'page'; readonly index: number };

function search(ctx: PageContext): DocumentsData {
  const pageIndex = pageIndexFrom(ctx.query.get('page'));
  const type = (ctx.query.get('type') ?? '').trim();
  const q = (ctx.query.get('q') ?? '').trim();
  const clauses = ['v.dataset_id=?'];
  const parameters: (string | number)[] = [ctx.binding.datasetId];
  if (type !== '') {
    clauses.push('d.document_type=?');
    parameters.push(type);
  }
  if (q !== '') {
    clauses.push("(d.display_name LIKE ? ESCAPE '\\')");
    parameters.push(`%${q.replaceAll('%', '\\%').replaceAll('_', '\\_')}%`);
  }
  const where = clauses.join(' AND ');
  const items = ctx.read((db) => {
    const total = db.prepare(`SELECT COUNT(*) AS c FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id WHERE ${where}`).get(...parameters) as { c: number };
    const list = db
      .prepare(
        `SELECT v.id AS version_id,d.id AS document_id,d.display_name,d.document_type,v.media_type,v.version,v.status,v.issued_at,b.byte_length,p.display_name AS owner_name
         FROM documents d JOIN document_versions v ON v.dataset_id=d.dataset_id AND v.document_id=d.id JOIN document_blobs b ON b.dataset_id=v.dataset_id AND b.digest=v.digest JOIN parties p ON p.dataset_id=d.dataset_id AND p.id=d.owner_party_id
         WHERE ${where} ORDER BY v.issued_at DESC,v.id LIMIT ? OFFSET ?`,
      )
      .all(...parameters, PAGE_SIZE, pageIndex * PAGE_SIZE) as Record<string, unknown>[];
    return { items: list, total: total.c };
  });
  return {
    items: items.items.map((r) => ({
      versionId: String(r.version_id),
      documentId: String(r.document_id),
      displayName: String(r.display_name),
      documentType: String(r.document_type),
      mediaType: String(r.media_type),
      version: Number(r.version),
      status: String(r.status),
      issuedAt: String(r.issued_at),
      byteLength: Number(r.byte_length),
      ownerName: String(r.owner_name),
    })),
    total: items.total,
    pageIndex,
  };
}

function queryUrl(ctx: PageContext, patch: Record<string, string | null>): string {
  const query = new URLSearchParams(ctx.query);
  for (const [key, value] of Object.entries(patch)) {
    if (value === null) query.delete(key);
    else query.set(key, value);
  }
  const text = query.toString();
  return `Documents.aspx${text === '' ? '' : `?${text}`}`;
}

export const documentsPage = definePage<DocumentsData, DocumentsEvent>({
  load(ctx) {
    return { kind: 'ready', data: search(ctx), fields: { q: ctx.query.get('q') ?? '', type: ctx.query.get('type') ?? '' } };
  },
  handle(ctx, state, event): Outcome<DocumentsData> {
    if (event === null || event.kind === 'find') {
      return redirectTo(queryUrl(ctx, { q: (state.fields.q ?? '').trim() || null, type: (state.fields.type ?? '').trim() || null, page: null }));
    }
    return redirectTo(queryUrl(ctx, { page: String(event.index + 1) }));
  },
  render(_ctx, state, view) {
    const data = state.data;
    const grid = gridView<DocumentsEvent>(view);
    return {
      title: 'Documents',
      breadcrumbs: [HOME, { label: 'Documents', href: null }],
      body: html`
        <div class="filter-bar">${view.panel(
          'pnlFilter',
          'btnFind',
          html`${view.label('txtQ', 'Name')} ${view.textBox('txtQ', { field: 'q', maxLength: 80, columns: 18 })}
            ${view.label('txtType', 'Type')} ${view.textBox('txtType', { field: 'type', maxLength: 60, columns: 16 })}
            ${view.button('btnFind', 'Find', { kind: 'find' })}`,
        )}</div>
        <p class="hint" id="${view.idOf('lblCount')}">${data.total} document version${data.total === 1 ? '' : 's'}. <a href="${pageHref('Operation.aspx', { op: 'document.index' })}">Index a new document</a>.</p>
        ${grid({
          id: 'grdDocuments',
          rows: [...data.items],
          emptyText: 'No documents match.',
          columns: [
            { header: 'Name', cell: (r) => documentLink(r.versionId, r.displayName) },
            { header: 'Type', cell: (r) => r.documentType },
            { header: 'Owner', cell: (r) => r.ownerName },
            { header: 'Version', cell: (r) => String(r.version) },
            { header: 'Media', cell: (r) => r.mediaType },
            { header: 'Status', cell: (r) => r.status },
            { header: 'Bytes', className: 'amount', cell: (r) => String(r.byteLength) },
            { header: 'Issued', cell: (r) => when(r.issuedAt) },
          ],
          paging: { pageIndex: data.pageIndex, pageSize: PAGE_SIZE, total: data.total, event: (index) => ({ kind: 'page', index }) },
        })}`,
    };
  },
});
