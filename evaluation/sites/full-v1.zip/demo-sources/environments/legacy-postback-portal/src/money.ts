/** Exact minor-unit money helpers. The financial store never floats; text input is parsed to integers. */

export interface CurrencyInfo {
  readonly code: string;
  readonly exponent: number;
  readonly name: string;
}

const amountPattern = /^(\d{1,3}(?:,\d{3})*|\d{1,15})(?:\.(\d{1,6}))?$/u;

/** Parses operator-entered decimal text into positive integer minor units at the currency exponent. */
export function parseMoney(input: string, exponent: number): number | undefined {
  const text = input.trim().replace(/^[$€¥]/u, '');
  const match = amountPattern.exec(text);
  if (match === null) return undefined;
  const whole = match[1] ?? '0';
  const fraction = match[2] ?? '';
  if (fraction.length > exponent) return undefined;
  const digits = `${whole.replaceAll(',', '')}${fraction.padEnd(exponent, '0')}`;
  // A twelve-digit whole part bounds minor units at 1e14, well inside safe-integer range.
  if (whole.replaceAll(',', '').length > 12 || digits.length > 15) return undefined;
  const minorUnits = Number(digits);
  return Number.isSafeInteger(minorUnits) && minorUnits > 0 ? minorUnits : undefined;
}

/** Parses an amount that may be zero or negative, for corrections and declared totals. */
export function parseSignedMoney(input: string, exponent: number): number | undefined {
  const negative = input.trim().startsWith('-');
  const value = parseMoney(input.trim().replace(/^-+/u, ''), exponent);
  if (value === undefined) return undefined;
  return negative ? -value : value;
}

export function formatMoney(minorUnits: number, exponent: number, currency?: string): string {
  const sign = minorUnits < 0 ? '-' : '';
  const magnitude = Math.abs(minorUnits);
  const divisor = 10 ** exponent;
  const whole = Math.trunc(magnitude / divisor);
  const fraction = String(magnitude % divisor).padStart(exponent, '0');
  const amount = exponent === 0 ? whole.toLocaleString('en-US') : `${whole.toLocaleString('en-US')}.${fraction}`;
  return currency === undefined ? `${sign}${amount}` : `${sign}${amount} ${currency}`;
}

/** Format with a currency record, e.g. `{currency:'USD', exponent:2}`. */
export function formatAmount(minorUnits: number, currency: CurrencyInfo): string {
  return `${formatMoney(minorUnits, currency.exponent)} ${currency.code}`;
}
