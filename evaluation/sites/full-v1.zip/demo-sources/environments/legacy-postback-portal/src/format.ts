function pad(value: number): string {
  return String(value).padStart(2, '0');
}

export function formatDate(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return `${pad(date.getUTCMonth() + 1)}/${pad(date.getUTCDate())}/${String(date.getUTCFullYear())}`;
}

export function formatDateTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return `${formatDate(iso)} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())} UTC`;
}

export function formatClock(date: Date): string {
  return `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())} UTC`;
}

const monthNames = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
] as const;

export function monthName(monthIndex: number): string {
  return monthNames[monthIndex] ?? '';
}

/** Formats a statement period such as 2025-02 as "February 2025". */
export function formatPeriod(period: string): string {
  const match = /^(\d{4})-(\d{2})$/u.exec(period);
  if (match === null) return period;
  return `${monthName(Number(match[2]) - 1)} ${match[1] ?? ''}`;
}
