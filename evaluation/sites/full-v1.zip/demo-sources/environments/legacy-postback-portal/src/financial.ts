import {
  openFinancialDatabase,
  type DatasetBinding,
  type FinancialDatabase,
} from '@computer-use/financial-database';
import {
  authorizeQuery,
  institutionSummary,
  openFinancialStore,
  operatorProfile,
  type FinancialStore,
  type InstitutionSummary,
  type OperatorProfile,
  type ServiceContext,
  type SqlDatabase,
} from '@computer-use/financial-database/services';

export const DEFAULT_WORLD = 'financial-demo-v1';
export const DEFAULT_INSTITUTION = 'northstar';
export const DEFAULT_OPERATORS = ['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0006', 'OP0007'];
export const DEFAULT_OPERATOR = 'OP0002';
/** Statement export destinations the trusted backend approves; values are checked server-side. */
export const EXPORT_DESTINATIONS = ['browser-download', 'export-folder'] as const;

/**
 * The shared financial world this portal is bound to. `database` owns dataset cloning and the
 * bounded record readers; `store` is the transactional service boundary every page uses.
 */
export interface PortalServices {
  readonly store: FinancialStore;
  readonly database: FinancialDatabase;
  readonly worldName: string;
  readonly world: readonly DatasetBinding[];
  readonly operators: readonly string[];
  readonly defaultOperator: string;
  readonly exportDirectory: string;
  readonly exportDestinations: readonly string[];
  readonly ownsStore: boolean;
}

export interface OpenPortalServicesOptions {
  path: string;
  world: string;
  operators?: readonly string[];
  defaultOperator?: string;
  exportDirectory?: string;
  busyTimeoutMs?: number;
  /** Evaluator mode: an existing store the caller owns, for example a verification run. */
  store?: FinancialStore;
}

export function openPortalServices(options: OpenPortalServicesOptions): PortalServices {
  const database = openFinancialDatabase({ path: options.path, ...(options.busyTimeoutMs === undefined ? {} : { busyTimeoutMs: options.busyTimeoutMs }) });
  try {
    const world = database.getNamedWorld(options.world);
    if (world.length === 0) {
      throw new Error(`World ${options.world} is not seeded in ${options.path}. Seed it with the financial package first.`);
    }
    const store = options.store ?? openFinancialStore({ path: options.path, ...(options.busyTimeoutMs === undefined ? {} : { busyTimeoutMs: options.busyTimeoutMs }) });
    const operators = [...(options.operators ?? DEFAULT_OPERATORS)];
    const defaultOperator = options.defaultOperator ?? operators[1] ?? DEFAULT_OPERATOR;
    return {
      store,
      database,
      worldName: options.world,
      world,
      operators,
      defaultOperator,
      exportDirectory: options.exportDirectory ?? '.runtime/exports',
      exportDestinations: [...EXPORT_DESTINATIONS],
      ownsStore: options.store === undefined,
    };
  } catch (error) {
    database.close();
    throw error;
  }
}

/** Binding for one institution in the bound world; undefined when the world lacks it. */
export function worldBinding(services: PortalServices, institutionId: string): DatasetBinding | undefined {
  return services.world.find((binding) => binding.institutionId === institutionId);
}

/** The institution a dataset belongs to, resolved through the service store. */
export function datasetInstitution(store: FinancialStore, datasetId: string): InstitutionSummary {
  return store.read((database) => institutionSummary(database, datasetId));
}

export interface Operator {
  readonly actorId: string;
  readonly actorNumber: string;
  readonly displayName: string;
  readonly status: string;
  readonly roles: readonly string[];
  readonly permissions: ReadonlySet<string>;
}

function toOperator(profile: OperatorProfile): Operator {
  return {
    actorId: profile.actor.id,
    actorNumber: profile.actor.actorNumber,
    displayName: profile.actor.displayName,
    status: profile.status,
    roles: profile.roles,
    permissions: new Set(profile.permissions),
  };
}

/** Resolves a configured actor number against the session's institution dataset. */
export function resolveOperator(store: FinancialStore, binding: DatasetBinding, actorNumber: string): Operator | undefined {
  return store.read((database) => {
    const profile = operatorProfile(database, binding.datasetId, binding.institutionId, actorNumber);
    return profile === undefined ? undefined : toOperator(profile);
  });
}

/** Trusted service context for one request; actor identity comes from server configuration. */
export function serviceContext(binding: DatasetBinding, operator: Operator, reference: string): ServiceContext {
  return { binding, actorId: operator.actorId, principalKind: 'human', reference };
}

/** Confirms the operator may read institution data at all, without granting a write. */
export function authorizedRead(store: FinancialStore, binding: DatasetBinding, operator: Operator): { denied: boolean; message: string | null } {
  return store.read((database) => {
    const rejection = authorizeQuery(database, serviceContext(binding, operator, 'branchnet:read'), undefined);
    return rejection === null ? { denied: false, message: null } : { denied: true, message: rejection.message };
  });
}

export type { SqlDatabase };
