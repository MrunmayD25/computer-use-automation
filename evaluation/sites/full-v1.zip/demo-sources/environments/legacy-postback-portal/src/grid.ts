import type { ViewBuilder } from './controls.js';
import { html, type HtmlValue, type SafeHtml } from './html.js';

export interface GridColumn<R, E> {
  readonly header: string;
  readonly sortKey?: string;
  readonly className?: string;
  cell(row: R, rowView: ViewBuilder<E>): HtmlValue;
}

export interface GridSpec<R, E> {
  readonly id: string;
  readonly rows: readonly R[];
  readonly columns: readonly GridColumn<R, E>[];
  readonly emptyText: string;
  readonly paging?: {
    readonly pageIndex: number;
    readonly pageSize: number;
    /** Server-paged total; when absent the row list itself is the full result set. */
    readonly total?: number;
    readonly event: (pageIndex: number) => E;
  };
  readonly sorting?: {
    readonly key: string;
    readonly descending: boolean;
    readonly event: (key: string) => E;
  };
  readonly expansion?: {
    readonly isExpanded: (row: R) => boolean;
    readonly event: (row: R) => E;
    readonly detail: (row: R) => SafeHtml;
  };
  readonly rowClass?: (row: R) => string | null;
}

export interface PageWindow {
  readonly pageIndex: number;
  readonly pageCount: number;
  readonly start: number;
  readonly end: number;
}

/** Clamps a requested page so a list that shrank still shows its last page. */
export function pageWindow(total: number, requestedIndex: number, pageSize: number): PageWindow {
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  const pageIndex = Math.min(Math.max(0, requestedIndex), pageCount - 1);
  const start = pageIndex * pageSize;
  return { pageIndex, pageCount, start, end: Math.min(total, start + pageSize) };
}

const pagerButtonCount = 10;

function pager<E>(grid: ViewBuilder<E>, window: PageWindow, event: (pageIndex: number) => E): SafeHtml {
  const first = Math.floor(window.pageIndex / pagerButtonCount) * pagerButtonCount;
  const last = Math.min(window.pageCount, first + pagerButtonCount) - 1;
  const cells: SafeHtml[] = [];
  if (first > 0) {
    cells.push(html`<td>${grid.postBackLink(`Page$${String(first)}`, '...', event(first - 1))}</td>`);
  }
  for (let index = first; index <= last; index += 1) {
    const label = String(index + 1);
    cells.push(
      index === window.pageIndex
        ? html`<td><span>${label}</span></td>`
        : html`<td>${grid.postBackLink(`Page$${label}`, label, event(index))}</td>`,
    );
  }
  if (last < window.pageCount - 1) {
    cells.push(html`<td>${grid.postBackLink(`Page$${String(last + 2)}`, '...', event(last + 1))}</td>`);
  }
  return html`<table class="pager-buttons"><tr>${cells}</tr></table>`;
}

/**
 * Renders a GridView: header row ctl01, data rows ctl02 onward, numeric pager, sortable headers.
 * Curried so the page's event type is fixed by the view before the spec's callbacks are checked; otherwise their event literals widen.
 */
export function gridView<E>(view: ViewBuilder<E>): <R>(spec: GridSpec<R, E>) => SafeHtml {
  return (spec) => renderGrid(view, spec);
}

function renderGrid<R, E>(view: ViewBuilder<E>, spec: GridSpec<R, E>): SafeHtml {
  const grid = view.child(spec.id);
  const window = spec.paging
    ? pageWindow(spec.paging.total ?? spec.rows.length, spec.paging.pageIndex, spec.paging.pageSize)
    : { pageIndex: 0, pageCount: 1, start: 0, end: spec.rows.length };
  const visible = spec.paging?.total === undefined ? spec.rows.slice(window.start, window.end) : spec.rows;
  const expansion = spec.expansion;
  const columnCount = spec.columns.length + (expansion === undefined ? 0 : 1);
  const sorting = spec.sorting;

  const header = html`<tr class="grid-header">${expansion === undefined ? '' : html`<th scope="col" class="expand-col">&nbsp;</th>`}${spec.columns.map(
    (column) => {
      if (sorting === undefined || column.sortKey === undefined) return html`<th scope="col">${column.header}</th>`;
      const active = sorting.key === column.sortKey;
      const arrow = active ? (sorting.descending ? ' ▼' : ' ▲') : '';
      return html`<th scope="col">${grid.postBackLink(`Sort$${column.sortKey}`, column.header, sorting.event(column.sortKey))}${arrow}</th>`;
    },
  )}</tr>`;

  const body =
    visible.length === 0
      ? html`<tr class="grid-empty"><td colspan="${columnCount}">${spec.emptyText}</td></tr>`
      : visible.map((row, index) => {
          const rowView = grid.row(index);
          const expanded = expansion?.isExpanded(row) ?? false;
          const classes = [index % 2 === 0 ? 'grid-row' : 'grid-alt', spec.rowClass?.(row) ?? ''].join(' ').trim();
          const expander =
            expansion === undefined
              ? ''
              : html`<td class="expand-col">${rowView.linkButton('lnkExpand', expanded ? '-' : '+', expansion.event(row), {
                  title: expanded ? 'Hide details' : 'Show details',
                  className: 'expander',
                })}</td>`;
          const cells = spec.columns.map(
            (column) =>
              html`<td${column.className === undefined ? '' : html` class="${column.className}"`}>${column.cell(row, rowView)}</td>`,
          );
          const detail =
            expanded && expansion !== undefined
              ? html`<tr class="grid-detail"><td colspan="${columnCount}">${expansion.detail(row)}</td></tr>`
              : '';
          return html`<tr class="${classes}">${expander}${cells}</tr>${detail}`;
        });

  const pagerRow =
    spec.paging !== undefined && window.pageCount > 1
      ? html`<tr class="grid-pager"><td colspan="${columnCount}">${pager(grid, window, spec.paging.event)}</td></tr>`
      : '';

  return html`<table class="grid" cellspacing="0" rules="all" border="1" id="${grid.clientId}">${header}${body}${pagerRow}</table>`;
}
