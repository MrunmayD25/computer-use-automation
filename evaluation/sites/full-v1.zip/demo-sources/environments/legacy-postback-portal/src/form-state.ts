import { randomBytes } from 'node:crypto';

export interface FormStateLimits {
  /** Idle lifetime of one page state, in milliseconds. */
  readonly ttlMs: number;
  /** Maximum page states retained per UI session. */
  readonly capacity: number;
  readonly now: () => number;
}

interface Entry<T> {
  readonly value: T;
  lastUsedAt: number;
}

/** Per-session page-state history keyed by opaque tokens, with idle expiry and LRU eviction. */
export class FormStateHistory<T> {
  readonly #entries = new Map<string, Entry<T>>();
  readonly #limits: FormStateLimits;

  constructor(limits: FormStateLimits) {
    if (!Number.isSafeInteger(limits.ttlMs) || limits.ttlMs <= 0) {
      throw new Error('Form state TTL must be a positive integer number of milliseconds.');
    }
    if (!Number.isSafeInteger(limits.capacity) || limits.capacity < 1) {
      throw new Error('Form state history must retain at least one page state.');
    }
    this.#limits = limits;
  }

  get size(): number {
    return this.#entries.size;
  }

  save(value: T): string {
    this.#removeExpired();
    const token = randomBytes(24).toString('base64url');
    this.#entries.set(token, { value, lastUsedAt: this.#limits.now() });
    for (const oldest of this.#entries.keys()) {
      if (this.#entries.size <= this.#limits.capacity) break;
      this.#entries.delete(oldest);
    }
    return token;
  }

  lookup(token: string): T | undefined {
    const entry = this.#entries.get(token);
    if (entry === undefined) return undefined;
    this.#entries.delete(token);
    const now = this.#limits.now();
    if (now - entry.lastUsedAt > this.#limits.ttlMs) return undefined;
    entry.lastUsedAt = now;
    this.#entries.set(token, entry);
    return entry.value;
  }

  #removeExpired(): void {
    const now = this.#limits.now();
    for (const [token, entry] of this.#entries) {
      if (now - entry.lastUsedAt > this.#limits.ttlMs) this.#entries.delete(token);
    }
  }
}
