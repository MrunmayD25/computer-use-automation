import { createHash, randomBytes } from 'node:crypto';

import {
  executeCommand,
  institutionSummary,
  receiptByIdempotencyKey,
  reviewCommand,
  CAPABILITY_GRANTS,
  type CommandKind,
  type CommandOutcome,
  type InstitutionSummary,
  type NoteReader,
  type Receipt,
  type ReviewOutcome,
  type ServiceCommand,
  type ServiceContext,
  type SqlDatabase,
} from '@computer-use/financial-database/services';

import { ControlRegistry, loadPostValue, registrySink, ViewBuilder } from './controls.js';
import { resolveOperator, serviceContext, type Operator, type PortalServices } from './financial.js';
import { html, type SafeHtml } from './html.js';
import { NOTICES, renderDocumentHtml, renderMessagePage, type Crumb, type Link } from './layout.js';
import { pageHref, type PageName } from './page-names.js';
import type { UiSession } from './sessions.js';
import type { ComparisonRow, ValidationMessage } from './validation.js';

/** Presentation state of one rendered document; `data` is the page's own JSON-serializable view data. */
export interface PageState<S> {
  data: S;
  fields: Record<string, string>;
  /** Form instance key created on GET and kept across the document chain's postbacks. */
  formKey: string;
  errors: ValidationMessage[];
  comparison: ComparisonRow[];
  notice: string | null;
}

export type LoadOutcome<S> =
  | { readonly kind: 'ready'; readonly data: S; readonly fields?: Readonly<Record<string, string>> }
  | { readonly kind: 'not-found'; readonly title: string; readonly message: string; readonly links: readonly Link[] };

export type Outcome<S> =
  | { readonly kind: 'render'; readonly state: PageState<S>; readonly status: number }
  | { readonly kind: 'redirect'; readonly location: string }
  | { readonly kind: 'download'; readonly filename: string; readonly contentType: string; readonly body: string | Uint8Array };

export interface RenderedPage {
  readonly title: string;
  readonly breadcrumbs: readonly Crumb[];
  readonly body: SafeHtml;
  readonly layout?: 'master' | 'print';
}

export interface DocumentDefinition<S, E> {
  /** Runs after LoadPostData on a copy of the stored state; `event` is null when no control raised one. */
  handle(ctx: PageContext, state: PageState<S>, event: E | null): Outcome<S>;
  /** Renders the content area and registers every control it renders. */
  render(ctx: PageContext, state: PageState<S>, view: ViewBuilder<E>): RenderedPage;
}

export interface PageDefinition<S, E> extends DocumentDefinition<S, E> {
  load(ctx: PageContext): LoadOutcome<S>;
}

export type PageResponse =
  | { readonly kind: 'html'; readonly status: number; readonly body: string; readonly control: string | null }
  | { readonly kind: 'redirect'; readonly location: string; readonly control: string | null }
  | {
      readonly kind: 'download';
      readonly filename: string;
      readonly contentType: string;
      readonly body: string | Uint8Array;
      readonly control: string | null;
    };

export interface StoredDocument {
  /** Page whose URL the document was served at. */
  readonly page: PageName;
  postBack(ctx: PageContext, form: PostedForm): PageResponse;
}

export interface RegisteredPage {
  get(ctx: PageContext): PageResponse;
}

/**
 * Request-scoped page context. Trusted identity, institution and dataset binding come from server
 * configuration — never from posted fields. Business reads and commands run at the dataset's
 * controlled as-of clock through the shared financial services.
 */
export interface PageContext {
  readonly services: PortalServices;
  readonly session: UiSession;
  readonly binding: UiSession['binding'];
  readonly actor: Operator;
  readonly institution: InstitutionSummary;
  readonly page: PageName;
  readonly query: URLSearchParams;
  readonly requestNumber: number;
  /** Wall clock for render timestamps and form-state expiry. */
  readonly now: Date;
  /** The dataset's controlled business instant. */
  readonly businessNow: string;
  /** Ordinary bounded read against the session's dataset. */
  read<T>(fn: (database: SqlDatabase, datasetId: string) => T): T;
  /** Service-context read for the authorized servicing/finance query functions. */
  svc<T>(fn: (database: SqlDatabase, context: ServiceContext) => T): T;
  /** Reader token for restricted notes/documents. */
  reader(): NoteReader;
  /** Reviewed terms of a command against current data, without effect. */
  review(command: ServiceCommand): ReviewOutcome;
  /** Commits a command once per form instance and event; repeats return the stored receipt. */
  execute(command: ServiceCommand, eventName: string, formKey: string): CommandOutcome;
  /** Replays the committed receipt for this form's event, when one exists. */
  receiptFor(eventName: string, formKey: string): Receipt | undefined;
  /** One logical operation keeps one key across every retry of the same form instance. */
  idempotencyKey(eventName: string, formKey: string): string;
  /** Whether the signed-on operator holds any grant this command kind requires. */
  permits(kind: CommandKind): boolean;
  /** The grants a command kind requires, for an honest "requires …" label. */
  grantsFor(kind: CommandKind): readonly string[];
  /** Trusted service context for service-boundary calls that take one. */
  context(reference?: string): ServiceContext;
}

export function createPageContext(options: {
  services: PortalServices;
  session: UiSession;
  page: PageName;
  query: URLSearchParams;
  requestNumber: number;
  now: Date;
}): PageContext {
  const { services, session } = options;
  const binding = session.binding;
  const institution = services.store.read((database) => institutionSummary(database, binding.datasetId));
  const actor = resolveOperator(services.store, binding, session.actorNumber);
  if (actor === undefined) throw new Error(`Operator ${session.actorNumber} is not registered in this dataset.`);
  const ctx: PageContext = {
    services,
    session,
    binding,
    actor,
    institution,
    page: options.page,
    query: options.query,
    requestNumber: options.requestNumber,
    now: options.now,
    businessNow: institution.asOf,
    read(fn) {
      return services.store.read((database) => fn(database, binding.datasetId));
    },
    svc(fn) {
      return services.store.read((database) => fn(database, ctx.context()));
    },
    reader() {
      return { institutionId: binding.institutionId, actorId: actor.actorId, now: institution.asOf };
    },
    context(reference = `branchnet:${session.instanceId}`) {
      return serviceContext(binding, actor, reference);
    },
    review(command) {
      return reviewCommand(services.store, ctx.context(), command);
    },
    idempotencyKey(eventName, formKey) {
      return `${formKey}:${eventName}`;
    },
    execute(command, eventName, formKey) {
      return executeCommand(services.store, ctx.context(), command, ctx.idempotencyKey(eventName, formKey));
    },
    receiptFor(eventName, formKey) {
      return services.store.read((database) => receiptByIdempotencyKey(database, binding.datasetId, ctx.idempotencyKey(eventName, formKey)));
    },
    permits(kind) {
      const grants = CAPABILITY_GRANTS[kind];
      return grants.some((grant) => actor.permissions.has(grant));
    },
    grantsFor(kind) {
      return CAPABILITY_GRANTS[kind];
    },
  };
  return ctx;
}

/** Posted urlencoded fields in document order; duplicate names are not produced by this application's forms. */
export class PostedForm {
  readonly #values: ReadonlyMap<string, string>;

  private constructor(values: ReadonlyMap<string, string>) {
    this.#values = values;
  }

  static parse(body: string): PostedForm | undefined {
    const values = new Map<string, string>();
    for (const [name, value] of new URLSearchParams(body)) {
      if (values.has(name)) return undefined;
      values.set(name, value);
    }
    return new PostedForm(values);
  }

  get(name: string): string | undefined {
    return this.#values.get(name);
  }

  names(): IterableIterator<string> {
    return this.#values.keys();
  }
}

type MasterEvent = { readonly kind: 'quick-search' };
type Routed<E> = { readonly scope: 'page'; readonly event: E } | { readonly scope: 'master'; readonly event: MasterEvent };

const QUICK_SEARCH_FIELD = 'quickSearch';

interface Echo {
  readonly scrollY: string;
  readonly lastFocus: string;
}

const noEcho: Echo = { scrollY: '', lastFocus: '' };

export function viewStateGenerator(page: PageName): string {
  return createHash('sha1').update(`/${page.toLowerCase()}`).digest('hex').slice(0, 8).toUpperCase();
}

function search(query: URLSearchParams): string {
  const text = query.toString();
  return text === '' ? '' : `?${text}`;
}

/** The page's own URL without a one-time notice, for "open the current page" links. */
export function currentUrl(ctx: PageContext): string {
  const query = new URLSearchParams(ctx.query);
  query.delete('msg');
  return `${ctx.page}${search(query)}`;
}

export function rendered<S>(state: PageState<S>, status = 200): Outcome<S> {
  return { kind: 'render', state, status };
}

export function redirectTo(location: string): Outcome<never> {
  return { kind: 'redirect', location };
}

export function csvDownload(filename: string, body: string): Outcome<never> {
  return { kind: 'download', filename, contentType: 'text/csv; charset=utf-8', body };
}

export function withErrors<S>(state: PageState<S>, errors: readonly ValidationMessage[]): Outcome<S> {
  state.errors.push(...errors);
  return rendered(state);
}

/** Maps a rejected command outcome onto the form, keeping the user's entries. */
export function rejectionError<S>(state: PageState<S>, rejection: { code: string; message: string; field?: string }): Outcome<S> {
  state.errors.push({ field: rejection.field ?? null, message: rejection.message });
  return rendered(state, rejection.code === 'stale_version' ? 409 : 422);
}

/** Stale-current comparison text plus the "open the current page" recovery link. */
export function staleFailure<S>(ctx: PageContext, state: PageState<S>, message: string, comparison: readonly ComparisonRow[]): Outcome<S> {
  state.errors.push({ field: null, message, link: { href: currentUrl(ctx), label: 'Open the current page' } });
  state.comparison = [...comparison];
  return rendered(state, 409);
}

interface NotFoundData {
  readonly title: string;
  readonly message: string;
  readonly links: readonly Link[];
}

const notFoundDocument: DocumentDefinition<NotFoundData, never> = {
  handle: (_ctx, state) => rendered(state, 404),
  render: (_ctx, state) => ({
    title: state.data.title,
    breadcrumbs: [
      { label: 'Home', href: 'Default.aspx' },
      { label: state.data.title, href: null },
    ],
    body: html`<div class="not-found"><p>${state.data.message}</p><ul class="message-links">${state.data.links.map(
      (link) => html`<li><a href="${link.href}">${link.label}</a></li>`,
    )}</ul></div>`,
  }),
};

export function definePage<S, E>(definition: PageDefinition<S, E>): RegisteredPage {
  return {
    get(ctx) {
      const loaded = definition.load(ctx);
      const base = {
        formKey: randomBytes(12).toString('base64url'),
        errors: [],
        comparison: [],
        notice: NOTICES.get(ctx.query.get('msg') ?? '') ?? null,
      };
      if (loaded.kind === 'not-found') {
        const data: NotFoundData = { title: loaded.title, message: loaded.message, links: loaded.links };
        return renderDocument(notFoundDocument, ctx, { ...base, data, fields: {} }, 404, noEcho, null);
      }
      return renderDocument(definition, ctx, { ...base, data: loaded.data, fields: { ...loaded.fields } }, 200, noEcho, null);
    },
  };
}

function quickSearch(view: ViewBuilder<MasterEvent>): SafeHtml {
  return view.panel(
    'pnlQuickSearch',
    'btnQuickSearch',
    html`${view.label('txtQuickSearch', 'Member search')} ${view.textBox('txtQuickSearch', {
      field: QUICK_SEARCH_FIELD,
      maxLength: 80,
      columns: 16,
    })} ${view.button('btnQuickSearch', 'Go', { kind: 'quick-search' })}`,
    'quicksearch',
  );
}

function renderDocument<S, E>(
  definition: DocumentDefinition<S, E>,
  ctx: PageContext,
  state: PageState<S>,
  status: number,
  echo: Echo,
  control: string | null,
): PageResponse {
  const stored = structuredClone(state);
  const registry = new ControlRegistry<Routed<E>>();
  const invalidFields = new Set(state.errors.flatMap((error) => (error.field === null ? [] : [error.field])));
  const pageView = new ViewBuilder<E>(
    ['ctl00', 'MainContent'],
    registrySink(registry, (event: E): Routed<E> => ({ scope: 'page', event }), state.fields, invalidFields),
  );
  const page = definition.render(ctx, state, pageView);
  const layout = page.layout ?? 'master';
  const masterView = new ViewBuilder<MasterEvent>(
    ['ctl00'],
    registrySink(registry, (event: MasterEvent): Routed<E> => ({ scope: 'master', event }), state.fields, invalidFields),
  );
  const masterSearch = layout === 'master' ? quickSearch(masterView) : null;
  const token = ctx.session.documents.save({
    page: ctx.page,
    postBack: (nextCtx, form) => postBack(definition, stored, registry, nextCtx, form),
  });
  return {
    kind: 'html',
    status,
    control,
    body: renderDocumentHtml({
      page: ctx.page,
      title: page.title,
      formAction: `./${ctx.page}${search(ctx.query)}`,
      token,
      generator: viewStateGenerator(ctx.page),
      scrollY: echo.scrollY,
      lastFocus: echo.lastFocus,
      breadcrumbs: page.breadcrumbs,
      quickSearch: masterSearch,
      notice: state.notice,
      errors: state.errors,
      comparison: state.comparison,
      body: page.body,
      renderedAt: ctx.now,
      requestNumber: ctx.requestNumber,
      layout,
    }),
  };
}

type Resolution<T> =
  | { readonly kind: 'none' }
  | { readonly kind: 'event'; readonly event: T; readonly control: string }
  | { readonly kind: 'invalid'; readonly control: string };

/**
 * Event validation: only controls recorded for this document can raise events. A posted submit button wins
 * over __EVENTTARGET, because a page restored from the back-forward cache can still carry a stale target.
 */
function resolveEvent<T>(registry: ControlRegistry<T>, form: PostedForm): Resolution<T> {
  for (const name of form.names()) {
    const control = registry.get(name);
    if (control?.kind === 'submit') return { kind: 'event', event: control.event, control: name };
  }
  const target = form.get('__EVENTTARGET') ?? '';
  const argument = form.get('__EVENTARGUMENT') ?? '';
  if (target !== '') {
    const control = registry.get(target);
    let event: T | undefined;
    if (control?.kind === 'postback') event = control.events.get(argument);
    else if (control?.kind === 'field' && argument === '') event = control.autoPostBack ?? undefined;
    else if (control?.kind === 'submit' && argument === '') event = control.event;
    const label = argument === '' ? target : `${target} ${argument}`;
    return event === undefined ? { kind: 'invalid', control: label } : { kind: 'event', event, control: label };
  }
  return { kind: 'none' };
}

function readEcho(form: PostedForm): Echo {
  const scrollY = form.get('__SCROLLPOSITIONY') ?? '';
  const lastFocus = form.get('__LASTFOCUS') ?? '';
  return {
    scrollY: /^\d{1,7}$/u.test(scrollY) ? scrollY : '',
    lastFocus: /^[A-Za-z][\w]{0,199}$/u.test(lastFocus) ? lastFocus : '',
  };
}

function postBack<S, E>(
  definition: DocumentDefinition<S, E>,
  stored: PageState<S>,
  registry: ControlRegistry<Routed<E>>,
  ctx: PageContext,
  form: PostedForm,
): PageResponse {
  const state = structuredClone(stored);
  state.errors = [];
  state.comparison = [];
  state.notice = null;
  for (const [name, control] of registry.fields()) {
    const posted = form.get(name);
    if (posted === undefined) continue;
    const value = loadPostValue(control.input, posted);
    if (value === undefined) return invalidPostBack(ctx, name);
    state.fields[control.field] = value;
  }
  const resolution = resolveEvent(registry, form);
  if (resolution.kind === 'invalid') return invalidPostBack(ctx, resolution.control);
  const control = resolution.kind === 'event' ? resolution.control : null;
  let outcome: Outcome<S>;
  if (resolution.kind === 'none') {
    outcome = definition.handle(ctx, state, null);
  } else if (resolution.event.scope === 'master') {
    outcome = redirectTo(pageHref('Members.aspx', { q: (state.fields[QUICK_SEARCH_FIELD] ?? '').trim().slice(0, 80) }));
  } else {
    outcome = definition.handle(ctx, state, structuredClone(resolution.event.event));
  }
  switch (outcome.kind) {
    case 'render':
      return renderDocument(definition, ctx, outcome.state, outcome.status, readEcho(form), control);
    case 'redirect':
      return { kind: 'redirect', location: outcome.location, control };
    case 'download':
      return { ...outcome, control };
  }
}

function reloadLink(ctx: PageContext): Link {
  return { href: `${ctx.page}${search(ctx.query)}`, label: 'Reload this page' };
}

function invalidPostBack(ctx: PageContext, control: string): PageResponse {
  return {
    kind: 'html',
    status: 400,
    control,
    body: renderMessagePage({
      title: 'Invalid postback or callback argument',
      paragraphs: [
        'The server rejected this request because it does not match the controls on the page you were viewing. No changes were saved.',
      ],
      links: [reloadLink(ctx), { href: 'Default.aspx', label: 'Home' }],
      renderedAt: ctx.now,
      requestNumber: ctx.requestNumber,
    }),
  };
}

/** Postback entry point: the token must name live page state for this session and page. */
export function handlePostBack(ctx: PageContext, form: PostedForm): PageResponse {
  const token = form.get('__VIEWSTATE') ?? '';
  const document = /^[\w-]{32}$/u.test(token) ? ctx.session.documents.lookup(token) : undefined;
  if (document === undefined || document.page !== ctx.page) {
    return {
      kind: 'html',
      status: 410,
      control: null,
      body: renderMessagePage({
        title: 'This page has expired',
        paragraphs: [
          'The form state for this page is no longer available on the server, so the changes you submitted were not saved.',
          'Pages expire after a period without use, or after many newer pages were opened in this session. Reload the page to continue with current records.',
        ],
        links: [reloadLink(ctx), { href: 'Default.aspx', label: 'Home' }],
        renderedAt: ctx.now,
        requestNumber: ctx.requestNumber,
      }),
    };
  }
  if (form.get('__VIEWSTATEGENERATOR') !== viewStateGenerator(ctx.page)) {
    return invalidPostBack(ctx, '__VIEWSTATEGENERATOR');
  }
  return document.postBack(ctx, form);
}
