import { createHash } from 'node:crypto';

import type { FinanceRecordKind, ServiceCommand } from '@computer-use/financial-database/services';

import { parseMoney, parseSignedMoney } from '../money.js';
import type { PageContext } from '../runtime.js';
import { FieldCheck } from '../validation.js';
import {
  accountSubject,
  approvalSubject,
  caseSubject,
  financeSubject,
  memberSubject,
  mergePlanSubject,
  requestSubject,
  type Choice,
  type Subject,
} from './subjects.js';

export type SubjectKind =
  | 'member'
  | 'account'
  | 'case'
  | 'request'
  | 'merge-plan'
  | 'approval'
  | FinanceRecordKind;

/** Query-string subjects a form resolves to record identity, version and label. */
export interface SubjectSpec {
  readonly key: string;
  readonly kind: SubjectKind;
  readonly label: string;
  readonly optional?: boolean;
}

export type FieldSpec =
  | { readonly input: 'text'; readonly key: string; readonly label: string; readonly required?: boolean; readonly max?: number; readonly help?: string; readonly placeholder?: string }
  | { readonly input: 'textarea'; readonly key: string; readonly label: string; readonly required?: boolean; readonly max?: number; readonly help?: string }
  | { readonly input: 'select'; readonly key: string; readonly label: string; readonly required?: boolean; readonly options: (fx: Fx) => readonly Choice[]; readonly blank?: string; readonly autoPostBack?: boolean }
  | { readonly input: 'money'; readonly key: string; readonly label: string; readonly required?: boolean; readonly signed?: boolean; readonly currency?: (fx: Fx) => string | undefined; readonly help?: string }
  | { readonly input: 'date'; readonly key: string; readonly label: string; readonly required?: boolean }
  | { readonly input: 'instant'; readonly key: string; readonly label: string; readonly required?: boolean; readonly help?: string }
  | { readonly input: 'number'; readonly key: string; readonly label: string; readonly required?: boolean; readonly min?: number; readonly max?: number; readonly help?: string }
  | { readonly input: 'bool'; readonly key: string; readonly label: string }
  | { readonly input: 'lines'; readonly key: string; readonly label: string; readonly required?: boolean; readonly help?: string }
  | { readonly input: 'filetext'; readonly key: string; readonly label: string; readonly required?: boolean; readonly help?: string }
  | { readonly input: 'subject'; readonly key: string; readonly label: string; readonly kind: SubjectKind; readonly required?: boolean; readonly help?: string };

export interface OperationSpec {
  readonly kind: ServiceCommand['kind'];
  readonly title: string;
  readonly section: string;
  readonly summary: string;
  readonly subjects: readonly SubjectSpec[];
  readonly fields: readonly FieldSpec[];
  /** The command carries approvalId: it is requested through the review panel's approval form. */
  readonly approval?: boolean;
  readonly build: (fx: Fx) => Record<string, unknown> | undefined;
}

/** Field extraction with validator-collected errors; `resolve` binds posted subjects to records. */
export class Fx {
  readonly check: FieldCheck;
  readonly #subjects = new Map<string, Subject>();

  constructor(
    readonly ctx: PageContext,
    readonly fields: Readonly<Record<string, string>>,
  ) {
    this.check = new FieldCheck(fields);
  }

  get ok(): boolean {
    return this.check.errors.length === 0;
  }

  fail(field: string | null, message: string): void {
    this.check.fail(field, message);
  }

  raw(key: string): string {
    return this.fields[key] ?? '';
  }

  text(key: string, label: string, options: { required?: boolean; max?: number } = {}): string | undefined {
    const value = this.check.text(key, label, { required: options.required ?? true, max: options.max ?? 500 });
    return value === '' && this.check.errors.every((error) => error.field !== key) ? (options.required === true ? undefined : value) : value;
  }

  /** Optional text: undefined on validation failure, null when blank. */
  opt(key: string, label = key, options: { max?: number } = {}): string | null | undefined {
    const value = this.check.text(key, label, { required: false, max: options.max ?? 500 });
    return this.check.errors.some((error) => error.field === key) ? undefined : value === '' ? null : value;
  }

  pick(key: string, label: string, allowed: readonly Choice[], required = true): string | undefined {
    const value = this.raw(key).trim();
    if (value === '') {
      if (required) this.check.fail(key, `${label} is required.`);
      return undefined;
    }
    if (!allowed.some((choice) => choice.value === value)) {
      this.check.fail(key, `${label} is not one of the offered choices.`);
      return undefined;
    }
    return value;
  }

  int(key: string, label: string, options: { required?: boolean; min?: number; max?: number } = {}): number | undefined {
    return this.check.integer(key, label, { required: options.required ?? true, ...(options.min === undefined ? {} : { min: options.min }), ...(options.max === undefined ? {} : { max: options.max }) });
  }

  bool(key: string): boolean {
    return this.raw(key) === 'yes';
  }

  date(key: string, label: string, required = true): string | undefined {
    return this.check.date(key, label, { required });
  }

  /** Optional date: null when blank. */
  optDate(key: string, label: string): string | null | undefined {
    const value = this.check.date(key, label, { required: false });
    return value === undefined ? (this.check.errors.some((error) => error.field === key) ? undefined : null) : value;
  }

  instant(key: string, label: string, required = true): string | undefined {
    return this.check.instant(key, label, { required });
  }

  optInstant(key: string, label: string): string | null | undefined {
    const value = this.check.instant(key, label, { required: false });
    return value === undefined ? (this.check.errors.some((error) => error.field === key) ? undefined : null) : value;
  }

  /** Parses an amount at `currency`'s exponent; `signed` allows zero and negatives. */
  money(key: string, label: string, currency: string, signed = false, required = true): { minorUnits: number; currency: string } | undefined {
    const value = this.raw(key).trim();
    if (value === '') {
      if (required) this.check.fail(key, `${label} is required.`);
      return undefined;
    }
    if (this.fields[`${key}Minor`] === 'true') {
      if (!/^-?\d{1,15}$/u.test(value)) {
        this.check.fail(key, `${label} must be integer minor units.`);
        return undefined;
      }
      return { minorUnits: Number(value), currency };
    }
    const exponent = this.exponent(currency);
    const minorUnits = signed ? parseSignedMoney(value, exponent) : parseMoney(value, exponent);
    if (minorUnits === undefined) {
      this.check.fail(key, `${label} must be an amount with at most ${String(exponent)} decimal places in ${currency}.`);
      return undefined;
    }
    return { minorUnits, currency };
  }

  /** Signed amount parsed as raw minor units at the posted currency's exponent, for numeric-unit fields. */
  signedMinor(key: string, label: string): number | undefined {
    const value = this.raw(key).trim();
    if (value === '') {
      this.check.fail(key, `${label} is required.`);
      return undefined;
    }
    const currency = (this.fields[`${key}Ccy`] ?? 'USD').trim() || 'USD';
    const minorUnits = parseSignedMoney(value, this.exponent(currency));
    if (minorUnits === undefined) {
      this.check.fail(key, `${label} must be a signed amount.`);
      return undefined;
    }
    return minorUnits;
  }

  exponent(currency: string): number {
    const row = this.ctx.read((db) => db.prepare('SELECT exponent FROM currencies WHERE code=?').get(currency));
    return typeof row?.exponent === 'number' ? row.exponent : 2;
  }

  /** One business reference per line (or comma separated), whitespace-trimmed. */
  lines(key: string, label: string, required = true): string[] | undefined {
    const value = this.raw(key);
    const items = value
      .split(/[\n,]+/u)
      .map((item) => item.trim())
      .filter((item) => item !== '');
    if (items.length === 0 && required) {
      this.check.fail(key, `${label} requires at least one entry.`);
      return undefined;
    }
    if (items.some((item) => item.length > 200)) {
      this.check.fail(key, `${label} entries must be 200 characters or fewer.`);
      return undefined;
    }
    return items;
  }

  /** UTF-8 bytes of posted text for content-addressed document commands. */
  bytes(key: string, label: string, required = true): Uint8Array | undefined {
    const value = this.raw(key);
    if (value.trim() === '') {
      if (required) this.check.fail(key, `${label} is required.`);
      return undefined;
    }
    const encoded = new TextEncoder().encode(value);
    if (encoded.byteLength > 512 * 1024) {
      this.check.fail(key, `${label} exceeds the 512 KiB intake limit.`);
      return undefined;
    }
    return encoded;
  }

  digest(key: string, label: string, required = true): string | undefined {
    const value = this.raw(key).trim();
    if (value === '') {
      if (required) this.check.fail(key, `${label} is required.`);
      return undefined;
    }
    if (!/^[a-f0-9]{64}$/u.test(value)) {
      this.check.fail(key, `${label} must be a lowercase SHA-256 hex digest.`);
      return undefined;
    }
    return value;
  }

  /** SHA-256 of the UTF-8 bytes posted in a text field, for digest-typed inputs. */
  digestOf(key: string): string {
    return createHash('sha256').update(new TextEncoder().encode(this.raw(key))).digest('hex');
  }

  /** Resolves a posted or query-supplied business reference to a record; caches per key. */
  subject(key: string, kind: SubjectKind, label: string, required = true): Subject | undefined {
    const cached = this.#subjects.get(key);
    if (cached !== undefined) return cached;
    const reference = (this.fields[key] ?? '').trim() || (this.ctx.query.get(key) ?? '').trim();
    if (reference === '') {
      if (required) this.check.fail(key, `${label} is required.`);
      return undefined;
    }
    const outcome = resolveSubject(this.ctx, kind, reference);
    if (outcome.kind === 'missing') {
      this.check.fail(key, `${label} "${reference}" was not found.`);
      return undefined;
    }
    if (outcome.kind === 'error') {
      this.check.fail(key, `${label} could not be read: ${outcome.message}`);
      return undefined;
    }
    this.#subjects.set(key, outcome.subject);
    return outcome.subject;
  }

  /** Resolves a query-param subject only; used by builders for bound versions/fingerprints. */
  querySubject(key: string, kind: SubjectKind, label: string, required = true): Subject | undefined {
    const cacheKey = `$query.${key}`;
    const cached = this.#subjects.get(cacheKey);
    if (cached !== undefined) return cached;
    const reference = (this.ctx.query.get(key) ?? '').trim();
    if (reference === '') {
      if (required) this.check.fail(cacheKey, `${label} is required.`);
      return undefined;
    }
    const outcome = resolveSubject(this.ctx, kind, reference);
    if (outcome.kind === 'missing') {
      this.check.fail(cacheKey, `${label} "${reference}" was not found.`);
      return undefined;
    }
    if (outcome.kind === 'error') {
      this.check.fail(cacheKey, `${label} could not be read: ${outcome.message}`);
      return undefined;
    }
    this.#subjects.set(cacheKey, outcome.subject);
    return outcome.subject;
  }
}

export function resolveSubject(ctx: PageContext, kind: SubjectKind, reference: string) {
  switch (kind) {
    case 'member':
      return memberSubject(ctx, reference);
    case 'account':
      return accountSubject(ctx, reference);
    case 'case':
      return caseSubject(ctx, reference);
    case 'request':
      return requestSubject(ctx, reference);
    case 'merge-plan':
      return mergePlanSubject(ctx, reference);
    case 'approval':
      return approvalSubject(ctx, reference);
    default:
      return financeSubject(ctx, kind, reference);
  }
}
