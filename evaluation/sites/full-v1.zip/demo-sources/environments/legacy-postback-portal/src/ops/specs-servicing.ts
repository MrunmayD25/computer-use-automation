import { documentAnnotation, listCaseSubjectCorrectionEvidence } from '@computer-use/financial-database/services';

import { addressFields, addressInput, caseId, caseVersion, memberId, memberVersion, SUBJECT } from './specs-core.js';
import type { Fx, OperationSpec } from './fields.js';
import { cell, pickers, row, rows } from './subjects.js';

const memberParty = (fx: Fx, key = 'member'): string | undefined => {
  const member = fx.subject(key, 'member', 'Member');
  if (member === undefined) return undefined;
  const partyId = pickers.memberPartyId(fx.ctx, member.id);
  if (partyId === undefined) fx.fail(key, 'The member has no party record.');
  return partyId;
};

const evidencePick = (fx: Fx, key: string, memberKey = 'member'): string | undefined => {
  const member = fx.subject(memberKey, 'member', 'Member');
  if (member === undefined) return undefined;
  return fx.pick(key, 'Identity evidence', pickers.memberEvidence(fx.ctx, member.id));
};

const documentVersionPick = (fx: Fx, key: string, label: string, memberKey = 'member', required = true): string | null | undefined => {
  const member = fx.subject(memberKey, 'member', 'Member');
  if (member === undefined) return undefined;
  const value = fx.pick(key, label, pickers.memberDocumentVersions(fx.ctx, member.id), required);
  return required ? value : value ?? null;
};

export const servicingSpecs: OperationSpec[] = [
  {
    kind: 'member.identity_evidence.register',
    title: 'Register identity evidence',
    section: 'members',
    summary: 'Registers an identity document as verified evidence bound to its immutable document version.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'documentVersionId', label: 'Evidence document version', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id);
      } },
      { input: 'text', key: 'evidenceId', label: 'Evidence id', required: false, help: 'Leave blank to let the service assign one.' },
      { input: 'select', key: 'evidenceKind', label: 'Evidence kind', options: () => [
        { value: 'passport', label: 'Passport' },
        { value: 'drivers-license', label: "Driver's license" },
        { value: 'national-id', label: 'National ID' },
        { value: 'state-id', label: 'State ID' },
      ] },
      { input: 'instant', key: 'issuedAt', label: 'Issued at' },
      { input: 'instant', key: 'expiresAt', label: 'Expires at' },
      { input: 'text', key: 'reference', label: 'Source reference', max: 200 },
    ],
    build(fx) {
      const member = memberId(fx);
      const documentVersionId = documentVersionPick(fx, 'documentVersionId', 'Evidence document version');
      const evidenceId = fx.opt('evidenceId', 'Evidence id');
      const evidenceKind = fx.pick('evidenceKind', 'Evidence kind', [
        { value: 'passport', label: 'Passport' },
        { value: 'drivers-license', label: "Driver's license" },
        { value: 'national-id', label: 'National ID' },
        { value: 'state-id', label: 'State ID' },
      ]);
      const issuedAt = fx.instant('issuedAt', 'Issued at');
      const expiresAt = fx.instant('expiresAt', 'Expires at');
      const reference = fx.text('reference', 'Source reference', { max: 200 });
      if ([member, documentVersionId, evidenceId, evidenceKind, issuedAt, expiresAt, reference].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { memberId: member, documentVersionId, evidenceKind, issuedAt, expiresAt, reference };
      if (evidenceId !== null) command.evidenceId = evidenceId;
      return command;
    },
  },
  {
    kind: 'member.identity.verify',
    title: 'Verify member identity',
    section: 'members',
    summary: 'Marks registered identity evidence verified through a recorded method.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'evidenceId', label: 'Identity evidence', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberEvidence(fx.ctx, member.id);
      } },
      { input: 'text', key: 'method', label: 'Verification method', max: 120, placeholder: 'in-person, document-check' },
    ],
    build(fx) {
      const member = memberId(fx);
      const evidenceId = evidencePick(fx, 'evidenceId');
      const method = fx.text('method', 'Verification method', { max: 120 });
      if ([member, evidenceId, method].some((v) => v === undefined)) return undefined;
      return { memberId: member, evidenceId, method };
    },
  },
  {
    kind: 'member.legal_name.update',
    title: 'Update legal name',
    section: 'members',
    summary: 'Changes the member’s legal name on evidence, under independent approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'text', key: 'legalGiven', label: 'Legal given name', max: 80 },
      { input: 'text', key: 'legalFamily', label: 'Legal family name', max: 80 },
      { input: 'select', key: 'evidenceId', label: 'Identity evidence', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberEvidence(fx.ctx, member.id);
      } },
    ],
    build(fx) {
      const member = memberId(fx);
      const expectedVersion = memberVersion(fx);
      const legalGiven = fx.text('legalGiven', 'Legal given name');
      const legalFamily = fx.text('legalFamily', 'Legal family name');
      const evidenceId = evidencePick(fx, 'evidenceId');
      if ([member, expectedVersion, legalGiven, legalFamily, evidenceId].some((v) => v === undefined)) return undefined;
      return { memberId: member, expectedVersion, legalGiven, legalFamily, evidenceId };
    },
  },
  {
    kind: 'member.preferred_name.update',
    title: 'Update preferred name',
    section: 'members',
    summary: 'Sets or clears the member’s preferred name and its communication scope.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'text', key: 'preferredName', label: 'Preferred name', required: false, max: 80, help: 'Blank clears the preferred name.' },
      { input: 'select', key: 'communicationScope', label: 'Scope', options: () => [
        { value: 'servicing', label: 'Servicing' },
        { value: 'communications', label: 'Communications' },
        { value: 'all', label: 'All' },
      ] },
    ],
    build(fx) {
      const member = memberId(fx);
      const expectedVersion = memberVersion(fx);
      const preferredName = fx.opt('preferredName', 'Preferred name', { max: 80 });
      const communicationScope = fx.pick('communicationScope', 'Scope', [
        { value: 'servicing', label: 'Servicing' },
        { value: 'communications', label: 'Communications' },
        { value: 'all', label: 'All' },
      ]);
      if ([member, expectedVersion, preferredName, communicationScope].some((v) => v === undefined)) return undefined;
      return { memberId: member, expectedVersion, preferredName, communicationScope };
    },
  },
  {
    kind: 'document.index',
    title: 'Index document',
    section: 'documents',
    summary: 'Stores a new immutable document version for the member, content-addressed from exact bytes.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'accountId', label: 'Account', required: false, blank: '(member-level document)', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberAccounts(fx.ctx, member.id);
      } },
      { input: 'text', key: 'documentId', label: 'Existing document id', required: false, help: 'Adds a version to that document; blank creates a new document.' },
      { input: 'text', key: 'documentType', label: 'Document type', max: 60, placeholder: 'account-statement, disclosure, correspondence' },
      { input: 'text', key: 'displayName', label: 'Display name', max: 160 },
      { input: 'select', key: 'retentionClass', label: 'Retention class', options: () => [
        { value: 'standard', label: 'Standard' },
        { value: 'extended', label: 'Extended' },
        { value: 'legal', label: 'Legal' },
      ] },
      { input: 'filetext', key: 'bytes', label: 'Document content' },
      { input: 'text', key: 'mediaType', label: 'Media type', required: false, max: 80, placeholder: 'text/plain' },
      { input: 'number', key: 'pageCount', label: 'Page count', required: false, min: 1, max: 10000 },
      { input: 'text', key: 'source', label: 'Source', required: false, max: 120 },
      { input: 'text', key: 'sourceDigest', label: 'Source digest', required: false, max: 64, help: 'Lowercase SHA-256 when the source pins one.' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const ownerPartyId = member === undefined ? undefined : pickers.memberPartyId(fx.ctx, member.id);
      const accountId = member === undefined ? undefined : fx.pick('accountId', 'Account', pickers.memberAccounts(fx.ctx, member.id), false) ?? null;
      const documentId = fx.opt('documentId', 'Existing document id');
      const documentType = fx.text('documentType', 'Document type', { max: 60 });
      const displayName = fx.text('displayName', 'Display name', { max: 160 });
      const retentionClass = fx.pick('retentionClass', 'Retention class', [
        { value: 'standard', label: 'Standard' },
        { value: 'extended', label: 'Extended' },
        { value: 'legal', label: 'Legal' },
      ]);
      const bytes = fx.bytes('bytes', 'Document content');
      const mediaType = fx.opt('mediaType', 'Media type', { max: 80 });
      const pageCount = fx.int('pageCount', 'Page count', { required: false, min: 1, max: 10000 });
      const source = fx.opt('source', 'Source', { max: 120 });
      const sourceDigest = fx.opt('sourceDigest', 'Source digest', { max: 64 });
      if (sourceDigest !== undefined && sourceDigest !== null && !/^[a-f0-9]{64}$/u.test(sourceDigest)) {
        fx.fail('sourceDigest', 'Source digest must be lowercase SHA-256 hex.');
        return undefined;
      }
      if ([member, ownerPartyId, accountId, documentId, documentType, displayName, retentionClass, bytes, mediaType, source, sourceDigest].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { memberId: member?.id, ownerPartyId, accountId, documentType, displayName, retentionClass, bytes };
      if (documentId !== null) command.documentId = documentId;
      if (mediaType !== null) command.mediaType = mediaType;
      if (pageCount !== undefined) command.pageCount = pageCount;
      if (source !== null) command.source = source;
      if (sourceDigest !== null) command.sourceDigest = sourceDigest;
      return command;
    },
  },
  {
    kind: 'document.bundle.redact',
    title: 'Redact document bundle',
    section: 'documents',
    summary: 'Produces a text-only derivative retaining only the approved excerpts of the source versions.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'lines', key: 'sourceVersionIds', label: 'Source version ids', help: 'One document version id per line.' },
      { input: 'text', key: 'recipientPurpose', label: 'Recipient purpose', max: 120 },
      { input: 'select', key: 'redactionPolicyVersionId', label: 'Redaction policy', options: (fx) => pickers.policies(fx.ctx) },
      { input: 'textarea', key: 'approvedExcerpts', label: 'Approved excerpts', help: 'One excerpt per line as versionId|exact source text.', max: 16000 },
      { input: 'text', key: 'displayName', label: 'Display name', required: false, max: 160 },
    ],
    build(fx) {
      const member = memberId(fx);
      const sourceVersionIds = fx.lines('sourceVersionIds', 'Source version ids');
      const recipientPurpose = fx.text('recipientPurpose', 'Recipient purpose', { max: 120 });
      const redactionPolicyVersionId = fx.pick('redactionPolicyVersionId', 'Redaction policy', pickers.policies(fx.ctx));
      const rawExcerpts = fx.lines('approvedExcerpts', 'Approved excerpts');
      const displayName = fx.opt('displayName', 'Display name', { max: 160 });
      const approvedExcerpts = rawExcerpts?.map((line) => {
        const split = line.indexOf('|');
        if (split < 1) {
          fx.fail('approvedExcerpts', `Excerpt "${line.slice(0, 40)}" must be versionId|text.`);
          return undefined;
        }
        return { sourceVersionId: line.slice(0, split).trim(), text: line.slice(split + 1) };
      });
      if (approvedExcerpts?.some((excerpt) => excerpt === undefined)) return undefined;
      if ([member, sourceVersionIds, recipientPurpose, redactionPolicyVersionId, approvedExcerpts, displayName].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { memberId: member, sourceVersionIds, recipientPurpose, redactionPolicyVersionId, approvedExcerpts };
      if (displayName !== null) command.displayName = displayName;
      return command;
    },
  },
  {
    kind: 'document.signature.collect',
    title: 'Collect document signature',
    section: 'documents',
    summary: 'Requests, records, declines or expires a signature on one immutable document version.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'action', label: 'Action', options: () => [
        { value: 'request', label: 'Request signature' },
        { value: 'sign', label: 'Record signed' },
        { value: 'decline', label: 'Record declined' },
        { value: 'expire', label: 'Expire request' },
      ], autoPostBack: true },
      { input: 'select', key: 'documentVersionId', label: 'Document version', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id);
      } },
      { input: 'lines', key: 'signerPartyIds', label: 'Signer party ids', help: 'One party id per line; the member’s party id is listed in the member header.' },
      { input: 'text', key: 'channel', label: 'Channel', max: 40, placeholder: 'branch, email' },
      { input: 'text', key: 'evidenceReference', label: 'Evidence version id', required: false, help: 'Required when recording sign or decline.' },
    ],
    build(fx) {
      const action = fx.pick('action', 'Action', [
        { value: 'request', label: 'Request' },
        { value: 'sign', label: 'Sign' },
        { value: 'decline', label: 'Decline' },
        { value: 'expire', label: 'Expire' },
      ]);
      const documentVersionId = documentVersionPick(fx, 'documentVersionId', 'Document version');
      const signerPartyIds = fx.lines('signerPartyIds', 'Signer party ids');
      const channel = fx.text('channel', 'Channel', { max: 40 });
      const evidenceReference = fx.opt('evidenceReference', 'Evidence version id');
      if ([action, documentVersionId, signerPartyIds, channel, evidenceReference].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { action, documentVersionId, signerPartyIds, channel };
      if (evidenceReference !== null) command.evidenceReference = evidenceReference;
      return command;
    },
  },
  {
    kind: 'consent.delivery.record',
    title: 'Record consent',
    section: 'documents',
    summary: 'Records the member’s affirmative consent to a disclosure version over a channel.',
    subjects: [SUBJECT.member, SUBJECT.accountOptional],
    fields: [
      { input: 'text', key: 'purpose', label: 'Purpose', max: 60, placeholder: 'statements, marketing' },
      { input: 'text', key: 'channel', label: 'Channel', max: 40, placeholder: 'electronic, postal' },
      { input: 'select', key: 'disclosureVersionId', label: 'Disclosure version', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id, 'disclosure');
      } },
      { input: 'text', key: 'evidence', label: 'Acknowledgement evidence', max: 200 },
    ],
    build(fx) {
      const partyId = memberParty(fx);
      const account = fx.subject('account', 'account', 'Account', false);
      const purpose = fx.text('purpose', 'Purpose', { max: 60 });
      const channel = fx.text('channel', 'Channel', { max: 40 });
      const disclosureVersionId = documentVersionPick(fx, 'disclosureVersionId', 'Disclosure version');
      const evidence = fx.text('evidence', 'Acknowledgement evidence', { max: 200 });
      if ([partyId, purpose, channel, disclosureVersionId, evidence].some((v) => v === undefined)) return undefined;
      return { partyId, accountId: account?.id ?? null, purpose, channel, disclosureVersionId, evidence };
    },
  },
  {
    kind: 'consent.withdraw',
    title: 'Withdraw consent',
    section: 'documents',
    summary: 'Withdraws a granted consent across the selected channels.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'consentId', label: 'Consent', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberConsents(fx.ctx, member.id);
      } },
      { input: 'instant', key: 'effectiveAt', label: 'Effective at', required: false },
      { input: 'lines', key: 'affectedChannels', label: 'Affected channels', help: 'One channel per line, for example electronic.' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const consentId = member === undefined ? undefined : fx.pick('consentId', 'Consent', pickers.memberConsents(fx.ctx, member.id));
      const effectiveAt = fx.optInstant('effectiveAt', 'Effective at');
      const affectedChannels = fx.lines('affectedChannels', 'Affected channels');
      if ([consentId, effectiveAt, affectedChannels].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { consentId, affectedChannels };
      if (effectiveAt !== null) command.effectiveAt = effectiveAt;
      return command;
    },
  },
  {
    kind: 'document.customer_export.create',
    title: 'Create customer export',
    section: 'documents',
    summary: 'Generates the member’s portable record export under approval, bound to exact versions.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'lines', key: 'categories', label: 'Categories', help: 'One export category per line, for example accounts, documents.' },
      { input: 'date', key: 'from', label: 'From date', required: false },
      { input: 'date', key: 'through', label: 'Through date', required: false },
      { input: 'text', key: 'destination', label: 'Destination', max: 200, placeholder: 'member-download' },
      { input: 'lines', key: 'documentVersionIds', label: 'Document version ids', help: 'Exact preflight inventory; one per line.' },
    ],
    build(fx) {
      const member = memberId(fx);
      const categories = fx.lines('categories', 'Categories');
      const from = fx.optDate('from', 'From date');
      const through = fx.optDate('through', 'Through date');
      const destination = fx.text('destination', 'Destination', { max: 200 });
      const documentVersionIds = fx.lines('documentVersionIds', 'Document version ids');
      if ([member, categories, from, through, destination, documentVersionIds].some((v) => v === undefined)) return undefined;
      return { memberId: member, categories, from, through, destination, documentVersionIds };
    },
  },
  {
    kind: 'document.retention_hold.apply',
    title: 'Apply retention hold',
    section: 'documents',
    summary: 'Places a retention hold on a document or case under approval.',
    subjects: [],
    approval: true,
    fields: [
      { input: 'select', key: 'target', label: 'Hold target', options: () => [
        { value: 'document', label: 'Document' },
        { value: 'case', label: 'Case' },
      ], autoPostBack: true },
      { input: 'select', key: 'documentId', label: 'Document', required: false, blank: '(choose)', options: (fx) => pickers.documents(fx.ctx) },
      { input: 'subject', key: 'caseRef', kind: 'case', label: 'Case', required: false, help: 'Case number or id; used when the target is a case.' },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
      { input: 'instant', key: 'reviewAt', label: 'Review at' },
    ],
    build(fx) {
      const target = fx.pick('target', 'Hold target', [
        { value: 'document', label: 'Document' },
        { value: 'case', label: 'Case' },
      ]);
      const documentId = fx.pick('documentId', 'Document', pickers.documents(fx.ctx), false);
      const caseSubject = fx.subject('caseRef', 'case', 'Case', false);
      const reason = fx.text('reason', 'Reason', { max: 200 });
      const reviewAt = fx.instant('reviewAt', 'Review at');
      if ([target, reason, reviewAt].some((v) => v === undefined)) return undefined;
      if (target === 'document' && documentId === undefined) {
        fx.fail('documentId', 'Choose the document to hold.');
        return undefined;
      }
      if (target === 'case' && caseSubject === undefined) {
        fx.fail('caseRef', 'Choose the case to hold.');
        return undefined;
      }
      const command: Record<string, unknown> = { reason, reviewAt };
      if (target === 'document') command.documentId = documentId;
      else command.caseId = caseSubject?.id;
      return command;
    },
  },
  {
    kind: 'case.information.request',
    title: 'Request case information',
    section: 'cases',
    summary: 'Asks the member for the listed fields with a due instant and delivery channel.',
    subjects: [SUBJECT.case],
    fields: [
      { input: 'lines', key: 'fields', label: 'Requested fields', help: 'One field name per line.' },
      { input: 'select', key: 'recipientPartyId', label: 'Recipient', options: (fx) => {
        const subject = fx.subject('case', 'case', 'Case');
        const memberId = subject?.record?.member_id;
        return typeof memberId === 'string' ? pickers.parties(fx.ctx).filter((p) => p.value === pickers.memberPartyId(fx.ctx, memberId)) : pickers.parties(fx.ctx);
      } },
      { input: 'text', key: 'channel', label: 'Channel', max: 40 },
      { input: 'instant', key: 'dueAt', label: 'Due at' },
      { input: 'select', key: 'documentVersionId', label: 'Attached document', required: false, blank: '(none)', options: (fx) => {
        const subject = fx.subject('case', 'case', 'Case');
        const memberId = subject?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberDocumentVersions(fx.ctx, memberId) : [];
      } },
      { input: 'text', key: 'destination', label: 'Destination', required: false, max: 200 },
    ],
    build(fx) {
      const id = caseId(fx);
      const expectedVersion = caseVersion(fx);
      const fields = fx.lines('fields', 'Requested fields');
      const recipientPartyId = fx.text('recipientPartyId', 'Recipient', { max: 80 });
      const channel = fx.text('channel', 'Channel', { max: 40 });
      const dueAt = fx.instant('dueAt', 'Due at');
      const subject = fx.subject('case', 'case', 'Case');
      const memberId = subject?.record?.member_id;
      const documentVersionId = typeof memberId === 'string' ? fx.pick('documentVersionId', 'Attached document', pickers.memberDocumentVersions(fx.ctx, memberId), false) ?? null : null;
      const destination = fx.opt('destination', 'Destination', { max: 200 });
      if ([id, expectedVersion, fields, recipientPartyId, channel, dueAt, destination].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { caseId: id, expectedVersion, fields, recipientPartyId, channel, dueAt, documentVersionId };
      if (destination !== null) command.destination = destination;
      return command;
    },
  },
  {
    kind: 'case.escalate',
    title: 'Escalate case',
    section: 'cases',
    summary: 'Escalates the case under the named escalation rule.',
    subjects: [SUBJECT.case],
    fields: [{ input: 'text', key: 'escalationRule', label: 'Escalation rule', max: 120, placeholder: 'supervisor-review' }],
    build(fx) {
      const id = caseId(fx);
      const expectedVersion = caseVersion(fx);
      const escalationRule = fx.text('escalationRule', 'Escalation rule', { max: 120 });
      if ([id, expectedVersion, escalationRule].some((v) => v === undefined)) return undefined;
      return { caseId: id, expectedVersion, escalationRule };
    },
  },
  {
    kind: 'maintenance.address.reconcile',
    title: 'Reconcile conflicting address',
    section: 'requests',
    summary: 'Resolves a conflicting address record against the winning evidence under approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'select', key: 'conflictingAddressId', label: 'Conflicting address', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberAddressRows(fx.ctx, member.id).filter((a) => a.evidenceStatus === 'conflicting').map((a) => ({ value: a.addressId, label: `${a.line1}, ${a.city}` }));
      } },
      { input: 'select', key: 'winningEvidenceVersionId', label: 'Winning evidence version', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id);
      } },
      { input: 'text', key: 'winningEvidenceDigest', label: 'Evidence digest', max: 64, help: 'SHA-256 of the winning version’s bytes, shown on the document detail.' },
      { input: 'text', key: 'precedence', label: 'Precedence rule', max: 120, placeholder: 'verified-evidence-wins' },
      ...addressFields('addr', true),
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const expectedMemberVersion = memberVersion(fx);
      const addresses = member === undefined ? [] : pickers.memberAddressRows(fx.ctx, member.id).filter((a) => a.evidenceStatus === 'conflicting');
      const conflictingAddressId = member === undefined ? undefined : fx.pick('conflictingAddressId', 'Conflicting address', addresses.map((a) => ({ value: a.addressId, label: a.line1 })));
      const winningEvidenceVersionId = member === undefined ? undefined : fx.pick('winningEvidenceVersionId', 'Winning evidence version', pickers.memberDocumentVersions(fx.ctx, member.id));
      const winningEvidenceDigest = fx.digest('winningEvidenceDigest', 'Evidence digest');
      const precedence = fx.text('precedence', 'Precedence rule', { max: 120 });
      const address = addressInput(fx, 'addr', true);
      if ([member, expectedMemberVersion, conflictingAddressId, winningEvidenceVersionId, winningEvidenceDigest, precedence, address].some((v) => v === undefined)) return undefined;
      return { memberId: member?.id, expectedMemberVersion, conflictingAddressId, winningEvidenceVersionId, winningEvidenceDigest, precedence, address };
    },
  },
  {
    kind: 'maintenance.address.destination.update',
    title: 'Update address destination',
    section: 'requests',
    summary: 'Points a servicing context (mailing, statements, card shipping, loan notices) at a verified address under approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'select', key: 'context', label: 'Destination context', options: () => [
        { value: 'member-mailing', label: 'Member mailing' },
        { value: 'account-statement', label: 'Account statement' },
        { value: 'card-shipping', label: 'Card shipping' },
        { value: 'loan-notice', label: 'Loan notice' },
      ], autoPostBack: true },
      { input: 'select', key: 'targetId', label: 'Target record', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        const context = fx.raw('context');
        if (member === undefined) return [];
        switch (context) {
          case 'account-statement':
            return pickers.memberAccounts(fx.ctx, member.id);
          case 'card-shipping':
            return rows(fx.ctx, `SELECT c.id,c.last_four FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? AND a.member_id=?`, fx.ctx.binding.datasetId, member.id).map((r) => ({ value: String(r.id), label: `Card •••• ${String(r.last_four)}` }));
          case 'loan-notice':
            return rows(fx.ctx, `SELECT l.id FROM loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id WHERE l.dataset_id=? AND a.member_id=?`, fx.ctx.binding.datasetId, member.id).map((r) => ({ value: String(r.id), label: `Loan ${String(r.id).slice(-8)}` }));
          default:
            return [{ value: member.id, label: 'This member' }];
        }
      } },
      { input: 'select', key: 'partyAddressId', label: 'Address', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberAddresses(fx.ctx, member.id);
      } },
      { input: 'select', key: 'evidenceVersionId', label: 'Address evidence version', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id);
      } },
      { input: 'date', key: 'effectiveDate', label: 'Effective date' },
      { input: 'select', key: 'consentId', label: 'Postal consent', required: false, blank: '(not required)', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberConsents(fx.ctx, member.id);
      } },
      { input: 'select', key: 'expectedCurrentDestinationId', label: 'Current destination', required: false, blank: '(none currently effective)', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDestinations(fx.ctx, member.id);
      } },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const context = fx.pick('context', 'Destination context', [
        { value: 'member-mailing', label: 'Member mailing' },
        { value: 'account-statement', label: 'Account statement' },
        { value: 'card-shipping', label: 'Card shipping' },
        { value: 'loan-notice', label: 'Loan notice' },
      ]);
      const targetId = fx.text('targetId', 'Target record', { max: 80 });
      const addresses = member === undefined ? [] : pickers.memberAddresses(fx.ctx, member.id);
      const partyAddressId = member === undefined ? undefined : fx.pick('partyAddressId', 'Address', addresses);
      const addressRow = member === undefined || partyAddressId === undefined ? undefined : pickers.memberAddressRows(fx.ctx, member.id).find((a) => a.partyAddressId === partyAddressId);
      const evidenceVersionId = member === undefined ? undefined : fx.pick('evidenceVersionId', 'Address evidence version', pickers.memberDocumentVersions(fx.ctx, member.id));
      const effectiveDate = fx.date('effectiveDate', 'Effective date');
      const consentId = member === undefined ? undefined : fx.pick('consentId', 'Postal consent', pickers.memberConsents(fx.ctx, member.id), false) ?? null;
      const expectedCurrentDestinationId = member === undefined ? undefined : fx.pick('expectedCurrentDestinationId', 'Current destination', pickers.memberDestinations(fx.ctx, member.id), false) ?? null;
      if ([member, context, targetId, addressRow, evidenceVersionId, effectiveDate, consentId, expectedCurrentDestinationId].some((v) => v === undefined)) return undefined;
      return { memberId: member?.id, context, targetId, addressId: addressRow?.addressId, evidenceVersionId, effectiveDate, expectedCurrentDestinationId, consentId };
    },
  },
  {
    kind: 'case.close',
    title: 'Close case',
    section: 'cases',
    summary: 'Closes the case with a resolution code bound to effect evidence.',
    subjects: [SUBJECT.case],
    fields: [
      { input: 'text', key: 'resolutionCode', label: 'Resolution code', max: 60, placeholder: 'resolved, no-action' },
      { input: 'select', key: 'effectEvidenceVersionId', label: 'Effect evidence version', options: (fx) => {
        const subject = fx.subject('case', 'case', 'Case');
        const memberId = subject?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberDocumentVersions(fx.ctx, memberId) : [];
      } },
    ],
    build(fx) {
      const id = caseId(fx);
      const expectedVersion = caseVersion(fx);
      const resolutionCode = fx.text('resolutionCode', 'Resolution code', { max: 60 });
      const subject = fx.subject('case', 'case', 'Case');
      const memberId = subject?.record?.member_id;
      const effectEvidenceVersionId = typeof memberId === 'string' ? fx.pick('effectEvidenceVersionId', 'Effect evidence version', pickers.memberDocumentVersions(fx.ctx, memberId)) : undefined;
      if ([id, expectedVersion, resolutionCode, effectEvidenceVersionId].some((v) => v === undefined)) return undefined;
      return { caseId: id, expectedVersion, resolutionCode, effectEvidenceVersionId };
    },
  },
  {
    kind: 'case.reopen',
    title: 'Reopen case',
    section: 'cases',
    summary: 'Reopens a closed case on new evidence with a fresh due instant.',
    subjects: [SUBJECT.case],
    fields: [
      { input: 'select', key: 'evidenceVersionId', label: 'Reopening evidence version', options: (fx) => {
        const subject = fx.subject('case', 'case', 'Case');
        const memberId = subject?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberDocumentVersions(fx.ctx, memberId) : [];
      } },
      { input: 'text', key: 'reopeningBasis', label: 'Reopening basis', max: 300 },
      { input: 'instant', key: 'dueAt', label: 'New due at', required: false },
    ],
    build(fx) {
      const id = caseId(fx);
      const expectedVersion = caseVersion(fx);
      const subject = fx.subject('case', 'case', 'Case');
      const memberId = subject?.record?.member_id;
      const evidenceVersionId = typeof memberId === 'string' ? fx.pick('evidenceVersionId', 'Reopening evidence version', pickers.memberDocumentVersions(fx.ctx, memberId)) : undefined;
      const reopeningBasis = fx.text('reopeningBasis', 'Reopening basis', { max: 300 });
      const dueAt = fx.optInstant('dueAt', 'New due at');
      if ([id, expectedVersion, evidenceVersionId, reopeningBasis, dueAt].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { caseId: id, expectedVersion, evidenceVersionId, reopeningBasis };
      if (dueAt !== null) command.dueAt = dueAt;
      return command;
    },
  },
  {
    kind: 'case.subject.correct',
    title: 'Correct case subject',
    section: 'cases',
    summary: 'Rebinds the case to the correct member/account on evidence, under approval.',
    subjects: [SUBJECT.case],
    approval: true,
    fields: [
      { input: 'subject', key: 'correctMember', kind: 'member', label: 'Correct member' },
      { input: 'subject', key: 'correctAccount', kind: 'account', label: 'Correct account', required: false },
      { input: 'select', key: 'evidenceVersionId', label: 'Correction evidence version', options: (fx) => {
        const subject = fx.subject('case', 'case', 'Case');
        const original = subject?.record?.member_id;
        const corrected = fx.subject('correctMember', 'member', 'Correct member');
        if (typeof original !== 'string' || corrected === undefined) return [];
        const evidence = fx.ctx.svc((db, context) => listCaseSubjectCorrectionEvidence(db, context, original, corrected.id));
        return evidence.kind === 'authorized' ? evidence.value.evidenceDocuments.map((d) => ({ value: d.versionId, label: `${d.displayName} v${d.version}` })) : [];
      } },
    ],
    build(fx) {
      const id = caseId(fx);
      const expectedVersion = caseVersion(fx);
      const correctMember = fx.subject('correctMember', 'member', 'Correct member');
      const correctAccount = fx.subject('correctAccount', 'account', 'Correct account', false);
      const evidenceVersionId = fx.text('evidenceVersionId', 'Correction evidence version', { max: 80 });
      if ([id, expectedVersion, correctMember, evidenceVersionId].some((v) => v === undefined)) return undefined;
      return { caseId: id, expectedVersion, correctMemberId: correctMember?.id, correctAccountId: correctAccount?.id ?? null, evidenceVersionId };
    },
  },
  {
    kind: 'document.annotation.update',
    title: 'Annotate document',
    section: 'documents',
    summary: 'Creates, amends or removes a page-region annotation on a document version.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'documentVersionId', label: 'Document version', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id);
      }, autoPostBack: true },
      { input: 'select', key: 'action', label: 'Action', options: () => [
        { value: 'create', label: 'Create' },
        { value: 'amend', label: 'Amend' },
        { value: 'remove', label: 'Remove' },
      ], autoPostBack: true },
      { input: 'select', key: 'annotationId', label: 'Annotation', required: false, blank: '(new annotation)', options: (fx) => {
        const versionId = fx.raw('documentVersionId');
        if (versionId === '') return [];
        return rows(fx.ctx, `SELECT id,page_number,status FROM document_annotations WHERE dataset_id=? AND document_version_id=? ORDER BY page_number`, fx.ctx.binding.datasetId, versionId)
          .map((r) => ({ value: String(r.id), label: `Page ${String(r.page_number)} (${String(r.status)}) ${String(r.id).slice(-8)}` }));
      } },
      { input: 'number', key: 'pageNumber', label: 'Page', min: 1, max: 10000 },
      { input: 'text', key: 'region', label: 'Region (x,y,w,h micros)', max: 60, placeholder: '0,0,1000000,200000' },
      { input: 'textarea', key: 'text', label: 'Annotation text', required: false, max: 2000 },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const documentVersionId = member === undefined ? undefined : fx.pick('documentVersionId', 'Document version', pickers.memberDocumentVersions(fx.ctx, member.id));
      const action = fx.pick('action', 'Action', [
        { value: 'create', label: 'Create' },
        { value: 'amend', label: 'Amend' },
        { value: 'remove', label: 'Remove' },
      ]);
      const annotations = documentVersionId === undefined ? [] : rows(fx.ctx, `SELECT id,page_number,status FROM document_annotations WHERE dataset_id=? AND document_version_id=? ORDER BY page_number`, fx.ctx.binding.datasetId, documentVersionId);
      const annotationId = fx.pick('annotationId', 'Annotation', annotations.map((r) => ({ value: String(r.id), label: String(r.id) })), false);
      const pageNumber = fx.int('pageNumber', 'Page', { min: 1, max: 10000 });
      const regionText = fx.text('region', 'Region', { max: 60 });
      const regionParts = regionText?.split(',').map((part) => Number(part.trim()));
      if (regionParts === undefined || regionParts.length !== 4 || regionParts.some((part) => !Number.isSafeInteger(part) || part < 0)) {
        fx.fail('region', 'Region must be four nonnegative integers: x,y,width,height in micros.');
        return undefined;
      }
      const text = fx.opt('text', 'Annotation text', { max: 2000 });
      if ([documentVersionId, action, pageNumber, text].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { documentVersionId, pageNumber, regionMicros: { x: regionParts[0], y: regionParts[1], width: regionParts[2], height: regionParts[3] }, action };
      if (annotationId !== undefined) command.annotationId = annotationId;
      if (action !== 'create') {
        if (annotationId === undefined) {
          fx.fail('annotationId', 'Choose the annotation to amend or remove.');
          return undefined;
        }
        const stored = fx.ctx.svc((db, context) => documentAnnotation(db, context, annotationId));
        if (stored.kind === 'rejected') {
          fx.fail('annotationId', stored.message);
          return undefined;
        }
        if (stored.value === undefined) {
          fx.fail('annotationId', 'The annotation no longer exists.');
          return undefined;
        }
        command.expectedAnnotationFingerprint = stored.value.fingerprint;
      }
      if (text !== null) command.text = text;
      return command;
    },
  },
  {
    kind: 'document.metadata.update',
    title: 'Update document metadata',
    section: 'documents',
    summary: 'Rebinds a document’s type, name, owner, account or retention class against its stored metadata.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'documentId', label: 'Document', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.documents(fx.ctx, member.id);
      }, autoPostBack: true },
      { input: 'text', key: 'documentType', label: 'Document type', max: 60 },
      { input: 'text', key: 'displayName', label: 'Display name', max: 160 },
      { input: 'select', key: 'ownerPartyId', label: 'Owner party', options: (fx) => pickers.parties(fx.ctx) },
      { input: 'select', key: 'accountId', label: 'Account', required: false, blank: '(member-level document)', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberAccounts(fx.ctx, member.id);
      } },
      { input: 'select', key: 'retentionClass', label: 'Retention class', options: () => [
        { value: 'standard', label: 'Standard' },
        { value: 'extended', label: 'Extended' },
        { value: 'legal', label: 'Legal' },
      ] },
      { input: 'text', key: 'approvalId', label: 'Approval id', required: false, help: 'Required when the owner or account association changes.' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const documentId = member === undefined ? undefined : fx.pick('documentId', 'Document', pickers.documents(fx.ctx, member.id));
      const stored = documentId === undefined ? undefined : row(fx.ctx, 'SELECT owner_party_id,account_id,document_type,display_name,retention_class FROM documents WHERE dataset_id=? AND id=?', fx.ctx.binding.datasetId, documentId);
      const documentType = fx.text('documentType', 'Document type', { max: 60 });
      const displayName = fx.text('displayName', 'Display name', { max: 160 });
      const ownerPartyId = fx.pick('ownerPartyId', 'Owner party', pickers.parties(fx.ctx));
      const accountId = member === undefined ? undefined : fx.pick('accountId', 'Account', pickers.memberAccounts(fx.ctx, member.id), false) ?? null;
      const retentionClass = fx.pick('retentionClass', 'Retention class', [
        { value: 'standard', label: 'Standard' },
        { value: 'extended', label: 'Extended' },
        { value: 'legal', label: 'Legal' },
      ]);
      const approvalId = fx.opt('approvalId', 'Approval id', { max: 80 });
      if ([documentId, stored, documentType, displayName, ownerPartyId, accountId, retentionClass, approvalId].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = {
        documentId,
        expectedMetadata: {
          ownerPartyId: cell(stored?.owner_party_id),
          accountId: stored?.account_id === null || stored?.account_id === undefined ? null : cell(stored.account_id),
          documentType: cell(stored?.document_type),
          displayName: cell(stored?.display_name),
          retentionClass: cell(stored?.retention_class),
        },
        documentType,
        displayName,
        ownerPartyId,
        accountId,
        retentionClass,
      };
      if (approvalId !== null) command.approvalId = approvalId;
      return command;
    },
  },
  {
    kind: 'communication.preference.update',
    title: 'Update communication preference',
    section: 'documents',
    summary: 'Enables or disables one purpose/channel communication preference for the member.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'text', key: 'purpose', label: 'Purpose', max: 60 },
      { input: 'text', key: 'channel', label: 'Channel', max: 40 },
      { input: 'select', key: 'state', label: 'State', options: () => [
        { value: 'enabled', label: 'Enabled' },
        { value: 'disabled', label: 'Disabled' },
      ] },
    ],
    build(fx) {
      const partyId = memberParty(fx);
      const purpose = fx.text('purpose', 'Purpose', { max: 60 });
      const channel = fx.text('channel', 'Channel', { max: 40 });
      const state = fx.pick('state', 'State', [
        { value: 'enabled', label: 'Enabled' },
        { value: 'disabled', label: 'Disabled' },
      ]);
      if ([partyId, purpose, channel, state].some((v) => v === undefined)) return undefined;
      return { partyId, purpose, channel, state };
    },
  },
  {
    kind: 'communication.send',
    title: 'Send communication',
    section: 'documents',
    summary: 'Queues a communication job for the member over a channel with an optional document.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'text', key: 'channel', label: 'Channel', max: 40, placeholder: 'email, postal' },
      { input: 'text', key: 'destination', label: 'Destination', required: false, max: 200, help: 'Electronic address; postal derives from the address destination.' },
      { input: 'select', key: 'addressDestinationId', label: 'Address destination', required: false, blank: '(none)', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDestinations(fx.ctx, member.id);
      } },
      { input: 'text', key: 'purpose', label: 'Purpose', max: 60 },
      { input: 'select', key: 'documentVersionId', label: 'Document version', required: false, blank: '(none)', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id);
      } },
      { input: 'text', key: 'jobId', label: 'Job id', required: false, max: 80, help: 'Reuse a draft job id, or leave blank to create one.' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const partyId = member === undefined ? undefined : pickers.memberPartyId(fx.ctx, member.id);
      const channel = fx.text('channel', 'Channel', { max: 40 });
      const destination = fx.opt('destination', 'Destination', { max: 200 });
      const addressDestinationId = member === undefined ? undefined : fx.pick('addressDestinationId', 'Address destination', pickers.memberDestinations(fx.ctx, member.id), false) ?? null;
      const purpose = fx.text('purpose', 'Purpose', { max: 60 });
      const documentVersionId = member === undefined ? undefined : fx.pick('documentVersionId', 'Document version', pickers.memberDocumentVersions(fx.ctx, member.id), false) ?? null;
      const jobId = fx.opt('jobId', 'Job id', { max: 80 });
      if ([partyId, channel, destination, addressDestinationId, purpose, documentVersionId, jobId].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { partyId, channel, purpose };
      if (destination !== null) command.destination = destination;
      if (addressDestinationId !== null) command.addressDestinationId = addressDestinationId;
      if (documentVersionId !== null) command.documentVersionId = documentVersionId;
      if (jobId !== null) command.jobId = jobId;
      return command;
    },
  },
  {
    kind: 'communication.delivery.update',
    title: 'Update communication delivery',
    section: 'documents',
    summary: 'Records the accept, deliver, bounce or cancel outcome of a queued communication job.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'jobId', label: 'Communication job', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberJobs(fx.ctx, member.id);
      } },
      { input: 'select', key: 'expectedState', label: 'Expected state', options: () => [
        { value: 'queued', label: 'Queued' },
        { value: 'accepted', label: 'Accepted' },
      ] },
      { input: 'select', key: 'action', label: 'Action', options: () => [
        { value: 'accept', label: 'Accept' },
        { value: 'deliver', label: 'Deliver' },
        { value: 'bounce', label: 'Bounce' },
        { value: 'cancel', label: 'Cancel' },
      ] },
      { input: 'text', key: 'detail', label: 'Detail', max: 300 },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const jobId = member === undefined ? undefined : fx.pick('jobId', 'Communication job', pickers.memberJobs(fx.ctx, member.id));
      const expectedState = fx.pick('expectedState', 'Expected state', [
        { value: 'queued', label: 'Queued' },
        { value: 'accepted', label: 'Accepted' },
      ]);
      const action = fx.pick('action', 'Action', [
        { value: 'accept', label: 'Accept' },
        { value: 'deliver', label: 'Deliver' },
        { value: 'bounce', label: 'Bounce' },
        { value: 'cancel', label: 'Cancel' },
      ]);
      const detail = fx.text('detail', 'Detail', { max: 300 });
      if ([jobId, expectedState, action, detail].some((v) => v === undefined)) return undefined;
      return { jobId, expectedState, action, detail };
    },
  },
  {
    kind: 'edit.cancel',
    title: 'Cancel draft edit',
    section: 'requests',
    summary: 'Releases a draft editing session without applying changes.',
    subjects: [SUBJECT.request],
    fields: [],
    build(fx) {
      const request = fx.subject('request', 'request', 'Request');
      if (request === undefined) return undefined;
      return { requestId: request.id, expectedUpdatedAt: cell(request.record?.updated_at ?? '') };
    },
  },
  {
    kind: 'maintenance.request.submit',
    title: 'Submit request',
    section: 'requests',
    summary: 'Submits a draft maintenance request for review.',
    subjects: [SUBJECT.request],
    fields: [],
    build(fx) {
      const request = fx.subject('request', 'request', 'Request');
      if (request === undefined) return undefined;
      return { requestId: request.id, expectedUpdatedAt: cell(request.record?.updated_at ?? ''), declaredState: 'submitted' };
    },
  },
  {
    kind: 'maintenance.request.withdraw',
    title: 'Withdraw request',
    section: 'requests',
    summary: 'Withdraws a submitted or draft request with a reason.',
    subjects: [SUBJECT.request],
    fields: [{ input: 'text', key: 'reason', label: 'Reason', max: 300 }],
    build(fx) {
      const request = fx.subject('request', 'request', 'Request');
      const reason = fx.text('reason', 'Reason', { max: 300 });
      if ([request, reason].some((v) => v === undefined)) return undefined;
      return { requestId: request?.id, expectedUpdatedAt: cell(request?.record?.updated_at), reason };
    },
  },
  {
    kind: 'maintenance.request.review',
    title: 'Review request',
    section: 'requests',
    summary: 'Approves, rejects or returns a submitted request for information.',
    subjects: [SUBJECT.request],
    fields: [
      { input: 'select', key: 'decision', label: 'Decision', options: () => [
        { value: 'approve', label: 'Approve' },
        { value: 'reject', label: 'Reject' },
        { value: 'return-for-information', label: 'Return for information' },
      ] },
      { input: 'text', key: 'reason', label: 'Reason', max: 300 },
      { input: 'lines', key: 'missingFields', label: 'Missing fields', required: false, help: 'For return-for-information: one field name per line.' },
    ],
    build(fx) {
      const request = fx.subject('request', 'request', 'Request');
      const decision = fx.pick('decision', 'Decision', [
        { value: 'approve', label: 'Approve' },
        { value: 'reject', label: 'Reject' },
        { value: 'return-for-information', label: 'Return for information' },
      ]);
      const reason = fx.text('reason', 'Reason', { max: 300 });
      const missingFields = fx.lines('missingFields', 'Missing fields', false);
      if ([request, decision, reason, missingFields].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { requestId: request?.id, expectedUpdatedAt: cell(request?.record?.updated_at), decision, reason };
      if ((missingFields ?? []).length > 0) command.missingFields = missingFields;
      return command;
    },
  },
  {
    kind: 'maintenance.request.process',
    title: 'Process request',
    section: 'requests',
    summary: 'Applies or rejects an approved request; apply binds the committed change receipt.',
    subjects: [SUBJECT.request],
    fields: [
      { input: 'select', key: 'disposition', label: 'Disposition', options: () => [
        { value: 'apply', label: 'Apply' },
        { value: 'reject', label: 'Reject' },
      ], autoPostBack: true },
      { input: 'text', key: 'reason', label: 'Reason', max: 300 },
      { input: 'text', key: 'appliedReceiptId', label: 'Applied receipt id', required: false, max: 80, help: 'Required for apply — the receipt id of the committed change.' },
    ],
    build(fx) {
      const request = fx.subject('request', 'request', 'Request');
      const disposition = fx.pick('disposition', 'Disposition', [
        { value: 'apply', label: 'Apply' },
        { value: 'reject', label: 'Reject' },
      ]);
      const reason = fx.text('reason', 'Reason', { max: 300 });
      const appliedReceiptId = fx.opt('appliedReceiptId', 'Applied receipt id', { max: 80 });
      if ([request, disposition, reason, appliedReceiptId].some((v) => v === undefined)) return undefined;
      if (disposition === 'apply' && appliedReceiptId === null) {
        fx.fail('appliedReceiptId', 'Applying a request requires the committed change’s receipt id.');
        return undefined;
      }
      const command: Record<string, unknown> = { requestId: request?.id, expectedUpdatedAt: cell(request?.record?.updated_at), disposition, reason };
      if (appliedReceiptId !== null) command.appliedReceiptId = appliedReceiptId;
      return command;
    },
  },
];
