import type { OperationSpec } from './fields.js';
import { coreSpecs } from './specs-core.js';
import { financeSpecs } from './specs-finance.js';
import { servicingSpecs } from './specs-servicing.js';

export const OPERATION_SECTIONS = [
  { id: 'members', label: 'Members and identity' },
  { id: 'accounts', label: 'Accounts' },
  { id: 'money', label: 'Money movement and journals' },
  { id: 'payments', label: 'Payments and beneficiaries' },
  { id: 'cards', label: 'Cards and disputes' },
  { id: 'loans', label: 'Loans' },
  { id: 'cases', label: 'Servicing cases' },
  { id: 'documents', label: 'Documents and communications' },
  { id: 'batches', label: 'Batches and reconciliation' },
  { id: 'requests', label: 'Maintenance requests' },
  { id: 'searches', label: 'Saved searches' },
] as const;

/** Every Operation.aspx form. Draft save/amend live on RequestEdit.aspx; approval.decide on Approvals.aspx. */
export const OPERATIONS: readonly OperationSpec[] = [...coreSpecs, ...servicingSpecs, ...financeSpecs];

export function operationSpec(kind: string): OperationSpec | undefined {
  return OPERATIONS.find((spec) => spec.kind === kind);
}
