import { queryMemberMergePlan } from '@computer-use/financial-database/services';

import type { Fx, OperationSpec } from './fields.js';
import { accountCurrency, accountVersion, memberVersion, SUBJECT } from './specs-core.js';
import { cell, pickers, rows } from './subjects.js';

const fp = (fx: Fx, key: string, kind: Parameters<Fx['subject']>[1], label: string): string | undefined => {
  const subject = fx.subject(key, kind, label);
  if (subject?.fingerprint === undefined) {
    if (subject !== undefined) fx.fail(key, `${label} has no current fingerprint to bind.`);
    return undefined;
  }
  return subject.fingerprint;
};

const subjectId = (fx: Fx, key: string, kind: Parameters<Fx['subject']>[1], label: string): string | undefined => fx.subject(key, kind, label)?.id;

const accountMoney = (fx: Fx, key = 'amount', label = 'Amount', accountKey = 'account', signed = false) => {
  const currency = accountCurrency(fx, accountKey);
  return currency === undefined ? undefined : fx.money(key, label, currency, signed);
};

const memberDocs = (fx: Fx, memberKey = 'member') => {
  const member = fx.subject(memberKey, 'member', 'Member');
  return member === undefined ? [] : pickers.memberDocumentVersions(fx.ctx, member.id);
};

export const financeSpecs: OperationSpec[] = [
  {
    kind: 'member.merge',
    title: 'Merge members',
    section: 'members',
    summary: 'Executes a seeded merge plan, binding both member versions and the full inventory fingerprint.',
    subjects: [{ key: 'plan', kind: 'merge-plan', label: 'Merge plan' }],
    approval: true,
    fields: [
      { input: 'lines', key: 'relationshipAccountIds', label: 'Relationship account ids', help: 'Every account the two members share; one id per line.' },
    ],
    build(fx) {
      const plan = fx.subject('plan', 'merge-plan', 'Merge plan');
      if (plan === undefined) return undefined;
      const inventory = queryMemberMergePlan(fx.ctx.services.store, fx.ctx.context(), plan.id);
      if (inventory.kind === 'rejected') {
        fx.fail('plan', inventory.message);
        return undefined;
      }
      const relationshipAccountIds = fx.lines('relationshipAccountIds', 'Relationship account ids');
      if (relationshipAccountIds === undefined) return undefined;
      const sourceVersion = Number(row_version(fx, inventory.sourceMemberId));
      const targetVersion = Number(row_version(fx, inventory.targetMemberId));
      if (!Number.isSafeInteger(sourceVersion) || !Number.isSafeInteger(targetVersion)) {
        fx.fail('plan', 'The merge members have no editable versions.');
        return undefined;
      }
      return {
        mergePlanId: plan.id,
        sourceMemberId: inventory.sourceMemberId,
        targetMemberId: inventory.targetMemberId,
        expectedSourceVersion: sourceVersion,
        expectedTargetVersion: targetVersion,
        relationshipAccountIds,
        expectedInventoryFingerprint: inventory.fingerprint,
      };
    },
  },
  {
    kind: 'member.deceased.record',
    title: 'Record member deceased',
    section: 'members',
    summary: 'Marks the member deceased on evidence, under approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'select', key: 'evidenceId', label: 'Death evidence', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberEvidence(fx.ctx, member.id);
      } },
      { input: 'date', key: 'effectiveDate', label: 'Effective date' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const expectedVersion = memberVersion(fx);
      const evidenceId = member === undefined ? undefined : fx.pick('evidenceId', 'Death evidence', pickers.memberEvidence(fx.ctx, member.id));
      const effectiveDate = fx.date('effectiveDate', 'Effective date');
      if ([member, expectedVersion, evidenceId, effectiveDate].some((v) => v === undefined)) return undefined;
      return { memberId: member?.id, expectedVersion, evidenceId, effectiveDate };
    },
  },
  {
    kind: 'member.beneficial_owners.update',
    title: 'Update beneficial owners',
    section: 'members',
    summary: 'Replaces an organization member’s beneficial-owner register under approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'date', key: 'effectiveDate', label: 'Effective date' },
      { input: 'textarea', key: 'owners', label: 'Owners', help: 'One per line: memberId|ownershipBps|controlPerson(yes/no)|evidenceId', max: 8000 },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Organization member');
      const expectedVersion = memberVersion(fx);
      const effectiveDate = fx.date('effectiveDate', 'Effective date');
      const lines = fx.lines('owners', 'Owners');
      const owners = lines?.map((line) => {
        const parts = line.split('|').map((part) => part.trim());
        if (parts.length !== 4 || !/^\d+$/u.test(parts[1] ?? '') || !['yes', 'no'].includes(parts[2] ?? '')) {
          fx.fail('owners', `Owner "${line.slice(0, 50)}" must be memberId|ownershipBps|yes/no|evidenceId.`);
          return undefined;
        }
        return { memberId: parts[0] ?? '', ownershipBps: Number(parts[1]), isControlPerson: parts[2] === 'yes', evidenceId: parts[3] ?? '' };
      });
      if (owners?.some((owner) => owner === undefined)) return undefined;
      if ([member, expectedVersion, effectiveDate, owners].some((v) => v === undefined)) return undefined;
      return { organizationMemberId: member?.id, expectedVersion, owners, effectiveDate };
    },
  },
  {
    kind: 'member.tax_classification.update',
    title: 'Update tax classification',
    section: 'members',
    summary: 'Changes the member’s tax classification for a year on evidence, under approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'text', key: 'classification', label: 'Classification', max: 60, placeholder: 'us-person, non-us-person, us-organization' },
      { input: 'number', key: 'effectiveYear', label: 'Effective year', min: 1900, max: 2200 },
      { input: 'select', key: 'evidenceId', label: 'Tax evidence', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberEvidence(fx.ctx, member.id);
      } },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const expectedVersion = memberVersion(fx);
      const classification = fx.text('classification', 'Classification', { max: 60 });
      const effectiveYear = fx.int('effectiveYear', 'Effective year', { min: 1900, max: 2200 });
      const evidenceId = member === undefined ? undefined : fx.pick('evidenceId', 'Tax evidence', pickers.memberEvidence(fx.ctx, member.id));
      if ([member, expectedVersion, classification, effectiveYear, evidenceId].some((v) => v === undefined)) return undefined;
      return { memberId: member?.id, expectedVersion, classification, effectiveYear, evidenceId };
    },
  },
  {
    kind: 'account.product.convert',
    title: 'Convert account product',
    section: 'accounts',
    summary: 'Converts the account to another product on a date with fee disclosure, under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'targetProductId', label: 'Target product', options: (fx) => pickers.products(fx.ctx) },
      { input: 'date', key: 'effectiveDate', label: 'Effective date' },
      { input: 'bool', key: 'feeDisclosureAccepted', label: 'Fee disclosure accepted' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const targetProductId = fx.pick('targetProductId', 'Target product', pickers.products(fx.ctx));
      const effectiveDate = fx.date('effectiveDate', 'Effective date');
      const feeDisclosureAccepted = fx.bool('feeDisclosureAccepted');
      if ([account, expectedVersion, targetProductId, effectiveDate].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, targetProductId, effectiveDate, feeDisclosureAccepted };
    },
  },
  {
    kind: 'account.owner.add',
    title: 'Add account owner',
    section: 'accounts',
    summary: 'Adds an owner or joint-owner to the account on identity evidence and consent, under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'subject', key: 'memberRef', kind: 'member', label: 'Member to add' },
      { input: 'select', key: 'role', label: 'Role', options: () => [
        { value: 'owner', label: 'Owner' },
        { value: 'joint-owner', label: 'Joint owner' },
      ] },
      { input: 'date', key: 'effectiveDate', label: 'Effective date' },
      { input: 'select', key: 'identityEvidenceId', label: 'Identity evidence', options: (fx) => {
        const member = fx.subject('memberRef', 'member', 'Member to add');
        return member === undefined ? [] : pickers.memberEvidence(fx.ctx, member.id);
      } },
      { input: 'select', key: 'consentId', label: 'Consent', options: (fx) => {
        const member = fx.subject('memberRef', 'member', 'Member to add');
        return member === undefined ? [] : pickers.memberConsents(fx.ctx, member.id);
      } },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const member = fx.subject('memberRef', 'member', 'Member to add');
      const role = fx.pick('role', 'Role', [
        { value: 'owner', label: 'Owner' },
        { value: 'joint-owner', label: 'Joint owner' },
      ]);
      const effectiveDate = fx.date('effectiveDate', 'Effective date');
      const identityEvidenceId = member === undefined ? undefined : fx.pick('identityEvidenceId', 'Identity evidence', pickers.memberEvidence(fx.ctx, member.id));
      const consentId = member === undefined ? undefined : fx.pick('consentId', 'Consent', pickers.memberConsents(fx.ctx, member.id));
      if ([account, expectedVersion, member, role, effectiveDate, identityEvidenceId, consentId].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, memberId: member?.id, role, effectiveDate, identityEvidenceId, consentId };
    },
  },
  {
    kind: 'account.signer.remove',
    title: 'Remove account signer',
    section: 'accounts',
    summary: 'Removes a signer’s authority at an instant, under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'signerMemberId', label: 'Signer', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        if (account === undefined) return [];
        return rows(fx.ctx, `SELECT m.id,m.member_number,p.display_name FROM account_parties ap JOIN parties p ON p.dataset_id=ap.dataset_id AND p.id=ap.party_id JOIN members m ON m.dataset_id=ap.dataset_id AND m.party_id=ap.party_id WHERE ap.dataset_id=? AND ap.account_id=? AND ap.role IN ('signer','guardian') AND (ap.ends_at IS NULL)`, fx.ctx.binding.datasetId, account.id)
          .map((r) => ({ value: String(r.id), label: `${String(r.member_number)} ${String(r.display_name)}` }));
      } },
      { input: 'instant', key: 'effectiveAt', label: 'Effective at' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const signerMemberId = fx.text('signerMemberId', 'Signer', { max: 80 });
      const effectiveAt = fx.instant('effectiveAt', 'Effective at');
      if ([account, expectedVersion, signerMemberId, effectiveAt].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, signerMemberId, effectiveAt };
    },
  },
  {
    kind: 'account.overdraft_limit.update',
    title: 'Update overdraft limit',
    section: 'accounts',
    summary: 'Sets the account’s overdraft facility limit and expiry under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'money', key: 'limit', label: 'Limit', currency: (fx) => accountCurrency(fx) },
      { input: 'date', key: 'effectiveDate', label: 'Effective date' },
      { input: 'instant', key: 'expiresAt', label: 'Expires at', required: false },
      { input: 'select', key: 'facility', label: 'Facility', required: false, blank: '(create new)', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountFacilities(fx.ctx, account.id);
      } },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const limit = accountMoney(fx, 'limit', 'Limit');
      const effectiveDate = fx.date('effectiveDate', 'Effective date');
      const expiresAt = fx.optInstant('expiresAt', 'Expires at');
      const facilityId = account === undefined ? undefined : fx.pick('facility', 'Facility', pickers.accountFacilities(fx.ctx, account.id), false);
      const expectedFacilityFingerprint = facilityId === undefined ? null : fp(fx, 'facility', 'facility', 'Facility') ?? null;
      if (facilityId !== undefined && expectedFacilityFingerprint === null) return undefined;
      if ([account, expectedVersion, limit, effectiveDate, expiresAt].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, expectedFacilityFingerprint, limit, effectiveDate, expiresAt };
    },
  },
  {
    kind: 'account.hold.place',
    title: 'Place account hold',
    section: 'accounts',
    summary: 'Reserves funds on the account with an expiry and release authority.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
      { input: 'instant', key: 'expiresAt', label: 'Expires at' },
      { input: 'text', key: 'releaseAuthority', label: 'Release authority', max: 120, placeholder: 'operations-manager' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const amount = accountMoney(fx);
      const reason = fx.text('reason', 'Reason', { max: 200 });
      const expiresAt = fx.instant('expiresAt', 'Expires at');
      const releaseAuthority = fx.text('releaseAuthority', 'Release authority', { max: 120 });
      if ([account, expectedVersion, amount, reason, expiresAt, releaseAuthority].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, amount, reason, expiresAt, releaseAuthority };
    },
  },
  {
    kind: 'account.hold.release',
    title: 'Release account hold',
    section: 'accounts',
    summary: 'Releases part or all of an active hold on evidence, bound to the hold fingerprint.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'holdId', label: 'Hold', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountHolds(fx.ctx, account.id);
      } },
      { input: 'number', key: 'amountMinorUnits', label: 'Release amount (minor units)', min: 1, help: 'Exact minor units of the account currency.' },
      { input: 'text', key: 'releaseAuthority', label: 'Release authority', max: 120 },
      { input: 'text', key: 'evidenceReference', label: 'Evidence reference', max: 200 },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const holdId = account === undefined ? undefined : fx.pick('holdId', 'Hold', pickers.accountHolds(fx.ctx, account.id));
      const expectedFingerprint = holdId === undefined ? undefined : fp(fx, 'holdId', 'hold', 'Hold');
      const amountMinorUnits = fx.int('amountMinorUnits', 'Release amount', { min: 1 });
      const releaseAuthority = fx.text('releaseAuthority', 'Release authority', { max: 120 });
      const evidenceReference = fx.text('evidenceReference', 'Evidence reference', { max: 200 });
      if ([holdId, expectedFingerprint, amountMinorUnits, releaseAuthority, evidenceReference].some((v) => v === undefined)) return undefined;
      return { holdId, expectedFingerprint, amountMinorUnits, releaseAuthority, evidenceReference };
    },
  },
  {
    kind: 'account.restriction.apply',
    title: 'Apply account restriction',
    section: 'accounts',
    summary: 'Blocks debits, credits, closure or flags review on the account, tied to a case, under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'restrictionType', label: 'Restriction', options: () => [
        { value: 'debit-block', label: 'Debit block' },
        { value: 'credit-block', label: 'Credit block' },
        { value: 'closure-block', label: 'Closure block' },
        { value: 'fraud-review', label: 'Fraud review' },
        { value: 'legal-hold', label: 'Legal hold' },
      ] },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
      { input: 'text', key: 'authority', label: 'Authority', max: 120 },
      { input: 'subject', key: 'caseRef', kind: 'case', label: 'Case' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const restrictionType = fx.pick('restrictionType', 'Restriction', [
        { value: 'debit-block', label: 'Debit block' },
        { value: 'credit-block', label: 'Credit block' },
        { value: 'closure-block', label: 'Closure block' },
        { value: 'fraud-review', label: 'Fraud review' },
        { value: 'legal-hold', label: 'Legal hold' },
      ]);
      const reason = fx.text('reason', 'Reason', { max: 200 });
      const authority = fx.text('authority', 'Authority', { max: 120 });
      const caseRef = subjectId(fx, 'caseRef', 'case', 'Case');
      if ([account, expectedVersion, restrictionType, reason, authority, caseRef].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, restrictionType, reason, authority, caseId: caseRef };
    },
  },
  {
    kind: 'account.restriction.release',
    title: 'Release account restriction',
    section: 'accounts',
    summary: 'Releases an active restriction on clearance evidence under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'restrictionId', label: 'Restriction', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountRestrictions(fx.ctx, account.id);
      } },
      { input: 'select', key: 'clearanceEvidenceId', label: 'Clearance evidence', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberEvidence(fx.ctx, memberId) : [];
      } },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const restrictionId = account === undefined ? undefined : fx.pick('restrictionId', 'Restriction', pickers.accountRestrictions(fx.ctx, account.id));
      const expectedFingerprint = restrictionId === undefined ? undefined : fp(fx, 'restrictionId', 'restriction', 'Restriction');
      const memberId = account?.record?.member_id;
      const clearanceEvidenceId = typeof memberId === 'string' ? fx.pick('clearanceEvidenceId', 'Clearance evidence', pickers.memberEvidence(fx.ctx, memberId)) : undefined;
      if ([restrictionId, expectedFingerprint, clearanceEvidenceId].some((v) => v === undefined)) return undefined;
      return { restrictionId, expectedFingerprint, clearanceEvidenceId };
    },
  },
  {
    kind: 'fee.assess',
    title: 'Assess fee',
    section: 'money',
    summary: 'Assesses a fee against the account under the effective fee policy.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'text', key: 'feeCode', label: 'Fee code', max: 60, placeholder: 'monthly-maintenance' },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'basis', label: 'Basis', max: 200 },
      { input: 'select', key: 'policyVersionId', label: 'Fee policy', options: (fx) => pickers.policies(fx.ctx) },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const feeCode = fx.text('feeCode', 'Fee code', { max: 60 });
      const amount = accountMoney(fx);
      const basis = fx.text('basis', 'Basis', { max: 200 });
      const policyVersionId = fx.pick('policyVersionId', 'Fee policy', pickers.policies(fx.ctx));
      if ([account, expectedVersion, feeCode, amount, basis, policyVersionId].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, feeCode, amount, basis, policyVersionId };
    },
  },
  {
    kind: 'fee.waiver.create',
    title: 'Create fee waiver',
    section: 'money',
    summary: 'Creates a dated fee waiver with an amount limit and occurrence cap, under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'text', key: 'feeCode', label: 'Fee code', max: 60 },
      { input: 'date', key: 'validFrom', label: 'Valid from' },
      { input: 'date', key: 'validThrough', label: 'Valid through' },
      { input: 'money', key: 'amountLimit', label: 'Amount limit', currency: (fx) => accountCurrency(fx) },
      { input: 'number', key: 'maxOccurrences', label: 'Max occurrences', min: 1, max: 1000 },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const feeCode = fx.text('feeCode', 'Fee code', { max: 60 });
      const validFrom = fx.date('validFrom', 'Valid from');
      const validThrough = fx.date('validThrough', 'Valid through');
      const amountLimit = accountMoney(fx, 'amountLimit', 'Amount limit');
      const maxOccurrences = fx.int('maxOccurrences', 'Max occurrences', { min: 1, max: 1000 });
      const reason = fx.text('reason', 'Reason', { max: 200 });
      if ([account, feeCode, validFrom, validThrough, amountLimit, maxOccurrences, reason].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, feeCode, validFrom, validThrough, amountLimit, maxOccurrences, reason };
    },
  },
  {
    kind: 'fee.refund',
    title: 'Refund fee',
    section: 'money',
    summary: 'Refunds part or all of an assessed fee, bound to the fee fingerprint.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'feeId', label: 'Fee', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountFees(fx.ctx, account.id);
      } },
      { input: 'money', key: 'amount', label: 'Refund amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const feeId = account === undefined ? undefined : fx.pick('feeId', 'Fee', pickers.accountFees(fx.ctx, account.id));
      const expectedFingerprint = feeId === undefined ? undefined : fp(fx, 'feeId', 'fee', 'Fee');
      const amount = accountMoney(fx);
      const reason = fx.text('reason', 'Reason', { max: 200 });
      if ([feeId, expectedFingerprint, amount, reason].some((v) => v === undefined)) return undefined;
      return { feeId, expectedFingerprint, amount, reason };
    },
  },
  {
    kind: 'cash.deposit.reverse',
    title: 'Reverse cash deposit',
    section: 'money',
    summary: 'Reverses a posted deposit journal on correction evidence under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'journalId', label: 'Deposit journal', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountJournals(fx.ctx, account.id);
      } },
      { input: 'select', key: 'correctionEvidenceId', label: 'Correction evidence', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberEvidence(fx.ctx, memberId) : [];
      } },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const journalId = account === undefined ? undefined : fx.pick('journalId', 'Deposit journal', pickers.accountJournals(fx.ctx, account.id));
      const expectedFingerprint = journalId === undefined ? undefined : fp(fx, 'journalId', 'journal', 'Deposit journal');
      const memberId = account?.record?.member_id;
      const correctionEvidenceId = typeof memberId === 'string' ? fx.pick('correctionEvidenceId', 'Correction evidence', pickers.memberEvidence(fx.ctx, memberId)) : undefined;
      if ([journalId, expectedFingerprint, correctionEvidenceId].some((v) => v === undefined)) return undefined;
      return { journalId, expectedFingerprint, correctionEvidenceId };
    },
  },
  {
    kind: 'cash.withdrawal.reverse',
    title: 'Reverse cash withdrawal',
    section: 'money',
    summary: 'Reverses a posted withdrawal journal under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'journalId', label: 'Withdrawal journal', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountJournals(fx.ctx, account.id);
      } },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const journalId = account === undefined ? undefined : fx.pick('journalId', 'Withdrawal journal', pickers.accountJournals(fx.ctx, account.id));
      const expectedFingerprint = journalId === undefined ? undefined : fp(fx, 'journalId', 'journal', 'Withdrawal journal');
      const reason = fx.text('reason', 'Reason', { max: 200 });
      if ([journalId, expectedFingerprint, reason].some((v) => v === undefined)) return undefined;
      return { journalId, expectedFingerprint, reason };
    },
  },
  {
    kind: 'transfer.internal.reverse',
    title: 'Reverse internal transfer',
    section: 'money',
    summary: 'Reverses a posted internal transfer pair under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'transferJournalId', label: 'Transfer journal', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountJournals(fx.ctx, account.id);
      } },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const transferJournalId = account === undefined ? undefined : fx.pick('transferJournalId', 'Transfer journal', pickers.accountJournals(fx.ctx, account.id));
      const expectedFingerprint = transferJournalId === undefined ? undefined : fp(fx, 'transferJournalId', 'transfer', 'Transfer');
      const amount = accountMoney(fx);
      const reason = fx.text('reason', 'Reason', { max: 200 });
      if ([transferJournalId, expectedFingerprint, amount, reason].some((v) => v === undefined)) return undefined;
      return { transferJournalId, expectedFingerprint, amount, reason };
    },
  },
  {
    kind: 'interest.adjust',
    title: 'Adjust interest',
    section: 'money',
    summary: 'Applies an approved delta to an interest calculation, bound to its fingerprint.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'calculationId', label: 'Interest calculation', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.interestCalculations(fx.ctx, account.id);
      } },
      { input: 'money', key: 'approvedDelta', label: 'Approved delta', currency: (fx) => accountCurrency(fx), signed: true, help: 'May be negative.' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const calculationId = account === undefined ? undefined : fx.pick('calculationId', 'Interest calculation', pickers.interestCalculations(fx.ctx, account.id));
      const expectedFingerprint = calculationId === undefined ? undefined : fp(fx, 'calculationId', 'interest-calculation', 'Interest calculation');
      const approvedDelta = accountMoney(fx, 'approvedDelta', 'Approved delta', 'account', true);
      if ([account, calculationId, expectedFingerprint, approvedDelta].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, calculationId, expectedFingerprint, approvedDelta };
    },
  },
  {
    kind: 'transaction.effective_date.correct',
    title: 'Correct transaction date',
    section: 'money',
    summary: 'Corrects a journal’s effective date under policy under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'journalId', label: 'Journal', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountJournals(fx.ctx, account.id);
      } },
      { input: 'date', key: 'correctedDate', label: 'Corrected date' },
      { input: 'select', key: 'policyVersionId', label: 'Policy', options: (fx) => pickers.policies(fx.ctx) },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const journalId = account === undefined ? undefined : fx.pick('journalId', 'Journal', pickers.accountJournals(fx.ctx, account.id));
      const expectedFingerprint = journalId === undefined ? undefined : fp(fx, 'journalId', 'journal', 'Journal');
      const correctedDate = fx.date('correctedDate', 'Corrected date');
      const policyVersionId = fx.pick('policyVersionId', 'Policy', pickers.policies(fx.ctx));
      const reason = fx.text('reason', 'Reason', { max: 200 });
      if ([journalId, expectedFingerprint, correctedDate, policyVersionId, reason].some((v) => v === undefined)) return undefined;
      return { journalId, expectedFingerprint, correctedDate, policyVersionId, reason };
    },
  },
  {
    kind: 'transaction.description.update',
    title: 'Update transaction description',
    section: 'money',
    summary: 'Amends the displayed description of a posted journal.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'journalId', label: 'Journal', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountJournals(fx.ctx, account.id);
      } },
      { input: 'text', key: 'description', label: 'New description', max: 200 },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const journalId = account === undefined ? undefined : fx.pick('journalId', 'Journal', pickers.accountJournals(fx.ctx, account.id));
      const expectedFingerprint = journalId === undefined ? undefined : fp(fx, 'journalId', 'journal', 'Journal');
      const description = fx.text('description', 'New description', { max: 200 });
      if ([journalId, expectedFingerprint, description].some((v) => v === undefined)) return undefined;
      return { journalId, expectedFingerprint, description };
    },
  },
  {
    kind: 'beneficiary.create',
    title: 'Create beneficiary',
    section: 'payments',
    summary: 'Registers a payment beneficiary for the member with its first routing record.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'text', key: 'displayName', label: 'Display name', max: 120 },
      { input: 'text', key: 'routingKind', label: 'Routing kind', max: 40, placeholder: 'ach, wire, internal' },
      { input: 'text', key: 'maskedDestination', label: 'Masked destination', max: 80, placeholder: '****6789' },
      { input: 'text', key: 'simulatedToken', label: 'Simulated token', max: 80 },
      { input: 'lines', key: 'allowedRails', label: 'Allowed rails', help: 'One rail per line, for example ach, same-day.' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const expectedMemberVersion = memberVersion(fx);
      const displayName = fx.text('displayName', 'Display name', { max: 120 });
      const routingKind = fx.text('routingKind', 'Routing kind', { max: 40 });
      const maskedDestination = fx.text('maskedDestination', 'Masked destination', { max: 80 });
      const simulatedToken = fx.text('simulatedToken', 'Simulated token', { max: 80 });
      const allowedRails = fx.lines('allowedRails', 'Allowed rails');
      if ([member, expectedMemberVersion, displayName, routingKind, maskedDestination, simulatedToken, allowedRails].some((v) => v === undefined)) return undefined;
      return { memberId: member?.id, expectedMemberVersion, displayName, routingKind, maskedDestination, simulatedToken, allowedRails };
    },
  },
  {
    kind: 'beneficiary.verify',
    title: 'Verify beneficiary',
    section: 'payments',
    summary: 'Verifies a beneficiary route on evidence under approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'select', key: 'beneficiaryId', label: 'Beneficiary', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.beneficiaries(fx.ctx, member.id);
      }, autoPostBack: true },
      { input: 'select', key: 'routeId', label: 'Route', options: (fx) => {
        const beneficiary = fx.raw('beneficiaryId');
        return beneficiary === '' ? [] : pickers.beneficiaryRoutes(fx.ctx, beneficiary);
      } },
      { input: 'select', key: 'evidenceId', label: 'Verification evidence', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberEvidence(fx.ctx, member.id);
      } },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const beneficiaryId = member === undefined ? undefined : fx.pick('beneficiaryId', 'Beneficiary', pickers.beneficiaries(fx.ctx, member.id));
      const routeId = beneficiaryId === undefined ? undefined : fx.pick('routeId', 'Route', pickers.beneficiaryRoutes(fx.ctx, beneficiaryId));
      const expectedFingerprint = routeId === undefined ? undefined : fp(fx, 'routeId', 'beneficiary-route', 'Route');
      const evidenceId = member === undefined ? undefined : fx.pick('evidenceId', 'Verification evidence', pickers.memberEvidence(fx.ctx, member.id));
      if ([beneficiaryId, routeId, expectedFingerprint, evidenceId].some((v) => v === undefined)) return undefined;
      return { beneficiaryId, routeId, expectedFingerprint, evidenceId };
    },
  },
  {
    kind: 'beneficiary.routing.update',
    title: 'Update beneficiary routing',
    section: 'payments',
    summary: 'Supersedes a beneficiary’s routing record under approval.',
    subjects: [SUBJECT.member],
    approval: true,
    fields: [
      { input: 'select', key: 'beneficiaryId', label: 'Beneficiary', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.beneficiaries(fx.ctx, member.id);
      }, autoPostBack: true },
      { input: 'select', key: 'currentRouteId', label: 'Route being superseded', options: (fx) => {
        const beneficiaryId = fx.raw('beneficiaryId');
        return beneficiaryId === '' ? [] : pickers.beneficiaryRoutes(fx.ctx, beneficiaryId);
      } },
      { input: 'text', key: 'routingKind', label: 'Routing kind', max: 40 },
      { input: 'text', key: 'maskedDestination', label: 'Masked destination', max: 80 },
      { input: 'text', key: 'simulatedToken', label: 'Simulated token', max: 80 },
      { input: 'date', key: 'effectiveDate', label: 'Effective date' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const beneficiaryId = member === undefined ? undefined : fx.pick('beneficiaryId', 'Beneficiary', pickers.beneficiaries(fx.ctx, member.id));
      const currentRouteId = beneficiaryId === undefined ? undefined : fx.pick('currentRouteId', 'Route being superseded', pickers.beneficiaryRoutes(fx.ctx, beneficiaryId));
      const expectedRouteFingerprint = currentRouteId === undefined ? undefined : fp(fx, 'currentRouteId', 'beneficiary-route', 'Route being superseded');
      const routingKind = fx.text('routingKind', 'Routing kind', { max: 40 });
      const maskedDestination = fx.text('maskedDestination', 'Masked destination', { max: 80 });
      const simulatedToken = fx.text('simulatedToken', 'Simulated token', { max: 80 });
      const effectiveDate = fx.date('effectiveDate', 'Effective date');
      if ([beneficiaryId, expectedRouteFingerprint, routingKind, maskedDestination, simulatedToken, effectiveDate].some((v) => v === undefined)) return undefined;
      return { beneficiaryId, expectedRouteFingerprint, routingKind, maskedDestination, simulatedToken, effectiveDate };
    },
  },
  {
    kind: 'beneficiary.retire',
    title: 'Retire beneficiary',
    section: 'payments',
    summary: 'Retires a beneficiary, rejecting or cancelling dependent drafts.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'beneficiaryId', label: 'Beneficiary', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.beneficiaries(fx.ctx, member.id);
      } },
      { input: 'select', key: 'dependentDisposition', label: 'Dependents', options: () => [
        { value: 'reject-if-active', label: 'Reject if active dependents exist' },
        { value: 'cancel-drafts', label: 'Cancel dependent drafts' },
      ] },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const beneficiaryId = member === undefined ? undefined : fx.pick('beneficiaryId', 'Beneficiary', pickers.beneficiaries(fx.ctx, member.id));
      const expectedFingerprint = beneficiaryId === undefined ? undefined : fp(fx, 'beneficiaryId', 'beneficiary', 'Beneficiary');
      const dependentDisposition = fx.pick('dependentDisposition', 'Dependents', [
        { value: 'reject-if-active', label: 'Reject if active' },
        { value: 'cancel-drafts', label: 'Cancel drafts' },
      ]);
      const reason = fx.text('reason', 'Reason', { max: 200 });
      if ([beneficiaryId, expectedFingerprint, dependentDisposition, reason].some((v) => v === undefined)) return undefined;
      return { beneficiaryId, expectedFingerprint, dependentDisposition, reason };
    },
  },
  {
    kind: 'payment.create',
    title: 'Create payment',
    section: 'payments',
    summary: 'Creates a draft or approval-pending payment to a verified beneficiary route.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'beneficiaryRouteId', label: 'Beneficiary route', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        if (typeof memberId !== 'string') return [];
        return pickers.beneficiaries(fx.ctx, memberId).flatMap((b) => pickers.beneficiaryRoutes(fx.ctx, b.value).map((r) => ({ value: r.value, label: `${b.label} → ${r.label}` })));
      } },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'rail', label: 'Rail', max: 40, placeholder: 'ach' },
      { input: 'date', key: 'requestedDate', label: 'Requested date' },
      { input: 'text', key: 'calendarVersion', label: 'Calendar version', max: 40, help: 'Shown on the account’s institution calendar; usually "1".' },
      { input: 'instant', key: 'cutoffAt', label: 'Cutoff at' },
      { input: 'text', key: 'reference', label: 'Reference', max: 80 },
      { input: 'select', key: 'targetState', label: 'Create as', options: () => [
        { value: 'draft', label: 'Draft' },
        { value: 'pending-approval', label: 'Pending approval' },
      ] },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedSourceVersion = accountVersion(fx);
      const memberId = account?.record?.member_id;
      const routes = typeof memberId === 'string' ? pickers.beneficiaries(fx.ctx, memberId).flatMap((b) => pickers.beneficiaryRoutes(fx.ctx, b.value)) : [];
      const beneficiaryRouteId = fx.pick('beneficiaryRouteId', 'Beneficiary route', routes);
      const expectedRouteFingerprint = beneficiaryRouteId === undefined ? undefined : fp(fx, 'beneficiaryRouteId', 'beneficiary-route', 'Beneficiary route');
      const amount = accountMoney(fx);
      const rail = fx.text('rail', 'Rail', { max: 40 });
      const requestedDate = fx.date('requestedDate', 'Requested date');
      const calendarVersion = fx.text('calendarVersion', 'Calendar version', { max: 40 });
      const cutoffAt = fx.instant('cutoffAt', 'Cutoff at');
      const reference = fx.text('reference', 'Reference', { max: 80 });
      const targetState = fx.pick('targetState', 'Create as', [
        { value: 'draft', label: 'Draft' },
        { value: 'pending-approval', label: 'Pending approval' },
      ]);
      if ([account, expectedSourceVersion, beneficiaryRouteId, expectedRouteFingerprint, amount, rail, requestedDate, calendarVersion, cutoffAt, reference, targetState].some((v) => v === undefined)) return undefined;
      return { sourceAccountId: account?.id, expectedSourceVersion, beneficiaryRouteId, expectedRouteFingerprint, amount, rail, requestedDate, calendarVersion, cutoffAt, reference, targetState };
    },
  },
  {
    kind: 'payment.submit',
    title: 'Submit payment',
    section: 'payments',
    summary: 'Submits a draft payment for approval.',
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    fields: [],
    build(fx) {
      const payment = fx.subject('payment', 'payment', 'Payment');
      if (payment === undefined) return undefined;
      return { paymentId: payment.id, expectedVersion: Number(payment.record?.version ?? 0) };
    },
  },
  {
    kind: 'payment.approve_release',
    title: 'Approve and release payment',
    section: 'payments',
    summary: 'Releases a pending payment for settlement under approval.',
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    approval: true,
    fields: [
      { input: 'date', key: 'requestedDate', label: 'Requested date' },
      { input: 'text', key: 'calendarVersion', label: 'Calendar version', max: 40 },
      { input: 'instant', key: 'cutoffAt', label: 'Cutoff at' },
    ],
    build(fx) {
      const payment = fx.subject('payment', 'payment', 'Payment');
      const requestedDate = fx.date('requestedDate', 'Requested date');
      const calendarVersion = fx.text('calendarVersion', 'Calendar version', { max: 40 });
      const cutoffAt = fx.instant('cutoffAt', 'Cutoff at');
      if ([payment, requestedDate, calendarVersion, cutoffAt].some((v) => v === undefined)) return undefined;
      return { paymentId: payment?.id, expectedVersion: Number(payment?.record?.version ?? 0), requestedDate, calendarVersion, cutoffAt };
    },
  },
  {
    kind: 'payment.settle',
    title: 'Settle payment',
    section: 'payments',
    summary: 'Marks a released payment settled with its settlement reference.',
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    fields: [{ input: 'text', key: 'settlementReference', label: 'Settlement reference', max: 80 }],
    build(fx) {
      const payment = fx.subject('payment', 'payment', 'Payment');
      const settlementReference = fx.text('settlementReference', 'Settlement reference', { max: 80 });
      if ([payment, settlementReference].some((v) => v === undefined)) return undefined;
      return { paymentId: payment?.id, expectedVersion: Number(payment?.record?.version ?? 0), settlementReference };
    },
  },
  {
    kind: 'payment.cancel',
    title: 'Cancel payment',
    section: 'payments',
    summary: 'Cancels a payment with a reason.',
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    fields: [{ input: 'text', key: 'reason', label: 'Reason', max: 200 }],
    build(fx) {
      const payment = fx.subject('payment', 'payment', 'Payment');
      const reason = fx.text('reason', 'Reason', { max: 200 });
      if ([payment, reason].some((v) => v === undefined)) return undefined;
      return { paymentId: payment?.id, expectedVersion: Number(payment?.record?.version ?? 0), reason };
    },
  },
  {
    kind: 'payment.schedule.create',
    title: 'Create payment schedule',
    section: 'payments',
    summary: 'Creates a recurring payment schedule to a verified route under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'beneficiaryRouteId', label: 'Beneficiary route', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        if (typeof memberId !== 'string') return [];
        return pickers.beneficiaries(fx.ctx, memberId).flatMap((b) => pickers.beneficiaryRoutes(fx.ctx, b.value).map((r) => ({ value: r.value, label: `${b.label} → ${r.label}` })));
      } },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'select', key: 'frequency', label: 'Frequency', options: () => [
        { value: 'daily', label: 'Daily' },
        { value: 'weekly', label: 'Weekly' },
        { value: 'monthly', label: 'Monthly' },
      ] },
      { input: 'number', key: 'interval', label: 'Interval', min: 1, max: 366 },
      { input: 'date', key: 'startDate', label: 'Start date' },
      { input: 'date', key: 'endDate', label: 'End date' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedSourceVersion = accountVersion(fx);
      const memberId = account?.record?.member_id;
      const routes = typeof memberId === 'string' ? pickers.beneficiaries(fx.ctx, memberId).flatMap((b) => pickers.beneficiaryRoutes(fx.ctx, b.value)) : [];
      const beneficiaryRouteId = fx.pick('beneficiaryRouteId', 'Beneficiary route', routes);
      const expectedRouteFingerprint = beneficiaryRouteId === undefined ? undefined : fp(fx, 'beneficiaryRouteId', 'beneficiary-route', 'Beneficiary route');
      const amount = accountMoney(fx);
      const frequency = fx.pick('frequency', 'Frequency', [
        { value: 'daily', label: 'Daily' },
        { value: 'weekly', label: 'Weekly' },
        { value: 'monthly', label: 'Monthly' },
      ]);
      const interval = fx.int('interval', 'Interval', { min: 1, max: 366 });
      const startDate = fx.date('startDate', 'Start date');
      const endDate = fx.date('endDate', 'End date');
      if ([account, expectedSourceVersion, beneficiaryRouteId, expectedRouteFingerprint, amount, frequency, interval, startDate, endDate].some((v) => v === undefined)) return undefined;
      return { sourceAccountId: account?.id, expectedSourceVersion, beneficiaryRouteId, expectedRouteFingerprint, amount, frequency, interval, startDate, endDate };
    },
  },
  {
    kind: 'payment.schedule.materialize',
    title: 'Materialize scheduled payment',
    section: 'payments',
    summary: 'Materializes a planned schedule occurrence into a payment.',
    subjects: [{ key: 'schedule', kind: 'payment-schedule', label: 'Schedule' }],
    fields: [
      { input: 'select', key: 'occurrenceId', label: 'Occurrence', options: (fx) => {
        const schedule = fx.subject('schedule', 'payment-schedule', 'Schedule');
        return schedule === undefined ? [] : pickers.scheduleOccurrences(fx.ctx, schedule.id);
      } },
    ],
    build(fx) {
      const schedule = fx.subject('schedule', 'payment-schedule', 'Schedule');
      const occurrenceId = schedule === undefined ? undefined : fx.pick('occurrenceId', 'Occurrence', pickers.scheduleOccurrences(fx.ctx, schedule.id));
      const expectedFingerprint = occurrenceId === undefined ? undefined : fp(fx, 'occurrenceId', 'schedule-occurrence', 'Occurrence');
      if ([occurrenceId, expectedFingerprint].some((v) => v === undefined)) return undefined;
      return { occurrenceId, expectedFingerprint };
    },
  },
  {
    kind: 'payment.occurrence.amend',
    title: 'Amend scheduled occurrence',
    section: 'payments',
    summary: 'Changes the amount or date of a planned occurrence.',
    subjects: [{ key: 'schedule', kind: 'payment-schedule', label: 'Schedule' }],
    fields: [
      { input: 'select', key: 'occurrenceId', label: 'Occurrence', options: (fx) => {
        const schedule = fx.subject('schedule', 'payment-schedule', 'Schedule');
        return schedule === undefined ? [] : pickers.scheduleOccurrences(fx.ctx, schedule.id);
      } },
      { input: 'money', key: 'newAmount', label: 'New amount', currency: (fx) => { const schedule = fx.subject('schedule', 'payment-schedule', 'Schedule'); return schedule === undefined ? undefined : cell(schedule.record?.currency ?? 'USD'); } },
      { input: 'date', key: 'newDate', label: 'New date' },
    ],
    build(fx) {
      const schedule = fx.subject('schedule', 'payment-schedule', 'Schedule');
      const occurrenceId = schedule === undefined ? undefined : fx.pick('occurrenceId', 'Occurrence', pickers.scheduleOccurrences(fx.ctx, schedule.id));
      const expectedFingerprint = occurrenceId === undefined ? undefined : fp(fx, 'occurrenceId', 'schedule-occurrence', 'Occurrence');
      const currency = cell(schedule?.record?.currency);
      const newAmount = fx.money('newAmount', 'New amount', currency);
      const newDate = fx.date('newDate', 'New date');
      if ([occurrenceId, expectedFingerprint, newAmount, newDate].some((v) => v === undefined)) return undefined;
      return { occurrenceId, expectedFingerprint, newAmount, newDate };
    },
  },
  {
    kind: 'payment.schedule.end',
    title: 'End payment schedule',
    section: 'payments',
    summary: 'Ends a schedule from a date, cancelling planned occurrences or retaining released ones, under approval.',
    subjects: [{ key: 'schedule', kind: 'payment-schedule', label: 'Schedule' }],
    approval: true,
    fields: [
      { input: 'date', key: 'endFromDate', label: 'End from date' },
      { input: 'select', key: 'pendingDisposition', label: 'Pending occurrences', options: () => [
        { value: 'cancel-planned', label: 'Cancel planned' },
        { value: 'retain-released', label: 'Retain released' },
      ] },
    ],
    build(fx) {
      const schedule = fx.subject('schedule', 'payment-schedule', 'Schedule');
      const expectedFingerprint = schedule === undefined ? undefined : fp(fx, 'schedule', 'payment-schedule', 'Schedule');
      const endFromDate = fx.date('endFromDate', 'End from date');
      const pendingDisposition = fx.pick('pendingDisposition', 'Pending occurrences', [
        { value: 'cancel-planned', label: 'Cancel planned' },
        { value: 'retain-released', label: 'Retain released' },
      ]);
      if ([schedule, expectedFingerprint, endFromDate, pendingDisposition].some((v) => v === undefined)) return undefined;
      return { scheduleId: schedule?.id, expectedFingerprint, endFromDate, pendingDisposition };
    },
  },
  {
    kind: 'payment.return.resolve',
    title: 'Resolve payment return',
    section: 'payments',
    summary: 'Credits the source account or opens an investigation for a returned payment, under approval.',
    subjects: [{ key: 'return', kind: 'payment-return', label: 'Payment return' }],
    approval: true,
    fields: [
      { input: 'select', key: 'disposition', label: 'Disposition', options: () => [
        { value: 'credit-source', label: 'Credit source account' },
        { value: 'investigate', label: 'Investigate' },
      ] },
    ],
    build(fx) {
      const ret = fx.subject('return', 'payment-return', 'Payment return');
      const disposition = fx.pick('disposition', 'Disposition', [
        { value: 'credit-source', label: 'Credit source' },
        { value: 'investigate', label: 'Investigate' },
      ]);
      if ([ret, disposition].some((v) => v === undefined)) return undefined;
      return { returnId: ret?.id, expectedFingerprint: ret?.fingerprint, paymentId: cell(ret?.record?.payment_id), disposition };
    },
  },
  {
    kind: 'card.replace',
    title: 'Replace card',
    section: 'cards',
    summary: 'Orders a replacement card to a verified delivery destination.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'cardId', label: 'Card', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountCards(fx.ctx, account.id);
      } },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
      { input: 'select', key: 'identityEvidenceId', label: 'Identity evidence', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberEvidence(fx.ctx, memberId) : [];
      } },
      { input: 'select', key: 'deliveryDestinationId', label: 'Delivery destination', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberDestinations(fx.ctx, memberId) : [];
      } },
      { input: 'select', key: 'deliveryAddressId', label: 'Delivery address', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberAddressRows(fx.ctx, memberId).map((a) => ({ value: a.addressId, label: `${a.line1}, ${a.city}` })) : [];
      } },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const cardId = account === undefined ? undefined : fx.pick('cardId', 'Card', pickers.accountCards(fx.ctx, account.id));
      const expectedFingerprint = cardId === undefined ? undefined : fp(fx, 'cardId', 'card', 'Card');
      const reason = fx.text('reason', 'Reason', { max: 200 });
      const memberId = account?.record?.member_id;
      const identityEvidenceId = typeof memberId === 'string' ? fx.pick('identityEvidenceId', 'Identity evidence', pickers.memberEvidence(fx.ctx, memberId)) : undefined;
      const deliveryDestinationId = typeof memberId === 'string' ? fx.pick('deliveryDestinationId', 'Delivery destination', pickers.memberDestinations(fx.ctx, memberId)) : undefined;
      const deliveryAddressId = typeof memberId === 'string' ? fx.pick('deliveryAddressId', 'Delivery address', pickers.memberAddressRows(fx.ctx, memberId).map((a) => ({ value: a.addressId, label: a.line1 }))) : undefined;
      if ([cardId, expectedFingerprint, reason, identityEvidenceId, deliveryDestinationId, deliveryAddressId].some((v) => v === undefined)) return undefined;
      return { cardId, expectedFingerprint, reason, identityEvidenceId, deliveryDestinationId, deliveryAddressId };
    },
  },
  {
    kind: 'card.lock.update',
    title: 'Lock or unlock card',
    section: 'cards',
    summary: 'Temporarily locks or unlocks a card with the acting authority.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'cardId', label: 'Card', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountCards(fx.ctx, account.id);
      } },
      { input: 'select', key: 'requestedState', label: 'Requested state', options: () => [
        { value: 'locked', label: 'Locked' },
        { value: 'unlocked', label: 'Unlocked' },
      ] },
      { input: 'text', key: 'authority', label: 'Authority', max: 120, placeholder: 'member-request, fraud-desk' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const cardId = account === undefined ? undefined : fx.pick('cardId', 'Card', pickers.accountCards(fx.ctx, account.id));
      const expectedFingerprint = cardId === undefined ? undefined : fp(fx, 'cardId', 'card', 'Card');
      const requestedState = fx.pick('requestedState', 'Requested state', [
        { value: 'locked', label: 'Locked' },
        { value: 'unlocked', label: 'Unlocked' },
      ]);
      const authority = fx.text('authority', 'Authority', { max: 120 });
      if ([cardId, expectedFingerprint, requestedState, authority].some((v) => v === undefined)) return undefined;
      return { cardId, expectedFingerprint, requestedState, authority };
    },
  },
  {
    kind: 'card.limit.update',
    title: 'Update card limit',
    section: 'cards',
    summary: 'Sets a card limit window under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'cardId', label: 'Card', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.accountCards(fx.ctx, account.id);
      } },
      { input: 'select', key: 'limitKind', label: 'Limit kind', options: () => [
        { value: 'daily-purchase', label: 'Daily purchase' },
        { value: 'cash', label: 'Cash' },
        { value: 'online', label: 'Online' },
      ] },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'instant', key: 'effectiveAt', label: 'Effective at' },
      { input: 'instant', key: 'expiresAt', label: 'Expires at', required: false },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const cardId = account === undefined ? undefined : fx.pick('cardId', 'Card', pickers.accountCards(fx.ctx, account.id));
      const expectedFingerprint = cardId === undefined ? undefined : fp(fx, 'cardId', 'card', 'Card');
      const limitKind = fx.pick('limitKind', 'Limit kind', [
        { value: 'daily-purchase', label: 'Daily purchase' },
        { value: 'cash', label: 'Cash' },
        { value: 'online', label: 'Online' },
      ]);
      const amount = accountMoney(fx);
      const effectiveAt = fx.instant('effectiveAt', 'Effective at');
      const expiresAt = fx.optInstant('expiresAt', 'Expires at');
      if ([cardId, expectedFingerprint, limitKind, amount, effectiveAt, expiresAt].some((v) => v === undefined)) return undefined;
      return { cardId, expectedFingerprint, limitKind, amount, effectiveAt, expiresAt };
    },
  },
  {
    kind: 'dispute.open',
    title: 'Open card dispute',
    section: 'cards',
    summary: 'Opens a dispute on a card transaction with asserted amount and evidence.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'cardTransactionId', label: 'Card transaction', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        if (account === undefined) return [];
        const cardIds = pickers.accountCards(fx.ctx, account.id).map((c) => c.value);
        return cardIds.flatMap((cardId) => pickers.cardTransactions(fx.ctx, cardId));
      } },
      { input: 'text', key: 'reason', label: 'Reason', max: 200 },
      { input: 'money', key: 'assertedAmount', label: 'Asserted amount', currency: (fx) => accountCurrency(fx) },
      { input: 'lines', key: 'evidenceIds', label: 'Evidence ids', help: 'One identity-evidence id per line.' },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const cardIds = account === undefined ? [] : pickers.accountCards(fx.ctx, account.id).map((c) => c.value);
      const cardTransactionId = fx.pick('cardTransactionId', 'Card transaction', cardIds.flatMap((id) => pickers.cardTransactions(fx.ctx, id)));
      const expectedFingerprint = cardTransactionId === undefined ? undefined : fp(fx, 'cardTransactionId', 'card-transaction', 'Card transaction');
      const reason = fx.text('reason', 'Reason', { max: 200 });
      const assertedAmount = accountMoney(fx, 'assertedAmount', 'Asserted amount');
      const evidenceIds = fx.lines('evidenceIds', 'Evidence ids');
      if ([cardTransactionId, expectedFingerprint, reason, assertedAmount, evidenceIds].some((v) => v === undefined)) return undefined;
      return { cardTransactionId, expectedFingerprint, reason, assertedAmount, evidenceIds };
    },
  },
  {
    kind: 'dispute.provisional_credit.issue',
    title: 'Issue provisional credit',
    section: 'cards',
    summary: 'Issues a provisional credit to the disputed account under approval.',
    subjects: [{ key: 'dispute', kind: 'dispute', label: 'Dispute' }],
    approval: true,
    fields: [{ input: 'money', key: 'amount', label: 'Amount', currency: (fx) => { const dispute = fx.subject('dispute', 'dispute', 'Dispute'); return dispute === undefined ? undefined : cell(dispute.record?.currency ?? 'USD'); } }],
    build(fx) {
      const dispute = fx.subject('dispute', 'dispute', 'Dispute');
      const currency = cell(dispute?.record?.currency);
      const amount = fx.money('amount', 'Amount', currency);
      if ([dispute, amount].some((v) => v === undefined)) return undefined;
      return { disputeId: dispute?.id, expectedFingerprint: dispute?.fingerprint, amount };
    },
  },
  {
    kind: 'dispute.evidence.submit',
    title: 'Submit dispute evidence',
    section: 'cards',
    summary: 'Submits document evidence for a dispute with a deadline, under approval.',
    subjects: [{ key: 'dispute', kind: 'dispute', label: 'Dispute' }],
    approval: true,
    fields: [
      { input: 'lines', key: 'documentVersionIds', label: 'Document version ids', help: 'One per line.' },
      { input: 'instant', key: 'deadline', label: 'Deadline' },
      { input: 'text', key: 'recipient', label: 'Recipient', max: 120 },
      { input: 'text', key: 'channel', label: 'Channel', max: 40 },
    ],
    build(fx) {
      const dispute = fx.subject('dispute', 'dispute', 'Dispute');
      const documentVersionIds = fx.lines('documentVersionIds', 'Document version ids');
      const deadline = fx.instant('deadline', 'Deadline');
      const recipient = fx.text('recipient', 'Recipient', { max: 120 });
      const channel = fx.text('channel', 'Channel', { max: 40 });
      if ([dispute, documentVersionIds, deadline, recipient, channel].some((v) => v === undefined)) return undefined;
      return { disputeId: dispute?.id, expectedFingerprint: dispute?.fingerprint, documentVersionIds, deadline, recipient, channel };
    },
  },
  {
    kind: 'dispute.settle',
    title: 'Settle dispute',
    section: 'cards',
    summary: 'Approves or denies the dispute with a final amount, under approval.',
    subjects: [{ key: 'dispute', kind: 'dispute', label: 'Dispute' }],
    approval: true,
    fields: [
      { input: 'select', key: 'decision', label: 'Decision', options: () => [
        { value: 'approved', label: 'Approved' },
        { value: 'denied', label: 'Denied' },
      ] },
      { input: 'money', key: 'finalAmount', label: 'Final amount', currency: (fx) => { const dispute = fx.subject('dispute', 'dispute', 'Dispute'); return dispute === undefined ? undefined : cell(dispute.record?.currency ?? 'USD'); } },
    ],
    build(fx) {
      const dispute = fx.subject('dispute', 'dispute', 'Dispute');
      const currency = cell(dispute?.record?.currency);
      const decision = fx.pick('decision', 'Decision', [
        { value: 'approved', label: 'Approved' },
        { value: 'denied', label: 'Denied' },
      ]);
      const finalAmount = fx.money('finalAmount', 'Final amount', currency);
      if ([dispute, decision, finalAmount].some((v) => v === undefined)) return undefined;
      return { disputeId: dispute?.id, expectedFingerprint: dispute?.fingerprint, decision, finalAmount };
    },
  },
  {
    kind: 'loan.application.prepare',
    title: 'Prepare loan application',
    section: 'loans',
    summary: 'Prepares a draft loan application for the member with evidence.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'productId', label: 'Loan product', options: (fx) => pickers.products(fx.ctx, 'loan') },
      { input: 'money', key: 'requestedAmount', label: 'Requested amount', currency: (fx) => fx.ctx.institution.defaultCurrency },
      { input: 'number', key: 'termMonths', label: 'Term (months)', min: 1, max: 480 },
      { input: 'text', key: 'purpose', label: 'Purpose', max: 200 },
      { input: 'lines', key: 'evidenceIds', label: 'Evidence ids', help: 'One identity-evidence id per line.' },
    ],
    build(fx) {
      const member = fx.subject('member', 'member', 'Member');
      const expectedMemberVersion = memberVersion(fx);
      const productId = fx.pick('productId', 'Loan product', pickers.products(fx.ctx, 'loan'));
      const requestedAmount = fx.money('requestedAmount', 'Requested amount', fx.ctx.institution.defaultCurrency);
      const termMonths = fx.int('termMonths', 'Term (months)', { min: 1, max: 480 });
      const purpose = fx.text('purpose', 'Purpose', { max: 200 });
      const evidenceIds = fx.lines('evidenceIds', 'Evidence ids');
      if ([member, expectedMemberVersion, productId, requestedAmount, termMonths, purpose, evidenceIds].some((v) => v === undefined)) return undefined;
      return { memberId: member?.id, expectedMemberVersion, productId, requestedAmount, termMonths, purpose, evidenceIds };
    },
  },
  {
    kind: 'loan.payment.allocate',
    title: 'Allocate loan payment',
    section: 'loans',
    summary: 'Applies received funds to the loan under the chosen allocation policy.',
    subjects: [{ key: 'loan', kind: 'loan', label: 'Loan' }],
    fields: [
      { input: 'text', key: 'receivedFundsReference', label: 'Received funds reference', max: 80 },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => { const loan = fx.subject('loan', 'loan', 'Loan'); return loan === undefined ? undefined : cell(loan.record?.currency ?? 'USD'); } },
      { input: 'select', key: 'allocationPolicy', label: 'Allocation policy', options: () => [
        { value: 'fees-interest-principal', label: 'Fees, interest, principal' },
        { value: 'fees-interest-principal-hold-remainder', label: 'Fees, interest, principal, hold remainder' },
      ] },
    ],
    build(fx) {
      const loan = fx.subject('loan', 'loan', 'Loan');
      const receivedFundsReference = fx.text('receivedFundsReference', 'Received funds reference', { max: 80 });
      const amount = fx.money('amount', 'Amount', cell(loan?.record?.currency));
      const allocationPolicy = fx.pick('allocationPolicy', 'Allocation policy', [
        { value: 'fees-interest-principal', label: 'Fees, interest, principal' },
        { value: 'fees-interest-principal-hold-remainder', label: 'Fees, interest, principal, hold remainder' },
      ]);
      if ([loan, receivedFundsReference, amount, allocationPolicy].some((v) => v === undefined)) return undefined;
      return { loanId: loan?.id, expectedFingerprint: loan?.fingerprint, receivedFundsReference, amount, allocationPolicy };
    },
  },
  {
    kind: 'loan.payoff.quote',
    title: 'Quote loan payoff',
    section: 'loans',
    summary: 'Computes an exact payoff quote for the loan as of a date under policy.',
    subjects: [{ key: 'loan', kind: 'loan', label: 'Loan' }],
    fields: [
      { input: 'date', key: 'payoffDate', label: 'Payoff date' },
      { input: 'select', key: 'policyVersionId', label: 'Policy', options: (fx) => pickers.policies(fx.ctx) },
    ],
    build(fx) {
      const loan = fx.subject('loan', 'loan', 'Loan');
      const payoffDate = fx.date('payoffDate', 'Payoff date');
      const policyVersionId = fx.pick('policyVersionId', 'Policy', pickers.policies(fx.ctx));
      if ([loan, payoffDate, policyVersionId].some((v) => v === undefined)) return undefined;
      return { loanId: loan?.id, expectedFingerprint: loan?.fingerprint, payoffDate, policyVersionId };
    },
  },
  {
    kind: 'loan.close',
    title: 'Close loan',
    section: 'loans',
    summary: 'Closes a paid-off loan on payoff evidence under approval.',
    subjects: [{ key: 'loan', kind: 'loan', label: 'Loan' }],
    approval: true,
    fields: [
      { input: 'select', key: 'payoffEvidenceId', label: 'Payoff evidence', options: (fx) => {
        const loan = fx.subject('loan', 'loan', 'Loan');
        const memberId = loan?.record?.member_id;
        return typeof memberId === 'string' ? pickers.memberEvidence(fx.ctx, memberId) : [];
      } },
    ],
    build(fx) {
      const loan = fx.subject('loan', 'loan', 'Loan');
      const memberId = loan?.record?.member_id;
      const payoffEvidenceId = typeof memberId === 'string' ? fx.pick('payoffEvidenceId', 'Payoff evidence', pickers.memberEvidence(fx.ctx, memberId)) : undefined;
      if ([loan, payoffEvidenceId].some((v) => v === undefined)) return undefined;
      return { loanId: loan?.id, expectedFingerprint: loan?.fingerprint, payoffEvidenceId };
    },
  },
  {
    kind: 'document.loan_closure.issue',
    title: 'Issue loan closure document',
    section: 'loans',
    summary: 'Issues the closure confirmation or lien-release document for a closed loan under approval.',
    subjects: [{ key: 'loan', kind: 'loan', label: 'Loan' }],
    approval: true,
    fields: [
      { input: 'select', key: 'templateVersionId', label: 'Template', options: (fx) => pickers.policies(fx.ctx) },
      { input: 'select', key: 'recipientPartyId', label: 'Recipient party', options: (fx) => {
        const loan = fx.subject('loan', 'loan', 'Loan');
        const memberId = loan?.record?.member_id;
        const partyId = typeof memberId === 'string' ? pickers.memberPartyId(fx.ctx, memberId) : undefined;
        return partyId === undefined ? pickers.parties(fx.ctx) : [{ value: partyId, label: `Member party ${partyId.slice(-8)}` }];
      } },
      { input: 'select', key: 'documentType', label: 'Document type', options: () => [
        { value: 'loan-closure-confirmation', label: 'Loan closure confirmation' },
        { value: 'simulated-lien-release', label: 'Simulated lien release' },
      ] },
    ],
    build(fx) {
      const loan = fx.subject('loan', 'loan', 'Loan');
      const closure = loan === undefined ? undefined : rows(fx.ctx, 'SELECT id FROM loan_closures WHERE dataset_id=? AND loan_id=?', fx.ctx.binding.datasetId, loan.id)[0];
      const expectedClosureFingerprint = closure === undefined ? undefined : fp(fx, 'closure', 'loan-closure', 'Loan closure');
      const templateVersionId = fx.text('templateVersionId', 'Template', { max: 80 });
      const recipientPartyId = fx.text('recipientPartyId', 'Recipient party', { max: 80 });
      const documentType = fx.pick('documentType', 'Document type', [
        { value: 'loan-closure-confirmation', label: 'Loan closure confirmation' },
        { value: 'simulated-lien-release', label: 'Simulated lien release' },
      ]);
      if ([loan, expectedClosureFingerprint, templateVersionId, recipientPartyId, documentType].some((v) => v === undefined)) return undefined;
      return { loanId: loan?.id, expectedClosureFingerprint, templateVersionId, recipientPartyId, documentType };
    },
  },
  {
    kind: 'account.maturity.instruct',
    title: 'Instruct account maturity',
    section: 'accounts',
    summary: 'Records the maturity disposition — renew, transfer, or hold — under approval.',
    subjects: [SUBJECT.account],
    approval: true,
    fields: [
      { input: 'select', key: 'disposition', label: 'Disposition', options: () => [
        { value: 'renew', label: 'Renew' },
        { value: 'transfer', label: 'Transfer to account' },
        { value: 'hold', label: 'Hold proceeds' },
      ], autoPostBack: true },
      { input: 'select', key: 'destinationAccountId', label: 'Destination account', required: false, blank: '(none)', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        const memberId = account?.record?.member_id;
        return typeof memberId === 'string' && account !== undefined ? pickers.memberAccounts(fx.ctx, memberId).filter((a) => a.value !== account.id) : [];
      } },
      { input: 'number', key: 'termMonths', label: 'Renewal term (months)', required: false, min: 1, max: 480 },
      { input: 'number', key: 'approvedAnnualRateBps', label: 'Approved annual rate (bps)', required: false, min: 0, max: 100000 },
      { input: 'select', key: 'expectedInstructionFingerprint', label: 'Current instruction', required: false, blank: '(none exists)', options: (fx) => {
        const account = fx.subject('account', 'account', 'Account');
        return account === undefined ? [] : pickers.maturityInstructions(fx.ctx, account.id);
      } },
    ],
    build(fx) {
      const account = fx.subject('account', 'account', 'Account');
      const expectedVersion = accountVersion(fx);
      const disposition = fx.pick('disposition', 'Disposition', [
        { value: 'renew', label: 'Renew' },
        { value: 'transfer', label: 'Transfer' },
        { value: 'hold', label: 'Hold' },
      ]);
      const memberId = account?.record?.member_id;
      const destinationAccountId = typeof memberId === 'string' && account !== undefined ? fx.pick('destinationAccountId', 'Destination account', pickers.memberAccounts(fx.ctx, memberId).filter((a) => a.value !== account.id), false) ?? null : null;
      const termMonths = fx.int('termMonths', 'Renewal term', { required: false, min: 1, max: 480 }) ?? null;
      const approvedAnnualRateBps = fx.int('approvedAnnualRateBps', 'Approved annual rate', { required: false, min: 0, max: 100000 }) ?? null;
      const instructionId = account === undefined ? undefined : fx.pick('expectedInstructionFingerprint', 'Current instruction', pickers.maturityInstructions(fx.ctx, account.id), false);
      const expectedInstructionFingerprint = instructionId === undefined ? null : fp(fx, 'expectedInstructionFingerprint', 'maturity-instruction', 'Current instruction') ?? null;
      if (instructionId !== undefined && expectedInstructionFingerprint === null) return undefined;
      if ([account, expectedVersion, disposition, destinationAccountId].some((v) => v === undefined)) return undefined;
      return { accountId: account?.id, expectedVersion, expectedInstructionFingerprint, disposition, destinationAccountId, termMonths, approvedAnnualRateBps };
    },
  },
  {
    kind: 'reconciliation.suspense.investigate',
    title: 'Investigate suspense item',
    section: 'batches',
    summary: 'Attaches evidence and a proposed account to an open suspense item.',
    subjects: [{ key: 'suspense', kind: 'suspense-item', label: 'Suspense item' }],
    fields: [
      { input: 'lines', key: 'evidenceReferences', label: 'Evidence references', help: 'One per line.' },
      { input: 'subject', key: 'proposedAccount', kind: 'account', label: 'Proposed account', required: false },
    ],
    build(fx) {
      const suspense = fx.subject('suspense', 'suspense-item', 'Suspense item');
      const evidenceReferences = fx.lines('evidenceReferences', 'Evidence references');
      const proposedAccount = fx.subject('proposedAccount', 'account', 'Proposed account', false);
      if ([suspense, evidenceReferences].some((v) => v === undefined)) return undefined;
      return { suspenseId: suspense?.id, expectedFingerprint: suspense?.fingerprint, evidenceReferences, proposedAccountId: proposedAccount?.id ?? null };
    },
  },
  {
    kind: 'reconciliation.suspense.clear',
    title: 'Clear suspense item',
    section: 'batches',
    summary: 'Posts the suspense remainder to a destination account on evidence under approval.',
    subjects: [{ key: 'suspense', kind: 'suspense-item', label: 'Suspense item' }],
    approval: true,
    fields: [
      { input: 'subject', key: 'destinationAccount', kind: 'account', label: 'Destination account' },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => { const suspense = fx.subject('suspense', 'suspense-item', 'Suspense item'); return suspense === undefined ? undefined : cell(suspense.record?.currency ?? 'USD'); } },
      { input: 'text', key: 'evidenceReference', label: 'Evidence reference', max: 200 },
    ],
    build(fx) {
      const suspense = fx.subject('suspense', 'suspense-item', 'Suspense item');
      const destination = fx.subject('destinationAccount', 'account', 'Destination account');
      const amount = fx.money('amount', 'Amount', cell(suspense?.record?.currency));
      const evidenceReference = fx.text('evidenceReference', 'Evidence reference', { max: 200 });
      if ([suspense, destination, amount, evidenceReference].some((v) => v === undefined)) return undefined;
      return { suspenseId: suspense?.id, expectedFingerprint: suspense?.fingerprint, destinationAccountId: destination?.id, amount, evidenceReference };
    },
  },
  {
    kind: 'batch.import',
    title: 'Import batch',
    section: 'batches',
    summary: 'Imports a batch file as immutable items bound to the uploaded document version digest.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'documentVersionId', label: 'Batch file version', options: (fx) => memberDocs(fx) },
      { input: 'text', key: 'batchNumber', label: 'Batch number', max: 40 },
      { input: 'select', key: 'batchKind', label: 'Batch kind', options: () => [
        { value: 'contact-update', label: 'Contact update' },
        { value: 'fee-refund', label: 'Fee refund' },
      ] },
      { input: 'select', key: 'currency', label: 'Currency', required: false, blank: '(not bounded)', options: (fx) => pickers.currencies(fx.ctx) },
    ],
    build(fx) {
      const documentVersionId = documentVersionPickId(fx);
      const inputDigest = documentVersionId === undefined ? undefined : documentDigest(fx, documentVersionId);
      const batchNumber = fx.text('batchNumber', 'Batch number', { max: 40 });
      const batchKind = fx.pick('batchKind', 'Batch kind', [
        { value: 'contact-update', label: 'Contact update' },
        { value: 'fee-refund', label: 'Fee refund' },
      ]);
      const currency = fx.pick('currency', 'Currency', pickers.currencies(fx.ctx), false) ?? null;
      if ([documentVersionId, inputDigest, batchNumber, batchKind, currency].some((v) => v === undefined)) return undefined;
      return { documentVersionId, inputDigest, batchNumber, batchKind, currency };
    },
  },
  {
    kind: 'batch.contacts.apply',
    title: 'Apply contact batch item',
    section: 'batches',
    summary: 'Applies one approved contact-update batch item with a stale-conflict policy, under approval.',
    subjects: [{ key: 'batch', kind: 'batch', label: 'Batch' }],
    approval: true,
    fields: [
      { input: 'select', key: 'itemId', label: 'Batch item', options: (fx) => {
        const batch = fx.subject('batch', 'batch', 'Batch');
        return batch === undefined ? [] : pickers.batchItems(fx.ctx, batch.id);
      } },
      { input: 'select', key: 'conflictPolicy', label: 'Conflict policy', options: () => [
        { value: 'skip-stale', label: 'Skip stale items' },
        { value: 'reject-all', label: 'Reject the whole apply' },
      ] },
    ],
    build(fx) {
      const batch = fx.subject('batch', 'batch', 'Batch');
      const itemId = batch === undefined ? undefined : fx.pick('itemId', 'Batch item', pickers.batchItems(fx.ctx, batch.id));
      const conflictPolicy = fx.pick('conflictPolicy', 'Conflict policy', [
        { value: 'skip-stale', label: 'Skip stale' },
        { value: 'reject-all', label: 'Reject all' },
      ]);
      if ([batch, itemId, conflictPolicy].some((v) => v === undefined)) return undefined;
      return { batchId: batch?.id, itemId, expectedFingerprint: batch?.fingerprint, conflictPolicy };
    },
  },
  {
    kind: 'batch.fee_refunds.apply',
    title: 'Apply fee-refund batch item',
    section: 'batches',
    summary: 'Applies one approved fee-refund batch item, under approval bounded by the batch limit.',
    subjects: [{ key: 'batch', kind: 'batch', label: 'Batch' }],
    approval: true,
    fields: [
      { input: 'select', key: 'itemId', label: 'Batch item', options: (fx) => {
        const batch = fx.subject('batch', 'batch', 'Batch');
        return batch === undefined ? [] : pickers.batchItems(fx.ctx, batch.id);
      } },
    ],
    build(fx) {
      const batch = fx.subject('batch', 'batch', 'Batch');
      const itemId = batch === undefined ? undefined : fx.pick('itemId', 'Batch item', pickers.batchItems(fx.ctx, batch.id));
      if ([batch, itemId].some((v) => v === undefined)) return undefined;
      return { batchId: batch?.id, itemId, expectedFingerprint: batch?.fingerprint };
    },
  },
];

function row_version(fx: Fx, memberId: string): number | undefined {
  const record = rows(fx.ctx, 'SELECT version FROM members WHERE dataset_id=? AND id=?', fx.ctx.binding.datasetId, memberId)[0];
  return record === undefined ? undefined : Number(record.version);
}

function documentVersionPickId(fx: Fx): string | undefined {
  const member = fx.subject('member', 'member', 'Member');
  if (member === undefined) return undefined;
  return fx.pick('documentVersionId', 'Batch file version', pickers.memberDocumentVersions(fx.ctx, member.id));
}

function documentDigest(fx: Fx, versionId: string): string | undefined {
  const record = rows(fx.ctx, 'SELECT digest FROM document_versions WHERE dataset_id=? AND id=?', fx.ctx.binding.datasetId, versionId)[0];
  if (record === undefined) {
    fx.fail('documentVersionId', 'The document version has no stored digest.');
    return undefined;
  }
  return String(record.digest);
}
