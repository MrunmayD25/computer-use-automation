import {
  validateServiceCommand,
  type OperationReview,
  type ServiceCommand,
} from '@computer-use/financial-database/services';

import type { ViewBuilder } from '../controls.js';
import type { Crumb } from '../layout.js';
import { html, type SafeHtml } from '../html.js';
import { formatAmount } from '../money.js';
import { pageHref } from '../page-names.js';
import {
  definePage,
  redirectTo,
  rejectionError,
  rendered,
  type LoadOutcome,
  type Outcome,
  type PageContext,
  type PageState,
} from '../runtime.js';
import { Fx, resolveSubject, type FieldSpec, type OperationSpec } from './fields.js';
import { cell, pickers, type Choice } from './subjects.js';
import { OPERATIONS, OPERATION_SECTIONS } from './specs.js';

const APPROVAL_FIELD = 'approvalId';

interface PendingReview {
  readonly command: Record<string, unknown>;
  /** Null for an approval-bound operation awaiting its approval request — no target review exists yet. */
  readonly terms: OperationReview | null;
}

export interface OpData {
  readonly review: PendingReview | null;
}

export type OpEvent =
  | { readonly kind: 'refresh' }
  | { readonly kind: 'locate' }
  | { readonly kind: 'review' }
  | { readonly kind: 'commit' }
  | { readonly kind: 'request-approval' }
  | { readonly kind: 'clear' };

function specFor(ctx: PageContext): OperationSpec | undefined {
  const op = ctx.query.get('op') ?? '';
  return OPERATIONS.find((candidate) => candidate.kind === op);
}

/** Field values prefilled from a stored approval scope when the checker opens the operation. */
function scopePrefill(ctx: PageContext, spec: OperationSpec): Record<string, string> {
  const approvalId = ctx.query.get('approval') ?? '';
  if (approvalId === '' || spec.approval !== true) return {};
  const approval = ctx.read((db) =>
    db.prepare("SELECT scope_json FROM business_approvals WHERE dataset_id=? AND id=?").get(ctx.binding.datasetId, approvalId),
  );
  if (approval === undefined || typeof approval.scope_json !== 'string') return {};
  let scope: Record<string, unknown>;
  try {
    scope = JSON.parse(approval.scope_json) as Record<string, unknown>;
  } catch {
    return {};
  }
  const values: Record<string, string> = { [APPROVAL_FIELD]: approvalId };
  for (const field of spec.fields) {
    const value = scope[field.key];
    if (typeof value === 'string' || typeof value === 'number') {
      values[field.key] = String(value);
    } else if (field.input === 'money' && value !== null && typeof value === 'object') {
      const money = value as { minorUnits?: unknown; currency?: unknown };
      if (typeof money.minorUnits === 'number' && typeof money.currency === 'string') {
        values[field.key] = String(money.minorUnits);
        values[`${field.key}Ccy`] = money.currency;
        values[`${field.key}Minor`] = 'true';
      }
    }
  }
  return values;
}

function buildCommand(ctx: PageContext, spec: OperationSpec, fields: Record<string, string>, errors: PageState<OpData>['errors']): ServiceCommand | undefined {
  const fx = new Fx(ctx, fields);
  const built = spec.build(fx);
  if (built === undefined) {
    if (fx.ok) fx.fail(null, 'The operation could not be assembled from these entries.');
    errors.push(...fx.check.errors);
    return undefined;
  }
  if (spec.approval === true) {
    built[APPROVAL_FIELD] = (fields[APPROVAL_FIELD] ?? '').trim();
  }
  if (!fx.ok) {
    errors.push(...fx.check.errors);
    return undefined;
  }
  const command = { kind: spec.kind, ...built } as ServiceCommand;
  const invalid = validateServiceCommand(command);
  if (invalid !== null) {
    errors.push({ field: invalid.field ?? null, message: invalid.message });
    return undefined;
  }
  return command;
}

function reviewCommand(ctx: PageContext, spec: OperationSpec, state: PageState<OpData>): Outcome<OpData> {
  const command = buildCommand(ctx, spec, state.fields, state.errors);
  // Field validation is a recoverable form rejection; keep the document a normal
  // postback response so browsers preserve the entered values and summary.
  if (command === undefined) return rendered(state);
  const approvalId = spec.approval === true ? cell((command as Record<string, unknown>)[APPROVAL_FIELD]) : '';
  // A maker cannot preview the target without a bound approval; the request itself is what they confirm.
  if (spec.approval === true && approvalId === '') {
    state.data = { review: { command: command as Record<string, unknown>, terms: null } };
    return rendered(state);
  }
  const outcome = ctx.review(command);
  switch (outcome.kind) {
    case 'reviewable':
      state.data = { review: { command: command as Record<string, unknown>, terms: outcome.review } };
      return rendered(state);
    case 'unchanged':
      state.notice = outcome.message;
      return rendered(state);
    case 'rejected':
      return rejectionError(state, outcome);
  }
}

function commit(ctx: PageContext, state: PageState<OpData>): Outcome<OpData> {
  const review = state.data.review;
  if (review === null) {
    state.errors.push({ field: null, message: 'Review the operation before committing it.' });
    return rendered(state);
  }
  const outcome = ctx.execute(review.command as ServiceCommand, 'commit', state.formKey);
  switch (outcome.kind) {
    case 'committed':
    case 'duplicate':
      return redirectTo(pageHref('Receipt.aspx', { no: outcome.receipt.receiptNumber, msg: outcome.kind === 'duplicate' ? 'posted' : 'posted' }));
    case 'unchanged':
      state.data = { review: null };
      state.notice = outcome.message;
      return rendered(state);
    case 'rejected':
      return rejectionError(state, outcome);
  }
}

function requestApproval(ctx: PageContext, spec: OperationSpec, state: PageState<OpData>): Outcome<OpData> {
  const review = state.data.review;
  if (review === null || spec.approval !== true) {
    state.errors.push({ field: null, message: 'Review the operation before requesting approval.' });
    return rendered(state);
  }
  const fx = new Fx(ctx, state.fields);
  const checkerId = fx.pick('apChecker', 'Approving operator', pickers.checkers(ctx, ctx.grantsFor(spec.kind)));
  const policyVersionId = fx.pick('apPolicy', 'Approval policy', pickers.policies(ctx));
  const expiresAt = fx.instant('apExpires', 'Approval expiry');
  const limitText = (state.fields.apAmount ?? '').trim();
  const limitCcy = (state.fields.apAmountCcy ?? '').trim();
  const amountLimit = limitText === '' ? null : fx.money('apAmount', 'Approval amount limit', limitCcy === '' ? ctx.institution.defaultCurrency : limitCcy);
  if (!fx.ok) {
    state.errors.push(...fx.check.errors);
    return rendered(state);
  }
  const command: ServiceCommand = {
    kind: 'approval.request',
    target: { ...review.command, [APPROVAL_FIELD]: '' } as never,
    checkerActorId: checkerId ?? '',
    policyVersionId: policyVersionId ?? '',
    expiresAt: expiresAt ?? ctx.businessNow,
    amountLimit: amountLimit ?? null,
  };
  const outcome = ctx.execute(command, 'request-approval', state.formKey);
  switch (outcome.kind) {
    case 'committed':
    case 'duplicate': {
      const approvalId = cell((outcome.receipt.result ?? {}).approvalId);
      return redirectTo(pageHref('Approvals.aspx', { msg: 'approval-requested', approval: approvalId }));
    }
    case 'unchanged':
      state.notice = outcome.message;
      return rendered(state);
    case 'rejected':
      return rejectionError(state, outcome);
  }
}

function locate(ctx: PageContext, spec: OperationSpec, state: PageState<OpData>): Outcome<OpData> {
  const parameters: Record<string, string> = { op: spec.kind };
  const approval = ctx.query.get('approval');
  if (approval !== null) parameters.approval = approval;
  for (const subject of spec.subjects) {
    const value = (state.fields[`locate_${subject.key}`] ?? ctx.query.get(subject.key) ?? '').trim();
    if (value !== '') parameters[subject.key] = value;
  }
  return redirectTo(`${ctx.page}?${new URLSearchParams(parameters).toString()}`);
}

/* ---------- rendering ---------- */

function fieldRow(view: ViewBuilder<OpEvent>, fx: Fx, field: FieldSpec): SafeHtml {
  const id = `fld_${field.key.replaceAll('.', '_')}`;
  const label = html`<th scope="row">${view.label(id, field.label)}${field.input !== 'bool' && 'required' in field && !field.required ? html` <span class="optional">(optional)</span>` : ''}</th>`;
  const help = 'help' in field ? html`<div class="field-help">${field.help}</div>` : '';
  switch (field.input) {
    case 'text':
      return html`<tr>${label}<td>${view.textBox(id, { field: field.key, maxLength: field.max ?? 200, columns: 32 })}${help}</td></tr>`;
    case 'textarea':
      return html`<tr>${label}<td>${view.textArea(id, { field: field.key, rows: 4, maxLength: field.max ?? 4000 })}${help}</td></tr>`;
    case 'select': {
      const items: readonly Choice[] = field.options(fx);
      const list = field.blank === undefined ? items : [{ value: '', label: field.blank }, ...items];
      return html`<tr>${label}<td>${view.dropDownList(id, { field: field.key, items: list.map((item) => ({ value: item.value, text: item.label })), ...(field.autoPostBack === true ? { autoPostBack: { kind: 'refresh' } } : {}) })}${help}</td></tr>`;
    }
    case 'money': {
      const fixed = field.currency?.(fx);
      const currencyInput =
        fixed === undefined
          ? view.dropDownList(`${id}_ccy`, {
              field: `${field.key}Ccy`,
              items: pickers.currencies(fx.ctx).map((item) => ({ value: item.value, text: item.label })),
            })
          : html`<span class="currency-label">${fixed}</span>`;
      const minorHint = fx.raw(`${field.key}Minor`) === 'true' ? html`<div class="field-help">This amount is shown in minor units because it was prefilled from an approval scope.</div>` : '';
      return html`<tr>${label}<td>${view.textBox(id, { field: field.key, maxLength: 24, columns: 14 })} ${currencyInput}${help}${minorHint}</td></tr>`;
    }
    case 'date':
      return html`<tr>${label}<td>${view.textBox(id, { field: field.key, maxLength: 10, columns: 12 })} <span class="format-hint">YYYY-MM-DD</span>${help}</td></tr>`;
    case 'instant':
      return html`<tr>${label}<td>${view.textBox(id, { field: field.key, maxLength: 40, columns: 24 })} <span class="format-hint">YYYY-MM-DDTHH:MMZ</span>${help}</td></tr>`;
    case 'number':
      return html`<tr>${label}<td>${view.textBox(id, { field: field.key, maxLength: 15, columns: 10 })}${help}</td></tr>`;
    case 'bool':
      return html`<tr>${label}<td>${view.dropDownList(id, { field: field.key, items: [{ value: 'no', text: 'No' }, { value: 'yes', text: 'Yes' }] })}</td></tr>`;
    case 'lines':
      return html`<tr>${label}<td>${view.textArea(id, { field: field.key, rows: 4, maxLength: 8000 })}${help}</td></tr>`;
    case 'filetext':
      return html`<tr>${label}<td>${view.textArea(id, { field: field.key, rows: 8, maxLength: 400000 })}${help}<div class="field-help">The text is stored exactly as UTF-8 bytes; its digest binds the content.</div></td></tr>`;
    case 'subject':
      return html`<tr>${label}<td>${view.textBox(id, { field: field.key, maxLength: 80, columns: 28 })}${help}</td></tr>`;
  }
}

function subjectChips(ctx: PageContext, spec: OperationSpec): SafeHtml {
  const chips = spec.subjects.map((subject) => {
    const reference = (ctx.query.get(subject.key) ?? '').trim();
    const outcome = reference === '' ? { kind: 'missing' as const } : resolveSubject(ctx, subject.kind, reference);
    const content =
      outcome.kind === 'found'
        ? html`<span class="chip found">${subject.label}: ${outcome.subject.label}${outcome.subject.version === undefined ? '' : html` · v${outcome.subject.version}`}</span>`
        : html`<span class="chip missing">${subject.label}: ${reference === '' ? 'not selected' : `not found (${reference})`}</span>`;
    return content;
  });
  return chips.length === 0 ? html`` : html`<div class="subject-bar">${chips}</div>`;
}

function reviewPanel(view: ViewBuilder<OpEvent>, ctx: PageContext, spec: OperationSpec, review: PendingReview): SafeHtml {
  const terms = review.terms;
  const amount = terms?.amount == null ? html`` : html`<tr><th scope="row">Amount</th><td class="amount">${formatAmount(terms.amount.minorUnits, { code: terms.amount.currency, exponent: terms.exponent ?? 2, name: '' })}</td></tr>`;
  const accounts =
    terms === null || terms.accounts.length === 0
      ? html``
      : html`<table class="details"><tr><th>Account</th><th>Posted before</th><th>Posted after</th><th>Available after</th><th>Version</th></tr>${terms.accounts.map(
          (account) =>
            html`<tr><td>${account.accountNumber} ${account.ownerName}</td><td class="amount">${formatAmount(account.postedBeforeMinorUnits, { code: account.currency, exponent: account.exponent, name: '' })}</td><td class="amount">${formatAmount(
              account.postedAfterMinorUnits,
              { code: account.currency, exponent: account.exponent, name: '' },
            )}</td><td class="amount">${formatAmount(account.availableAfterMinorUnits, { code: account.currency, exponent: account.exponent, name: '' })}</td><td>${account.version}</td></tr>`,
        )}</table>`;
  const approvalFields =
    spec.approval === true && (review.command[APPROVAL_FIELD] === '' || review.command[APPROVAL_FIELD] === undefined)
      ? html`<fieldset class="approval-request"><legend>Independent approval</legend><table class="form">
          <tr><th scope="row">${view.label('fld_apChecker', 'Approving operator')}</th><td>${view.dropDownList('fld_apChecker', {
            field: 'apChecker',
            items: pickers.checkers(ctx, ctx.grantsFor(spec.kind)).map((item) => ({ value: item.value, text: item.label })),
          })}</td></tr>
          <tr><th scope="row">${view.label('fld_apPolicy', 'Policy')}</th><td>${view.dropDownList('fld_apPolicy', {
            field: 'apPolicy',
            items: pickers.policies(ctx).map((item) => ({ value: item.value, text: item.label })),
          })}</td></tr>
          <tr><th scope="row">${view.label('fld_apExpires', 'Expires at')}</th><td>${view.textBox('fld_apExpires', { field: 'apExpires', maxLength: 40, columns: 24 })} <span class="format-hint">YYYY-MM-DDTHH:MMZ, within 7 days</span></td></tr>
          <tr><th scope="row">${view.label('fld_apAmount', 'Amount limit')}</th><td>${view.textBox('fld_apAmount', { field: 'apAmount', maxLength: 24, columns: 14 })} ${view.dropDownList('fld_apAmountCcy', {
            field: 'apAmountCcy',
            items: pickers.currencies(ctx).map((item) => ({ value: item.value, text: item.label })),
          })} <span class="format-hint">optional</span></td></tr>
        </table></fieldset>`
      : html``;
  const commitButton =
    spec.approval === true && (review.command[APPROVAL_FIELD] === '' || review.command[APPROVAL_FIELD] === undefined)
      ? view.button('btnRequestApproval', 'Request approval', { kind: 'request-approval' }, { primary: true })
      : view.button('btnCommit', 'Commit', { kind: 'commit' }, { primary: true });
  return html`<div class="review-panel" id="reviewPanel">
    <h2>Review — no changes saved yet</h2>
    <table class="details">
      <tr><th scope="row">Operation</th><td>${spec.title} <span class="mono">(${spec.kind})</span></td></tr>
      ${amount}
      ${terms?.description == null ? '' : html`<tr><th scope="row">Description</th><td>${terms.description}</td></tr>`}
    </table>
    ${accounts}
    ${terms === null ? html`<p class="hint">This operation requires an approved action before it can commit. Complete the approval request below; the assigned checker will review and execute it.</p>` : html`<ul class="consequences">${terms.consequences.map((line) => html`<li>${line}</li>`)}</ul>`}
    <details class="command-scope"><summary>Exact command scope</summary><pre>${JSON.stringify(review.command, null, 2)}</pre></details>
    ${approvalFields}
    <div class="actions">${commitButton} ${view.button('btnClear', 'Change entries', { kind: 'clear' })}</div>
  </div>`;
}

function directory(ctx: PageContext): SafeHtml {
  return html`${OPERATION_SECTIONS.map(
    (section) => html`<h2 class="op-section">${section.label}</h2><table class="grid" cellspacing="0" rules="all" border="1"><tr class="grid-header"><th>Operation</th><th>Summary</th><th>Permission</th></tr>${OPERATIONS.filter(
      (spec) => spec.section === section.id,
    ).map(
      (spec) =>
        html`<tr class="grid-row"><td><a href="${pageHref('Operation.aspx', { op: spec.kind })}">${spec.title}</a></td><td>${spec.summary}</td><td>${ctx.permits(spec.kind) ? 'available' : `requires ${ctx.grantsFor(spec.kind).join(' or ')}`}</td></tr>`,
    )}</table>`,
  )}`;
}

/** Hosts one operation spec as a full postback page; used by Operation.aspx and dedicated entry pages. */
export function specPageHost(spec: OperationSpec): {
  load(ctx: PageContext): LoadOutcome<OpData>;
  handle(ctx: PageContext, state: PageState<OpData>, event: OpEvent | null): Outcome<OpData>;
  render(ctx: PageContext, state: PageState<OpData>, view: ViewBuilder<OpEvent>): { title: string; breadcrumbs: readonly Crumb[]; body: SafeHtml };
} {
  return {
    load(ctx): LoadOutcome<OpData> {
      const prefill = scopePrefill(ctx, spec);
      const fields: Record<string, string> = { ...prefill };
      for (const subject of spec.subjects) {
        const reference = ctx.query.get(subject.key);
        if (reference !== null && reference.trim() !== '') fields[`locate_${subject.key}`] = reference;
      }
      if (spec.approval === true && prefill[APPROVAL_FIELD] === undefined && (ctx.query.get('approval') ?? '') !== '') {
        fields[APPROVAL_FIELD] = ctx.query.get('approval') ?? '';
      }
      return { kind: 'ready', data: { review: null }, fields };
    },

    handle(ctx, state, event): Outcome<OpData> {
      switch (event?.kind) {
        case 'locate':
          return locate(ctx, spec, state);
        case 'review':
          state.data = { review: null };
          return reviewCommand(ctx, spec, state);
        case 'commit':
          return commit(ctx, state);
        case 'request-approval':
          return requestApproval(ctx, spec, state);
        case 'clear':
          state.data = { review: null };
          return rendered(state);
        default:
          return rendered(state);
      }
    },

    render(ctx, state, view) {
      return renderSpecForm(ctx, spec, state, view);
    },
  };
}

function renderSpecForm(ctx: PageContext, spec: OperationSpec, state: PageState<OpData>, view: ViewBuilder<OpEvent>): { title: string; breadcrumbs: readonly Crumb[]; body: SafeHtml } {
    const fx = new Fx(ctx, state.fields);
    const permitted = ctx.permits(spec.kind);
    const subjects = spec.subjects;
    const missingSubjects = subjects.filter((subject) => subject.optional !== true && (ctx.query.get(subject.key) ?? '').trim() === '' && (state.fields[`locate_${subject.key}`] ?? '').trim() === '');
    const locateBar =
      subjects.length === 0
        ? html``
        : html`<div class="locate-bar"><table class="form">${subjects.map(
            (subject) =>
              html`<tr><th scope="row">${view.label(`locate_${subject.key}`, subject.label)}</th><td>${view.textBox(`locate_${subject.key}`, { field: `locate_${subject.key}`, maxLength: 80, columns: 28 })}</td></tr>`,
          )}</table>${view.button('btnLocate', 'Open subjects', { kind: 'locate' })}</div>`;
    const fieldsHtml =
      missingSubjects.length > 0
        ? html`<p class="hint">Select ${missingSubjects.map((subject) => subject.label.toLowerCase()).join(', ')} to begin.</p>`
        : html`<table class="form">${spec.fields.map((field) => fieldRow(view, fx, field))}</table>${
            spec.approval === true
              ? html`<table class="form"><tr><th scope="row">${view.label('fld_approvalId', 'Approval id')}</th><td>${view.textBox('fld_approvalId', { field: APPROVAL_FIELD, maxLength: 80, columns: 36 })} <span class="format-hint">fill only when executing an approved action</span></td></tr></table>`
              : ''
          }<div class="actions">${view.button('btnReview', 'Review', { kind: 'review' }, { primary: true, disabled: !permitted })}</div>`;
    const denied = permitted ? '' : html`<div class="notice warning">This operation requires ${ctx.grantsFor(spec.kind).join(' or ')} authority; ${ctx.actor.displayName} cannot commit it.</div>`;
    const review = state.data.review === null ? '' : reviewPanel(view, ctx, spec, state.data.review);
    return {
      title: spec.title,
      breadcrumbs: [
        { label: 'Home', href: 'Default.aspx' },
        { label: 'Operations', href: 'Operation.aspx' },
        { label: spec.title, href: null },
      ],
      body: html`<p class="op-summary">${spec.summary}</p>${denied}${subjectChips(ctx, spec)}${locateBar}${fieldsHtml}${review}`,
    };
}

export const operationPage = definePage<OpData, OpEvent>({
  load(ctx): LoadOutcome<OpData> {
    const spec = specFor(ctx);
    if (spec === undefined) return { kind: 'ready', data: { review: null } };
    return specPageHost(spec).load(ctx);
  },

  handle(ctx, state, event): Outcome<OpData> {
    const spec = specFor(ctx);
    if (spec === undefined) return rendered(state);
    return specPageHost(spec).handle(ctx, state, event);
  },

  render(ctx, state, view) {
    const spec = specFor(ctx);
    if (spec === undefined) {
      return {
        title: 'Operations',
        breadcrumbs: [
          { label: 'Home', href: 'Default.aspx' },
          { label: 'Operations', href: null },
        ],
        body: html`<p class="hint">Every business action runs through review, then commit or independent approval. Nothing on this page saves until Commit.</p>${directory(ctx)}`,
      };
    }
    return specPageHost(spec).render(ctx, state, view);
  },
});
