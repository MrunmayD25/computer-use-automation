import {
  CASE_TRANSITIONS,
  parseSavedSearchDefinition,
  savedSearchRevision,
  type AddressInput,
  type CaseState,
  type SavedSearchDefinition,
} from '@computer-use/financial-database/services';

import type { FieldSpec, Fx, OperationSpec, SubjectSpec } from './fields.js';
import { cell, pickers, row } from './subjects.js';

export const SUBJECT = {
  member: { key: 'member', kind: 'member', label: 'Member' } satisfies SubjectSpec,
  memberOptional: { key: 'member', kind: 'member', label: 'Member', optional: true } satisfies SubjectSpec,
  account: { key: 'account', kind: 'account', label: 'Account' } satisfies SubjectSpec,
  accountOptional: { key: 'account', kind: 'account', label: 'Account', optional: true } satisfies SubjectSpec,
  case: { key: 'case', kind: 'case', label: 'Case' } satisfies SubjectSpec,
  request: { key: 'request', kind: 'request', label: 'Request' } satisfies SubjectSpec,
};

export const memberId = (fx: Fx, key = 'member', label = 'Member'): string | undefined => fx.subject(key, 'member', label)?.id;
export const memberVersion = (fx: Fx, key = 'member'): number | undefined => {
  const subject = fx.subject(key, 'member', 'Member');
  if (subject?.version === undefined) fx.fail(key, 'The member record has no editable version.');
  return subject?.version;
};
export const accountId = (fx: Fx, key = 'account', label = 'Account'): string | undefined => fx.subject(key, 'account', label)?.id;
export const accountVersion = (fx: Fx, key = 'account'): number | undefined => {
  const subject = fx.subject(key, 'account', 'Account');
  if (subject?.version === undefined) fx.fail(key, 'The account record has no editable version.');
  return subject?.version;
};
export const caseId = (fx: Fx, key = 'case'): string | undefined => fx.subject(key, 'case', 'Case')?.id;
export const caseVersion = (fx: Fx, key = 'case'): number | undefined => {
  const subject = fx.subject(key, 'case', 'Case');
  if (subject?.version === undefined) fx.fail(key, 'The case record has no editable version.');
  return subject?.version;
};
export const accountCurrency = (fx: Fx, key = 'account'): string | undefined => {
  const record = fx.subject(key, 'account', 'Account')?.record;
  return record === undefined ? undefined : cell(record.currency);
};

/** Reads the six address inputs into an AddressInput, or null when all are blank and not required. */
export function addressInput(fx: Fx, prefix: string, required: boolean): AddressInput | null | undefined {
  const raw = (key: string) => (fx.fields[`${prefix}.${key}`] ?? '').trim();
  const present = ['line1', 'line2', 'city', 'region', 'postalCode', 'country'].some((key) => raw(key) !== '');
  if (!present) {
    if (required) {
      fx.fail(`${prefix}.line1`, 'Address is required.');
      return undefined;
    }
    return null;
  }
  const line1 = fx.text(`${prefix}.line1`, 'Address line 1');
  const city = fx.text(`${prefix}.city`, 'City');
  const region = fx.text(`${prefix}.region`, 'Region/state');
  const postalCode = fx.text(`${prefix}.postalCode`, 'Postal code');
  const country = fx.text(`${prefix}.country`, 'Country');
  const line2 = fx.opt(`${prefix}.line2`, 'Address line 2');
  if ([line1, city, region, postalCode, country, line2].some((value) => value === undefined)) return undefined;
  return { line1: line1 ?? '', line2: line2 ?? null, city: city ?? '', region: region ?? '', postalCode: postalCode ?? '', country: country ?? '' };
}

export const addressFields = (prefix: string, required: boolean): FieldSpec[] => [
  { input: 'text', key: `${prefix}.line1`, label: 'Address line 1', required, max: 120 },
  { input: 'text', key: `${prefix}.line2`, label: 'Address line 2', required: false, max: 120 },
  { input: 'text', key: `${prefix}.city`, label: 'City', required, max: 80 },
  { input: 'text', key: `${prefix}.region`, label: 'Region/state', required, max: 80 },
  { input: 'text', key: `${prefix}.postalCode`, label: 'Postal code', required, max: 16 },
  { input: 'text', key: `${prefix}.country`, label: 'Country (ISO)', required: required, max: 2, help: 'Two-letter country code, for example US.' },
];

export const contactFields: FieldSpec[] = [
  { input: 'text', key: 'email', label: 'Email', required: false, max: 120 },
  { input: 'text', key: 'phone', label: 'Phone', required: false, max: 40 },
];

export const yesNo = (fx: Fx, key: string, label: string): boolean | undefined => {
  const value = fx.pick(key, label, [
    { value: 'yes', label: 'Yes' },
    { value: 'no', label: 'No' },
  ]);
  return value === undefined ? undefined : value === 'yes';
};

function savedSearchDefinition(fx: Fx): SavedSearchDefinition | undefined {
  const text = fx.text('definition', 'Search definition (JSON)', { required: true, max: 8000 });
  if (text === undefined) return undefined;
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    fx.fail('definition', 'Search definition must be valid JSON.');
    return undefined;
  }
  const outcome = parseSavedSearchDefinition(parsed);
  if (!outcome.ok) {
    fx.fail('definition', `Search definition: ${outcome.message}`);
    return undefined;
  }
  return outcome.definition;
}

export const coreSpecs: OperationSpec[] = [
  {
    kind: 'member.create',
    title: 'Create member (person)',
    section: 'members',
    summary: 'Onboards a person member with optional contact points and mailing address.',
    subjects: [],
    fields: [
      { input: 'text', key: 'legalGiven', label: 'Legal given name', max: 80 },
      { input: 'text', key: 'legalFamily', label: 'Legal family name', max: 80 },
      { input: 'text', key: 'preferredName', label: 'Preferred name', required: false, max: 80 },
      { input: 'date', key: 'birthDate', label: 'Birth date' },
      ...contactFields,
      ...addressFields('addr', false),
    ],
    build(fx) {
      const legalGiven = fx.text('legalGiven', 'Legal given name');
      const legalFamily = fx.text('legalFamily', 'Legal family name');
      const preferredName = fx.opt('preferredName', 'Preferred name');
      const birthDate = fx.date('birthDate', 'Birth date');
      const email = fx.opt('email', 'Email');
      const phone = fx.opt('phone', 'Phone');
      const address = addressInput(fx, 'addr', false);
      if ([legalGiven, legalFamily, preferredName, birthDate, email, phone, address].some((v) => v === undefined)) return undefined;
      return { legalGiven, legalFamily, preferredName, birthDate, email, phone, address };
    },
  },
  {
    kind: 'member.organization.create',
    title: 'Create member (organization)',
    section: 'members',
    summary: 'Onboards an organization member with registration details and optional contacts.',
    subjects: [],
    fields: [
      { input: 'text', key: 'legalName', label: 'Legal name', max: 160 },
      { input: 'text', key: 'registrationNumber', label: 'Registration number', max: 60 },
      { input: 'select', key: 'organizationType', label: 'Organization type', options: () => [
        { value: 'corporation', label: 'Corporation' },
        { value: 'nonprofit', label: 'Nonprofit' },
      ] },
      ...contactFields,
      ...addressFields('addr', false),
    ],
    build(fx) {
      const legalName = fx.text('legalName', 'Legal name');
      const registrationNumber = fx.text('registrationNumber', 'Registration number');
      const organizationType = fx.pick('organizationType', 'Organization type', [
        { value: 'corporation', label: 'Corporation' },
        { value: 'nonprofit', label: 'Nonprofit' },
      ]);
      const email = fx.opt('email', 'Email');
      const phone = fx.opt('phone', 'Phone');
      const address = addressInput(fx, 'addr', false);
      if ([legalName, registrationNumber, organizationType, email, phone, address].some((v) => v === undefined)) return undefined;
      return { legalName, registrationNumber, organizationType, email, phone, address };
    },
  },
  {
    kind: 'contact.update',
    title: 'Update contact details',
    section: 'members',
    summary: 'Replaces the member’s email, phone, or mailing address. Blank fields clear the value.',
    subjects: [SUBJECT.member],
    fields: [...contactFields, ...addressFields('addr', false)],
    build(fx) {
      const id = memberId(fx);
      const expectedVersion = memberVersion(fx);
      const email = fx.opt('email', 'Email');
      const phone = fx.opt('phone', 'Phone');
      const address = addressInput(fx, 'addr', false);
      if ([id, expectedVersion, email, phone, address].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { memberId: id, expectedVersion, email, phone };
      if (address !== null) command.address = address;
      return command;
    },
  },
  {
    kind: 'member.note.add',
    title: 'Add member note',
    section: 'members',
    summary: 'Appends a general or restricted note to the member record.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'visibility', label: 'Visibility', options: () => [
        { value: 'general', label: 'General' },
        { value: 'restricted', label: 'Restricted (supervisor visibility)' },
      ] },
      { input: 'textarea', key: 'text', label: 'Note text', max: 4000 },
    ],
    build(fx) {
      const id = memberId(fx);
      const visibility = fx.pick('visibility', 'Visibility', [
        { value: 'general', label: 'General' },
        { value: 'restricted', label: 'Restricted' },
      ]);
      const text = fx.text('text', 'Note text', { max: 4000 });
      if ([id, visibility, text].some((v) => v === undefined)) return undefined;
      return { memberId: id, visibility, text };
    },
  },
  {
    kind: 'account.open',
    title: 'Open account',
    section: 'accounts',
    summary: 'Opens a deposit product account for the member with a nickname and statement delivery.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'productId', label: 'Product', options: (fx) => pickers.products(fx.ctx, 'deposit') },
      { input: 'text', key: 'nickname', label: 'Nickname', max: 80 },
      { input: 'select', key: 'statementDelivery', label: 'Statement delivery', options: () => [
        { value: 'electronic', label: 'Electronic' },
        { value: 'paper', label: 'Paper' },
      ] },
    ],
    build(fx) {
      const id = memberId(fx);
      const productId = fx.pick('productId', 'Product', pickers.products(fx.ctx, 'deposit'));
      const nickname = fx.text('nickname', 'Nickname', { max: 80 });
      const statementDelivery = fx.pick('statementDelivery', 'Statement delivery', [
        { value: 'electronic', label: 'Electronic' },
        { value: 'paper', label: 'Paper' },
      ]);
      if ([id, productId, nickname, statementDelivery].some((v) => v === undefined)) return undefined;
      return { memberId: id, productId, nickname, statementDelivery };
    },
  },
  {
    kind: 'account.nickname.update',
    title: 'Update account nickname',
    section: 'accounts',
    summary: 'Renames the account; binds the reviewed record version.',
    subjects: [SUBJECT.account],
    fields: [{ input: 'text', key: 'nickname', label: 'Nickname', max: 80 }],
    build(fx) {
      const id = accountId(fx);
      const expectedVersion = accountVersion(fx);
      const nickname = fx.text('nickname', 'Nickname', { max: 80 });
      if ([id, expectedVersion, nickname].some((v) => v === undefined)) return undefined;
      return { accountId: id, expectedVersion, nickname };
    },
  },
  {
    kind: 'account.statement_delivery.update',
    title: 'Update statement delivery',
    section: 'accounts',
    summary: 'Switches the account between paper and electronic statements.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'select', key: 'statementDelivery', label: 'Statement delivery', options: () => [
        { value: 'electronic', label: 'Electronic' },
        { value: 'paper', label: 'Paper' },
      ] },
    ],
    build(fx) {
      const id = accountId(fx);
      const expectedVersion = accountVersion(fx);
      const statementDelivery = fx.pick('statementDelivery', 'Statement delivery', [
        { value: 'electronic', label: 'Electronic' },
        { value: 'paper', label: 'Paper' },
      ]);
      if ([id, expectedVersion, statementDelivery].some((v) => v === undefined)) return undefined;
      return { accountId: id, expectedVersion, statementDelivery };
    },
  },
  {
    kind: 'account.close',
    title: 'Close account',
    section: 'accounts',
    summary: 'Closes the account when eligibility allows; closure refusal returns the blocking reasons.',
    subjects: [SUBJECT.account],
    fields: [{ input: 'text', key: 'reason', label: 'Closure reason', max: 300 }],
    build(fx) {
      const id = accountId(fx);
      const expectedVersion = accountVersion(fx);
      const reason = fx.text('reason', 'Closure reason', { max: 300 });
      if ([id, expectedVersion, reason].some((v) => v === undefined)) return undefined;
      return { accountId: id, expectedVersion, reason };
    },
  },
  {
    kind: 'cash.deposit',
    title: 'Deposit cash',
    section: 'money',
    summary: 'Posts a cash deposit journal against the account at its currency exponent.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'description', label: 'Description', max: 200 },
    ],
    build(fx) {
      const id = accountId(fx);
      const expectedVersion = accountVersion(fx);
      const currency = accountCurrency(fx);
      const amount = currency === undefined ? undefined : fx.money('amount', 'Amount', currency);
      const description = fx.text('description', 'Description', { max: 200 });
      if ([id, expectedVersion, amount, description].some((v) => v === undefined)) return undefined;
      return { accountId: id, expectedVersion, amount, description };
    },
  },
  {
    kind: 'cash.withdraw',
    title: 'Withdraw cash',
    section: 'money',
    summary: 'Posts a cash withdrawal journal; refused when funds or eligibility are insufficient.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'description', label: 'Description', max: 200 },
    ],
    build(fx) {
      const id = accountId(fx);
      const expectedVersion = accountVersion(fx);
      const currency = accountCurrency(fx);
      const amount = currency === undefined ? undefined : fx.money('amount', 'Amount', currency);
      const description = fx.text('description', 'Description', { max: 200 });
      if ([id, expectedVersion, amount, description].some((v) => v === undefined)) return undefined;
      return { accountId: id, expectedVersion, amount, description };
    },
  },
  {
    kind: 'transfer.internal',
    title: 'Internal transfer',
    section: 'money',
    summary: 'Moves money between two accounts at this institution with both versions bound.',
    subjects: [SUBJECT.account],
    fields: [
      { input: 'subject', key: 'destination', kind: 'account', label: 'Destination account', help: 'Account number or record id.' },
      { input: 'money', key: 'amount', label: 'Amount', currency: (fx) => accountCurrency(fx) },
      { input: 'text', key: 'description', label: 'Description', max: 200 },
    ],
    build(fx) {
      const source = fx.subject('account', 'account', 'Source account');
      const destination = fx.subject('destination', 'account', 'Destination account');
      const currency = source?.record === undefined ? undefined : cell(source.record.currency ?? '');
      const amount = currency === undefined ? undefined : fx.money('amount', 'Amount', currency);
      const description = fx.text('description', 'Description', { max: 200 });
      if ([source, destination, amount, description].some((v) => v === undefined)) return undefined;
      if (source?.id === destination?.id) {
        fx.fail('destination', 'Source and destination accounts must differ.');
        return undefined;
      }
      return {
        sourceAccountId: source?.id,
        destinationAccountId: destination?.id,
        expectedSourceVersion: source?.version,
        expectedDestinationVersion: destination?.version,
        amount,
        description,
      };
    },
  },
  {
    kind: 'case.open',
    title: 'Open case',
    section: 'cases',
    summary: 'Opens a servicing case for the member, optionally tied to an account and queue assignee.',
    subjects: [SUBJECT.member],
    fields: [
      { input: 'select', key: 'accountId', label: 'Account', required: false, blank: '(no account)', options: (fx) => {
        const member = fx.subject('member', 'member', 'Member');
        return member === undefined ? [] : pickers.memberAccounts(fx.ctx, member.id);
      } },
      { input: 'select', key: 'queueId', label: 'Queue', options: (fx) => pickers.queues(fx.ctx) },
      { input: 'select', key: 'assignedActorId', label: 'Assignee', required: false, blank: '(unassigned)', options: (fx) => pickers.caseWorkers(fx.ctx) },
      { input: 'select', key: 'category', label: 'Category', options: (fx) => pickers.caseCategories(fx.ctx) },
      { input: 'select', key: 'priority', label: 'Priority', options: () => [
        { value: 'low', label: 'Low' },
        { value: 'normal', label: 'Normal' },
        { value: 'high', label: 'High' },
        { value: 'urgent', label: 'Urgent' },
      ] },
      { input: 'text', key: 'summary', label: 'Summary', max: 200 },
      { input: 'date', key: 'dueDate', label: 'Due date' },
    ],
    build(fx) {
      const member = memberId(fx);
      const accountIdValue = fx.pick('accountId', 'Account', pickers.memberAccounts(fx.ctx, member ?? ''), false) ?? null;
      const queueId = fx.pick('queueId', 'Queue', pickers.queues(fx.ctx));
      const assignedActorId = fx.pick('assignedActorId', 'Assignee', pickers.caseWorkers(fx.ctx), false) ?? null;
      const category = fx.pick('category', 'Category', pickers.caseCategories(fx.ctx));
      const priority = fx.pick('priority', 'Priority', [
        { value: 'low', label: 'Low' },
        { value: 'normal', label: 'Normal' },
        { value: 'high', label: 'High' },
        { value: 'urgent', label: 'Urgent' },
      ]);
      const summary = fx.text('summary', 'Summary', { max: 200 });
      const dueDate = fx.date('dueDate', 'Due date');
      if ([member, queueId, category, priority, summary, dueDate].some((v) => v === undefined)) return undefined;
      return { memberId: member, accountId: accountIdValue, queueId, assignedActorId, category, priority, summary, dueDate };
    },
  },
  {
    kind: 'case.assign',
    title: 'Assign case',
    section: 'cases',
    summary: 'Re-queues or re-assigns the case with a recorded reason.',
    subjects: [SUBJECT.case],
    fields: [
      { input: 'select', key: 'queueId', label: 'Queue', options: (fx) => pickers.queues(fx.ctx) },
      { input: 'select', key: 'assignedActorId', label: 'Assignee', required: false, blank: '(unassigned)', options: (fx) => pickers.caseWorkers(fx.ctx) },
      { input: 'text', key: 'reason', label: 'Reason', max: 300 },
    ],
    build(fx) {
      const id = caseId(fx);
      const expectedVersion = caseVersion(fx);
      const queueId = fx.pick('queueId', 'Queue', pickers.queues(fx.ctx));
      const assignedActorId = fx.pick('assignedActorId', 'Assignee', pickers.caseWorkers(fx.ctx), false) ?? null;
      const reason = fx.text('reason', 'Reason', { max: 300 });
      if ([id, expectedVersion, queueId, reason].some((v) => v === undefined)) return undefined;
      return { caseId: id, expectedVersion, queueId, assignedActorId, reason };
    },
  },
  {
    kind: 'case.transition',
    title: 'Transition case',
    section: 'cases',
    summary: 'Moves the case along its allowed state machine path with a reason.',
    subjects: [SUBJECT.case],
    fields: [
      { input: 'select', key: 'toState', label: 'New state', options: (fx) => {
        const state = fx.subject('case', 'case', 'Case')?.record?.state;
        const allowed = typeof state === 'string' && Object.hasOwn(CASE_TRANSITIONS, state) ? CASE_TRANSITIONS[state as CaseState] : [];
        return [...allowed].map((value) => ({ value, label: value }));
      } },
      { input: 'text', key: 'reason', label: 'Reason', max: 300 },
    ],
    build(fx) {
      const id = caseId(fx);
      const expectedVersion = caseVersion(fx);
      const state = fx.subject('case', 'case', 'Case')?.record?.state;
      const allowed = typeof state === 'string' && Object.hasOwn(CASE_TRANSITIONS, state) ? CASE_TRANSITIONS[state as CaseState] : [];
      const toState = fx.pick('toState', 'New state', [...allowed].map((value) => ({ value, label: value })));
      const reason = fx.text('reason', 'Reason', { max: 300 });
      if ([id, expectedVersion, toState, reason].some((v) => v === undefined)) return undefined;
      return { caseId: id, expectedVersion, toState, reason };
    },
  },
  {
    kind: 'case.note.add',
    title: 'Add case note',
    section: 'cases',
    summary: 'Appends a note to the case, optionally bound to document evidence versions.',
    subjects: [SUBJECT.case],
    fields: [
      { input: 'select', key: 'visibility', label: 'Visibility', options: () => [
        { value: 'general', label: 'General' },
        { value: 'restricted', label: 'Restricted' },
      ] },
      { input: 'textarea', key: 'text', label: 'Note text', max: 4000 },
      { input: 'lines', key: 'evidenceVersionIds', label: 'Evidence version ids', required: false, help: 'One document version id per line.' },
    ],
    build(fx) {
      const id = caseId(fx);
      const visibility = fx.pick('visibility', 'Visibility', [
        { value: 'general', label: 'General' },
        { value: 'restricted', label: 'Restricted' },
      ]);
      const text = fx.text('text', 'Note text', { max: 4000 });
      const evidenceVersionIds = fx.lines('evidenceVersionIds', 'Evidence version ids', false);
      if ([id, visibility, text, evidenceVersionIds].some((v) => v === undefined)) return undefined;
      const command: Record<string, unknown> = { caseId: id, visibility, text };
      if ((evidenceVersionIds ?? []).length > 0) command.evidenceVersionIds = evidenceVersionIds;
      return command;
    },
  },
  {
    kind: 'search.saved.create',
    title: 'Create saved search',
    section: 'searches',
    summary: 'Stores a named member/account/case search definition for this operator or all operators.',
    subjects: [],
    fields: [
      { input: 'text', key: 'name', label: 'Name', max: 80 },
      { input: 'select', key: 'visibility', label: 'Visibility', options: () => [
        { value: 'private', label: 'Private' },
        { value: 'shared', label: 'Shared' },
      ] },
      { input: 'textarea', key: 'definition', label: 'Search definition (JSON)', max: 8000, help: 'A SavedSearchDefinition: {"entity":"members","filters":{...},"sort":[{"field":"memberNumber","direction":"asc"}],"columns":[...]}.' },
    ],
    build(fx) {
      const name = fx.text('name', 'Name', { max: 80 });
      const visibility = fx.pick('visibility', 'Visibility', [
        { value: 'private', label: 'Private' },
        { value: 'shared', label: 'Shared' },
      ]);
      const definition = savedSearchDefinition(fx);
      if ([name, visibility, definition].some((v) => v === undefined)) return undefined;
      return { name, visibility, definition };
    },
  },
  {
    kind: 'search.saved.update',
    title: 'Update saved search',
    section: 'searches',
    summary: 'Renames, re-shares, or redefines a saved search; binds its stored revision.',
    subjects: [],
    fields: [
      { input: 'select', key: 'searchId', label: 'Saved search', options: (fx) =>
        fx.ctx.read((db) => db.prepare('SELECT id,name,visibility FROM saved_searches WHERE dataset_id=? ORDER BY name').all(fx.ctx.binding.datasetId) as Record<string, unknown>[])
          .map((r) => ({ value: String(r.id), label: `${String(r.name)} (${String(r.visibility)})` })) },
      { input: 'text', key: 'name', label: 'Name', required: false, max: 80 },
      { input: 'select', key: 'visibility', label: 'Visibility', required: false, blank: '(unchanged)', options: () => [
        { value: 'private', label: 'Private' },
        { value: 'shared', label: 'Shared' },
      ] },
      { input: 'textarea', key: 'definition', label: 'Search definition (JSON)', required: false, max: 8000 },
    ],
    build(fx) {
      const searches = fx.ctx.read((db) => db.prepare('SELECT id,name,visibility FROM saved_searches WHERE dataset_id=? ORDER BY name').all(fx.ctx.binding.datasetId) as Record<string, unknown>[]);
      const searchId = fx.pick('searchId', 'Saved search', searches.map((r) => ({ value: String(r.id), label: String(r.name) })));
      const stored = searchId === undefined ? undefined : row(fx.ctx, 'SELECT name,visibility,definition_json FROM saved_searches WHERE dataset_id=? AND id=?', fx.ctx.binding.datasetId, searchId);
      if (stored === undefined) {
        if (searchId !== undefined) fx.fail('searchId', 'The saved search no longer exists.');
        return undefined;
      }
      const expectedRevision = savedSearchRevision({ name: String(stored.name), visibility: String(stored.visibility), definitionJson: String(stored.definition_json) });
      const name = fx.opt('name', 'Name', { max: 80 });
      const visibility = fx.pick('visibility', 'Visibility', [
        { value: 'private', label: 'Private' },
        { value: 'shared', label: 'Shared' },
      ], false);
      const rawDefinition = (fx.fields.definition ?? '').trim();
      const definition = rawDefinition === '' ? undefined : savedSearchDefinition(fx);
      if (rawDefinition !== '' && definition === undefined) return undefined;
      if (name === undefined) return undefined;
      const command: Record<string, unknown> = { searchId, expectedRevision };
      if (name !== null) command.name = name;
      if (visibility !== undefined) command.visibility = visibility;
      if (definition !== undefined) command.definition = definition;
      if (command.name === undefined && command.visibility === undefined && command.definition === undefined) {
        fx.fail(null, 'Change at least one of name, visibility, or definition.');
        return undefined;
      }
      return command;
    },
  },
  {
    kind: 'search.saved.delete',
    title: 'Delete saved search',
    section: 'searches',
    summary: 'Removes a saved search; binds its stored revision.',
    subjects: [],
    fields: [
      { input: 'select', key: 'searchId', label: 'Saved search', options: (fx) =>
        fx.ctx.read((db) => db.prepare('SELECT id,name,visibility FROM saved_searches WHERE dataset_id=? ORDER BY name').all(fx.ctx.binding.datasetId) as Record<string, unknown>[])
          .map((r) => ({ value: String(r.id), label: `${String(r.name)} (${String(r.visibility)})` })) },
    ],
    build(fx) {
      const searchId = fx.pick('searchId', 'Saved search', fx.ctx.read((db) => db.prepare('SELECT id,name,visibility FROM saved_searches WHERE dataset_id=? ORDER BY name').all(fx.ctx.binding.datasetId) as Record<string, unknown>[]).map((r) => ({ value: String(r.id), label: String(r.name) })));
      if (searchId === undefined) return undefined;
      const stored = row(fx.ctx, 'SELECT name,visibility,definition_json FROM saved_searches WHERE dataset_id=? AND id=?', fx.ctx.binding.datasetId, searchId);
      if (stored === undefined) {
        fx.fail('searchId', 'The saved search no longer exists.');
        return undefined;
      }
      return { searchId, expectedRevision: savedSearchRevision({ name: String(stored.name), visibility: String(stored.visibility), definitionJson: String(stored.definition_json) }) };
    },
  },
];
