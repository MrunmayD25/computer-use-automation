import {
  listEffectivePolicyVersions,
  listMemberAddressDestinations,
  listMemberAddresses,
  listMemberCommunicationJobs,
  listMemberCommunicationPreferences,
  listMemberConsents,
  listMemberDocumentVersions,
  listMemberIdentityEvidence,
  listMemberMaintenanceRequests,
  listMemberRetentionHolds,
  listServicingQueues,
  operatorProfile,
  readFinanceRecord,
  referenceData,
  type FinanceRecordKind,
  type FinanceRecordSnapshot,
  type SqlDatabase,
} from '@computer-use/financial-database/services';

import type { PageContext } from '../runtime.js';

export interface Choice {
  readonly value: string;
  readonly label: string;
}

/** One resolved business record: identity for commands, plus version/fingerprint for stale binding. */
export interface Subject {
  readonly id: string;
  readonly label: string;
  readonly version?: number;
  readonly fingerprint?: string;
  readonly record?: Record<string, unknown>;
}

export type SubjectResult = { readonly kind: 'found'; readonly subject: Subject } | { readonly kind: 'missing' } | { readonly kind: 'error'; readonly message: string };

const found = (subject: Subject): SubjectResult => ({ kind: 'found', subject });
const missing = (): SubjectResult => ({ kind: 'missing' });
const failed = (message: string): SubjectResult => ({ kind: 'error', message });

type Row = Record<string, unknown>;

function one(database: SqlDatabase, sql: string, ...parameters: (string | number)[]): Row | undefined {
  const row = database.prepare(sql).get(...parameters);
  return row === undefined ? undefined : row;
}

function all(database: SqlDatabase, sql: string, ...parameters: (string | number)[]): Row[] {
  return database.prepare(sql).all(...parameters);
}

/** Narrows a raw cell to text; non-string cells render as empty rather than "[object Object]". */
export const cell = (value: unknown): string => (typeof value === 'string' ? value : typeof value === 'number' ? String(value) : '');

const text = (row: Row | undefined | null, key: string): string => cell(row?.[key]);
const num = (row: Row, key: string): number => Number(row[key] ?? 0);

/** Bounded read of arbitrary dataset rows; used only for lookups, never business decisions. */
export function rows(ctx: PageContext, sql: string, ...parameters: (string | number)[]): Row[] {
  return ctx.read((database) => all(database, sql, ...parameters));
}

export function row(ctx: PageContext, sql: string, ...parameters: (string | number)[]): Row | undefined {
  return ctx.read((database) => one(database, sql, ...parameters));
}

export function memberSubject(ctx: PageContext, reference: string): SubjectResult {
  const found_ = row(
    ctx,
    `SELECT m.id,m.member_number,m.version,m.status,m.party_id,p.display_name,p.kind
     FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
     WHERE m.dataset_id=? AND (m.member_number=? OR m.id=?)`,
    ctx.binding.datasetId,
    reference,
    reference,
  );
  if (found_ === undefined) return missing();
  return found({
    id: text(found_, 'id'),
    label: `${text(found_, 'member_number')} ${text(found_, 'display_name')}`,
    version: num(found_, 'version'),
    record: found_,
  });
}

export function accountSubject(ctx: PageContext, reference: string): SubjectResult {
  const found_ = row(
    ctx,
    `SELECT a.id,a.account_number,a.member_id,a.version,a.status,a.currency,a.nickname,b.posted_balance_minor_units,b.available_balance_minor_units,m.member_number
     FROM accounts a JOIN members m ON m.dataset_id=a.dataset_id AND m.id=a.member_id
     JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
     WHERE a.dataset_id=? AND (a.account_number=? OR a.id=?)`,
    ctx.binding.datasetId,
    reference,
    reference,
  );
  if (found_ === undefined) return missing();
  return found({
    id: text(found_, 'id'),
    label: `${text(found_, 'account_number')} · ${text(found_, 'nickname')}`,
    version: num(found_, 'version'),
    record: found_,
  });
}

export function caseSubject(ctx: PageContext, reference: string): SubjectResult {
  const found_ = row(
    ctx,
    `SELECT id,case_number,version,state,member_id,account_id FROM cases WHERE dataset_id=? AND (case_number=? OR id=?)`,
    ctx.binding.datasetId,
    reference,
    reference,
  );
  if (found_ === undefined) return missing();
  return found({ id: text(found_, 'id'), label: `Case ${text(found_, 'case_number')}`, version: num(found_, 'version'), record: found_ });
}

export function requestSubject(ctx: PageContext, reference: string): SubjectResult {
  const found_ = row(
    ctx,
    `SELECT id,request_number,state,updated_at,member_id,account_id FROM maintenance_requests WHERE dataset_id=? AND (request_number=? OR id=?)`,
    ctx.binding.datasetId,
    reference,
    reference,
  );
  if (found_ === undefined) return missing();
  return found({ id: text(found_, 'id'), label: `Request ${text(found_, 'request_number')}`, record: found_ });
}

/** Business-number columns for finance records that carry one; others resolve by id only. */
const FINANCE_KEYS: Partial<Record<FinanceRecordKind, { table: string; column: string }>> = {
  payment: { table: 'payments', column: 'reference' },
  dispute: { table: 'disputes', column: 'case_number' },
  'settlement-batch': { table: 'settlement_batches', column: 'reference' },
  'received-funds': { table: 'received_funds', column: 'reference' },
  batch: { table: 'batches', column: 'batch_number' },
  journal: { table: 'journals', column: 'reference' },
  transaction: { table: 'journals', column: 'reference' },
  transfer: { table: 'journals', column: 'reference' },
  card: { table: 'cards', column: 'token' },
};

export function financeSubject(ctx: PageContext, kind: FinanceRecordKind, reference: string): SubjectResult {
  const key = FINANCE_KEYS[kind];
  let id = reference;
  if (key !== undefined && !reference.startsWith('id-')) {
    const found_ = row(ctx, `SELECT id FROM ${key.table} WHERE dataset_id=? AND ${key.column}=?`, ctx.binding.datasetId, reference);
    if (found_ !== undefined) id = text(found_, 'id');
  }
  const outcome = readFinanceRecord(ctx.services.store, ctx.context(), kind, id);
  if (outcome.kind === 'rejected') {
    return outcome.code === 'not_found' ? missing() : failed(outcome.message);
  }
  if (outcome.kind !== 'found') return failed('The record could not be read.');
  const snapshot: FinanceRecordSnapshot = outcome.snapshot;
  const label = cell(snapshot.record.reference ?? snapshot.record.case_number ?? snapshot.record.batch_number ?? snapshot.record.last_four ?? snapshot.id);
  return found({ id: snapshot.id, label: `${kind} ${label}`, fingerprint: snapshot.fingerprint, record: snapshot.record });
}

export function mergePlanSubject(ctx: PageContext, reference: string): SubjectResult {
  const found_ = row(
    ctx,
    `SELECT id,state,source_member_id,target_member_id FROM member_merge_plans WHERE dataset_id=? AND id=?`,
    ctx.binding.datasetId,
    reference,
  );
  if (found_ === undefined) return missing();
  return found({ id: text(found_, 'id'), label: `Merge plan ${text(found_, 'id')} (${text(found_, 'state')})`, record: found_ });
}

export function approvalSubject(ctx: PageContext, reference: string): SubjectResult {
  const found_ = row(
    ctx,
    `SELECT id,status,maker_actor_id,checker_actor_id FROM business_approvals WHERE dataset_id=? AND id=?`,
    ctx.binding.datasetId,
    reference,
  );
  if (found_ === undefined) return missing();
  return found({ id: text(found_, 'id'), label: `Approval ${text(found_, 'id')} (${text(found_, 'status')})`, record: found_ });
}

/* ---------- pickers: option sources for dropdown fields ---------- */

function unwrap<T>(outcome: { kind: 'authorized'; value: T } | { kind: 'rejected' }): T | undefined {
  return outcome.kind === 'authorized' ? outcome.value : undefined;
}

export const pickers = {
  currencies(ctx: PageContext): Choice[] {
    return rows(ctx, 'SELECT code,exponent,name FROM currencies ORDER BY code').map((r) => ({
      value: text(r, 'code'),
      label: `${text(r, 'code')} — ${text(r, 'name')}`,
    }));
  },
  currencyExponent(ctx: PageContext, code: string): number {
    return num(row(ctx, 'SELECT exponent FROM currencies WHERE code=?', code) ?? { exponent: 2 }, 'exponent');
  },
  products(ctx: PageContext, family?: 'deposit' | 'loan' | 'card'): Choice[] {
    return rows(
      ctx,
      `SELECT id,code,name,currency FROM products WHERE dataset_id=? AND status='active'${family === undefined ? '' : ' AND family=?'} ORDER BY code`,
      ctx.binding.datasetId,
      ...(family === undefined ? [] : [family]),
    ).map((r) => ({ value: text(r, 'id'), label: `${text(r, 'code')} — ${text(r, 'name')} (${text(r, 'currency')})` }));
  },
  queues(ctx: PageContext): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listServicingQueues(db, context)));
    return (list ?? []).map((q) => ({ value: q.id, label: `${q.code} — ${q.name}` }));
  },
  caseWorkers(ctx: PageContext): Choice[] {
    return rows(
      ctx,
      `SELECT id,actor_number,display_name FROM actors WHERE dataset_id=? AND status='active' ORDER BY actor_number`,
      ctx.binding.datasetId,
    ).map((r) => ({ value: text(r, 'id'), label: `${text(r, 'actor_number')} ${text(r, 'display_name')}` }));
  },
  caseCategories(ctx: PageContext): Choice[] {
    return ctx.read((db) => referenceData(db, ctx.binding.datasetId, ctx.binding.institutionId)).caseCategories
      .map((c) => ({ value: c.code, label: c.label }));
  },
  memberAccounts(ctx: PageContext, memberId: string): Choice[] {
    return rows(
      ctx,
      `SELECT a.id,a.account_number,a.nickname,a.status,a.currency,b.posted_balance_minor_units
       FROM accounts a JOIN account_balances b ON b.dataset_id=a.dataset_id AND b.account_id=a.id
       WHERE a.dataset_id=? AND a.member_id=? ORDER BY a.account_number`,
      ctx.binding.datasetId,
      memberId,
    ).map((r) => ({ value: text(r, 'id'), label: `${text(r, 'account_number')} ${text(r, 'nickname')} (${text(r, 'status')})` }));
  },
  accountHolds(ctx: PageContext, accountId: string): Choice[] {
    return rows(ctx, `SELECT id,amount_minor_units,reason FROM holds WHERE dataset_id=? AND account_id=? AND status='active' ORDER BY placed_at`, ctx.binding.datasetId, accountId)
      .map((r) => ({ value: text(r, 'id'), label: `Hold ${text(r, 'id').slice(-8)} — ${text(r, 'reason')}`.slice(0, 80) }));
  },
  accountRestrictions(ctx: PageContext, accountId: string): Choice[] {
    return rows(ctx, `SELECT id,kind FROM restrictions WHERE dataset_id=? AND account_id=? AND status='active' ORDER BY placed_at`, ctx.binding.datasetId, accountId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'kind')} (${text(r, 'id').slice(-8)})` }));
  },
  accountFacilities(ctx: PageContext, accountId: string): Choice[] {
    return rows(ctx, `SELECT id,kind FROM facilities WHERE dataset_id=? AND account_id=? ORDER BY id`, ctx.binding.datasetId, accountId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'kind')} ${text(r, 'id').slice(-8)}` }));
  },
  accountCards(ctx: PageContext, accountId: string): Choice[] {
    return rows(ctx, `SELECT id,last_four,status FROM cards WHERE dataset_id=? AND account_id=? ORDER BY id`, ctx.binding.datasetId, accountId)
      .map((r) => ({ value: text(r, 'id'), label: `•••• ${text(r, 'last_four')} (${text(r, 'status')})` }));
  },
  accountLoans(ctx: PageContext, accountId?: string): Choice[] {
    return accountId === undefined
      ? rows(ctx, `SELECT id,account_id,state FROM loans WHERE dataset_id=? ORDER BY opened_at`, ctx.binding.datasetId).map((r) => ({ value: text(r, 'id'), label: `Loan ${text(r, 'id').slice(-8)} (${text(r, 'state')})` }))
      : rows(ctx, `SELECT id,state FROM loans WHERE dataset_id=? AND account_id=? ORDER BY opened_at`, ctx.binding.datasetId, accountId).map((r) => ({ value: text(r, 'id'), label: `Loan ${text(r, 'id').slice(-8)} (${text(r, 'state')})` }));
  },
  accountFees(ctx: PageContext, accountId: string): Choice[] {
    return rows(ctx, `SELECT id,original_amount_minor_units,currency,status FROM fees WHERE dataset_id=? AND account_id=? ORDER BY id`, ctx.binding.datasetId, accountId)
      .map((r) => ({ value: text(r, 'id'), label: `Fee ${text(r, 'id').slice(-8)} ${text(r, 'original_amount_minor_units')} ${text(r, 'currency')} (${text(r, 'status')})` }));
  },
  accountJournals(ctx: PageContext, accountId: string): Choice[] {
    return rows(
      ctx,
      `SELECT DISTINCT j.id,j.reference,j.description,j.status FROM journals j
       JOIN journal_lines l ON l.dataset_id=j.dataset_id AND l.journal_id=j.id
       JOIN ledger_accounts la ON la.dataset_id=l.dataset_id AND la.id=l.ledger_account_id
       WHERE j.dataset_id=? AND la.customer_account_id=? ORDER BY j.posted_at DESC LIMIT 200`,
      ctx.binding.datasetId,
      accountId,
    ).map((r) => ({ value: text(r, 'id'), label: `${text(r, 'reference')} — ${text(r, 'description')}`.slice(0, 90) }));
  },
  memberEvidence(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberIdentityEvidence(db, context, memberId)));
    return (list ?? []).map((e) => ({ value: e.id, label: `${e.kind} ${e.status} — ${e.sourceReference}`.slice(0, 90) }));
  },
  memberDocumentVersions(ctx: PageContext, memberId: string, documentType?: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberDocumentVersions(db, context, memberId, documentType)));
    return (list ?? []).map((d) => ({ value: d.versionId, label: `${d.displayName} v${d.version} (${d.status}, ${d.mediaType})`.slice(0, 90) }));
  },
  memberConsents(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberConsents(db, context, memberId)));
    return (list ?? []).map((c) => ({ value: c.id, label: `${c.purpose}/${c.channel} (${c.state})` }));
  },
  memberAddresses(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberAddresses(db, context, memberId)));
    return (list ?? []).map((a) => ({ value: a.partyAddressId, label: `${a.purpose}: ${a.line1}, ${a.city} (${a.evidenceStatus})`.slice(0, 90) }));
  },
  memberAddressRows(ctx: PageContext, memberId: string) {
    return unwrap(ctx.svc((db, context) => listMemberAddresses(db, context, memberId))) ?? [];
  },
  memberDestinations(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberAddressDestinations(db, context, memberId)));
    return (list ?? []).map((d) => ({ value: d.id, label: `${d.context}: ${d.address.line1}, ${d.address.city} (${d.effectiveAt.slice(0, 10)})` }));
  },
  memberPreferences(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberCommunicationPreferences(db, context, memberId)));
    return (list ?? []).map((p) => ({ value: p.id, label: `${p.purpose}/${p.channel} (${p.state})` }));
  },
  memberJobs(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberCommunicationJobs(db, context, memberId)));
    return (list ?? []).map((j) => ({ value: j.id, label: `${j.channel} → ${j.destination} (${j.state})`.slice(0, 90) }));
  },
  memberRetentionHolds(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberRetentionHolds(db, context, memberId)));
    return (list ?? []).map((h) => ({ value: h.id, label: `${h.reason} (${h.state})`.slice(0, 90) }));
  },
  memberRequests(ctx: PageContext, memberId: string): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listMemberMaintenanceRequests(db, context, memberId)));
    return (list ?? []).map((r) => ({ value: r.id, label: `${r.requestNumber} ${r.subject} (${r.state})`.slice(0, 90) }));
  },
  policies(ctx: PageContext): Choice[] {
    const list = unwrap(ctx.svc((db, context) => listEffectivePolicyVersions(db, context)));
    return (list ?? []).map((p) => ({ value: p.id, label: `${p.name} v${p.version}` }));
  },
  checkers(ctx: PageContext, grants: readonly string[]): Choice[] {
    // Actors holding any required grant, excluding the signed-on operator (maker/checker separation).
    return rows(ctx, `SELECT id,actor_number,display_name FROM actors WHERE dataset_id=? AND status='active' AND id<>? ORDER BY actor_number`, ctx.binding.datasetId, ctx.actor.actorId)
      .filter((r) => {
        const profile = ctx.read((db) => operatorProfile(db, ctx.binding.datasetId, ctx.binding.institutionId, text(r, 'actor_number')));
        return profile !== undefined && grants.some((grant) => profile.permissions.includes(grant));
      })
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'actor_number')} ${text(r, 'display_name')}` }));
  },
  mergePlans(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,state FROM member_merge_plans WHERE dataset_id=? ORDER BY id`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'id')} (${text(r, 'state')})` }));
  },
  beneficiaries(ctx: PageContext, memberId: string): Choice[] {
    const party = row(ctx, `SELECT party_id FROM members WHERE dataset_id=? AND id=?`, ctx.binding.datasetId, memberId);
    if (party === undefined) return [];
    return rows(ctx, `SELECT id,display_name,status FROM beneficiaries WHERE dataset_id=? AND owner_party_id=? ORDER BY display_name`, ctx.binding.datasetId, text(party, 'party_id'))
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'display_name')} (${text(r, 'status')})` }));
  },
  beneficiaryRoutes(ctx: PageContext, beneficiaryId: string): Choice[] {
    return rows(ctx, `SELECT id,version,routing_kind,masked_destination,status FROM beneficiary_routes WHERE dataset_id=? AND beneficiary_id=? ORDER BY version DESC`, ctx.binding.datasetId, beneficiaryId)
      .map((r) => ({ value: text(r, 'id'), label: `v${text(r, 'version')} ${text(r, 'routing_kind')} ${text(r, 'masked_destination')} (${text(r, 'status')})` }));
  },
  payments(ctx: PageContext, accountId?: string): Choice[] {
    const sql = accountId === undefined
      ? `SELECT id,reference,state,amount_minor_units,currency FROM payments WHERE dataset_id=? ORDER BY requested_date DESC LIMIT 200`
      : `SELECT id,reference,state,amount_minor_units,currency FROM payments WHERE dataset_id=? AND source_account_id=? ORDER BY requested_date DESC LIMIT 200`;
    return rows(ctx, sql, ctx.binding.datasetId, ...(accountId === undefined ? [] : [accountId]))
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'reference')} ${text(r, 'amount_minor_units')} ${text(r, 'currency')} (${text(r, 'state')})` }));
  },
  paymentSchedules(ctx: PageContext, accountId?: string): Choice[] {
    const sql = accountId === undefined
      ? `SELECT id,state,start_date FROM payment_schedules WHERE dataset_id=? ORDER BY start_date LIMIT 200`
      : `SELECT id,state,start_date FROM payment_schedules WHERE dataset_id=? AND source_account_id=? ORDER BY start_date LIMIT 200`;
    return rows(ctx, sql, ctx.binding.datasetId, ...(accountId === undefined ? [] : [accountId]))
      .map((r) => ({ value: text(r, 'id'), label: `Schedule ${text(r, 'id').slice(-8)} from ${text(r, 'start_date')} (${text(r, 'state')})` }));
  },
  scheduleOccurrences(ctx: PageContext, scheduleId: string): Choice[] {
    return rows(ctx, `SELECT id,local_date,state FROM schedule_occurrences WHERE dataset_id=? AND schedule_id=? ORDER BY local_date LIMIT 300`, ctx.binding.datasetId, scheduleId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'local_date')} (${text(r, 'state')})` }));
  },
  paymentReturns(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT r.id,r.return_code,r.amount_minor_units,p.reference FROM payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id WHERE r.dataset_id=? ORDER BY r.occurred_at DESC LIMIT 200`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `Return ${text(r, 'return_code')} on ${text(r, 'reference')}` }));
  },
  cardTransactions(ctx: PageContext, cardId?: string): Choice[] {
    const sql = cardId === undefined
      ? `SELECT t.id,t.amount_minor_units,t.currency,t.state FROM card_transactions t WHERE t.dataset_id=? ORDER BY t.id LIMIT 200`
      : `SELECT t.id,t.amount_minor_units,t.currency,t.state FROM card_transactions t WHERE t.dataset_id=? AND t.card_id=? ORDER BY t.id LIMIT 200`;
    return rows(ctx, sql, ctx.binding.datasetId, ...(cardId === undefined ? [] : [cardId]))
      .map((r) => ({ value: text(r, 'id'), label: `Card txn ${text(r, 'id').slice(-8)} ${text(r, 'amount_minor_units')} ${text(r, 'currency')} (${text(r, 'state')})` }));
  },
  disputes(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,case_number,state FROM disputes WHERE dataset_id=? ORDER BY case_number`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'case_number')} (${text(r, 'state')})` }));
  },
  interestCalculations(ctx: PageContext, accountId: string): Choice[] {
    return rows(ctx, `SELECT id,period_start,period_end,state FROM interest_calculations WHERE dataset_id=? AND account_id=? ORDER BY period_start DESC LIMIT 200`, ctx.binding.datasetId, accountId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'period_start')}…${text(r, 'period_end')} (${text(r, 'state')})` }));
  },
  maturityInstructions(ctx: PageContext, accountId: string): Choice[] {
    return rows(ctx, `SELECT id,state,cutoff_at FROM maturity_instructions WHERE dataset_id=? AND account_id=? ORDER BY cutoff_at`, ctx.binding.datasetId, accountId)
      .map((r) => ({ value: text(r, 'id'), label: `Instruction ${text(r, 'id').slice(-8)} (${text(r, 'state')})` }));
  },
  suspenseItems(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,state,remaining_amount_minor_units,currency FROM suspense_items WHERE dataset_id=? ORDER BY id LIMIT 200`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `Suspense ${text(r, 'id').slice(-8)} ${text(r, 'remaining_amount_minor_units')} ${text(r, 'currency')} (${text(r, 'state')})` }));
  },
  batches(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,batch_number,kind,state FROM batches WHERE dataset_id=? ORDER BY created_at DESC LIMIT 200`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'batch_number')} ${text(r, 'kind')} (${text(r, 'state')})` }));
  },
  batchItems(ctx: PageContext, batchId: string): Choice[] {
    return rows(ctx, `SELECT id,ordinal,source_key,state FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal LIMIT 500`, ctx.binding.datasetId, batchId)
      .map((r) => ({ value: text(r, 'id'), label: `#${text(r, 'ordinal')} ${text(r, 'source_key')} (${text(r, 'state')})` }));
  },
  settlementBatches(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,reference,state,currency FROM settlement_batches WHERE dataset_id=? ORDER BY reference LIMIT 200`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'reference')} (${text(r, 'state')}, ${text(r, 'currency')})` }));
  },
  cashSessions(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,business_date,state FROM cash_sessions WHERE dataset_id=? ORDER BY business_date DESC LIMIT 200`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `Session ${text(r, 'id').slice(-8)} ${text(r, 'business_date')} (${text(r, 'state')})` }));
  },
  approvals(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,status FROM business_approvals WHERE dataset_id=? ORDER BY expires_at DESC LIMIT 200`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `Approval ${text(r, 'id')} (${text(r, 'status')})` }));
  },
  documents(ctx: PageContext, memberId?: string): Choice[] {
    const sql = memberId === undefined
      ? `SELECT d.id,d.display_name,d.document_type FROM documents d WHERE d.dataset_id=? ORDER BY d.display_name LIMIT 300`
      : `SELECT d.id,d.display_name,d.document_type FROM documents d JOIN members m ON m.dataset_id=d.dataset_id AND m.party_id=d.owner_party_id WHERE d.dataset_id=? AND m.id=? ORDER BY d.display_name LIMIT 300`;
    return rows(ctx, sql, ctx.binding.datasetId, ...(memberId === undefined ? [] : [memberId]))
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'display_name')} (${text(r, 'document_type')})` }));
  },
  memberPartyId(ctx: PageContext, memberId: string): string | undefined {
    const found_ = row(ctx, `SELECT party_id FROM members WHERE dataset_id=? AND id=?`, ctx.binding.datasetId, memberId);
    return found_ === undefined ? undefined : text(found_, 'party_id');
  },
  parties(ctx: PageContext): Choice[] {
    return rows(ctx, `SELECT id,display_name,kind FROM parties WHERE dataset_id=? ORDER BY display_name LIMIT 300`, ctx.binding.datasetId)
      .map((r) => ({ value: text(r, 'id'), label: `${text(r, 'display_name')} (${text(r, 'kind')})` }));
  },
};
