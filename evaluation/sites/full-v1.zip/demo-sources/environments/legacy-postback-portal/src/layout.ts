import { formatClock } from './format.js';
import { html, raw, type SafeHtml } from './html.js';
import type { PageName } from './page-names.js';
import type { ComparisonRow, ValidationMessage } from './validation.js';

export interface Link {
  readonly href: string;
  readonly label: string;
}

export interface Crumb {
  readonly label: string;
  readonly href: string | null;
}

type Section =
  | 'home' | 'members' | 'accounts' | 'transactions' | 'statements' | 'cases' | 'documents'
  | 'payments' | 'cards' | 'loans' | 'batches' | 'requests' | 'approvals' | 'searches'
  | 'activity' | 'operator';

const menu: readonly { section: Section; label: string; page: PageName }[] = [
  { section: 'home', label: 'Home', page: 'Default.aspx' },
  { section: 'members', label: 'Members', page: 'Members.aspx' },
  { section: 'accounts', label: 'Accounts', page: 'Accounts.aspx' },
  { section: 'transactions', label: 'Transactions', page: 'Transactions.aspx' },
  { section: 'statements', label: 'Statements', page: 'Statements.aspx' },
  { section: 'cases', label: 'Cases', page: 'Cases.aspx' },
  { section: 'documents', label: 'Documents', page: 'Documents.aspx' },
  { section: 'payments', label: 'Payments', page: 'Payments.aspx' },
  { section: 'cards', label: 'Cards & Disputes', page: 'Cards.aspx' },
  { section: 'loans', label: 'Loans', page: 'Loans.aspx' },
  { section: 'batches', label: 'Batches & Reconciliation', page: 'Batches.aspx' },
  { section: 'requests', label: 'Maintenance Requests', page: 'Requests.aspx' },
  { section: 'approvals', label: 'Approvals', page: 'Approvals.aspx' },
  { section: 'searches', label: 'Saved Searches', page: 'Searches.aspx' },
  { section: 'activity', label: 'Activity', page: 'Activity.aspx' },
  { section: 'operator', label: 'Operator', page: 'Operator.aspx' },
];

const sectionOf: Readonly<Record<PageName, Section>> = {
  'Default.aspx': 'home',
  'Members.aspx': 'members',
  'MemberNew.aspx': 'members',
  'MemberDetail.aspx': 'members',
  'Accounts.aspx': 'accounts',
  'AccountOpen.aspx': 'accounts',
  'AccountDetail.aspx': 'accounts',
  'Transactions.aspx': 'transactions',
  'Receipt.aspx': 'transactions',
  'Statements.aspx': 'statements',
  'Activity.aspx': 'activity',
  'Cases.aspx': 'cases',
  'CaseDetail.aspx': 'cases',
  'Documents.aspx': 'documents',
  'DocumentDetail.aspx': 'documents',
  'Payments.aspx': 'payments',
  'Cards.aspx': 'cards',
  'Loans.aspx': 'loans',
  'Batches.aspx': 'batches',
  'Requests.aspx': 'requests',
  'RequestEdit.aspx': 'requests',
  'RequestDetail.aspx': 'requests',
  'RequestPrint.aspx': 'requests',
  'Approvals.aspx': 'approvals',
  'Searches.aspx': 'searches',
  'Operator.aspx': 'operator',
  'Operation.aspx': 'operator',
  'Record.aspx': 'activity',
};

export const NOTICES: ReadonlyMap<string, string> = new Map([
  ['member-created', 'Member created.'],
  ['contact-updated', 'Contact information updated.'],
  ['note-added', 'Note added.'],
  ['account-opened', 'Account opened.'],
  ['account-updated', 'Account preferences updated.'],
  ['account-closed', 'Account closed.'],
  ['posted', 'Operation committed.'],
  ['request-created', 'Draft request saved.'],
  ['request-updated', 'Draft request updated.'],
  ['request-submitted', 'Request submitted.'],
  ['request-cancelled', 'Request cancelled.'],
  ['approval-requested', 'Approval requested.'],
  ['approval-decided', 'Approval decision recorded.'],
  ['operator-switched', 'Signed on as the selected operator.'],
]);

const doctype =
  '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

export interface DocumentChrome {
  readonly page: PageName;
  readonly title: string;
  readonly formAction: string;
  readonly token: string;
  readonly generator: string;
  readonly scrollY: string;
  readonly lastFocus: string;
  readonly breadcrumbs: readonly Crumb[];
  readonly quickSearch: SafeHtml | null;
  readonly notice: string | null;
  readonly errors: readonly ValidationMessage[];
  readonly comparison: readonly ComparisonRow[];
  readonly body: SafeHtml;
  readonly renderedAt: Date;
  readonly requestNumber: number;
  readonly layout: 'master' | 'print';
  /** Signed-on operator and institution shown in the banner. */
  readonly operatorLabel?: string;
  readonly institutionLabel?: string;
}

function footer(renderedAt: Date, requestNumber: number): SafeHtml {
  return html`<div id="footer">Rendered ${formatClock(renderedAt)} · Request ${requestNumber}</div>`;
}

function banner(operatorLabel: string, institutionLabel: string): SafeHtml {
  return html`<div id="banner"><span class="brand">${institutionLabel} · BranchNet Administration</span><span class="operator">${operatorLabel} · <a href="Operator.aspx" class="banner-link">Switch operator</a></span></div>`;
}

function validationSummary(errors: readonly ValidationMessage[]): SafeHtml {
  if (errors.length === 0) return html``;
  return html`<div id="ctl00_MainContent_vsSummary" class="validation-summary" role="alert"><span>Please correct the following:</span><ul>${errors.map(
    (error) =>
      html`<li>${error.message}${error.link === undefined ? '' : html` <a href="${error.link.href}">${error.link.label}</a>`}</li>`,
  )}</ul></div>`;
}

function comparisonTable(rows: readonly ComparisonRow[]): SafeHtml {
  if (rows.length === 0) return html``;
  return html`<div id="ctl00_MainContent_pnlCurrentValues" class="comparison"><span class="comparison-title">Current saved values</span><table class="details">${rows.map(
    (row) => html`<tr><th scope="row">${row.label}</th><td>${row.saved}</td></tr>`,
  )}</table></div>`;
}

function breadcrumbTrail(crumbs: readonly Crumb[]): SafeHtml {
  return html`<div id="breadcrumbs">${crumbs.map(
    (crumb, index) =>
      html`${index === 0 ? '' : html` <span class="sep">&gt;</span> `}${
        crumb.href === null ? html`<span class="current">${crumb.label}</span>` : html`<a href="${crumb.href}">${crumb.label}</a>`
      }`,
  )}</div>`;
}

export function renderDocumentHtml(chrome: DocumentChrome): string {
  const section = sectionOf[chrome.page];
  const stylesheet = chrome.layout === 'print' ? '/assets/print.css' : '/assets/portal.css';
  const navigation =
    chrome.layout === 'master'
      ? html`<div id="menubar"><ul id="menu">${menu.map(
          (item) =>
            html`<li><a href="${item.page}"${item.section === section ? html` class="selected"` : ''}>${item.label}</a></li>`,
        )}</ul>${chrome.quickSearch}</div>${breadcrumbTrail(chrome.breadcrumbs)}`
      : '';
  return html`${raw(doctype)}
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><meta charset="utf-8" /><title>${chrome.title} - BranchNet</title><link rel="stylesheet" href="${stylesheet}" /><script src="/assets/WebForms.js" defer="defer"></script></head>
<body class="${chrome.layout}">
<form method="post" action="${chrome.formAction}" id="aspnetForm">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="${chrome.lastFocus}" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="${chrome.token}" />
</div>
<div id="page">
${banner(chrome.operatorLabel ?? 'Operator workstation', chrome.institutionLabel ?? 'Northstar Mutual')}
${navigation}
<div id="content">
<h1>${chrome.title}</h1>
${chrome.notice === null ? '' : html`<div id="ctl00_MainContent_lblNotice" class="notice" role="status">${chrome.notice}</div>`}
${validationSummary(chrome.errors)}
${comparisonTable(chrome.comparison)}
${chrome.body}
</div>
${footer(chrome.renderedAt, chrome.requestNumber)}
</div>
<div class="aspNetHidden">
<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="${chrome.generator}" />
<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="${chrome.scrollY}" />
</div>
</form>
</body>
</html>`.value;
}

/** A standalone page without a server form, for expired state, invalid postbacks, and unknown sessions. */
export function renderMessagePage(options: {
  title: string;
  paragraphs: readonly string[];
  links: readonly Link[];
  renderedAt: Date;
  requestNumber: number;
}): string {
  return html`${raw(doctype)}
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head><meta charset="utf-8" /><title>${options.title} - BranchNet</title><link rel="stylesheet" href="/assets/portal.css" /></head>
<body class="master">
<div id="page">
${banner('Operator workstation', 'Northstar Mutual')}
<div id="content" class="message-page">
<h1>${options.title}</h1>
${options.paragraphs.map((paragraph) => html`<p>${paragraph}</p>`)}
<ul class="message-links">${options.links.map((link) => html`<li><a href="${link.href}">${link.label}</a></li>`)}</ul>
</div>
${footer(options.renderedAt, options.requestNumber)}
</div>
</body>
</html>`.value;
}
