import { html, type SafeHtml } from './html.js';

export interface ListItem {
  readonly value: string;
  readonly text: string;
  readonly disabled?: boolean;
}

/** What a rendered field can post: free text up to its maxlength, or one of the values it offered. */
export type FieldInput = { readonly kind: 'text'; readonly maxLength: number } | { readonly kind: 'choice'; readonly options: readonly string[] };

export interface FieldControl<T> {
  readonly kind: 'field';
  readonly field: string;
  readonly input: FieldInput;
  readonly autoPostBack: T | null;
}

/**
 * LoadPostData for one field: the value the page sees, or undefined when the control could not have posted it.
 * Browsers post textarea line breaks as CRLF but count each as one character against maxlength, so text is
 * normalized to LF first and every later length rule sees the browser's count.
 */
export function loadPostValue(input: FieldInput, posted: string): string | undefined {
  if (input.kind === 'choice') return input.options.includes(posted) ? posted : undefined;
  const value = posted.replace(/\r\n?/gu, '\n');
  return value.length <= input.maxLength ? value : undefined;
}

export type ControlEntry<T> =
  | FieldControl<T>
  | { readonly kind: 'submit'; readonly event: T }
  | { readonly kind: 'postback'; readonly events: Map<string, T> };

/** The controls one rendered document offered, keyed by their generated UniqueID. */
export class ControlRegistry<T> {
  readonly #controls = new Map<string, ControlEntry<T>>();

  get(name: string): ControlEntry<T> | undefined {
    return this.#controls.get(name);
  }

  fields(): [string, FieldControl<T>][] {
    const result: [string, FieldControl<T>][] = [];
    for (const [name, entry] of this.#controls) {
      if (entry.kind === 'field') result.push([name, entry]);
    }
    return result;
  }

  addField(name: string, control: FieldControl<T>): void {
    this.#claim(name);
    this.#controls.set(name, control);
  }

  addSubmit(name: string, event: T): void {
    this.#claim(name);
    this.#controls.set(name, { kind: 'submit', event });
  }

  addPostBack(name: string, argument: string, event: T): void {
    const existing = this.#controls.get(name);
    if (existing === undefined) {
      this.#controls.set(name, { kind: 'postback', events: new Map([[argument, event]]) });
      return;
    }
    if (existing.kind !== 'postback' || existing.events.has(argument)) {
      throw new Error(`Control ${name} was rendered twice.`);
    }
    existing.events.set(argument, event);
  }

  #claim(name: string): void {
    if (this.#controls.has(name)) throw new Error(`Control ${name} was rendered twice.`);
  }
}

export interface ControlSink<E> {
  readonly values: Readonly<Record<string, string>>;
  readonly invalidFields: ReadonlySet<string>;
  addField(name: string, field: string, input: FieldInput, autoPostBack: E | null): void;
  addSubmit(name: string, event: E): void;
  addPostBack(name: string, argument: string, event: E): void;
}

export function registrySink<E, T>(
  registry: ControlRegistry<T>,
  wrap: (event: E) => T,
  values: Readonly<Record<string, string>>,
  invalidFields: ReadonlySet<string>,
): ControlSink<E> {
  return {
    values,
    invalidFields,
    addField(name, field, input, autoPostBack) {
      registry.addField(name, {
        kind: 'field',
        field,
        input,
        autoPostBack: autoPostBack === null ? null : wrap(autoPostBack),
      });
    },
    addSubmit(name, event) {
      registry.addSubmit(name, wrap(event));
    },
    addPostBack(name, argument, event) {
      registry.addPostBack(name, argument, wrap(event));
    },
  };
}

function postBackHref(target: string, argument: string): string {
  return `javascript:__doPostBack('${target}','${argument}')`;
}

/**
 * Renders Web Forms controls under a naming container and records each one in the document's
 * control registry, so a postback can be resolved only against what was actually rendered.
 */
export class ViewBuilder<E> {
  readonly #path: readonly string[];
  readonly #sink: ControlSink<E>;

  constructor(path: readonly string[], sink: ControlSink<E>) {
    this.#path = path;
    this.#sink = sink;
  }

  child(id: string): ViewBuilder<E> {
    return new ViewBuilder([...this.#path, id], this.#sink);
  }

  /** Grid data rows follow the header row (ctl01), so the first data row is ctl02. */
  row(index: number): ViewBuilder<E> {
    return this.child(`ctl${String(index + 2).padStart(2, '0')}`);
  }

  get uniqueId(): string {
    return this.#path.join('$');
  }

  get clientId(): string {
    return this.#path.join('_');
  }

  nameOf(id: string): string {
    return [...this.#path, id].join('$');
  }

  idOf(id: string): string {
    return [...this.#path, id].join('_');
  }

  value(field: string): string {
    return this.#sink.values[field] ?? '';
  }

  label(id: string, text: string): SafeHtml {
    return html`<label for="${this.idOf(id)}">${text}</label>`;
  }

  validator(field: string, id: string): SafeHtml {
    if (!this.#sink.invalidFields.has(field)) return html``;
    return html`<span id="${this.idOf(id)}_val" class="validator" title="See the message above">*</span>`;
  }

  textBox(id: string, options: { field: string; maxLength: number; columns?: number }): SafeHtml {
    const name = this.nameOf(id);
    this.#sink.addField(name, options.field, { kind: 'text', maxLength: options.maxLength }, null);
    return html`<input name="${name}" type="text" value="${this.value(options.field)}" maxlength="${options.maxLength}" id="${this.idOf(id)}" class="textbox" size="${options.columns ?? 24}" />${this.validator(options.field, id)}`;
  }

  textArea(id: string, options: { field: string; rows: number; maxLength: number; columns?: number }): SafeHtml {
    const name = this.nameOf(id);
    this.#sink.addField(name, options.field, { kind: 'text', maxLength: options.maxLength }, null);
    return html`<textarea name="${name}" rows="${options.rows}" cols="${options.columns ?? 60}" maxlength="${options.maxLength}" id="${this.idOf(id)}" class="textarea">\r\n${this.value(options.field)}</textarea>${this.validator(options.field, id)}`;
  }

  dropDownList(id: string, options: { field: string; items: readonly ListItem[]; autoPostBack?: E }): SafeHtml {
    const name = this.nameOf(id);
    const allowed = options.items.filter((item) => item.disabled !== true).map((item) => item.value);
    this.#sink.addField(name, options.field, { kind: 'choice', options: allowed }, options.autoPostBack ?? null);
    const current = this.value(options.field);
    return html`<select name="${name}" id="${this.idOf(id)}" class="ddl"${
      options.autoPostBack === undefined ? '' : html` data-autopostback="true"`
    }>${options.items.map(
      (item) =>
        html`<option value="${item.value}"${item.value === current ? html` selected="selected"` : ''}${
          item.disabled === true ? html` disabled="disabled"` : ''
        }>${item.text}</option>`,
    )}</select>${this.validator(options.field, id)}`;
  }

  radioButtonList(id: string, options: { field: string; items: readonly ListItem[] }): SafeHtml {
    const name = this.nameOf(id);
    this.#sink.addField(name, options.field, { kind: 'choice', options: options.items.map((item) => item.value) }, null);
    const current = this.value(options.field);
    return html`<table id="${this.idOf(id)}" class="radiolist"><tr>${options.items.map((item, index) => {
      const itemId = `${this.idOf(id)}_${String(index)}`;
      return html`<td><input id="${itemId}" type="radio" name="${name}" value="${item.value}"${
        item.value === current ? html` checked="checked"` : ''
      } /><label for="${itemId}">${item.text}</label></td>`;
    })}</tr></table>${this.validator(options.field, id)}`;
  }

  button(id: string, text: string, event: E, options: { disabled?: boolean; primary?: boolean } = {}): SafeHtml {
    const name = this.nameOf(id);
    if (options.disabled === true) {
      return html`<input type="submit" name="${name}" value="${text}" id="${this.idOf(id)}" class="button" disabled="disabled" />`;
    }
    this.#sink.addSubmit(name, event);
    return html`<input type="submit" name="${name}" value="${text}" id="${this.idOf(id)}" class="${
      options.primary === true ? 'button primary' : 'button'
    }" />`;
  }

  linkButton(id: string, text: string, event: E, options: { title?: string; className?: string } = {}): SafeHtml {
    const name = this.nameOf(id);
    this.#sink.addPostBack(name, '', event);
    return html`<a id="${this.idOf(id)}"${options.className === undefined ? '' : html` class="${options.className}"`}${
      options.title === undefined ? '' : html` title="${options.title}"`
    } href="${postBackHref(name, '')}">${text}</a>`;
  }

  /** A link that posts back to this container with an argument, like GridView's Page$N and Sort$Field. */
  postBackLink(argument: string, text: string, event: E, options: { title?: string } = {}): SafeHtml {
    this.#sink.addPostBack(this.uniqueId, argument, event);
    return html`<a${options.title === undefined ? '' : html` title="${options.title}"`} href="${postBackHref(
      this.uniqueId,
      argument,
    )}">${text}</a>`;
  }

  /** A Panel whose DefaultButton receives Enter pressed in its text inputs. */
  panel(id: string, defaultButtonId: string, content: SafeHtml, className = 'panel'): SafeHtml {
    return html`<div id="${this.idOf(id)}" class="${className}" data-default-button="${this.idOf(
      defaultButtonId,
    )}">${content}</div>`;
  }
}
