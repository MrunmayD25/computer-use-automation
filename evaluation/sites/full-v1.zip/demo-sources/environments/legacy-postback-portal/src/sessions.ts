import { randomBytes } from 'node:crypto';

import type { DatasetBinding } from '@computer-use/financial-database';

import { FormStateHistory } from './form-state.js';
import { DEFAULT_INSTITUTION, datasetInstitution, resolveOperator, worldBinding, type PortalServices } from './financial.js';
import type { StoredDocument } from './runtime.js';

export const SESSION_PATH_PATTERN = /^\/\(S\(([a-z0-5]{24})\)\)\/([A-Za-z]+\.(?:aspx|ashx))(?:\?(.*))?$/u;

/** Creates a UI session on an isolated cloned dataset or attaches to a shared dataset binding. */
export interface SessionRequest {
  /** Legacy alias retained for the administration contract; a clone of the institution's world dataset. */
  readonly seed?: number | undefined;
  readonly datasetId?: string | undefined;
  readonly institutionId?: string | undefined;
  readonly actorNumber?: string | undefined;
}

export interface CreatedSession {
  readonly instanceId: string;
  readonly capability: string;
  readonly entryPath: string;
  readonly datasetId: string;
  readonly institutionId: string;
}

export class UnknownInstanceError extends Error {
  constructor(instanceId: string) {
    super(`Unknown instance ${instanceId}.`);
  }
}

export class CapacityError extends Error {}

export interface UiSession {
  readonly instanceId: string;
  readonly capability: string;
  readonly entryPath: string;
  readonly binding: DatasetBinding;
  readonly institutionId: string;
  readonly datasetId: string;
  /** The operator this session is signed on as; changed only through the Operator page postback. */
  actorNumber: string;
  readonly documents: FormStateHistory<StoredDocument>;
  /** Number of committed seed operations present when this UI session was created. */
  readonly operationBaseline: number;
}

export interface InstanceSnapshot {
  readonly instanceId: string;
  readonly institutionId: string;
  readonly datasetId: string;
  readonly actorNumber: string;
  readonly revision: number;
  /** Committed commands on the bound dataset — the monotonic change counter. */
  readonly operations: number;
  readonly summary: unknown;
  readonly members: unknown;
  readonly accounts: unknown;
}

export interface SessionStoreOptions {
  readonly services: PortalServices;
  readonly formState: { ttlMs: number; capacity: number; now: () => number };
  readonly maxSessions?: number;
}

/**
 * In-memory UI sessions. Page state, form drafts and the signed-on operator live here; the business
 * records a session sees live in its bound shared dataset and are never copied into session state.
 */
export class SessionStore {
  readonly #services: PortalServices;
  readonly #formState: { ttlMs: number; capacity: number; now: () => number };
  readonly #maxSessions: number;
  readonly #sessions = new Map<string, UiSession>();
  readonly #byCapability = new Map<string, UiSession>();
  readonly #origins = new Map<string, string>();
  readonly #operationBaselines = new Map<string, number>();

  constructor(options: SessionStoreOptions) {
    this.#services = options.services;
    this.#formState = options.formState;
    this.#maxSessions = options.maxSessions ?? 64;
  }

  get services(): PortalServices {
    return this.#services;
  }

  create(request: SessionRequest): CreatedSession {
    if (this.#sessions.size >= this.#maxSessions) throw new CapacityError('Too many active sessions.');
    let binding: DatasetBinding;
    if (request.datasetId !== undefined) {
      const summary = datasetInstitution(this.#services.store, request.datasetId);
      binding = { institutionId: summary.institutionId as DatasetBinding['institutionId'], datasetId: summary.datasetId as DatasetBinding['datasetId'] };
    } else {
      const source = worldBinding(this.#services, request.institutionId ?? DEFAULT_INSTITUTION);
      if (source === undefined) throw new Error('Unknown institution.');
      binding = this.#services.database.cloneDataset(source, `branchnet-${randomBytes(4).toString('hex')}`);
    }
    const actorNumber = request.actorNumber ?? this.#services.defaultOperator;
    if (resolveOperator(this.#services.store, binding, actorNumber) === undefined) {
      throw new Error(`Operator ${actorNumber} is not registered in this dataset.`);
    }
    const instanceId = `inst-${randomBytes(8).toString('hex')}`;
    let operationBaseline = this.#operationBaselines.get(binding.datasetId);
    if (operationBaseline === undefined) {
      operationBaseline = this.#services.store.read((database) => {
        const row = database.prepare("SELECT COUNT(*) AS c FROM operations WHERE dataset_id=? AND status='committed'").get(binding.datasetId) as { c?: number } | undefined;
        return row?.c ?? 0;
      });
      this.#operationBaselines.set(binding.datasetId, operationBaseline);
    }
    const alphabet = 'abcdefghijklmnopqrstuvwxyz012345';
    const capability = [...randomBytes(24)].map((byte) => alphabet[byte % alphabet.length]).join('');
    const session: UiSession = {
      instanceId,
      capability,
      entryPath: `/(S(${capability}))/Default.aspx`,
      binding,
      institutionId: binding.institutionId,
      datasetId: binding.datasetId,
      actorNumber,
      documents: new FormStateHistory(this.#formState),
      operationBaseline,
    };
    this.#sessions.set(instanceId, session);
    this.#byCapability.set(capability, session);
    this.#origins.set(instanceId, request.datasetId !== undefined ? `attach:${request.datasetId}` : `clone:${binding.institutionId}`);
    return { instanceId, entryPath: session.entryPath, datasetId: binding.datasetId, institutionId: binding.institutionId, capability };
  }

  /** Replaces the session with a fresh one cloned from the same institution's world dataset. */
  reset(instanceId: string): CreatedSession {
    const session = this.session(instanceId);
    this.dispose(instanceId);
    return this.create({ institutionId: session.institutionId, actorNumber: session.actorNumber });
  }

  session(instanceId: string): UiSession {
    const session = this.#sessions.get(instanceId);
    if (session === undefined) throw new UnknownInstanceError(instanceId);
    return session;
  }

  byCapability(capability: string): UiSession | undefined {
    return this.#byCapability.get(capability);
  }

  dispose(instanceId: string): void {
    const session = this.session(instanceId);
    this.#sessions.delete(instanceId);
    this.#byCapability.delete(session.capability);
    this.#origins.delete(instanceId);
  }

  snapshot(instanceId: string): InstanceSnapshot {
    const session = this.session(instanceId);
    const dataset = this.#services.database.dataset(session.binding);
    const { revision, operations } = this.#services.store.read((database) => {
      const row = database.prepare('SELECT revision FROM datasets WHERE id=?').get(session.datasetId);
      const count = database.prepare("SELECT COUNT(*) AS c FROM operations WHERE dataset_id=? AND status='committed'").get(session.datasetId) as { c: number } | undefined;
      return {
        revision: typeof row?.revision === 'number' ? row.revision : 0,
        operations: Math.max(0, (count?.c ?? 0) - session.operationBaseline),
      };
    });
    const extras = this.#services.store.read((database) => {
      const parties = new Map(
        database
          .prepare('SELECT id, party_id FROM members WHERE dataset_id=?')
          .all(session.datasetId)
          .map((r) => [String(r.id), String(r.party_id)]),
      );
      const emails = new Map<string, string>();
      for (const r of database.prepare("SELECT party_id, value FROM contact_points WHERE dataset_id=? AND kind='email' AND valid_to IS NULL ORDER BY valid_from DESC, id DESC").all(session.datasetId)) {
        const party = String(r.party_id);
        if (!emails.has(party)) emails.set(party, String(r.value));
      }
      const accounts = new Map(
        database
          .prepare('SELECT id, nickname, statement_delivery FROM accounts WHERE dataset_id=?')
          .all(session.datasetId)
          .map((r) => [String(r.id), { nickname: String(r.nickname), statementDelivery: String(r.statement_delivery) }]),
      );
      return { parties, emails, accounts };
    });
    return {
      instanceId: session.instanceId,
      institutionId: session.institutionId,
      datasetId: session.datasetId,
      actorNumber: session.actorNumber,
      revision,
      operations,
      summary: dataset.summary(),
      members: {
        items: dataset.members.list({ limit: 100 }).items.map((member) => ({ ...member, email: extras.emails.get(extras.parties.get(member.id) ?? '') ?? null })),
      },
      accounts: {
        items: dataset.accounts.list({ limit: 100 }).items.map((account) => ({ ...account, ...(extras.accounts.get(account.id) ?? {}) })),
      },
    };
  }
}

export function createSessionStore(options: SessionStoreOptions): SessionStore {
  return new SessionStore(options);
}
