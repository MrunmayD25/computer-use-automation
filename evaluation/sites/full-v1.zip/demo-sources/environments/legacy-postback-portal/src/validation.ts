import { parseMoney, parseSignedMoney } from './money.js';

export interface ValidationMessage {
  /** Logical field that receives the red asterisk, or null for a form-level message. */
  readonly field: string | null;
  readonly message: string;
  readonly link?: { readonly href: string; readonly label: string };
}

export interface ComparisonRow {
  readonly label: string;
  readonly saved: string;
  /** Present server's value when it differs from the saved one. */
  readonly current?: string;
}

/** Collects server-side validator results for posted field values. */
export class FieldCheck {
  readonly errors: ValidationMessage[] = [];
  readonly #fields: Readonly<Record<string, string>>;

  constructor(fields: Readonly<Record<string, string>>) {
    this.#fields = fields;
  }

  get ok(): boolean {
    return this.errors.length === 0;
  }

  fail(field: string | null, message: string): void {
    this.errors.push({ field, message });
  }

  text(
    field: string,
    label: string,
    options: { required: boolean; max: number; pattern?: RegExp; patternMessage?: string },
  ): string {
    const value = (this.#fields[field] ?? '').trim();
    if (value === '') {
      if (options.required) this.fail(field, `${label} is required.`);
      return value;
    }
    if (value.length > options.max) {
      this.fail(field, `${label} must be ${options.max.toLocaleString('en-US')} characters or fewer.`);
    } else if (options.pattern !== undefined && !options.pattern.test(value)) {
      this.fail(field, options.patternMessage ?? `${label} is not in the expected format.`);
    }
    return value;
  }

  /** Optional text: null when blank, undefined only on a validation failure. */
  optional(field: string, label: string, options: { max: number }): string | null | undefined {
    const value = (this.#fields[field] ?? '').trim();
    if (value.length > options.max) {
      this.fail(field, `${label} must be ${options.max.toLocaleString('en-US')} characters or fewer.`);
      return undefined;
    }
    return value === '' ? null : value;
  }

  choice<T extends string>(field: string, label: string, allowed: readonly T[]): T | undefined {
    const value = this.#fields[field] ?? '';
    const match = allowed.find((candidate) => candidate === value);
    if (match === undefined) this.fail(field, `${label} is required.`);
    return match;
  }

  money(field: string, label: string, exponent = 2): number | undefined {
    const value = (this.#fields[field] ?? '').trim();
    if (value === '') {
      this.fail(field, `${label} is required.`);
      return undefined;
    }
    const amount = parseMoney(value, exponent);
    if (amount === undefined) {
      this.fail(field, `${label} must be a positive amount with at most ${String(exponent)} decimal places.`);
    }
    return amount;
  }

  signedMoney(field: string, label: string, exponent = 2): number | undefined {
    const value = (this.#fields[field] ?? '').trim();
    if (value === '') {
      this.fail(field, `${label} is required.`);
      return undefined;
    }
    const amount = parseSignedMoney(value, exponent);
    if (amount === undefined) {
      this.fail(field, `${label} must be an amount with at most ${String(exponent)} decimal places.`);
    }
    return amount;
  }

  integer(field: string, label: string, options: { required: boolean; min?: number; max?: number }): number | undefined {
    const value = (this.#fields[field] ?? '').trim();
    if (value === '') {
      if (options.required) this.fail(field, `${label} is required.`);
      return undefined;
    }
    if (!/^-?\d+$/u.test(value)) {
      this.fail(field, `${label} must be a whole number.`);
      return undefined;
    }
    const amount = Number(value);
    if (!Number.isSafeInteger(amount) || (options.min !== undefined && amount < options.min) || (options.max !== undefined && amount > options.max)) {
      this.fail(field, `${label} must be an integer from ${String(options.min ?? -9_007_199_254_740_991)} through ${String(options.max ?? 9_007_199_254_740_991)}.`);
      return undefined;
    }
    return amount;
  }

  date(field: string, label: string, options: { required: boolean }): string | undefined {
    const value = (this.#fields[field] ?? '').trim();
    if (value === '') {
      if (options.required) this.fail(field, `${label} is required.`);
      return undefined;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/u.test(value) || Number.isNaN(Date.parse(`${value}T00:00:00Z`)) || new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) !== value) {
      this.fail(field, `${label} must be a date like 2026-09-14.`);
      return undefined;
    }
    return value;
  }

  instant(field: string, label: string, options: { required: boolean }): string | undefined {
    const value = (this.#fields[field] ?? '').trim().replace(' ', 'T');
    if (value === '') {
      if (options.required) this.fail(field, `${label} is required.`);
      return undefined;
    }
    const match = /^(\d{4}-\d{2}-\d{2}T(?:[01]\d|2[0-3]):[0-5]\d)(:[0-5]\d(?:\.\d{1,9})?)?(Z|[+-](?:0\d|1[0-4]):[0-5]\d)?$/u.exec(value);
    const clock = match?.[1];
    const seconds = match?.[2] ?? ':00';
    const offset = match?.[4] ?? 'Z';
    if (match === null || clock === undefined || !isIsoDate(clock.slice(0, 10))) {
      this.fail(field, `${label} must be an instant like 2026-09-14T15:00:00Z with an explicit offset.`);
      return undefined;
    }
    const parsed = Date.parse(`${clock}${seconds}${offset}`);
    if (!Number.isFinite(parsed)) {
      this.fail(field, `${label} must be an instant like 2026-09-14T15:00:00Z with an explicit offset.`);
      return undefined;
    }
    return new Date(parsed).toISOString();
  }
}

function isIsoDate(value: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/u.test(value) && Number.isFinite(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value;
}

export const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/u;
export const PHONE_PATTERN = /^[0-9()+\-. ]{7,40}$/u;
export const POSTAL_PATTERN = /^[A-Za-z0-9 -]{3,12}$/u;
