export const PAGE_NAMES = [
  'Default.aspx',
  'Members.aspx',
  'MemberNew.aspx',
  'MemberDetail.aspx',
  'Accounts.aspx',
  'AccountOpen.aspx',
  'AccountDetail.aspx',
  'Transactions.aspx',
  'Receipt.aspx',
  'Statements.aspx',
  'Activity.aspx',
  'Cases.aspx',
  'CaseDetail.aspx',
  'Documents.aspx',
  'DocumentDetail.aspx',
  'Payments.aspx',
  'Cards.aspx',
  'Loans.aspx',
  'Batches.aspx',
  'Requests.aspx',
  'RequestEdit.aspx',
  'RequestDetail.aspx',
  'RequestPrint.aspx',
  'Approvals.aspx',
  'Searches.aspx',
  'Operator.aspx',
  'Operation.aspx',
  'Record.aspx',
] as const;

export type PageName = (typeof PAGE_NAMES)[number];

export function isPageName(value: string): value is PageName {
  return PAGE_NAMES.some((name) => name === value);
}

export type QueryValue = string | number | null | undefined;

/** Builds a link relative to the session directory; empty and absent parameters are omitted. */
export function pageHref(page: PageName, parameters: Readonly<Record<string, QueryValue>> = {}): string {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(parameters)) {
    if (value === null || value === undefined || value === '') continue;
    query.set(key, String(value));
  }
  const search = query.toString();
  return search === '' ? page : `${page}?${search}`;
}

/** Accepts a ReturnUrl only when it names one of this application's pages. */
export function safeReturnUrl(value: string | null): string | null {
  if (value === null) return null;
  const match = /^([A-Za-z]+\.aspx)(\?[^#\s]*)?$/u.exec(value);
  const page = match?.[1];
  return page !== undefined && isPageName(page) ? value : null;
}
