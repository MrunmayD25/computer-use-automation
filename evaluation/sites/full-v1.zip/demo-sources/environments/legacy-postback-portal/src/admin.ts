import { timingSafeEqual } from 'node:crypto';

import express, { type Express, type NextFunction, type Request, type Response } from 'express';
import { z } from 'zod';

import { CapacityError, UnknownInstanceError, type CreatedSession, type SessionStore } from './sessions.js';

const actorNumber = z.string().regex(/^[A-Z]{2}\d{4}$/u);
const createInstanceSchema = z.union([
  z.strictObject({
    seed: z.number().int().min(0).max(0x7fff_ffff),
    institutionId: z.string().regex(/^[a-z][a-z0-9-]*$/u).optional(),
    actorNumber: actorNumber.optional(),
  }),
  z.strictObject({ datasetId: z.string().min(1).max(200), actorNumber: actorNumber.optional() }),
]);

function tokenMatches(value: string | undefined, expected: string): boolean {
  const prefix = 'Bearer ';
  if (value === undefined || !value.startsWith(prefix)) return false;
  const actual = Buffer.from(value.slice(prefix.length));
  const wanted = Buffer.from(expected);
  return actual.length === wanted.length && timingSafeEqual(actual, wanted);
}

function isBrowserRequest(request: Request): boolean {
  return (
    request.headers.origin !== undefined ||
    request.headers['sec-fetch-site'] !== undefined ||
    request.headers['sec-fetch-dest'] !== undefined ||
    request.headers['sec-fetch-user'] !== undefined
  );
}

function hasLoopbackHost(request: Request): boolean {
  const host = request.headers.host?.toLowerCase();
  return host !== undefined && /^(127\.0\.0\.1|localhost):\d+$/u.test(host);
}

export function createAdminApp(options: { store: SessionStore; adminToken: string; mainOrigin: () => string }): Express {
  const app = express();
  app.disable('x-powered-by');
  app.use((request, response, next) => {
    response.setHeader('cache-control', 'no-store');
    if (!tokenMatches(request.headers.authorization, options.adminToken)) {
      response.status(401).json({ error: 'Unauthorized' });
      return;
    }
    if (isBrowserRequest(request)) {
      response.status(403).json({ error: 'Browser requests are forbidden' });
      return;
    }
    if (!hasLoopbackHost(request)) {
      response.status(403).json({ error: 'Invalid Host header' });
      return;
    }
    next();
  });
  app.use(express.json({ limit: '4kb', strict: true, type: 'application/json' }));

  function created(response: Response, session: CreatedSession): void {
    response.status(201).json({
      instanceId: session.instanceId,
      entryUrl: `${options.mainOrigin()}${session.entryPath}`,
      datasetId: session.datasetId,
      institutionId: session.institutionId,
    });
  }

  app.post('/instances', (request, response) => {
    const parsed = createInstanceSchema.safeParse(request.body);
    if (!parsed.success) {
      response.status(400).json({ error: 'Invalid instance request', issues: parsed.error.issues });
      return;
    }
    const body = parsed.data;
    try {
      created(response, options.store.create(body));
    } catch (error) {
      if (error instanceof Error && (error.message === 'Unknown dataset.' || error.message === 'Unknown institution.')) {
        response.status(404).json({ error: error.message });
        return;
      }
      if (error instanceof Error && error.message.startsWith('Operator ')) {
        response.status(422).json({ error: error.message });
        return;
      }
      throw error;
    }
  });

  app.get('/instances/:instanceId/state', (request, response) => {
    response.json(options.store.snapshot(request.params.instanceId));
  });

  app.get('/instances/:instanceId/export', (request, response) => {
    const snapshot = options.store.snapshot(request.params.instanceId);
    response.setHeader('content-disposition', `attachment; filename="branchnet-${snapshot.instanceId}.json"`);
    response.json(snapshot);
  });

  app.post('/instances/:instanceId/reset', (request, response) => {
    created(response, options.store.reset(request.params.instanceId));
  });

  app.delete('/instances/:instanceId', (request, response) => {
    options.store.dispose(request.params.instanceId);
    response.status(204).end();
  });

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    if (error instanceof UnknownInstanceError) {
      response.status(404).json({ error: 'Unknown instance' });
      return;
    }
    if (error instanceof CapacityError) {
      response.status(429).json({ error: error.message });
      return;
    }
    if (error instanceof SyntaxError || (typeof error === 'object' && error !== null && 'status' in error && error.status === 413)) {
      response.status(400).json({ error: 'Invalid JSON body' });
      return;
    }
    console.error('Administration request failed.', error);
    response.status(500).json({ error: 'Administration request failed' });
  });
  return app;
}
