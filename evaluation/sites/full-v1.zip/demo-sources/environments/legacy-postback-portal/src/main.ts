import { randomBytes } from 'node:crypto';
import { mkdir, rename, rm, writeFile } from 'node:fs/promises';
import { createServer, type Server } from 'node:http';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import type { Express } from 'express';

import { createAdminApp } from './admin.js';
import { DEFAULT_OPERATOR, DEFAULT_OPERATORS, DEFAULT_WORLD, openPortalServices } from './financial.js';
import { createSessionStore } from './sessions.js';
import { createPortalApp } from './web.js';

const DEFAULT_DATABASE = fileURLToPath(new URL('../../database/financial/.runtime/financial.sqlite', import.meta.url));

export interface EnvironmentConfig {
  port?: number;
  adminPort?: number;
  adminToken: string;
  verbose?: boolean;
  maxSessions?: number;
  /** Creates the demonstration session on the shared world dataset; default true. */
  demo?: boolean;
  databasePath?: string;
  databaseBusyTimeoutMs?: number;
  /** Named world to bind; default financial-demo-v1. */
  world?: string;
  /** Operator actor numbers that may sign on; default OP0001–OP0007. */
  operators?: string[];
  /** Actor number the demonstration session signs on as. */
  operator?: string;
  /** Idle lifetime of page state in milliseconds; default 20 minutes. */
  formStateTtlMs?: number;
  /** Page states retained per UI session; default 200. */
  formStateHistory?: number;
  /** Clock in epoch milliseconds, injectable for expiry tests. */
  now?: () => number;
  /** Local folder the 'export-folder' statement destination writes to. */
  exportDirectory?: string;
}

export interface EnvironmentHandle {
  origins: { main: string; admin: string };
  close(): Promise<void>;
}

const host = '127.0.0.1';

function listen(app: Express, port: number): Promise<Server> {
  const server = createServer(app);
  return new Promise((resolveListen, reject) => {
    const fail = (error: Error): void => reject(error);
    server.once('error', fail);
    server.listen(port, host, () => {
      server.off('error', fail);
      resolveListen(server);
    });
  });
}

function origin(server: Server): string {
  const address = server.address();
  if (address === null || typeof address === 'string') throw new Error('Listener has no TCP address.');
  return `http://${host}:${String(address.port)}`;
}

function closeServer(server: Server): Promise<void> {
  server.closeIdleConnections();
  return new Promise((resolveClose, reject) => {
    server.close((error) => (error === undefined ? resolveClose() : reject(error)));
  });
}

export async function startEnvironment(config: EnvironmentConfig): Promise<EnvironmentHandle> {
  if (config.adminToken.length < 16) throw new Error('The admin token must contain at least 16 characters.');
  const now = config.now ?? Date.now;
  const services = openPortalServices({
    path: config.databasePath ?? DEFAULT_DATABASE,
    world: config.world ?? DEFAULT_WORLD,
    ...(config.databaseBusyTimeoutMs === undefined ? {} : { busyTimeoutMs: config.databaseBusyTimeoutMs }),
    ...(config.operators === undefined ? {} : { operators: config.operators }),
    ...(config.operator === undefined ? {} : { defaultOperator: config.operator }),
    ...(config.exportDirectory === undefined ? {} : { exportDirectory: resolve(config.exportDirectory) }),
  });
  const servers: Server[] = [];
  try {
    const store = createSessionStore({
      services,
      formState: {
        ttlMs: config.formStateTtlMs ?? 20 * 60_000,
        capacity: config.formStateHistory ?? 200,
        now,
      },
      ...(config.maxSessions === undefined ? {} : { maxSessions: config.maxSessions }),
    });
    const demoEnabled = config.demo !== false;
    let demoCapabilityPath: string | null = null;
    const demoEntryPath = (): string | null => {
      if (!demoEnabled) return null;
      const capability = demoCapabilityPath?.match(/\(S\(([a-z0-5]{24})\)\)/u)?.[1];
      if (capability === undefined || store.byCapability(capability) === undefined) {
        const world = services.world.find((binding) => binding.institutionId === 'northstar') ?? services.world[0];
        if (world === undefined) throw new Error('The bound world has no institutions.');
        demoCapabilityPath = store.create({ datasetId: world.datasetId, actorNumber: services.defaultOperator }).entryPath;
      }
      return demoCapabilityPath;
    };
    demoEntryPath();
    let mainOrigin = '';
    const mainServer = await listen(
      createPortalApp({ store, services, demoEntryPath, now, verbose: config.verbose === true }),
      config.port ?? 4320,
    );
    servers.push(mainServer);
    mainOrigin = origin(mainServer);
    const adminServer = await listen(
      createAdminApp({ store, adminToken: config.adminToken, mainOrigin: () => mainOrigin }),
      config.adminPort ?? 4321,
    );
    servers.push(adminServer);
    const origins = { main: mainOrigin, admin: origin(adminServer) };
    if (config.verbose === true) {
      console.error(`BranchNet UI: ${origins.main}`);
      console.error(`BranchNet admin: ${origins.admin}`);
    }
    let closing: Promise<void> | undefined;
    return {
      origins,
      close() {
        closing ??= (async () => {
          try {
            await Promise.all(servers.toReversed().map(closeServer));
          } finally {
            if (services.ownsStore) services.store.close();
            services.database.close();
          }
        })();
        return closing;
      },
    };
  } catch (error) {
    await Promise.allSettled(servers.toReversed().map(closeServer));
    if (services.ownsStore) services.store.close();
    services.database.close();
    throw error;
  }
}

export interface CliOptions {
  port: number;
  adminPort: number;
  adminTokenFile: string;
  verbose: boolean;
  databasePath?: string;
  world: string;
  operators: string[];
  operator?: string;
  formStateTtlMs?: number;
  formStateHistory?: number;
  exportDirectory?: string;
}

function decimal(value: string | undefined): number | null {
  return value !== undefined && /^\d+$/u.test(value) ? Number(value) : null;
}

function parsePort(value: string | undefined, flag: string): number {
  const port = decimal(value);
  if (port === null || port > 65_535) throw new Error(`${flag} requires a port from 0 through 65535.`);
  return port;
}

function parsePositive(value: string | undefined, flag: string, maximum: number): number {
  const number = decimal(value);
  if (number === null || number < 1 || number > maximum) {
    throw new Error(`${flag} requires an integer from 1 through ${String(maximum)}.`);
  }
  return number;
}

function requiredPath(value: string | undefined, flag: string): string {
  if (value === undefined || value.trim() === '') throw new Error(`${flag} requires a path.`);
  return value;
}

export function parseCli(arguments_: readonly string[]): CliOptions {
  const options: CliOptions = {
    port: 4320,
    adminPort: 4321,
    adminTokenFile: '.runtime/admin.token',
    verbose: false,
    world: DEFAULT_WORLD,
    operators: [...DEFAULT_OPERATORS],
  };
  for (let index = 0; index < arguments_.length; index += 1) {
    const argument = arguments_[index];
    switch (argument) {
      case '--port':
        options.port = parsePort(arguments_[++index], '--port');
        break;
      case '--admin-port':
        options.adminPort = parsePort(arguments_[++index], '--admin-port');
        break;
      case '--admin-token-file':
        options.adminTokenFile = requiredPath(arguments_[++index], '--admin-token-file');
        break;
      case '--database':
        options.databasePath = resolve(requiredPath(arguments_[++index], '--database'));
        break;
      case '--world':
        options.world = requiredPath(arguments_[++index], '--world');
        break;
      case '--operators':
        options.operators = requiredPath(arguments_[++index], '--operators').split(',').map((value) => value.trim());
        break;
      case '--operator':
        options.operator = requiredPath(arguments_[++index], '--operator');
        break;
      case '--export-dir':
        options.exportDirectory = requiredPath(arguments_[++index], '--export-dir');
        break;
      case '--form-state-ttl':
        options.formStateTtlMs = parsePositive(arguments_[++index], '--form-state-ttl', 86_400) * 1_000;
        break;
      case '--form-state-history':
        options.formStateHistory = parsePositive(arguments_[++index], '--form-state-history', 10_000);
        break;
      case '--verbose':
        options.verbose = true;
        break;
      default:
        throw new Error(`Unknown option: ${argument ?? ''}`);
    }
  }
  return options;
}

/** Replaces the token file atomically so no reader sees a partial or wider-permission file. */
export async function writeAdminToken(path: string, token: string): Promise<void> {
  const directory = dirname(path);
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const temporary = join(directory, `.${basename(path)}.${randomBytes(6).toString('hex')}.tmp`);
  try {
    await writeFile(temporary, `${token}\n`, { mode: 0o600, flag: 'wx' });
    await rename(temporary, path);
  } catch (error) {
    await rm(temporary, { force: true });
    throw error;
  }
}

async function runCli(): Promise<void> {
  const options = parseCli(process.argv.slice(2));
  const token = randomBytes(32).toString('base64url');
  const tokenPath = resolve(options.adminTokenFile);
  await writeAdminToken(tokenPath, token);
  let environment: EnvironmentHandle;
  try {
    environment = await startEnvironment({
      port: options.port,
      adminPort: options.adminPort,
      adminToken: token,
      verbose: options.verbose,
      world: options.world,
      operators: options.operators,
      ...(options.operator === undefined ? {} : { operator: options.operator }),
      ...(options.databasePath === undefined ? {} : { databasePath: options.databasePath }),
      ...(options.formStateTtlMs === undefined ? {} : { formStateTtlMs: options.formStateTtlMs }),
      ...(options.formStateHistory === undefined ? {} : { formStateHistory: options.formStateHistory }),
      ...(options.exportDirectory === undefined ? {} : { exportDirectory: options.exportDirectory }),
    });
  } catch (error) {
    await rm(tokenPath, { force: true });
    throw error;
  }
  console.error(`BranchNet is available at ${environment.origins.main}`);
  console.error(`Admin token written to ${tokenPath}`);
  const shutdown = async (): Promise<void> => {
    await environment.close();
    process.exitCode = 0;
  };
  process.once('SIGINT', () => void shutdown());
  process.once('SIGTERM', () => void shutdown());
}

const invokedPath = process.argv[1];
if (invokedPath !== undefined && pathToFileURL(resolve(invokedPath)).href === import.meta.url) {
  runCli().catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : 'BranchNet failed to start.');
    process.exitCode = 1;
  });
}

export { DEFAULT_OPERATOR, DEFAULT_OPERATORS, DEFAULT_WORLD };
