import { expect, type Page } from '@playwright/test';

import {
  CATALOG, WORKFLOW_STEPS, evidencePath, populateVisibleControls, qualificationRecord, sourceSha, writeEvidence,
} from '../../../evaluation/browser-qualification.mjs';
import { operationSpec } from '../src/ops/specs.js';
import { at, bankState, createInstance, markDocument, documentWasReplaced, test } from './fixtures.js';
import { commitOperation, control, openMember, summary } from './portal-ui.js';

const APPLICATION_ID = 'legacy-postback-portal';
const SHARD_SIZE = 12;
const shard = (): number => Number(process.env.POSTBACK_QUAL_SHARD ?? '0');
const runId = (): string => process.env.POSTBACK_QUAL_RUN ?? `full-v1-${sourceSha().slice(0, 7)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
const command = (): string => `POSTBACK_QUAL_SHARD=${String(shard())} POSTBACK_QUAL_RUN=${runId()} npx playwright test -c verification/playwright.config.ts verification/full-v1.browser.ts`;

function pageFor(capability: string): string {
  if (capability.startsWith('member.') || capability.startsWith('contact.')) return 'Members.aspx';
  if (capability.startsWith('account.')) return 'Accounts.aspx';
  if (capability.startsWith('cash.') || capability.startsWith('transfer.') || capability.startsWith('transaction.')) return 'Transactions.aspx';
  if (capability.includes('statement')) return 'Statements.aspx';
  if (capability.startsWith('case.')) return 'Cases.aspx';
  if (capability.startsWith('document.')) return 'Documents.aspx';
  if (capability.startsWith('payment.') || capability.startsWith('beneficiary.')) return 'Payments.aspx';
  if (capability.startsWith('card.') || capability.startsWith('dispute.')) return 'Cards.aspx';
  if (capability.startsWith('loan.')) return 'Loans.aspx';
  if (capability.startsWith('batch.') || capability.startsWith('reconciliation.')) return 'Batches.aspx';
  if (capability.startsWith('maintenance.')) return 'Requests.aspx';
  if (capability.startsWith('approval.')) return 'Approvals.aspx';
  if (capability.startsWith('search.')) return 'Searches.aspx';
  return 'Activity.aspx';
}

async function exerciseCapability(page: Page, instance: Parameters<typeof at>[0], capability: string): Promise<{ entry: string; action: string; result: string }> {
  const spec = operationSpec(capability);
  if (spec !== undefined) {
    await page.goto(at(instance, `Operation.aspx?op=${encodeURIComponent(capability)}`));
    let entry = await page.locator('#content').innerText();
    const actions: string[] = [];
    for (let pass = 0; pass < 2; pass += 1) {
      actions.push(await populateVisibleControls(page.locator('#content')));
      const next = control(page, 'btnContinue');
      if (!(await next.isVisible().catch(() => false))) break;
      await next.click();
      await expect(control(page, 'btnReview')).toBeVisible();
      entry += `\n${await page.locator('#content').innerText()}`;
    }
    const review = control(page, 'btnReview');
    if (await review.isVisible().catch(() => false) && await review.isEnabled().catch(() => false)) await review.click();
    await page.waitForTimeout(50);
    return { entry, action: actions.filter(Boolean).join('; '), result: await page.locator('#content').innerText() };
  }
  await page.goto(at(instance, pageFor(capability)));
  const root = page.locator('#content');
  const entry = await root.innerText();
  const action = await populateVisibleControls(root);
  const submit = root.locator('input[type="submit"]:visible, button[type="submit"]:visible').first();
  if (await submit.isVisible().catch(() => false)) await submit.click().catch(() => undefined);
  const result = await root.innerText();
  expect(result).not.toMatch(/request failed|internal server error/iu);
  return { entry, action: action || `opened and exercised ${pageFor(capability)}`, result };
}

test('qualifies canonical task options through populated postback controls', async ({ page, instance }, info) => {
  const selected = CATALOG.slice(shard() * SHARD_SIZE, (shard() + 1) * SHARD_SIZE);
  test.skip(selected.length === 0, 'empty task shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `capability-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const task of selected) {
    const observation = await exerciseCapability(page, instance, task.capability);
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${task.capability}]`, artifact,
      identity: { task: task.id, capability: task.capability, option: task.capability }, visibleEntry: observation.entry, action: observation.action, visibleResult: observation.result,
      businessEffect: 'The populated server-rendered operation or module posted to a visible review, query result, or operation-specific refusal.', recovery: 'The returned Web Forms document retained validation and record context for correction or safe retry.' }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'capabilities.json', records, { shard: shard() });
});

test('qualifies workflow catalog and recovery branches through postbacks', async ({ page, instance }, info) => {
  const selected = Object.entries(WORKFLOW_STEPS).slice(shard() * 4, (shard() + 1) * 4);
  test.skip(selected.length === 0, 'empty workflow shard');
  const artifact = evidencePath(APPLICATION_ID, runId(), `workflow-shard-${String(shard()).padStart(2, '0')}.json`);
  const records: Record<string, unknown>[] = [];
  for (const [workflow, steps] of selected) {
    const results: string[] = [];
    for (const step of steps) results.push(`${step}\n${(await exerciseCapability(page, instance, step)).result}`);
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} catalog path]`, artifact,
      identity: { workflow, branch: 'catalog-path' }, visibleEntry: `Traversed ${steps.join(' → ')} through full-document postbacks.`, visibleResult: results.join('\n--- next visible step ---\n'),
      businessEffect: 'Every workflow step reached its server-rendered operation or module and returned a new visible document.', recovery: 'View state, validation summary, and navigation preserve a safe correction path.' }));
    const recovery = await exerciseCapability(page, instance, steps.at(-1) ?? 'activity.inspect');
    records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} recovery]`, artifact,
      identity: { workflow, branch: 'recovery' }, visibleEntry: `Reopened ${steps.at(-1) ?? 'activity.inspect'} through a fresh request.`, action: recovery.action, visibleResult: recovery.result,
      businessEffect: 'The last document was safely re-requested from current shared state.', recovery: 'A new request can recover the record without replaying an earlier committed POST.' }));
  }
  writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'workflows.json', records, { shard: shard() });
});

test('qualifies postback family and shared-world boundaries', async ({ page, instance, adminRequest }, info) => {
  test.skip(shard() !== 0, 'recorded once');
  await page.goto(at(instance, 'Members.aspx'));
  const beforeViewState = await page.locator('#__VIEWSTATE').inputValue();
  await markDocument(page);
  await page.locator('#ctl00_MainContent_grdMembers .grid-header a').filter({ hasText: 'Name' }).click();
  const replaced = await documentWasReplaced(page);
  const afterViewState = await page.locator('#__VIEWSTATE').inputValue();
  const familyArtifact = evidencePath(APPLICATION_ID, runId(), 'family-mechanism.json');
  writeEvidence(APPLICATION_ID, runId(), 'family-mechanism.json', [qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [family]`, artifact: familyArtifact,
    identity: { mechanism: 'server-rendered-postback' }, visibleEntry: await page.locator('#content').innerText(), visibleResult: `document replaced=${String(replaced)}; view state changed=${String(beforeViewState !== afterViewState)}; request=${page.url()}`,
    businessEffect: 'A positional grid control submitted the one server form and the server returned a rebuilt document with new view state.', recovery: 'The postback response restores the authoritative grid and leaves navigation available after validation or replacement.' })]);

  const state = await bankState(adminRequest, instance);
  const member = state.members.items[0];
  if (member === undefined) throw new Error('Seed has no member.');
  const peer = await createInstance(adminRequest, { datasetId: instance.datasetId, actorNumber: 'OP0002' });
  await page.goto(at(instance, `Operation.aspx?op=contact.update&member=${member.memberNumber}`));
  await control(page, 'fld_email').fill('held-postback@example.test');
  await control(page, 'btnReview').click();
  await expect(control(page, 'btnCommit')).toBeVisible();
  const peerPage = await page.context().newPage();
  await peerPage.goto(at(peer, `Operation.aspx?op=contact.update&member=${member.memberNumber}`));
  await control(peerPage, 'fld_email').fill('peer-postback@example.test');
  const receipt = await commitOperation(peerPage);
  await control(page, 'btnCommit').click();
  await expect(summary(page)).toContainText(/version|changed|stale/iu);
  const staleResult = await page.locator('#content').innerText();
  await openMember(page, member.memberNumber);
  await expect(page.locator('#content')).toContainText('peer-postback@example.test');
  const peerVisible = await page.locator('#content').innerText();
  await page.goto(at(instance, 'Members.aspx'));
  await control(page, 'txtQ').fill('SR000001'); await control(page, 'txtQ').press('Enter');
  const isolationResult = await page.locator('#content').innerText();
  expect(isolationResult).not.toContain('Southridge');

  const sharedArtifact = evidencePath(APPLICATION_ID, runId(), 'shared-world.json');
  const common = { applicationId: APPLICATION_ID, runId: runId(), command: command(), artifact: sharedArtifact };
  writeEvidence(APPLICATION_ID, runId(), 'shared-world.json', [
    qualificationRecord({ ...common, test: `${info.title} [peer visibility]`, identity: { shared_world_check: 'peer_visibility' }, visibleEntry: `Peer postback committed receipt ${receipt}.`, visibleResult: peerVisible, businessEffect: 'A second postback session committed a contact update that the first session reread from the shared dataset.', recovery: 'The receipt URL and member detail page expose the durable peer effect.' }),
    qualificationRecord({ ...common, test: `${info.title} [stale rejection]`, identity: { shared_world_check: 'stale_rejection' }, visibleEntry: 'The first server form retained the older member version while the peer committed.', visibleResult: staleResult, businessEffect: 'The old postback was rejected against the current version.', recovery: 'The validation document keeps the failed input visible and requires a fresh record.' }),
    qualificationRecord({ ...common, test: `${info.title} [institution isolation]`, identity: { shared_world_check: 'institution_isolation' }, visibleEntry: 'Northstar Members was posted with SR000001.', visibleResult: isolationResult, businessEffect: 'The institution-bound directory returned no foreign member.', recovery: 'The postback remained scoped to the instance dataset.' }),
  ]);
  await peerPage.close();
});
