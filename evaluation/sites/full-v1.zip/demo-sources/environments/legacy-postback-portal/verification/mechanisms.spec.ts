import type { Locator, Page } from '@playwright/test';

import {
  at,
  bankState,
  capture,
  documentWasReplaced,
  expect,
  markDocument,
  requestNumber,
  test,
} from './fixtures.js';
import { commitOperation, control, notice, reviewPanel, summary } from './portal-ui.js';

/*
 * Browser checks for the SPEC's "Web Forms mechanisms" that portal.spec.ts does not already prove.
 * The shared world is branchnet-test-v1 on a per-worker database copy; tests find their records
 * through the administration state rather than literal seed values.
 */

const postResponse = (page: Page) => page.waitForResponse((response) => response.request().method() === 'POST');

/** Waits for the document an auto-postback dropdown submits. */
async function choose(page: Page, select: Locator, value: string): Promise<void> {
  const loaded = page.waitForEvent('load');
  await select.selectOption(value);
  await loaded;
}

/** Posted control names inside `root`, in document order: field names and `__doPostBack` targets. */
function controlNames(root: Locator): Promise<string[]> {
  return root.evaluate((element) =>
    Array.from(element.querySelectorAll('input[name], select[name], a[href^="javascript:__doPostBack"]'), (item) =>
      item instanceof HTMLAnchorElement
        ? (/^javascript:__doPostBack\('([^']*)'/u.exec(item.getAttribute('href') ?? '')?.[1] ?? '')
        : (item.getAttribute('name') ?? ''),
    ),
  );
}

test('each page is one server form with the Web Forms hidden fields, and unknown records render not-found pages', async ({ page, instance }, info) => {
  const response = await page.goto(at(instance, 'Members.aspx'));
  expect(response?.status()).toBe(200);
  expect(response?.headers()['cache-control']).toBe('private, no-cache');
  const form = page.locator('form');
  await expect(form).toHaveCount(1);
  await expect(form).toHaveAttribute('method', 'post');
  await expect(form).toHaveAttribute('action', './Members.aspx');
  expect(await form.locator('input[type="hidden"]').evaluateAll((inputs) => inputs.map((input) => input.getAttribute('name')))).toEqual([
    '__EVENTTARGET',
    '__EVENTARGUMENT',
    '__LASTFOCUS',
    '__VIEWSTATE',
    '__VIEWSTATEGENERATOR',
    '__SCROLLPOSITIONY',
  ]);
  await expect(page.locator('#__VIEWSTATE')).toHaveAttribute('value', /^[\w-]{32}$/u);
  expect(await page.evaluate(() => typeof Reflect.get(window, '__doPostBack'))).toBe('function');
  await expect(page.locator('#ctl00_MainContent_lblCount')).toContainText('members found');

  const sorted = postResponse(page);
  await page.locator('#ctl00_MainContent_grdMembers .grid-header a', { hasText: 'Name' }).click();
  const sortResponse = await sorted;
  expect(sortResponse.status()).toBe(303);
  await expect(form).toHaveAttribute('action', './Members.aspx?sort=name&dir=asc');

  const missingMember = await page.goto(at(instance, 'MemberDetail.aspx?member=NM999999'));
  expect(missingMember?.status()).toBe(404);
  await expect(page.locator('h1')).toHaveText('Member not found');
  await expect(page.locator('#content')).toContainText('No member with that number exists');
  await capture(page, info, 'member-not-found');
  await page.getByRole('link', { name: 'Back to members', exact: true }).click();
  await expect(page.locator('h1')).toHaveText('Members');

  const missingRequest = await page.goto(at(instance, 'RequestDetail.aspx?request=MR999999'));
  expect(missingRequest?.status()).toBe(404);
  await expect(page.locator('h1')).toHaveText('Request not found');
  await page.getByRole('link', { name: 'Back to requests', exact: true }).click();
  await expect(page.locator('h1')).toHaveText('Requests');
  await expect(page.locator('#ctl00_MainContent_grdRequests')).toBeVisible();
});

test('a postback on a long page restores the scroll position and the focused control', async ({ page, instance }, info) => {
  await page.setViewportSize({ width: 1280, height: 420 });
  await page.goto(at(instance, 'Members.aspx'));
  const grid = page.locator('#ctl00_MainContent_grdMembers');
  const lastExpander = page.locator('#ctl00_MainContent_grdMembers_ctl21_lnkExpand');
  await lastExpander.scrollIntoViewIfNeeded();
  const scrolled = await page.evaluate(() => Math.round(window.scrollY));
  expect(scrolled).toBeGreaterThan(0);
  await capture(page, info, 'scroll-before-postback', { fullPage: false });

  await markDocument(page);
  await lastExpander.click();
  await expect(grid.locator('tr.grid-detail')).toHaveCount(1);
  expect(await documentWasReplaced(page)).toBe(true);
  await expect(page.locator('#__SCROLLPOSITIONY')).toHaveAttribute('value', scrolled.toString());
  await expect(page.locator('#__LASTFOCUS')).toHaveAttribute('value', 'ctl00_MainContent_grdMembers_ctl21_lnkExpand');
  await expect.poll(() => page.evaluate(() => Math.round(window.scrollY))).toBe(scrolled);
  await expect(lastExpander).toBeFocused();
  await expect(lastExpander).toHaveText('-');
  await expect(grid.locator('tr.grid-detail')).toContainText('Version');
  await capture(page, info, 'scroll-and-focus-restored-after-postback', { fullPage: false });
});

test('grid row control names are positional, so one name targets different records on other pages and sorts', async ({ page, instance, adminRequest }, info) => {
  const { members } = await bankState(adminRequest, instance);
  const byNumber = [...members.items].sort((a, b) => a.memberNumber.localeCompare(b.memberNumber));
  await page.goto(at(instance, 'Members.aspx'));
  const grid = page.locator('#ctl00_MainContent_grdMembers');
  const memberNumbers = grid.locator('tr.grid-row td:nth-child(2), tr.grid-alt td:nth-child(2)');
  const firstRowExpand = page.locator('#ctl00_MainContent_grdMembers_ctl02_lnkExpand');
  const firstRowTarget = "javascript:__doPostBack('ctl00$MainContent$grdMembers$ctl02$lnkExpand','')";

  await expect(memberNumbers.first()).toHaveText(byNumber[0]?.memberNumber ?? '');
  await expect(firstRowExpand).toHaveAttribute('href', firstRowTarget);
  await capture(page, info, 'positional-names-page-1');

  await grid.locator('.grid-pager a', { hasText: /^2$/u }).click();
  await expect(memberNumbers.first()).toHaveText(byNumber[20]?.memberNumber ?? '');
  await expect(firstRowExpand).toHaveAttribute('href', firstRowTarget);
  await capture(page, info, 'positional-names-page-2');
  await firstRowExpand.click();
  await expect(grid.locator('tr.grid-detail')).toContainText(byNumber[20]?.email ?? '');

  // Back restores the page-2 document from cache; a sort posted from it is judged against its own state.
  await page.goBack();
  await grid.locator('.grid-header a', { hasText: 'Member #' }).click();
  await expect(memberNumbers.first()).toHaveText(byNumber[byNumber.length - 1]?.memberNumber ?? '');
  await expect(firstRowExpand).toHaveAttribute('href', firstRowTarget);
});

test('Update on an editable grid row commits, redirects, and rebuilds the grid with regenerated row controls', async ({ page, instance, adminRequest }, info) => {
  const { members, accounts } = await bankState(adminRequest, instance);
  const account = accounts.items.find((item) => item.status === 'open');
  const owner = members.items.find((item) => item.id === account?.memberId);
  if (account === undefined || owner === undefined) throw new Error('Seed has no open account.');
  const accountNumber = account.accountNumber;
  await page.goto(at(instance, `MemberDetail.aspx?member=${owner.memberNumber}`));
  const grid = page.locator('#ctl00_MainContent_grdAccounts');
  const prefix = 'ctl00$MainContent$grdAccounts$';
  const editNames = await controlNames(grid);
  expect(editNames.every((name) => name.startsWith(prefix) && name.endsWith('$lnkEdit'))).toBe(true);
  const row = grid.locator('tr', { hasText: accountNumber });
  await expect(row.locator('td').nth(2)).toHaveText(account.nickname);

  await row.getByRole('link', { name: 'Edit', exact: true }).click();
  await expect(grid.locator('tr.editing')).toHaveCount(1);
  const editingNames = await controlNames(grid);
  for (const suffix of ['$txtNickname', '$ddlDelivery', '$lnkUpdate', '$lnkCancel']) {
    expect(editingNames.some((name) => name.startsWith(prefix) && name.endsWith(suffix))).toBe(true);
  }
  const nickname = grid.locator('input[name$="$txtNickname"]');
  await expect(nickname).toHaveValue(account.nickname);
  await nickname.fill('Rainy day fund');
  await grid.locator('select[name$="$ddlDelivery"]').selectOption('paper');
  await capture(page, info, 'grid-row-editing');
  const editingToken = await page.locator('#__VIEWSTATE').getAttribute('value');

  await markDocument(page);
  const update = postResponse(page);
  await grid.getByRole('link', { name: 'Update', exact: true }).click();
  expect((await update).status()).toBe(303);
  await expect(notice(page)).toHaveText('Account preferences updated.');
  expect(await documentWasReplaced(page)).toBe(true);
  await expect(page).toHaveURL(/\/MemberDetail\.aspx\?member=\w+&msg=account-updated$/u);
  expect(await controlNames(grid)).toEqual(editNames);
  expect(await page.locator('#__VIEWSTATE').getAttribute('value')).not.toBe(editingToken);
  await expect(grid.locator('tr.editing')).toHaveCount(0);
  await expect(row.locator('td').nth(2)).toHaveText('Rainy day fund');
  await capture(page, info, 'grid-rebuilt-after-update');

  const after = await bankState(adminRequest, instance);
  const saved = after.accounts.items.find((item) => item.accountNumber === accountNumber);
  expect([saved?.nickname, saved?.statementDelivery]).toEqual(['Rainy day fund', 'paper']);
});

test('the request editor rebuilds its account dropdown from the posted member and rejects a forged value', async ({ page, instance, adminRequest }, info) => {
  const { members, accounts } = await bankState(adminRequest, instance);
  const member = members.items.find((item) => accounts.items.some((account) => account.memberId === item.id));
  if (member === undefined) throw new Error('Seed has no member with accounts.');
  const memberNumber = member.memberNumber;
  await page.goto(at(instance, 'RequestEdit.aspx'));
  const account = control(page, 'ddlAccount');
  const requested = control(page, 'ddlRequested');
  await expect(account).toContainText('(enter member first)');

  // The account list is rebuilt from the posted member on every postback.
  await control(page, 'txtMember').fill(memberNumber);
  await markDocument(page);
  await choose(page, requested, 'account.nickname.update');
  expect(await documentWasReplaced(page)).toBe(true);
  await expect(page.locator('.field-help', { hasText: 'account.nickname.update' })).toBeVisible();
  const ownAccount = accounts.items.find((item) => item.memberId === member.id);
  if (ownAccount === undefined) throw new Error('No account.');
  await expect(account.locator('option', { hasText: ownAccount.accountNumber })).toHaveCount(1);
  await capture(page, info, 'request-edit-dependent-account-list');

  // Event validation: a value the server did not offer is rejected even when the browser submits it.
  const foreign = accounts.items.find((item) => item.memberId !== member.id);
  if (foreign === undefined) throw new Error('Need a foreign account.');
  await account.evaluate((select, value) => {
    const option = document.createElement('option');
    option.value = value;
    option.text = value;
    select.appendChild(option);
  }, foreign.id);
  const rejected = postResponse(page);
  await account.selectOption(foreign.id);
  expect((await rejected).status()).toBe(400);
  await expect(page.locator('h1')).toHaveText('Invalid postback or callback argument');
  await capture(page, info, 'invalid-postback-for-foreign-account');
  expect((await bankState(adminRequest, instance)).operations).toBe(0);
});

test('validators mark fields with a red asterisk while their messages appear only in the summary above the form', async ({ page, instance, adminRequest }, info) => {
  await page.goto(at(instance, 'MemberNew.aspx'));
  await control(page, 'fld_legalGiven').fill('Ada');
  const invalid = postResponse(page);
  await control(page, 'btnReview').click();
  expect((await invalid).status()).toBe(200);

  const items = summary(page).locator('li');
  await expect(items).toContainText(['Legal family name is required.', 'Birth date is required.']);
  await expect(summary(page)).toContainText('Please correct the following:');
  const validators = page.locator('.validator');
  await expect(validators).toHaveCount(2);
  await expect(validators).toHaveText(['*', '*']);
  await expect(validators.first()).toHaveCSS('color', 'rgb(255, 0, 0)');
  const form = page.locator('table.form').first();
  await expect(form).not.toContainText('must');
  const summaryBox = await summary(page).boundingBox();
  const formBox = await form.boundingBox();
  expect(summaryBox !== null && formBox !== null && summaryBox.y + summaryBox.height <= formBox.y).toBe(true);
  await expect(control(page, 'fld_legalGiven')).toHaveValue('Ada');
  await capture(page, info, 'validation-summary-and-markers');
  expect((await bankState(adminRequest, instance)).operations).toBe(0);

  await control(page, 'fld_legalFamily').fill('Lovelace');
  await control(page, 'fld_birthDate').fill('1915-12-10');
  await commitOperation(page);
  await expect(page.locator('h1')).toContainText('Receipt');
  const created = (await bankState(adminRequest, instance)).members.items.find((member) => member.displayName === 'Ada Lovelace');
  expect(created).not.toBeUndefined();
});

test('refreshing a review resubmits its postback; refreshing a committed receipt is a GET that writes nothing', async ({ page, instance, adminRequest }, info) => {
  const { accounts } = await bankState(adminRequest, instance);
  const account = accounts.items.find((item) => item.status === 'open');
  if (account === undefined) throw new Error('Seed has no open account.');
  const accountNumber = account.accountNumber;
  await page.goto(at(instance, `Operation.aspx?op=cash.deposit&account=${accountNumber}`));
  await expect(control(page, 'btnReview')).toBeVisible();
  await control(page, 'fld_amount').fill('40.00');
  await control(page, 'fld_description').fill('Branch counter deposit');
  const reviewRequest = page.waitForRequest((request) => request.isNavigationRequest() && request.method() === 'POST');
  await control(page, 'btnReview').click();
  const reviewBody = (await reviewRequest).postData();
  await expect(reviewPanel(page)).toBeVisible();
  await expect(reviewPanel(page)).toContainText('40.00');

  // Reload of a postback result resubmits the same token and event and recomputes the same view.
  const beforeReload = await requestNumber(page);
  const resubmission = page.waitForRequest((request) => request.isNavigationRequest());
  await page.reload();
  const resubmitted = await resubmission;
  expect(resubmitted.method()).toBe('POST');
  expect(resubmitted.postData()).toBe(reviewBody);
  await expect(reviewPanel(page)).toBeVisible();
  expect(await requestNumber(page)).toBeGreaterThan(beforeReload);
  expect((await bankState(adminRequest, instance)).operations).toBe(0);
  await capture(page, info, 'review-after-refresh');

  const commit = postResponse(page);
  await control(page, 'btnCommit').click();
  expect((await commit).status()).toBe(303);
  await expect(page).toHaveURL(/\/Receipt\.aspx\?no=[^&]+&msg=posted$/u);
  const receiptUrl = page.url();
  const committed = await bankState(adminRequest, instance);
  expect(committed.operations).toBe(1);

  // Post/Redirect/Get: refreshing the receipt is a plain GET and cannot post again.
  const refresh = page.waitForRequest((request) => request.isNavigationRequest());
  await page.reload();
  expect((await refresh).method()).toBe('GET');
  await expect(page).toHaveURL(receiptUrl);
  expect(await bankState(adminRequest, instance)).toEqual(committed);
  await capture(page, info, 'receipt-after-refresh');

  // Back restores the review from cache; posting from it again returns the stored receipt, not a second deposit.
  const receiptRequest = await requestNumber(page);
  await page.goBack();
  await expect(reviewPanel(page)).toBeVisible();
  expect(await requestNumber(page)).toBeLessThan(receiptRequest);
  await control(page, 'btnCommit').click();
  await expect(page).toHaveURL(receiptUrl);
  expect((await bankState(adminRequest, instance)).operations).toBe(1);
});
