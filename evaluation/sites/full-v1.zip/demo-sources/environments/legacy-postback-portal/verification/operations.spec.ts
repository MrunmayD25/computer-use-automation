import type { Locator, Page } from '@playwright/test';

import { at, bankState, createInstance, expect, test } from './fixtures.js';
import { addNote, commitOperation, control, noteTexts, openOperation, summary } from './portal-ui.js';

/** Postbacks replace the whole document, so wait for the new one before reading it. */
async function replacing(page: Page, action: () => Promise<void>): Promise<void> {
  const replaced = page.waitForEvent('load');
  await action();
  await replaced;
}

async function choose(page: Page, id: string, value: Parameters<Locator['selectOption']>[0]): Promise<void> {
  await replacing(page, async () => {
    await control(page, id).selectOption(value);
  });
}

test('the menu and quick search reach every module', async ({ page, instance, adminRequest, pageErrors }) => {
  const { members } = await bankState(adminRequest, instance);
  await page.goto(at(instance, 'Default.aspx'));
  for (const [label, heading] of [
    ['Members', 'Members'],
    ['Accounts', 'Accounts'],
    ['Transactions', 'Transactions'],
    ['Statements', 'Statements ·'],
    ['Cases', 'Servicing cases'],
    ['Documents', 'Documents'],
    ['Payments', 'Payments'],
    ['Cards & Disputes', 'Cards and disputes'],
    ['Loans', 'Loans'],
    ['Batches & Reconciliation', 'Batches and reconciliation'],
    ['Maintenance Requests', 'Requests'],
    ['Approvals', 'Approvals'],
    ['Saved Searches', 'Saved searches'],
    ['Activity', 'Activity'],
    ['Operator', 'Operator'],
  ] as const) {
    await page.locator('#menu').getByRole('link', { name: label, exact: true }).click();
    await expect(page.locator('h1')).toContainText(heading);
    await expect(page.locator('#menu a.selected')).toHaveText(label);
  }

  const member = members.items[0];
  if (member === undefined) throw new Error('Seed has no members.');
  await page.locator('#menubar input[type="text"]').fill(member.memberNumber);
  await page.locator('#menubar input[type="text"]').press('Enter');
  await expect(page.locator('#ctl00_MainContent_grdMembers tr.grid-row')).toHaveCount(1);
  await expect(page.locator('#ctl00_MainContent_grdMembers')).toContainText(member.memberNumber);
  expect(pageErrors).toEqual([]);
});

test('members are searched, opened, annotated, and given requests', async ({ page, instance, adminRequest }) => {
  const { members } = await bankState(adminRequest, instance);
  const member = members.items[0];
  if (member === undefined) throw new Error('Seed has no members.');
  const memberNumber = member.memberNumber;
  await page.goto(at(instance, 'Members.aspx'));
  await control(page, 'txtQ').fill(memberNumber);
  await control(page, 'txtQ').press('Enter');
  await expect(page.locator('#ctl00_MainContent_grdMembers tr.grid-row')).toHaveCount(1);
  await page.locator('#ctl00_MainContent_grdMembers').getByRole('link', { name: memberNumber, exact: true }).click();
  await expect(page.locator('h1')).toHaveText(`Member ${memberNumber}`);

  await addNote(page, 'Called about branch hours.');
  await expect(noteTexts(page).first()).toHaveText('Called about branch hours.');

  await page.getByRole('link', { name: 'New request for this member', exact: true }).click();
  await expect(page.locator('h1')).toHaveText('New maintenance request');
  await expect(control(page, 'txtMember')).toHaveValue(memberNumber);
});

test('accounts are filtered, opened through the operation form, and closed after review', async ({ page, instance, adminRequest }) => {
  const { members } = await bankState(adminRequest, instance);
  const member = members.items[0];
  if (member === undefined) throw new Error('Seed has no members.');
  const memberNumber = member.memberNumber;

  await page.goto(at(instance, 'Accounts.aspx'));
  await control(page, 'txtQ').fill(memberNumber);
  await control(page, 'txtQ').press('Enter');
  await expect(page.locator('#ctl00_MainContent_grdAccounts')).toContainText(memberNumber);

  await openOperation(page, instance, `op=account.open&member=${memberNumber}`);
  const product = control(page, 'fld_productId');
  const firstProduct = await product.locator('option').nth(0).getAttribute('value');
  expect(firstProduct ?? '').not.toBe('');
  await product.selectOption(firstProduct ?? '');
  await control(page, 'fld_nickname').fill('Holiday fund');
  await control(page, 'fld_statementDelivery').selectOption('paper');
  const receiptNumber = await commitOperation(page);
  expect(receiptNumber).not.toBe('');
  const opened = (await bankState(adminRequest, instance)).accounts.items.find((item) => item.nickname === 'Holiday fund');
  expect(opened).not.toBeUndefined();

  // Fund it, then try to close: the review refuses while a balance remains.
  await openOperation(page, instance, `op=cash.deposit&account=${opened?.accountNumber}`);
  await control(page, 'fld_amount').fill('250.00');
  await control(page, 'fld_description').fill('Opening deposit');
  await commitOperation(page);

  await openOperation(page, instance, `op=account.close&account=${opened?.accountNumber}`);
  await control(page, 'fld_reason').fill('Member request');
  const refused = page.waitForResponse((response) => response.request().method() === 'POST');
  await control(page, 'btnReview').click();
  expect((await refused).status()).toBe(422);
  await expect(summary(page)).toContainText('zero');
});

test('a transfer binds both account versions and can be changed before posting', async ({ page, instance, adminRequest }) => {
  const { accounts, datasetId } = await bankState(adminRequest, instance);
  const memberAccounts = new Map<string, typeof accounts.items>();
  for (const account of accounts.items) {
    const list = memberAccounts.get(account.memberId) ?? [];
    list.push(account);
    memberAccounts.set(account.memberId, list);
  }
  const pair = [...memberAccounts.values()].find((list) => list.filter((item) => item.status === 'open').length >= 2);
  if (pair === undefined) throw new Error('No member with two open accounts.');
  const [source, destination] = pair.filter((item) => item.status === 'open');
  if (source === undefined || destination === undefined) throw new Error('Need two accounts.');

  // Transfers need the payments-maker operator, so this test drives a second session as OP0003.
  const maker = await createInstance(adminRequest, { datasetId, actorNumber: 'OP0003' });
  await page.goto(at(maker, `Operation.aspx?op=transfer.internal&account=${source.accountNumber}`));
  await control(page, 'fld_destination').fill(destination.accountNumber);
  await control(page, 'fld_amount').fill('5.00');
  await control(page, 'fld_description').fill('Move to savings');
  await control(page, 'btnReview').click();
  await expect(page.locator('#reviewPanel')).toContainText(destination.accountNumber);
  await control(page, 'btnClear').click();
  await expect(control(page, 'fld_amount')).toHaveValue('5.00');
  await commitOperation(page);

  const after = await bankState(adminRequest, instance);
  const moved = after.accounts.items.find((item) => item.accountNumber === source.accountNumber);
  expect(moved?.postedBalanceMinorUnits).toBe(source.postedBalanceMinorUnits - 500);
});

test('statements follow the account dropdown and export the chosen period', async ({ page, instance, adminRequest }) => {
  const { accounts } = await bankState(adminRequest, instance);
  const account = accounts.items.find((item) => item.status === 'open');
  if (account === undefined) throw new Error('No account.');
  await page.goto(at(instance, 'Statements.aspx'));
  await choose(page, 'txtAccount', account.accountNumber);
  await expect(page.locator('h1')).toContainText(`Statements · ${account.accountNumber}`);
  const firstPeriod = page.locator('table.grid tr.grid-row td a').first();
  const period = await firstPeriod.innerText();
  await firstPeriod.click();
  await expect(page.getByRole('heading', { name: `Statement ${period}`, exact: true })).toBeVisible();
  await expect(page.locator('table.details')).toContainText('Closing');

  const download = page.waitForEvent('download');
  await page.locator('table.grid tr.grid-row').first().getByRole('button', { name: 'CSV', exact: true }).click();
  expect((await download).suggestedFilename()).toBe(`${account.accountNumber}-${period}.csv`);
});

test('activity filters by kind and lists the committed operation events', async ({ page, instance, adminRequest }) => {
  const { members } = await bankState(adminRequest, instance);
  const member = members.items[0];
  if (member === undefined) throw new Error('Seed has no members.');
  const memberNumber = member.memberNumber;
  await page.goto(at(instance, `MemberDetail.aspx?member=${memberNumber}`));
  await addNote(page, 'Activity check note.');

  await page.goto(at(instance, 'Activity.aspx'));
  await control(page, 'txtKind').fill('member.note.add');
  await control(page, 'txtKind').press('Enter');
  const kinds = await page.locator('#ctl00_MainContent_grdActivity tr.grid-row td:nth-child(2), #ctl00_MainContent_grdActivity tr.grid-alt td:nth-child(2)').allInnerTexts();
  expect(kinds.length).toBeGreaterThan(0);
  expect(new Set(kinds)).toEqual(new Set(['member.note.add']));
  await expect(page.locator('#ctl00_MainContent_grdActivity')).toContainText(`General note added to ${memberNumber}.`);
});

test('a request is drafted, submitted, reviewed, and processed across operators', async ({ page, context, instance, adminRequest }) => {
  const { members, datasetId } = await bankState(adminRequest, instance);
  const member = members.items[0];
  if (member === undefined) throw new Error('Seed has no members.');
  const memberNumber = member.memberNumber;

  await page.goto(at(instance, 'RequestEdit.aspx'));
  await control(page, 'txtMember').fill(memberNumber);
  await control(page, 'ddlCategory').selectOption('other');
  await control(page, 'txtSubject').fill('Nickname tidy-up');
  await control(page, 'ddlRequested').selectOption('member.note.add');
  await control(page, 'txtRequestedJson').fill(JSON.stringify({ memberId: member.id, visibility: 'general', text: 'Tidied at the branch' }));
  await control(page, 'txtReason').fill('Counter request');
  await control(page, 'btnSave').click();
  await expect(page.locator('h1')).toContainText('Request MR');
  const requestNumber = new URL(page.url()).searchParams.get('request') ?? '';
  expect(requestNumber).toMatch(/^MR/u);

  await page.getByRole('link', { name: 'Submit for review', exact: true }).click();
  await expect(page.locator('h1')).toContainText('Submit');
  await control(page, 'btnReview').click();
  await expect(page.locator('#reviewPanel')).toBeVisible();
  await control(page, 'btnCommit').click();
  await expect(page.locator('h1')).toContainText('Receipt');

  // Review and processing need supervisory authority, so a second session signs on as OP0005.
  const supervisor = await createInstance(adminRequest, { datasetId, actorNumber: 'OP0005' });
  const desk = await context.newPage();
  await desk.goto(at(supervisor, `Operation.aspx?op=maintenance.request.review&request=${requestNumber}`));
  await control(desk, 'fld_decision').selectOption('approve');
  await control(desk, 'fld_reason').fill('Looks complete.');
  await commitOperation(desk);

  // The servicer applies the requested change itself and hands its receipt id to the processor.
  await page.goto(at(instance, `Operation.aspx?op=member.note.add&member=${memberNumber}`));
  await control(page, 'fld_visibility').selectOption('general');
  await control(page, 'fld_text').fill('Tidied at the branch');
  await commitOperation(page);
  const appliedReceiptId = await page.locator('table.details tr').filter({ hasText: 'Receipt id' }).locator('td').innerText();

  await desk.goto(at(supervisor, `Operation.aspx?op=maintenance.request.process&request=${requestNumber}`));
  await control(desk, 'fld_reason').fill('Change applied at the branch.');
  await control(desk, 'fld_appliedReceiptId').fill(appliedReceiptId);
  await commitOperation(desk);
  await desk.close();

  await page.goto(at(instance, `RequestDetail.aspx?request=${requestNumber}`));
  await expect(page.locator('h1')).toHaveText(`Request ${requestNumber}`);
  await expect(page.locator('table.details').first()).toContainText('applied');
  // draft.save + draft.amend (the reason travels in a follow-up amend) + submit + review + apply-note + process.
  const after = await bankState(adminRequest, instance);
  expect(after.operations).toBe(6);
});
