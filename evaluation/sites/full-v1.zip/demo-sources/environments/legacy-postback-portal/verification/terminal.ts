import { expect, type APIRequestContext } from '@playwright/test';

const ROWS = 24;
const COLUMNS = 80;

export interface Screen {
  sequence: number;
  screenId: string;
  fields: { address: number; row: number; column: number; length: number; value: string }[];
  cursor: { row: number; column: number };
  message: { text: string; severity: string } | null;
}

/** Row text of a screen as the operator sees it, one string per row. */
export function rows(screen: Screen): string[] {
  const lines = Array.from({ length: ROWS }, () => '');
  for (const field of [...screen.fields].sort((a, b) => a.address - b.address)) {
    const line = lines[field.row] ?? '';
    lines[field.row] = `${line.padEnd(field.column)}${field.value}`;
  }
  return lines.map((line) => line.replace(/\s+$/u, ''));
}

export const textOf = (screen: Screen): string => rows(screen).join('\n');

/**
 * Drives one terminal-host session the way its browser client does: it answers the latest
 * screen by sequence and sends only typed fields, addressed by row and column.
 */
export class Terminal {
  private constructor(
    private readonly request: APIRequestContext,
    private readonly origin: string,
    readonly sessionId: string,
    public screen: Screen,
  ) {}

  static async open(request: APIRequestContext, origin: string): Promise<Terminal> {
    const opened = await request.post(`${origin}/api/sessions`);
    expect(opened.status()).toBe(201);
    const body = (await opened.json()) as { sessionId: string; screen: Screen };
    return new Terminal(request, origin, body.sessionId, body.screen);
  }

  get text(): string {
    return textOf(this.screen);
  }

  get message(): string {
    return this.screen.message?.text ?? '';
  }

  /** Sends an attention key with typed fields as `[row, column, value]`. */
  async send(aid: string, typed: readonly (readonly [number, number, string])[] = []): Promise<Screen> {
    const response = await this.request.post(`${this.origin}/api/sessions/${this.sessionId}/input`, {
      data: {
        sequence: this.screen.sequence,
        aid,
        cursor: this.screen.cursor,
        fields: typed.map(([row, column, value]) => ({ address: row * COLUMNS + column, value })),
      },
    });
    const body = await response.text();
    if (response.status() !== 200) {
      throw new Error(`Terminal input failed with HTTP ${String(response.status())}: ${body}`);
    }
    this.screen = JSON.parse(body) as Screen;
    return this.screen;
  }

  /** Asserts the destination screen id so navigation mistakes fail loudly. */
  async go(aid: string, typed: readonly (readonly [number, number, string])[], expectScreenId: string): Promise<void> {
    await this.send(aid, typed);
    if (this.screen.screenId !== expectScreenId) {
      throw new Error(`Expected ${expectScreenId} but reached ${this.screen.screenId}: ${this.message}\n${this.text}`);
    }
  }

  /** Index of the list row (from row 7) whose text contains `needle`. */
  listIndex(needle: string): number {
    const index = rows(this.screen).slice(7, 19).findIndex((line) => line.includes(needle));
    if (index < 0) throw new Error(`${needle} is not listed on ${this.screen.screenId}:\n${this.text}`);
    return index;
  }
}
