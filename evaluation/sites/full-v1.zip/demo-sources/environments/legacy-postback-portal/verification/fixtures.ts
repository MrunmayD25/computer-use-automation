import { randomUUID } from 'node:crypto';
import { copyFileSync, mkdirSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { test as base, expect, type APIRequestContext, type Page, type TestInfo } from '@playwright/test';
import { z } from 'zod';

import { startEnvironment, type EnvironmentConfig, type EnvironmentHandle } from '../src/main.js';
import { ensureTemplate } from '../test/template.js';

const createdSchema = z.object({ instanceId: z.string(), entryUrl: z.string(), datasetId: z.string() });
export type Instance = z.infer<typeof createdSchema>;

/** The `/instances/:id/state` body BranchNet's administration listener serves. */
const stateSchema = z.object({
  datasetId: z.string(),
  revision: z.number().int(),
  /** Committed commands on the bound dataset — the monotonic change counter. */
  operations: z.number().int(),
  summary: z.unknown(),
  members: z.object({
    items: z.array(
      z.looseObject({ id: z.string(), memberNumber: z.string(), displayName: z.string(), email: z.string().nullable(), status: z.string() }),
    ),
  }),
  accounts: z.object({
    items: z.array(
      z.looseObject({
        id: z.string(),
        accountNumber: z.string(),
        memberId: z.string(),
        status: z.string(),
        nickname: z.string(),
        statementDelivery: z.string(),
        postedBalanceMinorUnits: z.number(),
        availableBalanceMinorUnits: z.number(),
      }),
    ),
  }),
});
export type InstanceState = z.infer<typeof stateSchema>;

/** Reads an instance's persisted state from the administration listener. */
export async function instanceState(adminRequest: APIRequestContext, instanceId: string): Promise<InstanceState> {
  const response = await adminRequest.get(`/instances/${instanceId}/state`);
  expect(response.status()).toBe(200);
  return stateSchema.parse(await response.json());
}

/** A disposable seeded database file; deleting the directory removes it. */
export interface DatabaseCopy {
  readonly directory: string;
  readonly path: string;
  readonly [Symbol.asyncDispose]: () => Promise<void>;
}

/** Copies the cached seeded world into a private temporary directory. */
export async function copySeededDatabase(): Promise<DatabaseCopy> {
  const template = await ensureTemplate();
  const directory = mkdtempSync(join(tmpdir(), 'branchnet-verify-'));
  const path = join(directory, 'world.sqlite');
  copyFileSync(template.path, path);
  return {
    directory,
    path,
    [Symbol.asyncDispose]() {
      rmSync(directory, { recursive: true, force: true });
      return Promise.resolve();
    },
  };
}

/** The named world every disposable copy carries. */
export const TEST_WORLD = 'branchnet-test-v1';

/**
 * Saves a screenshot under the run's `browser/` directory and attaches it to the report.
 * Pass `fullPage: false` to keep the viewport, for example to show a restored scroll position.
 */
export async function capture(page: Page, info: TestInfo, name: string, options: { fullPage?: boolean } = {}): Promise<void> {
  const path = info.outputPath(`${name}.png`);
  await page.screenshot({ path, fullPage: options.fullPage ?? true });
  await info.attach(name, { path, contentType: 'image/png' });
}

interface WorkerFixtures {
  environment: EnvironmentHandle;
  adminToken: string;
}

interface TestFixtures {
  adminRequest: APIRequestContext;
  /** A fresh session on its own isolated dataset. */
  instance: Instance;
  /** Uncaught page errors from every page in the test's browser context. */
  pageErrors: string[];
}

export function parseInstance(body: unknown): Instance {
  return createdSchema.parse(body);
}

export async function createInstance(adminRequest: APIRequestContext, body: { seed?: number; datasetId?: string; actorNumber?: string } = { seed: 7 }): Promise<Instance> {
  const response = await adminRequest.post('/instances', { data: body });
  expect(response.status()).toBe(201);
  return parseInstance(await response.json());
}

export async function bankState(adminRequest: APIRequestContext, instance: Instance): Promise<InstanceState> {
  return instanceState(adminRequest, instance.instanceId);
}

/**
 * Starts a separate environment for tests that need their own configuration, such as a controlled clock.
 * `run` also receives the temporary database so another process can share the same file.
 */
export async function withEnvironment(
  config: Omit<EnvironmentConfig, 'adminToken' | 'databasePath' | 'port' | 'adminPort'>,
  run: (environment: EnvironmentHandle, adminToken: string, database: { directory: string; path: string }) => Promise<void>,
): Promise<void> {
  const database = await copySeededDatabase();
  const adminToken = randomUUID();
  const environment = await startEnvironment({ port: 0, adminPort: 0, demo: false, world: TEST_WORLD, ...config, adminToken, databasePath: database.path });
  try {
    await run(environment, adminToken, { directory: database.directory, path: database.path });
  } finally {
    await environment.close();
    await database[Symbol.asyncDispose]();
  }
}

export const test = base.extend<TestFixtures, WorkerFixtures>({
  adminToken: [
    async ({ browserName }, use) => {
      await use(`${browserName}-${randomUUID()}`);
    },
    { scope: 'worker' },
  ],
  environment: [
    async ({ adminToken }, use) => {
      const database = await copySeededDatabase();
      const environment = await startEnvironment({ port: 0, adminPort: 0, adminToken, demo: false, world: TEST_WORLD, databasePath: database.path });
      try {
        await use(environment);
      } finally {
        await environment.close();
        rmSync(database.directory, { recursive: true, force: true });
      }
    },
    // Cold seed generation has its own budget; UI scenarios retain their 45s deadline.
    { scope: 'worker', timeout: 120_000 },
  ],
  adminRequest: async ({ playwright, environment, adminToken }, use) => {
    const request = await playwright.request.newContext({
      baseURL: environment.origins.admin,
      extraHTTPHeaders: { Authorization: `Bearer ${adminToken}` },
    });
    try {
      await use(request);
    } finally {
      await request.dispose();
    }
  },
  instance: async ({ adminRequest }, use) => {
    await use(await createInstance(adminRequest));
  },
  pageErrors: async ({ context }, use) => {
    const errors: string[] = [];
    context.on('page', (page) => page.on('pageerror', (error) => errors.push(error.message)));
    await use(errors);
  },
});

export { expect };

export function at(instance: Instance, path: string): string {
  return new URL(path, instance.entryUrl).href;
}

/** Marks the current document so a later check can prove the browser replaced it. */
export async function markDocument(page: Page): Promise<void> {
  await page.evaluate(() => {
    Object.assign(window, { __branchnetMarker: true });
  });
}

export async function documentWasReplaced(page: Page): Promise<boolean> {
  return page.evaluate(() => !('__branchnetMarker' in window));
}

export async function requestNumber(page: Page): Promise<number> {
  const footer = await page.locator('#footer').innerText();
  return Number(/Request (\d+)/u.exec(footer)?.[1]);
}

/** Ensures the verification database directory exists before tests run. */
export function ensureArtifactRoot(): void {
  mkdirSync(join(import.meta.dirname, 'artifacts'), { recursive: true });
}
