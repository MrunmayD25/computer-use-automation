import { spawn } from 'node:child_process';
import { access, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

import type { APIRequestContext, PlaywrightWorkerArgs } from '@playwright/test';

/** How a launched application process ended. A clean shutdown is `{ code: 0, signal: null }`. */
export interface AppExit {
  readonly code: number | null;
  readonly signal: NodeJS.Signals | null;
}

/** One compiled application running as its own OS process. */
export interface AppProcess {
  readonly name: string;
  /** Origins parsed from the `--verbose` startup lines on stderr, keyed as requested. */
  readonly origins: Readonly<Record<string, string>>;
  /** Bearer token the process wrote to its `--admin-token-file`. */
  readonly adminToken: string;
  /** Everything the process wrote to stdout and stderr so far. */
  output(): string;
  /** Sends SIGTERM and waits for exit; kills the process and throws when it does not exit in time. */
  stop(): Promise<AppExit>;
}

const environments = fileURLToPath(new URL('../../', import.meta.url));
const startupTimeoutMs = 20_000;
const shutdownTimeoutMs = 10_000;

interface LaunchSpec {
  readonly name: string;
  readonly cli: string;
  readonly args: readonly string[];
  /** Admin token file; absent for applications without an administration listener. */
  readonly tokenFile?: string;
  /** Each pattern's first capture group is the origin. */
  readonly origins: Readonly<Record<string, RegExp>>;
}

async function launch(spec: LaunchSpec): Promise<AppProcess> {
  try {
    await access(spec.cli);
  } catch (error) {
    throw new Error(`${spec.name} is not built at ${spec.cli}. Run \`npm run build\` from environments/.`, { cause: error });
  }
  const child = spawn(process.execPath, [spec.cli, ...spec.args], { stdio: ['ignore', 'pipe', 'pipe'] });
  let output = '';
  const exited = new Promise<AppExit>((resolve) => {
    child.once('exit', (code, signal) => resolve({ code, signal }));
  });
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stdout.on('data', (chunk: string) => {
    output += chunk;
  });
  child.stderr.on('data', (chunk: string) => {
    output += chunk;
  });

  const origins = await new Promise<Record<string, string>>((resolve, reject) => {
    const fail = (error: Error): void => {
      clearTimeout(timer);
      clearInterval(poll);
      child.kill('SIGKILL');
      reject(error);
    };
    const timer = setTimeout(() => {
      fail(new Error(`${spec.name} did not report its origins within ${startupTimeoutMs} ms.\n${output}`));
    }, startupTimeoutMs);
    // Startup lines arrive on stderr in chunks; check after each chunk until every origin is present.
    const poll = setInterval(() => {
      const found: Record<string, string> = {};
      for (const [key, pattern] of Object.entries(spec.origins)) {
        const origin = pattern.exec(output)?.[1];
        if (origin === undefined) return;
        found[key] = origin;
      }
      clearTimeout(timer);
      clearInterval(poll);
      resolve(found);
    }, 25);
    child.once('error', fail);
    void exited.then((exit) => {
      fail(new Error(`${spec.name} exited during startup (code ${String(exit.code)}, signal ${String(exit.signal)}).\n${output}`));
    });
  });
  const adminToken = spec.tokenFile === undefined ? '' : (await readFile(spec.tokenFile, 'utf8')).trim();

  return {
    name: spec.name,
    origins,
    adminToken,
    output: () => output,
    async stop() {
      if (child.exitCode !== null || child.signalCode !== null) return exited;
      child.kill('SIGTERM');
      let timer: NodeJS.Timeout | undefined;
      const timedOut = new Promise<'timeout'>((resolve) => {
        timer = setTimeout(() => resolve('timeout'), shutdownTimeoutMs);
      });
      const result = await Promise.race([exited, timedOut]);
      clearTimeout(timer);
      if (result === 'timeout') {
        child.kill('SIGKILL');
        await exited;
        throw new Error(`${spec.name} did not exit within ${shutdownTimeoutMs} ms of SIGTERM.\n${output}`);
      }
      return result;
    },
  };
}

/**
 * Starts the terminal host's compiled CLI against `databasePath` bound to `world`.
 * Meridian Core still runs on the retired demo package in this worktree, so the financial
 * peer for cross-application checks is the terminal host; swap back once it is upgraded.
 */
export function startTerminalHost(databasePath: string, world: string): Promise<AppProcess> {
  return launch({
    name: 'Terminal host',
    cli: join(environments, 'terminal-host-banking/dist/server/main.js'),
    args: ['--port', '0', '--database', databasePath, '--world', world, '--operators', 'OP0001,OP0002,OP0003,OP0004,OP0005,OP0006,OP0007', '--verbose'],
    origins: { ui: /^Terminal host banking listening on (\S+)/mu },
  });
}

/** Starts BranchNet's compiled CLI on ephemeral ports against `databasePath`. */
export function startBranchNet(directory: string, databasePath: string, world = 'branchnet-test-v1'): Promise<AppProcess> {
  const tokenFile = join(directory, 'branchnet.token');
  return launch({
    name: 'BranchNet',
    cli: join(environments, 'legacy-postback-portal/dist/src/main.js'),
    args: ['--port', '0', '--admin-port', '0', '--admin-token-file', tokenFile, '--database', databasePath, '--world', world, '--verbose'],
    tokenFile,
    origins: { ui: /^BranchNet UI: (\S+)$/mu, admin: /^BranchNet admin: (\S+)$/mu },
  });
}

/** An administration client for a launched process; dispose it before stopping the process. */
export function adminClient(playwright: PlaywrightWorkerArgs['playwright'], app: AppProcess): Promise<APIRequestContext> {
  const baseURL = app.origins.admin;
  if (baseURL === undefined) throw new Error(`${app.name} reported no admin origin.`);
  return playwright.request.newContext({ baseURL, extraHTTPHeaders: { Authorization: `Bearer ${app.adminToken}` } });
}

/** Stops every process in reverse start order, even when an earlier stop fails, and returns their exits. */
export async function stopAll(apps: readonly AppProcess[]): Promise<AppExit[]> {
  const results = await Promise.allSettled(apps.toReversed().map((app) => app.stop()));
  const failures = results.flatMap((result): unknown[] => (result.status === 'rejected' ? [result.reason] : []));
  if (failures.length > 0) throw new AggregateError(failures, 'An application process did not stop cleanly.');
  return results.flatMap((result) => (result.status === 'fulfilled' ? [result.value] : []));
}
