import { openFinancialDatabase } from '@computer-use/financial-database';
import type { APIRequestContext } from '@playwright/test';

import { capture, copySeededDatabase, expect, instanceState, test, TEST_WORLD, type Instance } from './fixtures.js';
import { addNote, noteTexts, openMember, profileEmail, updateEmail } from './portal-ui.js';
import { startBranchNet, startTerminalHost, stopAll, type AppExit, type AppProcess } from './processes.js';
import { Terminal } from './terminal.js';

/*
 * BranchNet and the terminal host run as separate OS processes from their compiled CLIs, exactly
 * as an operator launches them, so the only thing they share is the SQLite file. Meridian Core
 * still depends on the retired demo package in this worktree; the terminal host is the financial
 * peer until the console upgrade lands.
 */

const MEMBER = 'NM000001';
const BRANCHNET_EMAIL = 'alex.morgan.branchnet@example.test';
const TERMINAL_NOTE = 'Terminal teller note for BranchNet.';
const BRANCHNET_NOTE = 'BranchNet note for the terminal.';

async function attach(admin: APIRequestContext, body: object): Promise<Instance> {
  const response = await admin.post('/instances', { data: body });
  expect(response.status()).toBe(201);
  const body_ = (await response.json()) as { instanceId: string; entryUrl: string; datasetId: string };
  return body_;
}

test('BranchNet and the terminal host share one world dataset and see each other\'s UI changes', async ({ page, playwright }, info) => {
  test.setTimeout(120_000);
  const database = await copySeededDatabase();
  const apps: AppProcess[] = [];
  let exits: AppExit[] | undefined;
  try {
    const world = (() => {
      using inspector = openFinancialDatabase({ path: database.path });
      const bindings = inspector.getNamedWorld(TEST_WORLD);
      const northstar = bindings.find((item) => item.institutionId === 'northstar');
      if (northstar === undefined) throw new Error('World has no northstar binding.');
      return { bindings, northstar };
    })();

    const terminal = await startTerminalHost(database.path, TEST_WORLD);
    apps.push(terminal);
    const branchnet = await startBranchNet(database.directory, database.path);
    apps.push(branchnet);
    const adminOrigin = branchnet.origins.admin;
    if (adminOrigin === undefined) throw new Error('BranchNet reported no admin origin.');
    const branchnetAdmin = await playwright.request.newContext({
      baseURL: adminOrigin,
      extraHTTPHeaders: { Authorization: `Bearer ${branchnet.adminToken}` },
    });
    const terminalRequest = await playwright.request.newContext();
    try {
      const peer = await attach(branchnetAdmin, { datasetId: world.northstar.datasetId });
      expect(peer.datasetId).toBe(world.northstar.datasetId);

      // The teller signs on to northstar (first binding in the world) as OP0002.
      const teller = await Terminal.open(terminalRequest, terminal.origins.ui ?? '');
      const institutionIndex = world.bindings.findIndex((binding) => binding.institutionId === 'northstar');
      await teller.go('enter', [[13, 28, String(institutionIndex + 1)], [14, 28, 'OP0002']], 'THMENU');

      // 1. BranchNet edits the member's email through its operation form.
      await page.goto(peer.entryUrl);
      await openMember(page, MEMBER);
      const seedEmail = await profileEmail(page).innerText();
      await updateEmail(page, BRANCHNET_EMAIL);
      await capture(page, info, '01-branchnet-contact-updated');
      expect((await instanceState(branchnetAdmin, peer.instanceId)).operations).toBe(1);

      // 2. The terminal shows that email on the member's contact screen.
      await teller.go('enter', [[19, 15, '1']], 'THMB01');
      await teller.go('enter', [[3, 11, MEMBER]], 'THMB01');
      await teller.go('enter', [[7 + teller.listIndex(MEMBER), 1, 'S']], 'THMB02');
      expect(teller.text).toContain(MEMBER);
      await teller.go('pf4', [], 'THMB05');
      expect(teller.text).toContain(BRANCHNET_EMAIL);
      await teller.go('pf3', [], 'THMB02');

      // 3. The terminal adds a note; BranchNet shows it on the member's detail page.
      await teller.go('pf5', [], 'THMB07');
      await teller.go('pf6', [], 'THMB08');
      await teller.go('enter', [[6, 1, TERMINAL_NOTE]], 'THMB10');
      await teller.go('enter', [[19, 34, 'Y']], 'THRC01');
      await teller.go('pf3', [], 'THMB07');
      expect(teller.text).toContain(TERMINAL_NOTE);
      const afterTerminal = await instanceState(branchnetAdmin, peer.instanceId);
      expect(afterTerminal.operations).toBe(2);

      await page.goto(new URL(`MemberDetail.aspx?member=${MEMBER}`, peer.entryUrl).href);
      await expect(profileEmail(page)).toHaveText(BRANCHNET_EMAIL);
      await expect(noteTexts(page).first()).toHaveText(TERMINAL_NOTE);
      await capture(page, info, '02-branchnet-sees-terminal-note');

      // 4. BranchNet adds a note; the terminal's notes screen lists it too.
      await addNote(page, BRANCHNET_NOTE);
      await page.goto(new URL(`MemberDetail.aspx?member=${MEMBER}`, peer.entryUrl).href);
      await expect(noteTexts(page).nth(0)).toHaveText(BRANCHNET_NOTE);
      await expect(noteTexts(page).nth(1)).toHaveText(TERMINAL_NOTE);
      await teller.go('pf8', [], 'THMB07');
      expect(teller.text).toContain(BRANCHNET_NOTE);
      expect(teller.text).toContain(TERMINAL_NOTE);
      const finalState = await instanceState(branchnetAdmin, peer.instanceId);
      expect(finalState.datasetId).toBe(world.northstar.datasetId);
      expect(finalState.operations).toBe(3);

      await info.attach('cross-application-evidence', {
        body: JSON.stringify(
          {
            datasetId: world.northstar.datasetId,
            world: TEST_WORLD,
            origins: { terminalHost: terminal.origins, branchnet: branchnet.origins },
            seedEmail,
            sharedOperations: finalState.operations,
            member: { memberNumber: MEMBER, email: BRANCHNET_EMAIL, notes: [BRANCHNET_NOTE, TERMINAL_NOTE] },
          },
          null,
          2,
        ),
        contentType: 'application/json',
      });
    } finally {
      await branchnetAdmin.dispose();
      await terminalRequest.dispose();
    }
  } finally {
    exits = await stopAll(apps);
    await database[Symbol.asyncDispose]();
  }
  // Reached only when the body passed: both processes must have shut down cleanly on SIGTERM.
  expect(exits).toEqual([
    { code: 0, signal: null },
    { code: 0, signal: null },
  ]);
});
