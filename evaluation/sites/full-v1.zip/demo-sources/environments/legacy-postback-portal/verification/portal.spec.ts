import type { Locator } from '@playwright/test';

import {
  at,
  bankState,
  capture,
  documentWasReplaced,
  expect,
  markDocument,
  parseInstance,
  requestNumber,
  test,
  withEnvironment,
} from './fixtures.js';
import { commitOperation, control, summary } from './portal-ui.js';

async function column(grid: Locator, index: number): Promise<string[]> {
  return grid.locator(`tr.grid-row td:nth-child(${index}), tr.grid-alt td:nth-child(${index})`).allInnerTexts();
}

const ascending = (left: string, right: string): number => left.localeCompare(right, 'en-US');

test('paging, sorting, and row expansion replace the whole document', async ({ page, instance, pageErrors }) => {
  await page.goto(at(instance, 'Members.aspx'));
  const grid = page.locator('#ctl00_MainContent_grdMembers');
  await expect(page.locator('#ctl00_MainContent_lblCount')).toContainText('members found');
  await expect(page.locator('h1')).toHaveText('Members');

  await markDocument(page);
  const before = await requestNumber(page);
  await grid.locator('.grid-pager a', { hasText: /^2$/u }).click();
  await expect(grid.locator('.grid-pager span')).toHaveText('2');
  expect(await documentWasReplaced(page)).toBe(true);
  expect(await requestNumber(page)).toBeGreaterThan(before);

  await markDocument(page);
  await grid.locator('tr.grid-row').first().getByRole('link', { name: '+', exact: true }).click();
  await expect(grid.locator('tr.grid-detail')).toHaveCount(1);
  await expect(grid.getByRole('link', { name: '-', exact: true })).toHaveCount(1);
  expect(await documentWasReplaced(page)).toBe(true);

  await markDocument(page);
  await grid.locator('.grid-header a', { hasText: 'Name' }).click();
  expect(await documentWasReplaced(page)).toBe(true);
  await expect(grid.locator('.grid-pager span')).toHaveText('1');
  const names = await column(grid, 3);
  expect(names.length).toBe(20);
  expect(names).toEqual(names.toSorted(ascending));
  expect(pageErrors).toEqual([]);
});

test('Back restores the cached document whose state still posts, and refresh resubmits the postback', async ({ page, instance }) => {
  await page.goto(at(instance, 'Members.aspx'));
  const grid = page.locator('#ctl00_MainContent_grdMembers');
  await grid.locator('.grid-pager a', { hasText: /^2$/u }).click();
  await expect(grid.locator('.grid-pager span')).toHaveText('2');
  await grid.locator('tr.grid-row').first().getByRole('link', { name: '+', exact: true }).click();
  await expect(grid.locator('tr.grid-detail')).toHaveCount(1);

  await page.goBack();
  await expect(grid.locator('tr.grid-detail')).toHaveCount(0);
  await expect(grid.locator('.grid-pager span')).toHaveText('2');

  await grid.locator('tr.grid-alt').first().getByRole('link', { name: '+', exact: true }).click();
  await expect(grid.locator('tr.grid-detail')).toHaveCount(1);
  const beforeRefresh = await requestNumber(page);
  await page.reload();
  await expect(grid.locator('tr.grid-detail')).toHaveCount(1);
  expect(await requestNumber(page)).toBeGreaterThan(beforeRefresh);
});

test('the validation summary names each field and marks it with a red asterisk', async ({ page, instance, adminRequest }) => {
  await page.goto(at(instance, 'MemberNew.aspx'));
  await control(page, 'btnReview').click();
  await expect(summary(page).locator('li').first()).toBeVisible();
  await expect(page.locator('.validator').first()).toHaveText('*');
  await expect(page.locator('.validator').first()).toHaveCSS('color', 'rgb(255, 0, 0)');
  const before = await bankState(adminRequest, instance);
  expect(before.operations).toBe(0);

  await control(page, 'fld_legalGiven').fill('Grace');
  await control(page, 'fld_legalFamily').fill('Hopper');
  await control(page, 'fld_birthDate').fill('1906-12-09');
  await control(page, 'fld_email').fill('grace@example.test');
  await commitOperation(page);
  await expect(page.locator('h1')).toContainText('Receipt');
  const after = await bankState(adminRequest, instance);
  expect(after.operations).toBe(1);
  expect(after.members.items.map((item) => item.displayName || item.memberNumber)).toContain('Grace Hopper');
});

test('editable account rows use regenerated control names and rebuild after Update', async ({ page, instance, adminRequest }) => {
  const { members, accounts } = await bankState(adminRequest, instance);
  const account = accounts.items.find((item) => item.status === 'open' && item.statementDelivery === 'electronic');
  const owner = members.items.find((item) => item.id === account?.memberId);
  if (account === undefined || owner === undefined) throw new Error('Seed has no open account.');
  const memberNumber = owner.memberNumber;
  await page.goto(at(instance, `MemberDetail.aspx?member=${memberNumber}`));
  const grid = page.locator('#ctl00_MainContent_grdAccounts');
  const row = grid.locator('tr', { hasText: account.accountNumber });

  await row.getByRole('link', { name: 'Edit', exact: true }).click();
  const nickname = grid.locator('input[name$="$txtNickname"]');
  await expect(nickname).toHaveAttribute('name', /^ctl00\$MainContent\$grdAccounts\$ctl\d{2}\$txtNickname$/u);
  await expect(grid.locator('tr.editing')).toHaveCount(1);
  await grid.getByRole('link', { name: 'Cancel', exact: true }).click();
  await expect(nickname).toHaveCount(0);

  await row.getByRole('link', { name: 'Edit', exact: true }).click();
  await nickname.fill('Everyday spending');
  const delivery = 'paper';
  await grid.locator('select[name$="$ddlDelivery"]').selectOption(delivery);
  await grid.getByRole('link', { name: 'Update', exact: true }).click();
  await expect(page.locator('#ctl00_MainContent_lblNotice')).toHaveText('Account preferences updated.');
  await expect(row).toContainText('Everyday spending');
  await expect(row).toContainText(delivery);
  await expect(grid.locator('input[name$="$txtNickname"]')).toHaveCount(0);
  await expect(row.getByRole('link', { name: 'Edit', exact: true })).toHaveAttribute('href', /grdAccounts\$ctl\d{2}\$lnkEdit/u);

  const after = await bankState(adminRequest, instance);
  const saved = after.accounts.items.find((item) => item.accountNumber === account.accountNumber);
  expect([after.operations, saved?.nickname, saved?.statementDelivery]).toEqual([2, 'Everyday spending', delivery]);
});

test('two windows commit one record edit and the stale commit is rejected', async ({ context, instance, adminRequest }, info) => {
  const { members } = await bankState(adminRequest, instance);
  const member = members.items[0];
  if (member === undefined) throw new Error('Seed has no members.');
  const memberNumber = member.memberNumber;
  const first = await context.newPage();
  const second = await context.newPage();
  for (const window of [first, second]) {
    await window.goto(at(instance, `Operation.aspx?op=contact.update&member=${memberNumber}`));
    await window.locator('[id$="_fld_email"]').fill('window@example.test');
    await window.locator('[id$="_btnReview"]').click();
    await expect(window.locator('#reviewPanel')).toBeVisible();
  }

  await first.locator('[id$="_fld_email"]').fill('first-window@example.test');
  // Re-review binds the posted values; commit writes version 1 -> 2.
  await first.locator('[id$="_btnReview"]').click();
  await first.locator('[id$="_btnCommit"]').click();
  await expect(first.locator('h1')).toContainText('Receipt');
  const afterFirst = await bankState(adminRequest, instance);
  expect(afterFirst.operations).toBe(1);
  const emailOf = (state: typeof afterFirst) =>
    state.members.items.find((item) => item.memberNumber === memberNumber)?.email ?? '';

  const stale = second.waitForResponse((response) => response.request().method() === 'POST');
  await second.locator('[id$="_btnCommit"]').click();
  expect((await stale).status()).toBe(409);
  await expect(second.locator('#ctl00_MainContent_vsSummary')).toContainText('changed after you opened it');
  await capture(second, info, 'stale-operation-409');
  expect(await bankState(adminRequest, instance)).toEqual(afterFirst);

  // A fresh review rebinds the current version; the second window's commit then succeeds.
  await second.locator('[id$="_btnReview"]').click();
  await expect(second.locator('#reviewPanel')).toBeVisible();
  await second.locator('[id$="_btnCommit"]').click();
  await expect(second.locator('h1')).toContainText('Receipt');
  const afterSecond = await bankState(adminRequest, instance);
  expect(afterSecond.operations).toBe(2);
  expect(emailOf(afterSecond)).toBe('window@example.test');
});

test('expired page state renders 410 with a reload control that recovers', async ({ page }) => {
  let offset = 0;
  await withEnvironment({ now: () => Date.now() + offset }, async (environment, adminToken) => {
    const response = await page.context().request.post(`${environment.origins.admin}/instances`, {
      data: { seed: 7 },
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    const { entryUrl } = parseInstance(await response.json());
    await page.goto(new URL('Members.aspx', entryUrl).href);
    const pager = page.locator('#ctl00_MainContent_grdMembers .grid-pager');
    await expect(pager.locator('a', { hasText: /^2$/u })).toBeVisible();

    offset = 21 * 60_000;
    const expired = page.waitForResponse((candidate) => candidate.request().method() === 'POST');
    await pager.locator('a', { hasText: /^2$/u }).click();
    expect((await expired).status()).toBe(410);
    await expect(page.locator('h1')).toHaveText('This page has expired');
    await expect(page.locator('body')).toContainText('the changes you submitted were not saved');

    await page.getByRole('link', { name: 'Reload this page' }).click();
    await expect(pager.locator('a', { hasText: /^2$/u })).toBeVisible();
    await pager.locator('a', { hasText: /^2$/u }).click();
    await expect(page.locator('#ctl00_MainContent_grdMembers .grid-pager span')).toHaveText('2');
  });
});

test('statement CSV exports download as attachments', async ({ page, instance, adminRequest }) => {
  const { accounts } = await bankState(adminRequest, instance);
  const account = accounts.items.find((item) => item.status === 'open');
  if (account === undefined) throw new Error('Seed has no accounts.');
  await page.goto(at(instance, `Statements.aspx?account=${account.accountNumber}`));
  const rows = page.locator('table.grid tr.grid-row');
  await expect(rows.first()).toBeVisible();
  const download = page.waitForEvent('download');
  await rows.first().getByRole('button', { name: 'CSV', exact: true }).click();
  expect((await download).suggestedFilename()).toMatch(/\.csv$/u);
});

test('the printable request renders in the print layout without the portal chrome', async ({ page, instance, adminRequest }) => {
  const { members } = await bankState(adminRequest, instance);
  const member = members.items[0];
  if (member === undefined) throw new Error('Seed has no members.');
  await page.goto(at(instance, 'RequestEdit.aspx'));
  await control(page, 'txtMember').fill(member.memberNumber);
  await control(page, 'ddlCategory').selectOption('other');
  await control(page, 'txtSubject').fill('Branch hours question');
  await control(page, 'ddlRequested').selectOption('member.note.add');
  await control(page, 'txtRequestedJson').fill(JSON.stringify({ memberId: member.id, visibility: 'general', text: 'Asked about hours' }));
  await control(page, 'txtReason').fill('Member asked at the counter');
  await control(page, 'btnSave').click();
  await expect(page.locator('h1')).toContainText('Request MR');
  const requestNumber = new URL(page.url()).searchParams.get('request') ?? '';

  await page.goto(at(instance, `RequestPrint.aspx?request=${requestNumber}`));
  await expect(page.locator('#menu')).toHaveCount(0);
  await expect(page.locator('h1')).toContainText('maintenance request');
  await expect(page.locator('#content')).toContainText('Branch hours question');
  await expect(page.locator('#content')).toContainText(requestNumber);
});
