import { expect, type Locator, type Page } from '@playwright/test';

/** BranchNet controls by their Web Forms ID suffix, such as `txtNote` for `ctl00_MainContent_txtNote`. */
export const control = (page: Page, id: string): Locator => page.locator(`[id$="_${id}"]`);
export const notice = (page: Page): Locator => page.locator('#ctl00_MainContent_lblNotice');
export const summary = (page: Page): Locator => page.locator('#ctl00_MainContent_vsSummary');
export const reviewPanel = (page: Page): Locator => page.locator('#reviewPanel');

/** Finds a member from the Members module search and opens it, as an operator would. */
export async function openMember(page: Page, memberNumber: string): Promise<void> {
  await page.locator('#menu').getByRole('link', { name: 'Members', exact: true }).click();
  await control(page, 'txtQ').fill(memberNumber);
  await control(page, 'txtQ').press('Enter');
  await expect(page.locator('h1')).toHaveText('Members');
  await expect(page.locator('#ctl00_MainContent_grdMembers tr.grid-row')).toHaveCount(1);
  await page.locator('#ctl00_MainContent_grdMembers').getByRole('link', { name: memberNumber, exact: true }).click();
  await expect(page.locator('h1')).toHaveText(`Member ${memberNumber}`);
}

/**
 * Runs one operation end to end on the open operation form: fill fields, Review, then Commit,
 * landing on the receipt page. Returns the receipt number from the URL.
 */
export async function commitOperation(page: Page, fields: Record<string, string> = {}): Promise<string> {
  for (const [key, value] of Object.entries(fields)) {
    const field = control(page, `fld_${key}`);
    if ((await field.evaluate((el) => el.tagName)) === 'SELECT') {
      await field.selectOption(value);
    } else {
      await field.fill(value);
    }
  }
  await control(page, 'btnReview').click();
  await expect(reviewPanel(page)).toBeVisible();
  const committed = page.waitForResponse((response) => response.request().method() === 'POST');
  await control(page, 'btnCommit').click();
  expect((await committed).status()).toBe(303);
  await expect(page.locator('h1')).toContainText('Receipt');
  return new URL(page.url()).searchParams.get('no') ?? '';
}

/** Opens the operation form for a subject-scoped operation, e.g. `contact.update&member=NM000001`. */
export async function openOperation(page: Page, instance: { entryUrl: string }, query: string): Promise<void> {
  await page.goto(new URL(`Operation.aspx?${query}`, instance.entryUrl).href);
  await expect(control(page, 'btnReview')).toBeVisible();
}

/** Edits the email on the member's contact record through the contact.update operation. */
export async function updateEmail(page: Page, email: string): Promise<void> {
  await page.getByRole('link', { name: 'Update contact', exact: true }).click();
  await control(page, 'fld_email').fill(email);
  await commitOperation(page);
}

/** Adds a note on the open member's detail page. */
export async function addNote(page: Page, text: string): Promise<void> {
  await control(page, 'txtNote').fill(text);
  await control(page, 'btnAddNote').click();
  await expect(notice(page)).toHaveText('Note added.');
}

/** Note texts on the open member's detail page, newest first. */
export function noteTexts(page: Page): Locator {
  return page.locator('#content h2', { hasText: 'Notes' }).locator('xpath=following-sibling::table[1]').locator('tr.grid-row td:nth-child(4), tr.grid-alt td:nth-child(4)');
}

/** The profile's Email value on MemberDetail.aspx. */
export function profileEmail(page: Page): Locator {
  return page.locator('#content table.details tr').filter({ hasText: 'Email' }).locator('td');
}
