import type { APIRequestContext } from '@playwright/test';

import { openFinancialDatabase } from '@computer-use/financial-database';

import { capture, expect, instanceState, parseInstance, test, withEnvironment, TEST_WORLD, type Instance, type InstanceState } from './fixtures.js';
import { addNote, control, noteTexts, openMember, profileEmail, updateEmail } from './portal-ui.js';

async function create(admin: APIRequestContext, body: object): Promise<Instance> {
  const response = await admin.post('/instances', { data: body });
  expect(response.status()).toBe(201);
  return parseInstance(await response.json());
}

function memberIn(state: InstanceState, memberNumber: string) {
  const member = state.members.items.find((item) => item.memberNumber === memberNumber);
  if (member === undefined) throw new Error(`State has no member ${memberNumber}.`);
  return { email: member.email };
}

test('an isolated dataset stays independent of the shared world dataset in both directions', async ({ page, playwright }, info) => {
  await withEnvironment({ demo: true }, async (environment, adminToken, database) => {
    const admin = await playwright.request.newContext({
      baseURL: environment.origins.admin,
      extraHTTPHeaders: { Authorization: `Bearer ${adminToken}` },
    });
    try {
      // The demo session binds the shared world dataset; read its binding from the seeded file.
      const worldBinding = (() => {
        using inspector = openFinancialDatabase({ path: database.path });
        const binding = inspector.getNamedWorld(TEST_WORLD).find((item) => item.institutionId === 'northstar');
        if (binding === undefined) throw new Error('World has no northstar binding.');
        return binding;
      })();
      const world = await create(admin, { datasetId: worldBinding.datasetId });
      const isolated = await create(admin, { seed: 8 });
      expect(isolated.datasetId).not.toBe(worldBinding.datasetId);
      const worldStart = await instanceState(admin, world.instanceId);
      const isolatedStart = await instanceState(admin, isolated.instanceId);
      const memberNumber = worldStart.members.items[0]?.memberNumber ?? '';

      // The demonstration session on the shared world dataset edits the member's email.
      await page.goto(`${environment.origins.main}/`);
      await expect(page).toHaveURL(/\/\(S\([a-z0-5]{24}\)\)\/Default\.aspx$/u);
      await openMember(page, memberNumber);
      const seedEmail = await profileEmail(page).innerText();
      await updateEmail(page, 'world-only@example.test');
      await capture(page, info, '01-world-session-edits-email');

      const other = await page.context().newPage();
      await other.goto(isolated.entryUrl);
      await openMember(other, memberNumber);
      await expect(profileEmail(other)).toHaveText(seedEmail);
      await addNote(other, 'Recorded only in the isolated dataset.');
      await expect(noteTexts(other).first()).toHaveText('Recorded only in the isolated dataset.');
      await capture(other, info, '02-isolated-session-keeps-seed-email-and-own-note');

      await page.goto(new URL(`MemberDetail.aspx?member=${memberNumber}`, page.url()).href);
      await expect(noteTexts(page).filter({ hasText: 'Recorded only in the isolated dataset.' })).toHaveCount(0);
      await capture(page, info, '03-world-session-lacks-isolated-note');

      const worldState = await instanceState(admin, world.instanceId);
      const isolatedState = await instanceState(admin, isolated.instanceId);
      expect([worldState.datasetId, worldState.operations - worldStart.operations, memberIn(worldState, memberNumber)]).toEqual([
        worldBinding.datasetId,
        1,
        { email: 'world-only@example.test' },
      ]);
      expect([isolatedState.datasetId, isolatedState.operations - isolatedStart.operations]).toEqual([isolated.datasetId, 1]);
    } finally {
      await admin.dispose();
    }
  });
});

test('sessions on one dataset share changes; reset detaches only the requester and disposal keeps the dataset', async ({ page, playwright }, info) => {
  await withEnvironment({}, async (environment, adminToken) => {
    const admin = await playwright.request.newContext({
      baseURL: environment.origins.admin,
      extraHTTPHeaders: { Authorization: `Bearer ${adminToken}` },
    });
    try {
      const first = await create(admin, { seed: 7 });
      const second = await create(admin, { datasetId: first.datasetId });
      expect(second.datasetId).toBe(first.datasetId);
      expect(second.instanceId).not.toBe(first.instanceId);
      expect(second.entryUrl).not.toBe(first.entryUrl);
      const sharedStart = await instanceState(admin, first.instanceId);
      const memberNumber = sharedStart.members.items[0]?.memberNumber ?? '';

      // Two sessions attached to one dataset see each other's UI changes.
      const pageA = page;
      const pageB = await page.context().newPage();
      await pageA.goto(first.entryUrl);
      await openMember(pageA, memberNumber);
      await updateEmail(pageA, 'shared-from-a@example.test');
      await pageB.goto(second.entryUrl);
      await openMember(pageB, memberNumber);
      await expect(profileEmail(pageB)).toHaveText('shared-from-a@example.test');
      await addNote(pageB, 'Written from session B.');
      await pageA.goto(new URL(`MemberDetail.aspx?member=${memberNumber}`, first.entryUrl).href);
      await expect(noteTexts(pageA).first()).toHaveText('Written from session B.');
      await capture(pageA, info, '01-session-a-sees-session-b-note');
      expect((await instanceState(admin, second.instanceId)).operations).toBe(sharedStart.operations + 2);

      // Reset gives A a fresh dataset and a new URL; A's open document and old URL stop working.
      const resetResponse = await admin.post(`/instances/${first.instanceId}/reset`, { data: {} });
      expect(resetResponse.status()).toBe(201);
      const replacement = parseInstance(await resetResponse.json());
      expect(replacement.instanceId).not.toBe(first.instanceId);
      expect(replacement.entryUrl).not.toBe(first.entryUrl);
      expect(replacement.datasetId).not.toBe(first.datasetId);
      const stalePost = pageA.waitForResponse((response) => response.request().method() === 'POST');
      await control(pageA, 'txtNote').fill('stale');
      await control(pageA, 'btnAddNote').click();
      expect((await stalePost).status()).toBe(404);
      await expect(pageA.locator('h1')).toHaveText('Session not found');
      await expect(pageA.getByRole('link', { name: 'Start a new session', exact: true })).toHaveAttribute('href', '/');
      await capture(pageA, info, '02-reset-session-old-document-is-dead');
      expect((await pageA.goto(first.entryUrl))?.status()).toBe(404);
      expect((await admin.get(`/instances/${first.instanceId}/state`)).status()).toBe(404);

      await pageA.goto(replacement.entryUrl);
      await openMember(pageA, memberNumber);
      const replacementStart = await instanceState(admin, replacement.instanceId);
      const seedEmail = replacementStart.members.items.find((item) => item.memberNumber === memberNumber)?.email;
      await expect(profileEmail(pageA)).toHaveText(seedEmail ?? '');
      await expect(noteTexts(pageA).filter({ hasText: 'Written from session B.' })).toHaveCount(0);
      await capture(pageA, info, '03-replacement-session-has-fresh-seed-data');
      expect(replacementStart.operations).toBe(sharedStart.operations);

      // The peer keeps the shared data and remains writable.
      await pageB.goto(new URL(`MemberDetail.aspx?member=${memberNumber}`, second.entryUrl).href);
      await expect(profileEmail(pageB)).toHaveText('shared-from-a@example.test');
      await updateEmail(pageB, 'still-writable-b@example.test');
      await capture(pageB, info, '04-peer-keeps-data-and-writes-after-reset');
      const afterReset = await instanceState(admin, second.instanceId);
      expect([afterReset.datasetId, afterReset.operations - sharedStart.operations, memberIn(afterReset, memberNumber)]).toEqual([
        first.datasetId,
        3,
        { email: 'still-writable-b@example.test' },
      ]);

      // Disposal ends only B's UI session; the dataset stays reachable for a new session.
      expect((await admin.delete(`/instances/${second.instanceId}`)).status()).toBe(204);
      expect((await admin.delete(`/instances/${second.instanceId}`)).status()).toBe(404);
      expect((await admin.get(`/instances/${second.instanceId}/state`)).status()).toBe(404);
      expect((await pageB.goto(second.entryUrl))?.status()).toBe(404);
      await expect(pageB.locator('h1')).toHaveText('Session not found');

      const third = await create(admin, { datasetId: first.datasetId });
      expect(third.datasetId).toBe(first.datasetId);
      await pageB.goto(third.entryUrl);
      await openMember(pageB, memberNumber);
      await expect(profileEmail(pageB)).toHaveText('still-writable-b@example.test');
      await expect(noteTexts(pageB).first()).toHaveText('Written from session B.');
      await capture(pageB, info, '05-new-session-on-preserved-dataset');
    } finally {
      await admin.dispose();
    }
  });
});
