# BranchNet legacy postback portal

BranchNet is Northstar Mutual's synthetic branch administration intranet, modeled on ASP.NET Web Forms. Every page is one server form. Paging, sorting, dropdown changes, row expansion, tab changes, edits, and validation all submit that form and replace the whole document. The application shares members, accounts, ledger, activity, and maintenance requests with Meridian Core through `@computer-use/financial-database`.

The [specification](SPEC.md) defines the modules and mechanisms. The implementation record (historical material omitted from this bundle) records decisions, evidence, and limits.

## Run the application

Use Node.js 22.15 or newer. From the repository root:

```sh
cd environments
npm ci
npm run build
npm start -w legacy-postback-portal -- --verbose
```

`npm run start:postback-portal` from `environments/` rebuilds the database package first and starts the portal without extra flags.

Open `http://127.0.0.1:4320`. The root URL redirects to the demonstration session, for example `/(S(<session>))/Default.aspx`. Stop the server with Ctrl+C or SIGTERM; it closes its listeners and database connection.

After the workspace build you can also start the compiled server from this folder:

```sh
node dist/src/main.js --verbose
```

| Flag | Default | Purpose |
| --- | --- | --- |
| `--port` | `4320` | Application listener. `0` selects an ephemeral port. |
| `--admin-port` | `4321` | Administration listener. |
| `--admin-token-file` | `.runtime/admin.token` | Where startup writes the administration bearer token, with owner-only permissions. |
| `--database` | `environments/database/financial/.runtime/financial.sqlite` | Seeded financial SQLite file. Use a temporary path for disposable runs. |
| `--form-state-ttl` | `1200` | Idle seconds before page state expires, from 1 through 86,400. |
| `--form-state-history` | `200` | Page states retained per session before the least recently used expire, from 1 through 10,000. |
| `--verbose` | off | Log each request's method, page, and postback event to stderr. |

BranchNet's ports do not collide with Meridian Core's 4310 to 4312, so both applications can run together. Give a second copy of BranchNet distinct ports and its own token file.

## Database and sessions

A normal launch opens the canonical default database and attaches to the Northstar dataset in `financial-demo-v1` (seed `20260911`). Meridian Core does the same, so records changed in one application appear in the other on the next page load. Restarting either application preserves business records. See the [shared database guide](../database/README.md).

UI sessions, page state, form tokens, and unsaved field values live in process memory. They expire on restart, after the idle timeout, or when the session's page-state history is full. A postback with expired state shows a message and a control that reloads the page. A maintenance request saved as a draft is a shared business record and survives restarts.

The database must already be seeded by `environments/database/financial`; startup validates the financial schema and named world, and never seeds or upgrades business data.

## Administration

The administration listener accepts JSON with `Authorization: Bearer <token>` and rejects browser-origin requests.

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/instances` | `{"seed":42}` creates an isolated dataset and session. `{"datasetId":"…"}` attaches a session to an existing dataset. |
| GET | `/instances/:id/state` | Current records and revision. |
| GET | `/instances/:id/export` | The same state as a JSON download. |
| POST | `/instances/:id/reset` | Replace only this session with a fresh seeded dataset and a new URL. |
| DELETE | `/instances/:id` | Dispose of the session. Its dataset is preserved. |

To share a dataset with a Meridian Core instance, create an instance in one application and pass the returned `datasetId` to the other application's administration listener. Both processes must open the same database file.

## Verify

From `environments/`, install the test browser once, then run the checks.

```sh
npx playwright install chromium
npm run build
npm run check
npm run verify
```

`npm run check` runs typechecking, lint, and the unit and HTTP tests for the database package and both applications. `npm run verify` runs both applications' browser suites. To run only this application's browser suite, run `npm run verify` from this folder after the workspace build.

Tests and browser checks use temporary databases and ephemeral ports. They never change the shared demonstration dataset. Browser results are saved to `verification/artifacts/<run-id>/results.json`, with screenshots under the run's `browser/` directory. The cross-application check starts the compiled Meridian Core server, so build the workspace first.

