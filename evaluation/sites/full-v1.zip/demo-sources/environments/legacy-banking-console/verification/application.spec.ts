import { test, expect } from './fixtures.js';
import assert from 'node:assert/strict';
import { capture, monitorBrowser, parseInstance, visibleFrame } from './reference.js';
import { assertStructure, clickWithScreenshot } from './structure.js';

const profiles = [
  'baseline', 'deep-frames', 'cross-origin', 'repeated-controls', 'hidden-duplicates',
  'nested-scroll', 'sticky-clipping', 'scaled-geometry', 'generated-ids', 'weak-semantics',
  'focus-replacement', 'separate-inquiry-window', 'navigation-hard', 'targeting-hard',
  'geometry-hard', 'combined-hard',
] as const;

for (const profile of profiles) {
  for (const seed of [17, 91]) {
    test(`${profile} seed ${String(seed)} opens a usable member directory`, async ({ page, adminRequest }, info) => {
      const errors = monitorBrowser(page.context());
      const response = await adminRequest.post('/instances', { data: { seed, profile } });
      expect(response.status()).toBe(201);
      const instance = parseInstance(await response.json());
      try {
        await page.goto(instance.entryUrl);
        const search = await visibleFrame(page.context(), 'Member Search');
        await capture(page, info, 'member-search');
        await assertStructure(page, search, profile, info);
        const oldInput = await search.locator('input[type="text"]:visible').first().elementHandle();
        assert(oldInput);
        const navigation = await visibleFrame(page.context(), 'Members');
        if (profile === 'scaled-geometry' || profile === 'geometry-hard' || profile === 'combined-hard') {
          await clickWithScreenshot(page, navigation, 'Members', info);
        } else {
          await navigation.getByRole('link', { name: 'Members', exact: true }).click();
        }
        const members = await visibleFrame(page.context(), 'Open member');
        if (profile === 'focus-replacement' || profile === 'navigation-hard' || profile === 'combined-hard') {
          await expect.poll(async () => oldInput.evaluate(element => element.isConnected).catch(() => false)).toBe(false);
        }
        await oldInput.dispose();
        expect(await members.getByText('Open member', { exact: true }).count()).toBeGreaterThan(1);
        const firstRow = members.locator('tr').filter({ has: members.getByText('Open member', { exact: true }) }).first();
        const memberNumber = await firstRow.locator('td').first().innerText();
        await firstRow.getByText('Open member', { exact: true }).click();
        const details = await visibleFrame(page.context(), 'Member Details');
        await expect(details.locator('body')).toContainText('Accounts');
        await expect(details.locator('body')).toContainText(memberNumber);
        if (['deep-frames', 'repeated-controls', 'navigation-hard', 'targeting-hard', 'combined-hard'].includes(profile)) {
          const register = await visibleFrame(page.context(), 'Account register');
          expect(register.parentFrame()).toBe(details);
          expect(await register.locator('tr').filter({ has: register.getByText('View account', { exact: true }) }).count()).toBeGreaterThan(0);
          if (profile === 'navigation-hard' || profile === 'combined-hard') {
            expect(new URL(register.url()).origin).not.toBe(new URL(details.url()).origin);
          }
        }
        await capture(page, info, 'member-details');
        await details.getByRole('link', { name: 'Member Search', exact: true }).click();
        const lookup = await visibleFrame(page.context(), 'Member Search');
        const query = lookup.locator('form:visible tr').filter({ hasText: 'Member name, number or contact' }).locator('input');
        await query.click();
        await page.keyboard.type(memberNumber);
        await expect(query).toHaveValue(memberNumber);
        await lookup.locator('form:visible').locator('button, input[type="image"], [onclick]').click();
        const results = await visibleFrame(page.context(), 'Open member');
        const selectedRow = results.locator('tr').filter({ hasText: memberNumber });
        await expect(selectedRow).toContainText(memberNumber);
        await selectedRow.getByText('Open member', { exact: true }).click();
        const selected = await visibleFrame(page.context(), 'Member Details');
        await expect(selected.locator('body')).toContainText(memberNumber);
        expect(errors).toEqual([]);
      } finally {
        expect((await adminRequest.delete(`/instances/${instance.instanceId}`)).ok()).toBe(true);
      }
    });
  }
}

test('the root URL opens a human demo', async ({ page, environment }) => {
  await page.goto(environment.origins.main);
  const search = await visibleFrame(page.context(), 'Member Search');
  await expect(search.locator('body')).toContainText('Member Search');
});
