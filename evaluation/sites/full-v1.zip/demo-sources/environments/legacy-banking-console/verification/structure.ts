import { expect, type Frame, type Page, type TestInfo } from '@playwright/test';
import assert from 'node:assert/strict';
import { capture } from './reference.js';

const combined = (profile: string, group: string, individual: string): boolean =>
  profile === 'combined-hard' || profile === group || profile === individual;

export async function assertStructure(page: Page, search: Frame, profile: string, info: TestInfo): Promise<void> {
  if (combined(profile, 'geometry-hard', 'nested-scroll')) {
    await page.setViewportSize({ width: 1024, height: 600 });
    const outer = search.locator('main');
    const inner = search.locator('.register-scroll').first();
    const dimensions = await Promise.all([outer, inner].map(locator => locator.evaluate(element => ({ client: element.clientHeight, content: element.scrollHeight }))));
    expect(dimensions.every(region => region.content > region.client)).toBe(true);
    await inner.hover();
    const outerBefore = await outer.evaluate(element => element.scrollTop);
    await page.mouse.wheel(0, 150);
    await expect.poll(() => inner.evaluate(element => element.scrollTop)).toBeGreaterThan(0);
    expect(await outer.evaluate(element => element.scrollTop)).toBe(outerBefore);
    const innerBefore = await inner.evaluate(element => element.scrollTop);
    const outerBox = await outer.boundingBox();
    assert(outerBox);
    await page.mouse.move(outerBox.x + 5, outerBox.y + 20);
    await page.mouse.wheel(0, outerBefore > 0 ? -Math.max(1, Math.floor(outerBefore / 2)) : 100);
    await expect.poll(() => outer.evaluate(element => element.scrollTop)).not.toBe(outerBefore);
    expect(await inner.evaluate(element => element.scrollTop)).toBe(innerBefore);
    await capture(page, info, 'independent-scroll-regions');
    await info.attach('scroll-offsets', {
      body: JSON.stringify({ dimensions, outer: await outer.evaluate(element => element.scrollTop), inner: await inner.evaluate(element => element.scrollTop) }),
      contentType: 'application/json',
    });
  }
  const frames = page.frames();
  if (combined(profile, 'navigation-hard', 'deep-frames')) {
    const depths = frames.map(frame => {
      let depth = 0;
      let parent = frame.parentFrame();
      while (parent) {
        depth += 1;
        parent = parent.parentFrame();
      }
      return depth;
    });
    expect(Math.max(...depths)).toBeGreaterThanOrEqual(3);
  }
  if (combined(profile, 'navigation-hard', 'cross-origin')) {
    const crossOriginChild = frames.find(frame => {
      const parent = frame.parentFrame();
      return parent && new URL(frame.url()).origin !== new URL(parent.url()).origin;
    });
    assert(crossOriginChild, 'A nested document has another loopback origin');
    const accessResult = await crossOriginChild.evaluate(() => {
      try {
        return window.parent.document.title;
      } catch (error) {
        return error instanceof DOMException ? error.name : 'unexpected error';
      }
    });
    expect(accessResult).toBe('SecurityError');
  }
  if (combined(profile, 'geometry-hard', 'scaled-geometry')) {
    const scales = await Promise.all(frames.map(async frame => {
      if (!frame.parentFrame()) return 1;
      return (await frame.frameElement()).evaluate(element => {
        if (!(element instanceof HTMLElement)) throw new Error('The frame element is not HTML');
        return element.getBoundingClientRect().width / element.offsetWidth;
      });
    }));
    expect(scales.some(scale => scale > 0 && scale < 0.95)).toBe(true);
  }
  if (combined(profile, 'targeting-hard', 'hidden-duplicates')) {
    const controls = search.locator('input:not([type="hidden"]), button, select, a');
    const duplicates = await controls.evaluateAll(elements => elements.map(element => {
      const style = getComputedStyle(element);
      return {
        key: [element.tagName, element.getAttribute('name'), element.textContent.trim(), element.getAttribute('alt')].join('|'),
        hidden: style.display === 'none' || style.visibility === 'hidden' || element.getClientRects().length === 0,
      };
    }));
    expect(duplicates.some(control => control.hidden && duplicates.some(other => !other.hidden && other.key === control.key))).toBe(true);
  }
  if (combined(profile, 'targeting-hard', 'weak-semantics')) {
    expect(await search.locator('input[type="image"], a > img, button > img, [onclick]:not(button):not(a)').count()).toBeGreaterThan(0);
  }
  if (combined(profile, 'navigation-hard', 'generated-ids') || profile === 'targeting-hard') {
    const before = await search.locator('[id]').evaluateAll(elements => elements.map(element => element.id));
    expect(before.length).toBeGreaterThan(0);
    await search.goto(search.url());
    const after = await search.locator('[id]').evaluateAll(elements => elements.map(element => element.id));
    expect(after.length).toBeGreaterThan(0);
    expect(after).not.toEqual(before);
  }
  if (combined(profile, 'geometry-hard', 'sticky-clipping')) {
    const stickyCount = await search.locator('*').evaluateAll(elements => elements.filter(element => getComputedStyle(element).position === 'sticky').length);
    expect(stickyCount).toBeGreaterThan(0);
    const clipping = await search.locator('.register-scroll').first().evaluate(element => ({
      overflow: getComputedStyle(element).overflowY,
      visibleHeight: element.clientHeight,
      contentHeight: element.scrollHeight,
    }));
    expect(clipping.overflow).toBe('auto');
    expect(clipping.contentHeight).toBeGreaterThan(clipping.visibleHeight);
  }
  if (combined(profile, 'navigation-hard', 'focus-replacement')) {
    const input = search.locator('input[type="text"]:visible').first();
    await input.click();
    await page.keyboard.type('focus-check');
    await expect(input).toHaveValue('focus-check');
    expect(await input.evaluate(element => element === document.activeElement)).toBe(true);
    await input.fill('');
  }
  await info.attach('frame-structure', {
    body: JSON.stringify({ profile, frames: page.frames().map(frame => ({ url: frame.url(), parent: frame.parentFrame()?.url() })) }, null, 2),
    contentType: 'application/json',
  });
}

export async function clickWithScreenshot(page: Page, frame: Frame, text: string, info: TestInfo): Promise<void> {
  const control = frame.getByRole('link', { name: text, exact: true });
  await control.scrollIntoViewIfNeeded();
  const box = await control.boundingBox();
  assert(box);
  await capture(page, info, 'before-coordinate-click');
  await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
}
