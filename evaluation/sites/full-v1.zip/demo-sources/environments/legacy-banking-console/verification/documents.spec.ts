import { readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { test, expect } from './fixtures.js';
import { capture, monitorBrowser, parseInstance, visibleFrame } from './reference.js';

for (const profile of ['baseline', 'separate-inquiry-window', 'navigation-hard', 'combined-hard']) {
  test(`${profile} opens account history and exports statements`, async ({ page, adminRequest }, info) => {
    const errors = monitorBrowser(page.context());
    const response = await adminRequest.post('/instances', { data: { seed: 51, profile } });
    expect(response.status()).toBe(201);
    const instance = parseInstance(await response.json());
    try {
      await page.goto(instance.entryUrl);
      const navigation = await visibleFrame(page.context(), 'Accounts');
      await navigation.getByRole('link', { name: 'Accounts', exact: true }).click();
      const accounts = await visibleFrame(page.context(), 'View account');
      const row = accounts.locator('tr').filter({ has: accounts.getByText('View account', { exact: true }) }).first();
      const visibleRecord = await row.innerText();
      await row.getByText('View account', { exact: true }).click();
      const details = await visibleFrame(page.context(), 'Account Details');
      const accountText = await details.locator('body').innerText();
      const accountNumber = accountText.match(/Account number\s+([\w-]+)/i)?.[1] ?? visibleRecord.split(/\s+/)[0];
      assert(accountNumber);
      expect(visibleRecord).toContain(accountNumber);
      await capture(details.page(), info, 'account-inquiry');
      await details.getByRole('link', { name: 'Transactions', exact: true }).click();
      const transactions = await visibleFrame(page.context(), 'Transactions');
      await expect(transactions.locator('body')).toContainText(accountNumber);
      expect(await transactions.locator('tr').count()).toBeGreaterThan(1);
      const visibleTransaction = await transactions.locator('.register tbody tr').first().locator('td').allTextContents();
      assert(visibleTransaction[0]);

      // Statement inquiry opens in a separate window under inquiry-window profiles.
      await transactions.getByRole('link', { name: 'Accounts', exact: true }).click();
      const accountList = await visibleFrame(page.context(), 'Account Search');
      const accountQuery = accountList.locator('form:visible tr').filter({ hasText: 'Account or member number' }).locator('input');
      await accountQuery.fill(accountNumber);
      await accountList.locator('form:visible').locator('button, input[type="image"], [onclick]').click();
      const listed = await visibleFrame(page.context(), 'View account');
      await listed.locator('tr').filter({ hasText: accountNumber }).getByText('View account', { exact: true }).click();
      const again = await visibleFrame(page.context(), 'Account Details');
      const pageCount = page.context().pages().length;
      await again.getByRole('link', { name: 'Statements', exact: true }).click();
      const statements = await visibleFrame(page.context(), 'Statement periods');
      if (profile !== 'baseline') {
        await expect.poll(() => page.context().pages().length).toBe(pageCount + 1);
      }
      const [download] = await Promise.all([
        statements.page().waitForEvent('download'),
        statements.getByRole('link', { name: 'CSV', exact: true })
          .or(statements.getByText('CSV', { exact: true }))
          .filter({ visible: true }).last().click(),
      ]);
      expect(download.suggestedFilename()).toMatch(/\.csv$/);
      expect(download.suggestedFilename()).toContain(accountNumber);
      const path = info.outputPath(download.suggestedFilename());
      await download.saveAs(path);
      const csv = await readFile(path, 'utf8');
      expect(csv).toContain('signed_minor_units');
      expect(csv).toContain(accountNumber);
      expect(csv.trim().split('\n').length).toBeGreaterThan(1);
      await info.attach('statement-csv', { path, contentType: 'text/csv' });
      await capture(page, info, 'statement');
      expect(errors).toEqual([]);
    } finally {
      await adminRequest.delete(`/instances/${instance.instanceId}`);
    }
  });
}
