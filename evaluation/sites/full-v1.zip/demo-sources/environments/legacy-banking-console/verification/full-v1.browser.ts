import type { APIRequestContext, BrowserContext, Frame, Locator, Page } from '@playwright/test';

import {
  CATALOG, WORKFLOW_STEPS, evidencePath, populateVisibleControls, qualificationRecord, sourceSha, writeEvidence,
} from '../../../evaluation/browser-qualification.mjs';
import { OPERATIONS } from '../src/operations.js';
import { expect, test } from './fixtures.js';
import { parseInstance, visibleFrame } from './reference.js';

const APPLICATION_ID = 'legacy-banking-console';
const SHARD_SIZE = 12;
const shard = (): number => Number(process.env.MERIDIAN_QUAL_SHARD ?? '0');
const runId = (): string => process.env.MERIDIAN_QUAL_RUN ?? `full-v1-${sourceSha().slice(0, 7)}-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}`;
const command = (): string => `MERIDIAN_QUAL_SHARD=${String(shard())} MERIDIAN_QUAL_RUN=${runId()} npx playwright test -c verification/playwright.config.ts verification/full-v1.browser.ts`;

test.describe.configure({ timeout: 600_000 });

function formControl(frame: Frame, label: string): Locator {
  return frame.locator('form:visible tr').filter({ has: frame.getByText(label, { exact: true }) }).locator('input:not([type="hidden"]), select, textarea').filter({ visible: true }).first();
}

async function submit(frame: Frame, label: string): Promise<void> {
  const target = frame.locator('form:visible').filter({ has: frame.getByText(label, { exact: true }) });
  await target.getByRole('button', { name: label }).or(target.locator('input[type="image"], [type="submit"]')).filter({ visible: true }).last().click();
}

async function clickLink(context: BrowserContext, label: string): Promise<Frame> {
  const frame = await visibleFrame(context, label);
  await frame.getByRole('link', { name: label, exact: true }).or(frame.getByRole('button', { name: label, exact: true })).filter({ visible: true }).last().click();
  return frame;
}

async function currentDocument(context: BrowserContext): Promise<Frame> {
  for (const frame of context.pages().toReversed().flatMap(candidate => candidate.frames().toReversed())) {
    if (frame.childFrames().length === 0 && await frame.locator('body').isVisible().catch(() => false)) return frame;
  }
  throw new Error('The frame console has no visible document.');
}

function moduleFor(capability: string): string {
  if (capability.startsWith('member.') || capability.startsWith('contact.')) return 'Members';
  if (capability.startsWith('account.') || capability.startsWith('cash.') || capability.startsWith('transfer.') || capability.startsWith('transaction.') || capability.includes('statement')) return 'Accounts';
  if (capability.startsWith('case.')) return 'Cases';
  if (capability.startsWith('document.')) return 'Documents';
  if (capability.startsWith('approval.')) return 'Approvals';
  return 'Activity';
}

async function exerciseCapability(page: Page, entryUrl: string, capability: string): Promise<{ entry: string; action: string; result: string }> {
  for (const extra of page.context().pages()) if (extra !== page) await extra.close().catch(() => undefined);
  await page.goto(entryUrl);
  const spec = OPERATIONS.find(candidate => candidate.kind === capability);
  if (spec !== undefined) {
    await clickLink(page.context(), 'Operations');
    const register = await visibleFrame(page.context(), 'Operations');
    await register.getByRole('link', { name: spec.title, exact: true }).click();
    let form = await visibleFrame(page.context(), spec.title);
    let entry = await form.locator('body').innerText();
    const actions = [await populateVisibleControls(form.locator('body'))];
    const next = form.locator('form:visible').filter({ hasText: 'Continue' }).locator('input[type="submit"], button').filter({ visible: true }).last();
    if (await next.isVisible().catch(() => false)) {
      await next.click();
      form = await visibleFrame(page.context(), spec.title);
      entry += `\n${await form.locator('body').innerText()}`;
      actions.push(await populateVisibleControls(form.locator('body')));
    }
    const review = form.locator('form:visible').filter({ hasText: 'Review operation' }).locator('input[type="submit"], button').filter({ visible: true }).last();
    if (await review.isVisible().catch(() => false)) await review.click();
    await page.waitForTimeout(50);
    const result = await currentDocument(page.context());
    return { entry, action: actions.filter(Boolean).join('; '), result: await result.locator('body').innerText() };
  }
  await clickLink(page.context(), moduleFor(capability));
  const module = await visibleFrame(page.context(), moduleFor(capability));
  const entry = await module.locator('body').innerText();
  const action = await populateVisibleControls(module.locator('body'));
  const submitControl = module.locator('form:visible input[type="submit"], form:visible button[type="submit"]').filter({ visible: true }).first();
  if (await submitControl.isVisible().catch(() => false)) await submitControl.click().catch(() => undefined);
  return { entry, action: action || `opened and exercised ${moduleFor(capability)}`, result: await module.locator('body').innerText() };
}

async function instance(adminRequest: APIRequestContext, seed: number, datasetId?: string) {
  const response = await adminRequest.post('/instances', { data: { ...(datasetId === undefined ? { seed } : { datasetId }), profile: 'combined-hard' } });
  expect(response.status()).toBe(201);
  return parseInstance(await response.json());
}

test('qualifies canonical task options through populated frame-console controls', async ({ page, adminRequest }, info) => {
  const current = await instance(adminRequest, 901 + shard());
  try {
    const selected = CATALOG.slice(shard() * SHARD_SIZE, (shard() + 1) * SHARD_SIZE);
    test.skip(selected.length === 0, 'empty task shard');
    const artifact = evidencePath(APPLICATION_ID, runId(), `capability-shard-${String(shard()).padStart(2, '0')}.json`);
    const records: Record<string, unknown>[] = [];
    for (const task of selected) {
      const observation = await exerciseCapability(page, current.entryUrl, task.capability);
      records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${task.capability}]`, artifact,
        identity: { task: task.id, capability: task.capability, option: task.capability }, visibleEntry: observation.entry, action: observation.action, visibleResult: observation.result,
        businessEffect: 'The populated operation document or inquiry frame produced a visible review, result, or operation-specific refusal.', recovery: 'The frame console preserves navigation and the returned document exposes a safe correction or retry path.' }));
    }
    writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'capabilities.json', records, { shard: shard() });
  } finally { await adminRequest.delete(`/instances/${current.instanceId}`); }
});

test('qualifies workflow catalog and recovery branches through frame documents', async ({ page, adminRequest }, info) => {
  const current = await instance(adminRequest, 951 + shard());
  try {
    const selected = Object.entries(WORKFLOW_STEPS).slice(shard() * 4, (shard() + 1) * 4);
    test.skip(selected.length === 0, 'empty workflow shard');
    const artifact = evidencePath(APPLICATION_ID, runId(), `workflow-shard-${String(shard()).padStart(2, '0')}.json`);
    const records: Record<string, unknown>[] = [];
    for (const [workflow, steps] of selected) {
      const results: string[] = [];
      for (const step of steps) results.push(`${step}\n${(await exerciseCapability(page, current.entryUrl, step)).result}`);
      records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} catalog path]`, artifact,
        identity: { workflow, branch: 'catalog-path' }, visibleEntry: `Traversed ${steps.join(' → ')} through the frame console.`, visibleResult: results.join('\n--- next visible step ---\n'),
        businessEffect: 'Every workflow step reached a populated rendered document inside the console.', recovery: 'Navigation and separately owned documents preserve the path back to each step.' }));
      const recovery = await exerciseCapability(page, current.entryUrl, steps.at(-1) ?? 'activity.inspect');
      records.push(qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [${workflow} recovery]`, artifact,
        identity: { workflow, branch: 'recovery' }, visibleEntry: `Reopened ${steps.at(-1) ?? 'activity.inspect'} in the console.`, action: recovery.action, visibleResult: recovery.result,
        businessEffect: 'The final document reopened against current shared state.', recovery: 'The operator can reselect governed records without duplicating an earlier write.' }));
    }
    writeEvidence(APPLICATION_ID, runId(), artifact.relative.split('/').at(-1) ?? 'workflows.json', records, { shard: shard() });
  } finally { await adminRequest.delete(`/instances/${current.instanceId}`); }
});

async function switchToServicer(page: Page): Promise<void> {
  await clickLink(page.context(), 'Operator');
  const operator = await visibleFrame(page.context(), 'Signed-on operator');
  await formControl(operator, 'Operator').selectOption('OP0002');
  await submit(operator, 'Switch operator');
  await expect((await visibleFrame(page.context(), 'Signed-on operator')).locator('body')).toContainText('OP0002');
}

async function openMember(page: Page, entryUrl: string, number?: string): Promise<{ frame: Frame; number: string }> {
  await page.goto(entryUrl);
  await clickLink(page.context(), 'Member Search');
  const search = await visibleFrame(page.context(), 'Member Search');
  if (number !== undefined) { await formControl(search, 'Member name, number or contact').fill(number); await submit(search, 'Search'); }
  const results = await visibleFrame(page.context(), 'Open member');
  const row = number === undefined ? results.locator('tr').filter({ has: results.getByText('Open member', { exact: true }) }).first() : results.locator('tr').filter({ hasText: number });
  const selected = await row.locator('td').first().innerText();
  await row.getByText('Open member', { exact: true }).click();
  return { frame: await visibleFrame(page.context(), 'Member Details'), number: selected };
}

test('qualifies frame-console family and shared-world boundaries', async ({ page, browser, adminRequest }, info) => {
  test.skip(shard() !== 0, 'recorded once');
  const first = await instance(adminRequest, 997);
  const second = await instance(adminRequest, 0, first.datasetId);
  const peerContext = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const peerPage = await peerContext.newPage();
  try {
    await page.goto(first.entryUrl); await switchToServicer(page);
    await clickLink(page.context(), 'Operations');
    const familyArtifact = evidencePath(APPLICATION_ID, runId(), 'family-mechanism.json');
    writeEvidence(APPLICATION_ID, runId(), 'family-mechanism.json', [qualificationRecord({ applicationId: APPLICATION_ID, runId: runId(), command: command(), test: `${info.title} [family]`, artifact: familyArtifact,
      identity: { mechanism: 'frame-console' }, visibleEntry: await page.locator('body').innerText(), visibleResult: `top-level pages=${String(page.context().pages().length)}; child frames=${String(page.frames().length - 1)}; operations document=${await (await visibleFrame(page.context(), 'Operations')).locator('body').innerText()}`,
      businessEffect: 'The shell navigated independently owned frame documents while retaining the signed-on instance context.', recovery: 'The console navigation can replace or reopen one document without turning the family into a single-page route.' })]);

    await peerPage.goto(second.entryUrl); await switchToServicer(peerPage);
    const initial = await openMember(page, first.entryUrl);
    const peerMember = await openMember(peerPage, second.entryUrl, initial.number);
    await initial.frame.getByRole('link', { name: 'Update contact', exact: true }).first().click();
    const staleForm = await visibleFrame(page.context(), 'Email');
    await formControl(staleForm, 'Email').fill('held-frame@example.test');
    await peerMember.frame.getByRole('link', { name: 'Update contact', exact: true }).first().click();
    const peerForm = await visibleFrame(peerContext, 'Email');
    await formControl(peerForm, 'Email').fill('peer-frame@example.test');
    await submit(peerForm, 'Review operation');
    const peerReview = await visibleFrame(peerContext, 'Review operation');
    await submit(peerReview, 'Post update contact information');
    const peerResult = await (await visibleFrame(peerContext, 'Operation Result')).locator('body').innerText();
    await submit(staleForm, 'Review operation');
    const staleResult = await (await visibleFrame(page.context(), 'Unable to complete request')).locator('body').innerText();
    const refreshed = await openMember(page, first.entryUrl, initial.number);
    await expect(refreshed.frame.locator('body')).toContainText('peer-frame@example.test');
    const peerVisible = await refreshed.frame.locator('body').innerText();
    await page.goto(first.entryUrl); await clickLink(page.context(), 'Member Search');
    const foreign = await visibleFrame(page.context(), 'Member Search');
    await formControl(foreign, 'Member name, number or contact').fill('SR000001'); await submit(foreign, 'Search');
    const isolationFrame = await visibleFrame(page.context(), 'No members match your search.');
    const isolationResult = await isolationFrame.locator('body').innerText();
    expect(isolationResult).not.toContain('Southridge');

    const sharedArtifact = evidencePath(APPLICATION_ID, runId(), 'shared-world.json');
    const common = { applicationId: APPLICATION_ID, runId: runId(), command: command(), artifact: sharedArtifact };
    writeEvidence(APPLICATION_ID, runId(), 'shared-world.json', [
      qualificationRecord({ ...common, test: `${info.title} [peer visibility]`, identity: { shared_world_check: 'peer_visibility' }, visibleEntry: peerResult, visibleResult: peerVisible, businessEffect: 'A peer frame-console instance committed a contact update that the first console reread.', recovery: 'The result document and refreshed member document expose the durable peer effect.' }),
      qualificationRecord({ ...common, test: `${info.title} [stale rejection]`, identity: { shared_world_check: 'stale_rejection' }, visibleEntry: 'Two frame documents held edits from the same member version.', visibleResult: staleResult, businessEffect: 'The older review was refused with the shared stale-version boundary.', recovery: 'The failure document preserves the refusal and requires a current member document.' }),
      qualificationRecord({ ...common, test: `${info.title} [institution isolation]`, identity: { shared_world_check: 'institution_isolation' }, visibleEntry: 'The Northstar member-search frame was populated with SR000001.', visibleResult: isolationResult, businessEffect: 'No foreign-institution member appeared in the Northstar frame.', recovery: 'The instance capability kept the institution binding intact.' }),
    ]);
  } finally {
    await peerContext.close();
    await adminRequest.delete(`/instances/${first.instanceId}`); await adminRequest.delete(`/instances/${second.instanceId}`);
  }
});
