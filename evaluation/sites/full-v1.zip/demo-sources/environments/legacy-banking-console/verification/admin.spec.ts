import { test, expect } from './fixtures.js';
import { datasetFromState, parseInstance } from './reference.js';

test('admin instances are isolated, reproducible, and revocable', async ({ adminRequest, request, page }) => {
  const specification = { seed: 31, profile: 'combined-hard' };
  const firstResponse = await adminRequest.post('/instances', { data: specification });
  const secondResponse = await adminRequest.post('/instances', { data: specification });
  expect(firstResponse.status()).toBe(201);
  expect(secondResponse.status()).toBe(201);
  const first = parseInstance(await firstResponse.json());
  const second = parseInstance(await secondResponse.json());
  try {
    expect(first.instanceId).not.toEqual(second.instanceId);
    expect(first.entryUrl).not.toEqual(second.entryUrl);
    // Same seed produces independent clones with distinct dataset identities.
    expect(first.datasetId).not.toEqual(second.datasetId);
    const firstState = datasetFromState(await (await adminRequest.get(`/instances/${first.instanceId}/state`)).json());
    const secondState = datasetFromState(await (await adminRequest.get(`/instances/${second.instanceId}/state`)).json());
    expect(firstState.revision).toBe(secondState.revision);
    await page.goto(first.entryUrl);
    const reset = await adminRequest.post(`/instances/${first.instanceId}/reset`);
    expect(reset.ok()).toBe(true);
    const replacement = parseInstance(await reset.json());
    expect(replacement.entryUrl).not.toEqual(first.entryUrl);
    expect(replacement.datasetId).not.toEqual(first.datasetId);
    expect((await request.get(first.entryUrl)).ok()).toBe(false);
    expect((await request.get(second.entryUrl)).ok()).toBe(true);
    expect((await request.get(replacement.entryUrl)).ok()).toBe(true);
    expect((await adminRequest.get(`/instances/${second.instanceId}/export`)).ok()).toBe(true);
    if (replacement.instanceId !== first.instanceId) await adminRequest.delete(`/instances/${replacement.instanceId}`);
  } finally {
    await adminRequest.delete(`/instances/${first.instanceId}`);
    await adminRequest.delete(`/instances/${second.instanceId}`);
  }
});

test('admin listener rejects unauthorized and browser-origin requests', async ({ request, adminRequest, environment }) => {
  const body = { seed: 1, profile: 'baseline' };
  expect((await request.post(`${environment.origins.admin}/instances`, { data: body })).status()).toBe(401);
  expect((await request.post(`${environment.origins.admin}/instances`, {
    data: body, headers: { Authorization: 'Bearer incorrect-token' },
  })).status()).toBe(401);
  expect((await adminRequest.post('/instances', {
    data: body, headers: { Origin: environment.origins.main },
  })).status()).toBe(403);
  expect((await adminRequest.post('/instances', {
    data: body, headers: { 'Sec-Fetch-Site': 'same-origin' },
  })).status()).toBe(403);
  expect((await request.post(`${environment.origins.main}/instances`, { data: body })).status()).toBe(404);
  expect((await adminRequest.post('/instances', { data: { seed: -1, profile: 'missing' } })).status()).toBe(400);
});
