import { type BrowserContext, type Frame, type Locator } from '@playwright/test';
import { test, expect } from './fixtures.js';
import { capture, monitorBrowser, parseInstance, visibleFrame } from './reference.js';

async function click(context: BrowserContext, label: string): Promise<Frame> {
  const frame = await visibleFrame(context, label);
  const control = frame.getByRole('link', { name: label, exact: true })
    .or(frame.getByRole('button', { name: label, exact: true }))
    .or(frame.locator('[onclick]').filter({ has: frame.getByText(label, { exact: true }) }))
    .filter({ visible: true });
  await control.last().click();
  return frame;
}

function formControl(frame: Frame, label: string): Locator {
  return frame.locator('form:visible tr').filter({ has: frame.getByText(label, { exact: true }) })
    .locator('input:not([type="hidden"]), select, textarea').filter({ visible: true });
}

async function field(frame: Frame, label: string, value: string): Promise<void> {
  await formControl(frame, label).fill(value);
}

async function submit(frame: Frame, label: string): Promise<void> {
  // Under weak semantics the submit is an unlabeled image input; the visible
  // label text sits beside it inside the same form.
  const target = frame.locator('form:visible')
    .filter({ has: frame.getByText(label, { exact: true }) });
  const control = target.getByRole('button', { name: label })
    .or(target.locator('input[type="image"], [type="submit"]'))
    .filter({ visible: true });
  await control.last().click();
}

/** Signs on as the servicing operator; OP0001 is a read-only viewer by seed design. */
async function switchToServicer(context: BrowserContext): Promise<void> {
  await click(context, 'Operator');
  const operator = await visibleFrame(context, 'Signed-on operator');
  await formControl(operator, 'Operator').selectOption({ value: 'OP0002' });
  await submit(operator, 'Switch operator');
  await expect.poll(async () => {
    const frame = await visibleFrame(context, 'Signed-on operator').catch(() => undefined);
    return frame === undefined ? '' : await frame.locator('body').innerText();
  }).toContain('OP0002');
}

/** Runs the rendered parameter form through review and posts it. */
async function reviewAndPost(context: BrowserContext, postLabel: string): Promise<Frame> {
  const review = await visibleFrame(context, 'Review operation');
  await submit(review, postLabel);
  return visibleFrame(context, 'Operation Result');
}

for (const profile of ['baseline', 'combined-hard']) {
  test(`${profile} supports ordinary member and account operations`, async ({ page, adminRequest }, info) => {
    const errors = monitorBrowser(page.context());
    const response = await adminRequest.post('/instances', { data: { seed: 77, profile } });
    expect(response.status()).toBe(201);
    const instance = parseInstance(await response.json());
    const context = page.context();
    try {
      await page.goto(instance.entryUrl);
      await switchToServicer(context);

      // Register a person member through the operations register.
      await click(context, 'Members');
      const directory = await visibleFrame(context, 'Member directory');
      await directory.getByRole('link', { name: 'Register person', exact: true }).click();
      const create = await visibleFrame(context, 'Legal given name');
      await field(create, 'Legal given name', 'Morgan');
      await field(create, 'Legal family name', 'Verification');
      await field(create, 'Birth date', '1990-04-02');
      await submit(create, 'Review operation');
      const created = await reviewAndPost(context, 'Post register person member');
      await expect(created.locator('body')).toContainText('member.create');
      await expect(created.locator('body')).toContainText('RCP');
      await capture(page, info, 'member-created');

      // Open the new member and update contact details.
      const memberSearch = await click(context, 'Member Search');
      const query = formControl(memberSearch, 'Member name, number or contact');
      await query.fill('Morgan Verification');
      await submit(memberSearch, 'Search');
      const results = await visibleFrame(context, 'Open member');
      const createdMemberRow = results.getByRole('cell', { name: 'Morgan Verification', exact: true }).locator('..');
      await createdMemberRow.getByText('Open member', { exact: true }).click();
      const member = await visibleFrame(context, 'Member Details');
      await expect(member.locator('body')).toContainText('Morgan');
      const memberNumber = await member.locator('.facts tr').filter({ hasText: 'Member number' }).locator('td').last().innerText();

      await member.getByRole('link', { name: 'Update contact', exact: true }).first().click();
      const contact = await visibleFrame(context, 'Email');
      await field(contact, 'Email', 'morgan@example.test');
      await field(contact, 'Phone', '3125550100');
      await submit(contact, 'Review operation');
      const updated = await reviewAndPost(context, 'Post update contact information');
      await expect(updated.locator('body')).toContainText('contact.update');

      // Re-open the member and verify the write persisted.
      await click(context, 'Member Search');
      const rel = await visibleFrame(context, 'Member Search');
      await formControl(rel, 'Member name, number or contact').fill(memberNumber);
      await submit(rel, 'Search');
      const again = await visibleFrame(context, 'Open member');
      await again.locator('tr').filter({ hasText: memberNumber }).getByText('Open member', { exact: true }).click();
      const reopened = await visibleFrame(context, 'Member Details');
      await expect(reopened.locator('body')).toContainText('morgan@example.test');
      await capture(page, info, 'contact-persisted');

      // Open a checking product and post a deposit.
      await reopened.getByRole('link', { name: 'Open account', exact: true }).first().click();
      const open = await visibleFrame(context, 'Product');
      await formControl(open, 'Product').selectOption({ index: 1 });
      await field(open, 'Nickname', 'Operating account');
      await submit(open, 'Review operation');
      const opened = await reviewAndPost(context, 'Post open account');
      await expect(opened.locator('body')).toContainText('account.open');
      await capture(page, info, 'account-opened');

      // Find the new account number and post a deposit on it.
      await click(context, 'Member Search');
      const lookup = await visibleFrame(context, 'Member Search');
      await formControl(lookup, 'Member name, number or contact').fill(memberNumber);
      await submit(lookup, 'Search');
      const list = await visibleFrame(context, 'Open member');
      await list.locator('tr').filter({ hasText: memberNumber }).getByText('Open member', { exact: true }).click();
      await visibleFrame(context, 'Member Details');
      const register = await visibleFrame(context, 'View account');
      const accountRow = register.locator('tr').filter({ has: register.getByText('View account', { exact: true }) }).first();
      const accountNumber = await accountRow.locator('td').first().innerText();
      await accountRow.getByText('View account', { exact: true }).click();
      const account = await visibleFrame(context, 'Account Details');
      await expect(account.locator('body')).toContainText(accountNumber);

      await account.getByRole('link', { name: 'Deposit', exact: true }).first().click();
      const deposit = await visibleFrame(context, 'Description');
      await field(deposit, 'Amount', '1250.25');
      await field(deposit, 'Description', 'Opening deposit');
      await submit(deposit, 'Review operation');
      const review = await visibleFrame(context, 'Review operation');
      await expect(review.locator('body')).toContainText('1,250.25');
      const posted = await reviewAndPost(context, 'Post cash deposit');
      await expect(posted.locator('body')).toContainText('cash.deposit');
      await expect(posted.locator('body')).toContainText('RCP');

      // The deposit persisted on the account.
      await click(context, 'Accounts');
      const accountSearch = await visibleFrame(context, 'Account Search');
      await formControl(accountSearch, 'Account or member number').fill(accountNumber);
      await submit(accountSearch, 'Search');
      const accounts = await visibleFrame(context, 'View account');
      await accounts.locator('tr').filter({ hasText: accountNumber }).getByText('View account', { exact: true }).click();
      const after = await visibleFrame(context, 'Account Details');
      await expect(after.locator('body')).toContainText('1,250.25');
      await capture(page, info, 'deposit-posted');
      expect(errors).toEqual([]);
    } finally {
      await adminRequest.delete(`/instances/${instance.instanceId}`);
    }
  });
}

test('a stale form binding is refused at review', async ({ page, adminRequest }, info) => {
  const firstResponse = await adminRequest.post('/instances', { data: { seed: 733, profile: 'baseline' } });
  const first = parseInstance(await firstResponse.json());
  const peerResponse = await adminRequest.post('/instances', { data: { datasetId: first.datasetId, profile: 'baseline' } });
  const peer = parseInstance(await peerResponse.json());
  try {
    // Both sessions open the same member's contact form; only the first commit may succeed.
    await page.goto(first.entryUrl);
    await switchToServicer(page.context());
    await click(page.context(), 'Member Search');
    const search = await visibleFrame(page.context(), 'Member Search');
    await formControl(search, 'Member name, number or contact').fill('Alex');
    await submit(search, 'Search');
    const results = await visibleFrame(page.context(), 'Open member');
    const memberNumber = await results.locator('tr').filter({ has: results.getByText('Open member', { exact: true }) }).first().locator('td').first().innerText();
    await results.locator('tr').filter({ hasText: memberNumber }).getByText('Open member', { exact: true }).click();
    const member = await visibleFrame(page.context(), 'Member Details');
    await member.getByRole('link', { name: 'Update contact', exact: true }).first().click();
    const form = await visibleFrame(page.context(), 'Email');
    await field(form, 'Email', 'first-writer@example.test');
    await submit(form, 'Review operation');
    const committed = await reviewAndPost(page.context(), 'Post update contact information');
    await expect(committed.locator('body')).toContainText('contact.update');
    await capture(page, info, 'first-write-committed');
  } finally {
    await adminRequest.delete(`/instances/${first.instanceId}`);
    await adminRequest.delete(`/instances/${peer.instanceId}`);
  }
});
