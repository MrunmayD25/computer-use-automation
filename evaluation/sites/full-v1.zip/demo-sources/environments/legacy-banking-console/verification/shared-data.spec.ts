import type { Frame, Page } from '@playwright/test';
import { z } from 'zod';

import { test, expect } from './fixtures.js';
import { capture, datasetFromState, visibleFrame } from './reference.js';

const instanceSchema = z.object({
  instanceId: z.string(),
  entryUrl: z.url(),
  datasetId: z.string(),
});

async function openMember(page: Page, entryUrl: string, memberNumber?: string): Promise<{ frame: Frame; memberNumber: string }> {
  await page.goto(entryUrl);
  const directory = await visibleFrame(page.context(), 'Open member');
  const rows = directory.locator('.register tbody tr').filter({ has: directory.getByText('Open member', { exact: true }) });
  const row = memberNumber === undefined ? rows.first() : rows.filter({ hasText: memberNumber });
  const selectedNumber = await row.locator('td').first().innerText();
  await row.getByText('Open member', { exact: true }).click();
  const member = await visibleFrame(page.context(), 'Member Details');
  await expect(member.locator('body')).toContainText(selectedNumber);
  return { frame: member, memberNumber: selectedNumber };
}

function contactField(frame: Frame, caption: string) {
  return frame.locator('form:visible tr')
    .filter({ has: frame.getByText(caption, { exact: true }) })
    .locator('input:visible, textarea:visible, select:visible');
}

async function submit(frame: Frame, label: string): Promise<void> {
  const target = frame.locator('form:visible')
    .filter({ has: frame.getByText(label, { exact: true }) });
  await target.getByRole('button', { name: label })
    .or(target.locator('input[type="image"], [type="submit"]'))
    .filter({ visible: true })
    .last().click();
}

async function switchToServicer(page: Page): Promise<void> {
  const nav = await visibleFrame(page.context(), 'Operator');
  await nav.getByRole('link', { name: 'Operator', exact: true }).click();
  const operator = await visibleFrame(page.context(), 'Signed-on operator');
  await contactField(operator, 'Operator').selectOption({ value: 'OP0002' });
  await submit(operator, 'Switch operator');
  const signed = await visibleFrame(page.context(), 'Signed-on operator');
  await expect(signed.locator('body')).toContainText('OP0002');
}

async function openContactForm(member: Frame): Promise<Frame> {
  await member.getByRole('link', { name: 'Update contact', exact: true }).first().click();
  return visibleFrame(member.page().context(), 'Email');
}

test('shared profiles observe writes, reject stale edits, and detach reset sessions', async ({ page, browser, adminRequest, request }, info) => {
  const firstResponse = await adminRequest.post('/instances', { data: { seed: 733, profile: 'baseline' } });
  expect(firstResponse.status()).toBe(201);
  const first = instanceSchema.parse(await firstResponse.json());
  const secondResponse = await adminRequest.post('/instances', { data: { datasetId: first.datasetId, profile: 'combined-hard' } });
  expect(secondResponse.status()).toBe(201);
  const second = instanceSchema.parse(await secondResponse.json());
  expect(second.datasetId).toBe(first.datasetId);
  expect(second.instanceId).not.toBe(first.instanceId);
  expect(second.entryUrl).not.toBe(first.entryUrl);

  const peerContext = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const peerPage = await peerContext.newPage();
  const pageErrors: string[] = [];
  page.on('pageerror', error => pageErrors.push(error.message));
  peerContext.on('page', currentPage => currentPage.on('pageerror', error => pageErrors.push(error.message)));
  peerPage.on('pageerror', error => pageErrors.push(error.message));
  const sessionIds = new Set([first.instanceId, second.instanceId]);
  try {
    await page.goto(first.entryUrl);
    await switchToServicer(page);
    await peerPage.goto(second.entryUrl);
    await switchToServicer(peerPage);

    const initialMember = await openMember(page, first.entryUrl);
    const peerMember = await openMember(peerPage, second.entryUrl, initialMember.memberNumber);
    const initialForm = await openContactForm(initialMember.frame);
    const staleForm = await openContactForm(peerMember.frame);
    const originalEmail = await contactField(initialForm, 'Email').inputValue();
    await expect(contactField(staleForm, 'Email')).toHaveValue(originalEmail);

    const savedEmail = 'shared-update@example.test';
    await contactField(initialForm, 'Email').fill(savedEmail);
    await submit(initialForm, 'Review operation');
    const review = await visibleFrame(page.context(), 'Review operation');
    await submit(review, 'Post update contact information');
    const saved = await visibleFrame(page.context(), 'Operation Result');
    await expect(saved.locator('body')).toContainText('contact.update');
    await expect(saved.locator('body')).toContainText('RCP');
    await capture(page, info, 'shared-contact-saved');

    const peerView = await peerContext.newPage();
    const currentPeer = await openMember(peerView, second.entryUrl, initialMember.memberNumber);
    await expect(currentPeer.frame.locator('body')).toContainText(savedEmail);
    await capture(peerView, info, 'peer-observes-shared-contact');
    await peerView.close();


    await contactField(staleForm, 'Email').fill('stale-overwrite@example.test');
    const [conflictResponse] = await Promise.all([
      peerPage.waitForResponse(response => response.request().method() === 'POST' && response.url().includes('/operations/contact.update')),
      submit(staleForm, 'Review operation'),
    ]);
    expect(conflictResponse.status()).toBe(409);
    const conflict = await visibleFrame(peerContext, 'Unable to complete request');
    await expect(conflict.locator('body')).toContainText('stale_version');
    await capture(peerPage, info, 'stale-contact-conflict');
    const afterConflict = await openMember(peerPage, second.entryUrl, initialMember.memberNumber);
    await expect(afterConflict.frame.locator('body')).toContainText(savedEmail);
    await expect(afterConflict.frame.locator('body')).not.toContainText('stale-overwrite@example.test');

    const resetResponse = await adminRequest.post(`/instances/${first.instanceId}/reset`, { data: {} });
    expect(resetResponse.status()).toBe(201);
    const replacement = instanceSchema.parse(await resetResponse.json());
    sessionIds.delete(first.instanceId);
    sessionIds.add(replacement.instanceId);
    expect(replacement.datasetId).not.toBe(first.datasetId);
    expect(replacement.entryUrl).not.toBe(first.entryUrl);
    expect((await request.get(first.entryUrl)).status()).toBe(404);
    expect((await request.get(second.entryUrl)).ok()).toBe(true);
    const detachedMember = await openMember(page, replacement.entryUrl, initialMember.memberNumber);
    await expect(detachedMember.frame.locator('body')).toContainText(originalEmail);
    await expect(detachedMember.frame.locator('body')).not.toContainText(savedEmail);

    const stillShared = await openMember(peerPage, second.entryUrl, initialMember.memberNumber);
    await expect(stillShared.frame.locator('body')).toContainText(savedEmail);
    const freshPeerForm = await openContactForm(stillShared.frame);
    const finalEmail = 'peer-still-usable@example.test';
    await contactField(freshPeerForm, 'Email').fill(finalEmail);
    await submit(freshPeerForm, 'Review operation');
    const peerReview = await visibleFrame(peerContext, 'Review operation');
    await submit(peerReview, 'Post update contact information');
    const peerSaved = await visibleFrame(peerContext, 'Operation Result');
    await expect(peerSaved.locator('body')).toContainText('contact.update');
    const detachedReload = await openMember(page, replacement.entryUrl, initialMember.memberNumber);
    await expect(detachedReload.frame.locator('body')).toContainText(originalEmail);
    await expect(detachedReload.frame.locator('body')).not.toContainText(finalEmail);

    expect((await adminRequest.delete(`/instances/${replacement.instanceId}`)).status()).toBe(204);
    sessionIds.delete(replacement.instanceId);
    expect((await request.get(replacement.entryUrl)).status()).toBe(404);
    const survivingPeer = await openMember(peerPage, second.entryUrl, initialMember.memberNumber);
    await expect(survivingPeer.frame.locator('body')).toContainText(finalEmail);
    const finalState = datasetFromState(await (await adminRequest.get(`/instances/${second.instanceId}/state`)).json());
    expect(finalState.datasetId).toBe(first.datasetId);
    await capture(peerPage, info, 'peer-survives-reset-and-disposal');
    await info.attach('shared-data-evidence', {
      body: JSON.stringify({
        profiles: ['baseline', 'combined-hard'],
        sharedDatasetId: first.datasetId,
        detachedDatasetId: replacement.datasetId,
        staleFormStatus: conflictResponse.status(),
        finalPeerDatasetId: finalState.datasetId,
      }, null, 2),
      contentType: 'application/json',
    });
    expect(pageErrors).toEqual([]);
  } finally {
    await peerContext.close();
    for (const sessionId of sessionIds) await adminRequest.delete(`/instances/${sessionId}`);
  }
});
