import { createServer, type Server } from 'node:http';
import type { AddressInfo } from 'node:net';
import { join } from 'node:path';

import { verificationRunStore } from '@computer-use/financial-database/services';
import type { Page, TestInfo } from '@playwright/test';
import assert from 'node:assert/strict';

import { createInstanceStore } from '../src/instance-store.js';
import { createUiApps } from '../src/web.js';
import { ensureTemplate } from '../test/template.js';
import { loadVerifier, type VerifierReport } from './evaluator.js';
import { expect, test } from './fixtures.js';
import { capture, visibleFrame } from './reference.js';
import type { Frame, Locator } from '@playwright/test';

function formControl(frame: Frame, label: string): Locator {
  return frame.locator('form:visible tr').filter({ has: frame.getByText(label, { exact: true }) }).locator('input:not([type="hidden"]), select, textarea').first();
}

async function submit(frame: Frame, label: string): Promise<void> {
  const target = frame.locator('form:visible').filter({ has: frame.getByText(label, { exact: true }) });
  await target.getByRole('button', { name: label }).or(target.locator('input[type="image"], [type="submit"]')).filter({ visible: true }).last().click();
}

const verifier = await loadVerifier();
const facts = verifier.legacyDepositCase;

async function listen(app: ReturnType<typeof createUiApps>['mainApp']): Promise<{ server: Server; origin: string }> {
  const server = createServer(app);
  await new Promise<void>((resolveListen) => server.listen(0, '127.0.0.1', resolveListen));
  const address = server.address() as AddressInfo;
  return { server, origin: `http://127.0.0.1:${String(address.port)}` };
}

/**
 * Drives the T008 deposit through the rendered frame console inside its own evaluator run, then
 * lets the evaluator grade and dispose the run. The app sees only the run's store; the contract
 * stays with the evaluator.
 */
async function qualify(page: Page, info: TestInfo): Promise<VerifierReport> {
  const template = await ensureTemplate();
  const binding = template.bindings.find((item) => item.institutionId === 'northstar');
  assert(binding !== undefined);
  const root = info.outputPath('evaluator');
  const session = await verifier.startTaskRun({ root, sourcePath: template.path, contract: verifier.legacyDepositContract(binding) });
  let submission: { disposition: string; outputs: Record<string, unknown> };
  const runStore = verificationRunStore(session);
  const store = createInstanceStore({
    store: runStore,
    world: 'run',
    institutionId: 'northstar',
    operators: ['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0006', 'OP0007'],
    principalKind: 'automation',
  });
  const instance = store.create({ datasetId: binding.datasetId, profile: 'combined-hard' });
  const origins = { main: '', frame: '' };
  const apps = createUiApps({
    store,
    mainOrigin: () => origins.main,
    frameOrigin: () => origins.frame,
    demoEntryPath: () => instance.entryUrl,
  });
  const main = await listen(apps.mainApp);
  const frame = await listen(apps.frameApp);
  origins.main = main.origin;
  origins.frame = frame.origin;
  try {
    await page.goto(`${main.origin}${instance.entryUrl}`);
    // Sign on as the servicer, then open the account through the rendered documents.
    const nav = await visibleFrame(page.context(), 'Operator');
    await nav.getByRole('link', { name: 'Operator', exact: true }).click();
    const operator = await visibleFrame(page.context(), 'Signed-on operator');
    await operator.locator('form:visible select').selectOption('OP0002');
    await submit(operator, 'Switch operator');
    await visibleFrame(page.context(), 'OP0002');
    const navigation = await visibleFrame(page.context(), 'Accounts');
    await navigation.getByRole('link', { name: 'Accounts', exact: true }).click();
    const search = await visibleFrame(page.context(), 'Account Search');
    await formControl(search, 'Account or member number').fill(facts.accountNumber);
    await submit(search, 'Search');
    const accounts = await visibleFrame(page.context(), 'View account');
    await accounts.locator('tr').filter({ hasText: facts.accountNumber }).getByText('View account', { exact: true }).click();
    const details = await visibleFrame(page.context(), 'Account Details');
    const depositLink = details.getByRole('link', { name: 'Deposit', exact: true })
      .or(details.getByText('Deposit', { exact: true }))
      .filter({ visible: true });
    await depositLink.last().click();
    const form = await visibleFrame(page.context(), 'Cash deposit');
    await formControl(form, 'Amount').fill('125.40');
    await formControl(form, 'Description').fill(facts.description);
    await submit(form, 'Review operation');
    const review = await visibleFrame(page.context(), 'Review operation');
    await expect(review.locator('body')).toContainText('125.40 USD');
    const postForm = review.locator('form:visible').filter({ hasText: 'Post cash deposit' });
    await postForm.locator('button, input[type="image"]').last().click();
    const result = await visibleFrame(page.context(), 'Operation Result');
    await expect(result.locator('body')).toContainText('cash.deposit');
    const resultText = await result.locator('body').innerText();
    const receiptNumber = resultText.match(/RCP\d+/)?.[0];
    assert(receiptNumber !== undefined, 'the result document shows the receipt number');
    await capture(page, info, 'deposit-posted');
    // Re-read the posted balance through the rendered UI.
    const reload = await visibleFrame(page.context(), 'Accounts');
    await reload.getByRole('link', { name: 'Accounts', exact: true }).click();
    const reSearch = await visibleFrame(page.context(), 'Account Search');
    await formControl(reSearch, 'Account or member number').fill(facts.accountNumber);
    await submit(reSearch, 'Search');
    const reListed = await visibleFrame(page.context(), 'View account');
    await reListed.locator('tr').filter({ hasText: facts.accountNumber }).getByText('View account', { exact: true }).click();
    const reopened = await visibleFrame(page.context(), 'Account Details');
    const reopenedText = await reopened.locator('body').innerText();
    const posted = reopenedText.match(/Posted balance\s+([\d,]+\.\d{2})/)?.[1];
    assert(posted !== undefined, 'the account document shows a posted balance');
    const postedMinorUnits = Math.round(Number(posted.replaceAll(',', '')) * 100);
    await capture(page, info, 'balance-after');
    submission = { disposition: 'completed', outputs: { accountNumber: facts.accountNumber, amountMinorUnits: facts.amountMinorUnits, currency: facts.currency, postedMinorUnits, receiptNumber } };
  } finally {
    main.server.close();
    frame.server.close();
    runStore.close();
  }
  const reportPath = join(root, 'report.json');
  const report = await session.verify(submission, { reportPath, dispose: true });
  await info.attach('verifier-report', { path: reportPath, contentType: 'application/json' });
  return report;
}

test('a cash deposit through the rendered frames is qualified by the evaluator run', async ({ page }, info) => {
  const report = await qualify(page, info);
  expect([report.databaseVerdict, report.checks.filter((check) => check.status !== 'pass')]).toEqual(['pass', []]);
});
