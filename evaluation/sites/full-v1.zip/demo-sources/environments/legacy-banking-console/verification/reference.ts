import { expect, type BrowserContext, type Frame, type Page, type TestInfo } from '@playwright/test';
import { z } from 'zod';

export function parseInstance(value: unknown) {
  return z.object({ instanceId: z.string(), entryUrl: z.url(), datasetId: z.string() }).parse(value);
}

export function datasetFromState(value: unknown): { datasetId: string; revision: number } {
  return z.object({ datasetId: z.string(), revision: z.number().int() }).parse(value);
}

export async function visibleFrame(context: BrowserContext, text: string): Promise<Frame> {
  let result: Frame | undefined;
  await expect.poll(async () => {
    const frames = context.pages().toReversed().flatMap(page => page.frames().toReversed());
    for (const frame of frames) {
      if (await frame.getByRole('heading', { name: text, exact: true }).first().isVisible().catch(() => false)) {
        result = frame;
        return true;
      }
    }
    for (const frame of frames) {
        if (!frame.parentFrame() && frame.childFrames().length > 0) continue;
        const marker = frame.getByText(text, { exact: true })
          .or(frame.getByRole('button', { name: text, exact: true }))
          .or(frame.getByRole('link', { name: text, exact: true }));
        if (await marker.filter({ visible: true }).first().isVisible().catch(() => false)) {
          result = frame;
          return true;
        }
    }
    return false;
  }, { message: `A visible document contains ${text}` }).toBe(true);
  if (!result) throw new Error(`No visible document contains ${text}`);
  return result;
}

export async function capture(page: Page, info: TestInfo, name: string): Promise<void> {
  const path = info.outputPath(`${name}.png`);
  await page.screenshot({ path, fullPage: true });
  await info.attach(name, { path, contentType: 'image/png' });
}

export function monitorBrowser(context: BrowserContext): string[] {
  const errors: string[] = [];
  const monitor = (page: Page) => {
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error') errors.push(message.text());
    });
  };
  context.pages().forEach(monitor);
  context.on('page', monitor);
  return errors;
}
