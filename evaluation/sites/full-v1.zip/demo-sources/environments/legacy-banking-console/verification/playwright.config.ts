import { defineConfig } from '@playwright/test';
import { join } from 'node:path';

const runName = process.env.MERIDIAN_VERIFICATION_RUN ?? `${new Date().toISOString().replaceAll(':', '-')}-${String(process.pid)}`;
process.env.MERIDIAN_VERIFICATION_RUN = runName;

export default defineConfig({
  testDir: '.',
  testMatch: ['**/*.spec.ts', '**/*.browser.ts'],
  timeout: 120_000,
  expect: { timeout: 8_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list'], ['json', { outputFile: join(import.meta.dirname, 'artifacts', runName, 'results.json') }]],
  outputDir: `artifacts/${runName}/browser`,
  use: {
    actionTimeout: 8_000,
    viewport: { width: 1440, height: 1000 },
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
});
