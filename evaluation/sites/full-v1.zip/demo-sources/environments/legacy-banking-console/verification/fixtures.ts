import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';

import { test as base, expect, type APIRequestContext } from '@playwright/test';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '@computer-use/financial-database';

import { startEnvironment } from '../src/main.js';

type Environment = Awaited<ReturnType<typeof startEnvironment>>;

type WorkerFixtures = {
  environment: Environment;
  adminToken: string;
};

type TestFixtures = {
  adminRequest: APIRequestContext;
};

export const test = base.extend<TestFixtures, WorkerFixtures>({
  adminToken: [async ({ browserName }, use) => {
    await use(`${browserName}-${randomUUID()}`);
  }, { scope: 'worker' }],
  environment: [async ({ adminToken }, use) => {
    const directory = mkdtempSync(join(tmpdir(), 'meridian-verify-'));
    const path = join(directory, 'financial.db');
    const world = `verify-${randomUUID().slice(0, 12)}`;
    const seedDatabase = openFinancialDatabase({ path });
    await seedDatabase.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: world, scale: 'small' });
    seedDatabase.close();
    const environment = await startEnvironment({
      port: 0,
      framePort: 0,
      adminPort: 0,
      adminToken,
      databasePath: path,
      world,
    });
    try {
      await use(environment);
    } finally {
      await environment.close();
      rmSync(directory, { recursive: true, force: true });
    }
  }, { scope: 'worker' }],
  adminRequest: async ({ playwright, environment, adminToken }, use) => {
    const request = await playwright.request.newContext({
      baseURL: environment.origins.admin,
      extraHTTPHeaders: { Authorization: `Bearer ${adminToken}` },
    });
    try {
      await use(request);
    } finally {
      await request.dispose();
    }
  },
});

export { expect };
