# legacy-banking-console implementation record

## Full-v1 qualification

Release verdict: FULL-V1 COMPLETE

- Source commit: `6bb6219c4fc24f7652055f93a2b33ff1fce3fd66`
- Evidence run: `full-v1-6bb6219-20260921-handoff`
- Visible task options: 102/102
- Workflow path and recovery branches: 30/30
- Family mechanism: frame-console
- Shared-world checks: 3/3
- Durable records: `environments/legacy-banking-console/verification/evidence/full-v1-6bb6219-20260921-handoff/`

The option-level matrix and exact commands, tests, visible entries/results, business effects, artifact paths, and recovery observations are in `capability-manifest.json` and the evidence directory.

## Runtime and verification

- Build: `npm run build` from `environments/legacy-banking-console`.
- Start: `npm run start` from `environments/legacy-banking-console`; use the package README for the default entry URL and database flags.
- Browser verification: `npm run verify` from the application package.
- Business data: the shared financial database and institution-scoped service boundary; no application-local business database.
- Release derivation: `npm --prefix environments run audit:full-v1`; release labels are not accepted without current tracked browser evidence.
