import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { expect, it } from 'vitest';

it('executes the CLI through a symlink and reports invalid arguments', () => {
  const directory = mkdtempSync(join(tmpdir(), 'meridian-cli-'));
  try {
    const entry = join(directory, 'meridian.ts');
    symlinkSync(fileURLToPath(new URL('../src/main.ts', import.meta.url)), entry);
    const result = spawnSync(process.execPath, [
      fileURLToPath(import.meta.resolve('tsx/cli')), entry, '--unsupported-option',
    ], { cwd: directory, encoding: 'utf8', timeout: 10_000 });
    expect(result.error).toBeUndefined();
    expect(result.status).toBe(1);
    expect(result.stderr).toContain('Unknown option: --unsupported-option');
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});
