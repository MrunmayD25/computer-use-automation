import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase, type FinancialDatabase } from '@computer-use/financial-database';
import { openFinancialStore, type FinancialStore, type ServiceCommand, type CommandOutcome } from '@computer-use/financial-database/services';

import { createInstanceStore, type InstanceStore, type ReviewTicket } from '../src/instance-store.js';
import type { ProfileId } from '../src/contracts.js';

export const TEST_OPERATORS = ['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0006', 'OP0007'] as const;

const databases: { database: FinancialDatabase; store: FinancialStore; directory: string }[] = [];

export function closeTestDatabases(): void {
  for (const entry of databases.splice(0)) {
    entry.store.close();
    entry.database.close();
    rmSync(entry.directory, { recursive: true, force: true });
  }
}

export interface TestFinancial {
  database: FinancialDatabase;
  store: FinancialStore;
  world: string;
  path: string;
}

/** One small seeded world per file; instances attach to it or clone from it. */
export async function createTestFinancial(): Promise<TestFinancial> {
  const directory = mkdtempSync(join(tmpdir(), 'meridian-test-'));
  const path = join(directory, 'financial.db');
  const world = `test-${randomUUID().slice(0, 12)}`;
  const database = openFinancialDatabase({ path });
  await database.seedWorld({ ...DEFAULT_SEED_MANIFEST, name: world, scale: 'small' });
  const store = openFinancialStore({ path });
  databases.push({ database, store, directory });
  return { database, store, world, path };
}

export function createTestStore(
  financial: TestFinancial,
  options: { maxInstances?: number; maxReviews?: number } = {},
): InstanceStore {
  return createInstanceStore({
    store: financial.store,
    database: financial.database,
    world: financial.world,
    institutionId: 'northstar',
    operators: TEST_OPERATORS,
    principalKind: 'human',
    exportDestinations: ['download'],
    ...options,
  });
}

export function review(store: InstanceStore, capability: string, command: ServiceCommand): ReviewTicket {
  return store.review(capability, 'test-nonce', command);
}

export function commit(store: InstanceStore, capability: string, ticket: ReviewTicket): CommandOutcome {
  if (ticket.kind !== 'reviewable') throw new Error(`Expected reviewable ticket, got ${ticket.kind}.`);
  const outcome = store.commit(capability, ticket.token);
  if (outcome.kind === 'missing') throw new Error('The ticket was not committed.');
  return outcome;
}

export function createInstance(
  store: InstanceStore,
  request: { seed: number; profile?: ProfileId } | { world: string; profile?: ProfileId },
): { instanceId: string; capability: string } {
  const created = store.create({ profile: 'baseline', ...request } as never);
  const capability = created.entryUrl.split('/')[2] ?? '';
  return { instanceId: created.instanceId, capability };
}
