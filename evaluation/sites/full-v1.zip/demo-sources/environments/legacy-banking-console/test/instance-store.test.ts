import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import { executeCommand, searchAccounts, searchMembers } from '@computer-use/financial-database/services';

import { closeTestDatabases, commit, createInstance, createTestFinancial, createTestStore, review, type TestFinancial } from './conftest.js';

let financial: TestFinancial;

beforeAll(async () => {
  financial = await createTestFinancial();
}, 120_000);

afterAll(() => closeTestDatabases());

function memberCount(store: ReturnType<typeof createTestStore>, capability: string, query?: string): number {
  const { context } = store.session(capability);
  return store.financial().read((database) =>
    searchMembers(database, context.binding.datasetId, { limit: 200, offset: 0, ...(query === undefined ? {} : { query, field: 'name' }) }).total);
}

describe('instance lifecycle', () => {
  it('binds a named world and exposes the seeded members', () => {
    const store = createTestStore(financial);
    const { instanceId, capability } = createInstance(store, { world: financial.world });
    const snapshot = store.snapshot(instanceId);
    expect(snapshot.institutionId).toBe('northstar');
    expect(snapshot.datasetId).toMatch(/^dataset-/);
    expect(memberCount(store, capability)).toBeGreaterThan(0);
  });

  it('creates isolated seed clones that never touch the world dataset', () => {
    const store = createTestStore(financial);
    const world = createInstance(store, { world: financial.world });
    const isolated = createInstance(store, { seed: 6_013 });
    store.switchOperator(isolated.capability, 'OP0002');
    expect(store.snapshot(isolated.instanceId).datasetId).not.toBe(store.snapshot(world.instanceId).datasetId);

    const worldMembers = memberCount(store, world.capability);
    const isolatedBefore = memberCount(store, isolated.capability);
    const ticket = review(store, isolated.capability, {
      kind: 'member.create', legalGiven: 'Isolated', legalFamily: 'Clone', preferredName: null,
      birthDate: '1990-01-01', email: null, phone: null, address: null,
    });
    expect(ticket.kind).toBe('reviewable');
    const outcome = commit(store, isolated.capability, ticket);
    expect(outcome.kind).toBe('committed');
    expect(memberCount(store, world.capability)).toBe(worldMembers);
    expect(memberCount(store, isolated.capability)).toBe(isolatedBefore + 1);
  });

  it('clears pending reviews on dispose and rejects dead capabilities', () => {
    const store = createTestStore(financial);
    const { instanceId, capability } = createInstance(store, { seed: 6_013 });
    store.dispose(instanceId);
    expect(() => store.session(capability)).toThrow('Unknown or expired UI capability.');
  });

  it('enforces instance capacity', () => {
    const store = createTestStore(financial, { maxInstances: 1 });
    createInstance(store, { seed: 6_013 });
    expect(() => createInstance(store, { seed: 6_013 })).toThrow('capacity');
  });
});

describe('review, commit and reconciliation', () => {
  it('commits a member registration through review and returns a durable receipt', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    store.switchOperator(capability, 'OP0002');
    const before = memberCount(store, capability);
    const ticket = review(store, capability, {
      kind: 'member.create', legalGiven: 'Reviewed', legalFamily: 'Receipt', preferredName: 'Rev',
      birthDate: '1985-05-05', email: 'rev.receipt@example.test', phone: null, address: null,
    });
    if (ticket.kind !== 'reviewable') throw new Error(`Expected reviewable, got ${ticket.kind}`);
    expect(ticket.review.consequences.length).toBeGreaterThan(0);
    const outcome = commit(store, capability, ticket);
    expect(outcome.kind).toBe('committed');
    if (outcome.kind !== 'committed') throw new Error('unreachable');
    expect(outcome.receipt.receiptNumber).toMatch(/^RCP/);
    expect(outcome.receipt.operationKind).toBe('member.create');
    expect(outcome.receipt.actor.actorNumber).toBe('OP0002');
    expect(memberCount(store, capability)).toBe(before + 1);
  });

  it('settles a repeated commit with the same receipt', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    store.switchOperator(capability, 'OP0002');
    const ticket = review(store, capability, {
      kind: 'member.create', legalGiven: 'Settled', legalFamily: 'Once', preferredName: null,
      birthDate: '1980-02-02', email: null, phone: null, address: null,
    });
    const first = commit(store, capability, ticket);
    const second = commit(store, capability, ticket);
    expect(first.kind).toBe('committed');
    expect(second.kind).toBe('committed');
    if (first.kind === 'committed' && second.kind === 'committed') {
      expect(second.receipt.receiptNumber).toBe(first.receipt.receiptNumber);
    }
  });

  it('produces a duplicate outcome when the same form is posted twice', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    store.switchOperator(capability, 'OP0002');
    const { context } = store.session(capability);
    const member = store.financial().read((database) =>
      searchMembers(database, context.binding.datasetId, { limit: 1, offset: 0 }).items[0]);
    if (member === undefined) throw new Error('Seeded member missing.');
    const command = {
      kind: 'member.note.add' as const, memberId: member.id, visibility: 'general' as const,
      text: 'Double post check',
    };
    const first = commit(store, capability, review(store, capability, command));
    // Same form nonce + same command => same operation key => durable duplicate detection.
    const second = commit(store, capability, review(store, capability, command));
    expect(first.kind).toBe('committed');
    expect(second.kind).toBe('duplicate');
    if (first.kind === 'committed' && second.kind === 'duplicate') {
      expect(second.receipt.receiptNumber).toBe(first.receipt.receiptNumber);
    }
  });

  it('rejects a stale expected version after a peer mutation', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    store.switchOperator(capability, 'OP0002');
    const { context } = store.session(capability);
    const member = store.financial().read((database) =>
      searchMembers(database, context.binding.datasetId, { limit: 1, offset: 0 }).items[0]);
    if (member === undefined) throw new Error('Seeded member missing.');

    // A peer updates the member's contact while the operator's form is open.
    const peer = executeCommand(store.financial(), { ...context, reference: 'peer' }, {
      kind: 'contact.update', memberId: member.id, expectedVersion: member.version, phone: '555-0100',
    }, `peer-${Date.now()}`);
    expect(peer.kind).toBe('committed');

    const ticket = review(store, capability, {
      kind: 'contact.update', memberId: member.id, expectedVersion: member.version, email: 'stale@example.test',
    });
    // The stale version is refused either at review or at commit.
    if (ticket.kind === 'rejected') {
      expect(ticket.code).toBe('stale_version');
      return;
    }
    const outcome = commit(store, capability, ticket);
    expect(outcome.kind).toBe('rejected');
    if (outcome.kind === 'rejected') expect(outcome.code).toBe('stale_version');
  });

  it('cancels a pending review without posting', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    store.switchOperator(capability, 'OP0002');
    const ticket = review(store, capability, {
      kind: 'member.create', legalGiven: 'Cancelled', legalFamily: 'Review', preferredName: null,
      birthDate: '1970-01-01', email: null, phone: null, address: null,
    });
    if (ticket.kind !== 'reviewable') throw new Error('expected reviewable');
    expect(store.cancelReview(capability, ticket.token)).toBe(true);
    expect(store.pendingFor(capability, ticket.token)).toBeUndefined();
    const outcome = store.commit(capability, ticket.token);
    expect(outcome.kind).toBe('missing');
  });
});

describe('operator switching', () => {
  it('commits under the switched operator identity and clears pending reviews', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    store.switchOperator(capability, 'OP0002');
    const pending = review(store, capability, {
      kind: 'member.create', legalGiven: 'Switch', legalFamily: 'Cleared', preferredName: null,
      birthDate: '1975-03-03', email: null, phone: null, address: null,
    });
    if (pending.kind !== 'reviewable') throw new Error('expected reviewable');
    store.switchOperator(capability, 'OP0002');
    expect(store.pendingFor(capability, pending.token)).toBeUndefined();
    const ticket = review(store, capability, {
      kind: 'member.create', legalGiven: 'Second', legalFamily: 'Operator', preferredName: null,
      birthDate: '1975-03-04', email: null, phone: null, address: null,
    });
    const outcome = commit(store, capability, ticket);
    if (outcome.kind !== 'committed') throw new Error(`expected committed, got ${outcome.kind}`);
    expect(outcome.receipt.actor.actorNumber).toBe('OP0002');
  });

  it('rejects an operator outside the authorized set', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    expect(() => store.switchOperator(capability, 'OP0099')).toThrow('not authorized');
  });
});

describe('deposit and transfer through the store', () => {
  it('posts a deposit and reconciles it through activity', () => {
    const store = createTestStore(financial);
    const { capability } = createInstance(store, { seed: 6_013 });
    store.switchOperator(capability, 'OP0002');
    const { context } = store.session(capability);
    const account = store.financial().read((database) =>
      searchAccounts(database, context.binding.datasetId, { limit: 10, offset: 0 }).items.find((item) => item.status === 'open'));
    if (account === undefined) throw new Error('Seeded open account missing.');
    const ticket = review(store, capability, {
      kind: 'cash.deposit', accountId: account.id, expectedVersion: account.version,
      amount: { minorUnits: 12_500, currency: 'USD' }, description: 'Verification deposit',
    });
    const outcome = commit(store, capability, ticket);
    expect(outcome.kind).toBe('committed');
    if (outcome.kind !== 'committed') throw new Error('unreachable');
    const after = store.financial().read((database) =>
      searchAccounts(database, context.binding.datasetId, { ids: [account.id], limit: 1, offset: 0 }).items[0]);
    expect(after?.postedMinorUnits).toBe(account.postedMinorUnits + 12_500);
  });
});
