import { randomUUID } from 'node:crypto';

import { afterAll, beforeAll, describe, expect, it } from 'vitest';

import { startEnvironment, type EnvironmentHandle } from '../src/main.js';
import { closeTestDatabases, createTestFinancial, type TestFinancial } from './conftest.js';

let financial: TestFinancial;
let handle: EnvironmentHandle;
let token: string;

beforeAll(async () => {
  financial = await createTestFinancial();
  token = randomUUID();
  handle = await startEnvironment({
    port: 0, framePort: 0, adminPort: 0,
    adminToken: token,
    databasePath: financial.path,
    world: financial.world,
    demo: true,
  });
}, 120_000);

afterAll(async () => {
  await handle.close();
  closeTestDatabases();
});

function admin(path: string, init: RequestInit = {}): Promise<Response> {
  return fetch(`${handle.origins.admin}${path}`, {
    ...init,
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json', ...Object.fromEntries(new Headers(init.headers ?? {}).entries()) },
  });
}

async function createInstance(body: Record<string, unknown>): Promise<{ entryUrl: string; datasetId: string; instanceId: string }> {
  const response = await admin('/instances', { method: 'POST', body: JSON.stringify(body) });
  expect(response.status).toBe(201);
  return response.json() as Promise<{ entryUrl: string; datasetId: string; instanceId: string }>;
}

/** Extracts a hidden input value from a rendered legacy form. */
function hidden(html: string, name: string): string {
  const match = new RegExp(`name="${name}" value="([^"]*)"`).exec(html);
  if (match === null) throw new Error(`Missing hidden field ${name}`);
  return match[1] ?? '';
}

describe('administration', () => {
  it('rejects requests without a bearer token and browser-shaped requests', async () => {
    expect((await fetch(`${handle.origins.admin}/instances`, { method: 'POST', body: '{}' })).status).toBe(401);
    const browserLike = await fetch(`${handle.origins.admin}/worlds`, {
      headers: { authorization: `Bearer ${token}`, 'sec-fetch-site': 'cross-site' },
    });
    expect(browserLike.status).toBe(403);
  });

  it('lists the seeded world and creates a world-bound instance', async () => {
    const worlds = await admin('/worlds');
    expect(worlds.status).toBe(200);
    const listed = (await worlds.json()) as { worlds: { name: string; bindings: { institutionId: string }[] }[] };
    expect(listed.worlds.map((world) => world.name)).toContain(financial.world);

    const created = await createInstance({ world: financial.world, profile: 'baseline' });
    expect(created.entryUrl).toContain(`${handle.origins.main}/app/`);
    const state = await admin(`/instances/${created.instanceId}/state`);
    expect(((await state.json()) as { datasetId: string }).datasetId).toBe(created.datasetId);
  });

  it('resets only the requesting instance', async () => {
    const created = await createInstance({ seed: 4_242, profile: 'baseline' });
    const peer = await createInstance({ world: financial.world, profile: 'baseline' });
    const reset = await admin(`/instances/${created.instanceId}/reset`, { method: 'POST', body: '{}' });
    expect(reset.status).toBe(201);
    const replacement = (await reset.json()) as { instanceId: string; datasetId: string };
    expect(replacement.datasetId).not.toBe(created.datasetId);
    const peerState = await admin(`/instances/${peer.instanceId}/state`);
    expect(((await peerState.json()) as { datasetId: string }).datasetId).toBe(peer.datasetId);
  });
});

describe('frame interface over HTTP', () => {
  it('serves the shell, nested workspace documents and member search', async () => {
    const { entryUrl } = await createInstance({ world: financial.world, profile: 'combined-hard' });
    const shell = await (await fetch(entryUrl)).text();
    expect(shell).toContain('MERIDIAN');
    const workspace = await (await fetch(`${handle.origins.main}${new URL(entryUrl).pathname.replace('/shell', '/workspace')}`)).text();
    expect(workspace).toContain('iframe');
    const search = await (await fetch(`${handle.origins.main}${new URL(entryUrl).pathname.replace('/shell', '/search')}`)).text();
    expect(search).toContain('Member Search');
  });

  it('rejects mutations without the session CSRF token', async () => {
    const { entryUrl } = await createInstance({ world: financial.world, profile: 'baseline' });
    const base = new URL(entryUrl).pathname.replace('/shell', '');
    const response = await fetch(`${handle.origins.main}${base}/operations/member.note.add`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: 's_member=x&visibility=general&text=x',
    });
    expect(response.status).toBe(403);
  });

  it('runs a contact update through review and commit via the rendered forms', async () => {
    const { entryUrl } = await createInstance({ world: financial.world, profile: 'baseline' });
    const base = new URL(entryUrl).pathname.replace('/shell', '');

    // OP0001 is the read-only viewer; switch to the servicer operator through the rendered form.
    const operatorPage = await (await fetch(`${handle.origins.main}${base}/operator`)).text();
    const opCsrf = hidden(operatorPage, 'csrfToken');
    const opNonce = hidden(operatorPage, 'formNonce');
    await fetch(`${handle.origins.main}${base}/operator`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ csrfToken: opCsrf, formNonce: opNonce, actorNumber: 'OP0002' }).toString(),
    });

    // Step 1: the operation page offers the member picker.
    const pick = await (await fetch(`${handle.origins.main}${base}/operations/contact.update`)).text();
    expect(pick).toContain('name="s_member"');
    const member = /name="s_member"[^>]*>.*?<option value="([^"]+)"/s.exec(pick);
    expect(member).not.toBeNull();

    // Step 2: member selected -> parameter form with bound version.
    const params = await (await fetch(`${handle.origins.main}${base}/operations/contact.update?s_member=${encodeURIComponent(member?.[1] ?? '')}`)).text();
    const csrf = hidden(params, 'csrfToken');
    const nonce = hidden(params, 'formNonce');
    const memberVersion = hidden(params, 'v_member');
    const memberId = hidden(params, 's_member');

    // POST -> review document.
    const reviewResponse = await fetch(`${handle.origins.main}${base}/operations/contact.update`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        csrfToken: csrf, formNonce: nonce, s_member: memberId, v_member: memberVersion,
        email: 'operator.http@example.test',
      }).toString(),
    });
    const reviewPage = await reviewResponse.text();
    expect(reviewResponse.status).toBe(200);
    expect(reviewPage).toContain('Review');
    const reviewToken = hidden(reviewPage, 'reviewToken');

    // Commit -> receipt document.
    const commitResponse = await fetch(`${handle.origins.main}${base}/commit`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ csrfToken: csrf, formNonce: nonce, reviewToken }).toString(),
    });
    const receiptPage = await commitResponse.text();
    expect(receiptPage).toContain('Receipt');
    expect(receiptPage).toContain('contact.update');
  });

  it('rejects cross-origin posts from an unexpected origin header', async () => {
    const { entryUrl } = await createInstance({ world: financial.world, profile: 'baseline' });
    const base = new URL(entryUrl).pathname.replace('/shell', '');
    const response = await fetch(`${handle.origins.main}${base}/cancel`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded', origin: 'http://evil.example' },
      body: 'csrfToken=x&reviewToken=x',
    });
    expect(response.status).toBe(403);
  });
});
