import { describe, expect, it } from 'vitest';

import { Form, FormError, operationFor, OPERATIONS, operationsByGroup } from '../src/operations.js';
import { SUBJECT_RESOLVERS } from '../src/prerequisites.js';

describe('operation catalog', () => {
  it('exposes every service command kind', () => {
    const kinds = new Set<string>(OPERATIONS.map((operation) => operation.kind));
    for (const kind of [
      'member.create', 'member.organization.create', 'contact.update', 'member.note.add',
      'account.open', 'account.close', 'account.nickname.update', 'account.statement_delivery.update',
      'cash.deposit', 'cash.withdraw', 'transfer.internal',
      'case.open', 'case.assign', 'case.transition', 'case.note.add', 'case.close', 'case.reopen',
      'case.subject.correct', 'case.escalate', 'case.information.request',
      'search.saved.create', 'search.saved.update', 'search.saved.delete',
      'member.identity_evidence.register', 'member.identity.verify', 'member.legal_name.update',
      'member.preferred_name.update', 'member.deceased.record', 'member.merge',
      'member.beneficial_owners.update', 'member.tax_classification.update',
      'document.index', 'document.bundle.redact', 'document.signature.collect',
      'document.annotation.update', 'document.metadata.update', 'document.customer_export.create',
      'document.retention_hold.apply', 'document.loan_closure.issue',
      'consent.delivery.record', 'consent.withdraw',
      'communication.send', 'communication.delivery.update', 'communication.preference.update',
      'maintenance.draft.save', 'maintenance.draft.amend', 'maintenance.request.submit',
      'maintenance.request.withdraw', 'maintenance.request.review', 'maintenance.request.process',
      'maintenance.address.reconcile', 'maintenance.address.destination.update', 'edit.cancel',
      'account.product.convert', 'account.owner.add', 'account.signer.remove',
      'account.overdraft_limit.update', 'account.maturity.instruct',
      'account.hold.place', 'account.hold.release', 'account.restriction.apply', 'account.restriction.release',
      'fee.assess', 'fee.waiver.create', 'fee.refund',
      'cash.deposit.reverse', 'cash.withdrawal.reverse', 'transfer.internal.reverse',
      'interest.adjust', 'transaction.effective_date.correct', 'transaction.description.update',
      'beneficiary.create', 'beneficiary.verify', 'beneficiary.routing.update', 'beneficiary.retire',
      'payment.create', 'payment.submit', 'payment.approve_release', 'payment.settle', 'payment.cancel',
      'payment.return.resolve', 'payment.schedule.create', 'payment.schedule.end',
      'payment.schedule.materialize', 'payment.occurrence.amend',
      'card.limit.update', 'card.lock.update', 'card.replace',
      'dispute.open', 'dispute.evidence.submit', 'dispute.provisional_credit.issue', 'dispute.settle',
      'loan.application.prepare', 'loan.payoff.quote', 'loan.payment.allocate', 'loan.close',
      'batch.import', 'batch.contacts.apply', 'batch.fee_refunds.apply',
      'reconciliation.suspense.investigate', 'reconciliation.suspense.clear',
      'approval.decide',
    ]) expect(kinds.has(kind), `missing ${kind}`).toBe(true);
  });

  it('declares subjects that resolve through governed resolvers only', () => {
    for (const operation of OPERATIONS) {
      for (const subject of operation.subjects) {
        expect(SUBJECT_RESOLVERS[subject.kind], `${operation.kind} subject ${subject.kind}`).toBeDefined();
      }
    }
  });

  it('groups every operation for the operations menu', () => {
    const grouped = new Set(operationsByGroup().flatMap((group) => group.operations.map((operation) => operation.kind)));
    for (const operation of OPERATIONS) expect(grouped.has(operation.kind)).toBe(true);
  });
});

describe('form boundary validation', () => {
  const env = {} as never;
  const noSubjects = {} as never;

  it('requires mandatory fields', () => {
    const spec = operationFor('member.create');
    expect(spec).toBeDefined();
    expect(() => spec?.build(new Form({ legalGiven: 'A' }), noSubjects, env)).toThrow(FormError);
  });

  it('parses decimal amounts into exact minor units', () => {
    const form = new Form({ amount: '125.50', amount__ccy: 'USD', description: 'counter deposit', s_account: 'acc-1', v_account: '7' });
    const spec = operationFor('cash.deposit');
    const command = spec?.build(form, { account: { id: 'acc-1', label: 'a', version: 7, data: {} } }, env);
    expect(command).toMatchObject({ kind: 'cash.deposit', accountId: 'acc-1', expectedVersion: 7, amount: { minorUnits: 12_550, currency: 'USD' } });
  });

  it('rejects malformed amounts instead of rounding', () => {
    const spec = operationFor('cash.deposit');
    expect(() => spec?.build(
      new Form({ amount: '12.505', amount__ccy: 'USD', description: 'x', s_account: 'a', v_account: '1' }),
      { account: { id: 'a', label: 'a', version: 1, data: {} } }, env,
    )).toThrow(FormError);
  });

  it('maps the dash convention to clearing an optional contact value', () => {
    const spec = operationFor('contact.update');
    const command = spec?.build(
      new Form({ email: '-', phone: '555-0199', s_member: 'm-1', v_member: '3' }),
      { member: { id: 'm-1', label: 'm', version: 3, data: {} } }, env,
    );
    expect(command).toMatchObject({ kind: 'contact.update', memberId: 'm-1', expectedVersion: 3, email: null, phone: '555-0199' });
  });
});
