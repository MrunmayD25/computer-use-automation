# Meridian Core legacy banking console

A local, synthetic banking application with nested cross-origin frames, dense tables, weak control semantics, and independently scrolling panels. This folder owns its UI and functional tests. The shared package `@computer-use/financial-database` in `../database/financial/` owns business records, seeded worlds, service commands, reviews, approvals, receipts, and domain rules. Future applications belong in sibling folders under `environments/`.

The application exposes the complete member-servicing and financial command surface — members, accounts, money movement, payments, beneficiaries, cards, disputes, lending, holds, fees, batches, suspense, cases, communications, approvals, registers, statements and exports — through rendered legacy documents. It does not assign agent tasks or grade workflows. A separate administration interface manages isolated synthetic instances.

## Run the application

Use Node.js 22.15 or newer. From the repository root, install the workspace dependencies, build the packages, and start the application.

```sh
cd environments
npm ci
npm run build
npm start --workspace legacy-banking-console -- --verbose
```

Open `http://127.0.0.1:4310`. The root URL provides a reusable demonstration instance. The application uses a second origin at `http://127.0.0.1:4311` for frame documents. Keep both origins available to your browser or future computer-use adapter.

Stop the server with Ctrl+C. Shared business records persist in SQLite across restarts. UI capabilities and open forms expire when the process exits. Open the root URL again to start a new session against the existing demonstration dataset. DOM identifiers are deliberately regenerated between document loads.

After the workspace build, you can also launch from this application's directory with `node dist/src/main.js --verbose`. Optional CLI flags are `--port`, `--frame-port`, `--admin-port`, `--admin-token-file`, and `--database`.

The default database is `environments/database/financial/.runtime/financial.sqlite`, independent of the working directory. `--database <path>` selects a different file; `FINANCIAL_DATABASE_PATH` overrides the default when the flag is absent. The default world is `financial-demo-v1` with the `northstar` institution; it is seeded only when absent. See the [financial database guide](../database/financial/README.md) for ownership and storage. If running a second copy of this application, use distinct ports and an administration token file.

## Application modules

- Members supports browsing, search, creation, contact and identity maintenance, notes, and merges.
- Accounts supports inquiry, opening, closing, nickname and statement-delivery maintenance, holds, restrictions, fees, and suspense.
- Transactions supports history, deposits, withdrawals, reversals, internal transfers, and corrections.
- Payments supports payment creation and lifecycle, beneficiaries, schedules, direct debits, and credits.
- Cards, disputes, and lending support their full service surfaces.
- Batches supports payment and member-import batches with per-item release.
- Cases supports opening, routing, linking, resolving, communications, and requests.
- Statements supports a separate inquiry window, stored document downloads, and CSV/PDF export.
- Activity exposes operations, durable receipts, and reconciliation positions.
- Approvals supports requesting, deciding, and releasing approval-gated operations.

Use visible record identifiers to distinguish repeated names and controls. The application is designed for desktop-sized viewports; narrow windows can require scrolling.

The demo uses `combined-hard`: four nested frame boundaries alternate between origins, with an additional account-register frame on member details. It combines repeated controls, hidden templates, generated DOM identifiers, weak semantics, independent scrolling, clipped sticky tables, scaled geometry, and separate statement windows.

Instances can select one of 16 profiles: `baseline`, `deep-frames`, `cross-origin`, `repeated-controls`, `hidden-duplicates`, `nested-scroll`, `sticky-clipping`, `scaled-geometry`, `generated-ids`, `weak-semantics`, `focus-replacement`, `separate-inquiry-window`, `navigation-hard`, `targeting-hard`, `geometry-hard`, or `combined-hard`. These are layouts of this one application.

## Manage instances

Instance administration listens separately at `http://127.0.0.1:4312`. Startup writes its bearer credential to `.runtime/admin.token` with owner-only permissions. The token is not embedded in the application or printed in request logs.

The administration interface accepts JSON requests authenticated with `Authorization: Bearer <token>`.

For example, `{"seed":42,"profile":"combined-hard"}` creates an isolated clone of the configured world and a UI instance. The response contains `instanceId`, `datasetId`, and `entryUrl`. To share its records with another instance or application process, send `{"datasetId":"<returned datasetId>","profile":"baseline"}` to that process's administration listener; both processes must use the same database file. To bind directly to a shared named world, send `{"world":"financial-demo-v1","profile":"baseline","institutionId":"northstar"}`. Supply exactly one of `seed`, `datasetId`, or `world`.

| Method | Path | Purpose |
| --- | --- | --- |
| POST | `/instances` | Create an isolated clone and UI instance, attach a UI instance to an existing dataset, or bind an instance to a named world. |
| GET | `/instances/:id/state` | Inspect its current records and action history. |
| GET | `/instances/:id/export` | Export its application state. |
| POST | `/instances/:id/reset` | Replace only this instance with a fresh clone or re-attachment and a new instance identity. |
| DELETE | `/instances/:id` | Dispose of the UI instance and preserve its dataset. |

A reset invalidates this instance's old URL. Other instances attached to the old dataset retain their records and access. Administration rejects browser-origin requests and does not enable CORS. Keep administration credentials, filesystem access, and unrestricted network tools outside a future agent's sandbox. Loopback ports cannot protect against another unrestricted process on the same computer.

This interface contains no goals, expected answers, or grading endpoints.

## Verify application behavior

From `environments/`, install the test browser once, then run the checks.

```sh
npx playwright install chromium
npm run build
npm run check
npm run verify
```

Store tests check review/commit flows, receipts, stale and duplicate outcomes, operator grants, reset isolation, and capacity. HTTP tests check administration and request boundaries. Playwright tests exercise ordinary UI operations across all 16 structural profiles and inspect frame structure; one evaluator-qualified test drives a deposit inside an isolated verification run and lets the evaluator grade the resulting state. These are application functional tests, not agent benchmark workflows or evidence of model-driven discovery.

Browser checks start and close their own listeners on ephemeral ports and use temporary databases. They do not change the shared demonstration dataset. Results are saved in this application's `verification/artifacts/<run-id>/results.json`, with screenshots and failure traces under the same run's `browser/` directory. Each invocation uses a unique directory.

The [specification](SPEC.md) defines the application scope. The implementation record (historical material omitted from this bundle) records actual verification results and current limitations.

