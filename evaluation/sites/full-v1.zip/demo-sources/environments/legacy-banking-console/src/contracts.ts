export type ProfileId =
  | 'baseline'
  | 'deep-frames'
  | 'cross-origin'
  | 'repeated-controls'
  | 'hidden-duplicates'
  | 'nested-scroll'
  | 'sticky-clipping'
  | 'scaled-geometry'
  | 'generated-ids'
  | 'weak-semantics'
  | 'focus-replacement'
  | 'separate-inquiry-window'
  | 'navigation-hard'
  | 'targeting-hard'
  | 'geometry-hard'
  | 'combined-hard';

/**
 * How an instance binds its financial world.
 * `seed` clones a freshly seeded isolated world; `datasetId` attaches to an existing shared
 * dataset; `world` attaches to one institution dataset of a named seeded world.
 */
export type CreateInstanceRequest =
  | { seed: number; profile: ProfileId; institutionId?: string | undefined }
  | { datasetId: string; profile: ProfileId }
  | { world: string; institutionId?: string | undefined; profile: ProfileId };

export interface CreatedInstance {
  instanceId: string;
  entryUrl: string;
  institutionId: string;
  datasetId: string;
}

/** What the administration listener reports about a live instance. */
export interface InstanceSnapshot {
  instanceId: string;
  profile: ProfileId;
  institutionId: string;
  datasetId: string;
  actorNumber: string;
  source: string;
  createdAt: string;
  pendingReviews: number;
  settledReceipts: number;
  revision: number;
}

export interface EnvironmentConfig {
  port?: number;
  framePort?: number;
  adminPort?: number;
  adminToken: string;
  verbose?: boolean;
  maxInstances?: number;
  /** Bind the shared demonstration world at startup (default true). */
  demo?: boolean;
  databasePath?: string;
  databaseBusyTimeoutMs?: number;
  /** Named financial world bound at startup (default: the canonical promoted world). */
  world?: string;
  /** Institution dataset the demonstration session binds (default northstar). */
  institutionId?: string | undefined;
  /** Operator actor numbers allowed to sign on through the console. */
  operators?: readonly string[];
  /** Allow-listed local export destinations offered to operators. */
  exportDestinations?: readonly string[];
}

export interface EnvironmentHandle {
  origins: {
    main: string;
    frame: string;
    admin: string;
  };
  close(): Promise<void>;
}
