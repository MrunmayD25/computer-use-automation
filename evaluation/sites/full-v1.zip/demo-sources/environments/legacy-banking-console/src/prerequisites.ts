import {
  CAPABILITY_GRANTS,
  accountDetail,
  authorizeQuery,
  caseDetail,
  listApprovals,
  listDocumentAnnotations,
  listMemberAddressDestinations,
  listMemberAddresses,
  listMemberCommunicationJobs,
  listMemberConsents,
  listMemberDocumentVersions,
  listMemberIdentityEvidence,
  listMemberMaintenanceRequests,
  listSavedSearches,
  listServicingQueues,
  listEffectivePolicyVersions,
  memberDetail,
  queryFinance,
  queryMemberMergePlan,
  referenceData,
  searchAccounts,
  searchCases,
  searchDocuments,
  searchMembers,
  type CommandKind,
  type FinanceRecordKind,
  type FinancialStore,
  type Rejection,

  type ServiceContext,
  type SqlDatabase,
} from '@computer-use/financial-database/services';

/** Backend environment for prerequisite reads: trusted binding plus the resolved operator. */
export interface Env {
  store: FinancialStore;
  context: ServiceContext;
  actorNumber: string;
  exportDestinations: readonly string[];
}

export interface Option {
  value: string;
  label: string;
}

/** A record the operator selected; versions and fingerprints bind the reviewed state. */
export interface ResolvedSubject {
  id: string;
  label: string;
  version?: number;
  fingerprint?: string;
  updatedAt?: string;
  memberId?: string;
  memberNumber?: string;
  partyId?: string;
  accountId?: string;
  accountNumber?: string;
  caseId?: string;
  documentId?: string;
  state?: string;
  currency?: string;
  data: Record<string, unknown>;
}

export type { Rejection };

export type Resolved = Record<string, ResolvedSubject>;

const rejected = (code: Rejection['code'], message: string): Rejection => ({ kind: 'rejected', code, message });
export const notFound = (label: string): Rejection => rejected('not_found', `The ${label} does not exist at this institution.`);

export function isRejected(value: unknown): value is Rejection {
  return typeof value === 'object' && value !== null && (value as { kind?: string }).kind === 'rejected';
}

/** Runs a read inside the dataset scope after the session's read authority is checked. */
export function read<T>(env: Env, callback: (database: SqlDatabase) => T): T | Rejection {
  return env.store.read((database) => {
    const denied = authorizeQuery(database, env.context);
    if (denied !== null) return denied;
    return callback(database);
  });
}

type Row = Record<string, string | number | bigint | null>;
const text = (value: unknown): string => (typeof value === 'string' ? value : typeof value === 'number' || typeof value === 'bigint' ? String(value) : '');
const allRows = (env: Env, sql: string, ...parameters: (string | number | null)[]): Row[] | Rejection =>
  read(env, (database) => database.prepare(sql).all(...parameters) as Row[]);
const oneRow = (env: Env, sql: string, ...parameters: (string | number | null)[]): Row | undefined | Rejection =>
  read(env, (database) => database.prepare(sql).get(...parameters) as Row | undefined);

const sqlOptions = (env: Env, sql: string, label: (row: Row) => string, ...parameters: (string | number | null)[]): Option[] | Rejection => {
  const result = allRows(env, sql, ...parameters);
  if (isRejected(result)) return result;
  return result.map((item) => ({ value: text(item.id), label: label(item) }));
};

function targetKindLabel(target: unknown): string {
  if (target !== null && typeof target === 'object' && !Array.isArray(target)) {
    const kind = (target as { kind?: unknown }).kind;
    if (typeof kind === 'string') return kind;
  }
  return 'approval';
}

export const pickers = {
  members(env: Env): Option[] | Rejection {
    const result = read(env, (database) => searchMembers(database, env.context.binding.datasetId, { limit: 200, offset: 0 }));
    if (isRejected(result)) return result;
    return result.items.map((member) => ({ value: member.id, label: `${member.memberNumber} · ${member.displayName} · ${member.status}` }));
  },
  organizationMembers(env: Env): Option[] | Rejection {
    return sqlOptions(env,
      `SELECT m.id,m.member_number,p.display_name,m.status FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id WHERE m.dataset_id=? AND p.kind='organization' ORDER BY m.member_number`,
      (item) => `${text(item.member_number)} · ${text(item.display_name)} · ${text(item.status)}`, env.context.binding.datasetId);
  },
  accounts(env: Env, memberId?: string): Option[] | Rejection {
    const result = read(env, (database) => searchAccounts(database, env.context.binding.datasetId, { limit: 200, offset: 0, ...(memberId === undefined ? {} : { memberId }) }));
    if (isRejected(result)) return result;
    return result.items.map((account) => ({ value: account.id, label: `${account.accountNumber} · ${account.productName} · ${account.status} · ${account.currency}` }));
  },
  products(env: Env, family?: string): Option[] | Rejection {
    return sqlOptions(env,
      `SELECT id,code,name,currency FROM products WHERE dataset_id=?${family === undefined ? '' : ' AND family=?'} AND status='active' ORDER BY code`,
      (item) => `${text(item.code)} · ${text(item.name)} · ${text(item.currency)}`,
      env.context.binding.datasetId, ...(family === undefined ? [] : [family]));
  },
  queues(env: Env): Option[] | Rejection {
    const result = read(env, (database) => listServicingQueues(database, env.context));
    if (isRejected(result)) return result;
        return result.value.map((queue) => ({ value: queue.id, label: `${queue.code} · ${queue.name} · ${queue.visibility}` }));
  },
  actors(env: Env): Option[] | Rejection {
    return sqlOptions(env, `SELECT id,actor_number,display_name,status FROM actors WHERE dataset_id=? AND status='active' ORDER BY actor_number`,
      (item) => `${text(item.actor_number)} · ${text(item.display_name)}`, env.context.binding.datasetId);
  },
  caseWorkers(env: Env): Option[] | Rejection {
    const result = read(env, (database) => referenceData(database, env.context.binding.datasetId, env.context.binding.institutionId).caseWorkers);
    if (isRejected(result)) return result;
    return result.map((actor) => ({ value: actor.id, label: `${actor.actorNumber} · ${actor.displayName}` }));
  },
  /** Active operators authorized for the target command's grant, excluding the requesting maker. */
  checkers(env: Env, commandKind: CommandKind): Option[] | Rejection {
    const grants: readonly string[] = CAPABILITY_GRANTS[commandKind];
    const result = allRows(env,
      `SELECT DISTINCT a.id,a.actor_number,a.display_name FROM actors a
       JOIN actor_roles ar ON ar.dataset_id=a.dataset_id AND ar.actor_id=a.id AND ar.ends_at IS NULL
       JOIN role_permissions rp ON rp.dataset_id=ar.dataset_id AND rp.role_id=ar.role_id
       WHERE a.dataset_id=? AND a.status='active' AND a.actor_number<>? AND rp.permission IN (${grants.map(() => '?').join(',') || "''"})
       ORDER BY a.actor_number`,
      env.context.binding.datasetId, env.actorNumber, ...grants);
    if (isRejected(result)) return result;
    return result.map((item) => ({ value: text(item.id), label: `${text(item.actor_number)} · ${text(item.display_name)}` }));
  },
  policyVersions(env: Env): Option[] | Rejection {
    const result = read(env, (database) => listEffectivePolicyVersions(database, env.context));
    if (isRejected(result)) return result;
        return result.value.map((policy) => ({ value: policy.id, label: `${policy.name} v${policy.version} · effective ${policy.effectiveAt.slice(0, 10)}` }));
  },
  evidence(env: Env, memberId: string): Option[] | Rejection {
    const result = read(env, (database) => listMemberIdentityEvidence(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.id, label: `${item.kind} · ${item.sourceReference} · ${item.status}` }));
  },
  documentVersions(env: Env, memberId?: string): Option[] | Rejection {
    if (memberId === undefined) {
      const result = read(env, (database) => searchDocuments(database, env.context.binding.datasetId, { limit: 200, offset: 0 }));
      if (isRejected(result)) return result;
      return result.items.map((item) => ({ value: item.versionId, label: `${item.displayName} v${item.version} · ${item.memberNumber} · ${item.documentType}` }));
    }
    const result = read(env, (database) => listMemberDocumentVersions(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.versionId, label: `${item.displayName} v${item.version} · ${item.documentType} · ${item.status}` }));
  },
  /** Document versions whose option value carries the content digest for exact evidence binding. */
  documentVersionsWithDigest(env: Env, memberId: string): Option[] | Rejection {
    const result = read(env, (database) => listMemberDocumentVersions(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: `${item.versionId}|${item.digest}`, label: `${item.displayName} v${item.version} · ${item.documentType} · ${item.status}` }));
  },
  documents(env: Env, memberId?: string): Option[] | Rejection {
    const result = read(env, (database) => searchDocuments(database, env.context.binding.datasetId, { limit: 200, offset: 0, ...(memberId === undefined ? {} : { memberId }) }));
    if (isRejected(result)) return result;
    return result.items.map((item) => ({ value: item.documentId, label: `${item.displayName} · ${item.memberNumber} · ${item.documentType}` }));
  },
  consents(env: Env, memberId: string): Option[] | Rejection {
    const result = read(env, (database) => listMemberConsents(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.id, label: `${item.purpose} · ${item.channel} · ${item.state} · ${item.effectiveAt.slice(0, 10)}` }));
  },
  addresses(env: Env, memberId: string): Option[] | Rejection {
    const result = read(env, (database) => listMemberAddresses(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.addressId, label: `${item.line1}, ${item.city} ${item.postalCode} · ${item.purpose} · ${item.evidenceStatus}` }));
  },
  partyAddresses(env: Env, memberId: string): Option[] | Rejection {
    const result = read(env, (database) => listMemberAddresses(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.partyAddressId, label: `${item.line1}, ${item.city} ${item.postalCode} · ${item.purpose} · ${item.evidenceStatus}` }));
  },
  addressDestinations(env: Env, memberId: string): Option[] | Rejection {
    const result = read(env, (database) => listMemberAddressDestinations(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.id, label: `${item.context} · ${item.address.line1}, ${item.address.city} · effective ${item.effectiveAt.slice(0, 10)}${item.endsAt === null ? '' : ' · ended'}` }));
  },
  cases(env: Env, memberId?: string): Option[] | Rejection {
    const result = read(env, (database) => searchCases(database, env.context.binding.datasetId, { limit: 200, offset: 0, ...(memberId === undefined ? {} : { memberId }) }));
    if (isRejected(result)) return result;
    return result.items.map((item) => ({ value: item.id, label: `${item.caseNumber} · ${item.summary.slice(0, 48)} · ${item.state}` }));
  },
  maintenanceRequests(env: Env, memberId?: string): Option[] | Rejection {
    if (memberId === undefined) {
      return sqlOptions(env, `SELECT id,request_number,subject,state FROM maintenance_requests WHERE dataset_id=? ORDER BY updated_at DESC LIMIT 500`,
        (item) => `${text(item.request_number)} · ${text(item.subject).slice(0, 40)} · ${text(item.state)}`, env.context.binding.datasetId);
    }
    const result = read(env, (database) => listMemberMaintenanceRequests(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.requestNumber, label: `${item.requestNumber} · ${item.subject.slice(0, 40)} · ${item.state}` }));
  },
  approvals(env: Env, status?: string): Option[] | Rejection {
    const result = listApprovals(env.store, env.context, 200);
    if (result.kind !== 'found') return result;
    return result.approvals
      .filter((approval) => status === undefined || approval.status === status)
      .map((approval) => ({ value: approval.id, label: `${approval.status} · ${targetKindLabel(approval.target)} · expires ${approval.expiresAt.slice(0, 10)}` }));
  },
  savedSearches(env: Env): Option[] | Rejection {
    const result = read(env, (database) => listSavedSearches(database, env.context.binding.datasetId, env.context.actorId));
    if (isRejected(result)) return result;
    return result.map((item) => ({ value: `${item.id}|${item.revision}`, label: `${item.name} · ${item.visibility} · ${item.owner.actorNumber}` }));
  },
  communicationJobs(env: Env, memberId?: string): Option[] | Rejection {
    if (memberId === undefined) {
      return sqlOptions(env, `SELECT id,purpose,channel,destination,state,created_at FROM communication_jobs WHERE dataset_id=? ORDER BY created_at DESC LIMIT 500`,
        (item) => `${text(item.purpose)} · ${text(item.channel)} · ${text(item.state)} · ${text(item.created_at).slice(0, 10)}`, env.context.binding.datasetId);
    }
    const result = read(env, (database) => listMemberCommunicationJobs(database, env.context, memberId));
    if (isRejected(result)) return result;
        return result.value.map((item) => ({ value: item.id, label: `${item.purpose} · ${item.channel} · ${item.state}` }));
  },
  annotations(env: Env, documentVersionId: string): Option[] | Rejection {
    const result = read(env, (database) => listDocumentAnnotations(database, env.context, documentVersionId));
    if (isRejected(result)) return result;
        return result.value.filter((item) => item.status !== 'removed').map((item) => ({ value: `${item.id}|${item.fingerprint}`, label: `p${item.pageNumber} · ${item.text.slice(0, 40)} · ${item.status}` }));
  },
  mergePlans(env: Env): Option[] | Rejection {
    return sqlOptions(env,
      `SELECT p.id,p.state,s.member_number AS source_number,t.member_number AS target_number FROM member_merge_plans p
       JOIN members s ON s.dataset_id=p.dataset_id AND s.id=p.source_member_id
       JOIN members t ON t.dataset_id=p.dataset_id AND t.id=p.target_member_id
       WHERE p.dataset_id=? AND p.state IN ('reviewed','approved') ORDER BY p.created_at`,
      (item) => `${text(item.id)} · ${text(item.source_number)} → ${text(item.target_number)} · ${text(item.state)}`, env.context.binding.datasetId);
  },
  exportDestinations(env: Env): Option[] {
    return env.exportDestinations.map((destination) => ({ value: destination, label: destination }));
  },
};

interface SubjectResolver {
  list(env: Env, resolved: Resolved): Option[] | Rejection | null;
  resolve(env: Env, resolved: Resolved, value: string): ResolvedSubject | Rejection;
}

/** A governed finance record resolves through the scoped reader for its exact fingerprint. */
function financeSubject(
  kind: FinanceRecordKind,
  label: (row: Row) => string,
  sql: (env: Env, resolved: Resolved) => { text: string; parameters: (string | number | null)[] },
): SubjectResolver {
  return {
    list: (env, resolved) => {
      const query = sql(env, resolved);
      const result = allRows(env, query.text, ...query.parameters);
      if (isRejected(result)) return result;
      return result.map((item) => ({ value: text(item.id), label: label(item) }));
    },
    resolve: (env, _resolved, value) => {
      const record = queryFinance(env.store, env.context, { kind: 'finance.record', resource: kind, id: value });
      if (record.kind === 'rejected') return record;
      if (record.kind !== 'found') return notFound('record');
      const fields = record.snapshot.record;
      const accountId = typeof fields.accountId === 'string' ? fields.accountId : typeof fields.account_id === 'string' ? fields.account_id : undefined;
      const memberId = typeof fields.memberId === 'string' ? fields.memberId : typeof fields.member_id === 'string' ? fields.member_id : undefined;
      const currency = typeof fields.currency === 'string' ? fields.currency : undefined;
      const state = typeof fields.state === 'string' ? fields.state : typeof fields.status === 'string' ? fields.status : undefined;
      const version = typeof fields.version === 'number' ? fields.version : undefined;
      return {
        id: value,
        label: `${kind} ${value}`,
        fingerprint: record.snapshot.fingerprint,
        ...(version === undefined ? {} : { version }),
        ...(accountId === undefined ? {} : { accountId }),
        ...(memberId === undefined ? {} : { memberId }),
        ...(currency === undefined ? {} : { currency }),
        ...(state === undefined ? {} : { state }),
        data: fields,
      };
    },
  };
}

export const SUBJECT_RESOLVERS: Record<string, SubjectResolver> = {
  member: {
    list: (env) => pickers.members(env),
    resolve: (env, _resolved, value) => {
      const detail = read(env, (database) => {
        const listed = searchMembers(database, env.context.binding.datasetId, { ids: [value], limit: 1, offset: 0 }).items[0]
          ?? searchMembers(database, env.context.binding.datasetId, { query: value, field: 'memberNumber', match: 'exact', limit: 1, offset: 0 }).items[0];
        return listed === undefined ? undefined : memberDetail(database, env.context.binding.datasetId, listed.id);
      });
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('member');
      return {
        id: detail.member.id, label: `${detail.member.memberNumber} · ${detail.member.displayName}`, version: detail.member.version,
        memberId: detail.member.id, memberNumber: detail.member.memberNumber, partyId: detail.member.partyId, state: detail.member.status,
        data: { kind: detail.member.kind, displayName: detail.member.displayName, email: detail.email?.value ?? null, phone: detail.phone?.value ?? null },
      };
    },
  },
  organization: {
    list: (env) => pickers.organizationMembers(env),
    resolve: (env, resolved, value) => {
      const subject = SUBJECT_RESOLVERS['member']?.resolve(env, resolved, value) ?? notFound('member');
      if (isRejected(subject)) return subject;
      if (subject.data.kind !== 'organization') return rejected('ineligible', 'The selected member is not an organization.');
      return subject;
    },
  },
  account: {
    list: (env, resolved) => pickers.accounts(env, resolved.member?.id),
    resolve: (env, _resolved, value) => {
      const detail = read(env, (database) => {
        const listed = searchAccounts(database, env.context.binding.datasetId, { ids: [value], limit: 1, offset: 0 }).items[0]
          ?? searchAccounts(database, env.context.binding.datasetId, { query: value, limit: 10, offset: 0 }).items.find((item) => item.accountNumber.toUpperCase() === value.toUpperCase());
        return listed === undefined ? undefined : accountDetail(database, env.context.binding.datasetId, listed.id);
      });
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('account');
      return {
        id: detail.account.id, label: `${detail.account.accountNumber} · ${detail.account.productName} · ${detail.account.status}`, version: detail.account.version,
        accountId: detail.account.id, accountNumber: detail.account.accountNumber, memberId: detail.account.memberId, memberNumber: detail.account.memberNumber,
        state: detail.account.status, currency: detail.account.currency,
        data: {
          productId: detail.account.productId, currency: detail.account.currency, memberId: detail.account.memberId,
          postedMinorUnits: detail.account.postedMinorUnits, availableMinorUnits: detail.account.availableMinorUnits,
          nickname: detail.account.nickname, statementDelivery: detail.account.statementDelivery,
        },
      };
    },
  },
  case: {
    list: (env, resolved) => pickers.cases(env, resolved.member?.id),
    resolve: (env, _resolved, value) => {
      const detail = read(env, (database) => {
        const listed = searchCases(database, env.context.binding.datasetId, { ids: [value], limit: 1, offset: 0 }).items[0]
          ?? searchCases(database, env.context.binding.datasetId, { query: value, limit: 10, offset: 0 }).items.find((item) => item.caseNumber.toUpperCase() === value.toUpperCase());
        return listed === undefined ? undefined : caseDetail(database, env.context.binding.datasetId, listed.id);
      });
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('case');
      return {
        id: detail.case.id, label: `${detail.case.caseNumber} · ${detail.case.state}`, version: detail.case.version,
        caseId: detail.case.id, memberId: detail.case.memberId, memberNumber: detail.case.memberNumber,
        ...(detail.case.accountId === null ? {} : { accountId: detail.case.accountId }), state: detail.case.state,
        data: { queueId: detail.case.queueId, assignedActorId: detail.case.assignedActorId, allowedTransitions: detail.allowedTransitions },
      };
    },
  },
  document: {
    list: (env, resolved) => pickers.documents(env, resolved.member?.id),
    resolve: (env, _resolved, value) => {
      const detail = read(env, (database) =>
        searchDocuments(database, env.context.binding.datasetId, { limit: 200, offset: 0 }).items.find((item) => item.documentId === value));
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('document');
      const retention = oneRow(env, 'SELECT retention_class AS retentionClass FROM documents WHERE dataset_id=? AND id=?', env.context.binding.datasetId, value);
      if (isRejected(retention)) return retention;
      return {
        id: detail.documentId, label: `${detail.displayName} · ${detail.documentType}`, documentId: detail.documentId,
        memberId: detail.memberId, memberNumber: detail.memberNumber, partyId: detail.ownerPartyId,
        ...(detail.accountId === null ? {} : { accountId: detail.accountId }), state: detail.status,
        data: { documentType: detail.documentType, displayName: detail.displayName, retentionClass: retention?.retentionClass ?? '', versionId: detail.versionId, ownerPartyId: detail.ownerPartyId, accountId: detail.accountId },
      };
    },
  },
  'document-version': {
    list: (env, resolved) => pickers.documentVersions(env, resolved.member?.id),
    resolve: (env, _resolved, value) => {
      const detail = read(env, (database) =>
        searchDocuments(database, env.context.binding.datasetId, { limit: 200, offset: 0 }).items.find((item) => item.versionId === value));
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('document version');
      const retention = oneRow(env, 'SELECT retention_class AS retentionClass FROM documents WHERE dataset_id=? AND id=?', env.context.binding.datasetId, detail.documentId);
      if (isRejected(retention)) return retention;
      return {
        id: detail.versionId, label: `${detail.displayName} v${detail.version} · ${detail.status}`, version: detail.version,
        documentId: detail.documentId, memberId: detail.memberId, memberNumber: detail.memberNumber, partyId: detail.ownerPartyId,
        ...(detail.accountId === null ? {} : { accountId: detail.accountId }), state: detail.status,
        data: { digest: detail.digest, documentType: detail.documentType, displayName: detail.displayName, mediaType: detail.mediaType, retentionClass: retention?.retentionClass ?? '', ownerPartyId: detail.ownerPartyId, accountId: detail.accountId },
      };
    },
  },
  consent: {
    list: (env, resolved) => (resolved.member === undefined ? null : pickers.consents(env, resolved.member.id)),
    resolve: (env, resolved, value) => {
      const detail = oneRow(env, 'SELECT * FROM consents WHERE dataset_id=? AND id=?', env.context.binding.datasetId, value);
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('consent');
      return {
        id: value, label: `${text(detail.purpose)} · ${text(detail.channel)} · ${text(detail.state)}`,
        state: text(detail.state), partyId: text(detail.party_id),
        ...(detail.account_id === null ? {} : { accountId: text(detail.account_id) }),
        ...(resolved.member === undefined ? {} : { memberId: resolved.member.id }), data: detail,
      };
    },
  },
  evidence: {
    list: (env, resolved) => (resolved.member === undefined ? null : pickers.evidence(env, resolved.member.id)),
    resolve: (env, _resolved, value) => {
      const detail = oneRow(env, 'SELECT * FROM identity_evidence WHERE dataset_id=? AND id=?', env.context.binding.datasetId, value);
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('identity evidence');
      return { id: value, label: `${text(detail.kind)} · ${text(detail.reference)} · ${text(detail.status)}`, state: text(detail.status), partyId: text(detail.party_id), data: detail };
    },
  },
  'maintenance-request': {
    list: (env, resolved) => pickers.maintenanceRequests(env, resolved.member?.id),
    resolve: (env, _resolved, value) => {
      const detail = oneRow(env, 'SELECT * FROM maintenance_requests WHERE dataset_id=? AND id=?', env.context.binding.datasetId, value);
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('maintenance request');
      return {
        id: value, label: `${text(detail.request_number)} · ${text(detail.state)}`, updatedAt: text(detail.updated_at),
        state: text(detail.state), memberId: text(detail.member_id), ...(detail.account_id === null ? {} : { accountId: text(detail.account_id) }), data: detail,
      };
    },
  },
  approval: {
    list: (env) => pickers.approvals(env),
    resolve: (env, _resolved, value) => {
      const result = listApprovals(env.store, env.context, 200);
      if (result.kind !== 'found') return result;
      const approval = result.approvals.find((item) => item.id === value);
      if (approval === undefined) return notFound('approval');
      return {
        id: approval.id, label: `${approval.status} · ${targetKindLabel(approval.target)}`, fingerprint: approval.fingerprint,
        state: approval.status, data: { target: approval.target, expiresAt: approval.expiresAt, amountLimit: approval.amountLimit },
      };
    },
  },
  'saved-search': {
    list: (env) => pickers.savedSearches(env),
    resolve: (env, _resolved, value) => {
      const [id] = value.split('|');
      if (id === undefined) return notFound('saved search');
      const result = read(env, (database) => listSavedSearches(database, env.context.binding.datasetId, env.context.actorId).find((item) => item.id === id));
      if (isRejected(result)) return result;
      if (result === undefined) return notFound('saved search');
      return { id: result.id, label: result.name, fingerprint: result.revision, state: result.visibility, data: { definition: result.definition, owner: result.owner } };
    },
  },
  'communication-job': {
    list: (env, resolved) => pickers.communicationJobs(env, resolved.member?.id),
    resolve: (env, _resolved, value) => {
      const detail = oneRow(env, 'SELECT * FROM communication_jobs WHERE dataset_id=? AND id=?', env.context.binding.datasetId, value);
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('communication job');
      return { id: value, label: `${text(detail.purpose)} · ${text(detail.channel)} · ${text(detail.state)}`, state: text(detail.state), partyId: text(detail.party_id), data: detail };
    },
  },
  'merge-plan': {
    list: (env) => pickers.mergePlans(env),
    resolve: (env, _resolved, value) => {
      const inventory = queryMemberMergePlan(env.store, env.context, value);
      if (inventory.kind !== 'found') return inventory;
      return {
        id: value, label: `${value} · ${inventory.planState}`, fingerprint: inventory.fingerprint, state: inventory.planState,
        memberId: inventory.sourceMemberId,
        data: { sourceMemberId: inventory.sourceMemberId, targetMemberId: inventory.targetMemberId, decisions: inventory.decisions, tables: inventory.tables.map((table) => ({ table: table.table, count: table.count })) },
      };
    },
  },
  annotation: {
    list: (env, resolved) => (resolved['document-version'] === undefined ? null : pickers.annotations(env, resolved['document-version'].id)),
    resolve: (env, _resolved, value) => {
      const [id, fingerprint] = value.split('|');
      if (id === undefined) return notFound('annotation');
      const detail = oneRow(env, 'SELECT * FROM document_annotations WHERE dataset_id=? AND id=?', env.context.binding.datasetId, id);
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('annotation');
      return { id, label: `Annotation p${text(detail.page_number)} · ${text(detail.status)}`, ...(fingerprint === undefined ? {} : { fingerprint }), state: text(detail.status), data: detail };
    },
  },
  hold: financeSubject('hold', (item) => `${text(item.reason).slice(0, 40)} · ${text(item.status)}`,
    (env, resolved) => ({ text: `SELECT id,reason,status FROM holds WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY placed_at DESC LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  restriction: financeSubject('restriction', (item) => `${text(item.kind)} · ${text(item.status)}`,
    (env, resolved) => ({ text: `SELECT id,kind,status FROM restrictions WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY placed_at DESC LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  facility: financeSubject('facility', (item) => `${text(item.kind)} · limit ${text(item.limit_minor_units)} · ${text(item.status)}`,
    (env, resolved) => ({ text: `SELECT id,kind,limit_minor_units,status FROM facilities WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY id LIMIT 100`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  fee: financeSubject('fee', (item) => `${text(item.id)} · ${text(item.status)}`,
    (env, resolved) => ({ text: `SELECT id,status FROM fees WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY id LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  journal: financeSubject('journal', (item) => `${text(item.reference)} · ${text(item.description).slice(0, 48)} · ${text(item.status)}`,
    (env, resolved) => ({
      text: `SELECT j.id,j.reference,j.description,j.status FROM journals j WHERE j.dataset_id=?${resolved.account === undefined ? '' : ' AND j.id IN (SELECT jl.journal_id FROM journal_lines jl JOIN ledger_accounts la ON la.dataset_id=jl.dataset_id AND la.id=jl.ledger_account_id WHERE jl.dataset_id=? AND la.customer_account_id=?)'} ORDER BY j.posted_at DESC LIMIT 300`,
      parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [env.context.binding.datasetId, resolved.account.id])],
    })),
  transfer: financeSubject('transfer', (item) => `${text(item.reference)} · ${text(item.description).slice(0, 48)}`,
    (env) => ({ text: `SELECT j.id,j.reference,j.description FROM journals j JOIN operations o ON o.dataset_id=j.dataset_id AND o.id=j.operation_id WHERE j.dataset_id=? AND o.operation_kind='transfer.internal' ORDER BY j.posted_at DESC LIMIT 200`, parameters: [env.context.binding.datasetId] })),
  payment: financeSubject('payment', (item) => `${text(item.reference)} · ${text(item.state)} · ${text(item.amount_minor_units)} ${text(item.currency)}`,
    (env, resolved) => ({ text: `SELECT id,reference,state,amount_minor_units,currency FROM payments WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND source_account_id=?'} ORDER BY requested_date DESC LIMIT 300`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  schedule: financeSubject('payment-schedule', (item) => `${text(item.id)} · ${text(item.state)}`,
    (env, resolved) => ({ text: `SELECT id,state FROM payment_schedules WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND source_account_id=?'} ORDER BY id LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  occurrence: financeSubject('schedule-occurrence', (item) => `${text(item.local_date)} · ${text(item.state)}`,
    (env, resolved) => ({ text: `SELECT id,local_date,state FROM schedule_occurrences WHERE dataset_id=?${resolved.schedule === undefined ? '' : ' AND schedule_id=?'} ORDER BY local_date LIMIT 300`, parameters: [env.context.binding.datasetId, ...(resolved.schedule === undefined ? [] : [resolved.schedule.id])] })),
  'payment-return': financeSubject('payment-return', (item) => `${text(item.reference)} · ${text(item.return_code)} · payment ${text(item.state)}`,
    (env) => ({ text: `SELECT r.id,r.return_code,p.reference,p.state FROM payment_returns r JOIN payments p ON p.dataset_id=r.dataset_id AND p.id=r.payment_id WHERE r.dataset_id=? ORDER BY r.occurred_at DESC LIMIT 200`, parameters: [env.context.binding.datasetId] })),
  beneficiary: financeSubject('beneficiary', (item) => `${text(item.display_name)} · ${text(item.status)}`,
    (env, resolved) => ({
      text: `SELECT b.id,b.display_name,b.status FROM beneficiaries b${resolved.member === undefined ? '' : ' JOIN parties p ON p.dataset_id=b.dataset_id AND p.id=b.owner_party_id JOIN members m ON m.dataset_id=p.dataset_id AND m.party_id=p.id AND m.id=?'} WHERE b.dataset_id=? ORDER BY b.display_name LIMIT 300`,
      parameters: [...(resolved.member === undefined ? [] : [resolved.member.id]), env.context.binding.datasetId],
    })),
  'beneficiary-route': financeSubject('beneficiary-route', (item) => `${text(item.routing_kind)} · ${text(item.masked_destination)} · ${text(item.status)}`,
    (env, resolved) => ({
      text: `SELECT r.id,r.routing_kind,r.masked_destination,r.status FROM beneficiary_routes r WHERE r.dataset_id=?${resolved.beneficiary === undefined ? '' : ' AND r.beneficiary_id=?'} ORDER BY r.version DESC LIMIT 300`,
      parameters: [env.context.binding.datasetId, ...(resolved.beneficiary === undefined ? [] : [resolved.beneficiary.id])],
    })),
  card: financeSubject('card', (item) => `····${text(item.last_four)} · ${text(item.status)}`,
    (env, resolved) => ({ text: `SELECT id,last_four,status FROM cards WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY id LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  'card-transaction': financeSubject('card-transaction', (item) => `${text(item.merchant)} · ${text(item.amount_minor_units)} ${text(item.currency)}`,
    (env, resolved) => ({ text: `SELECT id,merchant,amount_minor_units,currency FROM card_transactions WHERE dataset_id=?${resolved.card === undefined ? '' : ' AND card_id=?'} ORDER BY occurred_at DESC LIMIT 300`, parameters: [env.context.binding.datasetId, ...(resolved.card === undefined ? [] : [resolved.card.id])] })),
  dispute: financeSubject('dispute', (item) => `${text(item.case_number)} · ${text(item.state)}`,
    (env, resolved) => ({ text: `SELECT id,case_number,state FROM disputes WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY id LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  loan: financeSubject('loan', (item) => `${text(item.id)} · ${text(item.state)} · ${text(item.principal_minor_units)}`,
    (env, resolved) => ({ text: `SELECT id,state,principal_minor_units FROM loans WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY id LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  'loan-application': {
    list: (env, resolved) => sqlOptions(env,
      `SELECT id,state,requested_amount_minor_units AS amount,currency FROM loan_applications WHERE dataset_id=?${resolved.member === undefined ? '' : ' AND member_id=?'} ORDER BY id LIMIT 200`,
      (item) => `${text(item.id)} · ${text(item.state)} · ${text(item.amount)} ${text(item.currency)}`,
      env.context.binding.datasetId, ...(resolved.member === undefined ? [] : [resolved.member.id])),
    resolve: (env, _resolved, value) => {
      const detail = oneRow(env, 'SELECT * FROM loan_applications WHERE dataset_id=? AND id=?', env.context.binding.datasetId, value);
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('loan application');
      return { id: value, label: `${text(detail.id)} · ${text(detail.state)}`, state: text(detail.state), memberId: text(detail.member_id), data: detail };
    },
  },
  'interest-calculation': financeSubject('interest-calculation', (item) => `${text(item.id)} · ${text(item.state)}`,
    (env, resolved) => ({ text: `SELECT id,state FROM interest_calculations WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY id LIMIT 200`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  'suspense-item': financeSubject('suspense-item', (item) => `${text(item.id)} · ${text(item.state)} · ${text(item.remaining_amount_minor_units)}`,
    (env) => ({ text: `SELECT id,state,remaining_amount_minor_units FROM suspense_items WHERE dataset_id=? ORDER BY id LIMIT 200`, parameters: [env.context.binding.datasetId] })),
  batch: financeSubject('batch', (item) => `${text(item.batch_number)} · ${text(item.kind)} · ${text(item.state)}`,
    (env) => ({ text: `SELECT id,batch_number,kind,state FROM batches WHERE dataset_id=? ORDER BY created_at DESC LIMIT 200`, parameters: [env.context.binding.datasetId] })),
  'batch-item': {
    list: (env, resolved) => {
      if (resolved.batch === undefined) return null;
      const result = allRows(env, 'SELECT id,ordinal,state FROM batch_items WHERE dataset_id=? AND batch_id=? ORDER BY ordinal LIMIT 500', env.context.binding.datasetId, resolved.batch.id);
      if (isRejected(result)) return result;
      return result.map((item) => ({ value: text(item.id), label: `#${text(item.ordinal)} · ${text(item.state)}` }));
    },
    resolve: (env, _resolved, value) => {
      const detail = oneRow(env, 'SELECT * FROM batch_items WHERE dataset_id=? AND id=?', env.context.binding.datasetId, value);
      if (isRejected(detail)) return detail;
      if (detail === undefined) return notFound('batch item');
      return { id: value, label: `Item ${text(detail.ordinal)} · ${text(detail.state)}`, state: text(detail.state), data: detail };
    },
  },
  'settlement-batch': financeSubject('settlement-batch', (item) => `${text(item.reference)} · ${text(item.state)}`,
    (env) => ({ text: `SELECT id,reference,state FROM settlement_batches WHERE dataset_id=? ORDER BY cutoff_at DESC LIMIT 200`, parameters: [env.context.binding.datasetId] })),
  'maturity-instruction': financeSubject('maturity-instruction', (item) => `${text(item.disposition)} · ${text(item.state)} · cutoff ${text(item.cutoff_at).slice(0, 10)}`,
    (env, resolved) => ({ text: `SELECT id,disposition,state,cutoff_at FROM maturity_instructions WHERE dataset_id=?${resolved.account === undefined ? '' : ' AND account_id=?'} ORDER BY cutoff_at DESC LIMIT 100`, parameters: [env.context.binding.datasetId, ...(resolved.account === undefined ? [] : [resolved.account.id])] })),
  'received-funds': financeSubject('received-funds', (item) => `${text(item.reference)} · ${text(item.state)}`,
    (env) => ({ text: `SELECT id,reference,state FROM received_funds WHERE dataset_id=? ORDER BY received_at DESC LIMIT 200`, parameters: [env.context.binding.datasetId] })),
  'loan-closure': financeSubject('loan-closure', (item) => `${text(item.id)} · closed ${text(item.closed_at)}`,
    (env, resolved) => ({ text: `SELECT id,closed_at FROM loan_closures WHERE dataset_id=?${resolved.loan === undefined ? '' : ' AND loan_id=?'} ORDER BY id LIMIT 100`, parameters: [env.context.binding.datasetId, ...(resolved.loan === undefined ? [] : [resolved.loan.id])] })),
};
