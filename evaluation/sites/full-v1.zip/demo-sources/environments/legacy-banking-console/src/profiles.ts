import type { ProfileId } from './contracts.js';

export type { ProfileId } from './contracts.js';

export interface StructuralFeatures {
  deepFrames: boolean;
  crossOrigin: boolean;
  repeatedControls: boolean;
  hiddenDuplicates: boolean;
  nestedScroll: boolean;
  stickyClipping: boolean;
  scaledGeometry: boolean;
  generatedIds: boolean;
  weakSemantics: boolean;
  keyboardFocus: boolean;
  frameReplacement: boolean;
  separateInquiryWindow: boolean;
}

export interface StructuralProfile {
  id: ProfileId;
  label: string;
  features: Readonly<StructuralFeatures>;
}

const none: StructuralFeatures = {
  deepFrames: false,
  crossOrigin: false,
  repeatedControls: false,
  hiddenDuplicates: false,
  nestedScroll: false,
  stickyClipping: false,
  scaledGeometry: false,
  generatedIds: false,
  weakSemantics: false,
  keyboardFocus: false,
  frameReplacement: false,
  separateInquiryWindow: false,
};

function features(...enabled: readonly (keyof StructuralFeatures)[]): StructuralFeatures {
  const value = { ...none };
  for (const key of enabled) value[key] = true;
  return value;
}

const profiles: Record<ProfileId, StructuralProfile> = {
  baseline: { id: 'baseline', label: 'Baseline', features: features() },
  'deep-frames': { id: 'deep-frames', label: 'Deep frames', features: features('deepFrames') },
  'cross-origin': {
    id: 'cross-origin',
    label: 'Cross-origin workspace',
    features: features('crossOrigin'),
  },
  'repeated-controls': {
    id: 'repeated-controls',
    label: 'Repeated controls',
    features: features('repeatedControls'),
  },
  'hidden-duplicates': {
    id: 'hidden-duplicates',
    label: 'Hidden duplicate controls',
    features: features('hiddenDuplicates'),
  },
  'nested-scroll': {
    id: 'nested-scroll',
    label: 'Nested scrolling',
    features: features('nestedScroll'),
  },
  'sticky-clipping': {
    id: 'sticky-clipping',
    label: 'Sticky headers and clipping',
    features: features('stickyClipping'),
  },
  'scaled-geometry': {
    id: 'scaled-geometry',
    label: 'Scaled frame geometry',
    features: features('scaledGeometry'),
  },
  'generated-ids': {
    id: 'generated-ids',
    label: 'Generated identifiers',
    features: features('generatedIds'),
  },
  'weak-semantics': {
    id: 'weak-semantics',
    label: 'Weak semantics',
    features: features('weakSemantics'),
  },
  'focus-replacement': {
    id: 'focus-replacement',
    label: 'Focus and frame replacement',
    features: features('keyboardFocus', 'frameReplacement'),
  },
  'separate-inquiry-window': {
    id: 'separate-inquiry-window',
    label: 'Separate inquiry window',
    features: features('separateInquiryWindow'),
  },
  'navigation-hard': {
    id: 'navigation-hard',
    label: 'Navigation hard',
    features: features(
      'deepFrames',
      'crossOrigin',
      'generatedIds',
      'keyboardFocus',
      'frameReplacement',
      'separateInquiryWindow',
    ),
  },
  'targeting-hard': {
    id: 'targeting-hard',
    label: 'Targeting hard',
    features: features('repeatedControls', 'hiddenDuplicates', 'generatedIds', 'weakSemantics'),
  },
  'geometry-hard': {
    id: 'geometry-hard',
    label: 'Geometry hard',
    features: features('nestedScroll', 'stickyClipping', 'scaledGeometry'),
  },
  'combined-hard': {
    id: 'combined-hard',
    label: 'Combined hard',
    features: features(...(Object.keys(none) as (keyof StructuralFeatures)[])),
  },
};

export const PROFILE_IDS = Object.freeze(Object.keys(profiles) as ProfileId[]);
export const DEFAULT_PROFILE_ID: ProfileId = 'combined-hard';

export function getProfile(id: ProfileId): StructuralProfile {
  return structuredClone(profiles[id]);
}

export function isProfileId(value: string): value is ProfileId {
  return Object.hasOwn(profiles, value);
}
