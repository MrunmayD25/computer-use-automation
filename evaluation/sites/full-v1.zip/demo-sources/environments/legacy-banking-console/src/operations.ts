import { createHash, randomBytes } from 'node:crypto';

import type { AddressInput, CommandKind, Money, ServiceCommand } from '@computer-use/financial-database/services';

import {
  pickers,
  read,
  isRejected,
  SUBJECT_RESOLVERS,
  type Env,
  type Option,
  type Rejection,
  type Resolved,
  type ResolvedSubject,
} from './prerequisites.js';

export type { Env, Option, Resolved, ResolvedSubject };

export class FormError extends Error {
  constructor(
    message: string,
    readonly field: string,
  ) {
    super(message);
  }
}

const str = (value: unknown): string => (typeof value === 'string' ? value : '');

function fail(field: string, message: string): never {
  throw new FormError(message, field);
}

/** Raw submitted form values; every getter is a boundary parse with an explicit failure. */
export class Form {
  constructor(private readonly values: Record<string, unknown>) {}

  get(name: string): string {
    const value = this.values[name];
    if (Array.isArray(value)) return str(value[0] ?? '').trim();
    return typeof value === 'string' ? value.trim() : '';
  }

  list(name: string): string[] {
    const value = this.values[name];
    if (Array.isArray(value)) return value.map((item) => str(item).trim()).filter((item) => item !== '');
    const single = this.get(name);
    return single === '' ? [] : [single];
  }

  text(name: string, label: string): string {
    const value = this.get(name);
    if (value === '') fail(name, `${label} is required.`);
    return value;
  }

  optional(name: string): string | null {
    const value = this.get(name);
    return value === '' ? null : value;
  }

  int(name: string, label: string, required = true): number | undefined {
    const value = this.get(name);
    if (value === '') {
      if (required) fail(name, `${label} is required.`);
      return undefined;
    }
    const parsed = Number(value);
    if (!Number.isSafeInteger(parsed)) fail(name, `${label} must be a whole number.`);
    return parsed;
  }

  decimal(name: string, label: string): number {
    const value = this.get(name);
    const match = /^(\d{1,12})(?:\.(\d{1,2}))?$/.exec(value);
    if (match === null || match[1] === undefined) fail(name, `${label} must be a decimal amount, for example 125.50.`);
    const minor = Number(match[1]) * 100 + Number((match[2] ?? '').padEnd(2, '0') || '0');
    if (!Number.isSafeInteger(minor)) fail(name, `${label} is out of range.`);
    return minor;
  }

  money(name: string, label: string, required = true): Money | undefined {
    const value = this.get(name);
    if (value === '') {
      if (required) fail(name, `${label} is required.`);
      return undefined;
    }
    const currency = this.get(`${name}__ccy`);
    if (currency === '') fail(name, `${label} currency is required.`);
    return { minorUnits: this.decimal(name, label), currency };
  }

  date(name: string, label: string, required = true): string | undefined {
    const value = this.get(name);
    if (value === '') {
      if (required) fail(name, `${label} is required.`);
      return undefined;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) fail(name, `${label} must be a calendar date (YYYY-MM-DD).`);
    return value;
  }

  instant(name: string, label: string, required = true): string | undefined {
    const value = this.get(name);
    if (value === '') {
      if (required) fail(name, `${label} is required.`);
      return undefined;
    }
    const iso = value.length === 16 ? `${value}:00Z` : value;
    if (Number.isNaN(Date.parse(iso))) fail(name, `${label} must be a date and time (UTC).`);
    return new Date(Date.parse(iso)).toISOString();
  }

  strings(name: string): string[] {
    return this.get(name)
      .split(',')
      .map((item) => item.trim())
      .filter((item) => item !== '');
  }

  bool(name: string): boolean {
    const value = this.get(name);
    return value === 'yes' || value === 'on' || value === 'true';
  }

  bytes(name: string, label: string): Uint8Array {
    const value = this.get(name);
    if (value === '') fail(name, `${label} is required.`);
    return new TextEncoder().encode(value);
  }

  json(name: string, label: string): unknown {
    const value = this.get(name);
    if (value === '') return undefined;
    try {
      return JSON.parse(value) as unknown;
    } catch {
      return fail(name, `${label} must be valid JSON.`);
    }
  }

  address(prefix: string): AddressInput | null {
    const line1 = this.get(`${prefix}__line1`);
    if (line1 === '') return null;
    return {
      line1,
      line2: this.get(`${prefix}__line2`) || null,
      city: this.get(`${prefix}__city`),
      region: this.get(`${prefix}__region`),
      postalCode: this.get(`${prefix}__postal`),
      country: this.get(`${prefix}__country`) || 'US',
    };
  }
}

export type InputKind =
  | 'text'
  | 'textarea'
  | 'date'
  | 'instant'
  | 'integer'
  | 'decimal'
  | 'strings'
  | 'bytes'
  | 'checkbox'
  | 'money'
  | 'select'
  | 'multiselect'
  | 'address';

export interface FieldSpec {
  name: string;
  label: string;
  input: InputKind;
  required?: boolean;
  /** Rendered on the subject-selection step; values carry forward to the parameter step. */
  step1?: boolean;
  options?: (env: Env, resolved: Resolved, step: Record<string, string>) => Option[] | Rejection;
  default?: (env: Env, resolved: Resolved) => string;
  help?: string;
  /** Renders the field only when this predicate on carried step-1 values holds. */
  when?: (step: Record<string, string>, resolved: Resolved) => boolean;
}

export interface SubjectSpec {
  key: string;
  kind: keyof typeof SUBJECT_RESOLVERS;
  label: string;
}

export interface OperationSpec {
  kind: CommandKind;
  title: string;
  group: string;
  /** The command carries an approvalId; the review step can raise an approval request instead. */
  approval?: boolean;
  subjects: readonly SubjectSpec[];
  fields: readonly FieldSpec[];
  /** Extra values captured when the parameter form is rendered and bound as hidden inputs. */
  extraHidden?: (env: Env, resolved: Resolved, step?: Record<string, string>) => Record<string, string>;
  build(form: Form, subjects: Resolved, env: Env): ServiceCommand;
}

// ---------- field factories ----------

const text = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'text', ...extra });
const area = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'textarea', ...extra });
const date = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'date', ...extra });
const instant = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'instant', ...extra });
const integer = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'integer', ...extra });
const decimal = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'decimal', ...extra });
const money = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'money', ...extra });
const flag = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'checkbox', ...extra });
const strings = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'strings', ...extra });
const address = (name: string, label: string, extra?: Partial<FieldSpec>): FieldSpec => ({ name, label, input: 'address', ...extra });
const sel = (
  name: string,
  label: string,
  options: Option[] | ((env: Env, resolved: Resolved, step: Record<string, string>) => Option[] | Rejection),
  extra?: Partial<FieldSpec>,
): FieldSpec => ({
  name,
  label,
  input: 'select',
  options: typeof options === 'function' ? options : () => options,
  ...extra,
});
const multi = (
  name: string,
  label: string,
  options: (env: Env, resolved: Resolved, step: Record<string, string>) => Option[] | Rejection,
  extra?: Partial<FieldSpec>,
): FieldSpec => ({ name, label, input: 'multiselect', options, ...extra });

const fixed = (pairs: readonly (readonly [string, string])[]): Option[] => pairs.map(([value, label]) => ({ value, label }));

const memberSubject: SubjectSpec = { key: 'member', kind: 'member', label: 'Member' };
const orgSubject: SubjectSpec = { key: 'member', kind: 'organization', label: 'Organization member' };
const accountSubject: SubjectSpec = { key: 'account', kind: 'account', label: 'Account' };
const caseSubject: SubjectSpec = { key: 'case', kind: 'case', label: 'Case' };
const approvalField = sel('approvalId', 'Approval', (env) => pickers.approvals(env, 'approved'), { required: false, help: 'Required when this operation needs independent approval.' });

const need = <T>(value: T | undefined | null, field: string, label: string): T => {
  if (value === undefined || value === null) fail(field, `${label} is required.`);
  return value;
};

const needSubject = (subjects: Resolved, key: string): ResolvedSubject =>
  subjects[key] ?? fail(`s_${key}`, 'The governing record must be selected.');

/** Optional subject: returns undefined rather than failing when the record was not selected. */
const subj = (subjects: Resolved, key: string): ResolvedSubject | undefined => subjects[key];

/** Member accounts the picker belongs to, resolved from any member-scoped context. */
const memberFrom = (subjects: Resolved): ResolvedSubject | undefined =>
  subjects.member ?? Object.values(subjects).find((subject) => subject.memberId !== undefined);

const memberDocuments = (env: Env, subjects: Resolved): Option[] | Rejection => {
  const member = memberFrom(subjects);
  if (member?.memberId === undefined) return [];
  return pickers.documentVersions(env, member.memberId);
};

const memberEvidence = (env: Env, subjects: Resolved): Option[] | Rejection => {
  const member = memberFrom(subjects);
  if (member?.memberId === undefined) return [];
  return pickers.evidence(env, member.memberId);
};

const currencies = (env: Env): Option[] | Rejection => {
  const result = read(env, (database) =>
    database.prepare('SELECT code,name FROM currencies ORDER BY code').all() as { code: string; name: string }[]);
  if (isRejected(result)) return result;
  return result.map((item) => ({ value: item.code, label: `${item.code} · ${item.name}` }));
};

const memberParties = (env: Env, subjects: Resolved): Option[] | Rejection => {
  const memberId = memberFrom(subjects)?.memberId;
  if (memberId === undefined) return [];
  const result = read(env, (database) =>
    database.prepare(`SELECT p.id,p.display_name FROM parties p WHERE p.dataset_id=? AND p.id IN (
      SELECT party_id FROM parties WHERE dataset_id=? AND id=(SELECT party_id FROM members WHERE dataset_id=? AND id=?)
      UNION SELECT party_id FROM account_parties WHERE dataset_id=? AND account_id IN (SELECT id FROM accounts WHERE dataset_id=? AND member_id=?))
      ORDER BY display_name`,
    ).all(env.context.binding.datasetId, env.context.binding.datasetId, env.context.binding.datasetId, memberId, env.context.binding.datasetId, env.context.binding.datasetId, memberId) as { id: string; display_name: string }[]);
  if (isRejected(result)) return result;
  return result.map((item) => ({ value: item.id, label: item.display_name }));
};

// ---------- specifications ----------

export const OPERATIONS: readonly OperationSpec[] = [
  // ── Members and accounts ────────────────────────────────────────────────
  {
    kind: 'member.create', title: 'Register person member', group: 'Membership',
    subjects: [],
    fields: [
      text('legalGiven', 'Legal given name', { required: true }),
      text('legalFamily', 'Legal family name', { required: true }),
      text('preferredName', 'Preferred name', { required: false }),
      date('birthDate', 'Birth date', { required: true }),
      text('email', 'Email', { required: false }),
      text('phone', 'Phone', { required: false }),
      address('address', 'Mailing address', { required: false }),
    ],
    build: (f) => ({
      kind: 'member.create',
      legalGiven: f.text('legalGiven', 'Legal given name'),
      legalFamily: f.text('legalFamily', 'Legal family name'),
      preferredName: f.optional('preferredName'),
      birthDate: need(f.date('birthDate', 'Birth date'), 'birthDate', 'Birth date'),
      email: f.optional('email'),
      phone: f.optional('phone'),
      address: f.address('address'),
    }),
  },
  {
    kind: 'member.organization.create', title: 'Register organization member', group: 'Membership',
    subjects: [],
    fields: [
      text('legalName', 'Legal name', { required: true }),
      text('registrationNumber', 'Registration number', { required: true }),
      sel('organizationType', 'Organization type', fixed([['corporation', 'Corporation'], ['nonprofit', 'Nonprofit']]), { required: true }),
      text('email', 'Email', { required: false }),
      text('phone', 'Phone', { required: false }),
      address('address', 'Mailing address', { required: false }),
    ],
    build: (f) => ({
      kind: 'member.organization.create',
      legalName: f.text('legalName', 'Legal name'),
      registrationNumber: f.text('registrationNumber', 'Registration number'),
      organizationType: f.text('organizationType', 'Organization type') as 'corporation' | 'nonprofit',
      email: f.optional('email'),
      phone: f.optional('phone'),
      address: f.address('address'),
    }),
  },
  {
    kind: 'contact.update', title: 'Update contact information', group: 'Membership',
    subjects: [memberSubject],
    fields: [
      text('email', 'Email', { required: false, default: (_e, s) => str(subj(s, 'member')?.data.email ?? ''), help: 'Leave empty to keep the stored value; enter a single dash to clear.' }),
      text('phone', 'Phone', { required: false, default: (_e, s) => str(subj(s, 'member')?.data.phone ?? '') }),
      address('address', 'Mailing address', { required: false }),
    ],
    build: (f, s) => {
      const patch: { email?: string | null; phone?: string | null; address?: AddressInput } = {};
      const email = f.get('email');
      const phone = f.get('phone');
      if (email !== '') patch.email = email === '-' ? null : email;
      if (phone !== '') patch.phone = phone === '-' ? null : phone;
      const addr = f.address('address');
      if (addr !== null) patch.address = addr;
      return { kind: 'contact.update', memberId: needSubject(s,'member').id, expectedVersion: need(needSubject(s,'member').version, 's_member', 'Member version'), ...patch };
    },
  },
  {
    kind: 'member.note.add', title: 'Add member note', group: 'Membership',
    subjects: [memberSubject],
    fields: [
      sel('visibility', 'Visibility', fixed([['general', 'General'], ['restricted', 'Restricted']]), { required: true }),
      area('text', 'Note', { required: true }),
    ],
    build: (f, s) => ({ kind: 'member.note.add', memberId: needSubject(s,'member').id, visibility: f.text('visibility', 'Visibility') as 'general' | 'restricted', text: f.text('text', 'Note') }),
  },
  {
    kind: 'account.open', title: 'Open account', group: 'Accounts',
    subjects: [memberSubject],
    fields: [
      sel('productId', 'Product', (env) => pickers.products(env, 'deposit'), { required: true }),
      text('nickname', 'Nickname', { required: false }),
      sel('statementDelivery', 'Statement delivery', fixed([['paper', 'Paper'], ['electronic', 'Electronic']]), { required: true }),
    ],
    build: (f, s) => ({ kind: 'account.open', memberId: needSubject(s,'member').id, productId: f.text('productId', 'Product'), nickname: f.get('nickname'), statementDelivery: f.text('statementDelivery', 'Statement delivery') as 'paper' | 'electronic' }),
  },
  {
    kind: 'account.nickname.update', title: 'Update account nickname', group: 'Accounts',
    subjects: [accountSubject],
    fields: [text('nickname', 'Nickname', { required: true, default: (_e, s) => str(needSubject(s,'account').data.nickname ?? '') })],
    build: (f, s) => ({ kind: 'account.nickname.update', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'), nickname: f.get('nickname') }),
  },
  {
    kind: 'account.statement_delivery.update', title: 'Update statement delivery', group: 'Accounts',
    subjects: [accountSubject],
    fields: [sel('statementDelivery', 'Statement delivery', fixed([['paper', 'Paper'], ['electronic', 'Electronic']]), { required: true, default: (_e, s) => str(needSubject(s,'account').data.statementDelivery ?? '') })],
    build: (f, s) => ({ kind: 'account.statement_delivery.update', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'), statementDelivery: f.text('statementDelivery', 'Statement delivery') as 'paper' | 'electronic' }),
  },
  {
    kind: 'account.close', title: 'Close account', group: 'Accounts',
    subjects: [accountSubject],
    fields: [text('reason', 'Closure reason', { required: true })],
    build: (f, s) => ({ kind: 'account.close', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'), reason: f.text('reason', 'Closure reason') }),
  },
  // ── Money movement ──────────────────────────────────────────────────────
  {
    kind: 'cash.deposit', title: 'Cash deposit', group: 'Money movement',
    subjects: [accountSubject],
    fields: [money('amount', 'Amount'), text('description', 'Description', { required: true })],
    build: (f, s) => ({ kind: 'cash.deposit', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'), amount: need(f.money('amount', 'Amount'), 'amount', 'Amount'), description: f.text('description', 'Description') }),
  },
  {
    kind: 'cash.withdraw', title: 'Cash withdrawal', group: 'Money movement',
    subjects: [accountSubject],
    fields: [money('amount', 'Amount'), text('description', 'Description', { required: true })],
    build: (f, s) => ({ kind: 'cash.withdraw', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'), amount: need(f.money('amount', 'Amount'), 'amount', 'Amount'), description: f.text('description', 'Description') }),
  },
  {
    kind: 'transfer.internal', title: 'Internal transfer', group: 'Money movement',
    subjects: [
      { key: 'source', kind: 'account', label: 'Source account' },
      { key: 'destination', kind: 'account', label: 'Destination account' },
    ],
    fields: [money('amount', 'Amount'), text('description', 'Description', { required: true })],
    build: (f, s) => ({
      kind: 'transfer.internal',
      sourceAccountId: needSubject(s,'source').id, destinationAccountId: needSubject(s,'destination').id,
      expectedSourceVersion: need(needSubject(s,'source').version, 's_source', 'Source version'), expectedDestinationVersion: need(needSubject(s,'destination').version, 's_destination', 'Destination version'),
      amount: need(f.money('amount', 'Amount'), 'amount', 'Amount'), description: f.text('description', 'Description'),
    }),
  },
  // ── Cases ────────────────────────────────────────────────────────────────
  {
    kind: 'case.open', title: 'Open servicing case', group: 'Cases',
    subjects: [memberSubject],
    fields: [
      sel('accountId', 'Account', (env, s) => [{ value: '', label: '— none —' }, ...(pickers.accounts(env, needSubject(s,'member').id) as Option[])], { required: false }),
      sel('queueId', 'Queue', (env) => pickers.queues(env), { required: true }),
      sel('assignedActorId', 'Assigned operator', (env) => [{ value: '', label: '— unassigned —' }, ...(pickers.caseWorkers(env) as Option[])], { required: false }),
      sel('category', 'Category', fixed([['contact', 'Contact'], ['account-servicing', 'Account servicing'], ['document-request', 'Document request'], ['estate-review', 'Estate review'], ['general', 'General']]), { required: true }),
      sel('priority', 'Priority', fixed([['low', 'Low'], ['normal', 'Normal'], ['high', 'High'], ['urgent', 'Urgent']]), { required: true }),
      text('summary', 'Summary', { required: true }),
      date('dueDate', 'Due date', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'case.open', memberId: needSubject(s,'member').id, accountId: f.optional('accountId'), queueId: f.text('queueId', 'Queue'),
      assignedActorId: f.optional('assignedActorId'), category: f.text('category', 'Category'),
      priority: f.text('priority', 'Priority') as 'low' | 'normal' | 'high' | 'urgent', summary: f.text('summary', 'Summary'),
      dueDate: need(f.date('dueDate', 'Due date'), 'dueDate', 'Due date'),
    }),
  },
  {
    kind: 'case.assign', title: 'Reassign case', group: 'Cases',
    subjects: [caseSubject],
    fields: [
      sel('queueId', 'Queue', (env) => pickers.queues(env), { required: true }),
      sel('assignedActorId', 'Assigned operator', (env) => [{ value: '', label: '— unassigned —' }, ...(pickers.caseWorkers(env) as Option[])], { required: false }),
      text('reason', 'Reason', { required: true }),
    ],
    build: (f, s) => ({ kind: 'case.assign', caseId: needSubject(s,'case').id, expectedVersion: need(needSubject(s,'case').version, 's_case', 'Case version'), queueId: f.text('queueId', 'Queue'), assignedActorId: f.optional('assignedActorId'), reason: f.text('reason', 'Reason') }),
  },
  {
    kind: 'case.transition', title: 'Transition case', group: 'Cases',
    subjects: [caseSubject],
    fields: [
      sel('toState', 'Next state', (_env, s) => ((needSubject(s,'case').data.allowedTransitions as string[] | undefined) ?? []).map((state) => ({ value: state, label: state })), { required: true }),
      text('reason', 'Reason', { required: true }),
    ],
    build: (f, s) => ({ kind: 'case.transition', caseId: needSubject(s,'case').id, expectedVersion: need(needSubject(s,'case').version, 's_case', 'Case version'), toState: f.text('toState', 'Next state') as never, reason: f.text('reason', 'Reason') }),
  },
  {
    kind: 'case.note.add', title: 'Add case note', group: 'Cases',
    subjects: [caseSubject],
    fields: [
      sel('visibility', 'Visibility', fixed([['general', 'General'], ['restricted', 'Restricted']]), { required: true }),
      area('text', 'Note', { required: true }),
      multi('evidenceVersionIds', 'Evidence documents', memberDocuments, { required: false }),
    ],
    build: (f, s) => ({
      kind: 'case.note.add', caseId: needSubject(s,'case').id, visibility: f.text('visibility', 'Visibility') as 'general' | 'restricted',
      text: f.text('text', 'Note'), evidenceVersionIds: f.list('evidenceVersionIds'),
    }),
  },
  // ── Saved searches ──────────────────────────────────────────────────────
  {
    kind: 'search.saved.create', title: 'Save search', group: 'Inquiry',
    subjects: [],
    fields: [
      text('name', 'Search name', { required: true }),
      sel('visibility', 'Visibility', fixed([['private', 'Private'], ['shared', 'Shared']]), { required: true }),
      sel('entity', 'Entity', fixed([['members', 'Members'], ['accounts', 'Accounts'], ['cases', 'Cases']]), { required: true }),
      text('filters', 'Filters (field=value; one per line)', { required: false }),
      text('sort', 'Sort field', { required: false }),
      sel('direction', 'Sort direction', fixed([['asc', 'Ascending'], ['desc', 'Descending']]), { required: false }),
      text('columns', 'Columns (comma-separated)', { required: false }),
      integer('maxResults', 'Maximum results', { required: false }),
    ],
    build: (f) => savedSearchCommand(f, null),
  },
  {
    kind: 'search.saved.update', title: 'Update saved search', group: 'Inquiry',
    subjects: [{ key: 'search', kind: 'saved-search', label: 'Saved search' }],
    fields: [
      text('name', 'Search name', { required: false, default: (_e, s) => needSubject(s,'search').label }),
      sel('visibility', 'Visibility', fixed([['private', 'Private'], ['shared', 'Shared']]), { required: false }),
      sel('entity', 'Entity', fixed([['members', 'Members'], ['accounts', 'Accounts'], ['cases', 'Cases']]), { required: false }),
      text('filters', 'Filters (field=value; one per line)', { required: false }),
      text('sort', 'Sort field', { required: false }),
      sel('direction', 'Sort direction', fixed([['asc', 'Ascending'], ['desc', 'Descending']]), { required: false }),
      text('columns', 'Columns (comma-separated)', { required: false }),
      integer('maxResults', 'Maximum results', { required: false }),
    ],
    build: (f, s) => savedSearchCommand(f, needSubject(s,'search')),
  },
  {
    kind: 'search.saved.delete', title: 'Delete saved search', group: 'Inquiry',
    subjects: [{ key: 'search', kind: 'saved-search', label: 'Saved search' }],
    fields: [],
    build: (_f, s) => ({ kind: 'search.saved.delete', searchId: needSubject(s,'search').id, expectedRevision: need(needSubject(s,'search').fingerprint, 's_search', 'Search revision') }),
  },
  {
    kind: 'edit.cancel', title: 'Cancel pending edit', group: 'Servicing',
    subjects: [{ key: 'request', kind: 'maintenance-request', label: 'Maintenance request' }],
    fields: [],
    build: (_f, s) => ({ kind: 'edit.cancel', requestId: needSubject(s,'request').id, expectedUpdatedAt: need(needSubject(s,'request').updatedAt, 's_request', 'Request timestamp') }),
  },
  // ── Identity ─────────────────────────────────────────────────────────────
  {
    kind: 'member.identity_evidence.register', title: 'Register identity evidence', group: 'Identity',
    subjects: [memberSubject],
    fields: [
      sel('documentVersionId', 'Evidence document version', memberDocuments, { required: true }),
      sel('evidenceKind', 'Evidence kind', fixed([['passport', 'Passport'], ['drivers-license', "Driver's license"], ['national-id', 'National ID'], ['state-id', 'State ID']]), { required: true }),
      instant('issuedAt', 'Issued at', { required: true }),
      instant('expiresAt', 'Expires at', { required: true }),
      text('reference', 'Evidence reference', { required: true }),
      text('evidenceId', 'Evidence ID (optional)', { required: false }),
    ],
    build: (f, s) => ({
      kind: 'member.identity_evidence.register', memberId: needSubject(s,'member').id, documentVersionId: f.text('documentVersionId', 'Evidence document version'),
      evidenceKind: f.text('evidenceKind', 'Evidence kind') as 'passport' | 'drivers-license' | 'national-id' | 'state-id',
      issuedAt: need(f.instant('issuedAt', 'Issued at'), 'issuedAt', 'Issued at'), expiresAt: need(f.instant('expiresAt', 'Expires at'), 'expiresAt', 'Expires at'),
      reference: f.text('reference', 'Evidence reference'), ...(f.optional('evidenceId') === null ? {} : { evidenceId: f.get('evidenceId') }),
    }),
  },
  {
    kind: 'member.identity.verify', title: 'Verify identity evidence', group: 'Identity',
    subjects: [memberSubject],
    fields: [
      sel('evidenceId', 'Identity evidence', memberEvidence, { required: true }),
      text('method', 'Verification method', { required: true }),
    ],
    build: (f, s) => ({ kind: 'member.identity.verify', memberId: needSubject(s,'member').id, evidenceId: f.text('evidenceId', 'Identity evidence'), method: f.text('method', 'Verification method') }),
  },
  {
    kind: 'member.legal_name.update', title: 'Update legal name', group: 'Identity', approval: true,
    subjects: [memberSubject],
    fields: [
      text('legalGiven', 'Legal given name', { required: true }),
      text('legalFamily', 'Legal family name', { required: true }),
      sel('evidenceId', 'Identity evidence', memberEvidence, { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'member.legal_name.update', memberId: needSubject(s,'member').id, expectedVersion: need(needSubject(s,'member').version, 's_member', 'Member version'),
      legalGiven: f.text('legalGiven', 'Legal given name'), legalFamily: f.text('legalFamily', 'Legal family name'),
      evidenceId: f.text('evidenceId', 'Identity evidence'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'member.preferred_name.update', title: 'Update preferred name', group: 'Identity',
    subjects: [memberSubject],
    fields: [
      text('preferredName', 'Preferred name', { required: false, help: 'A single dash clears the preferred name.' }),
      text('communicationScope', 'Communication scope', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'member.preferred_name.update', memberId: needSubject(s,'member').id, expectedVersion: need(needSubject(s,'member').version, 's_member', 'Member version'),
      preferredName: f.get('preferredName') === '-' ? null : f.optional('preferredName'),
      communicationScope: f.text('communicationScope', 'Communication scope'),
    }),
  },
  // ── Documents ────────────────────────────────────────────────────────────
  {
    kind: 'document.index', title: 'Index document', group: 'Documents',
    subjects: [memberSubject],
    fields: [
      sel('accountId', 'Account', (env, s) => [{ value: '', label: '— none —' }, ...(pickers.accounts(env, needSubject(s,'member').id) as Option[])], { required: false }),
      text('documentType', 'Document type', { required: true }),
      text('displayName', 'Display name', { required: true }),
      text('retentionClass', 'Retention class', { required: true }),
      sel('documentId', 'Attach to existing document', (env, s) => [{ value: '', label: '— new document —' }, ...((pickers.documents(env, needSubject(s,'member').id) as Option[]))], { required: false }),
      area('bytes', 'Document content', { required: true, help: 'Plain-text content; stored bytes are content addressed.' }),
      integer('pageCount', 'Page count', { required: false }),
      text('source', 'Source description', { required: false }),
    ],
    build: (f, s) => ({
      kind: 'document.index', memberId: needSubject(s,'member').id, ownerPartyId: need(needSubject(s,'member').partyId, 's_member', 'Member party'),
      accountId: f.optional('accountId'), ...(f.optional('documentId') === null ? {} : { documentId: f.get('documentId') }),
      documentType: f.text('documentType', 'Document type'), displayName: f.text('displayName', 'Display name'),
      retentionClass: f.text('retentionClass', 'Retention class'), bytes: f.bytes('bytes', 'Document content'),
      mediaType: 'text/plain', pageCount: f.int('pageCount', 'Page count', false) ?? null,
      source: f.get('source') || 'operator-console',
    }),
  },
  {
    kind: 'document.bundle.redact', title: 'Create redacted document bundle', group: 'Documents',
    subjects: [memberSubject],
    fields: [
      multi('sourceVersionIds', 'Source versions', memberDocuments, { required: true, step1: true }),
      text('recipientPurpose', 'Recipient purpose', { required: true }),
      sel('redactionPolicyVersionId', 'Redaction policy', (env) => pickers.policyVersions(env), { required: true }),
      text('displayName', 'Bundle display name', { required: false }),
      area('excerpts', 'Approved excerpts (versionId: text; one per line)', { required: true }),
    ],
    build: (f, s) => {
      const sourceVersionIds = f.list('sourceVersionIds');
      const excerpts = f.get('excerpts').split('\n').map((line) => {
        const [versionId, ...rest] = line.split(':');
        return { sourceVersionId: (versionId ?? '').trim(), text: rest.join(':').trim() };
      }).filter((item) => item.sourceVersionId !== '' && item.text !== '');
      return {
        kind: 'document.bundle.redact', memberId: needSubject(s,'member').id, sourceVersionIds,
        recipientPurpose: f.text('recipientPurpose', 'Recipient purpose'),
        redactionPolicyVersionId: f.text('redactionPolicyVersionId', 'Redaction policy'),
        approvedExcerpts: excerpts, ...(f.optional('displayName') === null ? {} : { displayName: f.get('displayName') }),
      };
    },
  },
  {
    kind: 'document.signature.collect', title: 'Collect document signature', group: 'Documents',
    subjects: [{ key: 'version', kind: 'document-version', label: 'Document version' }],
    fields: [
      sel('action', 'Action', fixed([['request', 'Request'], ['sign', 'Record signature'], ['decline', 'Record decline'], ['expire', 'Expire request']]), { required: true, step1: true }),
      multi('signerPartyIds', 'Signer parties', memberParties, { required: true }),
      text('channel', 'Channel', { required: true }),
      text('evidenceReference', 'Evidence reference', { required: false, help: 'Required when recording a terminal response.' }),
    ],
    build: (f, s) => ({
      kind: 'document.signature.collect', action: f.text('action', 'Action') as 'request' | 'sign' | 'decline' | 'expire',
      documentVersionId: needSubject(s,'version').id, signerPartyIds: f.list('signerPartyIds'),
      channel: f.text('channel', 'Channel'), ...(f.optional('evidenceReference') === null ? {} : { evidenceReference: f.get('evidenceReference') }),
    }),
  },
  {
    kind: 'consent.delivery.record', title: 'Record consent delivery', group: 'Servicing',
    subjects: [memberSubject],
    fields: [
      sel('accountId', 'Account', (env, s) => [{ value: '', label: '— member scope —' }, ...(pickers.accounts(env, needSubject(s,'member').id) as Option[])], { required: false }),
      text('purpose', 'Purpose', { required: true }),
      text('channel', 'Channel', { required: true }),
      sel('disclosureVersionId', 'Disclosure version', memberDocuments, { required: true }),
      text('evidence', 'Acknowledgement evidence', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'consent.delivery.record', partyId: need(needSubject(s,'member').partyId, 's_member', 'Member party'),
      accountId: f.optional('accountId'), purpose: f.text('purpose', 'Purpose'), channel: f.text('channel', 'Channel'),
      disclosureVersionId: f.text('disclosureVersionId', 'Disclosure version'), evidence: f.text('evidence', 'Acknowledgement evidence'),
    }),
  },
  {
    kind: 'consent.withdraw', title: 'Withdraw consent', group: 'Servicing',
    subjects: [memberSubject, { key: 'consent', kind: 'consent', label: 'Consent' }],
    fields: [
      strings('affectedChannels', 'Affected channels (comma-separated)'),
      instant('effectiveAt', 'Effective at', { required: false }),
    ],
    build: (f, s) => ({
      kind: 'consent.withdraw', consentId: needSubject(s,'consent').id, affectedChannels: f.strings('affectedChannels'),
      ...(f.instant('effectiveAt', 'Effective at', false) === undefined ? {} : { effectiveAt: f.get('effectiveAt') }),
    }),
  },
  {
    kind: 'document.customer_export.create', title: 'Create customer data export', group: 'Documents', approval: true,
    subjects: [memberSubject],
    fields: [
      strings('categories', 'Categories (comma-separated)'),
      date('from', 'From', { required: false }),
      date('through', 'Through', { required: false }),
      sel('destination', 'Destination', (env) => pickers.exportDestinations(env), { required: true }),
      multi('documentVersionIds', 'Included document versions', memberDocuments, { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'document.customer_export.create', memberId: needSubject(s,'member').id, categories: f.strings('categories'),
      from: f.date('from', 'From', false) ?? null, through: f.date('through', 'Through', false) ?? null,
      destination: f.text('destination', 'Destination'), documentVersionIds: f.list('documentVersionIds'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'document.retention_hold.apply', title: 'Apply retention hold', group: 'Documents', approval: true,
    subjects: [memberSubject],
    fields: [
      sel('holdTarget', 'Hold target', fixed([['document', 'Document'], ['case', 'Case']]), { required: true, step1: true }),
      sel('documentId', 'Document', (env, s, step) => step.holdTarget === 'case' ? [] : pickers.documents(env, needSubject(s,'member').id), { required: false }),
      sel('caseId', 'Case', (env, s, step) => step.holdTarget === 'document' ? [] : pickers.cases(env, needSubject(s,'member').id), { required: false }),
      text('reason', 'Reason', { required: true }),
      instant('reviewAt', 'Review at', { required: true }),
      approvalField,
    ],
    build: (f) => {
      const target = f.get('holdTarget');
      return {
        kind: 'document.retention_hold.apply',
        ...(target === 'document' ? { documentId: f.text('documentId', 'Document') } : {}),
        ...(target === 'case' ? { caseId: f.text('caseId', 'Case') } : {}),
        reason: f.text('reason', 'Reason'), reviewAt: need(f.instant('reviewAt', 'Review at'), 'reviewAt', 'Review at'),
        approvalId: f.text('approvalId', 'Approval'),
      };
    },
  },
  // ── Case servicing ───────────────────────────────────────────────────────
  {
    kind: 'case.information.request', title: 'Request case information', group: 'Cases',
    subjects: [caseSubject],
    fields: [
      strings('fields', 'Requested fields (comma-separated)'),
      sel('recipientPartyId', 'Recipient party', memberParties, { required: true }),
      text('channel', 'Channel', { required: true }),
      instant('dueAt', 'Due at', { required: true }),
      sel('documentVersionId', 'Request document', (env, s) => [{ value: '', label: '— none —' }, ...((memberDocuments(env, s) as Option[]))], { required: false }),
      text('destination', 'Destination', { required: false }),
    ],
    build: (f, s) => ({
      kind: 'case.information.request', caseId: needSubject(s,'case').id, expectedVersion: need(needSubject(s,'case').version, 's_case', 'Case version'),
      fields: f.strings('fields'), recipientPartyId: f.text('recipientPartyId', 'Recipient party'),
      channel: f.text('channel', 'Channel'), dueAt: need(f.instant('dueAt', 'Due at'), 'dueAt', 'Due at'),
      documentVersionId: f.optional('documentVersionId'), ...(f.optional('destination') === null ? {} : { destination: f.get('destination') }),
    }),
  },
  {
    kind: 'case.escalate', title: 'Escalate case', group: 'Cases',
    subjects: [caseSubject],
    fields: [
      sel('escalationRule', 'Escalation rule', fixed([['sla-breach', 'SLA breach'], ['customer-request', 'Customer request'], ['restricted-queue', 'Restricted queue'], ['standard', 'Standard escalation']]), { required: true }),
    ],
    build: (f, s) => ({ kind: 'case.escalate', caseId: needSubject(s,'case').id, expectedVersion: need(needSubject(s,'case').version, 's_case', 'Case version'), escalationRule: f.text('escalationRule', 'Escalation rule') }),
  },
  {
    kind: 'case.close', title: 'Close case', group: 'Cases',
    subjects: [caseSubject],
    fields: [
      text('resolutionCode', 'Resolution code', { required: true }),
      sel('effectEvidenceVersionId', 'Effect evidence', memberDocuments, { required: true }),
    ],
    build: (f, s) => ({
      kind: 'case.close', caseId: needSubject(s,'case').id, expectedVersion: need(needSubject(s,'case').version, 's_case', 'Case version'),
      resolutionCode: f.text('resolutionCode', 'Resolution code'), effectEvidenceVersionId: f.text('effectEvidenceVersionId', 'Effect evidence'),
    }),
  },
  {
    kind: 'case.reopen', title: 'Reopen case', group: 'Cases',
    subjects: [caseSubject],
    fields: [
      sel('evidenceVersionId', 'Reopening evidence', memberDocuments, { required: true }),
      text('reopeningBasis', 'Reopening basis', { required: true }),
      instant('dueAt', 'New due date', { required: false }),
    ],
    build: (f, s) => ({
      kind: 'case.reopen', caseId: needSubject(s,'case').id, expectedVersion: need(needSubject(s,'case').version, 's_case', 'Case version'),
      evidenceVersionId: f.text('evidenceVersionId', 'Reopening evidence'), reopeningBasis: f.text('reopeningBasis', 'Reopening basis'),
      ...(f.instant('dueAt', 'New due date', false) === undefined ? {} : { dueAt: f.get('dueAt') }),
    }),
  },
  {
    kind: 'case.subject.correct', title: 'Correct case subject', group: 'Cases', approval: true,
    subjects: [caseSubject, { key: 'correctMember', kind: 'member', label: 'Correct member' }],
    fields: [
      sel('correctAccountId', 'Correct account', (env, s) => [{ value: '', label: '— none —' }, ...(pickers.accounts(env, needSubject(s,'correctMember').id) as Option[])], { required: false }),
      sel('evidenceVersionId', 'Correction evidence', (env, s) => pickers.documentVersions(env, needSubject(s,'correctMember').id), { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'case.subject.correct', caseId: needSubject(s,'case').id, expectedVersion: need(needSubject(s,'case').version, 's_case', 'Case version'),
      correctMemberId: needSubject(s,'correctMember').id, correctAccountId: f.optional('correctAccountId'),
      evidenceVersionId: f.text('evidenceVersionId', 'Correction evidence'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  // ── Maintenance requests ─────────────────────────────────────────────────
  {
    kind: 'maintenance.draft.save', title: 'Save maintenance draft', group: 'Maintenance',
    subjects: [memberSubject],
    fields: [
      sel('requestedKind', 'Requested change', fixed([
        ['contact.update', 'Contact update'], ['member.note.add', 'Member note'], ['account.nickname.update', 'Nickname'],
        ['account.statement_delivery.update', 'Statement delivery'], ['account.close', 'Account close'],
      ]), { required: true, step1: true }),
      sel('accountId', 'Account', (env, s, step) => ['account.nickname.update', 'account.statement_delivery.update', 'account.close'].includes(step.requestedKind ?? '')
        ? pickers.accounts(env, needSubject(s,'member').id) : [{ value: '', label: '— none —' }, ...(pickers.accounts(env, needSubject(s,'member').id) as Option[])], { required: false }),
      text('category', 'Category', { required: true }),
      text('subject', 'Subject', { required: true }),
      area('note', 'Note', { required: false }),
      strings('missingFields', 'Missing fields (comma-separated)'),
      multi('evidenceDocumentVersionIds', 'Evidence documents', memberDocuments, { required: false }),
      text('rEmail', 'Requested email', { required: false, when: (step) => step.requestedKind === 'contact.update' }),
      text('rPhone', 'Requested phone', { required: false, when: (step) => step.requestedKind === 'contact.update' }),
      address('rAddress', 'Requested address', { required: false, when: (step) => step.requestedKind === 'contact.update' }),
      area('rText', 'Note text', { required: false, when: (step) => step.requestedKind === 'member.note.add' }),
      sel('rVisibility', 'Note visibility', fixed([['general', 'General'], ['restricted', 'Restricted']]), { required: false, when: (step) => step.requestedKind === 'member.note.add' }),
      text('rNickname', 'Requested nickname', { required: false, when: (step) => step.requestedKind === 'account.nickname.update' }),
      sel('rDelivery', 'Requested delivery', fixed([['paper', 'Paper'], ['electronic', 'Electronic']]), { required: false, when: (step) => step.requestedKind === 'account.statement_delivery.update' }),
      text('rReason', 'Closure reason', { required: false, when: (step) => step.requestedKind === 'account.close' }),
    ],
    build: (f, s, env) => {
      const requestedKind = f.text('requestedKind', 'Requested change');
      const memberVersion = needSubject(s,'member').version ?? 0;
      const accountVersion = (id: string): number => {
        const detail = read(env, (database) => (database.prepare('SELECT version FROM accounts WHERE dataset_id=? AND id=?').get(env.context.binding.datasetId, id) as { version: number } | undefined));
        if (isRejected(detail) || detail === undefined) fail('accountId', 'The selected account cannot be resolved.');
        return detail.version;
      };
      const accountId = f.optional('accountId');
      const requestedCommand = (() => {
        switch (requestedKind) {
          case 'contact.update': {
            const patch: { email?: string | null; phone?: string | null; address?: AddressInput } = {};
            if (f.get('rEmail') !== '') patch.email = f.get('rEmail') === '-' ? null : f.get('rEmail');
            if (f.get('rPhone') !== '') patch.phone = f.get('rPhone') === '-' ? null : f.get('rPhone');
            const addr = f.address('rAddress');
            if (addr !== null) patch.address = addr;
            return { kind: 'contact.update' as const, memberId: needSubject(s,'member').id, expectedVersion: memberVersion, ...patch };
          }
          case 'member.note.add':
            return { kind: 'member.note.add' as const, memberId: needSubject(s,'member').id, visibility: (f.get('rVisibility') || 'general') as 'general' | 'restricted', text: f.text('rText', 'Note text') };
          case 'account.nickname.update':
            if (accountId === null) fail('accountId', 'Account is required.');
            return { kind: 'account.nickname.update' as const, accountId, expectedVersion: accountVersion(accountId), nickname: f.get('rNickname') };
          case 'account.statement_delivery.update':
            if (accountId === null) fail('accountId', 'Account is required.');
            return { kind: 'account.statement_delivery.update' as const, accountId, expectedVersion: accountVersion(accountId), statementDelivery: (f.get('rDelivery') || 'paper') as 'paper' | 'electronic' };
          default:
            if (accountId === null) fail('accountId', 'Account is required.');
            return { kind: 'account.close' as const, accountId, expectedVersion: accountVersion(accountId), reason: f.get('rReason') };
        }
      })();
      return {
        kind: 'maintenance.draft.save', memberId: needSubject(s,'member').id, accountId,
        category: f.text('category', 'Category'), subject: f.text('subject', 'Subject'),
        requestedCommand, ...(f.optional('note') === null ? {} : { note: f.get('note') }), missingFields: f.strings('missingFields'),
        evidenceDocumentVersionIds: f.list('evidenceDocumentVersionIds'),
      };
    },
  },
  {
    kind: 'maintenance.draft.amend', title: 'Amend maintenance draft', group: 'Maintenance',
    subjects: [{ key: 'request', kind: 'maintenance-request', label: 'Maintenance request' }],
    fields: [
      text('subject', 'Subject', { required: false }),
      text('reason', 'Reason', { required: false }),
      area('note', 'Note', { required: false }),
      strings('missingFields', 'Missing fields (comma-separated)'),
      sel('evidenceVersionId', 'Evidence version', memberDocuments, { required: false }),
      multi('evidenceDocumentVersionIds', 'Evidence documents', memberDocuments, { required: false }),
    ],
    build: (f, s) => {
      const patch: Record<string, unknown> = {};
      if (f.get('subject') !== '') patch.subject = f.get('subject');
      if (f.get('reason') !== '') patch.reason = f.get('reason');
      if (f.get('note') !== '') patch.note = f.get('note');
      const missing = f.strings('missingFields');
      if (missing.length > 0) patch.missingFields = missing;
      if (f.get('evidenceVersionId') !== '') patch.evidenceVersionId = f.get('evidenceVersionId');
      const docs = f.list('evidenceDocumentVersionIds');
      if (docs.length > 0) patch.evidenceDocumentVersionIds = docs;
      return { kind: 'maintenance.draft.amend', requestId: needSubject(s,'request').id, expectedUpdatedAt: need(needSubject(s,'request').updatedAt, 's_request', 'Request timestamp'), patch };
    },
  },
  {
    kind: 'maintenance.request.submit', title: 'Submit maintenance request', group: 'Maintenance',
    subjects: [{ key: 'request', kind: 'maintenance-request', label: 'Maintenance request' }],
    fields: [],
    build: (_f, s) => ({ kind: 'maintenance.request.submit', requestId: needSubject(s,'request').id, expectedUpdatedAt: need(needSubject(s,'request').updatedAt, 's_request', 'Request timestamp'), declaredState: 'submitted' }),
  },
  {
    kind: 'maintenance.request.withdraw', title: 'Withdraw maintenance request', group: 'Maintenance',
    subjects: [{ key: 'request', kind: 'maintenance-request', label: 'Maintenance request' }],
    fields: [text('reason', 'Reason', { required: true })],
    build: (f, s) => ({ kind: 'maintenance.request.withdraw', requestId: needSubject(s,'request').id, expectedUpdatedAt: need(needSubject(s,'request').updatedAt, 's_request', 'Request timestamp'), reason: f.text('reason', 'Reason') }),
  },
  {
    kind: 'maintenance.request.review', title: 'Review maintenance request', group: 'Maintenance',
    subjects: [{ key: 'request', kind: 'maintenance-request', label: 'Maintenance request' }],
    fields: [
      sel('decision', 'Decision', fixed([['approve', 'Approve'], ['reject', 'Reject'], ['return-for-information', 'Return for information']]), { required: true }),
      text('reason', 'Reason', { required: true }),
      strings('missingFields', 'Missing fields (comma-separated)'),
    ],
    build: (f, s) => ({
      kind: 'maintenance.request.review', requestId: needSubject(s,'request').id, expectedUpdatedAt: need(needSubject(s,'request').updatedAt, 's_request', 'Request timestamp'),
      decision: f.text('decision', 'Decision') as 'approve' | 'reject' | 'return-for-information',
      reason: f.text('reason', 'Reason'), missingFields: f.strings('missingFields'),
    }),
  },
  {
    kind: 'maintenance.request.process', title: 'Process maintenance request', group: 'Maintenance',
    subjects: [{ key: 'request', kind: 'maintenance-request', label: 'Maintenance request' }],
    fields: [
      sel('disposition', 'Disposition', fixed([['apply', 'Apply'], ['reject', 'Reject']]), { required: true }),
      text('reason', 'Reason', { required: true }),
      text('appliedReceiptId', 'Applied receipt ID', { required: false, help: 'Required when applying: the receipt of the already committed change.' }),
    ],
    build: (f, s) => ({
      kind: 'maintenance.request.process', requestId: needSubject(s,'request').id, expectedUpdatedAt: need(needSubject(s,'request').updatedAt, 's_request', 'Request timestamp'),
      disposition: f.text('disposition', 'Disposition') as 'apply' | 'reject', reason: f.text('reason', 'Reason'),
      ...(f.optional('appliedReceiptId') === null ? {} : { appliedReceiptId: f.get('appliedReceiptId') }),
    }),
  },
  // ── Address maintenance ──────────────────────────────────────────────────
  {
    kind: 'maintenance.address.reconcile', title: 'Reconcile member address', group: 'Servicing', approval: true,
    subjects: [memberSubject],
    fields: [
      sel('conflictingAddressId', 'Conflicting address', (env, s) => pickers.addresses(env, needSubject(s,'member').id), { required: true }),
      sel('winningEvidence', 'Winning evidence version', (env, s) => pickers.documentVersionsWithDigest(env, needSubject(s,'member').id), { required: true }),
      text('precedence', 'Precedence rule', { required: true }),
      address('address', 'Canonical address'),
      approvalField,
    ],
    build: (f, s) => {
      const [versionId, digest] = f.text('winningEvidence', 'Winning evidence version').split('|');
      return {
        kind: 'maintenance.address.reconcile', memberId: needSubject(s,'member').id, expectedMemberVersion: need(needSubject(s,'member').version, 's_member', 'Member version'),
        conflictingAddressId: f.text('conflictingAddressId', 'Conflicting address'),
        winningEvidenceVersionId: versionId ?? '', winningEvidenceDigest: digest ?? '',
        precedence: f.text('precedence', 'Precedence rule'), address: need(f.address('address'), 'address', 'Canonical address'),
        approvalId: f.text('approvalId', 'Approval'),
      };
    },
  },
  {
    kind: 'maintenance.address.destination.update', title: 'Update address destination', group: 'Servicing', approval: true,
    subjects: [memberSubject],
    fields: [
      sel('context', 'Destination context', fixed([['member-mailing', 'Member mailing'], ['account-statement', 'Account statement'], ['card-shipping', 'Card shipping'], ['loan-notice', 'Loan notice']]), { required: true, step1: true }),
      sel('targetId', 'Target', (env, s, step) => {
        const member = needSubject(s,'member');
        switch (step.context) {
          case 'account-statement': return pickers.accounts(env, member.id);
          case 'card-shipping': return sqlOptionsFor(env, `SELECT c.id,c.last_four,c.status FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? AND a.member_id=? ORDER BY c.id`, (item) => `····${str(item.last_four)} · ${str(item.status)}`, member.id);
          case 'loan-notice': return sqlOptionsFor(env, `SELECT l.id,l.state,l.principal_minor_units FROM loans l JOIN accounts a ON a.dataset_id=l.dataset_id AND a.id=l.account_id WHERE l.dataset_id=? AND a.member_id=? ORDER BY l.id`, (item) => `${str(item.id)} · ${str(item.state)}`, member.id);
          default: return [{ value: member.id, label: member.label }];
        }
      }, { required: true }),
      sel('addressId', 'Address', (env, s) => pickers.partyAddresses(env, needSubject(s,'member').id), { required: true }),
      sel('evidenceVersionId', 'Evidence version', (env, s) => pickers.documentVersions(env, needSubject(s,'member').id), { required: true }),
      date('effectiveDate', 'Effective date', { required: true }),
      sel('consentId', 'Postal consent', (env, s) => [{ value: '', label: '— none required —' }, ...(pickers.consents(env, needSubject(s,'member').id) as Option[])], { required: false }),
      approvalField,
    ],
    extraHidden: (env, _resolved, step) => {
      const context = step?.context ?? 'member-mailing';
      const targetId = step?.targetId;
      if (targetId === undefined || targetId === '') return {};
      const column = context === 'account-statement' ? 'account_id' : context === 'card-shipping' ? 'card_id' : context === 'loan-notice' ? 'loan_id' : 'member_id';
      const result = read(env, (database) => database.prepare(
        `SELECT id FROM address_destinations WHERE dataset_id=? AND context_kind=? AND ${column}=? AND ends_at IS NULL ORDER BY effective_at DESC LIMIT 1`,
      ).get(env.context.binding.datasetId, context, targetId) as { id: string } | undefined);
      if (isRejected(result)) return {};
      return { currentDestination: result?.id ?? '' };
    },
    build: (f, s) => ({
      kind: 'maintenance.address.destination.update', memberId: needSubject(s,'member').id,
      context: f.text('context', 'Destination context') as never,
      targetId: f.text('targetId', 'Target'), addressId: f.text('addressId', 'Address'),
      evidenceVersionId: f.text('evidenceVersionId', 'Evidence version'), effectiveDate: need(f.date('effectiveDate', 'Effective date'), 'effectiveDate', 'Effective date'),
      expectedCurrentDestinationId: f.get('h_currentDestination') === '' ? null : f.get('h_currentDestination'),
      consentId: f.optional('consentId'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  // ── Annotations and metadata ─────────────────────────────────────────────
  {
    kind: 'document.annotation.update', title: 'Annotate document', group: 'Documents',
    subjects: [{ key: 'version', kind: 'document-version', label: 'Document version' }],
    fields: [
      sel('action', 'Action', fixed([['create', 'Create'], ['amend', 'Amend'], ['remove', 'Remove']]), { required: true, step1: true }),
      sel('annotation', 'Existing annotation', (env, s, step) => step.action === 'create' ? [] : pickers.annotations(env, needSubject(s,'version').id), { required: false, when: (step) => step.action !== 'create' }),
      integer('pageNumber', 'Page', { required: true }),
      integer('regionX', 'Region X (micros)', { required: true }),
      integer('regionY', 'Region Y (micros)', { required: true }),
      integer('regionW', 'Region width (micros)', { required: true }),
      integer('regionH', 'Region height (micros)', { required: true }),
      area('text', 'Annotation text', { required: false, when: (step) => step.action !== 'remove' }),
    ],
    build: (f, s) => {
      const annotation = f.get('annotation');
      const [annotationId, fingerprint] = annotation === '' ? ['', ''] : annotation.split('|');
      const action = f.text('action', 'Action') as 'create' | 'amend' | 'remove';
      if (action !== 'create' && annotationId === '') fail('annotation', 'Existing annotation is required.');
      return {
        kind: 'document.annotation.update', documentVersionId: needSubject(s,'version').id, action,
        ...(annotationId === '' ? {} : { annotationId }),
        ...(fingerprint === '' || fingerprint === undefined ? {} : { expectedAnnotationFingerprint: fingerprint }),
        pageNumber: need(f.int('pageNumber', 'Page'), 'pageNumber', 'Page'),
        regionMicros: {
          x: need(f.int('regionX', 'Region X'), 'regionX', 'Region X'),
          y: need(f.int('regionY', 'Region Y'), 'regionY', 'Region Y'),
          width: need(f.int('regionW', 'Region width'), 'regionW', 'Region width'),
          height: need(f.int('regionH', 'Region height'), 'regionH', 'Region height'),
        },
        ...(f.optional('text') === null ? {} : { text: f.get('text') }),
      };
    },
  },
  {
    kind: 'document.metadata.update', title: 'Update document metadata', group: 'Documents', approval: true,
    subjects: [{ key: 'document', kind: 'document', label: 'Document' }],
    fields: [
      text('documentType', 'Document type', { required: true, default: (_e, s) => str(needSubject(s,'document').data.documentType ?? '') }),
      text('displayName', 'Display name', { required: true, default: (_e, s) => str(needSubject(s,'document').data.displayName ?? '') }),
      sel('ownerPartyId', 'Owner party', memberParties, { required: true, default: (_e, s) => str(needSubject(s,'document').data.ownerPartyId ?? '') }),
      sel('accountId', 'Account', (env, s) => [{ value: '', label: '— none —' }, ...(needSubject(s,'document').memberId === undefined ? [] : (pickers.accounts(env, needSubject(s,'document').memberId) as Option[]))], { required: false, default: (_e, s) => str(needSubject(s,'document').data.accountId ?? '') }),
      text('retentionClass', 'Retention class', { required: true, default: (_e, s) => str(needSubject(s,'document').data.retentionClass ?? '') }),
      approvalField,
    ],
    extraHidden: (_env, resolved) => ({
      expectedMetadata: JSON.stringify({
        ownerPartyId: needSubject(resolved,'document').data.ownerPartyId ?? '',
        accountId: needSubject(resolved,'document').data.accountId ?? null,
        documentType: needSubject(resolved,'document').data.documentType ?? '',
        displayName: needSubject(resolved,'document').data.displayName ?? '',
        retentionClass: needSubject(resolved,'document').data.retentionClass ?? '',
      }),
    }),
    build: (f, s) => {
      const expected = f.json('h_expectedMetadata', 'Expected metadata') as Record<string, unknown> | undefined;
      return {
        kind: 'document.metadata.update', documentId: needSubject(s,'document').id,
        expectedMetadata: expected === undefined
          ? { ownerPartyId: '', accountId: null, documentType: '', displayName: '', retentionClass: '' }
          : (expected as { ownerPartyId: string; accountId: string | null; documentType: string; displayName: string; retentionClass: string }),
        documentType: f.text('documentType', 'Document type'), displayName: f.text('displayName', 'Display name'),
        ownerPartyId: f.text('ownerPartyId', 'Owner party'), accountId: f.optional('accountId'),
        retentionClass: f.text('retentionClass', 'Retention class'), ...(f.optional('approvalId') === null ? {} : { approvalId: f.get('approvalId') }),
      };
    },
  },
  // ── Communication ────────────────────────────────────────────────────────
  {
    kind: 'communication.preference.update', title: 'Update communication preference', group: 'Servicing',
    subjects: [memberSubject],
    fields: [
      text('purpose', 'Purpose', { required: true }),
      text('channel', 'Channel', { required: true }),
      sel('state', 'State', fixed([['enabled', 'Enabled'], ['disabled', 'Disabled']]), { required: true }),
    ],
    build: (f, s) => ({
      kind: 'communication.preference.update', partyId: need(needSubject(s,'member').partyId, 's_member', 'Member party'),
      purpose: f.text('purpose', 'Purpose'), channel: f.text('channel', 'Channel'),
      state: f.text('state', 'State') as 'enabled' | 'disabled',
    }),
  },
  {
    kind: 'communication.send', title: 'Send communication', group: 'Servicing',
    subjects: [memberSubject],
    fields: [
      text('channel', 'Channel', { required: true }),
      text('destination', 'Destination', { required: false, help: 'Required for electronic delivery; postal uses the address destination.' }),
      sel('addressDestinationId', 'Address destination', (env, s) => [{ value: '', label: '— none —' }, ...(pickers.addressDestinations(env, needSubject(s,'member').id) as Option[])], { required: false }),
      text('purpose', 'Purpose', { required: true }),
      sel('documentVersionId', 'Document version', (env, s) => pickers.documentVersions(env, needSubject(s,'member').id), { required: true }),
      text('jobId', 'Existing job ID (optional)', { required: false }),
    ],
    build: (f, s) => ({
      kind: 'communication.send', partyId: need(needSubject(s,'member').partyId, 's_member', 'Member party'),
      channel: f.text('channel', 'Channel'), ...(f.optional('destination') === null ? {} : { destination: f.get('destination') }),
      ...(f.optional('addressDestinationId') === null ? {} : { addressDestinationId: f.get('addressDestinationId') }), purpose: f.text('purpose', 'Purpose'),
      documentVersionId: f.text('documentVersionId', 'Document version'), ...(f.optional('jobId') === null ? {} : { jobId: f.get('jobId') }),
    }),
  },
  {
    kind: 'communication.delivery.update', title: 'Update communication delivery', group: 'Servicing',
    subjects: [{ key: 'job', kind: 'communication-job', label: 'Communication job' }],
    fields: [
      sel('action', 'Action', fixed([['accept', 'Accept'], ['deliver', 'Deliver'], ['bounce', 'Bounce'], ['cancel', 'Cancel']]), { required: true }),
      text('detail', 'Detail', { required: true }),
    ],
    extraHidden: (_env, resolved) => ({ jobState: needSubject(resolved,'job').state ?? 'queued' }),
    build: (f, s) => ({
      kind: 'communication.delivery.update', jobId: needSubject(s,'job').id,
      expectedState: (f.get('h_jobState') || needSubject(s,'job').state || 'queued') as 'queued' | 'accepted',
      action: f.text('action', 'Action') as 'accept' | 'deliver' | 'bounce' | 'cancel',
      detail: f.text('detail', 'Detail'),
    }),
  },
  // ── Approvals ────────────────────────────────────────────────────────────
  {
    kind: 'approval.decide', title: 'Decide approval request', group: 'Approvals',
    subjects: [{ key: 'approval', kind: 'approval', label: 'Approval request' }],
    fields: [
      sel('decision', 'Decision', fixed([['approve', 'Approve'], ['deny', 'Deny']]), { required: true }),
      text('reason', 'Reason', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'approval.decide', approvalId: needSubject(s,'approval').id, expectedFingerprint: need(needSubject(s,'approval').fingerprint, 's_approval', 'Approval fingerprint'),
      decision: f.text('decision', 'Decision') as 'approve' | 'deny', reason: f.text('reason', 'Reason'),
    }),
  },
  // ── Member lifecycle (finance) ───────────────────────────────────────────
  {
    kind: 'member.merge', title: 'Merge member records', group: 'Membership', approval: true,
    subjects: [{ key: 'plan', kind: 'merge-plan', label: 'Reviewed merge plan' }],
    fields: [approvalField],
    extraHidden: (env, resolved) => {
      const plan = subj(resolved, 'plan');
      if (plan === undefined) return {};
      const sourceId = str(plan.data.sourceMemberId ?? '');
      const targetId = str(plan.data.targetMemberId ?? '');
      const versions = read(env, (database) => ({
        source: (database.prepare('SELECT version FROM members WHERE dataset_id=? AND id=?').get(env.context.binding.datasetId, sourceId))?.version,
        target: (database.prepare('SELECT version FROM members WHERE dataset_id=? AND id=?').get(env.context.binding.datasetId, targetId))?.version,
        accounts: (database.prepare('SELECT id FROM accounts WHERE dataset_id=? AND member_id=? ORDER BY id').all(env.context.binding.datasetId, sourceId) as { id: string }[]).map((item) => item.id),
      }));
      if (isRejected(versions) || versions.source === undefined || versions.target === undefined) return {};
      return {
        sourceMemberId: sourceId, targetMemberId: targetId,
        sourceVersion: str(versions.source), targetVersion: str(versions.target),
        relationshipAccounts: versions.accounts.join(','),
      };
    },
    build: (f, s) => ({
      kind: 'member.merge', mergePlanId: needSubject(s,'plan').id,
      sourceMemberId: f.text('h_sourceMemberId', 'Source member'), targetMemberId: f.text('h_targetMemberId', 'Surviving member'),
      expectedSourceVersion: need(f.int('h_sourceVersion', 'Source version'), 'h_sourceVersion', 'Source version'),
      expectedTargetVersion: need(f.int('h_targetVersion', 'Survivor version'), 'h_targetVersion', 'Survivor version'),
      relationshipAccountIds: f.get('h_relationshipAccounts').split(',').filter((item) => item !== ''),
      expectedInventoryFingerprint: need(needSubject(s,'plan').fingerprint, 's_plan', 'Plan fingerprint'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'member.deceased.record', title: 'Record deceased member', group: 'Membership', approval: true,
    subjects: [memberSubject],
    fields: [
      sel('evidenceId', 'Verified evidence', memberEvidence, { required: true }),
      instant('effectiveDate', 'Effective at', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'member.deceased.record', memberId: needSubject(s,'member').id, expectedVersion: need(needSubject(s,'member').version, 's_member', 'Member version'),
      evidenceId: f.text('evidenceId', 'Verified evidence'), effectiveDate: need(f.instant('effectiveDate', 'Effective at'), 'effectiveDate', 'Effective at'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'member.beneficial_owners.update', title: 'Update beneficial owners', group: 'Membership', approval: true,
    subjects: [orgSubject],
    fields: [
      instant('effectiveDate', 'Effective at', { required: true }),
      text('owner1Member', 'Owner 1 member number', { required: true }),
      integer('owner1Bps', 'Owner 1 basis points', { required: true }),
      flag('owner1Control', 'Owner 1 is control person'),
      text('owner1EvidenceRef', 'Owner 1 evidence reference', { required: true }),
      text('owner2Member', 'Owner 2 member number', { required: false }),
      integer('owner2Bps', 'Owner 2 basis points', { required: false }),
      flag('owner2Control', 'Owner 2 is control person'),
      text('owner2EvidenceRef', 'Owner 2 evidence reference', { required: false }),
      text('owner3Member', 'Owner 3 member number', { required: false }),
      integer('owner3Bps', 'Owner 3 basis points', { required: false }),
      flag('owner3Control', 'Owner 3 is control person'),
      text('owner3EvidenceRef', 'Owner 3 evidence reference', { required: false }),
      approvalField,
    ],
    build: (f, s, env) => {
      const owners = [1, 2, 3].flatMap((index) => {
        const memberNumber = f.get(`owner${index}Member`);
        if (memberNumber === '') return [];
        const resolver = SUBJECT_RESOLVERS['member'];
        if (resolver === undefined) fail(`owner${index}Member`, 'Member resolution is unavailable.');
        const resolved = resolver.resolve(env, {}, memberNumber);
        if (isRejected(resolved)) fail(`owner${index}Member`, resolved.message);
        const memberId = resolved.id;
        const evidenceList = read(env, (database) =>
          database.prepare('SELECT id,source_reference AS reference FROM identity_evidence WHERE dataset_id=? AND party_id=?').all(
            env.context.binding.datasetId, resolved.partyId ?? '') as { id: string; reference: string }[]);
        if (isRejected(evidenceList)) fail(`owner${index}EvidenceRef`, 'Evidence could not be listed.');
        const reference = f.get(`owner${index}EvidenceRef`);
        const evidence = (evidenceList as { id: string; reference: string }[]).find((item) => item.reference === reference || item.id === reference);
        if (evidence === undefined) fail(`owner${index}EvidenceRef`, `No evidence "${reference}" for owner ${memberNumber}.`);
        return [{
          memberId,
          ownershipBps: need(f.int(`owner${index}Bps`, `Owner ${index} basis points`), `owner${index}Bps`, 'Basis points'),
          isControlPerson: f.bool(`owner${index}Control`),
          evidenceId: evidence.id,
        }];
      });
      if (owners.length === 0) fail('owner1Member', 'At least one owner is required.');
      return {
        kind: 'member.beneficial_owners.update', organizationMemberId: needSubject(s,'member').id,
        expectedVersion: need(needSubject(s,'member').version, 's_member', 'Member version'), owners,
        effectiveDate: need(f.instant('effectiveDate', 'Effective at'), 'effectiveDate', 'Effective at'),
        approvalId: f.text('approvalId', 'Approval'),
      };
    },
  },
  {
    kind: 'member.tax_classification.update', title: 'Update tax classification', group: 'Membership', approval: true,
    subjects: [memberSubject],
    fields: [
      sel('classification', 'Classification', fixed([['individual', 'Individual'], ['organization', 'Organization'], ['tax-exempt', 'Tax exempt'], ['non-resident', 'Non-resident']]), { required: true }),
      integer('effectiveYear', 'Effective year', { required: true }),
      sel('evidenceId', 'Identity evidence', memberEvidence, { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'member.tax_classification.update', memberId: needSubject(s,'member').id, expectedVersion: need(needSubject(s,'member').version, 's_member', 'Member version'),
      classification: f.text('classification', 'Classification'), effectiveYear: need(f.int('effectiveYear', 'Effective year'), 'effectiveYear', 'Effective year'),
      evidenceId: f.text('evidenceId', 'Identity evidence'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  // ── Account administration ───────────────────────────────────────────────
  {
    kind: 'account.product.convert', title: 'Convert account product', group: 'Accounts', approval: true,
    subjects: [accountSubject],
    fields: [
      sel('targetProductId', 'Target product', (env) => pickers.products(env, 'deposit'), { required: true }),
      date('effectiveDate', 'Effective date', { required: true }),
      flag('feeDisclosureAccepted', 'Fee disclosure accepted'),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'account.product.convert', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      targetProductId: f.text('targetProductId', 'Target product'), effectiveDate: need(f.date('effectiveDate', 'Effective date'), 'effectiveDate', 'Effective date'),
      feeDisclosureAccepted: f.bool('feeDisclosureAccepted'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'account.owner.add', title: 'Add account owner', group: 'Accounts', approval: true,
    subjects: [accountSubject, { key: 'owner', kind: 'member', label: 'New owner member' }],
    fields: [
      sel('role', 'Role', fixed([['owner', 'Owner'], ['joint-owner', 'Joint owner']]), { required: true }),
      date('effectiveDate', 'Effective date', { required: true }),
      sel('identityEvidenceId', 'Owner identity evidence', (env, s) => pickers.evidence(env, needSubject(s,'owner').id), { required: true }),
      sel('consentId', 'Ownership consent', (env, s) => pickers.consents(env, needSubject(s,'owner').id), { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'account.owner.add', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      memberId: needSubject(s,'owner').id, role: f.text('role', 'Role') as 'owner' | 'joint-owner',
      effectiveDate: need(f.date('effectiveDate', 'Effective date'), 'effectiveDate', 'Effective date'),
      identityEvidenceId: f.text('identityEvidenceId', 'Owner identity evidence'), consentId: f.text('consentId', 'Ownership consent'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'account.signer.remove', title: 'Remove account signer', group: 'Accounts', approval: true,
    subjects: [accountSubject],
    fields: [
      sel('signerMemberId', 'Signer to remove', (env, s) => {
        const result = read(env, (database) => database.prepare(
          `SELECT DISTINCT m.id,m.member_number,p.display_name FROM members m JOIN parties p ON p.dataset_id=m.dataset_id AND p.id=m.party_id
           JOIN account_parties ap ON ap.dataset_id=p.dataset_id AND ap.party_id=p.id AND ap.role='signer' AND ap.ends_at IS NULL
           WHERE m.dataset_id=? AND ap.account_id=? ORDER BY m.member_number`,
        ).all(env.context.binding.datasetId, needSubject(s,'account').id) as { id: string; member_number: string; display_name: string }[]);
        if (isRejected(result)) return result;
        return result.map((item) => ({ value: item.id, label: `${item.member_number} · ${item.display_name}` }));
      }, { required: true }),
      instant('effectiveAt', 'Effective at', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'account.signer.remove', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      signerMemberId: f.text('signerMemberId', 'Signer to remove'), effectiveAt: need(f.instant('effectiveAt', 'Effective at'), 'effectiveAt', 'Effective at'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'account.overdraft_limit.update', title: 'Update overdraft facility', group: 'Accounts', approval: true,
    subjects: [accountSubject, { key: 'facility', kind: 'facility', label: 'Facility (optional for first grant)' }],
    fields: [
      money('limit', 'Facility limit'),
      date('effectiveDate', 'Effective date', { required: true }),
      instant('expiresAt', 'Expires at', { required: false }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'account.overdraft_limit.update', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      expectedFacilityFingerprint: subj(s,'facility')?.fingerprint ?? null,
      limit: need(f.money('limit', 'Facility limit'), 'limit', 'Facility limit'),
      effectiveDate: need(f.date('effectiveDate', 'Effective date'), 'effectiveDate', 'Effective date'),
      expiresAt: f.instant('expiresAt', 'Expires at', false) ?? null,
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'account.hold.place', title: 'Place account hold', group: 'Accounts',
    subjects: [accountSubject],
    fields: [
      money('amount', 'Hold amount'),
      text('reason', 'Reason', { required: true }),
      instant('expiresAt', 'Expires at', { required: true }),
      text('releaseAuthority', 'Release authority', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'account.hold.place', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      amount: need(f.money('amount', 'Hold amount'), 'amount', 'Hold amount'), reason: f.text('reason', 'Reason'),
      expiresAt: need(f.instant('expiresAt', 'Expires at'), 'expiresAt', 'Expires at'), releaseAuthority: f.text('releaseAuthority', 'Release authority'),
    }),
  },
  {
    kind: 'account.hold.release', title: 'Release account hold', group: 'Accounts',
    subjects: [accountSubject, { key: 'hold', kind: 'hold', label: 'Hold' }],
    fields: [
      decimal('amountMinorUnits', 'Amount to release (minor units)'),
      text('releaseAuthority', 'Release authority', { required: true }),
      text('evidenceReference', 'Evidence reference', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'account.hold.release', holdId: needSubject(s,'hold').id, expectedFingerprint: need(needSubject(s,'hold').fingerprint, 's_hold', 'Hold fingerprint'),
      amountMinorUnits: f.decimal('amountMinorUnits', 'Amount to release'), releaseAuthority: f.text('releaseAuthority', 'Release authority'),
      evidenceReference: f.text('evidenceReference', 'Evidence reference'),
    }),
  },
  {
    kind: 'account.restriction.apply', title: 'Apply account restriction', group: 'Accounts', approval: true,
    subjects: [accountSubject],
    fields: [
      sel('restrictionType', 'Restriction type', fixed([['debit-block', 'Debit block'], ['credit-block', 'Credit block'], ['full-block', 'Full block'], ['closure-pending', 'Closure pending']]), { required: true }),
      text('reason', 'Reason', { required: true }),
      text('authority', 'Authority', { required: true }),
      sel('caseId', 'Governing case', (env, s) => pickers.cases(env, needSubject(s,'account').memberId), { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'account.restriction.apply', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      restrictionType: f.text('restrictionType', 'Restriction type') as never, reason: f.text('reason', 'Reason'),
      authority: f.text('authority', 'Authority'), caseId: f.text('caseId', 'Governing case'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'account.restriction.release', title: 'Release account restriction', group: 'Accounts', approval: true,
    subjects: [accountSubject, { key: 'restriction', kind: 'restriction', label: 'Restriction' }],
    fields: [
      sel('clearanceEvidenceId', 'Clearance evidence', memberEvidence, { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'account.restriction.release', restrictionId: needSubject(s,'restriction').id, expectedFingerprint: need(needSubject(s,'restriction').fingerprint, 's_restriction', 'Restriction fingerprint'),
      clearanceEvidenceId: f.text('clearanceEvidenceId', 'Clearance evidence'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  // ── Fees and corrections ─────────────────────────────────────────────────
  {
    kind: 'fee.assess', title: 'Assess fee', group: 'Fees',
    subjects: [accountSubject],
    fields: [
      text('feeCode', 'Fee code', { required: true }),
      money('amount', 'Fee amount'),
      text('basis', 'Basis', { required: true }),
      sel('policyVersionId', 'Fee policy', (env) => pickers.policyVersions(env), { required: true }),
    ],
    build: (f, s) => ({
      kind: 'fee.assess', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      feeCode: f.text('feeCode', 'Fee code'), amount: need(f.money('amount', 'Fee amount'), 'amount', 'Fee amount'),
      basis: f.text('basis', 'Basis'), policyVersionId: f.text('policyVersionId', 'Fee policy'),
    }),
  },
  {
    kind: 'fee.waiver.create', title: 'Create fee waiver', group: 'Fees', approval: true,
    subjects: [accountSubject],
    fields: [
      text('feeCode', 'Fee code', { required: true }),
      date('validFrom', 'Valid from', { required: true }),
      date('validThrough', 'Valid through', { required: true }),
      money('amountLimit', 'Amount limit'),
      integer('maxOccurrences', 'Maximum occurrences', { required: true }),
      text('reason', 'Reason', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'fee.waiver.create', accountId: needSubject(s,'account').id, feeCode: f.text('feeCode', 'Fee code'),
      validFrom: need(f.date('validFrom', 'Valid from'), 'validFrom', 'Valid from'), validThrough: need(f.date('validThrough', 'Valid through'), 'validThrough', 'Valid through'),
      amountLimit: need(f.money('amountLimit', 'Amount limit'), 'amountLimit', 'Amount limit'),
      maxOccurrences: need(f.int('maxOccurrences', 'Maximum occurrences'), 'maxOccurrences', 'Maximum occurrences'),
      reason: f.text('reason', 'Reason'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'fee.refund', title: 'Refund fee', group: 'Fees',
    subjects: [accountSubject, { key: 'fee', kind: 'fee', label: 'Fee' }],
    fields: [money('amount', 'Refund amount'), text('reason', 'Reason', { required: true })],
    build: (f, s) => ({
      kind: 'fee.refund', feeId: needSubject(s,'fee').id, expectedFingerprint: need(needSubject(s,'fee').fingerprint, 's_fee', 'Fee fingerprint'),
      amount: need(f.money('amount', 'Refund amount'), 'amount', 'Refund amount'), reason: f.text('reason', 'Reason'),
    }),
  },
  {
    kind: 'cash.deposit.reverse', title: 'Reverse cash deposit', group: 'Corrections', approval: true,
    subjects: [accountSubject, { key: 'journal', kind: 'journal', label: 'Deposit posting' }],
    fields: [
      sel('correctionEvidenceId', 'Correction evidence', memberEvidence, { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'cash.deposit.reverse', journalId: needSubject(s,'journal').id, expectedFingerprint: need(needSubject(s,'journal').fingerprint, 's_journal', 'Journal fingerprint'),
      correctionEvidenceId: f.text('correctionEvidenceId', 'Correction evidence'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'cash.withdrawal.reverse', title: 'Reverse cash withdrawal', group: 'Corrections', approval: true,
    subjects: [accountSubject, { key: 'journal', kind: 'journal', label: 'Withdrawal posting' }],
    fields: [text('reason', 'Reason', { required: true }), approvalField],
    build: (f, s) => ({
      kind: 'cash.withdrawal.reverse', journalId: needSubject(s,'journal').id, expectedFingerprint: need(needSubject(s,'journal').fingerprint, 's_journal', 'Journal fingerprint'),
      reason: f.text('reason', 'Reason'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'transfer.internal.reverse', title: 'Reverse internal transfer', group: 'Corrections', approval: true,
    subjects: [{ key: 'transfer', kind: 'transfer', label: 'Transfer posting' }],
    fields: [money('amount', 'Reversal amount'), text('reason', 'Reason', { required: true }), approvalField],
    build: (f, s) => ({
      kind: 'transfer.internal.reverse', transferJournalId: needSubject(s,'transfer').id, expectedFingerprint: need(needSubject(s,'transfer').fingerprint, 's_transfer', 'Transfer fingerprint'),
      amount: need(f.money('amount', 'Reversal amount'), 'amount', 'Reversal amount'), reason: f.text('reason', 'Reason'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'interest.adjust', title: 'Adjust interest calculation', group: 'Corrections', approval: true,
    subjects: [accountSubject, { key: 'calculation', kind: 'interest-calculation', label: 'Interest calculation' }],
    fields: [money('approvedDelta', 'Approved delta'), approvalField],
    build: (f, s) => ({
      kind: 'interest.adjust', accountId: needSubject(s,'account').id, calculationId: needSubject(s,'calculation').id,
      expectedFingerprint: need(needSubject(s,'calculation').fingerprint, 's_calculation', 'Calculation fingerprint'),
      approvedDelta: need(f.money('approvedDelta', 'Approved delta'), 'approvedDelta', 'Approved delta'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'transaction.effective_date.correct', title: 'Correct effective date', group: 'Corrections', approval: true,
    subjects: [accountSubject, { key: 'journal', kind: 'journal', label: 'Transaction posting' }],
    fields: [
      date('correctedDate', 'Corrected date', { required: true }),
      sel('policyVersionId', 'Correction policy', (env) => pickers.policyVersions(env), { required: true }),
      text('reason', 'Reason', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'transaction.effective_date.correct', journalId: needSubject(s,'journal').id, expectedFingerprint: need(needSubject(s,'journal').fingerprint, 's_journal', 'Journal fingerprint'),
      correctedDate: need(f.date('correctedDate', 'Corrected date'), 'correctedDate', 'Corrected date'),
      policyVersionId: f.text('policyVersionId', 'Correction policy'), reason: f.text('reason', 'Reason'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'transaction.description.update', title: 'Amend transaction description', group: 'Corrections',
    subjects: [accountSubject, { key: 'journal', kind: 'journal', label: 'Transaction posting' }],
    fields: [text('description', 'New description', { required: true })],
    build: (f, s) => ({
      kind: 'transaction.description.update', journalId: needSubject(s,'journal').id, expectedFingerprint: need(needSubject(s,'journal').fingerprint, 's_journal', 'Journal fingerprint'),
      description: f.text('description', 'New description'),
    }),
  },
  // ── Beneficiaries and payments ───────────────────────────────────────────
  {
    kind: 'beneficiary.create', title: 'Register beneficiary', group: 'Payments',
    subjects: [memberSubject],
    fields: [
      text('displayName', 'Display name', { required: true }),
      text('routingKind', 'Routing kind', { required: true }),
      text('maskedDestination', 'Masked destination', { required: true }),
      text('simulatedToken', 'Simulated token', { required: true }),
      strings('allowedRails', 'Allowed rails (comma-separated)'),
    ],
    build: (f, s) => ({
      kind: 'beneficiary.create', memberId: needSubject(s,'member').id, expectedMemberVersion: need(needSubject(s,'member').version, 's_member', 'Member version'),
      displayName: f.text('displayName', 'Display name'), routingKind: f.text('routingKind', 'Routing kind'),
      maskedDestination: f.text('maskedDestination', 'Masked destination'), simulatedToken: f.text('simulatedToken', 'Simulated token'),
      allowedRails: f.strings('allowedRails'),
    }),
  },
  {
    kind: 'beneficiary.verify', title: 'Verify beneficiary route', group: 'Payments', approval: true,
    subjects: [memberSubject, { key: 'beneficiary', kind: 'beneficiary', label: 'Beneficiary' }, { key: 'route', kind: 'beneficiary-route', label: 'Route' }],
    fields: [sel('evidenceId', 'Verification evidence', memberEvidence, { required: true }), approvalField],
    build: (f, s) => ({
      kind: 'beneficiary.verify', beneficiaryId: needSubject(s,'beneficiary').id, routeId: needSubject(s,'route').id,
      expectedFingerprint: need(needSubject(s,'route').fingerprint, 's_route', 'Route fingerprint'),
      evidenceId: f.text('evidenceId', 'Verification evidence'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'beneficiary.routing.update', title: 'Update beneficiary routing', group: 'Payments', approval: true,
    subjects: [memberSubject, { key: 'beneficiary', kind: 'beneficiary', label: 'Beneficiary' }, { key: 'route', kind: 'beneficiary-route', label: 'Route' }],
    fields: [
      text('routingKind', 'Routing kind', { required: true }),
      text('maskedDestination', 'Masked destination', { required: true }),
      text('simulatedToken', 'Simulated token', { required: true }),
      date('effectiveDate', 'Effective date', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'beneficiary.routing.update', beneficiaryId: needSubject(s,'beneficiary').id, expectedRouteFingerprint: need(needSubject(s,'route').fingerprint, 's_route', 'Route fingerprint'),
      routingKind: f.text('routingKind', 'Routing kind'), maskedDestination: f.text('maskedDestination', 'Masked destination'),
      simulatedToken: f.text('simulatedToken', 'Simulated token'), effectiveDate: need(f.date('effectiveDate', 'Effective date'), 'effectiveDate', 'Effective date'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'beneficiary.retire', title: 'Retire beneficiary', group: 'Payments',
    subjects: [memberSubject, { key: 'beneficiary', kind: 'beneficiary', label: 'Beneficiary' }],
    fields: [
      sel('dependentDisposition', 'Dependent disposition', fixed([['reject-if-active', 'Reject if dependents active'], ['cancel-drafts', 'Cancel draft dependents']]), { required: true }),
      text('reason', 'Reason', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'beneficiary.retire', beneficiaryId: needSubject(s,'beneficiary').id, expectedFingerprint: need(needSubject(s,'beneficiary').fingerprint, 's_beneficiary', 'Beneficiary fingerprint'),
      dependentDisposition: f.text('dependentDisposition', 'Dependent disposition') as 'reject-if-active' | 'cancel-drafts', reason: f.text('reason', 'Reason'),
    }),
  },
  {
    kind: 'payment.create', title: 'Create payment', group: 'Payments',
    subjects: [
      { key: 'source', kind: 'account', label: 'Source account' },
      { key: 'member', kind: 'member', label: 'Beneficiary owner' },
      { key: 'beneficiary', kind: 'beneficiary', label: 'Beneficiary' },
      { key: 'route', kind: 'beneficiary-route', label: 'Route' },
    ],
    fields: [
      money('amount', 'Amount'),
      text('rail', 'Payment rail', { required: true }),
      date('requestedDate', 'Requested date', { required: true }),
      text('calendarVersion', 'Calendar version', { required: true }),
      instant('cutoffAt', 'Cutoff at', { required: true }),
      text('reference', 'Payment reference', { required: true, default: () => generatedReference('PMT') }),
      sel('targetState', 'Target state', fixed([['draft', 'Draft'], ['pending-approval', 'Pending approval']]), { required: true }),
    ],
    build: (f, s) => ({
      kind: 'payment.create', sourceAccountId: needSubject(s,'source').id, expectedSourceVersion: need(needSubject(s,'source').version, 's_source', 'Source version'),
      beneficiaryRouteId: needSubject(s,'route').id, expectedRouteFingerprint: need(needSubject(s,'route').fingerprint, 's_route', 'Route fingerprint'),
      amount: need(f.money('amount', 'Amount'), 'amount', 'Amount'), rail: f.text('rail', 'Payment rail'),
      requestedDate: need(f.date('requestedDate', 'Requested date'), 'requestedDate', 'Requested date'),
      calendarVersion: f.text('calendarVersion', 'Calendar version'), cutoffAt: need(f.instant('cutoffAt', 'Cutoff at'), 'cutoffAt', 'Cutoff at'),
      reference: f.text('reference', 'Payment reference'), targetState: f.text('targetState', 'Target state') as 'draft' | 'pending-approval',
    }),
  },
  {
    kind: 'payment.submit', title: 'Submit payment', group: 'Payments',
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    fields: [],
    build: (_f, s) => ({ kind: 'payment.submit', paymentId: needSubject(s,'payment').id, expectedVersion: need(needSubject(s,'payment').version, 's_payment', 'Payment version') }),
  },
  {
    kind: 'payment.approve_release', title: 'Approve payment release', group: 'Payments', approval: true,
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    fields: [
      date('requestedDate', 'Requested date', { required: true }),
      text('calendarVersion', 'Calendar version', { required: true }),
      instant('cutoffAt', 'Cutoff at', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'payment.approve_release', paymentId: needSubject(s,'payment').id, expectedVersion: need(needSubject(s,'payment').version, 's_payment', 'Payment version'),
      requestedDate: need(f.date('requestedDate', 'Requested date'), 'requestedDate', 'Requested date'),
      calendarVersion: f.text('calendarVersion', 'Calendar version'), cutoffAt: need(f.instant('cutoffAt', 'Cutoff at'), 'cutoffAt', 'Cutoff at'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'payment.settle', title: 'Settle payment', group: 'Payments',
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    fields: [text('settlementReference', 'Settlement reference', { required: true })],
    build: (f, s) => ({ kind: 'payment.settle', paymentId: needSubject(s,'payment').id, expectedVersion: need(needSubject(s,'payment').version, 's_payment', 'Payment version'), settlementReference: f.text('settlementReference', 'Settlement reference') }),
  },
  {
    kind: 'payment.cancel', title: 'Cancel payment', group: 'Payments',
    subjects: [{ key: 'payment', kind: 'payment', label: 'Payment' }],
    fields: [text('reason', 'Reason', { required: true })],
    build: (f, s) => ({ kind: 'payment.cancel', paymentId: needSubject(s,'payment').id, expectedVersion: need(needSubject(s,'payment').version, 's_payment', 'Payment version'), reason: f.text('reason', 'Reason') }),
  },
  {
    kind: 'payment.schedule.create', title: 'Create payment schedule', group: 'Payments', approval: true,
    subjects: [
      { key: 'source', kind: 'account', label: 'Source account' },
      { key: 'member', kind: 'member', label: 'Beneficiary owner' },
      { key: 'beneficiary', kind: 'beneficiary', label: 'Beneficiary' },
      { key: 'route', kind: 'beneficiary-route', label: 'Route' },
    ],
    fields: [
      money('amount', 'Amount'),
      sel('frequency', 'Frequency', fixed([['weekly', 'Weekly'], ['biweekly', 'Biweekly'], ['monthly', 'Monthly'], ['quarterly', 'Quarterly'], ['annually', 'Annually']]), { required: true }),
      integer('interval', 'Interval', { required: true }),
      date('startDate', 'Start date', { required: true }),
      date('endDate', 'End date', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'payment.schedule.create', sourceAccountId: needSubject(s,'source').id, expectedSourceVersion: need(needSubject(s,'source').version, 's_source', 'Source version'),
      beneficiaryRouteId: needSubject(s,'route').id, expectedRouteFingerprint: need(needSubject(s,'route').fingerprint, 's_route', 'Route fingerprint'),
      amount: need(f.money('amount', 'Amount'), 'amount', 'Amount'),
      frequency: f.text('frequency', 'Frequency') as never, interval: need(f.int('interval', 'Interval'), 'interval', 'Interval'),
      startDate: need(f.date('startDate', 'Start date'), 'startDate', 'Start date'), endDate: need(f.date('endDate', 'End date'), 'endDate', 'End date'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'payment.schedule.materialize', title: 'Materialize scheduled occurrence', group: 'Payments',
    subjects: [{ key: 'schedule', kind: 'schedule', label: 'Payment schedule' }, { key: 'occurrence', kind: 'occurrence', label: 'Occurrence' }],
    fields: [],
    build: (_f, s) => ({ kind: 'payment.schedule.materialize', occurrenceId: needSubject(s,'occurrence').id, expectedFingerprint: need(needSubject(s,'occurrence').fingerprint, 's_occurrence', 'Occurrence fingerprint') }),
  },
  {
    kind: 'payment.occurrence.amend', title: 'Amend scheduled occurrence', group: 'Payments',
    subjects: [{ key: 'schedule', kind: 'schedule', label: 'Payment schedule' }, { key: 'occurrence', kind: 'occurrence', label: 'Occurrence' }],
    fields: [money('newAmount', 'New amount'), date('newDate', 'New date', { required: true })],
    build: (f, s) => ({
      kind: 'payment.occurrence.amend', occurrenceId: needSubject(s,'occurrence').id, expectedFingerprint: need(needSubject(s,'occurrence').fingerprint, 's_occurrence', 'Occurrence fingerprint'),
      newAmount: need(f.money('newAmount', 'New amount'), 'newAmount', 'New amount'), newDate: need(f.date('newDate', 'New date'), 'newDate', 'New date'),
    }),
  },
  {
    kind: 'payment.return.resolve', title: 'Resolve payment return', group: 'Payments', approval: true,
    subjects: [{ key: 'return', kind: 'payment-return', label: 'Payment return' }],
    fields: [
      sel('disposition', 'Disposition', fixed([['credit-source', 'Credit source account'], ['investigate', 'Investigate']]), { required: true }),
      approvalField,
    ],
    extraHidden: (_env, resolved) => ({ paymentId: str(needSubject(resolved,'return').data.paymentId ?? needSubject(resolved,'return').data.payment_id) }),
    build: (f, s) => ({
      kind: 'payment.return.resolve', returnId: needSubject(s,'return').id, expectedFingerprint: need(needSubject(s,'return').fingerprint, 's_return', 'Return fingerprint'),
      paymentId: f.get('h_paymentId'), disposition: f.text('disposition', 'Disposition') as 'credit-source' | 'investigate',
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'payment.schedule.end', title: 'End payment schedule', group: 'Payments', approval: true,
    subjects: [{ key: 'schedule', kind: 'schedule', label: 'Payment schedule' }],
    fields: [
      date('endFromDate', 'End from date', { required: true }),
      sel('pendingDisposition', 'Pending disposition', fixed([['cancel-planned', 'Cancel planned occurrences'], ['retain-released', 'Retain released occurrences']]), { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'payment.schedule.end', scheduleId: needSubject(s,'schedule').id, expectedFingerprint: need(needSubject(s,'schedule').fingerprint, 's_schedule', 'Schedule fingerprint'),
      endFromDate: need(f.date('endFromDate', 'End from date'), 'endFromDate', 'End from date'),
      pendingDisposition: f.text('pendingDisposition', 'Pending disposition') as 'cancel-planned' | 'retain-released',
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  // ── Cards and disputes ───────────────────────────────────────────────────
  {
    kind: 'card.replace', title: 'Replace card', group: 'Cards',
    subjects: [accountSubject, { key: 'card', kind: 'card', label: 'Card' }],
    fields: [
      text('reason', 'Reason', { required: true }),
      sel('identityEvidenceId', 'Identity evidence', memberEvidence, { required: true }),
      sel('deliveryDestinationId', 'Delivery destination', (env, s) => pickers.addressDestinations(env, needSubject(s,'account').memberId ?? ''), { required: true }),
      sel('deliveryAddressId', 'Delivery address', (env, s) => pickers.partyAddresses(env, needSubject(s,'account').memberId ?? ''), { required: true }),
    ],
    build: (f, s) => ({
      kind: 'card.replace', cardId: needSubject(s,'card').id, expectedFingerprint: need(needSubject(s,'card').fingerprint, 's_card', 'Card fingerprint'),
      reason: f.text('reason', 'Reason'), identityEvidenceId: f.text('identityEvidenceId', 'Identity evidence'),
      deliveryDestinationId: f.text('deliveryDestinationId', 'Delivery destination'), deliveryAddressId: f.text('deliveryAddressId', 'Delivery address'),
    }),
  },
  {
    kind: 'card.lock.update', title: 'Update card lock', group: 'Cards',
    subjects: [accountSubject, { key: 'card', kind: 'card', label: 'Card' }],
    fields: [
      sel('requestedState', 'Requested state', fixed([['locked', 'Locked'], ['unlocked', 'Unlocked']]), { required: true }),
      text('authority', 'Authority', { required: true }),
    ],
    build: (f, s) => ({
      kind: 'card.lock.update', cardId: needSubject(s,'card').id, expectedFingerprint: need(needSubject(s,'card').fingerprint, 's_card', 'Card fingerprint'),
      requestedState: f.text('requestedState', 'Requested state') as 'locked' | 'unlocked', authority: f.text('authority', 'Authority'),
    }),
  },
  {
    kind: 'card.limit.update', title: 'Update card limit', group: 'Cards', approval: true,
    subjects: [accountSubject, { key: 'card', kind: 'card', label: 'Card' }],
    fields: [
      sel('limitKind', 'Limit kind', fixed([['atm-daily', 'ATM daily'], ['pos-daily', 'POS daily'], ['ecommerce-daily', 'E-commerce daily']]), { required: true }),
      money('amount', 'Limit amount'),
      instant('effectiveAt', 'Effective at', { required: true }),
      instant('expiresAt', 'Expires at', { required: false }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'card.limit.update', cardId: needSubject(s,'card').id, expectedFingerprint: need(needSubject(s,'card').fingerprint, 's_card', 'Card fingerprint'),
      limitKind: f.text('limitKind', 'Limit kind') as never, amount: need(f.money('amount', 'Limit amount'), 'amount', 'Limit amount'),
      effectiveAt: need(f.instant('effectiveAt', 'Effective at'), 'effectiveAt', 'Effective at'),
      expiresAt: f.instant('expiresAt', 'Expires at', false) ?? null, approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'dispute.open', title: 'Open card dispute', group: 'Cards',
    subjects: [accountSubject, { key: 'card', kind: 'card', label: 'Card' }, { key: 'cardTransaction', kind: 'card-transaction', label: 'Card transaction' }],
    fields: [
      text('reason', 'Reason', { required: true }),
      money('assertedAmount', 'Asserted amount'),
      multi('evidenceIds', 'Evidence documents', memberDocuments, { required: false }),
    ],
    build: (f, s) => ({
      kind: 'dispute.open', cardTransactionId: needSubject(s,'cardTransaction').id, expectedFingerprint: need(needSubject(s,'cardTransaction').fingerprint, 's_cardTransaction', 'Transaction fingerprint'),
      reason: f.text('reason', 'Reason'), assertedAmount: need(f.money('assertedAmount', 'Asserted amount'), 'assertedAmount', 'Asserted amount'),
      evidenceIds: f.list('evidenceIds'),
    }),
  },
  {
    kind: 'dispute.provisional_credit.issue', title: 'Issue provisional credit', group: 'Cards', approval: true,
    subjects: [{ key: 'dispute', kind: 'dispute', label: 'Dispute' }],
    fields: [money('amount', 'Credit amount'), approvalField],
    build: (f, s) => ({
      kind: 'dispute.provisional_credit.issue', disputeId: needSubject(s,'dispute').id, expectedFingerprint: need(needSubject(s,'dispute').fingerprint, 's_dispute', 'Dispute fingerprint'),
      amount: need(f.money('amount', 'Credit amount'), 'amount', 'Credit amount'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'dispute.evidence.submit', title: 'Submit dispute evidence', group: 'Cards', approval: true,
    subjects: [{ key: 'dispute', kind: 'dispute', label: 'Dispute' }],
    fields: [
      multi('documentVersionIds', 'Evidence documents', memberDocuments, { required: true }),
      instant('deadline', 'Deadline', { required: true }),
      text('recipient', 'Recipient', { required: true }),
      text('channel', 'Channel', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'dispute.evidence.submit', disputeId: needSubject(s,'dispute').id, expectedFingerprint: need(needSubject(s,'dispute').fingerprint, 's_dispute', 'Dispute fingerprint'),
      documentVersionIds: f.list('documentVersionIds'), deadline: need(f.instant('deadline', 'Deadline'), 'deadline', 'Deadline'),
      recipient: f.text('recipient', 'Recipient'), channel: f.text('channel', 'Channel'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'dispute.settle', title: 'Settle dispute', group: 'Cards', approval: true,
    subjects: [{ key: 'dispute', kind: 'dispute', label: 'Dispute' }],
    fields: [
      sel('decision', 'Decision', fixed([['approved', 'Approved'], ['denied', 'Denied']]), { required: true }),
      money('finalAmount', 'Final amount'),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'dispute.settle', disputeId: needSubject(s,'dispute').id, expectedFingerprint: need(needSubject(s,'dispute').fingerprint, 's_dispute', 'Dispute fingerprint'),
      decision: f.text('decision', 'Decision') as 'approved' | 'denied', finalAmount: need(f.money('finalAmount', 'Final amount'), 'finalAmount', 'Final amount'),
      approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  // ── Lending ──────────────────────────────────────────────────────────────
  {
    kind: 'loan.application.prepare', title: 'Prepare loan application', group: 'Lending',
    subjects: [memberSubject],
    fields: [
      sel('productId', 'Loan product', (env) => pickers.products(env, 'loan'), { required: true }),
      money('requestedAmount', 'Requested amount'),
      integer('termMonths', 'Term (months)', { required: true }),
      text('purpose', 'Purpose', { required: true }),
      multi('evidenceIds', 'Identity evidence', memberEvidence, { required: true }),
    ],
    build: (f, s) => ({
      kind: 'loan.application.prepare', memberId: needSubject(s,'member').id, expectedMemberVersion: need(needSubject(s,'member').version, 's_member', 'Member version'),
      productId: f.text('productId', 'Loan product'), requestedAmount: need(f.money('requestedAmount', 'Requested amount'), 'requestedAmount', 'Requested amount'),
      termMonths: need(f.int('termMonths', 'Term'), 'termMonths', 'Term'), purpose: f.text('purpose', 'Purpose'), evidenceIds: f.list('evidenceIds'),
    }),
  },
  {
    kind: 'loan.payment.allocate', title: 'Allocate loan payment', group: 'Lending',
    subjects: [accountSubject, { key: 'loan', kind: 'loan', label: 'Loan' }],
    fields: [
      sel('receivedFundsReference', 'Received funds', (env) => {
        const result = read(env, (database) => database.prepare('SELECT reference,state FROM received_funds WHERE dataset_id=? ORDER BY received_at DESC LIMIT 200').all(env.context.binding.datasetId) as { reference: string; state: string }[]);
        if (isRejected(result)) return result;
        return result.map((item) => ({ value: item.reference, label: `${item.reference} · ${item.state}` }));
      }, { required: true }),
      money('amount', 'Amount'),
      sel('allocationPolicy', 'Allocation policy', fixed([['fees-interest-principal', 'Fees, interest, principal'], ['fees-interest-principal-hold-remainder', 'Fees, interest, principal, hold remainder']]), { required: true }),
    ],
    build: (f, s) => ({
      kind: 'loan.payment.allocate', loanId: needSubject(s,'loan').id, expectedFingerprint: need(needSubject(s,'loan').fingerprint, 's_loan', 'Loan fingerprint'),
      receivedFundsReference: f.text('receivedFundsReference', 'Received funds'), amount: need(f.money('amount', 'Amount'), 'amount', 'Amount'),
      allocationPolicy: f.text('allocationPolicy', 'Allocation policy') as 'fees-interest-principal' | 'fees-interest-principal-hold-remainder',
    }),
  },
  {
    kind: 'loan.payoff.quote', title: 'Quote loan payoff', group: 'Lending',
    subjects: [accountSubject, { key: 'loan', kind: 'loan', label: 'Loan' }],
    fields: [
      date('payoffDate', 'Payoff date', { required: true }),
      sel('policyVersionId', 'Payoff policy', (env) => pickers.policyVersions(env), { required: true }),
    ],
    build: (f, s) => ({
      kind: 'loan.payoff.quote', loanId: needSubject(s,'loan').id, expectedFingerprint: need(needSubject(s,'loan').fingerprint, 's_loan', 'Loan fingerprint'),
      payoffDate: need(f.date('payoffDate', 'Payoff date'), 'payoffDate', 'Payoff date'), policyVersionId: f.text('policyVersionId', 'Payoff policy'),
    }),
  },
  {
    kind: 'loan.close', title: 'Close loan', group: 'Lending', approval: true,
    subjects: [accountSubject, { key: 'loan', kind: 'loan', label: 'Loan' }],
    fields: [sel('payoffEvidenceId', 'Payoff evidence', memberEvidence, { required: true }), approvalField],
    build: (f, s) => ({
      kind: 'loan.close', loanId: needSubject(s,'loan').id, expectedFingerprint: need(needSubject(s,'loan').fingerprint, 's_loan', 'Loan fingerprint'),
      payoffEvidenceId: f.text('payoffEvidenceId', 'Payoff evidence'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'document.loan_closure.issue', title: 'Issue loan closure document', group: 'Lending', approval: true,
    subjects: [accountSubject, { key: 'loan', kind: 'loan', label: 'Loan' }, { key: 'closure', kind: 'loan-closure', label: 'Closure record' }],
    fields: [
      sel('templateVersionId', 'Template version', (env, s) => pickers.documentVersions(env, needSubject(s,'account').memberId), { required: true }),
      sel('recipientPartyId', 'Recipient party', memberParties, { required: true }),
      sel('documentType', 'Document type', fixed([['loan-closure-confirmation', 'Loan closure confirmation'], ['simulated-lien-release', 'Simulated lien release']]), { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'document.loan_closure.issue', loanId: needSubject(s,'loan').id, expectedClosureFingerprint: need(needSubject(s,'closure').fingerprint, 's_closure', 'Closure fingerprint'),
      templateVersionId: f.text('templateVersionId', 'Template version'), recipientPartyId: f.text('recipientPartyId', 'Recipient party'),
      documentType: f.text('documentType', 'Document type') as 'loan-closure-confirmation' | 'simulated-lien-release', approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  // ── Reconciliation and batches ───────────────────────────────────────────
  {
    kind: 'reconciliation.suspense.investigate', title: 'Investigate suspense item', group: 'Reconciliation',
    subjects: [{ key: 'suspense', kind: 'suspense-item', label: 'Suspense item' }],
    fields: [
      strings('evidenceReferences', 'Evidence references (comma-separated)'),
      sel('proposedAccountId', 'Proposed account', (env) => [{ value: '', label: '— none —' }, ...(pickers.accounts(env) as Option[])], { required: false }),
    ],
    build: (f, s) => ({
      kind: 'reconciliation.suspense.investigate', suspenseId: needSubject(s,'suspense').id, expectedFingerprint: need(needSubject(s,'suspense').fingerprint, 's_suspense', 'Suspense fingerprint'),
      evidenceReferences: f.strings('evidenceReferences'), proposedAccountId: f.optional('proposedAccountId'),
    }),
  },
  {
    kind: 'reconciliation.suspense.clear', title: 'Clear suspense item', group: 'Reconciliation', approval: true,
    subjects: [{ key: 'suspense', kind: 'suspense-item', label: 'Suspense item' }],
    fields: [
      sel('destinationAccountId', 'Destination account', (env) => pickers.accounts(env), { required: true }),
      money('amount', 'Clearing amount'),
      text('evidenceReference', 'Evidence reference', { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'reconciliation.suspense.clear', suspenseId: needSubject(s,'suspense').id, expectedFingerprint: need(needSubject(s,'suspense').fingerprint, 's_suspense', 'Suspense fingerprint'),
      destinationAccountId: f.text('destinationAccountId', 'Destination account'), amount: need(f.money('amount', 'Clearing amount'), 'amount', 'Clearing amount'),
      evidenceReference: f.text('evidenceReference', 'Evidence reference'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'batch.import', title: 'Import maintenance batch', group: 'Batches',
    subjects: [memberSubject, { key: 'version', kind: 'document-version', label: 'Input document version' }],
    fields: [
      sel('batchKind', 'Batch kind', fixed([['contact-update', 'Contact update'], ['fee-refund', 'Fee refund']]), { required: true }),
      text('batchNumber', 'Batch number', { required: true, default: () => generatedReference('BCH') }),
      sel('currency', 'Currency', currencies, { required: false }),
    ],
    extraHidden: (_env, resolved) => ({ inputDigest: str(needSubject(resolved,'version').data.digest ?? '') }),
    build: (f, s) => ({
      kind: 'batch.import', documentVersionId: needSubject(s,'version').id, inputDigest: f.get('h_inputDigest'),
      batchNumber: f.text('batchNumber', 'Batch number'), batchKind: f.text('batchKind', 'Batch kind') as 'contact-update' | 'fee-refund',
      currency: f.optional('currency'),
    }),
  },
  {
    kind: 'batch.contacts.apply', title: 'Apply contact batch item', group: 'Batches', approval: true,
    subjects: [{ key: 'batch', kind: 'batch', label: 'Batch' }, { key: 'item', kind: 'batch-item', label: 'Batch item' }],
    fields: [
      sel('conflictPolicy', 'Conflict policy', fixed([['skip-stale', 'Skip stale items'], ['reject-all', 'Reject on conflict']]), { required: true }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'batch.contacts.apply', batchId: needSubject(s,'batch').id, itemId: needSubject(s,'item').id,
      expectedFingerprint: need(needSubject(s,'batch').fingerprint, 's_batch', 'Batch fingerprint'),
      conflictPolicy: f.text('conflictPolicy', 'Conflict policy') as 'skip-stale' | 'reject-all', approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'batch.fee_refunds.apply', title: 'Apply fee-refund batch item', group: 'Batches', approval: true,
    subjects: [{ key: 'batch', kind: 'batch', label: 'Batch' }, { key: 'item', kind: 'batch-item', label: 'Batch item' }],
    fields: [approvalField],
    build: (f, s) => ({
      kind: 'batch.fee_refunds.apply', batchId: needSubject(s,'batch').id, itemId: needSubject(s,'item').id,
      expectedFingerprint: need(needSubject(s,'batch').fingerprint, 's_batch', 'Batch fingerprint'), approvalId: f.text('approvalId', 'Approval'),
    }),
  },
  {
    kind: 'account.maturity.instruct', title: 'Record maturity instruction', group: 'Accounts', approval: true,
    subjects: [accountSubject, { key: 'instruction', kind: 'maturity-instruction', label: 'Current instruction (optional)' }],
    fields: [
      sel('disposition', 'Disposition', fixed([['renew', 'Renew'], ['transfer', 'Transfer proceeds'], ['hold', 'Hold in account']]), { required: true }),
      sel('destinationAccountId', 'Destination account', (env, s) => [{ value: '', label: '— none —' }, ...(pickers.accounts(env, needSubject(s,'account').memberId) as Option[])], { required: false }),
      integer('termMonths', 'Renewal term (months)', { required: false }),
      integer('approvedAnnualRateBps', 'Approved rate (bps)', { required: false }),
      approvalField,
    ],
    build: (f, s) => ({
      kind: 'account.maturity.instruct', accountId: needSubject(s,'account').id, expectedVersion: need(needSubject(s,'account').version, 's_account', 'Account version'),
      expectedInstructionFingerprint: subj(s,'instruction')?.fingerprint ?? null,
      disposition: f.text('disposition', 'Disposition') as 'renew' | 'transfer' | 'hold',
      destinationAccountId: f.optional('destinationAccountId'), termMonths: f.int('termMonths', 'Renewal term', false) ?? null,
      approvedAnnualRateBps: f.int('approvedAnnualRateBps', 'Approved rate', false) ?? null, approvalId: f.text('approvalId', 'Approval'),
    }),
  },
];

function savedSearchCommand(f: Form, subject: ResolvedSubject | null): ServiceCommand {
  const parseDefinition = (): { entity: 'members' | 'accounts' | 'cases'; filters: Record<string, string | boolean | string[]>; sort: { field: string; direction: 'asc' | 'desc' }[]; columns: string[]; maxResults?: number } | undefined => {
    const entity = f.get('entity');
    if (entity === '') return undefined;
    const filters: Record<string, string | boolean | string[]> = {};
    for (const line of f.get('filters').split('\n')) {
      const trimmed = line.trim();
      if (trimmed === '') continue;
      const [field, ...rest] = trimmed.split('=');
      if (field === undefined || rest.length === 0) fail('filters', 'Filters must be field=value lines.');
      const value = rest.join('=').trim();
      filters[field.trim()] = value === 'true' ? true : value === 'false' ? false : value.includes(',') ? value.split(',').map((item) => item.trim()) : value;
    }
    const sort = f.get('sort');
    const columns = f.strings('columns');
    const maxResults = f.int('maxResults', 'Maximum results', false);
    return {
      entity: entity as 'members' | 'accounts' | 'cases',
      filters,
      sort: sort === '' ? [] : [{ field: sort, direction: (f.get('direction') || 'asc') as 'asc' | 'desc' }],
      columns,
      ...(maxResults === undefined ? {} : { maxResults }),
    };
  };
  if (subject === null) {
    return {
      kind: 'search.saved.create',
      name: f.text('name', 'Search name'),
      visibility: f.text('visibility', 'Visibility') as 'private' | 'shared',
      definition: parseDefinition() as never,
    };
  }
  const patch: Record<string, unknown> = {};
  if (f.get('name') !== '') patch.name = f.get('name');
  if (f.get('visibility') !== '') patch.visibility = f.get('visibility');
  const definition = parseDefinition();
  if (definition !== undefined) patch.definition = definition;
  return { kind: 'search.saved.update', searchId: subject.id, expectedRevision: subject.fingerprint ?? '', ...patch };
}

function sqlOptionsFor(env: Env, sql: string, label: (row: Record<string, unknown>) => string, memberId: string): Option[] | Rejection {
  const result = read(env, (database) => database.prepare(sql).all(env.context.binding.datasetId, memberId) as Record<string, unknown>[]);
  if (isRejected(result)) return result;
  return result.map((item) => ({ value: str(item.id), label: label(item) }));
}

export function operationFor(kind: string): OperationSpec | undefined {
  return OPERATIONS.find((operation) => operation.kind === kind);
}

export function operationsByGroup(): { group: string; operations: OperationSpec[] }[] {
  const groups = new Map<string, OperationSpec[]>();
  for (const operation of OPERATIONS) {
    const list = groups.get(operation.group) ?? [];
    list.push(operation);
    groups.set(operation.group, list);
  }
  return [...groups.entries()].map(([group, operations]) => ({ group, operations }));
}

/** Builds the approval-request command offered on the review page of an approval-gated operation. */
export function approvalRequestCommand(
  _env: Env,
  target: ServiceCommand,
  checkerActorId: string,
  policyVersionId: string,
  expiresAt: string,
  amountLimit: Money | null,
): ServiceCommand {
  return {
    kind: 'approval.request',
    target: target as never,
    checkerActorId,
    policyVersionId,
    expiresAt,
    amountLimit,
  };
}

export function generatedReference(prefix: string): string {
  return `${prefix}-${randomBytes(4).toString('hex').toUpperCase()}`;
}

export function digestOf(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}
