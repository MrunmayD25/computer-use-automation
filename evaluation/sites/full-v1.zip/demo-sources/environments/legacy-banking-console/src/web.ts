import { fileURLToPath } from 'node:url';

import express, { type Express, type Request, type Response } from 'express';

import {
  accountDetail,
  accountTransactions,
  caseDetail,
  documentContent,
  exportStatement,
  listActivity,
  memberDetail,
  queryFinance,
  receiptByIdempotencyKey,
  receiptByNumber,
  retrieveHistoricalStatement,
  searchAccounts,
  searchCases,
  searchDocuments,
  searchMembers,
  statementPeriods,
  transactionsCsv,
  type AccountDetail,
  type CommandOutcome,
  type DocumentArtifact,
  type FinanceRecordKind,
  type MemberDetail,
  type OperationReview,
  type Receipt,
  type Rejection,
} from '@computer-use/financial-database/services';

import type { InstanceStore } from './instance-store.js';
import { Form, FormError, operationFor, operationsByGroup, type OperationSpec } from './operations.js';
import { read, isRejected, pickers, SUBJECT_RESOLVERS, type Env, type Resolved } from './prerequisites.js';
import { getProfile, type StructuralProfile } from './profiles.js';
import {
  basePath, field, form, link, linkCell, money, renderPage, renderShell, renderWorkspace,
  selectField, textCell,
  type Cell, type Field, type PageModel, type RenderContext, type Section,
} from './views.js';

interface UiOptions {
  store: InstanceStore;
  mainOrigin: () => string;
  frameOrigin: () => string;
  demoEntryPath: () => string;
}

interface RequestState {
  capability: string;
  profile: StructuralProfile;
  context: RenderContext;
  env: Env;
  instance: ReturnType<InstanceStore['byCapability']>;
}

const text = (value: unknown): string => (typeof value === 'string' ? value : typeof value === 'number' || typeof value === 'bigint' || typeof value === 'boolean' ? String(value) : '');

function routeParam(value: string | string[] | undefined): string {
  return typeof value === 'string' ? value : '';
}

function rejectionStatus(rejection: Rejection): number {
  return rejection.code === 'stale_version' ? 409 : rejection.code === 'not_authorized' ? 403 : rejection.code === 'not_found' ? 404 : 400;
}

function monthEndExclusive(period: string): string {
  const [year, month] = period.split('-').map(Number);
  if (year === undefined || month === undefined || Number.isNaN(year) || Number.isNaN(month)) return period;
  const next = month === 12 ? { year: year + 1, month: 1 } : { year, month: month + 1 };
  return `${next.year}-${String(next.month).padStart(2, '0')}-01`;
}

function describeOutcome(outcome: CommandOutcome): { status: string; receipt: Receipt | null; message: string } {
  switch (outcome.kind) {
    case 'committed': return { status: 'Committed', receipt: outcome.receipt, message: 'Operation committed and receipted.' };
    case 'duplicate': return { status: 'Duplicate', receipt: outcome.receipt, message: 'This operation was already posted; the existing receipt is shown.' };
    case 'unchanged': return { status: 'Unchanged', receipt: null, message: outcome.message };
    case 'rejected': return { status: `Rejected · ${outcome.code}`, receipt: null, message: outcome.message };
  }
}

export function configureUiApp(app: Express, options: UiOptions, rootRedirect: boolean): void {
  app.disable('x-powered-by');
  app.use('/assets', express.static(fileURLToPath(new URL('../public/', import.meta.url)), { fallthrough: false, maxAge: 0 }));
  app.use(express.urlencoded({ extended: false, limit: '256kb', parameterLimit: 200 }));

  app.use((_request, response, next) => {
    response.setHeader('cache-control', 'no-store');
    response.setHeader('x-content-type-options', 'nosniff');
    response.setHeader('referrer-policy', 'same-origin');
    response.setHeader(
      'content-security-policy',
      `default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-src ${options.mainOrigin()} ${options.frameOrigin()}; form-action 'self'; base-uri 'none'; object-src 'none'`,
    );
    next();
  });

  app.get('/favicon.ico', (_request, response) => response.status(204).end());
  if (rootRedirect) app.get('/', (_request, response) => response.redirect(302, options.demoEntryPath()));

  function requestState(request: Request, response: Response): RequestState | undefined {
    const capability = routeParam(request.params.capability);
    try {
      const { instance, context } = options.store.session(capability);
      const profile = getProfile(instance.profile);
      const institutionName = options.store.financial().read((database) => {
        const row = database.prepare('SELECT display_name AS name FROM institutions WHERE id=?').get(instance.binding.institutionId) as { name?: string } | undefined;
        return row?.name ?? instance.binding.institutionId;
      });
      return {
        capability,
        profile,
        instance,
        env: { store: options.store.financial(), context, actorNumber: instance.actorNumber, exportDestinations: options.store.exportDestinations() },
        context: {
          capability,
          mainOrigin: options.mainOrigin(),
          frameOrigin: options.frameOrigin(),
          profile,
          csrfToken: instance.csrfToken,
          documentId: Math.random().toString(16).slice(2, 18),
          institutionName,
          operator: instance.actorNumber,
          ...(typeof request.query.notice === 'string' ? { notice: request.query.notice } : {}),
          ...(typeof request.query.error === 'string' ? { error: request.query.error } : {}),
        },
      };
    } catch (error) {
      if (error instanceof Error && error.message === 'Unknown or expired UI capability.') {
        response.status(404).type('html').send('<!doctype html><title>Instance unavailable</title><h1>Instance unavailable</h1>');
        return undefined;
      }
      throw error;
    }
  }

  function mutationState(request: Request, response: Response): RequestState | undefined {
    const state = requestState(request, response);
    if (state === undefined) return undefined;
    const token = typeof request.body === 'object' && request.body !== null ? text((request.body as Record<string, unknown>).csrfToken) : '';
    const origin = request.headers.origin;
    if (token !== state.context.csrfToken || (origin !== undefined && origin !== options.mainOrigin() && origin !== options.frameOrigin())) {
      sendPage(response, state, { title: 'Unable to complete request', sections: [{ title: 'Application message', text: 'The form expired or came from an invalid page.', links: [link(state.context, 'Member Search', '/search')] }] }, 403);
      return undefined;
    }
    return state;
  }

  function sendPage(response: Response, state: RequestState, model: PageModel, status = 200): void {
    response.status(status).type('html').send(renderPage(model, state.context));
  }

  function sendRejection(response: Response, state: RequestState, rejection: Rejection): void {
    sendPage(response, state, {
      title: 'Unable to complete request',
      sections: [{ title: `Rejected · ${rejection.code}`, text: rejection.message, links: [link(state.context, 'Operations', '/operations'), link(state.context, 'Member Search', '/search')] }],
    }, rejectionStatus(rejection));
  }

  function sendError(response: Response, state: RequestState, message: string, status = 400): void {
    sendPage(response, state, { title: 'Unable to complete request', sections: [{ title: 'Application message', text: message, links: [link(state.context, 'Member Search', '/search')] }] }, status);
  }

  const memberUrl = (memberNumber: string): string => `/members/${encodeURIComponent(memberNumber)}`;
  const accountUrl = (accountNumber: string): string => `/accounts/${encodeURIComponent(accountNumber)}`;

  // ---------- shell and frame plumbing ----------

  app.get('/app/:capability/shell', (request, response) => {
    const state = requestState(request, response);
    if (state !== undefined) response.type('html').send(renderShell(state.context));
  });

  app.get('/app/:capability/workspace', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const level = Number.parseInt(text(request.query.level) || '0', 10);
    response.type('html').send(renderWorkspace(state.context, Number.isNaN(level) ? 0 : level));
  });

  // ---------- member inquiry ----------

  app.get('/app/:capability/search', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const query = text(request.query.query);
    const fieldParam = text(request.query.field);
    const status = text(request.query.status);
    const offset = Math.max(0, Number.parseInt(text(request.query.offset) || '0', 10) || 0);
    const result = read(state.env, (database) =>
      searchMembers(database, state.env.context.binding.datasetId, {
        limit: 50, offset,
        ...(query === '' ? {} : {
          query,
          field: (['memberNumber', 'name', 'email', 'phone', 'accountNumber'].includes(fieldParam) ? fieldParam : undefined) as never,
          match: (text(request.query.match) || undefined) as never,
        }),
        ...(status === '' ? {} : { status }),
      }));
    if (isRejected(result)) return sendRejection(response, state, result);
    const sections: Section[] = [
      {
        title: 'Member Search',
        form: form(state.context, '/search', 'Search', [
          field(state.context, 'query', 'Member name, number or contact', query, 'text', false),
          selectField(state.context, 'field', 'Search field', [
            { value: '', label: 'Any field' }, { value: 'memberNumber', label: 'Member number' }, { value: 'name', label: 'Name' },
            { value: 'email', label: 'Email' }, { value: 'phone', label: 'Phone' }, { value: 'accountNumber', label: 'Account number' },
          ], fieldParam, false),
          selectField(state.context, 'status', 'Status', [
            { value: '', label: 'Any status' }, { value: 'active', label: 'Active' }, { value: 'inactive', label: 'Inactive' },
            { value: 'deceased', label: 'Deceased' }, { value: 'merged', label: 'Merged' },
          ], status, false),
        ], {}, 'get'),
      },
      {
        title: 'Results',
        headers: ['Member number', 'Name', 'Kind', 'Status', 'Open accounts', 'Action'],
        rows: result.items.map((member) => [
          textCell(member.memberNumber), textCell(member.displayName), textCell(member.kind), textCell(member.status),
          textCell(String(member.openAccounts)), linkCell(state.context, 'Open member', memberUrl(member.memberNumber)),
        ]),
        empty: 'No members match your search.',
        links: result.offset + result.limit >= result.total ? [] : [link(state.context, 'Next page', `/search?query=${encodeURIComponent(query)}&offset=${result.offset + result.limit}`)],
      },
    ];
    sendPage(response, state, { title: 'Member Search', sections });
  });

  app.get('/app/:capability/members', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const offset = Math.max(0, Number.parseInt(text(request.query.offset) || '0', 10) || 0);
    const result = read(state.env, (database) => searchMembers(database, state.env.context.binding.datasetId, { limit: 50, offset }));
    if (isRejected(result)) return sendRejection(response, state, result);
    sendPage(response, state, {
      title: 'Members',
      sections: [{
        title: 'Member directory',
        links: [link(state.context, 'Register person', '/operations/member.create'), link(state.context, 'Register organization', '/operations/member.organization.create')],
        headers: ['Member number', 'Name', 'Kind', 'Status', 'Joined', 'Action'],
        rows: result.items.map((member) => [
          textCell(member.memberNumber), textCell(member.displayName), textCell(member.kind), textCell(member.status),
          textCell(member.joinedAt.slice(0, 10)), linkCell(state.context, 'Open member', memberUrl(member.memberNumber)),
        ]),
        empty: 'No members.',
      }],
    });
  });

  app.get('/app/:capability/members/:memberNumber', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = memberByNumber(state, text(request.params.memberNumber));
    if (detail === undefined) return sendError(response, state, 'The member does not exist.', 404);
    if (isRejected(detail)) return sendRejection(response, state, detail);
    if (detail.redirectTo !== null) {
      response.redirect(302, `${basePath(state.context)}${memberUrl(detail.redirectTo.memberNumber)}?notice=${encodeURIComponent('This member record was merged; showing the surviving record.')}`);
      return;
    }
    const member = detail.member;
    const sections: Section[] = [
      {
        title: 'Member', facts: [
          { label: 'Member number', value: member.memberNumber }, { label: 'Name', value: member.displayName },
          { label: 'Kind', value: member.kind }, { label: 'Status', value: member.status },
          { label: 'Joined', value: member.joinedAt.slice(0, 10) }, { label: 'Tax classification', value: member.taxClassification },
          { label: 'Record version', value: String(member.version) },
        ],
        links: memberLinks(state, member.memberNumber),
      },
      {
        title: 'Contact', facts: [
          { label: 'Email', value: detail.email?.value ?? '' },
          { label: 'Phone', value: detail.phone?.value ?? '' },
          { label: 'Address', value: detail.address === null ? '' : `${detail.address.line1}${detail.address.line2 === null ? '' : `, ${detail.address.line2}`}, ${detail.address.city}, ${detail.address.region} ${detail.address.postalCode}` },
        ],
      },
    ];
    if (detail.person !== null) {
      sections.push({
        title: 'Person', facts: [
          { label: 'Legal name', value: `${detail.person.legalGiven} ${detail.person.legalFamily}` },
          { label: 'Preferred name', value: detail.person.preferredName ?? '' },
          { label: 'Birth date', value: detail.person.birthDate },
          { label: 'Deceased', value: detail.person.deceasedAt ?? 'No' },
        ],
      });
    }
    if (detail.organization !== null) {
      sections.push({
        title: 'Organization', facts: [
          { label: 'Legal name', value: detail.organization.legalName },
          { label: 'Registration', value: detail.organization.registrationNumber },
          { label: 'Type', value: detail.organization.organizationType },
        ],
      });
    }
    sections.push(memberAccountsSection(state, member.memberNumber, detail.accounts));
    sections.push({
      title: `Notes${detail.restrictedNotesWithheld > 0 ? ` (${detail.restrictedNotesWithheld} restricted withheld)` : ''}`,
      headers: ['Date', 'Visibility', 'Note'],
      rows: detail.notes.map((note) => [textCell(note.createdAt.slice(0, 10)), textCell(note.visibility), textCell(note.text)]),
      empty: 'No member notes.',
    });
    sections.push({
      title: 'Cases',
      headers: ['Case number', 'State', 'Priority', 'Summary', 'Action'],
      rows: detail.cases.map((item) => [textCell(item.caseNumber), textCell(item.state), textCell(item.priority), textCell(item.summary.slice(0, 60)), linkCell(state.context, 'Open case', `/cases/${item.id}`)]),
      empty: 'No cases.',
    });
    sendPage(response, state, { title: 'Member Details', identity: `${member.memberNumber} · ${member.displayName}`, sections });
  });

  function memberLinks(state: RequestState, memberNumber: string) {
    const path = memberUrl(memberNumber);
    return [
      link(state.context, 'Update contact', `/operations/contact.update?s_member=${encodeURIComponent(memberNumber)}`),
      link(state.context, 'Add note', `/operations/member.note.add?s_member=${encodeURIComponent(memberNumber)}`),
      link(state.context, 'Open account', `/operations/account.open?s_member=${encodeURIComponent(memberNumber)}`),
      link(state.context, 'Open case', `/operations/case.open?s_member=${encodeURIComponent(memberNumber)}`),
      link(state.context, 'Index document', `/operations/document.index?s_member=${encodeURIComponent(memberNumber)}`),
      link(state.context, 'Statements & documents', `${path}/documents`),
      link(state.context, 'Maintenance requests', `${path}/requests`),
      link(state.context, 'Communications', `${path}/communications`),
    ];
  }

  function memberAccountsSection(state: RequestState, memberNumber: string, accounts: MemberDetail['accounts']): Section {
    if (state.profile.features.deepFrames || state.profile.features.repeatedControls) {
      const registerOrigin = state.profile.features.crossOrigin ? state.context.frameOrigin : state.context.mainOrigin;
      return { title: 'Accounts', frame: { src: `${registerOrigin}${basePath(state.context)}${memberUrl(memberNumber)}/accounts-frame`, title: `Account register for ${memberNumber}` } };
    }
    return {
      title: 'Accounts',
      headers: ['Account number', 'Product', 'Nickname', 'Status', 'Available', 'Action'],
      rows: accountRows(state, accounts),
      empty: 'No accounts.',
      links: [link(state.context, 'Open account', `/operations/account.open?s_member=${encodeURIComponent(memberNumber)}`)],
    };
  }

  function accountRows(state: RequestState, accounts: { accountNumber: string; productName: string; nickname: string; status: string; availableMinorUnits: number; currency: string }[], target?: string): Cell[][] {
    return accounts.map((account) => [
      textCell(account.accountNumber), textCell(account.productName), textCell(account.nickname), textCell(account.status),
      textCell(money(account.availableMinorUnits, account.currency)), linkCell(state.context, 'View account', accountUrl(account.accountNumber), target),
    ]);
  }

  app.get('/app/:capability/members/:memberNumber/accounts-frame', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = memberByNumber(state, text(request.params.memberNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The member does not exist.', 404);
    sendPage(response, state, {
      title: 'Accounts', embedded: true,
      sections: [{
        title: 'Account register',
        headers: ['Account number', 'Product', 'Nickname', 'Status', 'Available', 'Action'],
        rows: accountRows(state, detail.accounts, '_parent'),
        empty: 'No accounts.',
        links: [link(state.context, 'Open account', `/operations/account.open?s_member=${encodeURIComponent(detail.member.memberNumber)}`, '_parent')],
      }],
    });
  });

  app.get('/app/:capability/members/:memberNumber/documents', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = memberByNumber(state, text(request.params.memberNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The member does not exist.', 404);
    const documents = read(state.env, (database) => searchDocuments(database, state.env.context.binding.datasetId, { memberId: detail.member.id, limit: 200, offset: 0 }));
    if (isRejected(documents)) return sendRejection(response, state, documents);
    sendPage(response, state, {
      title: 'Member Documents', identity: `${detail.member.memberNumber} · ${detail.member.displayName}`,
      sections: [{
        title: 'Documents',
        headers: ['Name', 'Type', 'Version', 'Issued', 'Status', 'Action'],
        rows: documents.items.map((document) => [
          textCell(document.displayName), textCell(document.documentType), textCell(`v${document.version}`),
          textCell(document.issuedAt.slice(0, 10)), textCell(document.status),
          linkCell(state.context, 'View', `/documents/${document.versionId}`),
        ]),
        empty: 'No documents.',
        links: [link(state.context, 'Index document', `/operations/document.index?s_member=${encodeURIComponent(detail.member.memberNumber)}`)],
      }],
    });
  });

  app.get('/app/:capability/members/:memberNumber/requests', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = memberByNumber(state, text(request.params.memberNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The member does not exist.', 404);
    const requests = read(state.env, (database) =>
      database.prepare('SELECT id,request_number AS requestNumber,subject,category,state,updated_at AS updatedAt FROM maintenance_requests WHERE dataset_id=? AND member_id=? ORDER BY updated_at DESC LIMIT 200')
        .all(state.env.context.binding.datasetId, detail.member.id) as { id: string; requestNumber: string; subject: string; category: string; state: string; updatedAt: string }[]);
    if (isRejected(requests)) return sendRejection(response, state, requests);
    sendPage(response, state, {
      title: 'Maintenance Requests', identity: `${detail.member.memberNumber} · ${detail.member.displayName}`,
      sections: [{
        title: 'Requests',
        headers: ['Request', 'Category', 'Subject', 'State', 'Updated', 'Action'],
        rows: requests.map((item) => [textCell(item.requestNumber), textCell(item.category), textCell(item.subject.slice(0, 48)), textCell(item.state), textCell(item.updatedAt.slice(0, 10)), linkCell(state.context, 'Maintain', `/operations/maintenance.draft.amend?s_request=${item.id}`)]),
        empty: 'No maintenance requests.',
        links: [link(state.context, 'New draft', `/operations/maintenance.draft.save?s_member=${encodeURIComponent(detail.member.memberNumber)}`)],
      }],
    });
  });

  app.get('/app/:capability/members/:memberNumber/communications', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = memberByNumber(state, text(request.params.memberNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The member does not exist.', 404);
    const jobs = read(state.env, (database) =>
      database.prepare('SELECT id,purpose,channel,destination,state,created_at AS createdAt FROM communication_jobs WHERE dataset_id=? AND party_id=? ORDER BY created_at DESC LIMIT 200')
        .all(state.env.context.binding.datasetId, detail.member.partyId) as { id: string; purpose: string; channel: string; destination: string; state: string; createdAt: string }[]);
    if (isRejected(jobs)) return sendRejection(response, state, jobs);
    sendPage(response, state, {
      title: 'Communications', identity: `${detail.member.memberNumber} · ${detail.member.displayName}`,
      sections: [{
        title: 'Communication jobs',
        headers: ['Purpose', 'Channel', 'Destination', 'State', 'Created', 'Action'],
        rows: jobs.map((job) => [textCell(job.purpose), textCell(job.channel), textCell(job.destination), textCell(job.state), textCell(job.createdAt.slice(0, 10)), linkCell(state.context, 'Update delivery', `/operations/communication.delivery.update?s_job=${job.id}`)]),
        empty: 'No communications.',
        links: [link(state.context, 'Send communication', `/operations/communication.send?s_member=${encodeURIComponent(detail.member.memberNumber)}`)],
      }],
    });
  });

  // ---------- accounts ----------

  app.get('/app/:capability/accounts', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const query = text(request.query.query);
    const offset = Math.max(0, Number.parseInt(text(request.query.offset) || '0', 10) || 0);
    const result = read(state.env, (database) =>
      searchAccounts(database, state.env.context.binding.datasetId, { limit: 50, offset, ...(query === '' ? {} : { query }) }));
    if (isRejected(result)) return sendRejection(response, state, result);
    sendPage(response, state, {
      title: 'Accounts',
      sections: [
        { title: 'Account Search', form: form(state.context, '/accounts', 'Search', [field(state.context, 'query', 'Account or member number', query, 'text', false)], {}, 'get') },
        {
          title: 'Results',
          headers: ['Account', 'Member', 'Product', 'Status', 'Posted', 'Available', 'Action'],
          rows: result.items.map((account) => [
            textCell(account.accountNumber), textCell(`${account.memberNumber} · ${account.ownerName}`), textCell(account.productName),
            textCell(account.status), textCell(money(account.postedMinorUnits, account.currency)), textCell(money(account.availableMinorUnits, account.currency)),
            linkCell(state.context, 'View account', accountUrl(account.accountNumber)),
          ]),
          empty: 'No accounts match.',
        },
      ],
    });
  });

  app.get('/app/:capability/accounts/:accountNumber', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = accountByNumber(state, text(request.params.accountNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The account does not exist.', 404);
    const account = detail.account;
    const number = account.accountNumber;
    const sections: Section[] = [
      {
        title: 'Account', facts: [
          { label: 'Account number', value: account.accountNumber },
          { label: 'Member', value: `${account.memberNumber} · ${account.ownerName}` },
          { label: 'Product', value: `${account.productCode} · ${account.productName}` },
          { label: 'Status', value: account.status },
          { label: 'Nickname', value: account.nickname },
          { label: 'Posted balance', value: money(account.postedMinorUnits, account.currency) },
          { label: 'Available balance', value: money(account.availableMinorUnits, account.currency) },
          { label: 'Statement delivery', value: account.statementDelivery },
          { label: 'Opened', value: account.openedAt.slice(0, 10) },
          { label: 'Record version', value: String(account.version) },
        ],
        links: [
          link(state.context, 'Member details', memberUrl(account.memberNumber)),
          link(state.context, 'Transactions', `${accountUrl(number)}/transactions`),
          link(state.context, 'Statements', `${accountUrl(number)}/statements`, state.profile.features.separateInquiryWindow ? '_blank' : undefined),
          link(state.context, 'Documents', `${accountUrl(number)}/documents`),
        ],
      },
      {
        title: 'Operations',
        links: [
          link(state.context, 'Deposit', `/operations/cash.deposit?s_account=${encodeURIComponent(number)}`),
          link(state.context, 'Withdrawal', `/operations/cash.withdraw?s_account=${encodeURIComponent(number)}`),
          link(state.context, 'Transfer', `/operations/transfer.internal?s_source=${encodeURIComponent(number)}`),
          link(state.context, 'Update nickname', `/operations/account.nickname.update?s_account=${encodeURIComponent(number)}`),
          link(state.context, 'Statement delivery', `/operations/account.statement_delivery.update?s_account=${encodeURIComponent(number)}`),
          link(state.context, 'Place hold', `/operations/account.hold.place?s_account=${encodeURIComponent(number)}`),
          link(state.context, 'Apply restriction', `/operations/account.restriction.apply?s_account=${encodeURIComponent(number)}`),
          link(state.context, 'Assess fee', `/operations/fee.assess?s_account=${encodeURIComponent(number)}`),
          link(state.context, 'Create payment', `/operations/payment.create?s_source=${encodeURIComponent(number)}`),
          link(state.context, 'Close account', `/operations/account.close?s_account=${encodeURIComponent(number)}`),
        ],
      },
      {
        title: 'Parties', headers: ['Party', 'Role', 'Since'],
        rows: detail.parties.map((party) => [textCell(party.displayName), textCell(party.role), textCell(party.startsAt.slice(0, 10))]),
        empty: 'No parties.',
      },
    ];
    const loans = read(state.env, (database) =>
      database.prepare('SELECT id,state,principal_minor_units AS principal,annual_rate_bps AS rate,currency FROM loans WHERE dataset_id=? AND account_id=? ORDER BY id')
        .all(state.env.context.binding.datasetId, account.id) as { id: string; state: string; principal: number; rate: number; currency: string }[]);
    if (isRejected(loans)) return sendRejection(response, state, loans);
    const collections: [string, { headers: string[]; rows: Cell[][] }][] = [
      ['Holds', { headers: ['Amount', 'Reason', 'Status', 'Placed'], rows: detail.holds.map((item) => [textCell(money(item.amountMinorUnits, account.currency)), textCell(item.reason), textCell(item.status), textCell(item.placedAt.slice(0, 10))]) }],
      ['Restrictions', { headers: ['Kind', 'Status', 'Placed'], rows: detail.restrictions.map((item) => [textCell(item.kind), textCell(item.status), textCell(item.placedAt.slice(0, 10))]) }],
      ['Facilities', { headers: ['Kind', 'Limit', 'Used', 'Status'], rows: detail.facilities.map((item) => [textCell(item.kind), textCell(money(item.limitMinorUnits, account.currency)), textCell(money(item.usedMinorUnits, account.currency)), textCell(item.status)]) }],
      ['Cards', { headers: ['Card', 'Status'], rows: detail.cards.map((item) => [textCell(`····${item.lastFour}`), textCell(item.status)]) }],
      ['Loans', { headers: ['Loan', 'Principal', 'Rate', 'State'], rows: loans.map((item) => [textCell(item.id), textCell(money(item.principal, item.currency)), textCell(`${item.rate} bps`), textCell(item.state)]) }],
      ['Maturity instructions', { headers: ['Instruction', 'State', 'Cutoff'], rows: detail.maturityInstructions.map((item) => [textCell(item.id), textCell(item.state), textCell(item.cutoffAt.slice(0, 10))]) }],
    ];
    for (const [title, table] of collections) if (table.rows.length > 0) sections.push({ title, headers: table.headers, rows: table.rows });
    sendPage(response, state, { title: 'Account Details', identity: `${number} · ${account.productName}`, sections });
  });

  app.get('/app/:capability/accounts/:accountNumber/transactions', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = accountByNumber(state, text(request.params.accountNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The account does not exist.', 404);
    const account = detail.account;
    const offset = Math.max(0, Number.parseInt(text(request.query.offset) || '0', 10) || 0);
    const direction = text(request.query.direction);
    const query = text(request.query.text);
    const result = read(state.env, (database) =>
      accountTransactions(database, state.env.context.binding.datasetId, account.id, {
        limit: 50, offset,
        ...(direction === '' ? {} : { direction: direction as 'credit' | 'debit' }),
        ...(query === '' ? {} : { text: query }),
      }));
    if (isRejected(result)) return sendRejection(response, state, result);
    sendPage(response, state, {
      title: 'Transactions', identity: `${account.accountNumber} · ${account.productName}`,
      sections: [
        {
          title: 'Filters',
          form: form(state.context, `${accountUrl(account.accountNumber)}/transactions`, 'Filter', [
            selectField(state.context, 'direction', 'Direction', [{ value: '', label: 'Any' }, { value: 'credit', label: 'Credit' }, { value: 'debit', label: 'Debit' }], direction, false),
            field(state.context, 'text', 'Description contains', query, 'text', false),
          ], {}, 'get'),
          links: [link(state.context, 'Download CSV', `${accountUrl(account.accountNumber)}/transactions.csv`)],
        },
        {
          title: 'Transactions',
          headers: ['Posted', 'Effective', 'Reference', 'Description', 'Amount', 'Balance', 'Receipt', 'Action'],
          rows: result.items.map((item) => [
            textCell(item.postedAt.slice(0, 10)), textCell(item.effectiveDate), textCell(item.reference), textCell(item.description.slice(0, 48)),
            textCell(money(item.amountMinorUnits, account.currency)), textCell(money(item.runningBalanceMinorUnits, account.currency)),
            item.receiptNumber === null ? textCell('') : linkCell(state.context, item.receiptNumber, `/receipts/${item.receiptNumber}`),
            linkCell(state.context, 'Correct', `/operations/transaction.description.update?s_account=${encodeURIComponent(account.accountNumber)}&s_journal=${item.journalId}`),
          ]),
          empty: 'No transactions.',
          links: result.offset + result.limit >= result.total ? [] : [link(state.context, 'Next page', `${accountUrl(account.accountNumber)}/transactions?offset=${result.offset + result.limit}${direction === '' ? '' : `&direction=${encodeURIComponent(direction)}`}${query === '' ? '' : `&text=${encodeURIComponent(query)}`}`)],
        },
      ],
    });
  });

  app.get('/app/:capability/accounts/:accountNumber/transactions.csv', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = accountByNumber(state, text(request.params.accountNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The account does not exist.', 404);
    const result = read(state.env, (database) => {
      const rows = accountTransactions(database, state.env.context.binding.datasetId, detail.account.id, { limit: 200, offset: 0 }).items;
      return transactionsCsv(detail.account, rows);
    });
    if (isRejected(result)) return sendRejection(response, state, result);
    sendArtifact(response, result);
  });

  app.get('/app/:capability/accounts/:accountNumber/statements', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = accountByNumber(state, text(request.params.accountNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The account does not exist.', 404);
    const account = detail.account;
    const periods = read(state.env, (database) => statementPeriods(database, state.env.context.binding.datasetId, account.id));
    if (isRejected(periods)) return sendRejection(response, state, periods);
    sendPage(response, state, {
      title: 'Statements', identity: `${account.accountNumber} · ${account.productName}`,
      sections: [
        {
          title: 'Statement periods',
          headers: ['Period', 'View', 'CSV', 'HTML', 'PDF'],
          rows: periods.map((period) => [
            textCell(period),
            linkCell(state.context, 'View', `${accountUrl(account.accountNumber)}/statement-view?period=${period}`, state.profile.features.separateInquiryWindow ? '_blank' : undefined),
            linkCell(state.context, 'CSV', `${accountUrl(account.accountNumber)}/statements.csv?period=${period}`),
            linkCell(state.context, 'HTML', `${accountUrl(account.accountNumber)}/statements.html?period=${period}`),
            linkCell(state.context, 'PDF', `${accountUrl(account.accountNumber)}/statements.pdf?period=${period}`),
          ]),
          empty: 'No statement periods.',
        },
      ],
    });
  });

  for (const format of ['csv', 'html', 'pdf'] as const) {
    app.get(`/app/:capability/accounts/:accountNumber/statements.${format}`, async (request, response) => {
      const state = requestState(request, response);
      if (state === undefined) return;
      const detail = accountByNumber(state, text(request.params.accountNumber));
      if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The account does not exist.', 404);
      const period = text(request.query.period) || statementPeriodsFallback(state, detail.account.id)[0] || '';
      try {
        const result = await exportStatement(state.env.store, state.env.context, {
          memberId: detail.account.memberId, accountId: detail.account.id, period, formats: [format], destinationId: 'download',
        }, state.env.exportDestinations);
        if (isRejected(result)) return sendRejection(response, state, result);
        const artifact = result.artifacts[0];
        if (artifact === undefined) return sendError(response, state, 'The statement could not be produced.', 404);
        sendArtifact(response, artifact);
      } catch (error) {
        sendError(response, state, error instanceof Error ? error.message : 'The statement could not be produced.');
      }
    });
  }

  app.get('/app/:capability/accounts/:accountNumber/statement-view', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = accountByNumber(state, text(request.params.accountNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The account does not exist.', 404);
    const account = detail.account;
    const period = text(request.query.period);
    // Issued versions take precedence over the derived projection.
    if (period !== '') {
      const [year, month] = period.split('-');
      const issued = read(state.env, (database) => {
        const start = `${period}-01`;
        const end = `${period}-${new Date(Number(year), Number(month), 0).getDate()}`;
        return retrieveHistoricalStatement(database, state.env.context, account.id, start, end, 'html');
      });
      if (isRejected(issued)) return sendRejection(response, state, issued);
      if (issued.value !== undefined) {
        response.type('html').send(Buffer.from(issued.value.bytes).toString('utf8'));
        return;
      }
    }
    const derived = read(state.env, (database) =>
      accountTransactions(database, state.env.context.binding.datasetId, account.id, {
        limit: 200, offset: 0, order: 'oldest',
        ...(period === '' ? {} : { startDate: `${period}-01`, endDate: monthEndExclusive(period) }),
      }));
    if (isRejected(derived)) return sendRejection(response, state, derived);
    sendPage(response, state, {
      title: 'Account Statement', identity: `${account.accountNumber} · ${period || 'current'}`,
      sections: [{
        title: 'Derived ledger statement', text: `Derived statement projection for ${account.accountNumber}${period === '' ? '' : `, period ${period}`}.`,
        headers: ['Posted', 'Effective', 'Reference', 'Description', 'Amount', 'Balance'],
        rows: derived.items.map((item) => [
          textCell(item.postedAt.slice(0, 10)), textCell(item.effectiveDate), textCell(item.reference), textCell(item.description.slice(0, 48)),
          textCell(money(item.amountMinorUnits, account.currency)), textCell(money(item.runningBalanceMinorUnits, account.currency)),
        ]),
        empty: 'No activity in this period.',
      }],
    });
  });

  app.get('/app/:capability/accounts/:accountNumber/documents', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = accountByNumber(state, text(request.params.accountNumber));
    if (detail === undefined || isRejected(detail)) return sendError(response, state, 'The account does not exist.', 404);
    const documents = read(state.env, (database) => searchDocuments(database, state.env.context.binding.datasetId, { accountId: detail.account.id, limit: 200, offset: 0 }));
    if (isRejected(documents)) return sendRejection(response, state, documents);
    sendPage(response, state, {
      title: 'Account Documents', identity: detail.account.accountNumber,
      sections: [{
        title: 'Documents',
        headers: ['Name', 'Type', 'Version', 'Issued', 'Status', 'Action'],
        rows: documents.items.map((document) => [
          textCell(document.displayName), textCell(document.documentType), textCell(`v${document.version}`),
          textCell(document.issuedAt.slice(0, 10)), textCell(document.status), linkCell(state.context, 'View', `/documents/${document.versionId}`),
        ]),
        empty: 'No documents.',
      }],
    });
  });

  // ---------- documents ----------

  app.get('/app/:capability/documents', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const query = text(request.query.query);
    const documentType = text(request.query.documentType);
    const result = read(state.env, (database) =>
      searchDocuments(database, state.env.context.binding.datasetId, { limit: 100, offset: 0, ...(query === '' ? {} : { query }), ...(documentType === '' ? {} : { documentType }) }));
    if (isRejected(result)) return sendRejection(response, state, result);
    const types = read(state.env, (database) => database.prepare('SELECT DISTINCT document_type AS type FROM documents WHERE dataset_id=? ORDER BY document_type').all(state.env.context.binding.datasetId) as { type: string }[]);
    if (isRejected(types)) return sendRejection(response, state, types);
    sendPage(response, state, {
      title: 'Documents',
      sections: [
        {
          title: 'Document search',
          form: form(state.context, '/documents', 'Search', [
            field(state.context, 'query', 'Member, account, name', query, 'text', false),
            selectField(state.context, 'documentType', 'Type', [{ value: '', label: 'Any type' }, ...types.map((item) => ({ value: item.type, label: item.type }))], documentType, false),
          ], {}, 'get'),
        },
        {
          title: 'Documents',
          headers: ['Name', 'Type', 'Member', 'Version', 'Issued', 'Status', 'Action'],
          rows: result.items.map((document) => [
            textCell(document.displayName), textCell(document.documentType), textCell(`${document.memberNumber} · ${document.ownerName}`),
            textCell(`v${document.version}`), textCell(document.issuedAt.slice(0, 10)), textCell(document.status),
            linkCell(state.context, 'View', `/documents/${document.versionId}`),
          ]),
          empty: 'No documents match.',
        },
      ],
    });
  });

  app.get('/app/:capability/documents/:versionId', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = read(state.env, (database) => documentContent(database, state.env.context.binding.datasetId, text(request.params.versionId)));
    if (isRejected(detail)) return sendRejection(response, state, detail);
    if (detail === undefined) return sendError(response, state, 'The document version does not exist.', 404);
    const annotations = read(state.env, (database) =>
      database.prepare('SELECT id,page_number AS page,text,status FROM document_annotations WHERE dataset_id=? AND document_version_id=? ORDER BY page_number,id').all(state.env.context.binding.datasetId, detail.versionId) as { id: string; page: number; text: string; status: string }[]);
    if (isRejected(annotations)) return sendRejection(response, state, annotations);
    sendPage(response, state, {
      title: 'Document', identity: `${detail.displayName} v${detail.version}`,
      sections: [
        {
          title: 'Document', facts: [
            { label: 'Name', value: detail.displayName }, { label: 'Type', value: detail.documentType },
            { label: 'Version', value: String(detail.version) }, { label: 'Status', value: detail.status },
            { label: 'Issued', value: detail.issuedAt.slice(0, 10) }, { label: 'Media type', value: detail.mediaType },
            { label: 'Size', value: `${detail.byteLength} bytes` }, { label: 'Digest', value: detail.digest.slice(0, 16) },
          ],
          links: [
            link(state.context, 'Download content', `/documents/${detail.versionId}/content`),
            link(state.context, 'Annotate', `/operations/document.annotation.update?s_version=${detail.versionId}`),
            link(state.context, 'Collect signature', `/operations/document.signature.collect?s_version=${detail.versionId}`),
            link(state.context, 'Edit metadata', `/operations/document.metadata.update?s_document=${detail.documentId}`),
          ],
        },
        {
          title: 'Annotations', headers: ['Page', 'Text', 'Status'],
          rows: annotations.map((item) => [textCell(String(item.page)), textCell(item.text.slice(0, 60)), textCell(item.status)]),
          empty: 'No annotations.',
        },
      ],
    });
  });

  app.get('/app/:capability/documents/:versionId/content', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = read(state.env, (database) => documentContent(database, state.env.context.binding.datasetId, text(request.params.versionId)));
    if (isRejected(detail)) return sendRejection(response, state, detail);
    if (detail === undefined) return sendError(response, state, 'The document version does not exist.', 404);
    response.setHeader('content-type', detail.mediaType);
    response.setHeader('content-disposition', `attachment; filename="${detail.displayName.replaceAll('"', '')}-v${detail.version}"`);
    response.send(Buffer.from(detail.bytes));
  });

  // ---------- cases ----------

  app.get('/app/:capability/cases', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const query = text(request.query.query);
    const caseState = text(request.query.state);
    const result = read(state.env, (database) =>
      searchCases(database, state.env.context.binding.datasetId, { limit: 100, offset: 0, ...(query === '' ? {} : { query }), ...(caseState === '' ? {} : { states: [caseState] }) }));
    if (isRejected(result)) return sendRejection(response, state, result);
    sendPage(response, state, {
      title: 'Cases',
      sections: [
        {
          title: 'Case search',
          form: form(state.context, '/cases', 'Search', [
            field(state.context, 'query', 'Case or member number', query, 'text', false),
            selectField(state.context, 'state', 'State', [
              { value: '', label: 'Any state' }, { value: 'open', label: 'Open' }, { value: 'pending-customer', label: 'Pending customer' },
              { value: 'pending-internal', label: 'Pending internal' }, { value: 'resolved', label: 'Resolved' }, { value: 'closed', label: 'Closed' }, { value: 'reopened', label: 'Reopened' },
            ], caseState, false),
          ], {}, 'get'),
        },
        {
          title: 'Cases',
          headers: ['Case', 'Member', 'State', 'Priority', 'Category', 'Summary', 'Action'],
          rows: result.items.map((item) => [
            textCell(item.caseNumber), textCell(`${item.memberNumber} · ${item.memberName}`), textCell(item.state), textCell(item.priority),
            textCell(item.category), textCell(item.summary.slice(0, 40)), linkCell(state.context, 'Open case', `/cases/${item.id}`),
          ]),
          empty: 'No cases match.',
        },
      ],
    });
  });

  app.get('/app/:capability/cases/:caseId', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const detail = caseById(state, text(request.params.caseId));
    if (detail === undefined) return sendError(response, state, 'The case does not exist.', 404);
    if (isRejected(detail)) return sendRejection(response, state, detail);
    const item = detail.case;
    sendPage(response, state, {
      title: 'Case', identity: `${item.caseNumber} · ${item.state}`,
      sections: [
        {
          title: 'Case', facts: [
            { label: 'Case number', value: item.caseNumber }, { label: 'Member', value: `${item.memberNumber} · ${item.memberName}` },
            { label: 'Account', value: item.accountNumber ?? '' }, { label: 'Queue', value: `${item.queueCode} · ${item.queueName}` },
            { label: 'Assigned', value: item.assignedName ?? 'Unassigned' }, { label: 'State', value: item.state },
            { label: 'Priority', value: item.priority }, { label: 'Category', value: item.category },
            { label: 'Summary', value: item.summary }, { label: 'Opened', value: item.openedAt.slice(0, 10) },
            { label: 'Due', value: item.dueAt.slice(0, 10) }, { label: 'Record version', value: String(item.version) },
          ],
          links: [
            link(state.context, 'Member details', memberUrl(item.memberNumber)),
            link(state.context, 'Add note', `/operations/case.note.add?s_case=${item.id}`),
            link(state.context, 'Reassign', `/operations/case.assign?s_case=${item.id}`),
            link(state.context, 'Transition', `/operations/case.transition?s_case=${item.id}`),
            link(state.context, 'Request information', `/operations/case.information.request?s_case=${item.id}`),
            link(state.context, 'Escalate', `/operations/case.escalate?s_case=${item.id}`),
            link(state.context, 'Close case', `/operations/case.close?s_case=${item.id}`),
            link(state.context, 'Reopen', `/operations/case.reopen?s_case=${item.id}`),
          ],
        },
        {
          title: 'Events', headers: ['Sequence', 'State', 'When', 'Actor', 'Detail'],
          rows: detail.events.map((event) => [textCell(String(event.sequence)), textCell(event.state), textCell(event.occurredAt.slice(0, 16)), textCell(event.actor?.actorNumber ?? ''), textCell(event.detail.slice(0, 60))]),
          empty: 'No events.',
        },
        {
          title: `Notes${detail.restrictedNotesWithheld > 0 ? ` (${detail.restrictedNotesWithheld} restricted withheld)` : ''}`,
          headers: ['When', 'Visibility', 'Actor', 'Note'],
          rows: detail.notes.map((note) => [textCell(note.createdAt.slice(0, 10)), textCell(note.visibility), textCell(note.actor?.actorNumber ?? ''), textCell(note.text.slice(0, 60))]),
          empty: 'No notes.',
        },
        {
          title: 'Dependencies', headers: ['Kind', 'Reference', 'State', 'Due'],
          rows: detail.dependencies.map((dependency) => [textCell(dependency.kind), textCell(dependency.referenceId), textCell(dependency.state), textCell(dependency.dueAt?.slice(0, 10) ?? '')]),
          empty: 'No dependencies.',
        },
        {
          title: 'Documents', headers: ['Name', 'Purpose', 'Visibility', 'Version'],
          rows: detail.documents.map((document) => [
            textCell(document.displayName), textCell(document.purpose), textCell(document.visibility),
            { text: `v${document.version}`, link: link(state.context, `v${document.version}`, `/documents/${document.versionId}`) },
          ]),
          empty: 'No documents.',
        },
      ],
    });
  });

  // ---------- finance registers ----------

  app.get('/app/:capability/registers', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    sendPage(response, state, {
      title: 'Registers',
      sections: [{
        title: 'Operational registers',
        links: REGISTERS.map((register) => link(state.context, register.title, `/registers/${register.id}`)),
      }],
    });
  });

  app.get('/app/:capability/registers/:register', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const register = REGISTERS.find((item) => item.id === text(request.params.register));
    if (register === undefined) return sendError(response, state, 'Unknown register.', 404);
    const result = read(state.env, (database) => database.prepare(register.sql).all(state.env.context.binding.datasetId) as Record<string, unknown>[]);
    if (isRejected(result)) return sendRejection(response, state, result);
    sendPage(response, state, {
      title: register.title,
      sections: [{
        title: register.title,
        headers: register.headers,
        rows: result.map((row) => [
          ...register.columns.map((column) => textCell(text(row[column]))),
          linkCell(state.context, 'Inspect', `/registers/${register.id}/${text(row.id)}`),
        ]),
        empty: 'No records.',
      }],
    });
  });

  app.get('/app/:capability/registers/:register/:id', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const register = REGISTERS.find((item) => item.id === text(request.params.register));
    if (register === undefined) return sendError(response, state, 'Unknown register.', 404);
    const detail = register.detail(state.env, text(request.params.id));
    if (isRejected(detail)) return sendRejection(response, state, detail);
    if (detail === undefined) return sendError(response, state, 'The record does not exist.', 404);
    sendPage(response, state, { title: register.title, sections: detail });
  });

  // ---------- activity and receipts ----------

  app.get('/app/:capability/activity', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const query = text(request.query.query);
    const offset = Math.max(0, Number.parseInt(text(request.query.offset) || '0', 10) || 0);
    const result = read(state.env, (database) =>
      listActivity(database, state.env.context.binding.datasetId, { limit: 50, offset, ...(query === '' ? {} : { query }) }));
    if (isRejected(result)) return sendRejection(response, state, result);
    sendPage(response, state, {
      title: 'Activity',
      sections: [
        { title: 'Filter', form: form(state.context, '/activity', 'Search', [field(state.context, 'query', 'Summary or receipt number', query, 'text', false)], {}, 'get'), links: [link(state.context, 'Reconcile an operation key', '/reconcile')] },
        {
          title: 'Business events',
          headers: ['When', 'Kind', 'Resource', 'Summary', 'Actor', 'Receipt'],
          rows: result.items.map((event) => [
            textCell(event.occurredAt.slice(0, 16)), textCell(event.kind), textCell(event.resourceKind), textCell(event.summary.slice(0, 60)),
            textCell(event.actor?.actorNumber ?? ''),
            event.receiptNumber === null ? textCell('') : linkCell(state.context, event.receiptNumber, `/receipts/${event.receiptNumber}`),
          ]),
          empty: 'No activity has been recorded.',
          links: result.offset + result.limit >= result.total ? [] : [link(state.context, 'Next page', `/activity?offset=${result.offset + result.limit}`)],
        },
      ],
    });
  });

  app.get('/app/:capability/receipts/:receiptNumber', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const receipt = read(state.env, (database) => receiptByNumber(database, state.env.context.binding.datasetId, text(request.params.receiptNumber)));
    if (isRejected(receipt)) return sendRejection(response, state, receipt);
    if (receipt === undefined) return sendError(response, state, 'The receipt does not exist.', 404);
    sendPage(response, state, { title: 'Operation Receipt', sections: receiptSections(receipt) });
  });

  app.get('/app/:capability/reconcile', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const key = text(request.query.key);
    const receipt = key === ''
      ? undefined
      : read(state.env, (database) => receiptByIdempotencyKey(database, state.env.context.binding.datasetId, key));
    if (isRejected(receipt)) return sendRejection(response, state, receipt);
    const sections: Section[] = [{
      title: 'Reconcile operation',
      text: 'Enter an operation idempotency key to recover its durable receipt after a lost acknowledgement.',
      form: form(state.context, '/reconcile', 'Look up', [field(state.context, 'key', 'Operation key', key, 'text', false)], {}, 'get'),
    }];
    if (receipt !== undefined) sections.push({ title: 'Recovered receipt', facts: [{ label: 'Receipt', value: receipt.receiptNumber }, { label: 'Operation', value: receipt.operationKind }, { label: 'Status', value: receipt.status }, { label: 'Committed', value: receipt.committedAt }], links: [link(state.context, 'Open receipt', `/receipts/${receipt.receiptNumber}`)] });
    else if (key !== '') sections.push({ title: 'Recovered receipt', text: 'No committed operation exists under that key.' });
    sendPage(response, state, { title: 'Operation Reconciliation', sections });
  });

  // ---------- approvals ----------

  app.get('/app/:capability/approvals', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const result = read(state.env, (database) =>
      database.prepare(
        `SELECT a.id,a.status,a.expires_at AS expiresAt,json_extract(a.scope_json,'$.kind') AS targetKind,
                maker.actor_number AS makerNumber, checker.actor_number AS checkerNumber
         FROM business_approvals a
         JOIN actors maker ON maker.dataset_id=a.dataset_id AND maker.id=a.maker_actor_id
         JOIN actors checker ON checker.dataset_id=a.dataset_id AND checker.id=a.checker_actor_id
         WHERE a.dataset_id=? AND (a.maker_actor_id=? OR a.checker_actor_id=?)
         ORDER BY a.expires_at DESC LIMIT 200`,
      ).all(state.env.context.binding.datasetId, state.env.context.actorId, state.env.context.actorId) as
        { id: string; status: string; expiresAt: string; targetKind: string | null; makerNumber: string; checkerNumber: string }[]);
    if (isRejected(result)) return sendRejection(response, state, result);
    sendPage(response, state, {
      title: 'Approvals',
      sections: [{
        title: 'Approval requests',
        headers: ['Status', 'Target', 'Maker', 'Checker', 'Expires', 'Action'],
        rows: result.map((approval) => [
          textCell(approval.status), textCell(approval.targetKind ?? ''), textCell(approval.makerNumber), textCell(approval.checkerNumber),
          textCell(approval.expiresAt.slice(0, 10)),
          linkCell(state.context, 'Decide', `/operations/approval.decide?s_approval=${approval.id}`),
        ]),
        empty: 'No approval requests.',
      }],
    });
  });

  // ---------- operator ----------

  app.get('/app/:capability/operator', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const operators = options.store.operators(state.capability);
    sendPage(response, state, {
      title: 'Operator',
      sections: [{
        title: 'Signed-on operator',
        text: `All operations execute under the trusted actor identity of the selected operator. Changing operator clears pending reviews.`,
        form: form(state.context, '/operator', 'Switch operator', [
          selectField(state.context, 'actorNumber', 'Operator', operators.map((operator) => ({ value: operator.actorNumber, label: `${operator.actorNumber} · ${operator.displayName} · ${operator.status}${operator.current ? ' (current)' : ''}` })), state.instance.actorNumber),
        ]),
      }],
    });
  });

  app.post('/app/:capability/operator', (request, response) => {
    const state = mutationState(request, response);
    if (state === undefined) return;
    const actorNumber = text((request.body as Record<string, unknown>).actorNumber);
    try {
      options.store.switchOperator(state.capability, actorNumber);
      response.redirect(303, `${basePath(state.context)}/operator?notice=${encodeURIComponent(`Operator switched to ${actorNumber}`)}`);
    } catch (error) {
      sendError(response, state, error instanceof Error ? error.message : 'The operator could not be switched.');
    }
  });

  // ---------- operations ----------

  app.get('/app/:capability/operations', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    sendPage(response, state, {
      title: 'Operations',
      sections: operationsByGroup().map((group) => ({
        title: group.group,
        links: group.operations.map((operation) => link(state.context, operation.title, `/operations/${operation.kind}`)),
      })),
    });
  });

  app.get('/app/:capability/operations/:kind', (request, response) => {
    const state = requestState(request, response);
    if (state === undefined) return;
    const spec = operationFor(text(request.params.kind));
    if (spec === undefined) return sendError(response, state, 'Unknown operation.', 404);
    renderOperationForm(response, state, spec, request.query);
  });

  app.post('/app/:capability/operations/:kind', (request, response) => {
    const state = mutationState(request, response);
    if (state === undefined) return;
    const spec = operationFor(text(request.params.kind));
    if (spec === undefined) return sendError(response, state, 'Unknown operation.', 404);
    const body = request.body as Record<string, unknown>;
    const resolved = resolveSubjects(state, spec, body);
    if (isRejected(resolved)) return sendRejection(response, state, resolved);
    const bound = boundSubjects(spec, resolved, body);
    const values = new Form(body);
    let command;
    try {
      command = spec.build(values, bound, state.env);
    } catch (error) {
      if (error instanceof FormError) return sendError(response, state, error.message);
      throw error;
    }
    const nonce = values.get('formNonce');
    // Approval-gated commands without an approval produce a review that defers to the checker flow.
    if (spec.approval === true && values.get('approvalId') === '') {
      const ticket = options.store.review(state.capability, nonce, command);
      if (ticket.kind !== 'reviewable') {
        if (ticket.kind === 'rejected') return sendRejection(response, state, ticket);
        return sendError(response, state, 'The operation could not be prepared.');
      }
      return sendApprovalRequired(response, state, spec, ticket.token);
    }
    const ticket = options.store.review(state.capability, nonce, command);
    if (ticket.kind === 'rejected') return sendRejection(response, state, ticket);
    if (ticket.kind === 'unchanged') {
      return sendPage(response, state, { title: spec.title, sections: [{ title: 'No change', text: ticket.message, links: [link(state.context, 'Operations', '/operations')] }] });
    }
    return sendReview(response, state, spec, ticket.token, ticket.review);
  });

  app.post('/app/:capability/operations/:kind/approve', (request, response) => {
    const state = mutationState(request, response);
    if (state === undefined) return;
    const spec = operationFor(text(request.params.kind));
    if (spec === undefined) return sendError(response, state, 'Unknown operation.', 404);
    const body = request.body as Record<string, unknown>;
    const token = text(body.reviewToken);
    const ticket = options.store.pendingFor(state.capability, token);
    if (ticket === undefined) return sendError(response, state, 'The review ticket expired or was already settled.');
    const values = new Form(body);
    const request2 = {
      kind: 'approval.request' as const,
      target: ticket.command as never,
      checkerActorId: values.text('checkerActorId', 'Checker'),
      policyVersionId: values.text('policyVersionId', 'Policy version'),
      expiresAt: values.instant('expiresAt', 'Expiry') ?? new Date(Date.now() + 72 * 3600_000).toISOString(),
      amountLimit: values.money('amountLimit', 'Amount limit', false) ?? null,
    };
    const outcome = options.store.review(state.capability, `${token}:approval`, request2);
    if (outcome.kind === 'rejected') return sendRejection(response, state, outcome);
    if (outcome.kind === 'unchanged') return sendError(response, state, outcome.message);
    return sendReview(response, state, spec, outcome.token, outcome.review, 'Approval request');
  });

  app.post('/app/:capability/commit', (request, response) => {
    const state = mutationState(request, response);
    if (state === undefined) return;
    const token = text((request.body as Record<string, unknown>).reviewToken);
    const outcome = options.store.commit(state.capability, token);
    if (outcome.kind === 'missing') return sendError(response, state, 'The review ticket expired or was already settled.', 410);
    if (outcome.kind === 'rejected') return sendRejection(response, state, outcome);
    if (outcome.kind === 'unchanged') {
      return sendPage(response, state, { title: 'Operation Result', sections: [{ title: 'Unchanged', text: outcome.message, links: [link(state.context, 'Operations', '/operations')] }] });
    }
    const description = describeOutcome(outcome);
    const receipt = outcome.receipt;
    sendPage(response, state, {
      title: 'Operation Result',
      sections: [
        {
          title: description.status, text: description.message,
          facts: [
            { label: 'Receipt number', value: receipt.receiptNumber },
            { label: 'Operation', value: receipt.operationKind },
            { label: 'Business reference', value: receipt.businessReference },
            { label: 'Committed at', value: receipt.committedAt },
            { label: 'Actor', value: `${receipt.actor.actorNumber} · ${receipt.actor.displayName}` },
            { label: 'Operation', value: receipt.operationId },
          ],
          links: [
            link(state.context, 'Receipt', `/receipts/${receipt.receiptNumber}`),
            link(state.context, 'Operations', '/operations'),
            link(state.context, 'Member Search', '/search'),
          ],
        },
        ...receiptSections(receipt),
      ],
    });
  });

  app.post('/app/:capability/cancel', (request, response) => {
    const state = mutationState(request, response);
    if (state === undefined) return;
    const token = text((request.body as Record<string, unknown>).reviewToken);
    options.store.cancelReview(state.capability, token);
    response.redirect(303, `${basePath(state.context)}/operations?notice=${encodeURIComponent('The operation was cancelled before posting.')}`);
  });

  // ---------- shared resolution helpers ----------

  function memberByNumber(state: RequestState, memberNumber: string): MemberDetail | Rejection | undefined {
    const result = read(state.env, (database) => {
      const listed = searchMembers(database, state.env.context.binding.datasetId, { query: memberNumber, field: 'memberNumber', match: 'exact', limit: 1, offset: 0 }).items[0];
      return listed === undefined ? undefined : memberDetail(database, state.env.context.binding.datasetId, listed.id);
    });
    return result;
  }

  function accountByNumber(state: RequestState, accountNumber: string): AccountDetail | Rejection | undefined {
    return read(state.env, (database) => {
      const listed = searchAccounts(database, state.env.context.binding.datasetId, { query: accountNumber, limit: 10, offset: 0 }).items.find((item) => item.accountNumber.toUpperCase() === accountNumber.toUpperCase());
      return listed === undefined ? undefined : accountDetail(database, state.env.context.binding.datasetId, listed.id);
    });
  }

  function caseById(state: RequestState, caseId: string) {
    return read(state.env, (database) => {
      const listed = searchCases(database, state.env.context.binding.datasetId, { ids: [caseId], limit: 1, offset: 0 }).items[0]
        ?? searchCases(database, state.env.context.binding.datasetId, { query: caseId, limit: 10, offset: 0 }).items.find((item) => item.caseNumber.toUpperCase() === caseId.toUpperCase());
      return listed === undefined ? undefined : caseDetail(database, state.env.context.binding.datasetId, listed.id);
    });
  }

  function statementPeriodsFallback(state: RequestState, accountId: string): string[] {
    const result = read(state.env, (database) => statementPeriods(database, state.env.context.binding.datasetId, accountId));
    return isRejected(result) ? [] : result;
  }

  function receiptSections(receipt: Receipt): Section[] {
    const sections: Section[] = [];
    if (receipt.affected.length > 0) {
      sections.push({
        title: 'Affected records',
        headers: ['Kind', 'Label'],
        rows: receipt.affected.map((item) => [textCell(item.kind), textCell(item.label)]),
      });
    }
    if (receipt.events.length > 0) {
      sections.push({
        title: 'Recorded events',
        headers: ['Sequence', 'Kind', 'Resource', 'Summary'],
        rows: receipt.events.map((event) => [textCell(String(event.sequence)), textCell(event.kind), textCell(event.resourceKind), textCell(event.summary.slice(0, 60))]),
      });
    }
    if (receipt.journals.length > 0) {
      sections.push({
        title: 'Journal lines',
        headers: ['Reference', 'Ledger', 'Account', 'Debit', 'Credit'],
        rows: receipt.journals.flatMap((journal) => journal.lines.map((line) => [
          textCell(journal.reference), textCell(line.ledgerCode), textCell(line.accountNumber ?? ''),
          textCell(line.debitMinorUnits === 0 ? '' : money(line.debitMinorUnits, line.currency)),
          textCell(line.creditMinorUnits === 0 ? '' : money(line.creditMinorUnits, line.currency)),
        ])),
      });
    }
    return sections;
  }

  // ---------- operation form machinery ----------

  function resolveSubjects(state: RequestState, spec: OperationSpec, values: Record<string, unknown>): Resolved | Rejection {
    const resolved: Resolved = {};
    for (const subject of spec.subjects) {
      const raw = values[`s_${subject.key}`];
      const value = Array.isArray(raw) ? text(raw[0]) : text(raw);
      if (value === '') {
        if (subjectOptional(subject)) continue;
        return { kind: 'rejected', code: 'validation', message: `${subject.label} is required.` };
      }
      const resolver = SUBJECT_RESOLVERS[subject.kind];
      if (resolver === undefined) return { kind: 'rejected', code: 'validation', message: `Unknown subject ${subject.kind}.` };
      const subject$1 = resolver.resolve(state.env, resolved, value);
      if (isRejected(subject$1)) return subject$1;
      resolved[subject.key] = subject$1;
    }
    return resolved;
  }

  function subjectOptional(subject: OperationSpec['subjects'][number]): boolean {
    return subject.label.includes('(optional') || subject.label.includes('optional for');
  }

  /** Render-bound versions/fingerprints/timestamps hidden on the form override the re-resolved state. */
  function boundSubjects(spec: OperationSpec, resolved: Resolved, values: Record<string, unknown>): Resolved {
    const bound: Resolved = {};
    for (const subject of spec.subjects) {
      const subject$1 = resolved[subject.key];
      if (subject$1 === undefined) continue;
      const version = text(values[`v_${subject.key}`]);
      const fingerprint = text(values[`f_${subject.key}`]);
      const updatedAt = text(values[`u_${subject.key}`]);
      bound[subject.key] = {
        ...subject$1,
        ...(version === '' ? {} : { version: Number.parseInt(version, 10) }),
        ...(fingerprint === '' ? {} : { fingerprint }),
        ...(updatedAt === '' ? {} : { updatedAt }),
      };
    }
    return bound;
  }

  function stepValues(spec: OperationSpec, values: Record<string, unknown>): Record<string, string> {
    const step: Record<string, string> = {};
    for (const spec$1 of spec.fields) {
      if (spec$1.step1 === true) {
        const value = values[spec$1.name];
        step[spec$1.name] = Array.isArray(value) ? value.map((item) => text(item)).join(',') : text(value);
      }
    }
    // Non-step1 fields like destination.update's targetId resolve inside extraHidden too.
    for (const name of ['targetId']) {
      const value = values[name];
      if (value !== undefined) step[name] = Array.isArray(value) ? text(value[0]) : text(value);
    }
    return step;
  }

  function renderOperationForm(response: Response, state: RequestState, spec: OperationSpec, values: Record<string, unknown>): void {
    const resolved: Resolved = {};
    const step = stepValues(spec, values);
    // Resolve each supplied subject in order; show the first unresolved picker.
    for (const subject of spec.subjects) {
      const raw = values[`s_${subject.key}`];
      const value = Array.isArray(raw) ? text(raw[0]) : text(raw);
      if (value === '') break;
      const resolver = SUBJECT_RESOLVERS[subject.kind];
      if (resolver === undefined) return sendError(response, state, `Unknown subject ${subject.kind}.`, 400);
      const subject$1 = resolver.resolve(state.env, resolved, value);
      if (isRejected(subject$1)) return sendRejection(response, state, subject$1);
      resolved[subject.key] = subject$1;
    }
    const allResolved = spec.subjects.every((subject) => resolved[subject.key] !== undefined || subjectOptional(subject));
    const stepFields = spec.fields.filter((spec$1) => spec$1.step1 === true);
    const stepComplete = stepFields.every((spec$1) => step[spec$1.name] !== undefined && step[spec$1.name] !== '');

    if (!allResolved || !stepComplete) {
      // Selection page: resolved subjects + chosen step fields as hidden, next pickers visible.
      const fields: Field[] = [];
      const hidden: Record<string, string> = {};
      for (const subject of spec.subjects) {
        const subject$1 = resolved[subject.key];
        if (subject$1 === undefined) {
          const resolver = SUBJECT_RESOLVERS[subject.kind];
          const options$1 = resolver?.list(state.env, resolved) ?? null;
          if (options$1 === null) {
            fields.push(field(state.context, `s_${subject.key}`, `${subject.label} identifier`));
          } else if (isRejected(options$1)) {
            return sendRejection(response, state, options$1);
          } else if (subjectOptional(subject)) {
            fields.push(selectField(state.context, `s_${subject.key}`, subject.label, [{ value: '', label: '— none —' }, ...options$1], '', false));
          } else {
            fields.push(selectField(state.context, `s_${subject.key}`, subject.label, options$1, '', false));
          }
        } else {
          hidden[`s_${subject.key}`] = subject$1.id;
        }
      }
      for (const spec$1 of stepFields) {
        const chosen = step[spec$1.name];
        if (chosen !== undefined && chosen !== '') {
          hidden[spec$1.name] = chosen;
          continue;
        }
        if (spec$1.when !== undefined && !spec$1.when(step, resolved)) continue;
        const field$1 = renderField(state, spec$1, resolved, step, '');
        if (isRejected(field$1)) return sendRejection(response, state, field$1);
        fields.push(field$1);
      }
      // Non-step1 fields that gate extraHidden (targetId) render here too when their dependencies are set.
      for (const spec$1 of spec.fields) {
        if (spec$1.step1 === true || spec$1.name !== 'targetId' || step.context === undefined) continue;
        const field$1 = renderField(state, spec$1, resolved, step, '');
        if (isRejected(field$1)) return sendRejection(response, state, field$1);
        fields.push(field$1);
      }
      sendPage(response, state, {
        title: spec.title,
        identity: Object.values(resolved).map((subject) => subject.label).join(' · '),
        sections: [{ title: 'Select records', form: form(state.context, `/operations/${spec.kind}`, 'Continue', fields, hidden, 'get') }],
      });
      return;
    }

    // Parameter page: hidden subject bindings + parameter fields.
    const hidden: Record<string, string> = {};
    const facts: { label: string; value: string }[] = [];
    for (const subject of spec.subjects) {
      const subject$1 = resolved[subject.key];
      if (subject$1 === undefined) continue;
      hidden[`s_${subject.key}`] = subject$1.id;
      if (subject$1.version !== undefined) hidden[`v_${subject.key}`] = String(subject$1.version);
      if (subject$1.fingerprint !== undefined) hidden[`f_${subject.key}`] = subject$1.fingerprint;
      if (subject$1.updatedAt !== undefined) hidden[`u_${subject.key}`] = subject$1.updatedAt;
      facts.push({ label: subject.label, value: subject$1.label });
    }
    for (const [name, value] of Object.entries(step)) if (value !== '') hidden[name] = value;
    const extra = spec.extraHidden?.(state.env, resolved, step) ?? {};
    for (const [name, value] of Object.entries(extra)) hidden[`h_${name}`] = value;

    const fields = expandFields(state, spec, resolved, step);
    if (isRejected(fields)) return sendRejection(response, state, fields);
    sendPage(response, state, {
      title: spec.title,
      identity: Object.values(resolved).map((subject) => subject.label).join(' · '),
      sections: [
        { title: 'Selected records', facts },
        { title: spec.title, form: form(state.context, `/operations/${spec.kind}`, 'Review operation', fields, hidden) },
      ],
    });
  }

  function renderField(state: RequestState, spec: NonNullable<OperationSpec['fields'][number]>, resolved: Resolved, step: Record<string, string>, value: string): Field | Rejection {
    const id = `${state.context.documentId}-${spec.name}`;
    const defaultValue = spec.default?.(state.env, resolved) ?? value;
    switch (spec.input) {
      case 'select':
      case 'multiselect': {
        const options$1 = spec.options?.(state.env, resolved, step) ?? [];
        if (isRejected(options$1)) return options$1;
        const withEmpty = spec.required === false ? [{ value: '', label: '— none —' }, ...options$1] : options$1;
        return {
          name: spec.name, label: spec.label, value: defaultValue, id, type: 'text', required: spec.required === true,
          multiple: spec.input === 'multiselect',
          options: withEmpty.map((option) => ({ value: option.value, label: option.label, selected: option.value === defaultValue })),
          ...(spec.help === undefined ? {} : { help: spec.help }),
        };
      }
      case 'textarea':
      case 'bytes':
        return { name: spec.name, label: spec.label, value: defaultValue, id, type: 'text', required: spec.required === true, multiline: true, ...(spec.help === undefined ? {} : { help: spec.help }) };
      case 'checkbox':
        return { name: spec.name, label: spec.label, value: '', id, type: 'checkbox', required: false, checked: defaultValue === 'yes', ...(spec.help === undefined ? {} : { help: spec.help }) };
      case 'money': {
        // A money field renders the decimal amount; a currency select is appended after it.
        return { name: spec.name, label: spec.label, value: defaultValue, id, type: 'text', required: spec.required === true, ...(spec.help === undefined ? {} : { help: spec.help }) };
      }
      case 'address':
        return { name: spec.name, label: spec.label, value: '', id, type: 'text', required: false, ...(spec.help === undefined ? {} : { help: spec.help }) };
      default:
        return { name: spec.name, label: spec.label, value: defaultValue, id, type: spec.input === 'integer' || spec.input === 'decimal' ? 'text' : spec.input === 'date' ? 'date' : spec.input === 'instant' ? 'datetime-local' : 'text', required: spec.required === true, ...(spec.help === undefined ? {} : { help: spec.help }) };
    }
  }

  /** Money/address composite inputs render as extra fields following their anchor field. */
  function expandFields(state: RequestState, spec: OperationSpec, resolved: Resolved, step: Record<string, string>): Field[] | Rejection {
    const fields: Field[] = [];
    for (const spec$1 of spec.fields) {
      if (spec$1.step1 === true) continue;
      if (spec$1.when !== undefined && !spec$1.when(step, resolved)) continue;
      if (spec$1.input === 'money') {
        const amount = renderField(state, spec$1, resolved, step, '');
        if (isRejected(amount)) return amount;
        fields.push(amount);
        const defaultCurrency = Object.values(resolved).find((subject) => subject.currency !== undefined)?.currency ?? 'USD';
        const ccy = renderField(state, { name: `${spec$1.name}__ccy`, label: `${spec$1.label} currency`, input: 'select', required: spec$1.required === true, options: currenciesOptions }, resolved, step, defaultCurrency);
        if (isRejected(ccy)) return ccy;
        fields.push(ccy);
        continue;
      }
      if (spec$1.input === 'address') {
        for (const [suffix, label] of [['line1', 'Address line 1'], ['line2', 'Address line 2'], ['city', 'City'], ['region', 'Region'], ['postal', 'Postal code'], ['country', 'Country']] as const) {
          fields.push(field(state.context, `${spec$1.name}__${suffix}`, `${spec$1.label} · ${label}`, '', 'text', suffix === 'line1' || suffix === 'city' ? spec$1.required === true : false));
        }
        continue;
      }
      const field$1 = renderField(state, spec$1, resolved, step, '');
      if (isRejected(field$1)) return field$1;
      fields.push(field$1);
    }
    return fields;
  }

  function sendReview(response: Response, state: RequestState, spec: OperationSpec, token: string, review: OperationReview, heading?: string): void {
    const sections: Section[] = [
      {
        title: heading ?? 'Review operation',
        text: 'Verify the operation details before posting. Posting commits the operation to the shared record immediately.',
        facts: [
          { label: 'Operation', value: spec.kind },
          ...(review.description === null ? [] : [{ label: 'Description', value: review.description }]),
          ...(review.amount === null
            ? []
            : [{ label: 'Amount', value: money(review.amount.minorUnits, review.amount.currency) }]),
          ...(review.consequences).map((consequence, index) => ({ label: `Consequence ${index + 1}`, value: consequence })),
        ],
      },
    ];
    if (review.accounts.length > 0) {
      sections.push({
        title: 'Accounts',
        headers: ['Account', 'Member', 'Posted before', 'Posted after', 'Available before', 'Available after'],
        rows: (review.accounts as { accountNumber: string; memberNumber: string; postedBeforeMinorUnits: number; postedAfterMinorUnits: number; availableBeforeMinorUnits: number; availableAfterMinorUnits: number; currency: string }[]).map((account) => [
          textCell(account.accountNumber), textCell(account.memberNumber),
          textCell(money(account.postedBeforeMinorUnits, account.currency)), textCell(money(account.postedAfterMinorUnits, account.currency)),
          textCell(money(account.availableBeforeMinorUnits, account.currency)), textCell(money(account.availableAfterMinorUnits, account.currency)),
        ]),
      });
    }
    sections.push({
      title: 'Confirm',
      form: form(state.context, '/commit', `Post ${spec.title.toLowerCase()}`, [], { reviewToken: token }),
      links: [],
    });
    sections.push({
      title: 'Cancel',
      form: form(state.context, '/cancel', 'Cancel without posting', [], { reviewToken: token }),
    });
    sendPage(response, state, { title: 'Review operation', sections });
  }

  function sendApprovalRequired(response: Response, state: RequestState, spec: OperationSpec, token: string): void {
    const checkers = pickers.checkers(state.env, spec.kind);
    if (isRejected(checkers)) return sendRejection(response, state, checkers);
    const policies = pickers.policyVersions(state.env);
    if (isRejected(policies)) return sendRejection(response, state, policies);
    sendPage(response, state, {
      title: 'Approval required',
      sections: [
        { title: 'Approval required', text: `${spec.title} requires an independent approval before it can be posted. Submit the operation for a checker to approve, or return and attach an existing approval.` },
        {
          title: 'Request approval',
          form: form(state.context, `/operations/${spec.kind}/approve`, 'Request approval', [
            selectField(state.context, 'checkerActorId', 'Checker', checkers),
            selectField(state.context, 'policyVersionId', 'Policy version', policies),
            field(state.context, 'expiresAt', 'Approval expiry (UTC)', '', 'datetime-local', false),
            field(state.context, 'amountLimit', 'Amount limit (optional)', '', 'text', false),
          ], { reviewToken: token }),
        },
        { title: 'Cancel', form: form(state.context, '/cancel', 'Cancel without posting', [], { reviewToken: token }) },
      ],
    });
  }
}

const currenciesOptions = (env: Env) => {
  const result = read(env, (database) => database.prepare('SELECT code,name FROM currencies ORDER BY code').all() as { code: string; name: string }[]);
  if (isRejected(result)) return result;
  return result.map((item) => ({ value: item.code, label: `${item.code} · ${item.name}` }));
};

interface RegisterDef {
  id: string;
  title: string;
  headers: string[];
  columns: string[];
  sql: string;
  detail(env: Env, id: string): Section[] | Rejection | undefined;
}

const genericDetail = (kind: FinanceRecordKind) =>
  (env: Env, id: string): Section[] | Rejection | undefined => {
    const result = queryFinance(env.store, env.context, { kind: 'finance.record', resource: kind, id });
    if (result.kind === 'rejected') return result;
    if (result.kind !== 'found') return undefined;
    return recordSections(result.snapshot.record, `Fingerprint ${result.snapshot.fingerprint.slice(0, 12)}`);
  };

function recordSections(record: Record<string, unknown>, caption?: string): Section[] {
  const facts: { label: string; value: string }[] = [];
  const children: Section[] = [];
  for (const [key, value] of Object.entries(record)) {
    if (value === null || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      facts.push({ label: key, value: String(value ?? '') });
    } else if (Array.isArray(value) && value.every((item) => typeof item === 'object' && item !== null)) {
      const rows = value as Record<string, unknown>[];
      const headers = [...new Set(rows.flatMap((item) => Object.keys(item)))].slice(0, 8);
      children.push({
        title: key,
        headers,
        rows: rows.slice(0, 200).map((item) => headers.map((header) => textCell(text(item[header])))),
      });
    } else if (typeof value === 'object' && !Array.isArray(value)) {
      for (const [inner, innerValue] of Object.entries(value as Record<string, unknown>)) {
        if (typeof innerValue !== 'object') facts.push({ label: `${key}.${inner}`, value: text(innerValue) });
      }
    }
  }
  return [{ title: caption ?? 'Record', facts }, ...children];
}

export const REGISTERS: RegisterDef[] = [
  {
    id: 'payments', title: 'Payments', headers: ['Reference', 'State', 'Amount', 'Requested', 'Source'],
    columns: ['reference', 'state', 'amount', 'requested', 'source'],
    sql: `SELECT p.id,p.reference,p.state,p.amount_minor_units||' '||p.currency AS amount,p.requested_date AS requested,a.account_number AS source FROM payments p JOIN accounts a ON a.dataset_id=p.dataset_id AND a.id=p.source_account_id WHERE p.dataset_id=? ORDER BY p.requested_date DESC LIMIT 300`,
    detail: genericDetail('payment'),
  },
  {
    id: 'schedules', title: 'Payment schedules', headers: ['Schedule', 'State', 'Start', 'End'],
    columns: ['id', 'state', 'start', 'end_'],
    sql: `SELECT id,state,start_date AS start,COALESCE(end_date,'') AS "end_" FROM payment_schedules WHERE dataset_id=? ORDER BY id LIMIT 300`,
    detail: genericDetail('payment-schedule'),
  },
  {
    id: 'beneficiaries', title: 'Beneficiaries', headers: ['Name', 'Status', 'Owner'],
    columns: ['display_name', 'status', 'owner'],
    sql: `SELECT b.id,b.display_name,b.status,p.display_name AS owner FROM beneficiaries b JOIN parties p ON p.dataset_id=b.dataset_id AND p.id=b.owner_party_id WHERE b.dataset_id=? ORDER BY b.display_name LIMIT 300`,
    detail: genericDetail('beneficiary'),
  },
  {
    id: 'cards', title: 'Cards', headers: ['Card', 'Status', 'Account'],
    columns: ['last_four', 'status', 'account_number'],
    sql: `SELECT c.id,c.last_four,c.status,a.account_number FROM cards c JOIN accounts a ON a.dataset_id=c.dataset_id AND a.id=c.account_id WHERE c.dataset_id=? ORDER BY c.id LIMIT 300`,
    detail: genericDetail('card'),
  },
  {
    id: 'disputes', title: 'Disputes', headers: ['Case', 'State', 'Claimed'],
    columns: ['case_number', 'state', 'claimed'],
    sql: `SELECT id,case_number,state,claimed_amount_minor_units||' '||currency AS claimed FROM disputes WHERE dataset_id=? ORDER BY id LIMIT 300`,
    detail: genericDetail('dispute'),
  },
  {
    id: 'loans', title: 'Loans', headers: ['Loan', 'State', 'Principal', 'Rate'],
    columns: ['id', 'state', 'principal', 'rate'],
    sql: `SELECT id,state,principal_minor_units||' '||currency AS principal,annual_rate_bps||' bps' AS rate FROM loans WHERE dataset_id=? ORDER BY id LIMIT 300`,
    detail: genericDetail('loan'),
  },
  {
    id: 'holds', title: 'Holds', headers: ['Account', 'Amount', 'Status', 'Reason'],
    columns: ['account_number', 'amount', 'status', 'reason'],
    sql: `SELECT h.id,a.account_number,h.amount_minor_units||' '||h.currency AS amount,h.status,h.reason FROM holds h JOIN accounts a ON a.dataset_id=h.dataset_id AND a.id=h.account_id WHERE h.dataset_id=? ORDER BY h.placed_at DESC LIMIT 300`,
    detail: genericDetail('hold'),
  },
  {
    id: 'restrictions', title: 'Restrictions', headers: ['Account', 'Kind', 'Status'],
    columns: ['account_number', 'kind', 'status'],
    sql: `SELECT r.id,a.account_number,r.kind,r.status FROM restrictions r JOIN accounts a ON a.dataset_id=r.dataset_id AND a.id=r.account_id WHERE r.dataset_id=? ORDER BY r.placed_at DESC LIMIT 300`,
    detail: genericDetail('restriction'),
  },
  {
    id: 'fees', title: 'Fees', headers: ['Fee', 'Status', 'Account'],
    columns: ['id', 'status', 'account_number'],
    sql: `SELECT f.id,f.status,a.account_number FROM fees f JOIN accounts a ON a.dataset_id=f.dataset_id AND a.id=f.account_id WHERE f.dataset_id=? ORDER BY f.id LIMIT 300`,
    detail: genericDetail('fee'),
  },
  {
    id: 'batches', title: 'Batches', headers: ['Batch', 'Kind', 'State'],
    columns: ['batch_number', 'kind', 'state'],
    sql: `SELECT id,batch_number,kind,state FROM batches WHERE dataset_id=? ORDER BY created_at DESC LIMIT 300`,
    detail: genericDetail('batch'),
  },
  {
    id: 'suspense', title: 'Suspense items', headers: ['Item', 'State', 'Remaining'],
    columns: ['id', 'state', 'remaining'],
    sql: `SELECT id,state,remaining_amount_minor_units||' '||currency AS remaining FROM suspense_items WHERE dataset_id=? ORDER BY id LIMIT 300`,
    detail: genericDetail('suspense-item'),
  },
  {
    id: 'approvals', title: 'Business approvals', headers: ['Status', 'Target'],
    columns: ['status', 'target_kind'],
    sql: `SELECT id,status,json_extract(scope_json,'$.kind') AS target_kind FROM business_approvals WHERE dataset_id=? ORDER BY created_at DESC LIMIT 300`,
    detail: (env, id) => {
      const row = read(env, (database) => database.prepare('SELECT * FROM business_approvals WHERE dataset_id=? AND id=?').get(env.context.binding.datasetId, id) as Record<string, unknown> | undefined);
      if (isRejected(row)) return row;
      return row === undefined ? undefined : recordSections(row);
    },
  },
];

function sendArtifact(response: Response, artifact: DocumentArtifact): void {
  response.setHeader('content-type', artifact.mediaType);
  response.setHeader('content-disposition', `attachment; filename="${artifact.displayName.replaceAll('"', '')}"`);
  response.send(Buffer.from(artifact.bytes));
}

/**
 * Two loopback applications on distinct origins serve the same frame documents so
 * shell, workspace and register frames can nest across origins. The main app owns
 * the top-level redirect; the frame app serves documents only.
 */
export function createUiApps(options: UiOptions): { mainApp: Express; frameApp: Express } {
  const mainApp = express();
  configureUiApp(mainApp, options, true);
  const frameApp = express();
  configureUiApp(frameApp, options, false);
  return { mainApp, frameApp };
}
