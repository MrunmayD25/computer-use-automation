import { randomBytes } from 'node:crypto';
import { chmod, mkdir, rm, writeFile } from 'node:fs/promises';
import { createServer, type Server } from 'node:http';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import type { Express } from 'express';

import { DEFAULT_SEED_MANIFEST, openFinancialDatabase } from '@computer-use/financial-database';
import { openFinancialStore } from '@computer-use/financial-database/services';

import { createAdminApp } from './admin.js';
import type { EnvironmentConfig, EnvironmentHandle } from './contracts.js';
import { createInstanceStore } from './instance-store.js';
import { DEFAULT_PROFILE_ID } from './profiles.js';
import { createUiApps } from './web.js';

export type { EnvironmentConfig, EnvironmentHandle } from './contracts.js';

const host = '127.0.0.1';
const DEFAULT_WORLD = 'financial-demo-v1';
const DEFAULT_INSTITUTION = 'northstar';
const DEFAULT_OPERATORS = ['OP0001', 'OP0002', 'OP0003', 'OP0004', 'OP0005', 'OP0006', 'OP0007'] as const;
const DEFAULT_DATABASE = fileURLToPath(new URL('../.runtime/financial.sqlite', import.meta.resolve('@computer-use/financial-database')));

function listen(app: Express, port: number): Promise<Server> {
  const server = createServer(app);
  return new Promise((resolveListen, reject) => {
    const fail = (error: Error): void => reject(error);
    server.once('error', fail);
    server.listen(port, host, () => {
      server.off('error', fail);
      resolveListen(server);
    });
  });
}

function origin(server: Server): string {
  const address = server.address();
  if (address === null || typeof address === 'string') throw new Error('Listener has no TCP address.');
  return `http://${host}:${String(address.port)}`;
}

function closeServer(server: Server): Promise<void> {
  return new Promise((resolveClose, reject) => {
    server.close((error) => (error === undefined ? resolveClose() : reject(error)));
  });
}

export async function startEnvironment(config: EnvironmentConfig): Promise<EnvironmentHandle> {
  if (config.adminToken.length < 16) throw new Error('The admin token must contain at least 16 characters.');
  const databasePath = resolve(config.databasePath ?? process.env.FINANCIAL_DATABASE_PATH ?? DEFAULT_DATABASE);
  const database = openFinancialDatabase({
    path: databasePath,
    ...(config.databaseBusyTimeoutMs === undefined ? {} : { busyTimeoutMs: config.databaseBusyTimeoutMs }),
  });
  // The named demo world is idempotent: seeding an identical manifest returns the existing bindings.
  const world = config.world ?? DEFAULT_WORLD;
  if (database.getNamedWorld(world).length === 0) {
    if (world !== DEFAULT_SEED_MANIFEST.name) throw new Error(`World "${world}" is not seeded in ${databasePath}.`);
    await database.seedWorld(DEFAULT_SEED_MANIFEST);
  }
  const store = openFinancialStore({ path: databasePath, ...(config.databaseBusyTimeoutMs === undefined ? {} : { busyTimeoutMs: config.databaseBusyTimeoutMs }) });
  let mainOrigin = '';
  let frameOrigin = '';
  const servers: Server[] = [];
  try {
    const instanceStore = createInstanceStore({
      store,
      database,
      world,
      institutionId: config.institutionId ?? DEFAULT_INSTITUTION,
      operators: config.operators ?? DEFAULT_OPERATORS,
      principalKind: 'human',
      ...(config.exportDestinations === undefined ? { exportDestinations: ['download', 'operator-console-export'] } : { exportDestinations: config.exportDestinations }),
      ...(config.maxInstances === undefined ? {} : { maxInstances: config.maxInstances }),
    });
    const demo =
      config.demo === false
        ? undefined
        : instanceStore.create({ world, institutionId: config.institutionId ?? DEFAULT_INSTITUTION, profile: DEFAULT_PROFILE_ID });
    const { mainApp, frameApp } = createUiApps({
      store: instanceStore,
      mainOrigin: () => mainOrigin,
      frameOrigin: () => frameOrigin,
      demoEntryPath: () => demo?.entryUrl ?? '/unavailable',
    });
    const adminApp = createAdminApp({
      store: instanceStore,
      adminToken: config.adminToken,
      mainOrigin: () => mainOrigin,
    });
    const mainServer = await listen(mainApp, config.port ?? 4310);
    servers.push(mainServer);
    mainOrigin = origin(mainServer);
    const frameServer = await listen(frameApp, config.framePort ?? 4311);
    servers.push(frameServer);
    frameOrigin = origin(frameServer);
    const adminServer = await listen(adminApp, config.adminPort ?? 4312);
    servers.push(adminServer);
    const origins = { main: mainOrigin, frame: frameOrigin, admin: origin(adminServer) };
    if (config.verbose === true) {
      console.error(`Meridian Core UI: ${origins.main}`);
      console.error(`Meridian Core frame origin: ${origins.frame}`);
      console.error(`Meridian Core admin: ${origins.admin}`);
      console.error(`Financial world: ${world} (${databasePath})`);
    }
    let closed = false;
    return {
      origins,
      async close() {
        if (closed) return;
        closed = true;
        try {
          await Promise.all(servers.toReversed().map(closeServer));
        } finally {
          store.close();
          database.close();
        }
      },
    };
  } catch (error) {
    await Promise.allSettled(servers.toReversed().map(closeServer));
    store.close();
    database.close();
    throw error;
  }
}

interface CliOptions {
  port: number;
  framePort: number;
  adminPort: number;
  adminTokenFile: string;
  verbose: boolean;
  databasePath?: string;
  world?: string;
}

function parsePort(value: string | undefined, flag: string): number {
  const port = Number(value);
  if (!Number.isInteger(port) || port < 0 || port > 65_535) {
    throw new Error(`${flag} requires a port from 0 through 65535.`);
  }
  return port;
}

function parseCli(arguments_: readonly string[]): CliOptions {
  const options: CliOptions = {
    port: 4310,
    framePort: 4311,
    adminPort: 4312,
    adminTokenFile: '.runtime/admin.token',
    verbose: false,
  };
  for (let index = 0; index < arguments_.length; index += 1) {
    const argument = arguments_[index];
    switch (argument) {
      case '--port':
        options.port = parsePort(arguments_[++index], '--port');
        break;
      case '--frame-port':
        options.framePort = parsePort(arguments_[++index], '--frame-port');
        break;
      case '--admin-port':
        options.adminPort = parsePort(arguments_[++index], '--admin-port');
        break;
      case '--admin-token-file': {
        const value = arguments_[++index];
        if (value === undefined || value.trim() === '') throw new Error('--admin-token-file requires a path.');
        options.adminTokenFile = value;
        break;
      }
      case '--database': {
        const value = arguments_[++index];
        if (value === undefined || value.trim() === '') throw new Error('--database requires a path.');
        options.databasePath = resolve(value);
        break;
      }
      case '--world': {
        const value = arguments_[++index];
        if (value === undefined || value.trim() === '') throw new Error('--world requires a name.');
        options.world = value;
        break;
      }
      case '--verbose':
        options.verbose = true;
        break;
      default:
        throw new Error(`Unknown option: ${argument ?? ''}`);
    }
  }
  return options;
}

async function runCli(): Promise<void> {
  const options = parseCli(process.argv.slice(2));
  const token = randomBytes(32).toString('base64url');
  const tokenPath = resolve(options.adminTokenFile);
  await mkdir(dirname(tokenPath), { recursive: true, mode: 0o700 });
  await writeFile(tokenPath, `${token}\n`, { mode: 0o600 });
  await chmod(tokenPath, 0o600);
  let environment: EnvironmentHandle;
  try {
    environment = await startEnvironment({
      port: options.port,
      framePort: options.framePort,
      adminPort: options.adminPort,
      adminToken: token,
      verbose: options.verbose,
      ...(options.databasePath === undefined ? {} : { databasePath: options.databasePath }),
      ...(options.world === undefined ? {} : { world: options.world }),
    });
  } catch (error) {
    await rm(tokenPath, { force: true });
    throw error;
  }
  console.error(`Meridian Core is available at ${environment.origins.main}`);
  console.error(`Admin token written to ${tokenPath}`);
  const shutdown = async (): Promise<void> => {
    await environment.close();
    process.exitCode = 0;
  };
  process.once('SIGINT', () => void shutdown());
  process.once('SIGTERM', () => void shutdown());
}

if (import.meta.main) {
  runCli().catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : 'Meridian Core failed to start.');
    process.exitCode = 1;
  });
}
