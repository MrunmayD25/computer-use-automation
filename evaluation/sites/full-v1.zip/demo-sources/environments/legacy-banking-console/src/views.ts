import Handlebars from 'handlebars';

import type { StructuralProfile } from './profiles.js';

export interface RenderContext {
  capability: string;
  mainOrigin: string;
  frameOrigin: string;
  profile: StructuralProfile;
  csrfToken: string;
  documentId: string;
  institutionName: string;
  operator: string;
  notice?: string;
  error?: string;
}

export interface Link {
  text: string;
  href: string;
  target?: string;
}

export interface Cell {
  text: string;
  link?: Link;
}

export interface Field {
  name: string;
  label: string;
  value: string;
  id: string;
  type: string;
  required: boolean;
  multiline?: boolean;
  multiple?: boolean;
  checked?: boolean;
  help?: string;
  options?: { value: string; label: string; selected: boolean }[];
}

export interface FormModel {
  action: string;
  method: 'get' | 'post';
  submit: string;
  fields: Field[];
  hidden: { name: string; value: string }[];
  imageSubmit?: boolean;
}

export interface Section {
  title: string;
  facts?: { label: string; value: string }[];
  links?: Link[];
  headers?: string[];
  rows?: Cell[][];
  empty?: string;
  form?: FormModel;
  text?: string;
  frame?: { src: string; title: string };
}

/** Everything a document renders; web.ts composes sections per page. */
export interface PageModel {
  title: string;
  identity?: string;
  sections: Section[];
  /** Renders as an embedded register document (no chrome, no navigation). */
  embedded?: boolean;
  /** Includes the misleading hidden duplicate control block. */
  hiddenDuplicate?: boolean;
}

const pageTemplate = Handlebars.compile(`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{title}} | Meridian Core</title><link rel="stylesheet" href="/assets/meridian.css">{{#if weak}}<script src="/assets/legacy.js" defer></script>{{/if}}</head>
<body class="document {{classes}}{{#if embedded}} account-register-document{{/if}}">
<div class="document-caption"><span>MERIDIAN CORE</span><span>{{institutionName}} · Member Services</span></div>
{{#unless embedded}}
<nav class="toolbar" aria-label="Modules">{{#each navigation}}<a href="{{href}}">{{text}}</a>{{/each}}</nav>
{{/unless}}
<main><div class="page-heading"><h1>{{title}}</h1><span class="module-code">{{operator}}</span></div>
{{#if identity}}<div class="identity-strip">{{identity}}</div>{{/if}}
{{#if notice}}<div class="notice" role="status">{{notice}}</div>{{/if}}
{{#if error}}<div class="error" role="alert">{{error}}</div>{{/if}}
{{#each sections}}<section class="inset-panel"><h2>{{title}}</h2>
{{#if frame}}<iframe class="account-register-frame" title="{{frame.title}}" src="{{frame.src}}"></iframe>{{/if}}
{{#if text}}<p class="section-text">{{text}}</p>{{/if}}
{{#if facts}}<table class="facts"><tbody>{{#each facts}}<tr><td class="fact-label">{{label}}</td><td>{{value}}</td></tr>{{/each}}</tbody></table>{{/if}}
{{#if links}}<div class="action-strip">{{#each links}}<a class="command-link" href="{{href}}"{{#if target}} target="{{target}}"{{/if}}>{{#if @root.weak}}<span class="command-glyph" aria-hidden="true">▣</span>{{/if}}{{text}}</a>{{/each}}</div>{{/if}}
{{#if headers}}<div class="register-scroll"><table class="register"><thead><tr>{{#each headers}}<th scope="col">{{this}}</th>{{/each}}</tr></thead><tbody>
{{#each rows}}<tr>{{#each this}}<td>{{#if link}}{{#if @root.weak}}<span class="row-command generic-command" tabindex="0" data-href="{{link.href}}"{{#if link.target}} data-target="{{link.target}}"{{/if}}>{{link.text}}</span>{{else}}<a class="row-command" href="{{link.href}}"{{#if link.target}} target="{{link.target}}"{{/if}}>{{link.text}}</a>{{/if}}{{else}}{{text}}{{/if}}</td>{{/each}}</tr>{{else}}<tr><td class="empty" colspan="12">{{empty}}</td></tr>{{/each}}</tbody></table></div>{{/if}}
{{#if form}}<form class="maintenance-form" action="{{form.action}}" method="{{form.method}}">
{{#each form.hidden}}<input type="hidden" name="{{name}}" value="{{value}}">{{/each}}
<table class="form-grid"><tbody>{{#each form.fields}}<tr><td>{{#if @root.weak}}<span>{{label}}</span>{{else}}<label for="{{id}}">{{label}}</label>{{/if}}</td><td>
{{#if options}}<select name="{{name}}" id="{{id}}"{{#if multiple}} multiple size="6"{{/if}}{{#if required}} required{{/if}}>{{#each options}}<option value="{{value}}"{{#if selected}} selected{{/if}}>{{label}}</option>{{/each}}</select>
{{else}}{{#if multiline}}<textarea name="{{name}}" id="{{id}}" rows="4" maxlength="8000"{{#if required}} required{{/if}}>{{value}}</textarea>
{{else}}{{#if checkbox}}<input type="checkbox" name="{{name}}" id="{{id}}" value="yes"{{#if checked}} checked{{/if}}>
{{else}}<input type="{{type}}" name="{{name}}" id="{{id}}" value="{{value}}" maxlength="250"{{#if required}} required{{/if}}>{{/if}}{{/if}}{{/if}}
{{#if help}}<div class="field-help">{{help}}</div>{{/if}}
</td></tr>{{/each}}</tbody></table><div class="form-actions">{{#if form.imageSubmit}}<span class="image-submit"><input type="image" alt="" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Crect width='24' height='24' fill='%23e0dfd6'/%3E%3Ccircle cx='10' cy='10' r='6' fill='%23f8f8ed' stroke='%2323394d' stroke-width='2'/%3E%3Cpath d='M14 14L21 21' stroke='%2323394d' stroke-width='3'/%3E%3C/svg%3E"><span>{{form.submit}}</span></span>{{else}}<button type="submit">{{form.submit}}</button>{{/if}}</div></form>{{/if}}
</section>{{/each}}
{{#if hiddenDuplicate}}<div hidden aria-hidden="true"><form><label>Member Search <input name="query" tabindex="-1" disabled></label><button disabled tabindex="-1">Open member</button><input name="amount" disabled tabindex="-1"><button disabled tabindex="-1">Review deposit</button></form></div>{{/if}}
</main>{{#unless embedded}}<footer class="status-strip"><span>{{institutionName}}</span><span>Ready · {{operator}}</span></footer>{{/unless}}</body></html>`);

const shellTemplate = Handlebars.compile(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Meridian Core | {{institutionName}}</title><link rel="stylesheet" href="/assets/meridian.css"></head><body class="shell {{classes}}"><header class="title-strip"><strong>MERIDIAN <span>CORE</span></strong><span>{{institutionName}}</span><span class="operator">{{operator}}</span></header><nav class="shell-menu" aria-label="Operations">{{#each navigation}}<a href="{{href}}" target="work">{{text}}</a>{{/each}}</nav><div class="shell-body"><aside><h2>Services</h2>{{#each navigation}}<a href="{{href}}" target="work">{{text}}</a>{{/each}}<div class="branch-label">Member operations<br>{{institutionName}}</div></aside><div class="frame-clip"><iframe name="workspace" title="Member services workspace" src="{{src}}"></iframe></div></div><footer class="status-strip"><span>Meridian Core · Operations</span><span>Ready</span></footer></body></html>`);

const workspaceTemplate = Handlebars.compile(`<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{{caption}}</title><link rel="stylesheet" href="/assets/meridian.css"></head><body class="workspace {{classes}}"><div class="workspace-caption">{{caption}}</div><iframe name="{{name}}" title="{{title}}" src="{{src}}"></iframe></body></html>`);

export function basePath(context: RenderContext): string {
  return `/app/${encodeURIComponent(context.capability)}`;
}

export function navigation(context: RenderContext): Link[] {
  return ([
    ['Member Search', '/search'], ['Members', '/members'], ['Accounts', '/accounts'],
    ['Documents', '/documents'], ['Cases', '/cases'], ['Operations', '/operations'],
    ['Approvals', '/approvals'], ['Registers', '/registers'], ['Activity', '/activity'], ['Operator', '/operator'],
  ] as const).map(([text, path]) => ({ text, href: `${basePath(context)}${path}` }));
}

function classes(context: RenderContext): string {
  return Object.entries(context.profile.features).filter(([, enabled]) => enabled).map(([name]) => name).join(' ');
}

export function renderPage(model: PageModel, context: RenderContext): string {
  return pageTemplate({
    title: model.title,
    identity: model.identity ?? '',
    sections: model.sections,
    navigation: navigation(context),
    classes: classes(context),
    institutionName: context.institutionName,
    operator: context.operator,
    notice: context.notice,
    error: context.error,
    weak: context.profile.features.weakSemantics,
    hiddenDuplicate: model.hiddenDuplicate === true || context.profile.features.hiddenDuplicates,
    embedded: model.embedded === true,
  });
}

export function renderShell(context: RenderContext): string {
  const origin = context.profile.features.crossOrigin ? context.frameOrigin : context.mainOrigin;
  return shellTemplate({ classes: classes(context), navigation: navigation(context), src: `${origin}${basePath(context)}/workspace`, institutionName: context.institutionName, operator: context.operator });
}

export function renderWorkspace(context: RenderContext, level = 0): string {
  const nested = context.profile.features.deepFrames && level < 2;
  const origin = context.profile.features.crossOrigin && level % 2 !== 0 ? context.frameOrigin : context.mainOrigin;
  const caption = ['Operations desk', 'Member services', 'Record workspace'][level] ?? 'Record workspace';
  return workspaceTemplate({ caption, classes: classes(context), name: nested ? `workspace-${String(level + 1)}` : 'work', title: nested ? 'Member services document container' : 'Member operations', src: `${origin}${basePath(context)}${nested ? `/workspace?level=${String(level + 1)}` : '/search'}` });
}

// ---------- view helpers used by web.ts ----------

export function textCell(text: string): Cell {
  return { text };
}

export function linkCell(context: RenderContext, text: string, path: string, target?: string): Cell {
  return { text, link: { text, href: `${basePath(context)}${path}`, ...(target === undefined ? {} : { target }) } };
}

export function link(context: RenderContext, text: string, path: string, target?: string): Link {
  return { text, href: `${basePath(context)}${path}`, ...(target === undefined ? {} : { target }) };
}

export function absoluteLink(_context: RenderContext, text: string, href: string, target?: string): Link {
  return { text, href, ...(target === undefined ? {} : { target }) };
}

export function field(context: RenderContext, name: string, label: string, value = '', type = 'text', required = true, help?: string): Field {
  return {
    name, label, value, type, required, ...(help === undefined ? {} : { help }),
    id: `${context.profile.features.generatedIds ? context.documentId : 'field'}-${name}`,
  };
}

export function selectField(context: RenderContext, name: string, label: string, options: { value: string; label: string }[], value = '', required = true, help?: string, multiple = false): Field {
  return {
    ...field(context, name, label, value, 'text', required, help),
    multiple,
    options: options.map((option) => ({ value: option.value, label: option.label, selected: option.value === value || (multiple && value.split(',').includes(option.value)) })),
  };
}

export function checkField(context: RenderContext, name: string, label: string, checked = false): Field {
  return { ...field(context, name, label, '', 'checkbox', false), checked };
}

/** A maintenance form with the session bindings every post needs. */
export function form(context: RenderContext, path: string, submit: string, fields: Field[], hidden: Record<string, string> = {}, method: 'get' | 'post' = 'post'): FormModel {
  return {
    action: `${basePath(context)}${path}`, method, submit, fields,
    hidden: Object.entries(method === 'post' ? { ...hidden, csrfToken: context.csrfToken, formNonce: context.documentId } : hidden).map(([name, value]) => ({ name, value })),
    ...(context.profile.features.weakSemantics ? { imageSubmit: true } : {}),
  };
}

export function money(minorUnits: number, currency = 'USD'): string {
  const minor = BigInt(Math.trunc(minorUnits));
  const absolute = minor < 0n ? -minor : minor;
  const whole = absolute / 100n;
  const cents = String(absolute % 100n).padStart(2, '0');
  const formatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(whole);
  return `${minor < 0n ? '-' : ''}${formatted}.${cents} ${currency}`;
}
