import { timingSafeEqual } from 'node:crypto';

import express, { type Express, type NextFunction, type Request, type Response } from 'express';
import { z } from 'zod';

import { PROFILE_IDS } from './profiles.js';
import type { InstanceStore } from './instance-store.js';

const profileSchema = z.enum(PROFILE_IDS);
const institutionSchema = z.string().regex(/^[a-z][a-z0-9-]*$/u).max(64);

const createInstanceSchema = z.union([
  z.strictObject({
    seed: z.number().int().min(0).max(0x7fff_ffff),
    profile: profileSchema,
    institutionId: institutionSchema.optional(),
  }),
  z.strictObject({
    datasetId: z.string().min(1).max(200),
    profile: profileSchema,
  }),
  z.strictObject({
    world: z.string().min(1).max(120),
    institutionId: institutionSchema.optional(),
    profile: profileSchema,
  }),
]);

function tokenMatches(value: string | undefined, expected: string): boolean {
  const prefix = 'Bearer ';
  if (value === undefined || !value.startsWith(prefix)) return false;
  const actualBuffer = Buffer.from(value.slice(prefix.length));
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length && timingSafeEqual(actualBuffer, expectedBuffer);
}

function isBrowserRequest(request: Request): boolean {
  return (
    request.headers.origin !== undefined ||
    request.headers['sec-fetch-site'] !== undefined ||
    request.headers['sec-fetch-dest'] !== undefined ||
    request.headers['sec-fetch-user'] !== undefined
  );
}

function hasAllowedHost(request: Request): boolean {
  const host = request.headers.host?.toLowerCase();
  if (host === undefined) return false;
  return /^(127\.0\.0\.1|localhost):\d+$/u.test(host);
}

export function createAdminApp(options: {
  store: InstanceStore;
  adminToken: string;
  mainOrigin: () => string;
}): Express {
  const app = express();
  app.disable('x-powered-by');
  app.use((request, response, next) => {
    response.setHeader('cache-control', 'no-store');
    if (!tokenMatches(request.headers.authorization, options.adminToken)) {
      response.status(401).json({ error: 'Unauthorized' });
      return;
    }
    if (isBrowserRequest(request)) {
      response.status(403).json({ error: 'Browser requests are forbidden' });
      return;
    }
    if (!hasAllowedHost(request)) {
      response.status(403).json({ error: 'Invalid Host header' });
      return;
    }
    next();
  });
  app.use(express.json({ limit: '4kb', strict: true, type: 'application/json' }));

  app.get('/worlds', (_request, response) => {
    response.json({ worlds: options.store.worlds() });
  });

  app.post('/instances', (request, response) => {
    const parsed = createInstanceSchema.safeParse(request.body);
    if (!parsed.success) {
      response.status(400).json({ error: 'Invalid instance request', issues: parsed.error.issues });
      return;
    }
    try {
      const created = options.store.create(parsed.data);
      response.status(201).json({
        instanceId: created.instanceId,
        entryUrl: `${options.mainOrigin()}${created.entryUrl}`,
        institutionId: created.institutionId,
        datasetId: created.datasetId,
      });
    } catch (error) {
      if (error instanceof Error && error.message.includes('capacity')) {
        response.status(429).json({ error: error.message });
        return;
      }
      if (error instanceof Error && (error.message === 'Unknown dataset.' || error.message.includes('not seeded') || error.message.includes('has no'))) {
        response.status(404).json({ error: error.message });
        return;
      }
      throw error;
    }
  });

  app.get('/instances/:instanceId/state', (request, response) => {
    try {
      response.json(options.store.snapshot(request.params.instanceId));
    } catch (error) {
      if (error instanceof Error && error.message === 'Unknown instance.') {
        response.status(404).json({ error: 'Unknown instance' });
        return;
      }
      throw error;
    }
  });

  app.get('/instances/:instanceId/export', (request, response) => {
    try {
      const snapshot = options.store.snapshot(request.params.instanceId);
      response.setHeader(
        'content-disposition',
        `attachment; filename="meridian-${snapshot.instanceId}.json"`,
      );
      response.json(snapshot);
    } catch (error) {
      if (error instanceof Error && error.message === 'Unknown instance.') {
        response.status(404).json({ error: 'Unknown instance' });
        return;
      }
      throw error;
    }
  });

  app.post('/instances/:instanceId/reset', (request, response) => {
    try {
      const replacement = options.store.reset(request.params.instanceId);
      response.status(201).json({
        instanceId: replacement.instanceId,
        entryUrl: `${options.mainOrigin()}${replacement.entryUrl}`,
        institutionId: replacement.institutionId,
        datasetId: replacement.datasetId,
      });
    } catch (error) {
      if (error instanceof Error && error.message === 'Unknown instance.') {
        response.status(404).json({ error: 'Unknown instance' });
        return;
      }
      throw error;
    }
  });

  app.delete('/instances/:instanceId', (request, response) => {
    try {
      options.store.snapshot(request.params.instanceId);
      options.store.dispose(request.params.instanceId);
      response.status(204).end();
    } catch (error) {
      if (error instanceof Error && error.message === 'Unknown instance.') {
        response.status(404).json({ error: 'Unknown instance' });
        return;
      }
      throw error;
    }
  });

  app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
    if (error instanceof SyntaxError || (error instanceof Error && error.message.includes('too large'))) {
      response.status(400).json({ error: 'Invalid JSON body' });
      return;
    }
    console.error('Administration request failed.', error);
    response.status(500).json({ error: 'Administration request failed' });
  });
  return app;
}
