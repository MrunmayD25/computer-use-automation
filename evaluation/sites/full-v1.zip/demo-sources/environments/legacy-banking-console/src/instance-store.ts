import { createHash, randomBytes } from 'node:crypto';

import {
  type DatasetBinding,
  type FinancialDatabase,
  type SeedScale,
} from '@computer-use/financial-database';
import {
  executeCommand,
  reviewCommand,
  type CommandOutcome,
  type FinancialStore,
  type OperationReview,
  type Rejection,
  type ReviewOutcome,
  type ServiceCommand,
  type ServiceContext,
} from '@computer-use/financial-database/services';

import type {
  CreatedInstance,
  CreateInstanceRequest,
  InstanceSnapshot,
  ProfileId,
} from './contracts.js';

/** One reviewable operation an operator confirmed on screen but has not posted yet. */
export interface PendingReview {
  token: string;
  command: ServiceCommand;
  review: OperationReview;
  idempotencyKey: string;
  createdAt: number;
}

/** The settled outcome of a posted review, kept so a retried commit recovers the same receipt. */
export interface SettledReview {
  command: ServiceCommand;
  idempotencyKey: string;
  outcome: CommandOutcome;
  settledAt: number;
}

type InstanceSource =
  | { kind: 'seed'; seed: number; scale: SeedScale }
  | { kind: 'attach'; datasetId: string }
  | { kind: 'world'; world: string };

export interface Instance {
  instanceId: string;
  capability: string;
  csrfToken: string;
  profile: ProfileId;
  binding: DatasetBinding;
  actorNumber: string;
  source: InstanceSource;
  pending: Map<string, PendingReview>;
  settled: Map<string, SettledReview>;
  createdAt: string;
}

export interface SessionContext {
  instance: Instance;
  context: ServiceContext;
}

export type ReviewTicket = { kind: 'reviewable'; token: string; review: OperationReview } | Exclude<ReviewOutcome, { kind: 'reviewable' }>;

export type CommitResult = CommandOutcome | { kind: 'missing' } | Rejection;

export interface StoreOptions {
  store: FinancialStore;
  /** Present in ordinary mode; enables seed templates and isolated clones. */
  database?: FinancialDatabase;
  world: string;
  institutionId: string;
  operators: readonly string[];
  principalKind?: NonNullable<ServiceContext['principalKind']>;
  exportDestinations?: readonly string[];
  maxInstances?: number;
  maxReviews?: number;
  maxSettled?: number;
}

const REVIEW_TTL_MS = 30 * 60_000;

function generated(prefix: string, length = 10): string {
  return `${prefix}-${randomBytes(length).toString('hex')}`;
}

/** Stable operation key: one intent, one key. Re-posting the same rendered form reuses it. */
function idempotencyKey(instance: Instance, nonce: string, command: ServiceCommand): string {
  const digest = createHash('sha256')
    .update(instance.capability)
    .update('\n')
    .update(nonce)
    .update('\n')
    .update(JSON.stringify(command))
    .digest('hex');
  return `mc-${digest.slice(0, 40)}`;
}

export function createInstanceStore(options: StoreOptions) {
  const maxInstances = options.maxInstances ?? 32;
  const maxReviews = options.maxReviews ?? 64;
  const maxSettled = options.maxSettled ?? 128;
  const exportDestinations = [...(options.exportDestinations ?? ['operator-console-export'])];
  const operators = [...options.operators];
  const instances = new Map<string, Instance>();

  function datasetInfo(datasetId: string): { institutionId: string; seed: number; scale: SeedScale } | undefined {
    return options.store.read((database) => {
      const row = database
        .prepare('SELECT institution_id AS institutionId, seed, scale FROM datasets WHERE id=?')
        .get(datasetId) as { institutionId?: string; seed?: number; scale?: string } | undefined;
      if (row?.institutionId === undefined || row.seed === undefined || row.scale === undefined) return undefined;
      return { institutionId: row.institutionId, seed: row.seed, scale: row.scale as SeedScale };
    });
  }

  function worldBindings(world: string): readonly DatasetBinding[] {
    if (options.database === undefined) throw new Error('This store cannot list named worlds.');
    const bindings = options.database.getNamedWorld(world);
    if (bindings.length === 0) throw new Error(`The financial world "${world}" is not seeded in this database.`);
    return bindings;
  }

  function bindWorldInstitution(world: string, institutionId: string): DatasetBinding {
    const binding = worldBindings(world).find((item) => item.institutionId === institutionId);
    if (binding === undefined) throw new Error(`World "${world}" has no ${institutionId} dataset.`);
    return binding;
  }

  /** A fresh isolated copy of the configured world for the requested institution. */
  function isolatedBinding(institutionId: string): DatasetBinding {
    if (options.database === undefined) throw new Error('This store cannot clone datasets.');
    return options.database.cloneDataset(bindWorldInstitution(options.world, institutionId));
  }

  function bindingFor(request: CreateInstanceRequest): { binding: DatasetBinding; source: InstanceSource } {
    const institutionId = 'institutionId' in request && request.institutionId !== undefined ? request.institutionId : options.institutionId;
    if ('seed' in request) {
      const binding = isolatedBinding(institutionId);
      return { binding, source: { kind: 'seed', seed: request.seed, scale: 'small' } };
    }
    if ('datasetId' in request) {
      const info = datasetInfo(request.datasetId);
      if (info === undefined) throw new Error('Unknown dataset.');
      return { binding: { institutionId: info.institutionId as DatasetBinding['institutionId'], datasetId: request.datasetId as DatasetBinding['datasetId'] }, source: { kind: 'attach', datasetId: request.datasetId } };
    }
    return { binding: bindWorldInstitution(request.world, institutionId), source: { kind: 'world', world: request.world } };
  }

  function adopt(binding: DatasetBinding, profile: ProfileId, source: InstanceSource): Instance {
    if (instances.size >= maxInstances) throw new Error('Instance capacity reached. Dispose of an instance before creating another.');
    const instance: Instance = {
      instanceId: generated('inst', 8),
      capability: generated('cap'),
      csrfToken: randomBytes(24).toString('base64url'),
      profile,
      binding,
      actorNumber: operators[0] ?? '',
      source,
      pending: new Map(),
      settled: new Map(),
      createdAt: new Date().toISOString(),
    };
    instances.set(instance.instanceId, instance);
    return instance;
  }

  function byCapability(capability: string): Instance {
    for (const instance of instances.values()) if (instance.capability === capability) return instance;
    throw new Error('Unknown or expired UI capability.');
  }

  function byId(instanceId: string): Instance {
    const instance = instances.get(instanceId);
    if (instance === undefined) throw new Error('Unknown instance.');
    return instance;
  }

  /** Resolves the session's trusted actor identity; never taken from browser input. */
  function contextOf(instance: Instance): ServiceContext {
    const actorId = options.store.read((database) => {
      const row = database
        .prepare('SELECT id FROM actors WHERE dataset_id=? AND actor_number=?')
        .get(instance.binding.datasetId, instance.actorNumber) as { id?: string } | undefined;
      if (row?.id === undefined) throw new Error(`Operator ${instance.actorNumber} is not registered in this institution's dataset.`);
      return row.id;
    });
    return {
      binding: instance.binding,
      actorId,
      ...(options.principalKind === undefined ? {} : { principalKind: options.principalKind }),
      reference: `meridian-core:${instance.instanceId}`,
    };
  }

  function snapshot(instance: Instance): InstanceSnapshot {
    const source =
      instance.source.kind === 'seed'
        ? `seed ${instance.source.seed} (${instance.source.scale})`
        : instance.source.kind === 'world'
          ? `world ${instance.source.world}`
          : `dataset ${instance.source.datasetId}`;
    const revision = options.store.read((database) =>
      (database.prepare('SELECT revision FROM datasets WHERE id=?').get(instance.binding.datasetId) as { revision: number } | undefined)?.revision ?? 0);
    return {
      instanceId: instance.instanceId,
      profile: instance.profile,
      institutionId: instance.binding.institutionId,
      datasetId: instance.binding.datasetId,
      actorNumber: instance.actorNumber,
      source,
      createdAt: instance.createdAt,
      pendingReviews: instance.pending.size,
      revision,
      settledReceipts: instance.settled.size,
    };
  }

  function expire(instance: Instance): void {
    const cutoff = Date.now() - REVIEW_TTL_MS;
    for (const [token, ticket] of instance.pending) if (ticket.createdAt < cutoff) instance.pending.delete(token);
    while (instance.pending.size >= maxReviews) {
      const oldest = [...instance.pending.entries()].sort((a, b) => a[1].createdAt - b[1].createdAt)[0];
      if (oldest === undefined) break;
      instance.pending.delete(oldest[0]);
    }
    while (instance.settled.size >= maxSettled) {
      const oldest = [...instance.settled.entries()].sort((a, b) => a[1].settledAt - b[1].settledAt)[0];
      if (oldest === undefined) break;
      instance.settled.delete(oldest[0]);
    }
  }

  const store = {
    create(request: CreateInstanceRequest): CreatedInstance {
      const { binding, source } = bindingFor(request);
      const instance = adopt(binding, request.profile, source);
      return { instanceId: instance.instanceId, entryUrl: `/app/${encodeURIComponent(instance.capability)}/shell`, institutionId: binding.institutionId, datasetId: binding.datasetId };
    },
    byCapability,
    byId,
    snapshot(instanceId: string): InstanceSnapshot {
      return snapshot(byId(instanceId));
    },
    list(): InstanceSnapshot[] {
      return [...instances.values()].map(snapshot);
    },
    csrfToken(capability: string): string {
      return byCapability(capability).csrfToken;
    },
    exportDestinations(): readonly string[] {
      return exportDestinations;
    },
    session(capability: string): SessionContext {
      const instance = byCapability(capability);
      return { instance, context: contextOf(instance) };
    },
    /** The bound shared financial store backing every instance. */
    financial(): FinancialStore {
      return options.store;
    },
    /** Named seeded worlds available for instance attachment, with their institution bindings. */
    worlds(): { name: string; bindings: readonly DatasetBinding[] }[] {
      if (options.database === undefined) return [];
      const names = options.store.read((database) =>
        (database.prepare('SELECT name FROM worlds ORDER BY name').all() as { name: string }[]).map((row) => row.name));
      return names.map((name) => ({ name, bindings: options.database === undefined ? [] : options.database.getNamedWorld(name) }));
    },
    /** A pending review ticket for the approval or cancellation surfaces. */
    pendingFor(capability: string, token: string): PendingReview | undefined {
      const instance = byCapability(capability);
      expire(instance);
      return instance.pending.get(token);
    },
    /** Discard a pending review without posting. Returns false when absent. */
    cancelReview(capability: string, token: string): boolean {
      const instance = byCapability(capability);
      return instance.pending.delete(token);
    },
    operators(capability: string): { actorNumber: string; displayName: string; status: string; current: boolean }[] {
      const instance = byCapability(capability);
      return options.store.read((database) =>
        (database.prepare('SELECT actor_number AS actorNumber, display_name AS displayName, status FROM actors WHERE dataset_id=? ORDER BY actor_number').all(instance.binding.datasetId) as { actorNumber: string; displayName: string; status: string }[])
          .map((actor) => ({ ...actor, current: actor.actorNumber === instance.actorNumber }))
          .filter((actor) => operators.includes(actor.actorNumber)),
      );
    },
    switchOperator(capability: string, actorNumber: string): void {
      const instance = byCapability(capability);
      if (!operators.includes(actorNumber)) throw new Error('The requested operator is not authorized for this console.');
      instance.actorNumber = actorNumber;
      instance.pending.clear();
    },
    review(capability: string, nonce: string, command: ServiceCommand): ReviewTicket {
      const instance = byCapability(capability);
      expire(instance);
      const outcome = reviewCommand(options.store, contextOf(instance), command);
      if (outcome.kind !== 'reviewable') return outcome;
      const token = generated('rv', 12);
      instance.pending.set(token, {
        token,
        command,
        review: outcome.review,
        idempotencyKey: idempotencyKey(instance, nonce, command),
        createdAt: Date.now(),
      });
      return { kind: 'reviewable', token, review: outcome.review };
    },
    commit(capability: string, token: string): CommitResult {
      const instance = byCapability(capability);
      expire(instance);
      const settled = instance.settled.get(token);
      if (settled !== undefined) return settled.outcome;
      const pending = instance.pending.get(token);
      if (pending === undefined) return { kind: 'missing' };
      const outcome = executeCommand(options.store, contextOf(instance), pending.command, pending.idempotencyKey);
      if (outcome.kind === 'committed' || outcome.kind === 'duplicate') {
        instance.pending.delete(token);
        instance.settled.set(token, { command: pending.command, idempotencyKey: pending.idempotencyKey, outcome, settledAt: Date.now() });
      }
      return outcome;
    },
    /** Re-checks a committed key when the acknowledgement was lost: durable receipt reconciliation. */
    receiptForKey(capability: string, key: string): string | null {
      const instance = byCapability(capability);
      return options.store.read((database) => {
        const row = database
          .prepare('SELECT r.receipt_number AS receiptNumber FROM operations o JOIN operation_receipts r ON r.dataset_id=o.dataset_id AND r.operation_id=o.id WHERE o.dataset_id=? AND o.idempotency_key=?')
          .get(instance.binding.datasetId, key) as { receiptNumber?: string } | undefined;
        return row?.receiptNumber ?? null;
      });
    },
    reset(instanceId: string): CreatedInstance {
      const existing = byId(instanceId);
      // Reset only affects the requesting instance: a fresh clone of the source seed
      // for isolated instances, re-attachment for shared worlds, a private copy for
      // attached datasets. Peer datasets are never touched.
      let binding: DatasetBinding;
      let source: InstanceSource;
      if (existing.source.kind === 'seed') {
        binding = isolatedBinding(existing.binding.institutionId);
        source = existing.source;
      } else if (existing.source.kind === 'world') {
        binding = bindWorldInstitution(existing.source.world, existing.binding.institutionId);
        source = existing.source;
      } else {
        if (options.database === undefined) throw new Error('This store cannot clone datasets.');
        binding = options.database.cloneDataset(existing.binding);
        source = existing.source;
      }
      instances.delete(existing.instanceId);
      const instance = adopt(binding, existing.profile, source);
      return { instanceId: instance.instanceId, entryUrl: `/app/${encodeURIComponent(instance.capability)}/shell`, institutionId: binding.institutionId, datasetId: binding.datasetId };
    },
    dispose(instanceId: string): void {
      byId(instanceId);
      instances.delete(instanceId);
    },
  };
  return store;
}

export type InstanceStore = ReturnType<typeof createInstanceStore>;
