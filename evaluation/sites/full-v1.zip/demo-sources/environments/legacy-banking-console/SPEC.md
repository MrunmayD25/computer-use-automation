# Legacy banking console application

## Purpose and scope

Build a complete local member-servicing application with a deliberately difficult legacy interface. It must support ordinary independent banking operations so future agents can compose their own workflows.

There are no benchmark goals, prescribed task sequences, expected answers, grading endpoints, capability artifacts, or agent loops inside this application. Workflow design and grading belong to a separate future verification layer. Functional tests check application behavior and do not define the agent's task contract.

Each application owns a subfolder beneath `environments/`. This first application is `environments/legacy-banking-console/`.

## Application identity

Northstar Mutual is a fictional institution. Meridian Core is its internal servicing console, modeled on older frame-based banking software. The interface uses dense tables, compact Tahoma or Arial text, image toolbars, inset panels, and a status strip. Its visual palette is navy `#23394d`, toolbar grey `#d2d1c9`, paper `#f1f0e8`, white `#ffffff`, muted teal `#42636b`, and amber `#8f6028`.

The app is desktop-oriented. Smaller viewports may require horizontal scrolling, as real legacy applications do. Records, controls, and their relationships must remain understandable to a careful human. Avoid marketing content and visible benchmark machinery. All records and transactions are synthetic.

## Application capabilities

The console exposes the full member-servicing and financial operation surface through rendered documents. Every consequential submission is a governed service command; every command is reachable through ordinary visible controls, a bound review document, and a durable receipt.

| Area | Required operations |
| --- | --- |
| Members | Browse, search, create persons and organizations, view identity/contact information, edit contact, names, tax classification and beneficial owners, record deceased status, merge duplicates, add notes. |
| Identity and documents | Index and annotate documents, retrieve stored statement bytes, collect signatures, record and withdraw consent, request customer exports, apply retention holds. |
| Accounts | List member accounts, inspect identity/product/status/balances/parties/holds/restrictions/cards, open and close accounts, edit nickname and statement delivery, place and release holds, apply and lift restrictions, reconcile suspense. |
| Money | Inspect history, post deposits, withdrawals and reversals, transfer between eligible accounts, correct effective dates, post interest, assess and reverse fees. |
| Payments | Create, update, release, hold and recall payments; maintain beneficiaries and their routes; create and manage schedules; apply, settle, reject and reclaim direct debits and credits. |
| Cards and disputes | Issue, replace, activate, lock, unlock and cancel cards; set PINs; open, update, provisionally credit, escalate, resolve and withdraw disputes; charge back card transactions. |
| Lending | Book and modify loans, post disbursements, repayments, rate changes, schedule restructures, write-offs and recoveries. |
| Batches and imports | Create, validate, post, reverse and reconcile payment and member-import batches; release batch items; correct suspense items. |
| Cases and servicing | Open, update, route, link and resolve cases; manage service requests, communications, escalations and information requests. |
| Approvals and reconciliation | Request, decide and release approvals; inspect registers, activity, receipts and reconciliation positions; export statements and artifacts. |
| Navigation | Reach every supported operation through ordinary visible controls, including returning to prior modules. |

The authoritative command list is the shared financial services package (`../database/financial/`). `src/operations.ts` must render an operation for every command kind; `test/operations.test.ts` enforces the parity.

Money uses integer minor units and an explicit currency. Transfers update both accounts atomically. The shared services enforce invalid amounts, overdrafts, closed accounts, unsupported products, permission grants, and approval policies. Reviewed submissions bind to their exact inputs and record/dependency versions; stale forms and accidental duplicate commitments are refused. Server-side validation remains authoritative.

Navigation and account selection must not restrict an instance to a preselected member, target account, or prescribed sequence. An instance is a UI session bound to a dataset of a named financial world. Instances can share a dataset or hold isolated clones. Refreshes, additional windows, and other applications attached to the same dataset read its current records.

The shared financial database owns worlds, datasets, seed generation, commands, reviews, receipts and mutation rules. Business data persists across application restarts. UI capabilities and form state may expire on restart. The service layer validates record and dataset state inside its write transactions, preventing an old form from overwriting a newer change made through another application.

## Structural coverage

The default layout combines difficult features. Layout profiles may isolate or combine features for future verification, but application functionality is the priority. Advertise only features that are implemented and exercised.

| Challenge | Required application behavior |
| --- | --- |
| Deeply nested frames | Real operations occur below at least three iframe boundaries. |
| Cross-origin frames | Documents use two distinct loopback origins. Ordinary page JavaScript cannot cross the boundary. |
| Repeated controls | Repeated controls are identified by visible surrounding member/account context. |
| Hidden duplicate controls | Legacy templates coexist with visible forms without becoming the active form. |
| Nested scrolling | Frames and internal panels can scroll independently. |
| Sticky headers and clipping | Dense registers have headers and clipped scrolling regions. |
| Scaled geometry | A layout profile changes frame geometry without breaking human operation. |
| Generated identifiers | DOM IDs vary between document loads; business identity remains stable. |
| Weak semantics | Some image and generic controls require visible context. |
| Keyboard focus | Navigation and typing span nested frame documents. |
| Frame replacement | Ordinary module navigation replaces documents and invalidates old handles. |
| Separate windows | Account statements or inquiries open in a separate identifiable browser window. |

## Environment administration

A separate protected loopback listener creates an isolated clone and instance from `{seed, profile}`, attaches an instance to an existing dataset with `{datasetId, profile}`, or binds an instance to a named world with `{world, profile, institutionId?}`. It inspects or exports current state, resets an instance, and disposes of it. Creation identifies the instance, dataset, and entry URL. It does not select tasks or reveal an answer key.

Reset replaces only the requesting instance: seed-backed instances get a fresh clone of the world, world-bound instances re-attach to the shared world, and attached instances get a private clone of the attached dataset. Other instances keep their current dataset and records. Disposal removes the UI session without deleting shared business data. Application startup binds the demo to a named world and seeds that world only when it is absent; it must not reseed on every start.

Admin requests require a bearer credential and reject browser-origin requests. Application HTML does not contain admin credentials or links to admin APIs. Instance identifiers are unguessable; resets invalidate old instance URLs. Bound request sizes, active instances, pending reviews, and settled-receipt caches. HTML and CSV exports must treat user-entered content as data.

This boundary protects against ordinary browser requests, not a process with unrestricted access to the host filesystem or network. A future agent runner must enforce that isolation itself. Instances are local synthetic application state, not access to an actual institution.

## Functional evidence

Store tests check review/commit flows, durable receipts, idempotent settlement, duplicate outcomes, stale-version refusals, permission grants, operator switching, reset isolation and instance capacity. HTTP checks exercise parsing, admin isolation, and listener cleanup. Browser checks operate visible controls for implemented application features across every structural profile, inspect resulting state, prove the structural features are present, and save screenshots. The evaluator-qualified run (`verification/qualification.spec.ts`) drives a deposit through the rendered frames inside an isolated verification run and lets the evaluator grade the resulting database state. Functional tests use private administration only to prepare and inspect instances. Tests use temporary databases and must not change the shared demonstration records.

No reference browser sequence is described as LLM discovery or benchmark performance. Runtime fault injection, human takeover protocols, agent capabilities, and workflow scoring remain future work.

