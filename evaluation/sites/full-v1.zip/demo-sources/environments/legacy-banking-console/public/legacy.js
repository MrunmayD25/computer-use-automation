function activateControl(event) {
  if (!(event.target instanceof Element)) return;
  const control = event.target.closest('[data-href]');
  if (!(control instanceof HTMLElement)) return;
  if (event instanceof KeyboardEvent && event.key !== 'Enter' && event.key !== ' ') return;
  const destination = new URL(control.dataset.href, window.location.href);
  if (destination.origin !== window.location.origin) return;
  event.preventDefault();
  if (control.dataset.target === '_parent') window.open(destination.href, '_parent');
  else window.location.assign(destination.href);
}

document.addEventListener('click', activateControl);
document.addEventListener('keydown', activateControl);
