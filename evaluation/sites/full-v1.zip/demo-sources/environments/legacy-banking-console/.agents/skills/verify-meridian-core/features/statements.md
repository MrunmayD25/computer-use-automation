# Statements, structure, and instances

## Sub-features

Statement-period inquiry and CSV/PDF export, stored document downloads, cross-origin frames, generated identifiers, clipping and scrolling, weak controls, popup windows, isolated application instances, and evaluator-qualified verification runs.

## How to get to it (user POV)

Open an account and select Statements. Depending on the layout profile, the statement document opens in the same frame or a separate window. Download CSV or PDF from the statement periods table; stored member documents download from the Documents module.

## Driving it with Playwright

`verification/documents.spec.ts` exercises statements and exported bytes. `verification/structure.ts` checks actual frame boundaries and geometry. `verification/admin.spec.ts` checks instance isolation and administration restrictions. `verification/shared-data.spec.ts` checks shared records, stale contact edits, and peer access after reset and disposal. `verification/qualification.spec.ts` runs the evaluator contract `evaluation/verifier/app-qualification/legacy-banking-console-deposit.mjs`. Run the full suite with `npm run verify`.

## Gotchas

A popup shares its instance's dataset. Returning to the original page requires choosing the correct browser page. Raw page JavaScript cannot traverse cross-origin frame documents; under weak semantics row commands are `span[data-href]` generics, not links. Administration credentials belong to the test fixture, never the UI. Reset invalidates only the requesting instance's old URL and attaches its replacement to a fresh clone or re-attachment; peer sessions retain their shared data. `datasets.revision` in admin state is set at seed time and does not increment per write; prove mutations through records and receipts, not revision deltas.
