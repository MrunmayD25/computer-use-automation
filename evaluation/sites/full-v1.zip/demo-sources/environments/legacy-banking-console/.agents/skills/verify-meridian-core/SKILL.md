---
name: verify-meridian-core
description: Verify the legacy banking console through its real browser UI and inspect its isolated synthetic state. Use for changes within environments/legacy-banking-console, not for agent benchmarks or other applications.
---

# Verify Meridian Core

Run commands from `environments/legacy-banking-console/`.

## Launch

Install workspace dependencies with `npm ci` from `environments/` and run `npm run build` there before verification. Install the browser with `npx playwright install chromium` when missing. From this application's folder, `npm run verify` starts its own application, frame, and administration listeners on ephemeral loopback ports with a temporary database. It closes them after the suite. An existing manual instance can remain running without sharing data with the tests.

For manual inspection, run `npm start -- --verbose`. Open `http://127.0.0.1:4310`. The frame origin uses port 4311 and administration uses 4312. Record the process you start and stop only that process afterward. Use `--port`, `--frame-port`, `--admin-port`, and `--admin-token-file` to isolate another process. Use `--database <temporary-path>` for a disposable manual dataset. Without that flag, the app opens the persistent shared database at `../database/financial/.runtime/financial.sqlite` and seeds the `financial-demo-v1` world when it is absent.

## Doctor

Run `npm run typecheck`. For a manual instance, `curl -fsSL http://127.0.0.1:4310` must return the Meridian Core shell, not another service. The shell alone is not proof that its cross-origin frames loaded; inspect the actual browser before acting.

## Drive

Run `npm run check` from `environments/` for shared-database and application checks. Run `npm run verify` for the browser suite. Targeted examples from the application folder are `npm run verify -- --grep 'supports ordinary member'` and `npm run verify -- --grep 'statements'`.

Use `verification/reference.ts` to find the actual document containing visible content. The combined profile has weak label relationships and generic row controls. Use visible row captions and identifiers, as the tests do. Do not add test IDs or repair legacy semantics to accommodate a test selector.

The administration interface may create, inspect, reset, export, or dispose of test instances. Attach peer instances using `datasetId` when checking shared data. Reset detaches only the requesting instance to a fresh dataset; disposal removes only its UI session. Business actions must go through rendered controls in browser tests. Do not use direct store mutations or HTTP form requests as a substitute for a claimed UI check.

## Evidence

Playwright writes `verification/artifacts/<run-id>/results.json`, screenshots beneath `verification/artifacts/<run-id>/browser/`, and traces on failure. Each invocation generates a unique run ID. Check both visible results and persisted instance state when verifying mutations. A screenshot alone does not establish that a transfer or contact edit persisted.

These tests verify application behavior. They are not agent workflows, grading oracles, capability artifacts, or evidence of model-driven discovery. Keep administrative credentials outside screenshots and reports.

## Cleanup

The fixture in `verification/fixtures.ts` closes the three test listeners and disposes of its API client. If overriding `MERIDIAN_VERIFICATION_RUN`, use a distinct value for each concurrent invocation. Stop only manual server processes created for the current check. Keep evidence after cleanup.

## Helpers

The existing npm scripts and Playwright files are the helpers. The feature map below describes their coverage without duplicating implementation.

- [Feature map](features/README.md)
