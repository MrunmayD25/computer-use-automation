# Members

## Sub-features

Browse and search the directory, create person and organization members, update contact information, record identity changes, merge duplicates, add notes, and manage member documents, cases, requests, and communications.

## How to get to it (user POV)

Open the application and use Member Search, Members, or the Operations index in the navigation. Open the row matching a visible member number to inspect details; member detail documents embed an account register and expose maintenance links.

## Driving it with Playwright

`verification/application.spec.ts` exercises directory search across layout profiles and seeds. `verification/operations.spec.ts` creates a member and verifies contact and note changes. `verification/shared-data.spec.ts` proves cross-instance writes and stale-form refusal. Run `npm run verify -- --grep 'member'`.

## Gotchas

Names are deliberately duplicated. The exact member number distinguishes records. Weak forms expose captions without reliable label associations, and submits are unlabeled image inputs inside the visible form. A navigation label can appear in several frames; choose the document containing the active form or table. Member writes need a servicer operator (OP0002) — OP0001 is viewer-only by design; switch on the Operator page.
