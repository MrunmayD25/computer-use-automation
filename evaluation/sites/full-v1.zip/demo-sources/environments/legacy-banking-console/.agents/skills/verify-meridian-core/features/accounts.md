# Accounts and money

## Sub-features

Account inquiry, opening, nickname and delivery maintenance, closure, holds, restrictions, fees, deposits, withdrawals, reversals, internal transfers, effective-date corrections, interest, payments and schedules, beneficiaries, cards, disputes, lending, batches, and suspense.

## How to get to it (user POV)

Open an account by its visible number through Accounts or a member's account register. Account detail documents expose the operation links for that account; the Operations index exposes the same commands with a subject picker. Registers cover accounts, transactions, batches, suspense and reconciliation.

## Driving it with Playwright

Run `npm run verify -- --grep 'supports ordinary member'`. The operation tests exercise account and money controls end to end. `verification/documents.spec.ts` exercises history and statement export. `verification/qualification.spec.ts` drives a deposit inside an evaluator verification run and lets the evaluator grade the resulting database state. Store tests in `test/instance-store.test.ts` check review/commit, receipts, stale versions, duplicates, and capacity.

## Gotchas

The hard layout can put the account register in another document. A review binds to the exact account, amount, subject versions, and dataset state; posting an old review refuses instead of writing an unintended transaction. Amounts are entered in major units and rendered with the account currency. Loan accounts appear in member registers but not in the customer Accounts register.
