# Meridian Core feature map

- [Members](members.md) covers browsing, search, creation, contact and identity maintenance, notes, documents, and cases.
- [Accounts and money](accounts.md) covers account maintenance, holds, fees, money movement, payments, cards, disputes, lending, and batches.
- [Statements, structure, and instances](statements.md) covers documents, frame geometry, evaluator-qualified runs, and application-instance administration.

The Operations index lists every governed command grouped by area; each renders a bound form, a review document, and a durable receipt. The authoritative command list is the shared financial services package; `test/operations.test.ts` pins parity.
