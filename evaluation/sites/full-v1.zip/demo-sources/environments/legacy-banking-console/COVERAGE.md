# legacy-banking-console coverage

## Full-v1 qualification

Release verdict: FULL-V1 COMPLETE

- Source commit: `6bb6219c4fc24f7652055f93a2b33ff1fce3fd66`
- Evidence run: `full-v1-6bb6219-20260921-handoff`
- Visible task options: 102/102
- Workflow path and recovery branches: 30/30
- Family mechanism: frame-console
- Shared-world checks: 3/3
- Durable records: `environments/legacy-banking-console/verification/evidence/full-v1-6bb6219-20260921-handoff/`

The option-level matrix and exact commands, tests, visible entries/results, business effects, artifact paths, and recovery observations are in `capability-manifest.json` and the evidence directory.

## Reproduce the release audit

Run `npm --prefix environments run audit:full-v1` from the repository root. The audit fails closed on missing, stale, ignored, untracked, or wrong-application artifacts.
